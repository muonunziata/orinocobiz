<?php
/**
 * «Ficha PDF» of an investment project: the standard sheet as a downloadable A4 PDF, built on
 * the fly from the same fields as the «Ficha de proyecto» widget (stage, estimate vs verified
 * figure, technical sheet, pending validations, public documents) in the language of the
 * project. URL: the project's address + ?ficha=pdf. Only what the public sheet shows goes in.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

defined( 'ABSPATH' ) || die();

require_once __DIR__ . '/pdf.php';

class Sheet {

	const M   = 48;   // Page margin (pt).
	const TOP = 64;   // First line on continuation pages.
	const BOT = 64;   // Space kept for the footer.

	/** @var Pdf */
	private $pdf;
	private $y = 0;
	private $c = [];
	private $p;

	public static function init() {
		add_action( 'template_redirect', [ __CLASS__, 'serve' ], 4 );
	}

	/** Address of the PDF of a project. */
	public static function url( $project ) {
		$u = get_permalink( $project );
		return $u ? add_query_arg( 'ficha', 'pdf', $u ) : '';
	}

	public static function serve() {
		if ( empty( $_GET['ficha'] ) || ! is_singular( Module::PROJECT ) ) { return; } // phpcs:ignore WordPress.Security.NonceVerification
		$p = get_queried_object();
		if ( ! $p instanceof \WP_Post || ( 'publish' !== $p->post_status && ! current_user_can( 'edit_post', $p->ID ) ) ) { return; }
		$data = ( new self() )->build( $p );
		$name = sanitize_file_name( ( Module::meta( $p->ID, 'code' ) ? Module::meta( $p->ID, 'code' ) . '-' : '' ) . ( $p->post_name ?: 'proyecto-' . $p->ID ) ) . '.pdf';
		nocache_headers();
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: attachment; filename="' . $name . '"' );
		header( 'Content-Length: ' . strlen( $data ) );
		header( 'X-Robots-Tag: noindex' );
		echo $data; // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	/** Brand colours: Territorio settings, else the Elementor kit, else Wakoo's navy and gold. */
	public static function colors() {
		$s   = Module::settings();
		$kit = [];
		if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->kits_manager ) ) {
			$k = \Elementor\Plugin::$instance->kits_manager->get_active_kit_for_frontend();
			foreach ( $k ? (array) $k->get_settings( 'system_colors' ) : [] as $c ) {
				if ( ! empty( $c['_id'] ) && ! empty( $c['color'] ) ) { $kit[ $c['_id'] ] = substr( (string) $c['color'], 0, 7 ); }
			}
		}
		$pick = function ( ...$v ) { foreach ( $v as $x ) { if ( $x && sanitize_hex_color( $x ) ) { return $x; } } return ''; };
		return [
			'main'   => $pick( $s['pdf_color'], $kit['primary'] ?? '', '#10355B' ),
			'accent' => $pick( $s['pdf_accent'], $kit['accent'] ?? '', '#C5A15B' ),
			'text'   => '#24303D',
			'muted'  => '#5B6878',
			'line'   => '#D8DEE6',
			'soft'   => '#F2F5F8',
		];
	}

	/** Rich text → plain paragraphs. */
	private static function plain( $html ) {
		$html = preg_replace( '#<li[^>]*>#i', "\n• ", (string) $html );
		$html = preg_replace( '#</(p|div|h[1-6]|li|ul|ol|blockquote)>|<br\s*/?>#i', "\n", $html );
		$txt  = html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES, 'UTF-8' );
		return trim( preg_replace( "/\n{2,}/", "\n", preg_replace( "/[ \t]+/", ' ', $txt ) ) );
	}

	private function m( $k ) { return trim( (string) Module::meta( $this->p->ID, $k ) ); }

	/* ---------------------------------------------------------------- layout helpers */

	private function cw() { return Pdf::W - 2 * self::M; }

	/** New page when $h points do not fit. */
	private function need( $h ) {
		if ( $this->y + $h <= Pdf::H - self::BOT ) { return; }
		$this->pdf->add_page();
		$this->pdf->rect( 0, 0, Pdf::W, 6, $this->c['main'] );
		$this->pdf->font( 'B', 8 );
		$this->pdf->text( self::M, 34, mb_strimwidth( get_the_title( $this->p ), 0, 110, '…' ), $this->c['muted'] );
		$this->pdf->line( self::M, 42, Pdf::W - self::M, 42, $this->c['line'] );
		$this->y = self::TOP;
	}

	/** Wrapped paragraph from the cursor. */
	private function para( $text, $size = 9.5, $style = 'R', $color = null, $x = null, $w = null, $lh = 1.42 ) {
		$x = null === $x ? self::M : $x;
		$w = null === $w ? $this->cw() : $w;
		$this->pdf->font( $style, $size );
		foreach ( $this->pdf->wrap( $text, $w ) as $line ) {
			$this->need( $size * $lh );
			$this->y += $size * $lh;
			$this->pdf->text( $x, $this->y - $size * ( $lh - 1 ) / 2 - 1, $line, $color ?: $this->c['text'] );
		}
	}

	private function heading( $text ) {
		$this->need( 44 );
		$this->y += 18;
		$this->pdf->rect( self::M, $this->y + 2, 22, 2.4, $this->c['accent'] );
		$this->y += 8;
		$this->para( mb_strtoupper( $text ), 9, 'B', $this->c['main'] );
		$this->y += 4;
	}

	/* ---------------------------------------------------------------- the sheet */

	public function build( \WP_Post $p ) {
		$this->p   = $p;
		$this->c   = self::colors();
		$this->pdf = new Pdf( false !== stripos( (string) get_post_meta( $p->ID, '_wakoo_lang', true ), 'cn' ) ? 'cn' : 'tw' );
		$pdf       = $this->pdf;
		$c         = $this->c;
		$M         = self::M;
		$W         = $this->cw();
		$site      = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$stages    = Module::stages();
		$stage     = $this->m( 'stage' ) ?: 'conceptual';
		$none      = __( 'Por definir', 'wakoo' );

		// Header band.
		$pdf->add_page();
		$pdf->rect( 0, 0, Pdf::W, 104, $c['main'] );
		$pdf->rect( 0, 104, Pdf::W, 3, $c['accent'] );
		$pdf->font( 'B', 10 );
		$pdf->text( $M, 40, $site, '#FFFFFF' );
		$pdf->font( 'R', 8.5 );
		$pdf->text( Pdf::W - $M, 40, mb_strtoupper( __( 'Ficha de proyecto', 'wakoo' ) ), '#FFFFFF', 'R' );
		$chip = trim( $this->m( 'code' ) . '   ' . ( $stages[ $stage ] ?? '' ) );
		$pdf->font( 'B', 8.5 );
		$cwid = $pdf->width( $chip ) + 20;
		$pdf->rect( $M, 58, $cwid, 22, $c['accent'], null, 0, 11 );
		$pdf->text( $M + 10, 72.5, $chip, $c['main'] );
		$scale = Admin::fields( Module::PROJECT )['scale'][2][ $this->m( 'scale' ) ] ?? '';
		if ( $scale && '—' !== $scale ) {
			$pdf->font( 'R', 8.5 );
			$pdf->rect( $M + $cwid + 8, 58, $pdf->width( $scale ) + 20, 22, null, '#FFFFFF', 0.8, 11 );
			$pdf->text( $M + $cwid + 18, 72.5, $scale, '#FFFFFF' );
		}

		// Title and objective.
		$this->y = 122;
		$this->para( get_the_title( $p ), 19, 'B', $c['main'], null, null, 1.25 );
		if ( $this->m( 'objective' ) ) { $this->y += 4; $this->para( $this->m( 'objective' ), 10.5, 'R', $c['muted'] ); }

		// Photo of the project, when there is one.
		$img = $this->photo( $p );
		if ( $img ) {
			$this->need( 196 );
			$this->y += 14;
			if ( $pdf->image( $img, $M, $this->y, $W, 180 ) ) { $this->y += 180; }
			@unlink( $img ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
		}

		// Stage track (the six stages in order; «suspended» is shown apart).
		$this->need( 70 );
		$this->y += 18;
		$pdf->font( 'B', 7.5 );
		$pdf->text( $M, $this->y, mb_strtoupper( __( 'Estado de preparación', 'wakoo' ) ), $c['muted'] );
		$this->y += 8;
		$keys = array_keys( $stages );
		$pos  = array_search( $stage, $keys, true );
		$gap  = 4;
		$bw   = ( $W - 5 * $gap ) / 6;
		foreach ( array_slice( $stages, 0, 6, true ) as $k => $l ) {
			$i    = array_search( $k, $keys, true );
			$x    = $M + $i * ( $bw + $gap );
			$done = 'suspendido' !== $stage && $i < $pos;
			$now  = 'suspendido' !== $stage && $i === $pos;
			$pdf->rect( $x, $this->y, $bw, 30, $now ? $c['main'] : ( $done ? $c['soft'] : null ), $now ? null : $c['line'], 0.7, 4 );
			$pdf->font( $now ? 'B' : 'R', 7 );
			$lines = array_slice( $pdf->wrap( $l, $bw - 8 ), 0, 2 );
			$ty    = $this->y + ( 2 === count( $lines ) ? 13 : 18 );
			foreach ( $lines as $j => $ln ) { $pdf->text( $x + $bw / 2, $ty + $j * 8.5, $ln, $now ? '#FFFFFF' : ( $done ? $c['main'] : $c['muted'] ), 'C' ); }
		}
		$this->y += 30;
		if ( 'suspendido' === $stage ) { $this->y += 4; $this->para( $stages['suspendido'], 8.5, 'B', $c['muted'] ); }

		// Investment and location, side by side.
		$this->need( 120 );
		$this->y += 18;
		$top  = $this->y;
		$half = ( $W - 12 ) / 2;
		$this->box_money( $M, $top, $half );
		$h1 = $this->y - $top;
		$this->y = $top;
		$this->box_place( $M + $half + 12, $top, $half );
		$h2 = $this->y - $top;
		$h  = max( $h1, $h2 );
		$this->y = $top + $h;

		// Description.
		$desc = self::plain( apply_filters( 'the_content', $p->post_content ) ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals
		if ( '' !== $desc ) {
			$this->heading( __( 'Descripción', 'wakoo' ) );
			foreach ( explode( "\n", $desc ) as $par ) { $this->para( $par ); $this->y += 5; }
		}

		// Technical sheet.
		$this->heading( __( 'Ficha técnica', 'wakoo' ) );
		$f    = Admin::fields( Module::PROJECT );
		$rows = [ __( 'Sector', 'wakoo' ) => Module::term_names( $p->ID, Module::T_SECTOR ), __( 'Municipio', 'wakoo' ) => Module::term_names( $p->ID, Module::T_MUN ) ];
		foreach ( [ 'market', 'infra', 'permits', 'studies', 'jobs', 'risks', 'timeline', 'precond', 'responsible' ] as $k ) { $rows[ $f[ $k ][0] ] = $this->m( $k ); }
		$lw = 140;
		foreach ( $rows as $label => $val ) {
			$pdf->font( 'R', 9.5 );
			$vl = $pdf->wrap( '' !== $val ? $val : $none, $W - $lw - 10 );
			$pdf->font( 'B', 8.5 );
			$ll = $pdf->wrap( $label, $lw - 8 );
			$rh = max( count( $vl ) * 13.5, count( $ll ) * 12 ) + 12;
			if ( $rh < Pdf::H - self::BOT - self::TOP ) { $this->need( $rh ); }
			$y0 = $this->y;
			$this->y += 4;
			$this->para( $label, 8.5, 'B', $c['main'], $M, $lw - 8, 1.41 );
			$ya = $this->y;
			$this->y = $y0 + 4;
			$this->para( '' !== $val ? $val : $none, 9.5, 'R', '' !== $val ? $c['text'] : $c['muted'], $M + $lw, $W - $lw, 1.42 );
			$this->y = max( $this->y, $ya ) + 6;
			$pdf->line( $M, $this->y, $M + $W, $this->y, $c['line'], 0.5 );
		}

		// Data still to be validated.
		$pend = array_values( array_filter( array_map( function ( $l ) { return trim( ltrim( trim( $l ), '-•· ' ) ); }, preg_split( '/\r\n|\r|\n/', $this->m( 'pending' ) ) ) ) );
		if ( $pend ) {
			$this->heading( __( 'Datos pendientes de validación', 'wakoo' ) );
			foreach ( $pend as $l ) {
				$this->need( 16 );
				$pdf->rect( $M + 2, $this->y + 7, 4, 4, $c['accent'], null, 0, 2 );
				$this->para( $l, 9.5, 'R', null, $M + 14, $W - 14 );
				$this->y += 3;
			}
		}

		// Public documents.
		$this->heading( __( 'Documentación pública', 'wakoo' ) );
		$docs = [];
		foreach ( preg_split( '/\r\n|\r|\n/', $this->m( 'docs' ) ) as $l ) {
			$l = trim( $l );
			if ( '' === $l ) { continue; }
			$parts  = array_map( 'trim', explode( '|', $l, 2 ) );
			$docs[] = [ $parts[0], esc_url_raw( $parts[1] ?? '' ) ];
		}
		if ( $docs ) {
			foreach ( $docs as $d ) {
				$y0 = $this->y;
				$this->para( '• ' . $d[0], 9.5, 'B', $d[1] ? $c['main'] : $c['text'] );
				if ( $d[1] ) { $pdf->link( $M, $y0, $W, $this->y - $y0 + 2, $d[1] ); $this->para( $d[1], 7.5, 'R', $c['muted'], $M + 12, $W - 12 ); }
				$this->y += 4;
			}
		} else {
			$this->para( __( 'Todavía no hay documentos públicos de este proyecto.', 'wakoo' ), 9.5, 'R', $c['muted'] );
		}
		if ( $this->m( 'source' ) ) { $this->y += 4; $this->para( $f['source'][0] . ': ' . $this->m( 'source' ), 8, 'R', $c['muted'] ); }

		// Call to action: the ventanilla with the project code, and the sheet online.
		$this->need( 96 );
		$this->y += 20;
		$cta  = Module::page_url( 'cases_new' ) ?: Module::page_url( 'cases' );
		$live = get_permalink( $p );
		$pdf->rect( $M, $this->y, $W, 64, $c['soft'], null, 0, 6 );
		$pdf->font( 'B', 10.5 );
		$label = __( 'Manifestar interés por este proyecto', 'wakoo' );
		if ( $cta ) {
			$cta = add_query_arg( 'proyecto', rawurlencode( $this->m( 'code' ) ?: (string) $p->ID ), $cta );
			$bw  = min( $W - 32, $pdf->width( $label ) + 34 );
			$pdf->rect( $M + 16, $this->y + 14, $bw, 34, $c['main'], null, 0, 17 );
			$pdf->text( $M + 16 + $bw / 2, $this->y + 35, $label, '#FFFFFF', 'C' );
			$pdf->link( $M + 16, $this->y + 14, $bw, 34, $cta );
			$tx = $M + 32 + $bw;
		} else {
			$tx = $M + 16;
		}
		$pdf->font( 'B', 8 );
		$pdf->text( $tx, $this->y + 27, __( 'Ficha en línea', 'wakoo' ), $c['main'] );
		$pdf->font( 'R', 7.5 );
		$short = preg_replace( '#^https?://#', '', $live );
		$sl    = $pdf->wrap( $short, max( 80, $M + $W - 16 - $tx ) );
		foreach ( array_slice( $sl, 0, 2 ) as $j => $ln ) { $pdf->text( $tx, $this->y + 39 + $j * 9.5, $ln, $c['muted'] ); }
		$pdf->link( $tx, $this->y + 18, $M + $W - $tx, 36, $live );
		$this->y += 64;

		// Disclaimer.
		$this->y += 14;
		$this->para( __( 'La información de esta ficha es una propuesta para evaluación. No constituye una oferta, un permiso ni un compromiso de las instituciones.', 'wakoo' ), 7.5, 'R', $c['muted'] );

		// Footer on every page, now that the count is known.
		$total = $pdf->pages();
		$gen   = sprintf( __( 'Generada el %s', 'wakoo' ), wp_date( 'd/m/Y' ) );
		for ( $i = 1; $i <= $total; $i++ ) {
			$pdf->on_page( $i );
			$pdf->line( $M, Pdf::H - 40, Pdf::W - $M, Pdf::H - 40, $c['line'], 0.5 );
			$pdf->font( 'R', 7 );
			$pdf->text( $M, Pdf::H - 27, $site . ' · ' . preg_replace( '#^https?://|/$#', '', home_url( '/' ) ) . ' · ' . $gen, $c['muted'] );
			$pdf->text( Pdf::W - $M, Pdf::H - 27, sprintf( __( 'Página %1$d de %2$d', 'wakoo' ), $i, $total ), $c['muted'], 'R' );
		}
		return $pdf->output( get_the_title( $p ), $site );
	}

	private function box_money( $x, $y, $w ) {
		$pdf = $this->pdf;
		$c   = $this->c;
		$money = Module::money( $this->p->ID );
		$this->y = $y + 16;
		$pdf->font( 'B', 7.5 );
		$pdf->text( $x + 14, $this->y + 6, mb_strtoupper( __( 'Inversión', 'wakoo' ) ), $c['muted'] );
		$this->y += 10;
		if ( $money ) {
			$ver = 'verified' === $this->m( 'amount_kind' );
			$this->para( $money, 18, 'B', $c['main'], $x + 14, $w - 28, 1.3 );
			$this->para( $ver ? __( 'Cifra verificada', 'wakoo' ) : __( 'Estimación (no es una cifra verificada)', 'wakoo' ), 8, 'B', $ver ? '#1E7A46' : '#8A5A00', $x + 14, $w - 28 );
			$this->y += 2;
			$this->para( __( 'Fuente', 'wakoo' ) . ': ' . ( $this->m( 'amount_src' ) ?: __( 'Por definir', 'wakoo' ) ), 8, 'R', $c['muted'], $x + 14, $w - 28 );
			$this->para( __( 'Fecha', 'wakoo' ) . ': ' . ( $this->m( 'amount_date' ) ? date_i18n( 'd/m/Y', strtotime( $this->m( 'amount_date' ) ) ) : __( 'Por definir', 'wakoo' ) ), 8, 'R', $c['muted'], $x + 14, $w - 28 );
		} else {
			$this->para( __( 'No hay una estimación de inversión publicada para este proyecto.', 'wakoo' ), 9, 'R', $c['muted'], $x + 14, $w - 28 );
		}
		$this->y += 14;
		$this->frame( $x, $y, $w );
	}

	private function box_place( $x, $y, $w ) {
		$pdf = $this->pdf;
		$c   = $this->c;
		$this->y = $y + 16;
		$pdf->font( 'B', 7.5 );
		$pdf->text( $x + 14, $this->y + 6, mb_strtoupper( __( 'Ubicación', 'wakoo' ) ), $c['muted'] );
		$this->y += 10;
		if ( $this->m( 'location' ) ) { $this->para( $this->m( 'location' ), 9.5, 'B', $c['text'], $x + 14, $w - 28 ); }
		$lat = $this->m( 'lat' );
		$lng = $this->m( 'lng' );
		if ( 'yes' === $this->m( 'geo_ok' ) && is_numeric( $lat ) && is_numeric( $lng ) ) {
			$y0 = $this->y;
			$this->para( $lat . ', ' . $lng, 8.5, 'R', $c['main'], $x + 14, $w - 28 );
			$pdf->link( $x + 14, $y0, $w - 28, $this->y - $y0 + 2, 'https://www.google.com/maps?q=' . rawurlencode( $lat . ',' . $lng ) );
			$this->para( __( 'Fuente', 'wakoo' ) . ': ' . ( $this->m( 'geo_source' ) ?: __( 'Por definir', 'wakoo' ) ), 8, 'R', $c['muted'], $x + 14, $w - 28 );
		} else {
			$this->para( __( 'La ubicación geográfica aún no está verificada, por eso no se muestra en el mapa.', 'wakoo' ), 8, 'R', $c['muted'], $x + 14, $w - 28 );
		}
		$this->y += 14;
		$this->frame( $x, $y, $w );
	}

	/** Box outline drawn after its content (height known), under the accent bar. */
	private function frame( $x, $y, $w ) {
		$this->pdf->rect( $x, $y, $w, $this->y - $y, null, $this->c['line'], 0.8, 6 );
		$this->pdf->rect( $x, $y + 10, 3, 18, $this->c['accent'] );
	}

	/** The project's featured image as a temporary JPEG (max 1400 px wide), or ''. */
	private function photo( $p ) {
		$id = (int) get_post_thumbnail_id( $p );
		$f  = $id ? get_attached_file( $id ) : '';
		if ( ! $f || ! file_exists( $f ) ) { return ''; }
		$ed = wp_get_image_editor( $f );
		if ( is_wp_error( $ed ) ) { return ''; }
		$ed->resize( 1400, 1400, false );
		$ed->set_quality( 80 );
		$base = wp_tempnam( 'wkt-sheet' );
		@unlink( $base ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
		$tmp = $base . '.jpg';
		$res = $ed->save( $tmp, 'image/jpeg' );
		return is_wp_error( $res ) ? '' : $res['path'];
	}
}
