<?php
/**
 * Small PDF writer (no library): A4 pages, the PDF standard fonts Helvetica and Helvetica-Bold
 * (WinAnsi, so Spanish, French and Italian text needs nothing embedded), Chinese runs with the
 * reader's built-in CJK font (MSung-Light / STSong-Light, not embedded), JPEG photos, filled
 * shapes and clickable links. Coordinates are in points from the top-left corner.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

defined( 'ABSPATH' ) || die();

class Pdf {

	const W = 595.28;
	const H = 841.89;
	const CJK_RE = '/([\x{2E80}-\x{9FFF}\x{F900}-\x{FAFF}\x{FE30}-\x{FE4F}\x{FF00}-\x{FFEF}])/u';

	/** Helvetica and Helvetica-Bold advance widths (1/1000 em) for WinAnsi codes 0-255 (Adobe AFM). */
	const WR = [
		278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278,
		278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556,
		1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556,
		333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584, 761,
		556, 761, 222, 556, 333, 1000, 556, 556, 333, 1000, 667, 333, 1000, 761, 611, 761, 761, 222, 222, 333, 333, 350, 556, 1000, 333, 1000, 500, 333, 944, 761, 500, 667,
		278, 333, 556, 556, 556, 556, 260, 556, 333, 737, 370, 556, 584, 333, 737, 333, 400, 584, 333, 333, 333, 556, 537, 278, 333, 333, 365, 556, 834, 834, 834, 611,
		667, 667, 667, 667, 667, 667, 1000, 722, 667, 667, 667, 667, 278, 278, 278, 278, 722, 722, 778, 778, 778, 778, 778, 584, 778, 722, 722, 722, 722, 667, 667, 611,
		556, 556, 556, 556, 556, 556, 889, 500, 556, 556, 556, 556, 278, 278, 278, 278, 556, 556, 556, 556, 556, 556, 556, 584, 611, 556, 556, 556, 556, 500, 556, 500
	];
	const WB = [
		278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278, 278,
		278, 333, 474, 556, 556, 889, 722, 238, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 333, 333, 584, 584, 584, 611,
		975, 722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722, 611, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 333, 278, 333, 584, 556,
		333, 556, 611, 556, 611, 556, 333, 611, 611, 278, 278, 556, 278, 889, 611, 611, 611, 611, 389, 556, 333, 611, 556, 778, 556, 556, 500, 389, 280, 389, 584, 761,
		556, 761, 278, 556, 500, 1000, 556, 556, 333, 1000, 667, 333, 1000, 761, 611, 761, 761, 278, 278, 500, 500, 350, 556, 1000, 333, 1000, 556, 333, 944, 761, 500, 667,
		278, 333, 556, 556, 556, 556, 280, 556, 333, 737, 370, 556, 584, 333, 737, 333, 400, 584, 333, 333, 333, 611, 556, 278, 333, 333, 365, 556, 834, 834, 834, 611,
		722, 722, 722, 722, 722, 722, 1000, 722, 667, 667, 667, 667, 278, 278, 278, 278, 722, 722, 778, 778, 778, 778, 778, 584, 778, 722, 722, 722, 722, 667, 667, 611,
		556, 556, 556, 556, 556, 556, 889, 556, 556, 556, 556, 556, 278, 278, 278, 278, 611, 611, 611, 611, 611, 611, 611, 584, 611, 611, 611, 611, 611, 556, 611, 556
	];

	private $pages  = [];
	private $annots = [];
	private $images = [];
	private $p      = -1;
	private $style  = 'R';
	private $size   = 10;
	private $cjk_used = false;
	private $cjk_font;

	/** $cjk: 'tw' (traditional Chinese, default) or 'cn' (simplified). */
	public function __construct( $cjk = 'tw' ) {
		$this->cjk_font = 'cn' === $cjk ? [ 'STSong-Light', 'UniGB-UCS2-H', 'GB1', 2 ] : [ 'MSung-Light', 'UniCNS-UCS2-H', 'CNS1', 0 ];
	}

	public function add_page() {
		$this->pages[]  = '';
		$this->annots[] = [];
		$this->p++;
	}

	public function page() { return $this->p + 1; }

	public function pages() { return count( $this->pages ); }

	/** Writes on page $n (1-based), e.g. footers once the page count is known. */
	public function on_page( $n ) { $this->p = max( 0, min( count( $this->pages ), (int) $n ) - 1 ); }

	private function out( $s ) { $this->pages[ $this->p ] .= $s . "\n"; }

	private static function rgb( $hex ) {
		$hex = ltrim( (string) $hex, '#' );
		if ( 3 === strlen( $hex ) ) { $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2]; }
		if ( ! preg_match( '/^[0-9a-f]{6}$/i', $hex ) ) { $hex = '000000'; }
		return sprintf( '%.3F %.3F %.3F', hexdec( substr( $hex, 0, 2 ) ) / 255, hexdec( substr( $hex, 2, 2 ) ) / 255, hexdec( substr( $hex, 4, 2 ) ) / 255 );
	}

	private static function n( $v ) { return rtrim( rtrim( sprintf( '%.2F', $v ), '0' ), '.' ); }

	/* ---------------------------------------------------------------- shapes */

	public function rect( $x, $y, $w, $h, $fill = null, $stroke = null, $lw = 0.6, $r = 0 ) {
		if ( null === $fill && null === $stroke ) { return; }
		$ops = ( $fill ? self::rgb( $fill ) . ' rg ' : '' ) . ( $stroke ? self::rgb( $stroke ) . ' RG ' . self::n( $lw ) . ' w ' : '' );
		$path = $r > 0 ? $this->round_path( $x, $y, $w, $h, $r ) : sprintf( '%s %s %s %s re', self::n( $x ), self::n( self::H - $y - $h ), self::n( $w ), self::n( $h ) );
		$this->out( 'q ' . $ops . $path . ' ' . ( $fill && $stroke ? 'B' : ( $fill ? 'f' : 'S' ) ) . ' Q' );
	}

	private function round_path( $x, $y, $w, $h, $r ) {
		$r  = min( $r, $w / 2, $h / 2 );
		$k  = 0.5523 * $r;
		$x1 = $x; $x2 = $x + $w; $t = self::H - $y; $b = self::H - $y - $h;
		$n  = [ __CLASS__, 'n' ];
		return implode( ' ', [
			$n( $x1 + $r ) . ' ' . $n( $t ) . ' m',
			$n( $x2 - $r ) . ' ' . $n( $t ) . ' l',
			$n( $x2 - $r + $k ) . ' ' . $n( $t ) . ' ' . $n( $x2 ) . ' ' . $n( $t - $r + $k ) . ' ' . $n( $x2 ) . ' ' . $n( $t - $r ) . ' c',
			$n( $x2 ) . ' ' . $n( $b + $r ) . ' l',
			$n( $x2 ) . ' ' . $n( $b + $r - $k ) . ' ' . $n( $x2 - $r + $k ) . ' ' . $n( $b ) . ' ' . $n( $x2 - $r ) . ' ' . $n( $b ) . ' c',
			$n( $x1 + $r ) . ' ' . $n( $b ) . ' l',
			$n( $x1 + $r - $k ) . ' ' . $n( $b ) . ' ' . $n( $x1 ) . ' ' . $n( $b + $r - $k ) . ' ' . $n( $x1 ) . ' ' . $n( $b + $r ) . ' c',
			$n( $x1 ) . ' ' . $n( $t - $r ) . ' l',
			$n( $x1 ) . ' ' . $n( $t - $r + $k ) . ' ' . $n( $x1 + $r - $k ) . ' ' . $n( $t ) . ' ' . $n( $x1 + $r ) . ' ' . $n( $t ) . ' c h',
		] );
	}

	public function line( $x1, $y1, $x2, $y2, $color = '#cccccc', $lw = 0.6 ) {
		$this->out( sprintf( 'q %s RG %s w %s %s m %s %s l S Q', self::rgb( $color ), self::n( $lw ), self::n( $x1 ), self::n( self::H - $y1 ), self::n( $x2 ), self::n( self::H - $y2 ) ) );
	}

	/** Clickable area that opens $url. */
	public function link( $x, $y, $w, $h, $url ) {
		if ( ! preg_match( '#^(https?:|mailto:)#i', (string) $url ) ) { return; }
		$this->annots[ $this->p ][] = sprintf( '<< /Type /Annot /Subtype /Link /Rect [%s %s %s %s] /Border [0 0 0] /A << /S /URI /URI (%s) >> >>', self::n( $x ), self::n( self::H - $y - $h ), self::n( $x + $w ), self::n( self::H - $y ), self::esc( preg_replace_callback( '/[^\x21-\x7E]/', function ( $m ) { return rawurlencode( $m[0] ); }, $url ) ) );
	}

	/* ---------------------------------------------------------------- text */

	public function font( $style = 'R', $size = 10 ) {
		$this->style = 'B' === $style ? 'B' : 'R';
		$this->size  = (float) $size;
	}

	private static function esc( $s ) {
		return str_replace( [ '\\', '(', ')', "\r" ], [ '\\\\', '\\(', '\\)', '' ], $s );
	}

	private static function latin( $s ) {
		$s = strtr( (string) $s, [ "\u{2009}" => ' ', "\u{202F}" => ' ', "\u{00A0}" => ' ', "\u{2192}" => '->', "\u{2190}" => '<-', "\u{2713}" => '', "\u{2264}" => '<=', "\u{2265}" => '>=' ] );
		$o = @iconv( 'UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $s ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		return false === $o ? (string) preg_replace( '/[^\x20-\x7E]/', '', $s ) : $o;
	}

	/** Text split into [ is_cjk, text ] runs. */
	private static function runs( $s ) {
		$out = [];
		foreach ( preg_split( self::CJK_RE, (string) $s, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY ) as $part ) {
			$cjk = (bool) preg_match( self::CJK_RE, $part );
			$n   = count( $out );
			if ( $n && $out[ $n - 1 ][0] === $cjk ) { $out[ $n - 1 ][1] .= $part; } else { $out[] = [ $cjk, $part ]; }
		}
		return $out;
	}

	/** Width of a string in points with the current font. */
	public function width( $s, $style = null, $size = null ) {
		$style = $style ?: $this->style;
		$size  = $size ?: $this->size;
		$tab   = 'B' === $style ? self::WB : self::WR;
		$w     = 0;
		foreach ( self::runs( $s ) as $r ) {
			if ( $r[0] ) { $w += 1000 * mb_strlen( $r[1] ); continue; }
			$b = self::latin( $r[1] );
			for ( $i = 0, $l = strlen( $b ); $i < $l; $i++ ) { $w += $tab[ ord( $b[ $i ] ) ]; }
		}
		return $w * $size / 1000;
	}

	/** One line of text; $y is the baseline. $align: L | C | R (around $x as left, centre or right). */
	public function text( $x, $y, $s, $color = '#222222', $align = 'L' ) {
		if ( '' === (string) $s ) { return; }
		if ( 'C' === $align ) { $x -= $this->width( $s ) / 2; } elseif ( 'R' === $align ) { $x -= $this->width( $s ); }
		$f   = 'B' === $this->style ? 'F2' : 'F1';
		$ops = 'BT ' . self::rgb( $color ) . ' rg ' . self::rgb( $color ) . ' RG ' . self::n( $x ) . ' ' . self::n( self::H - $y ) . ' Td ';
		foreach ( self::runs( $s ) as $r ) {
			if ( $r[0] ) {
				$this->cjk_used = true;
				$hex = strtoupper( bin2hex( mb_convert_encoding( $r[1], 'UTF-16BE', 'UTF-8' ) ) );
				$ops .= '/F3 ' . self::n( $this->size ) . ' Tf ' . ( 'B' === $this->style ? '2 Tr 0.25 w ' : '0 Tr ' ) . '<' . $hex . '> Tj ';
			} else {
				$ops .= '/' . $f . ' ' . self::n( $this->size ) . ' Tf 0 Tr (' . self::esc( self::latin( $r[1] ) ) . ') Tj ';
			}
		}
		$this->out( $ops . 'ET' );
	}

	/** Lines of $s that fit in $w points (keeps the line breaks of the text). */
	public function wrap( $s, $w ) {
		$lines = [];
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $s ) as $para ) {
			preg_match_all( '/[\x{2E80}-\x{9FFF}\x{F900}-\x{FAFF}\x{FE30}-\x{FE4F}\x{FF00}-\x{FFEF}]|[^\s\x{2E80}-\x{9FFF}\x{F900}-\x{FAFF}\x{FE30}-\x{FE4F}\x{FF00}-\x{FFEF}]+|\s+/u', $para, $m );
			$line = '';
			foreach ( $m[0] as $tok ) {
				if ( ctype_space( $tok ) ) { if ( '' !== $line ) { $line .= ' '; } continue; }
				if ( $this->width( $line . $tok ) <= $w ) { $line .= $tok; continue; }
				if ( '' !== trim( $line ) ) { $lines[] = rtrim( $line ); $line = ''; }
				while ( $this->width( $tok ) > $w && mb_strlen( $tok ) > 1 ) { // A word longer than the line (a URL): cut it.
					$cut = mb_strlen( $tok );
					while ( $cut > 1 && $this->width( mb_substr( $tok, 0, $cut ) ) > $w ) { $cut--; }
					$lines[] = mb_substr( $tok, 0, $cut );
					$tok     = mb_substr( $tok, $cut );
				}
				$line = $tok;
			}
			$lines[] = rtrim( $line );
		}
		return $lines;
	}

	/* ---------------------------------------------------------------- images */

	/** JPEG drawn to cover the box (cropped, like object-fit: cover). False when the file is not a usable JPEG. */
	public function image( $file, $x, $y, $w, $h ) {
		$info = @getimagesize( $file ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		if ( ! $info || IMAGETYPE_JPEG !== $info[2] ) { return false; }
		$data = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $data ) { return false; }
		$ch  = (int) ( $info['channels'] ?? 3 );
		$key = 'Im' . ( count( $this->images ) + 1 );
		$this->images[ $key ] = [ 'w' => $info[0], 'h' => $info[1], 'cs' => 1 === $ch ? 'DeviceGray' : ( 4 === $ch ? 'DeviceCMYK' : 'DeviceRGB' ), 'data' => $data, 'cmyk' => 4 === $ch ];
		$s  = max( $w / $info[0], $h / $info[1] );
		$iw = $info[0] * $s;
		$ih = $info[1] * $s;
		$ix = $x - ( $iw - $w ) / 2;
		$iy = $y - ( $ih - $h ) / 2;
		$this->out( sprintf( 'q %s %s %s %s re W n %s 0 0 %s %s %s cm /%s Do Q', self::n( $x ), self::n( self::H - $y - $h ), self::n( $w ), self::n( $h ), self::n( $iw ), self::n( $ih ), self::n( $ix ), self::n( self::H - $iy - $ih ), $key ) );
		return true;
	}

	/* ---------------------------------------------------------------- file */

	private static function utf16( $s ) {
		return '<FEFF' . strtoupper( bin2hex( mb_convert_encoding( (string) $s, 'UTF-16BE', 'UTF-8' ) ) ) . '>';
	}

	public function output( $title = '', $author = '' ) {
		$objs = [];
		$add  = function ( $body ) use ( &$objs ) { $objs[] = $body; return count( $objs ); };
		$cat  = $add( '' ); // 1: catalog, filled below.
		$pgs  = $add( '' ); // 2: page tree.
		$f1   = $add( '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>' );
		$f2   = $add( '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>' );
		$fonts = '/F1 ' . $f1 . ' 0 R /F2 ' . $f2 . ' 0 R';
		if ( $this->cjk_used ) {
			list( $name, $cmap, $order, $sup ) = $this->cjk_font;
			$desc  = $add( '<< /Type /FontDescriptor /FontName /' . $name . ' /Flags 6 /FontBBox [-160 -249 1015 1071] /ItalicAngle 0 /Ascent 880 /Descent -120 /CapHeight 880 /StemV 93 >>' );
			$cid   = $add( '<< /Type /Font /Subtype /CIDFontType0 /BaseFont /' . $name . ' /CIDSystemInfo << /Registry (Adobe) /Ordering (' . $order . ') /Supplement ' . $sup . ' >> /FontDescriptor ' . $desc . ' 0 R /DW 1000 >>' );
			$f3    = $add( '<< /Type /Font /Subtype /Type0 /BaseFont /' . $name . ' /Encoding /' . $cmap . ' /DescendantFonts [' . $cid . ' 0 R] >>' );
			$fonts .= ' /F3 ' . $f3 . ' 0 R';
		}
		$xo = '';
		foreach ( $this->images as $k => $im ) {
			$o   = $add( "<< /Type /XObject /Subtype /Image /Width {$im['w']} /Height {$im['h']} /ColorSpace /{$im['cs']} /BitsPerComponent 8 /Filter /DCTDecode" . ( $im['cmyk'] ? ' /Decode [1 0 1 0 1 0 1 0]' : '' ) . ' /Length ' . strlen( $im['data'] ) . " >>\nstream\n" . $im['data'] . "\nendstream" );
			$xo .= '/' . $k . ' ' . $o . ' 0 R ';
		}
		$res  = $add( '<< /ProcSet [/PDF /Text /ImageC /ImageB] /Font << ' . $fonts . ' >>' . ( $xo ? ' /XObject << ' . $xo . '>>' : '' ) . ' >>' );
		$kids = [];
		foreach ( $this->pages as $i => $content ) {
			$z    = function_exists( 'gzcompress' );
			$data = $z ? gzcompress( $content, 6 ) : $content;
			$c    = $add( '<< ' . ( $z ? '/Filter /FlateDecode ' : '' ) . '/Length ' . strlen( $data ) . " >>\nstream\n" . $data . "\nendstream" );
			$an   = $this->annots[ $i ] ? ' /Annots [' . implode( ' ', $this->annots[ $i ] ) . ']' : '';
			$kids[] = $add( '<< /Type /Page /Parent ' . $pgs . ' 0 R /MediaBox [0 0 ' . self::W . ' ' . self::H . '] /Resources ' . $res . ' 0 R /Contents ' . $c . ' 0 R' . $an . ' >>' );
		}
		$objs[ $pgs - 1 ] = '<< /Type /Pages /Kids [' . implode( ' ', array_map( function ( $k ) { return $k . ' 0 R'; }, $kids ) ) . '] /Count ' . count( $kids ) . ' >>';
		$objs[ $cat - 1 ] = '<< /Type /Catalog /Pages ' . $pgs . ' 0 R /ViewerPreferences << /DisplayDocTitle true >> >>';
		$info = $add( '<< /Title ' . self::utf16( $title ) . ' /Author ' . self::utf16( $author ) . ' /Producer (Wakoo) /CreationDate (D:' . gmdate( 'YmdHis' ) . "Z) >>" );

		$pdf  = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
		$offs = [];
		foreach ( $objs as $i => $body ) {
			$offs[] = strlen( $pdf );
			$pdf   .= ( $i + 1 ) . " 0 obj\n" . $body . "\nendobj\n";
		}
		$xref = strlen( $pdf );
		$pdf .= 'xref' . "\n0 " . ( count( $objs ) + 1 ) . "\n0000000000 65535 f \n";
		foreach ( $offs as $o ) { $pdf .= sprintf( "%010d 00000 n \n", $o ); }
		$pdf .= 'trailer' . "\n<< /Size " . ( count( $objs ) + 1 ) . ' /Root ' . $cat . ' 0 R /Info ' . $info . " 0 R >>\nstartxref\n" . $xref . "\n%%EOF\n";
		return $pdf;
	}
}
