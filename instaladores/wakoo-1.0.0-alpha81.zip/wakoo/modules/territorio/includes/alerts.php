<?php
/**
 * Directory alerts: when a purchase need is published, the companies that work in its sector
 * get an email (once, in the background); every week each company gets a summary of what
 * happened around it (queries received, offers to its needs, new needs in its sectors).
 * Each company chooses in «Mi empresa → Avisos» what it receives. Placeholder addresses
 * (.invalid) and companies without an account never get mail.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

defined( 'ABSPATH' ) || die();

class Alerts {

	const NEED_HOOK   = 'wakoo_t_need_alerts';
	const DIGEST_HOOK = 'wakoo_t_digest';
	const LAST        = 'wakoo_t_digest_last';

	public static function init() {
		add_action( 'transition_post_status', [ __CLASS__, 'on_publish' ], 20, 3 );
		add_action( self::NEED_HOOK, [ __CLASS__, 'send_need' ] );
		add_action( self::DIGEST_HOOK, [ __CLASS__, 'digest_all' ] );
		add_action( 'init', [ __CLASS__, 'schedule' ], 30 );
		add_action( 'admin_post_wakoo_t_alerts', [ __CLASS__, 'save' ] );
		add_action( 'admin_post_nopriv_wakoo_t_alerts', [ Forms::class, 'need_login' ] );
		add_action( 'admin_post_wakoo_t_hub_digest', [ __CLASS__, 'hub_digest' ] );
		// Who was already told belongs to this site: a pack never carries it.
		add_filter( 'wakoo_portable_skip_meta', function ( $k ) { return array_merge( (array) $k, [ Module::PRE . 'alerted' ] ); } );
	}

	/** Weekly summary on Monday morning (site time). */
	public static function schedule() {
		if ( wp_next_scheduled( self::DIGEST_HOOK ) ) { return; }
		$next = new \DateTime( 'next monday 08:00', wp_timezone() );
		wp_schedule_event( $next->getTimestamp(), 'weekly', self::DIGEST_HOOK );
	}

	/* ---------------------------------------------------------------- preferences */

	/** [ 'needs' => bool, 'digest' => bool, 'all' => bool, 'sectors' => int[] ] of a company. */
	public static function prefs( $company_id ) {
		$p = get_post_meta( $company_id, Module::PRE . 'alerts', true );
		$p = is_array( $p ) ? $p : [];
		$own = wp_list_pluck( Module::terms( $company_id, Module::T_SECTOR ), 'term_id' );
		return [
			'needs'   => ! isset( $p['needs'] ) || ! empty( $p['needs'] ),
			'digest'  => ! isset( $p['digest'] ) || ! empty( $p['digest'] ),
			'all'     => ! empty( $p['all'] ),
			'sectors' => isset( $p['sectors'] ) && is_array( $p['sectors'] ) ? array_map( 'intval', $p['sectors'] ) : array_map( 'intval', $own ),
		];
	}

	/** «Mi empresa → Avisos» form. */
	public static function save() {
		if ( ! isset( $_POST['_wkt'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wkt'] ) ), 'wakoo_t_alerts' ) ) { Forms::back( 'expired' ); }
		$c = Forms::my_company();
		if ( ! $c ) { Forms::back( 'nocompany' ); }
		$valid = get_terms( [ 'taxonomy' => Module::T_SECTOR, 'hide_empty' => false, 'fields' => 'ids' ] );
		$sec   = array_values( array_intersect( array_map( 'intval', (array) ( $_POST['sectors'] ?? [] ) ), is_array( $valid ) ? array_map( 'intval', $valid ) : [] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		update_post_meta( $c->ID, Module::PRE . 'alerts', [
			'needs'   => ! empty( $_POST['needs'] ) ? 1 : 0, // phpcs:ignore WordPress.Security.NonceVerification
			'digest'  => ! empty( $_POST['digest'] ) ? 1 : 0, // phpcs:ignore WordPress.Security.NonceVerification
			'all'     => ! empty( $_POST['all'] ) ? 1 : 0, // phpcs:ignore WordPress.Security.NonceVerification
			'sectors' => $sec,
		] );
		Store::log( Module::COMPANY, $c->ID, 'alerts', 'Preferencias de avisos actualizadas', 'audit' );
		Forms::back( 'alerts_ok' );
	}

	/** Address that may receive mail for a company, or ''. */
	public static function address( $c ) {
		if ( ! $c || 'publish' !== $c->post_status || ! Module::has_owner( $c ) ) { return ''; }
		$u = get_userdata( (int) $c->post_author );
		if ( ! $u || user_can( $u, 'edit_others_posts' ) || Hub::is_placeholder( $u->user_email ) || ! is_email( $u->user_email ) ) { return ''; }
		return $u->user_email;
	}

	/** Page that lists the open needs (the one with the «Necesidades de compra» widget, master language first). */
	public static function needs_page() {
		$id = (int) get_transient( 'wkt_needs_page' );
		if ( $id && 'publish' === get_post_status( $id ) ) { return $id; }
		global $wpdb;
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT p.ID FROM {$wpdb->posts} p JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_elementor_data' WHERE p.post_type = 'page' AND p.post_status = 'publish' AND m.meta_value LIKE %s ORDER BY p.ID ASC LIMIT 20", '%' . $wpdb->esc_like( '"widgetType":"wakoo-t-needs"' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$id  = 0;
		$i   = '\\Wakoo\\Modules\\Idiomas\\Module';
		foreach ( $ids as $pid ) {
			if ( ! $id ) { $id = (int) $pid; }
			if ( class_exists( $i ) && $i::lang_of( (int) $pid ) === $i::default_lang() ) { $id = (int) $pid; break; }
		}
		set_transient( 'wkt_needs_page', $id, DAY_IN_SECONDS );
		return $id;
	}

	/** Address where suppliers read a need and send an offer (opens it in the list). */
	public static function need_url( $need_id ) {
		$page = self::needs_page();
		return $page ? add_query_arg( 'necesidad', (int) $need_id, get_permalink( $page ) ) . '#wkt-need-' . (int) $need_id : ( Module::page_url( 'company' ) ?: home_url( '/' ) );
	}

	/* ---------------------------------------------------------------- new need → suppliers */

	public static function on_publish( $new, $old, $post ) {
		if ( 'publish' !== $new || 'publish' === $old || Module::NEED !== $post->post_type ) { return; }
		if ( Module::meta( $post->ID, 'alerted' ) || wp_next_scheduled( self::NEED_HOOK, [ (int) $post->ID ] ) ) { return; }
		// In the background: publishing stays fast however many companies there are.
		wp_schedule_single_event( time() + 30, self::NEED_HOOK, [ (int) $post->ID ] );
	}

	/** Companies that should hear about a need (never the company that published it). */
	public static function recipients( $need_id ) {
		$sectors = array_map( 'intval', wp_list_pluck( Module::terms( $need_id, Module::T_SECTOR ), 'term_id' ) );
		$from    = (int) Module::meta( $need_id, 'company' );
		$out     = [];
		foreach ( get_posts( [ 'post_type' => Module::COMPANY, 'post_status' => 'publish', 'numberposts' => -1 ] ) as $c ) {
			if ( (int) $c->ID === $from ) { continue; }
			$p = self::prefs( $c->ID );
			if ( ! $p['needs'] ) { continue; }
			if ( ! $p['all'] && ! array_intersect( $sectors, $p['sectors'] ) ) { continue; }
			$to = self::address( $c );
			if ( $to ) { $out[ $c->ID ] = $to; }
		}
		return $out;
	}

	public static function send_need( $need_id ) {
		$n = get_post( (int) $need_id );
		if ( ! $n || Module::NEED !== $n->post_type || 'publish' !== $n->post_status || Module::meta( $n->ID, 'alerted' ) || 'yes' === Module::meta( $n->ID, 'closed' ) ) { return 0; }
		update_post_meta( $n->ID, Module::PRE . 'alerted', time() ); // Before sending: a second run never repeats it.
		$buyer = (int) Module::meta( $n->ID, 'company' );
		$lines = array_filter( [
			$buyer ? sprintf( __( 'Empresa: %s', 'wakoo' ), get_the_title( $buyer ) ) : '',
			Module::term_names( $n->ID, Module::T_SECTOR ) ? sprintf( __( 'Sector: %s', 'wakoo' ), Module::term_names( $n->ID, Module::T_SECTOR ) ) : '',
			Module::term_names( $n->ID, Module::T_MUN ) ? sprintf( __( 'Municipio: %s', 'wakoo' ), Module::term_names( $n->ID, Module::T_MUN ) ) : '',
			Module::meta( $n->ID, 'qty' ) ? sprintf( __( 'Cantidad o alcance: %s', 'wakoo' ), Module::meta( $n->ID, 'qty' ) ) : '',
			Module::meta( $n->ID, 'deadline' ) ? sprintf( __( 'Fecha límite para ofertas: %s', 'wakoo' ), date_i18n( 'd/m/Y', strtotime( Module::meta( $n->ID, 'deadline' ) ) ) ) : '',
		] );
		$excerpt = wp_trim_words( wp_strip_all_tags( $n->post_content ), 60 );
		$link    = self::need_url( $n->ID );
		$sent    = 0;
		foreach ( self::recipients( $n->ID ) as $cid => $to ) {
			$body = sprintf( __( "Hola, %s:\n\nSe publicó en el directorio una necesidad de compra de su sector:\n\n«%s»\n\n%s\n\n%s\n\nPara enviar una oferta, entre en: %s\n\nPuede cambiar qué avisos recibe en «Mi empresa → Avisos»: %s", 'wakoo' ),
				get_the_title( $cid ), $n->post_title, implode( "\n", $lines ), $excerpt, $link, Module::page_url( 'company', [ 'tab' => 'avisos' ] ) ?: home_url( '/' ) );
			if ( Module::mail( $to, sprintf( __( 'Nueva necesidad de compra: %s', 'wakoo' ), $n->post_title ), $body ) ) { $sent++; }
		}
		Store::log( Module::NEED, $n->ID, 'alerts', sprintf( 'Aviso de necesidad nueva enviado a %d empresas', $sent ), 'internal', 0 );
		return $sent;
	}

	/* ---------------------------------------------------------------- weekly summary */

	/** What happened around one company since $since (Unix time). Empty sections are left out. */
	public static function digest( $c, $since ) {
		$after = gmdate( 'Y-m-d H:i:s', $since );
		$range = [ [ 'column' => 'post_date_gmt', 'after' => $after ] ];
		$owner = (int) $c->post_author;
		$out   = [];

		$in = get_posts( [ 'post_type' => Module::RFQ, 'post_status' => 'private', 'numberposts' => 50, 'date_query' => $range, 'meta_query' => [ [ 'key' => Module::PRE . 'to', 'value' => $c->ID ] ] ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
		$q = [];
		$o = [];
		foreach ( $in as $r ) {
			$from = (int) Module::meta( $r->ID, 'from' );
			$line = '- ' . $r->post_title . ' (' . ( $from ? get_the_title( $from ) : get_the_author_meta( 'display_name', $r->post_author ) ) . ')';
			if ( 'oferta' === Module::meta( $r->ID, 'kind' ) ) { $o[] = $line; } else { $q[] = $line; }
		}
		if ( $q ) { $out[] = sprintf( __( 'Consultas recibidas (%d):', 'wakoo' ), count( $q ) ) . "\n" . implode( "\n", $q ); }
		if ( $o ) { $out[] = sprintf( __( 'Ofertas a sus necesidades de compra (%d):', 'wakoo' ), count( $o ) ) . "\n" . implode( "\n", $o ); }

		// Replies inside threads where this company takes part, written by the other side.
		$threads = get_posts( [ 'post_type' => Module::RFQ, 'post_status' => 'private', 'numberposts' => 200, 'fields' => 'ids', 'meta_query' => [ 'relation' => 'OR', [ 'key' => Module::PRE . 'to', 'value' => $c->ID ], [ 'key' => Module::PRE . 'from', 'value' => $c->ID ] ] ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
		$rep = 0;
		foreach ( $threads as $t ) {
			foreach ( Store::lines( Module::RFQ, $t, [ 'public' ] ) as $l ) {
				if ( (int) $l->user_id !== $owner && strtotime( $l->created . ' UTC' ) >= $since ) { $rep++; }
			}
		}
		if ( $rep ) { $out[] = sprintf( _n( 'Respuestas nuevas en sus conversaciones: %d', 'Respuestas nuevas en sus conversaciones: %d', $rep, 'wakoo' ), $rep ); }

		// Its own open needs and how many offers each has in total.
		$mine = get_posts( [ 'post_type' => Module::NEED, 'post_status' => 'publish', 'numberposts' => 20, 'meta_query' => [ [ 'key' => Module::PRE . 'company', 'value' => $c->ID ] ] ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
		$open = [];
		foreach ( $mine as $n ) {
			if ( 'yes' === Module::meta( $n->ID, 'closed' ) ) { continue; }
			$cnt    = count( get_posts( [ 'post_type' => Module::RFQ, 'post_status' => 'private', 'numberposts' => -1, 'fields' => 'ids', 'meta_query' => [ [ 'key' => Module::PRE . 'need', 'value' => $n->ID ] ] ] ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
			$open[] = '- ' . $n->post_title . ' · ' . sprintf( _n( '%d oferta', '%d ofertas', $cnt, 'wakoo' ), $cnt );
		}

		// New needs from other companies in the sectors it follows.
		$p   = self::prefs( $c->ID );
		$new = [];
		if ( $p['all'] || $p['sectors'] ) {
			$args = [ 'post_type' => Module::NEED, 'post_status' => 'publish', 'numberposts' => 20, 'date_query' => $range ];
			if ( ! $p['all'] ) { $args['tax_query'] = [ [ 'taxonomy' => Module::T_SECTOR, 'terms' => $p['sectors'] ] ]; } // phpcs:ignore WordPress.DB.SlowDBQuery
			foreach ( get_posts( $args ) as $n ) {
				if ( (int) Module::meta( $n->ID, 'company' ) === (int) $c->ID || 'yes' === Module::meta( $n->ID, 'closed' ) ) { continue; }
				$new[] = '- ' . $n->post_title . ' · ' . self::need_url( $n->ID );
			}
		}
		if ( $new ) { $out[] = sprintf( __( 'Necesidades de compra nuevas en sus sectores (%d):', 'wakoo' ), count( $new ) ) . "\n" . implode( "\n", $new ); }
		// Open needs alone are no news: they only go along with something new.
		if ( $out && $open ) { $out[] = __( 'Sus necesidades de compra abiertas:', 'wakoo' ) . "\n" . implode( "\n", $open ); }
		return $out;
	}

	/** Sends the summary to every company with news. Returns [ sent, companies checked ]. */
	public static function digest_all( $since = 0 ) {
		$since = $since ?: time() - WEEK_IN_SECONDS;
		$sent  = 0;
		$seen  = 0;
		foreach ( get_posts( [ 'post_type' => Module::COMPANY, 'post_status' => 'publish', 'numberposts' => -1 ] ) as $c ) {
			$to = self::address( $c );
			if ( ! $to || ! self::prefs( $c->ID )['digest'] ) { continue; }
			$seen++;
			$parts = self::digest( $c, $since );
			if ( ! $parts ) { continue; }
			$body = sprintf( __( "Hola, %s:\n\nEsto es lo que pasó en el directorio desde el %s:\n\n%s\n\nEntre en su panel para responder: %s\n\nPuede cambiar qué avisos recibe en «Mi empresa → Avisos».", 'wakoo' ),
				$c->post_title, wp_date( 'd/m/Y', $since ), implode( "\n\n", $parts ), Module::page_url( 'company' ) ?: home_url( '/' ) );
			if ( Module::mail( $to, __( 'Resumen semanal del directorio empresarial', 'wakoo' ), $body ) ) { $sent++; }
		}
		update_option( self::LAST, [ 'time' => time(), 'sent' => $sent, 'seen' => $seen ], false );
		return [ $sent, $seen ];
	}

	/** Hub button «Enviar el resumen ahora». */
	public static function hub_digest() {
		if ( ! isset( $_POST['_wkt'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wkt'] ) ), 'wakoo_t_hub_digest' ) ) { Forms::back( 'expired' ); }
		if ( ! current_user_can( 'edit_others_posts' ) ) { Forms::back( 'denied' ); }
		if ( ! Module::rate( 'hub_digest', 3 ) ) { Forms::back( 'limit' ); }
		list( $sent ) = self::digest_all();
		Store::log( 'site', 0, 'digest', sprintf( 'Resumen semanal enviado a mano a %d empresas', $sent ), 'audit' );
		Forms::back( 'digest_ok' );
	}
}
