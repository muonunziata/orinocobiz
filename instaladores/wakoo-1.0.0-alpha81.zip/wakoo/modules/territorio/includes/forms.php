<?php
/**
 * Territorio front-end forms (posted to admin-post.php): account, ventanilla, company profile,
 * purchase needs and quote requests. Every handler checks a nonce, the user, limits and the
 * data on the server, and writes the audit trail.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

defined( 'ABSPATH' ) || die();

class Forms {

	/** Messages that come back in the URL (?wkt=code). Only codes travel, never text. */
	public static function messages() {
		return [
			'registered' => [ 'ok', __( 'Cuenta creada. Ya puede usar los servicios del portal.', 'wakoo' ) ],
			'case_ok'    => [ 'ok', __( 'Solicitud registrada. Guarde su código: lo verá también en su panel.', 'wakoo' ) ],
			'reply_ok'   => [ 'ok', __( 'Mensaje enviado al equipo de la ventanilla.', 'wakoo' ) ],
			'company_ok' => [ 'ok', __( 'Perfil guardado. El equipo lo revisará antes de publicarlo en el directorio.', 'wakoo' ) ],
			'company_up' => [ 'ok', __( 'Cambios guardados.', 'wakoo' ) ],
			'doc_ok'     => [ 'ok', __( 'Documento guardado en su expediente privado.', 'wakoo' ) ],
			'need_ok'    => [ 'ok', __( 'Necesidad registrada. Se publicará tras la revisión.', 'wakoo' ) ],
			'rfq_ok'     => [ 'ok', __( 'Consulta enviada. La respuesta llegará a su panel.', 'wakoo' ) ],
			'enrolled'   => [ 'ok', __( 'Inscripción registrada.', 'wakoo' ) ],
			'interest'   => [ 'ok', __( 'Registramos su interés. Le avisaremos cuando abra la inscripción.', 'wakoo' ) ],
			'lesson_ok'  => [ 'ok', __( 'Lección completada.', 'wakoo' ) ],
			'quiz_ok'    => [ 'ok', __( 'Evaluación aprobada.', 'wakoo' ) ],
			'quiz_ko'    => [ 'err', __( 'No alcanzó la nota mínima. Revise la lección y vuelva a intentarlo.', 'wakoo' ) ],
			'certified'  => [ 'ok', __( 'Curso completado: su certificado ya está disponible.', 'wakoo' ) ],
			'login'      => [ 'err', __( 'Inicie sesión o cree una cuenta para continuar.', 'wakoo' ) ],
			'invalid'    => [ 'err', __( 'Revise los campos marcados como obligatorios.', 'wakoo' ) ],
			'email'      => [ 'err', __( 'El correo no es válido o ya está registrado. Si ya tiene cuenta, inicie sesión.', 'wakoo' ) ],
			'password'   => [ 'err', __( 'La contraseña debe tener al menos 10 caracteres.', 'wakoo' ) ],
			'consent'    => [ 'err', __( 'Debe aceptar el tratamiento de datos para continuar.', 'wakoo' ) ],
			'limit'      => [ 'err', __( 'Demasiados intentos. Espere un momento y vuelva a intentarlo.', 'wakoo' ) ],
			'closed'     => [ 'err', __( 'Este registro está cerrado.', 'wakoo' ) ],
			'denied'     => [ 'err', __( 'No tiene permiso para esta acción.', 'wakoo' ) ],
			'file'       => [ 'err', __( 'Uno de los archivos no se guardó (tipo o tamaño no permitido).', 'wakoo' ) ],
			'nocompany'  => [ 'err', __( 'Primero registre el perfil de su empresa.', 'wakoo' ) ],
			'expired'    => [ 'err', __( 'La sesión del formulario caducó. Vuelva a enviarlo.', 'wakoo' ) ],
			'mismatch'   => [ 'err', __( 'Las dos contraseñas no coinciden.', 'wakoo' ) ],
			'samepass'   => [ 'err', __( 'Elija una contraseña distinta de la temporal.', 'wakoo' ) ],
			'newpass_ok' => [ 'ok', __( 'Contraseña cambiada. Ya puede usar el portal.', 'wakoo' ) ],
			'hub_saved'  => [ 'ok', __( 'Cambios guardados.', 'wakoo' ) ],
			'hub_user_ok'   => [ 'ok', __( 'Cuenta creada. Copie ahora la contraseña temporal: no se volverá a mostrar.', 'wakoo' ) ],
			'hub_access_ok' => [ 'ok', __( 'Accesos listos. Copie ahora las contraseñas temporales: no se volverán a mostrar.', 'wakoo' ) ],
			'photo_ok'   => [ 'ok', __( 'Fotos añadidas a la galería de su perfil.', 'wakoo' ) ],
			'photo_del'  => [ 'ok', __( 'Foto quitada de la galería.', 'wakoo' ) ],
			'photos_ok'  => [ 'ok', __( 'Fotos descargadas de Wikimedia Commons.', 'wakoo' ) ],
			'photos_ko'  => [ 'err', __( 'Algunas fotos no se pudieron descargar. Abajo verá el motivo.', 'wakoo' ) ],
			'rights'     => [ 'err', __( 'Confirme que la empresa tiene derecho a publicar estas fotos.', 'wakoo' ) ],
			'alerts_ok'  => [ 'ok', __( 'Preferencias de avisos guardadas.', 'wakoo' ) ],
			'digest_ok'  => [ 'ok', __( 'Resumen enviado a las empresas que tenían novedades.', 'wakoo' ) ],
			'hub_none'   => [ 'err', __( 'Todas las empresas ya tienen su cuenta.', 'wakoo' ) ],
			'off'        => [ 'err', __( 'El registro de cuentas está desactivado en este momento.', 'wakoo' ) ],
		];
	}

	public static function init() {
		add_action( 'admin_post_nopriv_wakoo_t_register', [ __CLASS__, 'register' ] );
		add_action( 'admin_post_wakoo_t_register', [ __CLASS__, 'register' ] );
		add_action( 'admin_post_wakoo_t_file', [ Store::class, 'serve' ] );
		foreach ( [ 'case', 'reply', 'company', 'company_doc', 'need', 'rfq', 'rfq_reply' ] as $a ) {
			add_action( 'admin_post_wakoo_t_' . $a, [ __CLASS__, $a ] );
			add_action( 'admin_post_nopriv_wakoo_t_' . $a, [ __CLASS__, 'need_login' ] );
		}
	}

	/* ---------------------------------------------------------------- helpers */

	public static function back( $code, $args = [], $url = '' ) {
		$url = $url ?: ( isset( $_POST['_back'] ) ? esc_url_raw( wp_unslash( $_POST['_back'] ) ) : '' ); // phpcs:ignore WordPress.Security.NonceVerification
		$url = wp_validate_redirect( $url, wp_get_referer() ?: home_url( '/' ) );
		$url = remove_query_arg( [ 'wkt', 'wkt_code' ], $url );
		wp_safe_redirect( add_query_arg( array_merge( [ 'wkt' => $code ], $args ), $url ) );
		exit;
	}

	private static function check( $action ) {
		if ( ! isset( $_POST['_wkt'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wkt'] ) ), 'wakoo_t_' . $action ) ) {
			self::back( 'expired' );
		}
		if ( ! empty( $_POST['wkt_hp'] ) ) { self::back( 'invalid' ); } // Honeypot.
	}

	public static function need_login() {
		self::back( 'login' );
	}

	public static function txt( $k, $max = 200 ) {
		return isset( $_POST[ $k ] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST[ $k ] ) ), 0, $max ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	}

	public static function area( $k, $max = 6000 ) {
		return isset( $_POST[ $k ] ) ? mb_substr( sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) ), 0, $max ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	}

	private static function term( $k, $tax ) {
		$id = isset( $_POST[ $k ] ) ? (int) $_POST[ $k ] : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$t  = $id ? get_term( $id, $tax ) : null;
		return ( $t && ! is_wp_error( $t ) ) ? (int) $t->term_id : 0;
	}

	/** Saves the uploaded files of input $field on $post_id. Returns false when one failed. */
	private static function files( $field, $post_id, $max = 5, $vis = 'public' ) {
		if ( empty( $_FILES[ $field ]['name'] ) ) { return true; }
		$f  = $_FILES[ $field ]; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$ok = true;
		$n  = is_array( $f['name'] ) ? count( $f['name'] ) : 1;
		for ( $i = 0; $i < min( $n, $max ); $i++ ) {
			$one = is_array( $f['name'] ) ? [ 'name' => $f['name'][ $i ], 'type' => $f['type'][ $i ], 'tmp_name' => $f['tmp_name'][ $i ], 'error' => $f['error'][ $i ], 'size' => $f['size'][ $i ] ] : $f;
			if ( '' === (string) $one['name'] ) { continue; }
			$rec = Store::keep( $one );
			if ( is_wp_error( $rec ) ) { $ok = false; continue; }
			Store::add_file( $post_id, $rec );
			Store::log( get_post_type( $post_id ), $post_id, 'file', sprintf( __( 'Documento añadido: %s', 'wakoo' ), $rec['name'] ), $vis );
		}
		return $ok;
	}

	/** Remembers what the visitor typed for 10 minutes, so a failed form keeps the answers. */
	public static function remember( $form ) {
		$keep = [];
		foreach ( $_POST as $k => $v ) { // phpcs:ignore WordPress.Security.NonceVerification
			if ( is_string( $v ) && 0 !== strpos( $k, '_' ) && 'pass' !== $k ) { $keep[ sanitize_key( $k ) ] = sanitize_textarea_field( wp_unslash( $v ) ); }
		}
		set_transient( 'wkt_old_' . $form . '_' . Module::who(), $keep, 10 * MINUTE_IN_SECONDS );
	}

	public static function old( $form ) {
		$o = get_transient( 'wkt_old_' . $form . '_' . Module::who() );
		return is_array( $o ) ? $o : [];
	}

	/* ---------------------------------------------------------------- account */

	public static function register() {
		self::check( 'register' );
		if ( empty( Module::settings()['register'] ) ) { self::back( 'off' ); }
		if ( ! Module::rate( 'register', 5 ) ) { self::back( 'limit' ); }
		self::remember( 'register' );
		$name  = self::txt( 'name', 100 );
		$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$pass  = (string) wp_unslash( $_POST['pass'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput
		if ( '' === $name ) { self::back( 'invalid' ); }
		if ( ! is_email( $email ) || email_exists( $email ) ) { self::back( 'email' ); }
		if ( strlen( $pass ) < 10 ) { self::back( 'password' ); }
		if ( empty( $_POST['consent'] ) ) { self::back( 'consent' ); } // phpcs:ignore WordPress.Security.NonceVerification
		$login = sanitize_user( strtolower( strtok( $email, '@' ) ), true ) ?: 'usuario';
		$base  = $login;
		for ( $i = 2; username_exists( $login ); $i++ ) { $login = $base . $i; }
		$uid = wp_insert_user( [ 'user_login' => $login, 'user_email' => $email, 'user_pass' => $pass, 'display_name' => $name, 'first_name' => $name, 'role' => 'subscriber' ] );
		if ( is_wp_error( $uid ) ) { self::back( 'email' ); }
		update_user_meta( $uid, Module::PRE . 'consent', gmdate( 'c' ) );
		Store::log( 'user', $uid, 'register', 'Cuenta creada desde el portal (consentimiento de datos registrado)', 'audit', $uid );
		wp_set_current_user( $uid );
		wp_set_auth_cookie( $uid, false, is_ssl() );
		delete_transient( 'wkt_old_register_' . Module::who() );
		self::back( 'registered' );
	}

	/* ---------------------------------------------------------------- ventanilla */

	public static function next_code() {
		$n = (int) get_option( 'wakoo_t_case_seq', 0 ) + 1;
		update_option( 'wakoo_t_case_seq', $n, false );
		$pre = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) Module::settings()['prefix'] ) ) ?: 'SOL';
		return sprintf( '%s-%s-%05d', $pre, gmdate( 'Y' ), $n );
	}

	public static function case() {
		self::check( 'case' );
		if ( ! Module::rate( 'case', 8, DAY_IN_SECONDS ) ) { self::back( 'limit' ); }
		self::remember( 'case' );
		$title = self::txt( 'title', 180 );
		$desc  = self::area( 'desc', 8000 );
		$promo = self::txt( 'promoter', 180 );
		$sector = self::term( 'sector', Module::T_SECTOR );
		$mun   = self::term( 'municipio', Module::T_MUN );
		if ( '' === $title || mb_strlen( $desc ) < 40 || '' === $promo || ! $sector ) { self::back( 'invalid' ); }
		if ( empty( $_POST['consent'] ) ) { self::back( 'consent' ); } // phpcs:ignore WordPress.Security.NonceVerification
		$st  = array_keys( Module::statuses() )[0];
		$pid = wp_insert_post( [ 'post_type' => Module::CASE_T, 'post_status' => 'private', 'post_title' => $title, 'post_content' => $desc, 'post_author' => get_current_user_id() ], true );
		if ( is_wp_error( $pid ) ) { self::back( 'invalid' ); }
		$code = self::next_code();
		$amount = self::txt( 'amount', 30 );
		$meta = [
			'code' => $code, 'status' => $st, 'promoter' => $promo, 'contact' => self::txt( 'contact', 120 ),
			'kind' => self::txt( 'kind', 40 ), 'maturity' => array_key_exists( self::txt( 'maturity', 40 ), Module::stages() ) ? self::txt( 'maturity', 40 ) : 'conceptual',
			'amount' => is_numeric( str_replace( [ '.', ',' ], '', $amount ) ) ? preg_replace( '/[^0-9]/', '', $amount ) : '', 'currency' => in_array( self::txt( 'currency', 5 ), [ 'USD', 'EUR', 'VES' ], true ) ? self::txt( 'currency', 5 ) : 'USD',
			'jobs' => (int) self::txt( 'jobs', 8 ), 'location' => self::txt( 'location', 200 ), 'services' => self::area( 'services', 1500 ),
			'consent' => gmdate( 'c' ), 'checklist' => [],
		];
		foreach ( $meta as $k => $v ) { update_post_meta( $pid, Module::PRE . $k, $v ); }
		if ( $sector ) { wp_set_object_terms( $pid, [ $sector ], Module::T_SECTOR ); }
		if ( $mun ) { wp_set_object_terms( $pid, [ $mun ], Module::T_MUN ); }
		Store::log( Module::CASE_T, $pid, 'status', sprintf( __( 'Solicitud %1$s registrada. Estado: %2$s.', 'wakoo' ), $code, Module::statuses()[ $st ][0] ), 'public' );
		$ok = self::files( 'docs', $pid );
		delete_transient( 'wkt_old_case_' . Module::who() );
		$u = wp_get_current_user();
		Module::mail( $u->user_email, sprintf( __( 'Solicitud %s registrada', 'wakoo' ), $code ),
			sprintf( __( "Hemos registrado su iniciativa «%1\$s» con el código %2\$s.\n\nLa ventanilla registra, orienta y hace seguimiento: no concede permisos ni aprueba proyectos, que corresponden a los organismos competentes.\n\nPuede seguir el estado en: %3\$s", 'wakoo' ), $title, $code, Module::page_url( 'cases' ) ?: home_url( '/' ) ) );
		Module::mail( Module::staff_email(), sprintf( __( 'Nueva solicitud %1$s: %2$s', 'wakoo' ), $code, $title ), admin_url( 'post.php?post=' . $pid . '&action=edit' ) );
		self::back( $ok ? 'case_ok' : 'file', [ 'wkt_code' => $code ], Module::page_url( 'cases' ) );
	}

	/** The applicant writes to their own case (message and/or documents). */
	public static function reply() {
		self::check( 'reply' );
		$pid = isset( $_POST['case'] ) ? (int) $_POST['case'] : 0;
		$p   = get_post( $pid );
		if ( ! $p || Module::CASE_T !== $p->post_type || (int) $p->post_author !== get_current_user_id() ) { self::back( 'denied' ); }
		$st = Module::statuses()[ Module::meta( $pid, 'status' ) ] ?? null;
		if ( $st && $st[1] ) { self::back( 'closed' ); }
		if ( ! Module::rate( 'reply', 30 ) ) { self::back( 'limit' ); }
		$msg = self::area( 'message', 4000 );
		if ( '' !== $msg ) { Store::log( Module::CASE_T, $pid, 'applicant', $msg, 'public' ); }
		$ok = self::files( 'docs', $pid );
		$to = (int) Module::meta( $pid, 'assignee' );
		$to = $to ? get_userdata( $to ) : null;
		Module::mail( $to ? $to->user_email : Module::staff_email(), sprintf( __( 'Respuesta del solicitante en %s', 'wakoo' ), Module::meta( $pid, 'code' ) ), admin_url( 'post.php?post=' . $pid . '&action=edit' ) );
		self::back( $ok ? 'reply_ok' : 'file' );
	}

	/* ---------------------------------------------------------------- companies */

	/** The company profile of the current user (one per account). */
	public static function my_company( $uid = 0 ) {
		$uid = $uid ?: get_current_user_id();
		if ( ! $uid ) { return null; }
		$q = get_posts( [ 'post_type' => Module::COMPANY, 'post_status' => [ 'publish', 'pending', 'draft', 'private' ], 'author' => $uid, 'numberposts' => 1 ] );
		return $q ? $q[0] : null;
	}

	/** Public contact fields the owner may choose to show. */
	public static function contact_fields() {
		return [ 'web' => __( 'Sitio web', 'wakoo' ), 'email' => __( 'Correo de contacto', 'wakoo' ), 'phone' => __( 'Teléfono', 'wakoo' ), 'address' => __( 'Dirección', 'wakoo' ) ];
	}

	public static function company() {
		self::check( 'company' );
		if ( ! Module::rate( 'company', 20 ) ) { self::back( 'limit' ); }
		self::remember( 'company' );
		$name = self::txt( 'trade_name', 160 );
		$desc = self::area( 'desc', 4000 );
		$cat  = self::term( 'cat', Module::T_CCAT );
		$mun  = self::term( 'municipio', Module::T_MUN );
		if ( '' === $name || mb_strlen( $desc ) < 30 || ! $cat ) { self::back( 'invalid' ); }
		if ( empty( $_POST['consent'] ) ) { self::back( 'consent' ); } // phpcs:ignore WordPress.Security.NonceVerification
		$mine = self::my_company();
		$arr  = [ 'post_type' => Module::COMPANY, 'post_title' => $name, 'post_content' => $desc, 'post_excerpt' => wp_trim_words( $desc, 30, '…' ) ];
		if ( $mine ) {
			$arr['ID'] = $mine->ID;
			$pid       = wp_update_post( $arr, true );
			$new       = false;
		} else {
			$arr += [ 'post_status' => 'pending', 'post_author' => get_current_user_id() ];
			$pid  = wp_insert_post( $arr, true );
			$new  = true;
		}
		if ( is_wp_error( $pid ) ) { self::back( 'invalid' ); }
		$meta = [
			'legal_name' => self::txt( 'legal_name', 200 ), 'rif' => self::txt( 'rif', 30 ),
			'products' => self::area( 'products', 3000 ), 'capabilities' => self::area( 'capabilities', 3000 ),
			'equipment' => self::area( 'equipment', 3000 ), 'certs' => self::area( 'certs', 2000 ),
			'web' => esc_url_raw( self::txt( 'web', 200 ) ), 'email' => sanitize_email( self::txt( 'email', 120 ) ),
			'phone' => self::txt( 'phone', 40 ), 'address' => self::txt( 'address', 200 ), 'consent' => gmdate( 'c' ),
		];
		$show = [];
		foreach ( array_keys( self::contact_fields() ) as $k ) { if ( ! empty( $_POST[ 'show_' . $k ] ) ) { $show[] = $k; } } // phpcs:ignore WordPress.Security.NonceVerification
		$meta['public'] = $show;
		foreach ( $meta as $k => $v ) { update_post_meta( $pid, Module::PRE . $k, $v ); }
		if ( $new ) { update_post_meta( $pid, Module::PRE . 'level', 'registrada' ); }
		wp_set_object_terms( $pid, [ $cat ], Module::T_CCAT );
		$sec = self::term( 'sector', Module::T_SECTOR );
		wp_set_object_terms( $pid, $sec ? [ $sec ] : [], Module::T_SECTOR );
		wp_set_object_terms( $pid, $mun ? [ $mun ] : [], Module::T_MUN );
		Store::log( Module::COMPANY, $pid, $new ? 'create' : 'edit', $new ? 'Perfil de empresa creado (pendiente de moderación)' : 'Perfil de empresa editado por su titular', 'internal' );
		$ok = self::files( 'docs', $pid, 5, 'internal' );
		delete_transient( 'wkt_old_company_' . Module::who() );
		Module::mail( Module::staff_email(), ( $new ? __( 'Nueva empresa por moderar: ', 'wakoo' ) : __( 'Empresa editada: ', 'wakoo' ) ) . $name, admin_url( 'post.php?post=' . $pid . '&action=edit' ) );
		self::back( $ok ? ( $new ? 'company_ok' : 'company_up' ) : 'file' );
	}

	public static function company_doc() {
		self::check( 'company_doc' );
		$mine = self::my_company();
		if ( ! $mine ) { self::back( 'nocompany' ); }
		if ( ! Module::rate( 'doc', 30 ) ) { self::back( 'limit' ); }
		self::back( self::files( 'docs', $mine->ID, 5, 'internal' ) ? 'doc_ok' : 'file' );
	}

	public static function need() {
		self::check( 'need' );
		$mine = self::my_company();
		if ( ! $mine ) { self::back( 'nocompany' ); }
		if ( ! Module::rate( 'need', 15, DAY_IN_SECONDS ) ) { self::back( 'limit' ); }
		$title = self::txt( 'title', 160 );
		$desc  = self::area( 'desc', 4000 );
		if ( '' === $title || mb_strlen( $desc ) < 30 ) { self::back( 'invalid' ); }
		$pid = wp_insert_post( [ 'post_type' => Module::NEED, 'post_status' => 'pending', 'post_title' => $title, 'post_content' => $desc, 'post_author' => get_current_user_id() ], true );
		if ( is_wp_error( $pid ) ) { self::back( 'invalid' ); }
		update_post_meta( $pid, Module::PRE . 'company', $mine->ID );
		$dl = self::txt( 'deadline', 10 );
		update_post_meta( $pid, Module::PRE . 'deadline', preg_match( '/^\d{4}-\d{2}-\d{2}$/', $dl ) ? $dl : '' );
		update_post_meta( $pid, Module::PRE . 'qty', self::txt( 'qty', 120 ) );
		$sec = self::term( 'sector', Module::T_SECTOR );
		$mun = self::term( 'municipio', Module::T_MUN );
		if ( $sec ) { wp_set_object_terms( $pid, [ $sec ], Module::T_SECTOR ); }
		if ( $mun ) { wp_set_object_terms( $pid, [ $mun ], Module::T_MUN ); }
		Store::log( Module::NEED, $pid, 'create', 'Necesidad de compra registrada (pendiente de moderación)', 'internal' );
		Module::mail( Module::staff_email(), __( 'Necesidad de compra por moderar: ', 'wakoo' ) . $title, admin_url( 'post.php?post=' . $pid . '&action=edit' ) );
		self::back( 'need_ok' );
	}

	/** Quote request / contact between companies. The recipient's email is never shown to the sender. */
	public static function rfq() {
		self::check( 'rfq' );
		if ( ! Module::rate( 'rfq', 15, DAY_IN_SECONDS ) ) { self::back( 'limit' ); }
		$to   = isset( $_POST['to'] ) ? (int) $_POST['to'] : 0;
		$need = isset( $_POST['need'] ) ? (int) $_POST['need'] : 0;
		if ( $need ) {
			$np = get_post( $need );
			if ( ! $np || Module::NEED !== $np->post_type || 'publish' !== $np->post_status ) { self::back( 'denied' ); }
			$to = (int) Module::meta( $need, 'company' );
		}
		$tp = get_post( $to );
		if ( ! $tp || Module::COMPANY !== $tp->post_type || 'publish' !== $tp->post_status || ! Module::has_owner( $tp ) ) { self::back( 'denied' ); }
		$subject = self::txt( 'subject', 160 );
		$msg     = self::area( 'message', 4000 );
		if ( '' === $subject || mb_strlen( $msg ) < 20 ) { self::back( 'invalid' ); }
		$from = self::my_company();
		if ( $from && (int) $from->ID === $to ) { self::back( 'denied' ); }
		$pid = wp_insert_post( [ 'post_type' => Module::RFQ, 'post_status' => 'private', 'post_title' => $subject, 'post_content' => $msg, 'post_author' => get_current_user_id() ], true );
		if ( is_wp_error( $pid ) ) { self::back( 'invalid' ); }
		update_post_meta( $pid, Module::PRE . 'to', $to );
		update_post_meta( $pid, Module::PRE . 'to_user', (int) $tp->post_author );
		update_post_meta( $pid, Module::PRE . 'from', $from ? $from->ID : 0 );
		update_post_meta( $pid, Module::PRE . 'need', $need );
		update_post_meta( $pid, Module::PRE . 'kind', $need ? 'oferta' : ( 'cotizacion' === self::txt( 'kind', 20 ) ? 'cotizacion' : 'contacto' ) );
		Store::log( Module::RFQ, $pid, 'create', sprintf( 'Consulta enviada a la empresa #%d', $to ), 'audit' );
		$owner = get_userdata( (int) $tp->post_author );
		if ( $owner ) {
			Module::mail( $owner->user_email, __( 'Nueva consulta en el directorio empresarial', 'wakoo' ),
				sprintf( __( "%1\$s le ha enviado una consulta: «%2\$s».\n\nResponda desde su panel: %3\$s", 'wakoo' ), $from ? $from->post_title : wp_get_current_user()->display_name, $subject, Module::page_url( 'company' ) ?: home_url( '/' ) ) );
		}
		self::back( 'rfq_ok' );
	}

	/** Reply inside a quote thread: only its two parties. */
	public static function rfq_reply() {
		self::check( 'rfq_reply' );
		$pid = isset( $_POST['rfq'] ) ? (int) $_POST['rfq'] : 0;
		$p   = get_post( $pid );
		$uid = get_current_user_id();
		if ( ! $p || Module::RFQ !== $p->post_type || ! in_array( $uid, [ (int) $p->post_author, (int) Module::meta( $pid, 'to_user' ) ], true ) ) { self::back( 'denied' ); }
		if ( ! Module::rate( 'rfq_reply', 40 ) ) { self::back( 'limit' ); }
		$msg = self::area( 'message', 4000 );
		if ( '' === $msg ) { self::back( 'invalid' ); }
		Store::log( Module::RFQ, $pid, 'reply', $msg, 'public' );
		$other = get_userdata( $uid === (int) $p->post_author ? (int) Module::meta( $pid, 'to_user' ) : (int) $p->post_author );
		if ( $other ) { Module::mail( $other->user_email, sprintf( __( 'Respuesta a «%s»', 'wakoo' ), $p->post_title ), Module::page_url( 'company' ) ?: home_url( '/' ) ); }
		self::back( 'reply_ok' );
	}
}
