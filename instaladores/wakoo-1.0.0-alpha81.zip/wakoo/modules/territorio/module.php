<?php
/**
 * Wakoo Territorio: tools for a regional investment-promotion portal.
 *
 * - Cartera de proyectos (`wakoo_project`): standard sheets with stage, estimate vs verified
 *   investment, sources and pending validations; catalogue with search and filters.
 * - Ventanilla única (`wakoo_case`): applicants register an initiative, get a unique code,
 *   a private file and a panel; staff change configurable statuses, assign, keep internal
 *   notes apart from public messages; every action is logged (audit).
 * - Directorio B2B y marketplace (`wakoo_company`, `wakoo_need`, `wakoo_rfq`): company
 *   profiles with owner-approved public fields, private documents, verification levels
 *   (registrada / documentación verificada / homologada), purchase needs and quote requests.
 * - Mapa (`wakoo_geo` + layers): Leaflet map with public and internal layers, verified flags,
 *   GeoJSON/CSV import and an honest empty state.
 * - Observatorio (`wakoo_indicator`): indicators with definition, unit, source, date,
 *   periodicity, owner, method and verification; demo values kept apart.
 * - Academia (`wakoo_course`, `wakoo_lesson`, `wakoo_cert`): MVP LMS with enrolment,
 *   lessons, quizzes, progress, completion and verifiable certificates; optional Moodle link.
 * - Roles: editor institucional, gestor de proyectos, gestor de proveedores, coordinador
 *   académico, docente and analista del observatorio.
 *
 * Nothing here grants permits or approves projects: the portal records, guides and follows up.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

defined( 'ABSPATH' ) || die();

class Module {

	const OPTION   = 'wakoo_territorio';
	const ROLES_V  = 'wakoo_territorio_roles';
	const DB_V     = 'wakoo_territorio_db';
	const VERSION  = '3';
	const PRE      = '_wakoo_t_';

	const PROJECT  = 'wakoo_project';
	const CASE_T   = 'wakoo_case';
	const COMPANY  = 'wakoo_company';
	const NEED     = 'wakoo_need';
	const RFQ      = 'wakoo_rfq';
	const GEO      = 'wakoo_geo';
	const IND      = 'wakoo_indicator';
	const COURSE   = 'wakoo_course';
	const LESSON   = 'wakoo_lesson';
	const CERT     = 'wakoo_cert';

	const T_SECTOR = 'wakoo_sector';
	const T_MUN    = 'wakoo_municipio';
	const T_CCAT   = 'wakoo_company_cat';
	const T_LAYER  = 'wakoo_geo_layer';
	const T_SCHOOL = 'wakoo_school';

	/** Project preparation stages (fixed list: the portal must distinguish them). */
	public static function stages() {
		return [
			'conceptual'    => __( 'Conceptual', 'wakoo' ),
			'evaluacion'    => __( 'En evaluación', 'wakoo' ),
			'estructuracion'=> __( 'En estructuración', 'wakoo' ),
			'promocion'     => __( 'Preparado para promoción', 'wakoo' ),
			'ejecucion'     => __( 'En ejecución', 'wakoo' ),
			'operacion'     => __( 'En operación', 'wakoo' ),
			'suspendido'    => __( 'Suspendido o cerrado', 'wakoo' ),
		];
	}

	/** Company verification levels. */
	public static function levels() {
		return [
			'referencia'  => __( 'Perfil de referencia (información pública)', 'wakoo' ),
			'registrada'  => __( 'Empresa registrada', 'wakoo' ),
			'verificada'  => __( 'Documentación verificada', 'wakoo' ),
			'homologada'  => __( 'Proveedor homologado por un comprador', 'wakoo' ),
		];
	}

	/** Indicator verification states. */
	public static function checks() {
		return [
			'pendiente'    => __( 'Pendiente de validación', 'wakoo' ),
			'verificacion' => __( 'En verificación', 'wakoo' ),
			'verificado'   => __( 'Verificado', 'wakoo' ),
		];
	}

	public static function init() {
		require_once __DIR__ . '/includes/store.php';
		require_once __DIR__ . '/includes/forms.php';
		require_once __DIR__ . '/includes/academy.php';
		add_action( 'init', [ __CLASS__, 'register' ] );
		add_action( 'init', [ __CLASS__, 'maybe_upgrade' ], 20 );
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widgets' ] );
		add_action( 'elementor/elements/categories_registered', [ __CLASS__, 'category' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'scripts' ] );
		add_action( 'elementor/frontend/after_register_styles', [ __CLASS__, 'styles' ] );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'styles' ], 5 );
		add_filter( 'template_include', [ __CLASS__, 'template' ], 99 );
		add_filter( 'wakoo_portable_types', [ __CLASS__, 'portable_types' ] );
		add_action( 'wakoo_portable_site', [ __CLASS__, 'portable_site' ], 10, 2 );
		add_filter( 'wp_robots', [ __CLASS__, 'robots' ] );
		add_filter( 'gettext_wakoo', [ __CLASS__, 'gettext' ], 10, 2 );
		require_once __DIR__ . '/includes/hub.php';
		require_once __DIR__ . '/includes/photos.php';
		require_once __DIR__ . '/includes/alerts.php';
		require_once __DIR__ . '/includes/sheet.php';
		Forms::init();
		Hub::init();
		Photos::init();
		Alerts::init();
		Sheet::init();
		Academy::init();
		require_once __DIR__ . '/includes/admin.php'; // Field definitions and counters are shared with the widgets.
		if ( is_admin() ) {
			Admin::init();
		}
	}

	/* ---------------------------------------------------------------- settings */

	public static function defaults() {
		return [
			'prefix'       => 'SOL',
			'statuses'     => "recibida|Recibida\nrevision|Revisión inicial\ninformacion|Información adicional solicitada\nevaluacion|Evaluación y orientación\nseguimiento|Seguimiento\ncerrada|Cierre administrativo|cerrado",
			'requirements' => "Descripción de la iniciativa\nIdentificación del promotor o la empresa\nLocalización propuesta (si existe)\nEstimación preliminar de inversión y fuente\nServicios requeridos (electricidad, agua, vialidad, telecomunicaciones)\nEstudios disponibles (suelo, mercado, factibilidad, ambientales)",
			'staff_email'  => '',
			'register'     => 1,
			'max_mb'       => 10,
			'tpl_project'  => 0,
			'tpl_company'  => 0,
			'tpl_course'   => 0,
			'page_access'  => 0,
			'page_cases'   => 0,
			'page_cases_new' => 0,
			'page_company' => 0,
			'page_student' => 0,
			'page_verify'  => 0,
			'page_hub'     => 0,
			'moodle_url'   => '',
			'tiles'        => 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
			'attr'         => '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
			'gmaps_key'    => '',
			'pdf_color'    => '',
			'pdf_accent'   => '',
			'center'       => '8.35,-64.15',
			'zoom'         => 8,
			'issuer'       => '',
			'privacy_url'  => '',
		];
	}

	public static function settings() {
		$o = get_option( self::OPTION, [] );
		return wp_parse_args( is_array( $o ) ? $o : [], self::defaults() );
	}

	/** Configurable case statuses: [ key => [ label, closed ] ]. */
	public static function statuses() {
		$out = [];
		foreach ( preg_split( '/\r\n|\r|\n/', (string) self::settings()['statuses'] ) as $line ) {
			$p = array_map( 'trim', explode( '|', $line ) );
			$k = sanitize_key( $p[0] ?? '' );
			if ( $k ) { $out[ $k ] = [ $p[1] ?? $k, ! empty( $p[2] ) ]; }
		}
		return $out ?: [ 'recibida' => [ __( 'Recibida', 'wakoo' ), false ] ];
	}

	public static function requirements() {
		return array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) self::settings()['requirements'] ) ) ) );
	}

	public static function page_url( $key, $args = [] ) {
		$id  = (int) ( self::settings()[ 'page_' . $key ] ?? 0 );
		$url = $id ? get_permalink( self::translated( $id ) ) : '';
		return $url ? add_query_arg( $args, $url ) : '';
	}

	/** The page in the language of the page being viewed (Wakoo Idiomas), when it exists. */
	public static function translated( $id ) {
		$i = '\Wakoo\Modules\Idiomas\Module';
		if ( ! class_exists( $i ) || ! is_singular() ) { return $id; }
		$lang = $i::lang_of( get_queried_object_id() );
		$tr   = $i::translations( $id );
		return ! empty( $tr[ $lang ] ) ? (int) $tr[ $lang ] : $id;
	}

	/* ---------------------------------------------------------------- types */

	private static function labels( $one, $many, $menu = '' ) {
		return [
			'name' => $many, 'singular_name' => $one, 'menu_name' => $menu ?: $many,
			'add_new' => __( 'Añadir', 'wakoo' ), 'add_new_item' => sprintf( __( 'Añadir: %s', 'wakoo' ), $one ),
			'edit_item' => sprintf( __( 'Editar: %s', 'wakoo' ), $one ), 'all_items' => $many,
			'search_items' => __( 'Buscar', 'wakoo' ), 'not_found' => __( 'No hay elementos.', 'wakoo' ),
		];
	}

	private static function caps( $type ) {
		return [ 'capability_type' => [ $type, $type . 's' ], 'map_meta_cap' => true ];
	}

	public static function register() {
		$hub = 'wakoo-territorio';
		register_post_type( self::PROJECT, [
			'labels' => self::labels( __( 'Proyecto', 'wakoo' ), __( 'Proyectos de inversión', 'wakoo' ) ),
			'public' => true, 'show_in_menu' => $hub, 'has_archive' => false, 'show_in_rest' => false,
			'rewrite' => [ 'slug' => 'proyectos', 'with_front' => false ],
			'supports' => [ 'title', 'editor', 'excerpt', 'thumbnail', 'revisions' ],
		] + self::caps( 'wk_project' ) );
		register_post_type( self::CASE_T, [
			'labels' => self::labels( __( 'Expediente', 'wakoo' ), __( 'Ventanilla: expedientes', 'wakoo' ), __( 'Expedientes', 'wakoo' ) ),
			'public' => false, 'show_ui' => true, 'show_in_menu' => $hub, 'show_in_rest' => false,
			'supports' => [ 'title', 'editor' ],
		] + self::caps( 'wk_case' ) );
		register_post_type( self::COMPANY, [
			'labels' => self::labels( __( 'Empresa', 'wakoo' ), __( 'Directorio: empresas', 'wakoo' ), __( 'Empresas', 'wakoo' ) ),
			'public' => true, 'show_in_menu' => $hub, 'has_archive' => false, 'show_in_rest' => false,
			'rewrite' => [ 'slug' => 'empresas', 'with_front' => false ],
			'supports' => [ 'title', 'editor', 'excerpt', 'thumbnail' ],
		] + self::caps( 'wk_company' ) );
		register_post_type( self::NEED, [
			'labels' => self::labels( __( 'Necesidad de compra', 'wakoo' ), __( 'Necesidades de compra', 'wakoo' ) ),
			'public' => false, 'show_ui' => true, 'show_in_menu' => $hub, 'show_in_rest' => false,
			'supports' => [ 'title', 'editor' ],
		] + self::caps( 'wk_need' ) );
		register_post_type( self::RFQ, [
			'labels' => self::labels( __( 'Consulta', 'wakoo' ), __( 'Consultas y cotizaciones', 'wakoo' ), __( 'Consultas', 'wakoo' ) ),
			'public' => false, 'show_ui' => true, 'show_in_menu' => $hub, 'show_in_rest' => false,
			'supports' => [ 'title', 'editor' ],
		] + self::caps( 'wk_rfq' ) );
		register_post_type( self::GEO, [
			'labels' => self::labels( __( 'Elemento del mapa', 'wakoo' ), __( 'Mapa: elementos', 'wakoo' ), __( 'Mapa', 'wakoo' ) ),
			'public' => false, 'show_ui' => true, 'show_in_menu' => $hub, 'show_in_rest' => false,
			'supports' => [ 'title', 'editor' ],
		] + self::caps( 'wk_geo' ) );
		register_post_type( self::IND, [
			'labels' => self::labels( __( 'Indicador', 'wakoo' ), __( 'Observatorio: indicadores', 'wakoo' ), __( 'Indicadores', 'wakoo' ) ),
			'public' => false, 'show_ui' => true, 'show_in_menu' => $hub, 'show_in_rest' => false,
			'supports' => [ 'title', 'editor', 'page-attributes' ],
		] + self::caps( 'wk_indicator' ) );
		register_post_type( self::COURSE, [
			'labels' => self::labels( __( 'Curso', 'wakoo' ), __( 'Academia: cursos', 'wakoo' ), __( 'Cursos', 'wakoo' ) ),
			'public' => true, 'show_in_menu' => $hub, 'has_archive' => false, 'show_in_rest' => false,
			'rewrite' => [ 'slug' => 'cursos', 'with_front' => false ],
			'supports' => [ 'title', 'editor', 'excerpt', 'thumbnail', 'author', 'page-attributes' ],
		] + self::caps( 'wk_course' ) );
		register_post_type( self::LESSON, [
			'labels' => self::labels( __( 'Lección', 'wakoo' ), __( 'Academia: lecciones', 'wakoo' ), __( 'Lecciones', 'wakoo' ) ),
			'public' => false, 'show_ui' => true, 'show_in_menu' => $hub, 'show_in_rest' => false,
			'supports' => [ 'title', 'editor', 'author', 'page-attributes' ],
		] + self::caps( 'wk_course' ) );
		register_post_type( self::CERT, [
			'labels' => self::labels( __( 'Certificado', 'wakoo' ), __( 'Academia: certificados', 'wakoo' ), __( 'Certificados', 'wakoo' ) ),
			'public' => false, 'show_ui' => true, 'show_in_menu' => $hub, 'show_in_rest' => false,
			'supports' => [ 'title' ],
		] + self::caps( 'wk_cert' ) );

		$tax = function ( $one, $many, $types, $cap ) {
			return [
				'labels' => [ 'name' => $many, 'singular_name' => $one, 'menu_name' => $many, 'add_new_item' => __( 'Añadir', 'wakoo' ) ],
				'public' => false, 'show_ui' => true, 'show_admin_column' => true, 'hierarchical' => true, 'show_in_rest' => false,
				'capabilities' => [ 'manage_terms' => $cap, 'edit_terms' => $cap, 'delete_terms' => $cap, 'assign_terms' => 'read' ],
			];
		};
		register_taxonomy( self::T_SECTOR, [ self::PROJECT, self::CASE_T, self::COMPANY, self::NEED, self::GEO, self::IND ], $tax( __( 'Sector', 'wakoo' ), __( 'Sectores', 'wakoo' ), null, 'wk_manage_portal' ) );
		register_taxonomy( self::T_MUN, [ self::PROJECT, self::CASE_T, self::COMPANY, self::NEED, self::GEO, self::IND ], $tax( __( 'Municipio', 'wakoo' ), __( 'Municipios', 'wakoo' ), null, 'wk_manage_portal' ) );
		register_taxonomy( self::T_CCAT, [ self::COMPANY ], $tax( __( 'Categoría', 'wakoo' ), __( 'Categorías de empresa', 'wakoo' ), null, 'edit_others_wk_companys' ) );
		register_taxonomy( self::T_LAYER, [ self::GEO ], $tax( __( 'Capa', 'wakoo' ), __( 'Capas del mapa', 'wakoo' ), null, 'edit_others_wk_geos' ) );
		register_taxonomy( self::T_SCHOOL, [ self::COURSE ], $tax( __( 'Escuela', 'wakoo' ), __( 'Escuelas', 'wakoo' ), null, 'edit_others_wk_courses' ) );
	}

	public static function portable_types( $t ) {
		return array_merge( $t, [ self::PROJECT, self::IND, self::COURSE, self::LESSON, self::GEO, self::COMPANY ] );
	}

	/**
	 * Pack settings: `site.wakoo.territorio` = { tpl_project: <key>, page_access: <key>, …, center, zoom, prefix,
	 * terms: { <taxonomy of this module>: [ { name, slug, meta: { wk_order, wk_color, wk_public } } ] } }.
	 * Terms are created (or renamed) so filters and forms have their lists before any content exists.
	 */
	public static function portable_site( $w, $keys ) {
		if ( empty( $w['territorio'] ) || ! is_array( $w['territorio'] ) ) { return; }
		$o = self::settings();
		foreach ( $w['territorio'] as $k => $v ) {
			$k = sanitize_key( $k );
			if ( 'terms' === $k && is_array( $v ) ) {
				self::pack_terms( $v );
			} elseif ( 'i18n' === $k && is_array( $v ) ) {
				$cur = get_option( 'wakoo_t_i18n', [] );
				$cur = is_array( $cur ) ? $cur : [];
				foreach ( $v as $lang => $pairs ) {
					$lang = sanitize_key( $lang );
					if ( ! $lang || ! is_array( $pairs ) ) { continue; }
					foreach ( $pairs as $es => $tr ) { $cur[ $lang ][ (string) $es ] = wp_kses_post( (string) $tr ); }
				}
				update_option( 'wakoo_t_i18n', $cur, false );
			} elseif ( 0 === strpos( $k, 'tpl_' ) || 0 === strpos( $k, 'page_' ) ) {
				if ( array_key_exists( $k, $o ) && isset( $keys[ sanitize_key( (string) $v ) ] ) ) { $o[ $k ] = (int) $keys[ sanitize_key( (string) $v ) ]; }
			} elseif ( in_array( $k, [ 'center', 'prefix', 'statuses', 'requirements', 'issuer' ], true ) && is_string( $v ) ) {
				$o[ $k ] = sanitize_textarea_field( $v );
			} elseif ( in_array( $k, [ 'pdf_color', 'pdf_accent' ], true ) && is_string( $v ) ) {
				$o[ $k ] = (string) sanitize_hex_color( $v );
			} elseif ( in_array( $k, [ 'zoom', 'max_mb', 'register' ], true ) ) {
				$o[ $k ] = (int) $v;
			}
		}
		update_option( self::OPTION, $o );
		flush_rewrite_rules( false );
	}

	private static function pack_terms( array $all ) {
		$mine = [ self::T_SECTOR, self::T_MUN, self::T_CCAT, self::T_LAYER, self::T_SCHOOL ];
		foreach ( $all as $tax => $list ) {
			if ( ! in_array( $tax, $mine, true ) || ! is_array( $list ) ) { continue; }
			foreach ( $list as $t ) {
				$name = sanitize_text_field( (string) ( $t['name'] ?? '' ) );
				$slug = sanitize_title( (string) ( $t['slug'] ?? $name ) );
				if ( '' === $name || '' === $slug ) { continue; }
				$term = get_term_by( 'slug', $slug, $tax );
				if ( $term ) {
					$tid = (int) $term->term_id;
					wp_update_term( $tid, $tax, [ 'name' => $name, 'description' => sanitize_textarea_field( (string) ( $t['description'] ?? $term->description ) ) ] );
				} else {
					$r = wp_insert_term( $name, $tax, [ 'slug' => $slug, 'description' => sanitize_textarea_field( (string) ( $t['description'] ?? '' ) ) ] );
					if ( is_wp_error( $r ) ) { continue; }
					$tid = (int) $r['term_id'];
				}
				foreach ( (array) ( $t['meta'] ?? [] ) as $mk => $mv ) {
					if ( in_array( $mk, [ 'wk_order', 'wk_color', 'wk_public', 'wk_icon' ], true ) || preg_match( '/^wk_name_[a-z_]{2,8}$/', $mk ) ) { update_term_meta( $tid, $mk, sanitize_text_field( (string) $mv ) ); }
				}
			}
		}
	}

	/* ---------------------------------------------------------------- roles */

	/** Capabilities of one capability_type (plural form as WordPress builds them). */
	public static function type_caps( $plural, $all = true ) {
		$c = [ "edit_$plural", "delete_$plural", "edit_published_$plural", "delete_published_$plural" ];
		if ( $all ) {
			$c = array_merge( $c, [ "edit_others_$plural", "publish_$plural", "read_private_$plural", "delete_others_$plural", "delete_private_$plural", "edit_private_$plural" ] );
		}
		return $c;
	}

	public static function role_map() {
		$tc = [ __CLASS__, 'type_caps' ];
		$base = [ 'read', 'upload_files', 'wk_staff' ];
		return [
			'wk_editor_inst'        => [ __( 'Editor institucional', 'wakoo' ), 'editor', array_merge( $base, $tc( 'wk_projects' ), [ 'wk_reports' ] ) ],
			'wk_gestor_proyectos'   => [ __( 'Gestor de proyectos', 'wakoo' ), '', array_merge( $base, $tc( 'wk_projects' ), $tc( 'wk_cases' ), $tc( 'wk_geos' ), [ 'wk_reports' ] ) ],
			'wk_gestor_proveedores' => [ __( 'Gestor de proveedores', 'wakoo' ), '', array_merge( $base, $tc( 'wk_companys' ), $tc( 'wk_needs' ), $tc( 'wk_rfqs' ), [ 'wk_reports' ] ) ],
			'wk_coord_academico'    => [ __( 'Coordinador académico', 'wakoo' ), '', array_merge( $base, $tc( 'wk_courses' ), $tc( 'wk_certs' ), [ 'wk_reports', 'wk_teach' ] ) ],
			'wk_docente'            => [ __( 'Docente', 'wakoo' ), '', array_merge( $base, $tc( 'wk_courses', false ), [ 'wk_teach' ] ) ],
			'wk_analista'           => [ __( 'Analista del observatorio', 'wakoo' ), '', array_merge( $base, $tc( 'wk_indicators' ), $tc( 'wk_geos' ), [ 'wk_reports' ] ) ],
		];
	}

	public static function maybe_upgrade() {
		if ( get_option( self::DB_V ) !== self::VERSION ) {
			Store::install();
			update_option( self::DB_V, self::VERSION );
		}
		if ( get_option( self::ROLES_V ) === self::VERSION ) { return; }
		foreach ( self::role_map() as $role => $d ) {
			remove_role( $role );
			$caps = array_fill_keys( $d[2], true );
			if ( $d[1] && ( $from = get_role( $d[1] ) ) ) { $caps = array_merge( $from->capabilities, $caps ); }
			add_role( $role, $d[0], $caps );
		}
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			foreach ( [ 'wk_projects', 'wk_cases', 'wk_companys', 'wk_needs', 'wk_rfqs', 'wk_geos', 'wk_indicators', 'wk_courses', 'wk_certs' ] as $p ) {
				foreach ( self::type_caps( $p ) as $c ) { $admin->add_cap( $c ); }
			}
			foreach ( [ 'wk_staff', 'wk_reports', 'wk_teach', 'wk_view_audit', 'wk_manage_portal' ] as $c ) { $admin->add_cap( $c ); }
		}
		update_option( self::ROLES_V, self::VERSION );
		flush_rewrite_rules( false );
	}

	/* ---------------------------------------------------------------- front */

	public static function category( $mgr ) {
		$mgr->add_category( 'wakoo-territorio', [ 'title' => __( 'Wakoo · Territorio e inversión', 'wakoo' ), 'icon' => 'eicon-globe' ] );
	}

	public static function register_widgets( $wm ) {
		require_once __DIR__ . '/widgets/base.php';
		$all = [ 'Access', 'Projects', 'Project', 'Stages', 'CaseForm', 'Cases', 'Companies', 'Company', 'CompanyPanel', 'Needs', 'Gis', 'Observatory', 'Courses', 'Course', 'Student', 'Verify', 'Hub' ];
		foreach ( $all as $c ) {
			require_once __DIR__ . '/widgets/' . strtolower( $c ) . '.php';
			$cls = __NAMESPACE__ . '\\W_' . $c;
			$wm->register( new $cls() );
		}
	}

	public static function scripts() {
		$u = WAKOO_MODULES_URL . 'territorio/';
		$p = WAKOO_MODULES_URL . 'places/vendor/';
		if ( ! wp_script_is( 'wakoo-leaflet', 'registered' ) ) {
			wp_register_script( 'wakoo-leaflet', $p . 'leaflet/leaflet.js', [], '1.9.4', true );
		}
		if ( ! wp_script_is( 'wakoo-chart', 'registered' ) ) {
			wp_register_script( 'wakoo-chart', WAKOO_ASSETS . 'vendor/chart/chart.min.js', [], '2.9.4', true );
		}
		wp_register_script( 'wakoo-territorio', $u . 'assets/territorio.js', [], WAKOO_VERSION, true );
		wp_register_script( 'wakoo-territorio-map', $u . 'assets/gis.js', [ 'wakoo-leaflet' ], WAKOO_VERSION, true );
		wp_register_script( 'wakoo-territorio-obs', $u . 'assets/observatorio.js', [ 'wakoo-chart' ], WAKOO_VERSION, true );
	}

	public static function styles() {
		$u = WAKOO_MODULES_URL . 'territorio/';
		if ( ! wp_style_is( 'wakoo-leaflet', 'registered' ) ) {
			wp_register_style( 'wakoo-leaflet', WAKOO_MODULES_URL . 'places/vendor/leaflet/leaflet.css', [], '1.9.4' );
		}
		if ( ! wp_style_is( 'wakoo-territorio', 'registered' ) ) {
			wp_register_style( 'wakoo-territorio', $u . 'assets/territorio.css', [], WAKOO_VERSION );
		}
	}

	/** Single project / company / course: the Elementor template chosen in Territorio → Ajustes. */
	public static function template( $tpl ) {
		if ( ! is_singular( [ self::PROJECT, self::COMPANY, self::COURSE ] ) ) { return $tpl; }
		$map = [ self::PROJECT => 'tpl_project', self::COMPANY => 'tpl_company', self::COURSE => 'tpl_course' ];
		$id  = (int) self::settings()[ $map[ get_post_type() ] ];
		$GLOBALS['wakoo_t_tpl'] = $id ? self::translated_tpl( $id ) : 0;
		return __DIR__ . '/templates/' . ( $GLOBALS['wakoo_t_tpl'] ? 'canvas.php' : 'single.php' );
	}

	/** Template in the visitor's language: translation group of the template, language of the referring page. */
	private static function translated_tpl( $id ) {
		$i = '\Wakoo\Modules\Idiomas\Module';
		if ( ! class_exists( $i ) ) { return $id; }
		$lang = isset( $_GET['lang'] ) ? sanitize_key( wp_unslash( $_GET['lang'] ) ) : ( is_singular() ? (string) $i::lang_of( get_queried_object_id() ) : '' ); // phpcs:ignore WordPress.Security.NonceVerification
		$tr   = $i::translations( $id );
		return ( $lang && ! empty( $tr[ $lang ] ) ) ? (int) $tr[ $lang ] : $id;
	}

	/** Private panels never go to search engines. */
	public static function robots( $r ) {
		if ( is_singular() ) {
			$id = get_queried_object_id();
			foreach ( [ 'access', 'cases', 'company', 'student', 'hub' ] as $k ) {
				$p = (int) ( self::settings()[ 'page_' . $k ] ?? 0 );
				if ( $p && ( $p === $id || in_array( $id, array_map( 'intval', self::translations_of( $p ) ), true ) ) ) {
					$r['noindex'] = true;
				}
			}
		}
		return $r;
	}

	private static function translations_of( $id ) {
		$i = '\Wakoo\Modules\Idiomas\Module';
		return class_exists( $i ) ? array_values( (array) $i::translations( $id ) ) : [];
	}

	/* ---------------------------------------------------------------- helpers */

	public static function meta( $id, $key, $default = '' ) {
		$v = get_post_meta( $id, self::PRE . $key, true );
		return ( '' === $v || null === $v ) ? $default : $v;
	}

	/** The company's own account (the profile's author when it is not a staff member), or null. */
	public static function company_account( $c ) {
		$u = get_userdata( (int) $c->post_author );
		return $u && ! user_can( $u, 'edit_others_posts' ) ? $u : null;
	}

	/**
	 * Whether a company profile is managed by the company itself. Reference profiles stay
	 * ownerless until the hub creates their account and the company replaces its temporary password.
	 */
	public static function has_owner( $c ) {
		if ( 'referencia' !== self::meta( $c->ID, 'level' ) ) { return true; }
		$u = self::company_account( $c );
		return $u && ! get_user_meta( $u->ID, Hub::MUST, true );
	}

	public static function terms( $id, $tax ) {
		$t = get_the_terms( $id, $tax );
		return is_array( $t ) ? $t : [];
	}

	public static function term_names( $id, $tax ) {
		return implode( ', ', array_map( [ __CLASS__, 'term_label' ], self::terms( $id, $tax ) ) );
	}

	/* ---------------------------------------------------------------- languages (Wakoo Idiomas) */

	/** Language of the page being viewed ('' without Wakoo Idiomas). */
	public static function view_lang() {
		$i = '\Wakoo\Modules\Idiomas\Module';
		if ( ! class_exists( $i ) ) { return ''; }
		$id = self::editor_doc();
		if ( ! $id ) {
			$id = is_singular() ? (int) get_queried_object_id() : ( is_front_page() ? (int) get_option( 'page_on_front' ) : 0 );
		}
		return $id ? (string) $i::lang_of( $id ) : (string) $i::default_lang();
	}

	/** Post being rendered by the Elementor editor (its HTML cache and AJAX renders run in admin), or 0. */
	public static function editor_doc() {
		if ( ! is_admin() || ! class_exists( '\Elementor\Plugin' ) || empty( \Elementor\Plugin::$instance->documents ) ) { return 0; }
		$d = \Elementor\Plugin::$instance->documents->get_current();
		return $d ? (int) $d->get_main_id() : 0;
	}

	public static function master_lang() {
		$i = '\Wakoo\Modules\Idiomas\Module';
		return class_exists( $i ) ? (string) $i::default_lang() : '';
	}

	/**
	 * Interface words in the language being viewed. Wakoo speaks Spanish; on a page in another
	 * language, Spanish texts found in the option `wakoo_t_i18n` ({ lang: { español: traducción } },
	 * filled by a pack or by hand) are swapped. Covers widget defaults, states and form messages.
	 */
	public static function tr( $text ) {
		static $dict = null;
		if ( ( ! did_action( 'wp' ) || is_admin() ) && ! self::editor_doc() ) { return $text; } // Only on a front page or an editor preview.
		$l = self::view_lang();
		if ( '' === $l || $l === self::master_lang() ) { return $text; }
		if ( null === $dict ) { $dict = get_option( 'wakoo_t_i18n', [] ); }
		return is_array( $dict ) && isset( $dict[ $l ][ $text ] ) && '' !== $dict[ $l ][ $text ] ? $dict[ $l ][ $text ] : $text;
	}

	public static function gettext( $translation, $text ) {
		return $translation === $text ? self::tr( $text ) : $translation;
	}

	/** Term name in the language being viewed (term meta wk_name_<lang>, e.g. wk_name_zh_tw). */
	public static function term_label( $t ) {
		$l = self::view_lang();
		if ( $l && $l !== self::master_lang() ) {
			$n = (string) get_term_meta( $t->term_id, 'wk_name_' . str_replace( '-', '_', $l ), true );
			if ( '' !== $n ) { return $n; }
		}
		return $t->name;
	}

	/**
	 * Restricts a query of translatable content (projects, indicators, courses) to one language:
	 * the one being viewed, or the master for counts. Posts without a language count as master.
	 */
	public static function by_lang( array $args, $lang = null ) {
		$lang   = null === $lang ? self::view_lang() : $lang;
		$master = self::master_lang();
		if ( '' === $lang || '' === $master ) { return $args; }
		$clause = $lang === $master
			? [ 'relation' => 'OR', [ 'key' => '_wakoo_lang', 'value' => $master ], [ 'key' => '_wakoo_lang', 'compare' => 'NOT EXISTS' ] ]
			: [ 'key' => '_wakoo_lang', 'value' => $lang ];
		$args['meta_query'] = empty( $args['meta_query'] ) ? [ $clause ] : [ 'relation' => 'AND', $clause, $args['meta_query'] ]; // phpcs:ignore WordPress.DB.SlowDBQuery
		return $args;
	}

	/** get_posts() in the language being viewed, falling back to the master when that language has none. */
	public static function lang_posts( array $args ) {
		$l    = self::view_lang();
		$list = get_posts( self::by_lang( $args, $l ) );
		if ( ! $list && $l && $l !== self::master_lang() ) { $list = get_posts( self::by_lang( $args, self::master_lang() ) ); }
		return $list;
	}

	/** Formatted investment with its nature: never presents an estimate as a verified figure. */
	public static function money( $id ) {
		$amt = self::meta( $id, 'amount' );
		if ( '' === $amt || ! is_numeric( $amt ) ) { return ''; }
		$cur = self::meta( $id, 'currency', 'USD' );
		return $cur . ' ' . number_format_i18n( (float) $amt, 0 );
	}

	public static function is_staff() {
		return current_user_can( 'wk_staff' ) || current_user_can( 'manage_options' );
	}

	/** Visitor fingerprint for rate limits (hash, no IP stored). */
	public static function who() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return substr( hash_hmac( 'sha256', $ip, wp_salt( 'nonce' ) ), 0, 20 );
	}

	/** True while under the limit; counts one more hit. */
	public static function rate( $action, $max = 10, $window = HOUR_IN_SECONDS ) {
		$k = 'wkt_rl_' . md5( $action . self::who() );
		$n = (int) get_transient( $k );
		if ( $n >= $max ) { return false; }
		set_transient( $k, $n + 1, $window );
		return true;
	}

	public static function mail( $to, $subject, $body ) {
		if ( ! $to || ! is_email( $to ) ) { return false; }
		$name = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		return wp_mail( $to, '[' . $name . '] ' . $subject, $body . "\n\n— " . $name . "\n" . home_url( '/' ) );
	}

	public static function staff_email() {
		$e = self::settings()['staff_email'];
		return is_email( $e ) ? $e : get_option( 'admin_email' );
	}
}

Module::init();
