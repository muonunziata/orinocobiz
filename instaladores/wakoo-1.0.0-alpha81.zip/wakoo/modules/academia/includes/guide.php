<?php
/**
 * «Guía del curso (PDF)»: the whole course as an A4 PDF to study without a connection
 * (lesson summaries, practices, how the evaluation and the certificate work), built on the
 * fly from the widgets of the course page. URL: the course page + ?guia=pdf. Shown when the
 * «Cabecera del curso» has «Guía del curso en PDF» on. Every word comes from the widgets,
 * so each language prints its own. The evaluation answers are never printed.
 *
 * Uses the PDF writer of Territorio (`modules/territorio/includes/pdf.php`, no library).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Academia;

use Wakoo\Modules\Territorio\Pdf;

defined( 'ABSPATH' ) || die();

class Guide {

	const M   = 52;
	const TOP = 66;
	const BOT = 64;

	private $pdf;
	private $y = 0;
	private $c = [];
	private $title = '';

	public static function init() {
		add_action( 'template_redirect', [ __CLASS__, 'serve' ], 4 );
	}

	public static function url( $post_id ) {
		return add_query_arg( 'guia', 'pdf', get_permalink( $post_id ) );
	}

	public static function serve() {
		if ( empty( $_GET['guia'] ) || ! is_singular() ) { return; } // phpcs:ignore WordPress.Security.NonceVerification
		$id   = (int) get_queried_object_id();
		$raw  = get_post_meta( $id, '_elementor_data', true );
		$data = is_array( $raw ) ? $raw : json_decode( (string) $raw, true );
		$head = Module::find( $data, 'wakoo-ac-cabecera' );
		if ( ! $head || 'yes' !== ( $head['settings']['guia'] ?? '' ) ) { return; }
		$file = WAKOO_MODULES_PATH . 'territorio/includes/pdf.php';
		if ( ! file_exists( $file ) ) { return; }
		require_once $file;
		$pdf  = ( new self() )->build( $id, $data, $head['settings'] );
		$name = sanitize_file_name( ( sanitize_key( $head['settings']['clave'] ?? '' ) ?: get_post_field( 'post_name', $id ) ) . '-guia.pdf' );
		nocache_headers();
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: attachment; filename="' . $name . '"' );
		header( 'Content-Length: ' . strlen( $pdf ) );
		header( 'X-Robots-Tag: noindex' );
		echo $pdf; // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	/** Word of a widget: its «Textos» control, else Wakoo's Spanish default. */
	private static function w( $settings, $key, $default ) {
		$v = (string) ( $settings[ 't_' . $key ] ?? '' );
		return '' !== $v ? $v : $default;
	}

	/** Rich text → [ [ 'p' | 'li', text ], … ]. */
	private static function blocks( $html ) {
		$out  = [];
		$html = preg_replace( '#<br\s*/?>#i', "\n", (string) $html );
		preg_match_all( '#<(p|li|h[1-6])[^>]*>(.*?)</\1>#is', $html, $m, PREG_SET_ORDER );
		foreach ( $m as $b ) {
			$t = trim( html_entity_decode( wp_strip_all_tags( $b[2] ), ENT_QUOTES, 'UTF-8' ) );
			if ( '' !== $t ) { $out[] = [ 'li' === strtolower( $b[1] ) ? 'li' : 'p', $t ]; }
		}
		if ( ! $out ) {
			$t = trim( html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES, 'UTF-8' ) );
			if ( '' !== $t ) { $out[] = [ 'p', $t ]; }
		}
		return $out;
	}

	private function cw() { return Pdf::W - 2 * self::M; }

	private function need( $h ) {
		if ( $this->y + $h <= Pdf::H - self::BOT ) { return; }
		$this->pdf->add_page();
		$this->pdf->rect( 0, 0, Pdf::W, 6, $this->c['main'] );
		$this->pdf->font( 'B', 8 );
		$this->pdf->text( self::M, 34, mb_strimwidth( $this->title, 0, 110, '…' ), $this->c['muted'] );
		$this->pdf->line( self::M, 42, Pdf::W - self::M, 42, $this->c['line'] );
		$this->y = self::TOP;
	}

	private function para( $text, $size = 10, $style = 'R', $color = null, $x = null, $w = null, $lh = 1.45 ) {
		$x = null === $x ? self::M : $x;
		$w = null === $w ? $this->cw() : $w;
		$this->pdf->font( $style, $size );
		foreach ( $this->pdf->wrap( $text, $w ) as $line ) {
			$this->need( $size * $lh );
			$this->y += $size * $lh;
			$this->pdf->text( $x, $this->y - $size * ( $lh - 1 ) / 2 - 1, $line, $color ?: $this->c['text'] );
		}
	}

	private function colors( $head ) {
		$main = sanitize_hex_color( (string) ( $head['accent'] ?? '' ) );
		$t    = '\Wakoo\Modules\Territorio\Sheet';
		$base = class_exists( $t ) ? $t::colors() : [ 'main' => '#10355B', 'accent' => '#C5A15B' ];
		return [
			'main'   => $main ?: $base['main'],
			'accent' => $base['accent'],
			'text'   => '#24303D',
			'muted'  => '#5B6878',
			'line'   => '#D8DEE6',
			'soft'   => '#F2F5F8',
		];
	}

	public function build( $id, $data, $h ) {
		$room  = Module::find( $data, 'wakoo-ac-aula' );
		$quiz  = Module::find( $data, 'wakoo-ac-evaluacion' );
		$rs    = $room['settings'] ?? [];
		$qs    = $quiz['settings'] ?? [];
		$sum   = Module::course( $id ) ?: [];
		$this->c     = $this->colors( $h );
		$this->title = (string) ( $h['titulo'] ?? '' ) ?: get_the_title( $id );
		$this->pdf   = new Pdf( false !== stripos( (string) get_post_meta( $id, '_wakoo_lang', true ), 'cn' ) ? 'cn' : 'tw' );
		$pdf  = $this->pdf;
		$c    = $this->c;
		$M    = self::M;
		$W    = $this->cw();
		$org  = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$less = array_values( (array) ( $rs['lessons'] ?? [] ) );
		$word = function ( $k, $d ) use ( $h ) { return self::w( $h, $k, $d ); };
		$lw   = function ( $k, $d ) use ( $rs ) { return self::w( $rs, $k, $d ); };

		// Cover band.
		$pdf->add_page();
		$pdf->rect( 0, 0, Pdf::W, 230, $c['main'] );
		$pdf->rect( 0, 230, Pdf::W, 3, $c['accent'] );
		$pdf->font( 'B', 10 );
		$pdf->text( $M, 44, $org, '#FFFFFF' );
		$pdf->font( 'R', 8.5 );
		$pdf->text( Pdf::W - $M, 44, mb_strtoupper( $word( 'guide_t', __( 'Guía del curso', 'wakoo' ) ) ), '#FFFFFF', 'R' );
		if ( ! empty( $h['cat'] ) ) {
			$pdf->font( 'B', 8.5 );
			$cw = $pdf->width( $h['cat'] ) + 20;
			$pdf->rect( $M, 74, $cw, 22, $c['accent'], null, 0, 11 );
			$pdf->text( $M + 10, 88.5, $h['cat'], $c['main'] );
		}
		$this->y = 104;
		$this->para( $this->title, 22, 'B', '#FFFFFF', null, null, 1.22 );
		if ( ! empty( $h['lema'] ) ) { $this->y += 4; $this->para( $h['lema'], 11, 'R', '#DCE5EF', null, $W * 0.85 ); }

		// Facts row.
		$this->y = 252;
		$facts = array_filter( [
			[ $word( 'lessons', __( 'lecciones', 'wakoo' ) ), (string) count( $less ) ],
			[ $word( 'hours', __( 'Duración', 'wakoo' ) ), (string) ( $h['horas'] ?? '' ) ],
			[ $word( 'level', __( 'Nivel', 'wakoo' ) ), (string) ( $h['nivel'] ?? '' ) ],
			[ preg_replace( '/[\s:：]+$/u', '', $word( 'badge', __( 'Insignia al aprobar:', 'wakoo' ) ) ), (string) ( $h['insignia'] ?? '' ) ],
		], function ( $f ) { return '' !== $f[1]; } );
		$n  = max( 1, count( $facts ) );
		$fw = ( $W - ( $n - 1 ) * 10 ) / $n;
		$i  = 0;
		foreach ( $facts as $f ) {
			$x = $M + $i * ( $fw + 10 );
			$pdf->rect( $x, $this->y, $fw, 50, $c['soft'], null, 0, 6 );
			$pdf->font( 'B', 7 );
			$pdf->text( $x + 12, $this->y + 18, mb_strtoupper( $f[0] ), $c['muted'] );
			$v  = mb_strimwidth( $f[1], 0, 34, '…' );
			$fs = 11;
			$pdf->font( 'B', $fs );
			while ( $fs > 7 && $pdf->width( $v ) > $fw - 20 ) { $pdf->font( 'B', --$fs ); } // Shrink long values to fit the box.
			$pdf->text( $x + 12, $this->y + 37, $v, $c['main'] );
			$i++;
		}
		$this->y += 72;

		// Contents.
		$pdf->rect( $M, $this->y, 22, 2.4, $c['accent'] );
		$this->y += 8;
		$this->para( mb_strtoupper( $word( 'contents', __( 'Contenido', 'wakoo' ) ) ), 9, 'B', $c['main'] );
		$this->y += 4;
		foreach ( $less as $k => $l ) {
			$this->need( 20 );
			$y0 = $this->y;
			$pdf->font( 'B', 10 );
			$pdf->text( $M, $y0 + 14, sprintf( '%02d', $k + 1 ), $c['accent'] );
			$this->para( (string) ( $l['title'] ?? '' ), 10, 'R', $c['text'], $M + 28, $W - 90 );
			if ( ! empty( $l['dur'] ) ) { $pdf->font( 'R', 8.5 ); $pdf->text( $M + $W, $y0 + 14, $l['dur'], $c['muted'], 'R' ); }
			$this->y += 4;
			$pdf->line( $M, $this->y, $M + $W, $this->y, $c['line'], 0.5 );
		}
		if ( $quiz ) {
			$this->need( 20 );
			$y0 = $this->y;
			$pdf->rect( $M + 3, $y0 + 7, 8, 8, $c['accent'], null, 0, 4 );
			$this->para( (string) ( $qs['title'] ?? '' ) ?: $word( 'quiz', __( 'evaluación final', 'wakoo' ) ), 10, 'B', $c['main'], $M + 28, $W - 28 );
		}

		// One section per lesson.
		foreach ( $less as $k => $l ) {
			$this->need( 120 );
			$this->y += 26;
			$pdf->font( 'B', 8 );
			$pdf->text( $M, $this->y, mb_strtoupper( $lw( 'lesson', __( 'Lección', 'wakoo' ) ) . ' ' . ( $k + 1 ) . ' ' . $lw( 'of', __( 'de', 'wakoo' ) ) . ' ' . count( $less ) ), $c['accent'] );
			$this->y += 4;
			$this->para( (string) ( $l['title'] ?? '' ), 15, 'B', $c['main'], null, null, 1.3 );
			$this->y += 6;
			foreach ( self::blocks( $l['summary'] ?? '' ) as $b ) {
				if ( 'li' === $b[0] ) {
					$this->need( 16 );
					$pdf->rect( $M + 3, $this->y + 7.5, 4, 4, $c['accent'], null, 0, 2 );
					$this->para( $b[1], 10, 'R', null, $M + 16, $W - 16 );
					$this->y += 2;
				} else {
					$this->para( $b[1], 10.5 );
					$this->y += 6;
				}
			}
			$prac = trim( (string) ( $l['practice'] ?? '' ) );
			if ( '' !== $prac ) {
				$pdf->font( 'R', 10 );
				$lines = count( $pdf->wrap( $prac, $W - 40 ) );
				$bh    = 34 + $lines * 14.5;
				$this->need( $bh + 76 ); // Box and the note lines stay on one page.
				$this->y += 8;
				$top = $this->y;
				$pdf->rect( $M, $top, $W, $bh, $c['soft'], null, 0, 6 );
				$pdf->rect( $M, $top, 4, $bh, $c['accent'] );
				$this->y = $top + 8;
				$this->para( mb_strtoupper( $lw( 'practice', __( 'Tu práctica', 'wakoo' ) ) ), 8, 'B', $c['main'], $M + 20, $W - 40 );
				$this->y += 2;
				$this->para( $prac, 10, 'R', null, $M + 20, $W - 40 );
				$this->y = $top + $bh;
				// Room to write by hand.
				$this->y += 10;
				$pdf->font( 'R', 7.5 );
				$pdf->text( $M, $this->y + 4, $lw( 'notes', __( 'Mis notas', 'wakoo' ) ), $c['muted'] );
				for ( $r = 1; $r <= 3; $r++ ) { $pdf->line( $M, $this->y + 4 + $r * 16, $M + $W, $this->y + 4 + $r * 16, $c['line'], 0.5 ); }
				$this->y += 56;
			}
		}

		// Evaluation and certificate (without the answers).
		$link = get_permalink( $id ) . ( $quiz && ! empty( $quiz['settings']['_element_id'] ) ? '#' . $quiz['settings']['_element_id'] : '' );
		$this->need( 110 );
		$this->y += 26;
		$top = $this->y;
		$pdf->rect( $M, $top, $W, 90, $c['main'], null, 0, 8 );
		$this->y = $top + 12;
		$this->para( (string) ( $qs['title'] ?? '' ) ?: $word( 'quiz', __( 'evaluación final', 'wakoo' ) ), 13, 'B', '#FFFFFF', $M + 20, $W - 40 );
		$pass = (int) ( $sum['pass'] ?? 0 );
		$this->para( $word( 'guide_q', __( 'Haga la evaluación final en línea para recibir su certificado con código de verificación:', 'wakoo' ) ) . ( $pass ? ' (' . $pass . ' %)' : '' ), 9.5, 'R', '#DCE5EF', $M + 20, $W - 40 );
		$this->y += 2;
		$y0 = $this->y;
		$this->para( preg_replace( '#^https?://#', '', $link ), 9.5, 'B', '#FFFFFF', $M + 20, $W - 40 );
		$pdf->link( $M + 20, $y0, $W - 40, $this->y - $y0 + 2, $link );
		$this->y = max( $this->y, $top + 90 );

		$note = trim( (string) ( $h['guia_nota'] ?? '' ) );
		if ( '' !== $note ) { $this->y += 14; $this->para( $note, 7.5, 'R', $c['muted'] ); }

		$total = $pdf->pages();
		$pg    = $word( 'page', __( 'Página %1$d de %2$d', 'wakoo' ) );
		for ( $i = 1; $i <= $total; $i++ ) {
			$pdf->on_page( $i );
			$pdf->line( $M, Pdf::H - 40, Pdf::W - $M, Pdf::H - 40, $c['line'], 0.5 );
			$pdf->font( 'R', 7 );
			$pdf->text( $M, Pdf::H - 27, $org . ' · ' . preg_replace( '#^https?://|/$#', '', home_url( '/' ) ), $c['muted'] );
			$pdf->text( Pdf::W - $M, Pdf::H - 27, sprintf( $pg, $i, $total ), $c['muted'], 'R' );
		}
		return $pdf->output( $this->title, $org );
	}
}
