<?php
/**
 * Certificado: the printable certificate of a passed course (?curso=key) and
 * the public check of a certificate code (?codigo=XXXXXXXXXX).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Academia\Widgets;

use Elementor\Controls_Manager;
use Wakoo\Modules\Academia\Module;

defined( 'ABSPATH' ) || die();

class Certificado extends Base {

	public function get_name() { return 'wakoo-ac-certificado'; }
	public function get_title() { return __( 'Certificado del curso', 'wakoo' ); }
	public function get_icon() { return 'eicon-document-file'; }
	public function get_keywords() { return [ 'certificado', 'diploma', 'certificate', 'verificar', 'academia', 'wakoo' ]; }

	protected function words() {
		return [
			'head'    => [ __( 'Certificado de aprovechamiento', 'wakoo' ), __( 'Título del certificado', 'wakoo' ) ],
			'grants'  => [ __( 'certifica que', 'wakoo' ), __( '«[organización] certifica que»', 'wakoo' ) ],
			'passed'  => [ __( 'ha completado el curso', 'wakoo' ) ],
			'on'      => [ __( 'el', 'wakoo' ), __( 'Antes de la fecha', 'wakoo' ) ],
			'hours'   => [ __( 'Duración', 'wakoo' ) ],
			'score'   => [ __( 'Nota', 'wakoo' ) ],
			'code'    => [ __( 'Código de verificación', 'wakoo' ) ],
			'print'   => [ __( 'Imprimir o guardar en PDF', 'wakoo' ) ],
			'login'   => [ __( 'Inicia sesión para ver tus certificados.', 'wakoo' ) ],
			'notyet'  => [ __( 'Aún no tienes el certificado de este curso: aprueba la evaluación final.', 'wakoo' ) ],
			'pick'    => [ __( 'Elige un curso desde «Mi aprendizaje».', 'wakoo' ) ],
			'valid'   => [ __( 'Certificado válido', 'wakoo' ) ],
			'invalid' => [ __( 'No encontramos ningún certificado con ese código.', 'wakoo' ) ],
			'check'   => [ __( 'Comprobar un código', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_c', [ 'label' => __( 'Certificado', 'wakoo' ) ] );
		$this->add_control( 'org', [ 'label' => __( 'Organización', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => get_bloginfo( 'name' ) ] );
		$this->add_control( 'logo', [ 'label' => __( 'Logo', 'wakoo' ), 'type' => Controls_Manager::MEDIA ] );
		$this->add_control( 'signer', [ 'label' => __( 'Firma (nombre)', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$this->add_control( 'signer_role', [ 'label' => __( 'Firma (cargo)', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$this->add_control( 'note', [ 'label' => __( 'Nota al pie', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 2 ] );
		$this->add_control( 'demo', [ 'label' => __( 'En el editor, mostrar un ejemplo', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();
		$this->texts_section();
		$this->style_section( '.wk-ac-cert__name' );
	}

	/** Course summary by key, preferring the page's language. */
	private static function by_key( $key ) {
		$lang = Module::lang();
		foreach ( [ $lang, '' ] as $l ) {
			foreach ( Module::courses( $l ) as $c ) {
				if ( $c['key'] === $key ) { return $c; }
			}
		}
		return null;
	}

	private function paper( $s, $name, $course, $rec, $code ) {
		$date = ! empty( $rec['ok'] ) ? wp_date( get_option( 'date_format' ), (int) $rec['ok'] ) : '';
		echo '<div class="wk-ac-cert__paper">';
		if ( ! empty( $s['logo']['url'] ) ) { echo '<img class="wk-ac-cert__logo" src="' . esc_url( $s['logo']['url'] ) . '" alt="' . esc_attr( $s['org'] ) . '">'; }
		echo '<p class="wk-ac-cert__k">' . esc_html( $this->word( $s, 'head' ) ) . '</p>';
		echo '<p>' . esc_html( $s['org'] . ' ' . $this->word( $s, 'grants' ) ) . '</p>';
		echo '<p class="wk-ac-cert__name">' . esc_html( $name ) . '</p>';
		echo '<p>' . esc_html( $this->word( $s, 'passed' ) ) . '</p>';
		echo '<p class="wk-ac-cert__course">' . esc_html( $course['title'] ?? '' ) . '</p>';
		if ( ! empty( $course['badge'] ) ) { echo '<p class="wk-ac-cert__badge">' . self::icon( 'cert' ) . esc_html( $course['badge'] ) . '</p>'; } // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<ul class="wk-ac-cert__meta">';
		if ( $date ) { echo '<li>' . esc_html( ucfirst( $this->word( $s, 'on' ) ) . ' ' . $date ) . '</li>'; }
		if ( ! empty( $course['hours'] ) || ! empty( $course['mins'] ) ) { echo '<li>' . esc_html( $this->word( $s, 'hours' ) . ': ' . ( ! empty( $course['hours'] ) ? $course['hours'] : self::hm( $course['mins'] ) ) ) . '</li>'; }
		if ( isset( $rec['s'] ) ) { echo '<li>' . esc_html( $this->word( $s, 'score' ) . ': ' . (int) $rec['s'] . '%' ) . '</li>'; }
		echo '</ul>';
		if ( $s['signer'] ) { echo '<p class="wk-ac-cert__sign"><span>' . esc_html( $s['signer'] ) . '</span>' . esc_html( $s['signer_role'] ) . '</p>'; }
		echo '<p class="wk-ac-cert__code">' . esc_html( $this->word( $s, 'code' ) ) . ': <b>' . esc_html( $code ) . '</b><br><small>' . esc_html( add_query_arg( 'codigo', $code, get_permalink() ) ) . '</small></p>';
		if ( $s['note'] ) { echo '<p class="wk-ac-cert__note">' . esc_html( $s['note'] ) . '</p>'; }
		echo '</div>';
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$edit = \Elementor\Plugin::$instance->editor->is_edit_mode();
		echo '<div class="wk-ac wk-ac-cert" data-wk-ac="cert">';
		$code = isset( $_GET['codigo'] ) ? sanitize_text_field( wp_unslash( $_GET['codigo'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$key  = isset( $_GET['curso'] ) ? sanitize_key( wp_unslash( $_GET['curso'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

		if ( $edit && 'yes' === $s['demo'] ) {
			$this->paper( $s, __( 'Nombre Apellido', 'wakoo' ), [ 'title' => __( 'Título del curso', 'wakoo' ), 'badge' => __( 'Insignia', 'wakoo' ), 'mins' => 30 ], [ 'ok' => time(), 's' => 90 ], 'ABCDE12345' );
		} elseif ( $code ) {
			$v = Module::verify( $code );
			if ( $v ) {
				echo '<p class="wk-ac-cert__ok">' . self::icon( 'check' ) . esc_html( $this->word( $s, 'valid' ) ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
				$this->paper( $s, $v[0], self::by_key( $v[1] ) ?: [ 'title' => $v[2]['t'] ?? $v[1] ], $v[2], strtoupper( $code ) );
			} else {
				echo '<p class="wk-ac-cert__ko">' . esc_html( $this->word( $s, 'invalid' ) ) . '</p>';
			}
		} elseif ( ! Module::learner() ) {
			echo '<p class="wk-ac-guest">' . esc_html( $this->word( $s, 'login' ) ) . '</p>';
		} elseif ( ! $key ) {
			echo '<p class="wk-ac-guest">' . esc_html( $this->word( $s, 'pick' ) ) . '</p>';
		} else {
			$who = Module::learner();
			$all = Module::load( $who );
			$rec = is_array( $all ) ? ( $all[ $key ] ?? null ) : null;
			if ( ! $rec || empty( $rec['ok'] ) ) {
				echo '<p class="wk-ac-guest">' . esc_html( $this->word( $s, 'notyet' ) ) . '</p>';
			} else {
				$this->paper( $s, $who['name'], self::by_key( $key ) ?: [ 'title' => $rec['t'] ?? $key ], $rec, $rec['c'] ?? Module::cert_code( $who['id'], $key ) );
				echo '<p class="wk-ac-cert__tools"><button type="button" class="wk-ac-btn" onclick="window.print()">' . esc_html( $this->word( $s, 'print' ) ) . '</button></p>';
			}
		}
		if ( ! $edit ) {
			echo '<form class="wk-ac-cert__check" method="get"><label>' . esc_html( $this->word( $s, 'check' ) ) . ' <input name="codigo" maxlength="12" pattern="[A-Za-z0-9]{10}" required></label> <button type="submit" class="wk-ac-btn is-ghost">OK</button></form>';
		}
		echo '</div>';
	}
}
