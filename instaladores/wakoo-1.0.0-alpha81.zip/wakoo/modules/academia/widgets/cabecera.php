<?php
/**
 * Cabecera del curso: turns the page into a course (key, category, level,
 * card image) and shows its title, stats, progress and the start button.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Academia\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Cabecera extends Base {

	public function get_name() { return 'wakoo-ac-cabecera'; }
	public function get_title() { return __( 'Cabecera del curso', 'wakoo' ); }
	public function get_icon() { return 'eicon-header'; }
	public function get_keywords() { return [ 'curso', 'academia', 'course', 'cabecera', 'lms', 'wakoo' ]; }

	protected function words() {
		return [
			'start'    => [ __( 'Empezar el curso', 'wakoo' ), __( 'Botón al empezar', 'wakoo' ) ],
			'continue' => [ __( 'Continuar', 'wakoo' ), __( 'Botón a medias', 'wakoo' ) ],
			'review'   => [ __( 'Repasar el curso', 'wakoo' ), __( 'Botón al terminar', 'wakoo' ) ],
			'lessons'  => [ __( 'lecciones', 'wakoo' ), __( 'Palabra «lecciones»', 'wakoo' ) ],
			'quiz'     => [ __( 'evaluación final', 'wakoo' ), __( 'Palabra «evaluación»', 'wakoo' ) ],
			'by'       => [ __( 'Con', 'wakoo' ), __( 'Antes del nombre de quien enseña', 'wakoo' ) ],
			'badge'    => [ __( 'Insignia al aprobar:', 'wakoo' ), __( 'Antes del nombre de la insignia', 'wakoo' ) ],
			'progress' => [ __( 'Tu progreso', 'wakoo' ), __( 'Barra de progreso', 'wakoo' ) ],
			'trailer'  => [ __( 'Ver presentación', 'wakoo' ), __( 'Botón del vídeo de presentación', 'wakoo' ) ],
			'guide'    => [ __( 'Guía del curso (PDF)', 'wakoo' ), __( 'Botón de la guía en PDF', 'wakoo' ) ],
			'guide_t'  => [ __( 'Guía del curso', 'wakoo' ), __( 'Guía PDF: título de la portada', 'wakoo' ) ],
			'contents' => [ __( 'Contenido', 'wakoo' ), __( 'Guía PDF: índice', 'wakoo' ) ],
			'hours'    => [ __( 'Duración', 'wakoo' ), __( 'Palabra «duración»', 'wakoo' ) ],
			'level'    => [ __( 'Nivel', 'wakoo' ), __( 'Guía PDF: palabra «nivel»', 'wakoo' ) ],
			'guide_q'  => [ __( 'Haga la evaluación final en línea para recibir su certificado con código de verificación:', 'wakoo' ), __( 'Guía PDF: aviso de la evaluación', 'wakoo' ) ],
			'page'     => [ __( 'Página %1$d de %2$d', 'wakoo' ), __( 'Guía PDF: número de página', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_course', [ 'label' => __( 'Curso', 'wakoo' ) ] );
		$this->add_control( 'help', [
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => __( 'Esta cabecera convierte la página en un curso: aparece en el Catálogo y en Mi aprendizaje. Añade debajo el Temario, el Aula y la Evaluación.', 'wakoo' ),
			'content_classes' => 'elementor-descriptor',
		] );
		$this->add_control( 'clave', [
			'label'       => __( 'Clave del curso', 'wakoo' ),
			'type'        => Controls_Manager::TEXT,
			'description' => __( 'Igual en todos los idiomas del curso (p. ej. «respirar»): el progreso se comparte entre idiomas.', 'wakoo' ),
		] );
		$this->add_control( 'titulo', [ 'label' => __( 'Título', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'label_block' => true, 'description' => __( 'Vacío = título de la página.', 'wakoo' ) ] );
		$this->add_control( 'lema', [ 'label' => __( 'Frase corta', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 2 ] );
		$this->add_control( 'cat', [ 'label' => __( 'Categoría', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'description' => __( 'Se usa para los filtros del catálogo.', 'wakoo' ) ] );
		$this->add_control( 'nivel', [ 'label' => __( 'Nivel', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Para empezar', 'wakoo' ) ] );
		$this->add_control( 'autora', [ 'label' => __( 'Quién enseña', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$this->add_control( 'insignia', [ 'label' => __( 'Insignia o certificado', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$this->add_control( 'img', [ 'label' => __( 'Imagen (tarjeta y fondo)', 'wakoo' ), 'type' => Controls_Manager::MEDIA ] );
		$this->add_control( 'trailer', [ 'label' => __( 'Vídeo de presentación (YouTube, Vimeo o mp4)', 'wakoo' ), 'type' => Controls_Manager::URL, 'options' => false ] );
		$this->add_control( 'horas', [ 'label' => __( 'Duración total (texto, p. ej. «12 horas»)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'description' => __( 'Vacío = la suma de las duraciones de las lecciones.', 'wakoo' ) ] );
		$this->add_control( 'guia', [ 'label' => __( 'Guía del curso en PDF', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'description' => __( 'Botón que descarga el curso completo (lecciones y prácticas, sin las respuestas de la evaluación) para estudiar sin conexión.', 'wakoo' ) ] );
		$this->add_control( 'guia_nota', [ 'label' => __( 'Nota al pie de la guía', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 2, 'condition' => [ 'guia' => 'yes' ] ] );
		$this->add_control( 'orden', [ 'label' => __( 'Orden en el catálogo', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 0 ] );
		$this->add_control( 'target', [ 'label' => __( 'El botón lleva a', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '#aula', 'description' => __( 'Ancla del Aula (su ID CSS).', 'wakoo' ) ] );
		$this->add_control( 'layout', [
			'label'   => __( 'Diseño', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'split',
			'options' => [ 'split' => __( 'Imagen al lado', 'wakoo' ), 'cover' => __( 'Imagen de fondo', 'wakoo' ) ],
		] );
		$this->end_controls_section();
		$this->texts_section();
		$this->style_section();
	}

	protected function render() {
		$s  = $this->get_settings_for_display();
		$c  = $this->course();
		$n  = $c ? count( $c['lessons'] ) : 0;
		$q  = $c ? (int) $c['quiz'] : 0;
		$ti = $s['titulo'] ?: get_the_title();
		$im = $s['img']['url'] ?? '';
		$tr = $s['trailer']['url'] ?? '';
		$ly = 'cover' === $s['layout'] ? 'cover' : 'split';
		$data = [
			'key'      => $c['key'] ?? ( sanitize_key( $s['clave'] ) ?: 'p' . get_the_ID() ),
			'n'        => $n,
			'target'   => $s['target'] ?: '#aula',
		];
		echo '<header class="wk-ac wk-ac-head is-' . esc_attr( $ly ) . '" data-wk-ac="head" data-cfg="' . esc_attr( wp_json_encode( $data ) ) . '" data-words="' . esc_attr( $this->words_json( $s ) ) . '"';
		if ( 'cover' === $ly && $im ) { echo ' style="--wk-ac-bg:url(' . esc_url( $im ) . ')"'; }
		echo '><div class="wk-ac-head__txt">';
		if ( $s['cat'] ) { echo '<span class="wk-ac-chip">' . esc_html( $s['cat'] ) . '</span>'; }
		echo '<h1 class="wk-ac-title">' . esc_html( $ti ) . '</h1>';
		if ( $s['lema'] ) { echo '<p class="wk-ac-head__lema">' . esc_html( $s['lema'] ) . '</p>'; }
		echo '<ul class="wk-ac-stats">';
		if ( $s['autora'] ) { echo '<li>' . self::icon( 'user' ) . esc_html( $this->word( $s, 'by' ) . ' ' . $s['autora'] ) . '</li>'; } // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $n ) { echo '<li>' . self::icon( 'list' ) . esc_html( $n . ' ' . $this->word( $s, 'lessons' ) ) . '</li>'; } // phpcs:ignore WordPress.Security.EscapeOutput
		if ( ! empty( $s['horas'] ) ) {
			echo '<li>' . self::icon( 'clock' ) . esc_html( $s['horas'] ) . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput
		} elseif ( $c && $c['mins'] ) {
			echo '<li>' . self::icon( 'clock' ) . esc_html( self::hm( $c['mins'] ) ) . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		if ( $q ) { echo '<li>' . self::icon( 'star' ) . esc_html( $this->word( $s, 'quiz' ) ) . '</li>'; } // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $s['nivel'] ) { echo '<li>' . self::icon( 'level' ) . esc_html( $s['nivel'] ) . '</li>'; } // phpcs:ignore WordPress.Security.EscapeOutput
		echo '</ul>';
		if ( $s['insignia'] ) { echo '<p class="wk-ac-head__badge">' . self::icon( 'cert' ) . '<span>' . esc_html( $this->word( $s, 'badge' ) ) . ' <strong>' . esc_html( $s['insignia'] ) . '</strong></span></p>'; } // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<div class="wk-ac-bar" hidden><span class="wk-ac-bar__lbl">' . esc_html( $this->word( $s, 'progress' ) ) . ' <b>0%</b></span><span class="wk-ac-bar__track"><i style="width:0"></i></span></div>';
		echo '<div class="wk-ac-head__cta"><a class="wk-ac-btn" href="' . esc_attr( $data['target'] ) . '">' . self::icon( 'play' ) . '<span>' . esc_html( $this->word( $s, 'start' ) ) . '</span></a>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $tr ) { echo '<button type="button" class="wk-ac-btn is-ghost" data-trailer="' . esc_attr( esc_url( $tr ) ) . '">' . esc_html( $this->word( $s, 'trailer' ) ) . '</button>'; }
		if ( 'yes' === ( $s['guia'] ?? '' ) && get_the_ID() ) { echo '<a class="wk-ac-btn is-ghost" href="' . esc_url( \Wakoo\Modules\Academia\Guide::url( get_the_ID() ) ) . '" download rel="nofollow">' . self::icon( 'doc' ) . '<span>' . esc_html( $this->word( $s, 'guide' ) ) . '</span></a>'; } // phpcs:ignore WordPress.Security.EscapeOutput
		echo '</div></div>';
		if ( 'split' === $ly && $im ) {
			echo '<figure class="wk-ac-head__img"><img src="' . esc_url( $im ) . '" alt="" loading="eager"></figure>';
		}
		echo '</header>';
	}
}
