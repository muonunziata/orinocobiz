<?php
/**
 * Catálogo de cursos: every course of the page's language as cards, with a
 * search box, category chips, level filter and each person's progress.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Academia\Widgets;

use Elementor\Controls_Manager;
use Wakoo\Modules\Academia\Module;

defined( 'ABSPATH' ) || die();

class Catalogo extends Base {

	public function get_name() { return 'wakoo-ac-catalogo'; }
	public function get_title() { return __( 'Catálogo de cursos', 'wakoo' ); }
	public function get_icon() { return 'eicon-posts-grid'; }
	public function get_keywords() { return [ 'cursos', 'catalogo', 'academia', 'courses', 'lms', 'wakoo' ]; }

	protected function words() {
		return [
			'search'  => [ __( 'Busca un curso…', 'wakoo' ), __( 'Buscador', 'wakoo' ) ],
			'all'     => [ __( 'Todos', 'wakoo' ), __( 'Chip «todos»', 'wakoo' ) ],
			'levels'  => [ __( 'Todos los niveles', 'wakoo' ) ],
			'lessons' => [ __( 'lecciones', 'wakoo' ) ],
			'start'   => [ __( 'Ver curso', 'wakoo' ), __( 'Botón de la tarjeta', 'wakoo' ) ],
			'going'   => [ __( 'Continuar', 'wakoo' ), __( 'Botón a medias', 'wakoo' ) ],
			'done'    => [ __( 'Completado', 'wakoo' ), __( 'Etiqueta de curso aprobado', 'wakoo' ) ],
			'none'    => [ __( 'No hay cursos con ese filtro.', 'wakoo' ), __( 'Sin resultados', 'wakoo' ) ],
			'badge'   => [ __( 'Insignia', 'wakoo' ) ],
			'soon'    => [ __( 'Vídeos en preparación', 'wakoo' ), __( 'Etiqueta de curso sin vídeos', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_cat', [ 'label' => __( 'Catálogo', 'wakoo' ) ] );
		$this->add_control( 'help', [
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => __( 'Muestra las páginas publicadas que tienen el widget «Cabecera del curso», en el idioma de esta página.', 'wakoo' ),
			'content_classes' => 'elementor-descriptor',
		] );
		$this->add_control( 'filters', [ 'label' => __( 'Buscador y filtros', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'only_cat', [ 'label' => __( 'Solo esta categoría', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'description' => __( 'Vacío = todas.', 'wakoo' ) ] );
		$this->add_control( 'limit', [ 'label' => __( 'Máximo de cursos (0 = todos)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 0, 'min' => 0 ] );
		$this->add_control( 'exclude_self', [ 'label' => __( 'Ocultar el curso de esta página', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_responsive_control( 'cols', [
			'label'     => __( 'Columnas', 'wakoo' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => '3',
			'tablet_default' => '2',
			'mobile_default' => '1',
			'options'   => [ '1' => '1', '2' => '2', '3' => '3', '4' => '4' ],
			'selectors' => [ '{{WRAPPER}} .wk-ac-grid' => '--wk-ac-cols: {{VALUE}};' ],
		] );
		$this->end_controls_section();
		$this->texts_section();
		$this->style_section( '.wk-ac-card__t' );
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$self = get_the_ID();
		$list = array_values( array_filter( Module::courses( Module::lang() ), function ( $c ) use ( $s, $self ) {
			if ( 'yes' === $s['exclude_self'] && (int) $c['id'] === (int) $self ) { return false; }
			return ! $s['only_cat'] || 0 === strcasecmp( trim( $s['only_cat'] ), trim( $c['cat'] ) );
		} ) );
		if ( (int) $s['limit'] > 0 ) { $list = array_slice( $list, 0, (int) $s['limit'] ); }
		if ( ! $list ) {
			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				echo '<p class="wk-ac-empty">' . esc_html__( 'Aún no hay cursos publicados. Crea una página con la «Cabecera del curso».', 'wakoo' ) . '</p>';
			}
			return;
		}
		$cats   = array_values( array_unique( array_filter( wp_list_pluck( $list, 'cat' ) ) ) );
		$levels = array_values( array_unique( array_filter( wp_list_pluck( $list, 'level' ) ) ) );
		echo '<div class="wk-ac wk-ac-cat" data-wk-ac="catalog" data-words="' . esc_attr( $this->words_json( $s ) ) . '">';
		if ( 'yes' === $s['filters'] ) {
			echo '<div class="wk-ac-filters"><input type="search" class="wk-ac-search" placeholder="' . esc_attr( $this->word( $s, 'search' ) ) . '" aria-label="' . esc_attr( $this->word( $s, 'search' ) ) . '">';
			if ( count( $levels ) > 1 ) {
				echo '<select class="wk-ac-level" aria-label="' . esc_attr( $this->word( $s, 'levels' ) ) . '"><option value="">' . esc_html( $this->word( $s, 'levels' ) ) . '</option>';
				foreach ( $levels as $l ) { echo '<option>' . esc_html( $l ) . '</option>'; }
				echo '</select>';
			}
			if ( count( $cats ) > 1 ) {
				echo '<div class="wk-ac-chips" role="group"><button type="button" class="wk-ac-chip is-on" data-cat="" aria-pressed="true">' . esc_html( $this->word( $s, 'all' ) ) . '</button>';
				foreach ( $cats as $c ) { echo '<button type="button" class="wk-ac-chip" data-cat="' . esc_attr( $c ) . '" aria-pressed="false">' . esc_html( $c ) . '</button>'; }
				echo '</div>';
			}
			echo '</div>';
		}
		echo '<div class="wk-ac-grid">';
		foreach ( $list as $c ) {
			$n      = count( $c['lessons'] );
			$videos = count( array_filter( wp_list_pluck( $c['lessons'], 2 ) ) );
			echo '<article class="wk-ac-card" data-key="' . esc_attr( $c['key'] ) . '" data-n="' . (int) $n . '" data-cat="' . esc_attr( $c['cat'] ) . '" data-level="' . esc_attr( $c['level'] ) . '" data-q="' . esc_attr( strtolower( remove_accents( $c['title'] . ' ' . $c['tagline'] . ' ' . $c['cat'] . ' ' . $c['author'] ) ) ) . '">';
			echo '<a class="wk-ac-card__img" href="' . esc_url( $c['url'] ) . '" tabindex="-1" aria-hidden="true">';
			if ( $c['img'] ) { echo '<img src="' . esc_url( $c['img'] ) . '" alt="" loading="lazy">'; }
			if ( $n && ! $videos ) { echo '<span class="wk-ac-card__soon">' . esc_html( $this->word( $s, 'soon' ) ) . '</span>'; }
			echo '<span class="wk-ac-card__done" hidden>' . self::icon( 'check' ) . esc_html( $this->word( $s, 'done' ) ) . '</span></a>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<div class="wk-ac-card__body">';
			if ( $c['cat'] ) { echo '<span class="wk-ac-chip is-small">' . esc_html( $c['cat'] ) . '</span>'; }
			echo '<h3 class="wk-ac-card__t"><a href="' . esc_url( $c['url'] ) . '">' . esc_html( $c['title'] ) . '</a></h3>';
			if ( $c['tagline'] ) { echo '<p class="wk-ac-card__lema">' . esc_html( $c['tagline'] ) . '</p>'; }
			echo '<ul class="wk-ac-stats is-small">';
			if ( $n ) { echo '<li>' . self::icon( 'list' ) . esc_html( $n . ' ' . $this->word( $s, 'lessons' ) ) . '</li>'; } // phpcs:ignore WordPress.Security.EscapeOutput
			if ( ! empty( $c['hours'] ) || $c['mins'] ) { echo '<li>' . self::icon( 'clock' ) . esc_html( ! empty( $c['hours'] ) ? $c['hours'] : self::hm( $c['mins'] ) ) . '</li>'; } // phpcs:ignore WordPress.Security.EscapeOutput
			if ( $c['level'] ) { echo '<li>' . self::icon( 'level' ) . esc_html( $c['level'] ) . '</li>'; } // phpcs:ignore WordPress.Security.EscapeOutput
			echo '</ul>';
			if ( $c['badge'] ) { echo '<p class="wk-ac-card__badge">' . self::icon( 'cert' ) . esc_html( $this->word( $s, 'badge' ) . ': ' . $c['badge'] ) . '</p>'; } // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<div class="wk-ac-bar" hidden><span class="wk-ac-bar__track"><i style="width:0"></i></span><b>0%</b></div>';
			echo '<a class="wk-ac-btn is-ghost wk-ac-card__go" href="' . esc_url( $c['url'] ) . '">' . esc_html( $this->word( $s, 'start' ) ) . '</a>';
			echo '</div></article>';
		}
		echo '</div><p class="wk-ac-empty" hidden>' . esc_html( $this->word( $s, 'none' ) ) . '</p></div>';
	}
}
