<?php
/**
 * Company photo gallery: public images attached to a directory profile, each with its credit.
 * Three ways in: the owner uploads them from «Mi empresa», the team picks them from the media
 * library, or the team lists Wikimedia Commons files and Wakoo downloads them with their author
 * and licence (on save, and in the background after a pack import).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

defined( 'ABSPATH' ) || die();

class Photos {

	const MAX   = 12;          // Photos per company.
	const BYTES = 5242880;     // 5 MB per upload.
	const TYPES = [ 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ];
	const HOOK  = 'wakoo_t_fetch_photos';

	public static function init() {
		add_action( self::HOOK, [ __CLASS__, 'fetch' ] );
		// Gallery IDs belong to this site's media library; a pack carries only «photo_src» and the next site downloads again.
		add_filter( 'wakoo_portable_skip_meta', function ( $k ) { return array_merge( (array) $k, [ Module::PRE . 'gallery', Module::PRE . 'photo_done', Module::PRE . 'photo_try' ] ); } );
		add_action( 'added_post_meta', [ __CLASS__, 'queue' ], 10, 4 );
		add_action( 'updated_post_meta', [ __CLASS__, 'queue' ], 10, 4 );
		add_action( 'admin_post_wakoo_t_company_photo', [ __CLASS__, 'upload' ] );
		add_action( 'admin_post_wakoo_t_company_photo_del', [ __CLASS__, 'remove' ] );
		add_action( 'admin_post_wakoo_t_hub_photos', [ __CLASS__, 'fetch_all' ] );
		foreach ( [ 'company_photo', 'company_photo_del' ] as $a ) { add_action( 'admin_post_nopriv_wakoo_t_' . $a, [ Forms::class, 'need_login' ] ); }
		if ( is_admin() ) {
			add_action( 'add_meta_boxes', [ __CLASS__, 'box_add' ] );
			add_action( 'save_post_' . Module::COMPANY, [ __CLASS__, 'box_save' ], 20, 2 );
		}
	}

	/* ---------------------------------------------------------------- reading */

	/** Image attachment IDs of the gallery, in order. */
	public static function ids( $company_id ) {
		$ids = array_filter( array_map( 'absint', explode( ',', (string) Module::meta( $company_id, 'gallery' ) ) ) );
		return array_values( array_filter( $ids, 'wp_attachment_is_image' ) );
	}

	/** Credit of one photo: [ author, licence, licence URL, source URL ]. */
	public static function credit( $att_id ) {
		$c = get_post_meta( $att_id, Module::PRE . 'credit', true );
		return is_array( $c ) ? array_merge( [ 'author' => '', 'license' => '', 'license_url' => '', 'source' => '' ], $c ) : [ 'author' => '', 'license' => '', 'license_url' => '', 'source' => '' ];
	}

	/** One-line credit as plain text («Foto: autor · licencia»). */
	public static function credit_text( $att_id ) {
		$c = self::credit( $att_id );
		$p = array_filter( [ $c['author'], $c['license'] ] );
		return $p ? sprintf( __( 'Foto: %s', 'wakoo' ), implode( ' · ', $p ) ) : '';
	}

	private static function set_ids( $company_id, $ids ) {
		$ids = array_slice( array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) ), 0, self::MAX );
		update_post_meta( $company_id, Module::PRE . 'gallery', implode( ',', $ids ) );
	}

	/* ---------------------------------------------------------------- Wikimedia Commons */

	/** Commons file title from a file page or upload URL, or ''. Only Commons is accepted: its files always carry a free licence. */
	public static function commons_title( $url ) {
		$url = trim( (string) $url );
		if ( preg_match( '#^https://commons\.wikimedia\.org/wiki/(File:[^?\#]+)#i', $url, $m ) ) { return str_replace( '_', ' ', rawurldecode( $m[1] ) ); }
		if ( preg_match( '#^https://upload\.wikimedia\.org/wikipedia/commons/(?:thumb/)?[0-9a-f]/[0-9a-f]{2}/([^/?\#]+)#i', $url, $m ) ) { return 'File:' . str_replace( '_', ' ', rawurldecode( $m[1] ) ); }
		return '';
	}

	/** A change of the «photo_src» list schedules the download, so imports and saves stay fast. */
	public static function queue( $meta_id, $post_id, $key, $value ) {
		if ( Module::PRE . 'photo_src' !== $key || '' === trim( (string) $value ) ) { return; }
		delete_post_meta( $post_id, Module::PRE . 'photo_try' );
		if ( ! wp_next_scheduled( self::HOOK, [ (int) $post_id ] ) ) { wp_schedule_single_event( time() + 10, self::HOOK, [ (int) $post_id ] ); }
	}

	/**
	 * Downloads the Commons files listed in «photo_src» that are not in the gallery yet. The author,
	 * licence and file page come from the Commons API; a file without them is skipped.
	 * Returns [ added, failed ].
	 */
	public static function fetch( $company_id ) {
		$company_id = (int) $company_id;
		if ( Module::COMPANY !== get_post_type( $company_id ) ) { return [ 0, 0 ]; }
		$done  = get_post_meta( $company_id, Module::PRE . 'photo_done', true );
		$done  = is_array( $done ) ? $done : [];
		$ids   = self::ids( $company_id );
		$added = 0;
		$fail  = 0;
		foreach ( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) Module::meta( $company_id, 'photo_src' ) ) ) ) as $src ) {
			$title = self::commons_title( $src );
			if ( '' === $title || isset( $done[ $title ] ) || count( $ids ) >= self::MAX ) { continue; }
			$att = self::from_commons( $title, $company_id );
			if ( is_wp_error( $att ) ) {
				$fail++;
				update_option( 'wakoo_t_photo_err', sprintf( '%1$s: %2$s', $title, $att->get_error_message() ), false );
				Store::log( Module::COMPANY, $company_id, 'photo', sprintf( 'Foto no descargada (%1$s): %2$s', $title, $att->get_error_message() ), 'internal' );
				continue;
			}
			$done[ $title ] = $att;
			$ids[]          = $att;
			$added++;
		}
		update_post_meta( $company_id, Module::PRE . 'photo_done', $done );
		if ( $added ) {
			self::set_ids( $company_id, $ids );
			Store::log( Module::COMPANY, $company_id, 'photo', sprintf( 'Fotos añadidas desde Wikimedia Commons: %d', $added ), 'internal' );
		}
		// A site without access to Commons at that moment tries again later (three times at most).
		$try = (int) get_post_meta( $company_id, Module::PRE . 'photo_try', true );
		if ( $fail && $try < 3 && ! wp_next_scheduled( self::HOOK, [ $company_id ] ) ) {
			update_post_meta( $company_id, Module::PRE . 'photo_try', $try + 1 );
			wp_schedule_single_event( time() + HOUR_IN_SECONDS * ( $try + 1 ), self::HOOK, [ $company_id ] );
		} elseif ( ! $fail ) {
			delete_post_meta( $company_id, Module::PRE . 'photo_try' );
		}
		return [ $added, $fail ];
	}

	/** Companies with Commons files still to download. */
	public static function pending() {
		$out = [];
		foreach ( get_posts( [ 'post_type' => Module::COMPANY, 'post_status' => 'any', 'numberposts' => 300, 'meta_key' => Module::PRE . 'photo_src', 'fields' => 'ids' ] ) as $id ) { // phpcs:ignore WordPress.DB.SlowDBQuery
			$done = get_post_meta( $id, Module::PRE . 'photo_done', true );
			$done = is_array( $done ) ? $done : [];
			foreach ( preg_split( '/\r\n|\r|\n/', (string) Module::meta( $id, 'photo_src' ) ) as $src ) {
				$t = self::commons_title( $src );
				if ( $t && ! isset( $done[ $t ] ) && count( self::ids( $id ) ) < self::MAX ) { $out[] = (int) $id; break; }
			}
		}
		return $out;
	}

	/** Hub button «Descargar fotos ahora»: runs the download right away instead of waiting for WP-Cron. */
	public static function fetch_all() {
		if ( ! isset( $_POST['_wkt'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wkt'] ) ), 'wakoo_t_hub_photos' ) ) { Forms::back( 'expired' ); }
		if ( ! current_user_can( 'edit_others_posts' ) ) { Forms::back( 'denied' ); }
		delete_option( 'wakoo_t_photo_err' );
		$added = 0;
		$fail  = 0;
		foreach ( self::pending() as $id ) {
			list( $a, $f ) = self::fetch( $id );
			$added += $a;
			$fail  += $f;
		}
		Forms::back( $fail ? 'photos_ko' : 'photos_ok' );
	}

	private static function from_commons( $title, $company_id ) {
		$api = apply_filters( 'wakoo_t_commons_api', 'https://commons.wikimedia.org/w/api.php' );
		$res = wp_remote_get( add_query_arg( [ 'action' => 'query', 'format' => 'json', 'titles' => $title, 'prop' => 'imageinfo', 'iiprop' => 'url|mime|extmetadata', 'iiurlwidth' => 1600 ], $api ), [ 'timeout' => 20, 'user-agent' => 'Wakoo/' . ( defined( 'WAKOO_VERSION' ) ? WAKOO_VERSION : '1' ) . ' (WordPress; ' . home_url() . ')' ] );
		if ( is_wp_error( $res ) ) { return $res; }
		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		$page = is_array( $data['query']['pages'] ?? null ) ? reset( $data['query']['pages'] ) : null;
		$info = $page['imageinfo'][0] ?? null;
		if ( ! $info || ! in_array( $info['mime'] ?? '', self::TYPES, true ) ) { return new \WP_Error( 'wkt_commons', __( 'El archivo no existe o no es una foto.', 'wakoo' ) ); }
		$md      = $info['extmetadata'] ?? [];
		$author  = trim( wp_strip_all_tags( html_entity_decode( (string) ( $md['Artist']['value'] ?? '' ) ) ) );
		$license = trim( wp_strip_all_tags( (string) ( $md['LicenseShortName']['value'] ?? '' ) ) );
		if ( '' === $license ) { return new \WP_Error( 'wkt_commons', __( 'Commons no indica la licencia.', 'wakoo' ) ); }
		$file = (string) ( $info['thumburl'] ?? $info['url'] ?? '' );
		if ( ! preg_match( '#^https://upload\.wikimedia\.org/#', $file ) && ! apply_filters( 'wakoo_t_commons_any_host', false ) ) { return new \WP_Error( 'wkt_commons', 'host' ); }
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$tmp = download_url( $file, 60 );
		if ( is_wp_error( $tmp ) ) { return $tmp; }
		$name = sanitize_file_name( preg_replace( '/^File:/i', '', $title ) );
		$att  = media_handle_sideload( [ 'name' => $name, 'tmp_name' => $tmp ], $company_id, get_the_title( $company_id ) );
		if ( is_wp_error( $att ) ) { @unlink( $tmp ); return $att; } // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
		$credit = [ 'author' => mb_substr( $author ?: __( 'Autor indicado en Wikimedia Commons', 'wakoo' ), 0, 160 ), 'license' => $license, 'license_url' => esc_url_raw( (string) ( $md['LicenseUrl']['value'] ?? '' ) ), 'source' => esc_url_raw( (string) ( $info['descriptionurl'] ?? '' ) ) ];
		update_post_meta( $att, Module::PRE . 'credit', $credit );
		// The Commons file name describes the photo better than the company name («Represa de Guri…»).
		$alt = trim( preg_replace( '/\s+\d*$/', '', preg_replace( '/\.[a-z0-9]+$/i', '', preg_replace( '/^File:/i', '', $title ) ) ) );
		update_post_meta( $att, '_wp_attachment_image_alt', $alt ?: get_the_title( $company_id ) );
		wp_update_post( [ 'ID' => $att, 'post_title' => $alt ?: get_the_title( $company_id ), 'post_excerpt' => self::credit_text( $att ) ] );
		return (int) $att;
	}

	/* ---------------------------------------------------------------- owner uploads («Mi empresa») */

	private static function owner_company() {
		$c = Forms::my_company();
		if ( ! $c ) { Forms::back( 'nocompany' ); }
		return $c;
	}

	public static function upload() {
		if ( ! isset( $_POST['_wkt'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wkt'] ) ), 'wakoo_t_company_photo' ) ) { Forms::back( 'expired' ); }
		$c = self::owner_company();
		if ( ! Module::rate( 'photo', 30 ) ) { Forms::back( 'limit' ); }
		if ( empty( $_POST['rights'] ) ) { Forms::back( 'rights' ); }
		if ( empty( $_FILES['photos']['name'] ) ) { Forms::back( 'invalid' ); }
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$ids    = self::ids( $c->ID );
		$author = Forms::txt( 'author', 120 );
		$f      = $_FILES['photos']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$n      = is_array( $f['name'] ) ? count( $f['name'] ) : 1;
		$ok     = true;
		for ( $i = 0; $i < $n && count( $ids ) < self::MAX; $i++ ) {
			$one = is_array( $f['name'] ) ? [ 'name' => $f['name'][ $i ], 'type' => $f['type'][ $i ], 'tmp_name' => $f['tmp_name'][ $i ], 'error' => $f['error'][ $i ], 'size' => $f['size'][ $i ] ] : $f;
			if ( '' === (string) $one['name'] ) { continue; }
			$chk = wp_check_filetype_and_ext( $one['tmp_name'], $one['name'], self::TYPES );
			if ( UPLOAD_ERR_OK !== (int) $one['error'] || (int) $one['size'] > self::BYTES || empty( $chk['type'] ) || ! @getimagesize( $one['tmp_name'] ) ) { $ok = false; continue; } // phpcs:ignore WordPress.PHP.NoSilencedErrors
			$_FILES['wkt_one'] = $one;
			$att = media_handle_upload( 'wkt_one', $c->ID, [ 'post_title' => $c->post_title ], [ 'test_form' => false, 'mimes' => self::TYPES ] );
			if ( is_wp_error( $att ) ) { $ok = false; continue; }
			update_post_meta( $att, Module::PRE . 'credit', [ 'author' => $author ?: $c->post_title, 'license' => __( 'Publicada por la empresa', 'wakoo' ), 'license_url' => '', 'source' => '' ] );
			update_post_meta( $att, '_wp_attachment_image_alt', $c->post_title );
			wp_update_post( [ 'ID' => $att, 'post_excerpt' => self::credit_text( $att ) ] );
			$ids[] = (int) $att;
		}
		self::set_ids( $c->ID, $ids );
		Store::log( Module::COMPANY, $c->ID, 'photo', 'Fotos de la galería actualizadas por su titular', 'internal' );
		Forms::back( $ok ? 'photo_ok' : 'file' );
	}

	public static function remove() {
		if ( ! isset( $_POST['_wkt'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wkt'] ) ), 'wakoo_t_company_photo_del' ) ) { Forms::back( 'expired' ); }
		$c   = self::owner_company();
		$att = isset( $_POST['photo'] ) ? absint( $_POST['photo'] ) : 0;
		$ids = self::ids( $c->ID );
		if ( ! in_array( $att, $ids, true ) ) { Forms::back( 'denied' ); }
		self::set_ids( $c->ID, array_diff( $ids, [ $att ] ) );
		// The file itself is deleted only if this company owns it (uploaded or downloaded for it).
		if ( (int) wp_get_post_parent_id( $att ) === (int) $c->ID ) { wp_delete_attachment( $att, true ); }
		Forms::back( 'photo_del' );
	}

	/* ---------------------------------------------------------------- team: edit screen */

	public static function box_add() {
		add_meta_box( 'wkt_photos', __( 'Fotos de la empresa', 'wakoo' ), [ __CLASS__, 'box' ], Module::COMPANY, 'normal', 'default' );
	}

	public static function box( $post ) {
		wp_enqueue_media();
		$ids = self::ids( $post->ID );
		echo '<div class="wkt-photos-box"><input type="hidden" name="wkt_gallery" id="wkt_gallery" value="' . esc_attr( implode( ',', $ids ) ) . '">';
		echo '<ul class="wkt-photos-box__list" id="wkt_gallery_list">';
		foreach ( $ids as $id ) {
			$cr = self::credit_text( $id );
			echo '<li data-id="' . (int) $id . '">' . wp_get_attachment_image( $id, 'thumbnail' ) . '<small>' . esc_html( $cr ?: __( 'Sin crédito', 'wakoo' ) ) . '</small><button type="button" class="button-link wkt-photos-box__rm">' . esc_html__( 'Quitar', 'wakoo' ) . '</button></li>';
		}
		echo '</ul><p><button type="button" class="button" id="wkt_gallery_add">' . esc_html__( 'Elegir fotos de la biblioteca', 'wakoo' ) . '</button></p>';
		echo '<p><label for="wkt_photo_src"><strong>' . esc_html__( 'Fotos de Wikimedia Commons (una dirección por línea)', 'wakoo' ) . '</strong></label><br><textarea id="wkt_photo_src" name="wkt_photo_src" rows="3" class="large-text">' . esc_textarea( (string) Module::meta( $post->ID, 'photo_src' ) ) . '</textarea></p>';
		echo '<p class="description">' . esc_html__( 'Pegue la página del archivo (https://commons.wikimedia.org/wiki/File:…). Al guardar, Wakoo la descarga con su autor y su licencia, que se muestran bajo la galería. No publique fotos sin permiso ni fotos de otro lugar o empresa.', 'wakoo' ) . '</p></div>';
		?>
		<style>.wkt-photos-box__list{display:flex;flex-wrap:wrap;gap:10px;margin:0}.wkt-photos-box__list li{width:150px;margin:0}.wkt-photos-box__list img{display:block;width:150px;height:100px;object-fit:cover}.wkt-photos-box__list small{display:block;font-size:11px;line-height:1.3;margin:4px 0}</style>
		<script>
		( function () {
			var input = document.getElementById( 'wkt_gallery' ), list = document.getElementById( 'wkt_gallery_list' );
			function sync() { input.value = Array.prototype.map.call( list.children, function ( li ) { return li.getAttribute( 'data-id' ); } ).join( ',' ); }
			list.addEventListener( 'click', function ( e ) { if ( e.target.classList.contains( 'wkt-photos-box__rm' ) ) { e.target.parentNode.remove(); sync(); } } );
			document.getElementById( 'wkt_gallery_add' ).addEventListener( 'click', function () {
				var frame = wp.media( { title: <?php echo wp_json_encode( __( 'Fotos de la empresa', 'wakoo' ) ); ?>, multiple: 'add', library: { type: 'image' } } );
				frame.on( 'select', function () {
					frame.state().get( 'selection' ).each( function ( a ) {
						var li = document.createElement( 'li' ), img = document.createElement( 'img' ), s = a.get( 'sizes' );
						li.setAttribute( 'data-id', a.id ); img.src = ( s && s.thumbnail ? s.thumbnail.url : a.get( 'url' ) ); li.appendChild( img ); list.appendChild( li );
					} );
					sync();
				} );
				frame.open();
			} );
		} )();
		</script>
		<?php
	}

	public static function box_save( $id, $post ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
		if ( ! isset( $_POST['_wkt_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wkt_nonce'] ) ), 'wkt_save_' . $id ) ) { return; }
		if ( ! current_user_can( 'edit_post', $id ) ) { return; }
		if ( isset( $_POST['wkt_gallery'] ) ) { self::set_ids( $id, explode( ',', sanitize_text_field( wp_unslash( $_POST['wkt_gallery'] ) ) ) ); }
		if ( isset( $_POST['wkt_photo_src'] ) ) {
			$lines = array_filter( array_map( 'esc_url_raw', array_map( 'trim', preg_split( '/\r\n|\r|\n/', sanitize_textarea_field( wp_unslash( $_POST['wkt_photo_src'] ) ) ) ) ) );
			remove_action( 'updated_post_meta', [ __CLASS__, 'queue' ], 10 );
			remove_action( 'added_post_meta', [ __CLASS__, 'queue' ], 10 );
			update_post_meta( $id, Module::PRE . 'photo_src', implode( "\n", $lines ) );
			if ( $lines ) { self::fetch( $id ); } // In the edit screen the team sees the result right away.
		}
	}
}
