/* Wakoo Territorio: map (Leaflet). Only draws what the server sends: public layers and
   projects with a verified location. */
( function () {
	'use strict';
	function esc( s ) { return String( s == null ? '' : s ).replace( /[&<>"']/g, function ( c ) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ c ]; } ); }
	function popup( f, t ) {
		var h = '<strong>' + esc( f.name ) + '</strong>';
		if ( f.stage ) { h += '<div>' + esc( f.stage ) + '</div>'; }
		if ( f.desc ) { h += '<div>' + esc( f.desc ) + '</div>'; }
		h += '<div><em>' + esc( f.ok ? t.ok : t.ko ) + '</em></div>';
		if ( f.src ) { h += '<div>' + esc( t.src ) + ': ' + esc( f.src ) + ( f.date ? ' (' + esc( f.date ) + ')' : '' ) + '</div>'; }
		if ( f.url ) { h += '<div><a href="' + esc( f.url ) + '">' + esc( t.more ) + '</a></div>'; }
		return h;
	}
	function pin( color ) {
		return L.divIcon( { className: '', html: '<span class="wkt-gis__pin" style="--c:' + esc( color ) + '"></span>', iconSize: [ 18, 18 ], iconAnchor: [ 9, 9 ] } );
	}
	/* ---- Google Maps (Maps JavaScript API, loaded once, only when a map asks for it) ---- */
	var CLEAN = [
		{ featureType: 'poi', stylers: [ { visibility: 'off' } ] },
		{ featureType: 'transit', stylers: [ { visibility: 'off' } ] },
		{ featureType: 'road', elementType: 'labels.icon', stylers: [ { visibility: 'off' } ] },
		{ featureType: 'landscape', stylers: [ { saturation: -60 }, { lightness: 12 } ] },
		{ featureType: 'road', stylers: [ { saturation: -80 }, { lightness: 20 } ] },
		{ featureType: 'water', stylers: [ { color: '#B9D3E6' } ] },
		{ featureType: 'administrative', elementType: 'geometry.stroke', stylers: [ { color: '#8A9BB0' }, { weight: .8 } ] }
	];
	var gQueue = [];
	function gLoad( key, lang, cb ) {
		if ( window.google && window.google.maps && window.google.maps.Map ) { cb(); return; }
		gQueue.push( cb );
		if ( gQueue.length > 1 ) { return; }
		window.wktGmapsReady = function () { gQueue.splice( 0 ).forEach( function ( f ) { f(); } ); };
		var s = document.createElement( 'script' );
		s.src = 'https://maps.googleapis.com/maps/api/js?key=' + encodeURIComponent( key ) + '&language=' + encodeURIComponent( lang || 'es' ) + '&callback=wktGmapsReady&loading=async';
		s.async = true;
		document.head.appendChild( s );
	}
	function gDot( color ) {
		return { path: 0, scale: 7, fillColor: color, fillOpacity: 1, strokeColor: '#fff', strokeWeight: 2.5 };
	}
	function gmap( w, cfg ) {
		gLoad( cfg.gkey, cfg.lang, function () {
			var G = window.google.maps, box = w.querySelector( '.wkt-gis__map' );
			var types = { roadmap: 'roadmap', terrain: 'terrain', hybrid: 'hybrid', clean: 'roadmap' };
			var map = new G.Map( box, { center: { lat: cfg.center[0], lng: cfg.center[1] }, zoom: cfg.zoom || 8, mapTypeId: types[ cfg.gtype ] || 'roadmap',
				styles: 'clean' === cfg.gtype ? CLEAN : null, gestureHandling: 'cooperative', streetViewControl: false, fullscreenControl: true, mapTypeControl: true,
				mapTypeControlOptions: { style: G.MapTypeControlStyle.DROPDOWN_MENU } } );
			var t = cfg.i18n || {}, toggles = w.querySelector( '[data-wkt-gis-toggles]' ), info = new G.InfoWindow(), bounds = new G.LatLngBounds(), any = false;
			function grow( ll ) { bounds.extend( ll ); any = true; }
			function walk( c, fn ) { if ( typeof c[0] === 'number' ) { fn( { lat: c[1], lng: c[0] } ); } else { c.forEach( function ( x ) { walk( x, fn ); } ); } }
			function add( layer, items ) {
				var id = 'wkt-l-' + Math.random().toString( 36 ).slice( 2 ), lab = document.createElement( 'label' );
				lab.innerHTML = '<input type="checkbox" checked id="' + id + '"><span class="wkt-gis__sw" style="background:' + esc( layer.color ) + '"></span><span>' + esc( layer.name ) + ' (' + layer.items.length + ')</span>';
				lab.querySelector( 'input' ).addEventListener( 'change', function ( e ) { items.forEach( function ( o ) { o.setMap( e.target.checked ? map : null ); } ); } );
				toggles.appendChild( lab );
			}
			function marker( f, color ) {
				var m = new G.Marker( { position: { lat: f.pt[0], lng: f.pt[1] }, map: map, title: f.name, icon: gDot( color ) } );
				m.addListener( 'click', function () { info.setContent( popup( f, t ) ); info.open( { anchor: m, map: map } ); } );
				grow( m.getPosition() );
				return m;
			}
			( cfg.layers || [] ).forEach( function ( layer ) {
				var items = [];
				layer.items.forEach( function ( f ) {
					if ( f.pt ) { items.push( marker( f, layer.color ) ); return; }
					var d = new G.Data( { map: map } );
					var geo = f.geo.type === 'FeatureCollection' || f.geo.type === 'Feature' ? f.geo : { type: 'Feature', geometry: f.geo, properties: {} };
					d.addGeoJson( geo );
					d.setStyle( { strokeColor: layer.color, strokeWeight: 2.5, fillColor: layer.color, fillOpacity: .12, icon: gDot( layer.color ) } );
					d.addListener( 'click', function ( e ) { info.setContent( popup( f, t ) ); info.setPosition( e.latLng ); info.open( { map: map } ); } );
					( geo.features || [ geo ] ).forEach( function ( x ) { if ( x.geometry ) { walk( x.geometry.coordinates, grow ); } } );
					items.push( d );
				} );
				add( layer, items );
			} );
			var proj = [], sel = w.querySelector( '[data-wkt-gis-sector]' );
			function drawProjects() {
				if ( ! cfg.projects ) { return; }
				var keep = sel ? sel.value : '';
				proj.forEach( function ( m ) { m.setMap( null ); } );
				proj.length = 0;
				cfg.projects.items.forEach( function ( f ) { if ( ! keep || ( f.sectors || [] ).indexOf( keep ) >= 0 ) { proj.push( marker( f, cfg.projects.color ) ); } } );
			}
			if ( cfg.projects ) { drawProjects(); add( cfg.projects, proj ); }
			if ( sel ) { sel.addEventListener( 'change', drawProjects ); }
			if ( any ) {
				map.fitBounds( bounds, 30 );
				G.event.addListenerOnce( map, 'idle', function () { if ( map.getZoom() > 12 ) { map.setZoom( 12 ); } } );
			}
		} );
	}

	function boot( root ) {
		( root || document ).querySelectorAll( '[data-wkt-gis]' ).forEach( function ( w ) {
			if ( w.dataset.wktReady ) { return; }
			var cfg = JSON.parse( w.getAttribute( 'data-wkt-gis' ) || '{}' );
			if ( 'google' === cfg.engine ) {
				w.dataset.wktReady = '1';
				if ( cfg.gkey ) { gmap( w, cfg ); } // Without a key the server already printed Google's embed.
				return;
			}
			if ( ! window.L ) { return; }
			w.dataset.wktReady = '1';
			var box = w.querySelector( '.wkt-gis__map' );
			var map = L.map( box, { scrollWheelZoom: false } ).setView( cfg.center || [ 0, 0 ], cfg.zoom || 8 );
			box.addEventListener( 'focus', function () { map.scrollWheelZoom.enable(); } );
			box.addEventListener( 'blur', function () { map.scrollWheelZoom.disable(); } );
			L.tileLayer( cfg.tiles, { attribution: cfg.attr, maxZoom: 18 } ).addTo( map );
			var t = cfg.i18n || {}, toggles = w.querySelector( '[data-wkt-gis-toggles]' ), bounds = [];
			function add( layer, group ) {
				map.addLayer( group );
				var id = 'wkt-l-' + Math.random().toString( 36 ).slice( 2 );
				var lab = document.createElement( 'label' );
				lab.innerHTML = '<input type="checkbox" checked id="' + id + '"><span class="wkt-gis__sw" style="background:' + esc( layer.color ) + '"></span><span>' + esc( layer.name ) + ' (' + layer.items.length + ')</span>';
				lab.querySelector( 'input' ).addEventListener( 'change', function ( e ) { e.target.checked ? map.addLayer( group ) : map.removeLayer( group ); } );
				toggles.appendChild( lab );
			}
			( cfg.layers || [] ).forEach( function ( layer ) {
				var g = L.featureGroup();
				layer.items.forEach( function ( f ) {
					var m = f.geo ? L.geoJSON( f.geo, { style: { color: layer.color, weight: 3, fillOpacity: .15 }, pointToLayer: function ( p, ll ) { return L.marker( ll, { icon: pin( layer.color ) } ); } } ) : L.marker( f.pt, { icon: pin( layer.color ), title: f.name, alt: f.name } );
					m.bindPopup( popup( f, t ) ).addTo( g );
				} );
				add( layer, g );
				bounds.push( g.getBounds() );
			} );
			var proj = null, sel = w.querySelector( '[data-wkt-gis-sector]' );
			function drawProjects() {
				if ( ! cfg.projects ) { return; }
				var keep = sel ? sel.value : '';
				if ( proj ) { proj.clearLayers(); } else { proj = L.featureGroup(); add( cfg.projects, proj ); }
				cfg.projects.items.forEach( function ( f ) {
					if ( keep && ( f.sectors || [] ).indexOf( keep ) < 0 ) { return; }
					L.marker( f.pt, { icon: pin( cfg.projects.color ), title: f.name, alt: f.name } ).bindPopup( popup( f, t ) ).addTo( proj );
				} );
			}
			drawProjects();
			if ( proj && proj.getLayers().length ) { bounds.push( proj.getBounds() ); }
			if ( sel ) { sel.addEventListener( 'change', drawProjects ); }
			var all = bounds.filter( function ( b ) { return b && b.isValid(); } );
			if ( all.length ) {
				var b = all[0];
				all.slice( 1 ).forEach( function ( x ) { b.extend( x ); } );
				map.fitBounds( b, { padding: [ 30, 30 ], maxZoom: 12 } );
			}
			if ( 'ResizeObserver' in window ) { new ResizeObserver( function () { map.invalidateSize(); } ).observe( box ); }
		} );
	}
	document.addEventListener( 'DOMContentLoaded', function () { boot(); } );
	window.addEventListener( 'elementor/frontend/init', function () {
		if ( window.elementorFrontend && elementorFrontend.hooks ) {
			elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-t-gis.default', function ( $el ) { boot( $el[0] ); } );
		}
	} );
} )();
