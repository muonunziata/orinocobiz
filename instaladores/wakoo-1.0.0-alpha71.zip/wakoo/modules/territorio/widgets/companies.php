<?php
/**
 * «Directorio empresarial» (B2B): published company profiles with search and filters
 * (categoría, sector, municipio, nivel de verificación). Only fields the owner authorised.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class W_Companies extends Base {

	public function get_name() { return 'wakoo-t-companies'; }
	public function get_title() { return __( 'Directorio empresarial (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-person'; }
	public function get_keywords() { return [ 'directorio', 'empresas', 'proveedores', 'b2b', 'marketplace', 'wakoo' ]; }

	protected function controls() {
		$this->start_controls_section( 'sec_main', [ 'label' => __( 'Directorio', 'wakoo' ) ] );
		$this->add_control( 'sector', [ 'label' => __( 'Solo este sector (slug)', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$this->add_control( 'filters', [ 'label' => __( 'Mostrar buscador y filtros', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'per', [ 'label' => __( 'Empresas por página', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 12, 'min' => 1, 'max' => 60 ] );
		$this->add_control( 'register', [ 'label' => __( 'Enlace «registrar mi empresa»', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$this->end_controls_section();
	}

	protected function texts() {
		return [
			'search'  => [ __( 'Campo: buscar', 'wakoo' ), __( 'Buscar empresa, producto o servicio', 'wakoo' ) ],
			'l_cat'   => [ __( 'Etiqueta: categoría', 'wakoo' ), __( 'Categoría', 'wakoo' ) ],
			'l_sec'   => [ __( 'Etiqueta: sector', 'wakoo' ), __( 'Sector', 'wakoo' ) ],
			'l_mun'   => [ __( 'Etiqueta: municipio', 'wakoo' ), __( 'Municipio', 'wakoo' ) ],
			'l_lvl'   => [ __( 'Etiqueta: verificación', 'wakoo' ), __( 'Verificación', 'wakoo' ) ],
			'all'     => [ __( 'Opción: todos', 'wakoo' ), __( 'Todos', 'wakoo' ) ],
			'filter'  => [ __( 'Botón: filtrar', 'wakoo' ), __( 'Filtrar', 'wakoo' ) ],
			'count'   => [ __( 'Recuento (%d)', 'wakoo' ), __( '%d empresas', 'wakoo' ) ],
			'empty'   => [ __( 'Directorio vacío', 'wakoo' ), __( 'Todavía no hay empresas publicadas. Los perfiles aparecen aquí cuando su titular los registra y el equipo los revisa.', 'wakoo' ) ],
			'none'    => [ __( 'Sin resultados', 'wakoo' ), __( 'No hay empresas que coincidan con la búsqueda.', 'wakoo' ) ],
			'reg'     => [ __( 'Botón: registrar', 'wakoo' ), __( 'Registrar mi empresa', 'wakoo' ) ],
			'more'    => [ __( 'Enlace: ver perfil', 'wakoo' ), __( 'Ver perfil', 'wakoo' ) ],
			'legend'  => [ __( 'Leyenda de niveles', 'wakoo' ), __( 'Perfil de referencia: elaborado por el portal con información pública; la empresa aún no lo administra. Registrada: datos declarados por la empresa. Documentación verificada: el equipo revisó sus documentos. Homologada: un comprador la aprobó como proveedor. Ningún nivel garantiza contratos.', 'wakoo' ) ],
		];
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$fixed = sanitize_title( (string) ( $s['sector'] ?? '' ) );
		$per   = max( 1, (int) ( $s['per'] ?? 12 ) );
		$pg    = max( 1, (int) $this->get( 'pg' ) );
		$q     = $this->get( 'q' );
		$f     = [ 'cat' => (int) $this->get( 'cat' ), 'sector' => $fixed ? 0 : (int) $this->get( 'sector' ), 'municipio' => (int) $this->get( 'municipio' ) ];
		$lvl   = sanitize_key( $this->get( 'nivel' ) );
		$args  = [ 'post_type' => Module::COMPANY, 'post_status' => 'publish', 'posts_per_page' => $per, 'paged' => $pg, 'orderby' => 'title', 'order' => 'ASC' ];
		$tax   = [];
		if ( $fixed ) { $tax[] = [ 'taxonomy' => Module::T_SECTOR, 'field' => 'slug', 'terms' => $fixed ]; }
		foreach ( [ 'cat' => Module::T_CCAT, 'sector' => Module::T_SECTOR, 'municipio' => Module::T_MUN ] as $k => $t ) { if ( $f[ $k ] ) { $tax[] = [ 'taxonomy' => $t, 'field' => 'term_id', 'terms' => $f[ $k ] ]; } }
		if ( $tax ) { $args['tax_query'] = $tax; } // phpcs:ignore WordPress.DB.SlowDBQuery
		if ( $lvl && isset( Module::levels()[ $lvl ] ) ) { $args['meta_query'] = [ [ 'key' => Module::PRE . 'level', 'value' => $lvl ] ]; } // phpcs:ignore WordPress.DB.SlowDBQuery
		if ( '' !== $q ) { $args['s'] = $q; }
		$query = new \WP_Query( $args );
		$any   = (int) wp_count_posts( Module::COMPANY )->publish;
		$reg   = ! empty( $s['register']['url'] ) ? $s['register']['url'] : Module::page_url( 'company' );

		echo '<div class="wkt wkt-companies">';
		if ( 'yes' === ( $s['filters'] ?? '' ) && $any ) {
			echo '<form class="wkt-filters" method="get" role="search">';
			$this->field( 'q', $this->t( 'search' ), 'search', [ 'value' => $q ] );
			$this->field( 'cat', $this->t( 'l_cat' ), 'select', [ 'value' => $f['cat'] ?: '', 'options' => $this->term_options( Module::T_CCAT, $this->t( 'all' ) ) ] );
			if ( ! $fixed ) { $this->field( 'sector', $this->t( 'l_sec' ), 'select', [ 'value' => $f['sector'] ?: '', 'options' => $this->term_options( Module::T_SECTOR, $this->t( 'all' ) ) ] ); }
			$this->field( 'municipio', $this->t( 'l_mun' ), 'select', [ 'value' => $f['municipio'] ?: '', 'options' => $this->term_options( Module::T_MUN, $this->t( 'all' ) ) ] );
			$this->field( 'nivel', $this->t( 'l_lvl' ), 'select', [ 'value' => $lvl, 'options' => [ '' => $this->t( 'all' ) ] + Module::levels() ] );
			echo '<div class="wkt-filters__go"><button class="wkt-btn" type="submit">' . esc_html( $this->t( 'filter' ) ) . '</button></div></form>';
			echo '<p class="wkt-count" aria-live="polite">' . esc_html( sprintf( $this->t( 'count' ), (int) $query->found_posts ) ) . '</p>';
		}
		if ( ! $any || ! $query->have_posts() ) {
			echo '<div class="wkt-empty"><p>' . esc_html( $any ? $this->t( 'none' ) : $this->t( 'empty' ) ) . '</p>' . ( $reg ? '<p><a class="wkt-btn" href="' . esc_url( $reg ) . '">' . esc_html( $this->t( 'reg' ) ) . '</a></p>' : '' ) . '</div>';
		} else {
			echo '<ul class="wkt-grid">';
			foreach ( $query->posts as $c ) {
				$lv = Module::meta( $c->ID, 'level', 'registrada' );
				$ph = Photos::ids( $c->ID );
				echo '<li class="wkt-card wkt-ccard' . ( $ph ? ' wkt-ccard--photo' : '' ) . '">';
				if ( $ph ) { echo '<a class="wkt-ccard__cover" href="' . esc_url( get_permalink( $c ) ) . '" tabindex="-1" aria-hidden="true">' . wp_get_attachment_image( $ph[0], 'medium_large', false, [ 'alt' => '', 'loading' => 'lazy' ] ) . '</a>'; } // phpcs:ignore WordPress.Security.EscapeOutput
				echo '<div class="wkt-ccard__top">';
				echo has_post_thumbnail( $c ) ? get_the_post_thumbnail( $c, 'thumbnail', [ 'class' => 'wkt-ccard__logo', 'alt' => '' ] ) : '<span class="wkt-ccard__mono" aria-hidden="true">' . esc_html( mb_strtoupper( mb_substr( $c->post_title, 0, 2 ) ) ) . '</span>';
				echo $this->badge( Module::levels()[ $lv ] ?? '', 'lvl-' . $lv ) . '</div><h3 class="wkt-pcard__title"><a href="' . esc_url( get_permalink( $c ) ) . '">' . esc_html( $c->post_title ) . '</a></h3>'; // phpcs:ignore WordPress.Security.EscapeOutput
				echo '<p class="wkt-small wkt-muted">' . esc_html( implode( ' · ', array_filter( [ Module::term_names( $c->ID, Module::T_CCAT ), Module::term_names( $c->ID, Module::T_MUN ) ] ) ) ) . '</p>';
				echo '<p class="wkt-pcard__text">' . esc_html( wp_trim_words( $c->post_excerpt ? Module::tr( $c->post_excerpt ) : $c->post_content, 24, '…' ) ) . '</p><a class="wkt-more" href="' . esc_url( get_permalink( $c ) ) . '">' . esc_html( $this->t( 'more' ) ) . ' <span aria-hidden="true">→</span></a></li>';
			}
			echo '</ul>';
			$this->pager( $pg, (int) $query->max_num_pages );
		}
		echo '<p class="wkt-small wkt-muted">' . esc_html( $this->t( 'legend' ) ) . '</p></div>';
	}
}
