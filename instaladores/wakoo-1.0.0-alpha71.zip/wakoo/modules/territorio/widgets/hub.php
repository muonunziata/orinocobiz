<?php
/**
 * «Hub administrativo»: front-end desk for the portal team (WordPress sign-in, same users and
 * roles). Tabs: requests (ventanilla cases: status, assignee, messages), users (create with a
 * temporary password) and companies (level, publication, access for the company).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class W_Hub extends Base {

	public function get_name() { return 'wakoo-t-hub'; }
	public function get_title() { return __( 'Hub administrativo (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-dashboard'; }
	public function get_keywords() { return [ 'hub', 'admin', 'administracion', 'usuarios', 'solicitudes', 'empresas', 'panel', 'wakoo' ]; }

	protected function controls() {
		$this->start_controls_section( 'sec_main', [ 'label' => __( 'Hub', 'wakoo' ) ] );
		$this->add_control( 'per', [ 'label' => __( 'Filas por página', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 15, 'min' => 5, 'max' => 100 ] );
		$this->add_control( 'wpadmin', [ 'label' => __( 'Enlace al escritorio de WordPress', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();
	}

	protected function texts() {
		return [
			'title'    => [ __( 'Título', 'wakoo' ), __( 'Hub administrativo', 'wakoo' ) ],
			'intro'    => [ __( 'Introducción', 'wakoo' ), __( 'Gestione las solicitudes, las cuentas y las empresas del portal. Se entra con el mismo usuario de WordPress.', 'wakoo' ) ],
			'login'    => [ __( 'Sin sesión', 'wakoo' ), __( 'Inicie sesión con su usuario del equipo para entrar en el hub.', 'wakoo' ) ],
			'denied'   => [ __( 'Sin permiso', 'wakoo' ), __( 'Su cuenta no forma parte del equipo del portal.', 'wakoo' ) ],
			't_cases'  => [ __( 'Pestaña: solicitudes', 'wakoo' ), __( 'Solicitudes', 'wakoo' ) ],
			't_users'  => [ __( 'Pestaña: usuarios', 'wakoo' ), __( 'Usuarios', 'wakoo' ) ],
			't_comp'   => [ __( 'Pestaña: empresas', 'wakoo' ), __( 'Empresas', 'wakoo' ) ],
			'k_open'   => [ __( 'Cifra: solicitudes abiertas', 'wakoo' ), __( 'Solicitudes abiertas', 'wakoo' ) ],
			'k_mine'   => [ __( 'Cifra: asignadas a mí', 'wakoo' ), __( 'Asignadas a usted', 'wakoo' ) ],
			'k_comp'   => [ __( 'Cifra: empresas', 'wakoo' ), __( 'Empresas en el directorio', 'wakoo' ) ],
			'k_noacc'  => [ __( 'Cifra: sin cuenta', 'wakoo' ), __( 'Empresas sin cuenta', 'wakoo' ) ],
			'all'      => [ __( 'Opción: todos', 'wakoo' ), __( 'Todos', 'wakoo' ) ],
			'filter'   => [ __( 'Botón: filtrar', 'wakoo' ), __( 'Filtrar', 'wakoo' ) ],
			'search'   => [ __( 'Campo: buscar', 'wakoo' ), __( 'Buscar', 'wakoo' ) ],
			'code'     => [ __( 'Columna: código', 'wakoo' ), __( 'Código', 'wakoo' ) ],
			'subject'  => [ __( 'Columna: solicitud', 'wakoo' ), __( 'Solicitud', 'wakoo' ) ],
			'applicant'=> [ __( 'Columna: solicitante', 'wakoo' ), __( 'Solicitante', 'wakoo' ) ],
			'status'   => [ __( 'Columna: estado', 'wakoo' ), __( 'Estado', 'wakoo' ) ],
			'assignee' => [ __( 'Columna: responsable', 'wakoo' ), __( 'Responsable', 'wakoo' ) ],
			'date'     => [ __( 'Columna: fecha', 'wakoo' ), __( 'Fecha', 'wakoo' ) ],
			'manage'   => [ __( 'Botón: gestionar', 'wakoo' ), __( 'Gestionar', 'wakoo' ) ],
			'history'  => [ __( 'Título: historial', 'wakoo' ), __( 'Historial', 'wakoo' ) ],
			'internal' => [ __( 'Etiqueta: nota interna', 'wakoo' ), __( 'Nota interna (solo el equipo)', 'wakoo' ) ],
			'public'   => [ __( 'Etiqueta: mensaje', 'wakoo' ), __( 'Mensaje para el solicitante', 'wakoo' ) ],
			'notify'   => [ __( 'Avisar por correo', 'wakoo' ), __( 'Avisar al solicitante por correo', 'wakoo' ) ],
			'save'     => [ __( 'Botón: guardar', 'wakoo' ), __( 'Guardar', 'wakoo' ) ],
			'no_cases' => [ __( 'Sin solicitudes', 'wakoo' ), __( 'No hay solicitudes con estos filtros.', 'wakoo' ) ],
			'nobody'   => [ __( 'Sin responsable', 'wakoo' ), __( 'Sin responsable', 'wakoo' ) ],
			'u_new'    => [ __( 'Título: crear usuario', 'wakoo' ), __( 'Crear un usuario', 'wakoo' ) ],
			'u_help'   => [ __( 'Ayuda: crear usuario', 'wakoo' ), __( 'El sistema genera una contraseña temporal que verá una sola vez. La persona deberá cambiarla al entrar por primera vez.', 'wakoo' ) ],
			'name'     => [ __( 'Campo: nombre', 'wakoo' ), __( 'Nombre', 'wakoo' ) ],
			'email'    => [ __( 'Campo: correo', 'wakoo' ), __( 'Correo electrónico', 'wakoo' ) ],
			'role'     => [ __( 'Campo: rol', 'wakoo' ), __( 'Rol', 'wakoo' ) ],
			'create'   => [ __( 'Botón: crear', 'wakoo' ), __( 'Crear usuario', 'wakoo' ) ],
			'user'     => [ __( 'Columna: usuario', 'wakoo' ), __( 'Usuario', 'wakoo' ) ],
			'since'    => [ __( 'Columna: alta', 'wakoo' ), __( 'Alta', 'wakoo' ) ],
			'temp'     => [ __( 'Marca: clave temporal', 'wakoo' ), __( 'Clave temporal sin cambiar', 'wakoo' ) ],
			'reset'    => [ __( 'Botón: nueva clave temporal', 'wakoo' ), __( 'Nueva clave temporal', 'wakoo' ) ],
			'c_name'   => [ __( 'Columna: empresa', 'wakoo' ), __( 'Empresa', 'wakoo' ) ],
			'level'    => [ __( 'Columna: nivel', 'wakoo' ), __( 'Nivel', 'wakoo' ) ],
			'pub'      => [ __( 'Columna: publicación', 'wakoo' ), __( 'Publicación', 'wakoo' ) ],
			'account'  => [ __( 'Columna: cuenta', 'wakoo' ), __( 'Cuenta', 'wakoo' ) ],
			'no_acc'   => [ __( 'Sin cuenta', 'wakoo' ), __( 'Sin cuenta', 'wakoo' ) ],
			'pending_mail' => [ __( 'Correo pendiente', 'wakoo' ), __( 'correo pendiente', 'wakoo' ) ],
			'give'     => [ __( 'Botón: crear acceso', 'wakoo' ), __( 'Crear acceso', 'wakoo' ) ],
			'give_all' => [ __( 'Botón: crear accesos', 'wakoo' ), __( 'Crear acceso para todas las empresas sin cuenta', 'wakoo' ) ],
			'give_help'=> [ __( 'Ayuda: accesos', 'wakoo' ), __( 'Cada empresa recibe un usuario y una contraseña temporal. Si no conoce aún el correo oficial, se usa una dirección provisional que no recibe correo y que debe cambiarse después.', 'wakoo' ) ],
			'c_email'  => [ __( 'Campo: correo de la empresa', 'wakoo' ), __( 'Correo oficial (opcional)', 'wakoo' ) ],
			's_pub'    => [ __( 'Estado: publicada', 'wakoo' ), __( 'Publicada', 'wakoo' ) ],
			's_pend'   => [ __( 'Estado: por revisar', 'wakoo' ), __( 'Por revisar', 'wakoo' ) ],
			's_draft'  => [ __( 'Estado: borrador', 'wakoo' ), __( 'Borrador', 'wakoo' ) ],
			'once'     => [ __( 'Título: credenciales', 'wakoo' ), __( 'Credenciales temporales (se muestran una sola vez)', 'wakoo' ) ],
			'once_help'=> [ __( 'Ayuda: credenciales', 'wakoo' ), __( 'Entréguelas por un canal seguro. No las envíe por chat ni las guarde en documentos compartidos. Al entrar, cada cuenta debe elegir su propia contraseña.', 'wakoo' ) ],
			'pass'     => [ __( 'Columna: contraseña', 'wakoo' ), __( 'Contraseña temporal', 'wakoo' ) ],
			'dl'       => [ __( 'Botón: descargar credenciales', 'wakoo' ), __( 'Descargar las credenciales (.txt)', 'wakoo' ) ],
			'dl_note'  => [ __( 'Texto del .txt', 'wakoo' ), __( 'Contraseñas temporales: al entrar por primera vez, cada cuenta debe elegir la suya. Borre este archivo cuando las haya entregado.', 'wakoo' ) ],
			'copy'     => [ __( 'Botón: copiar', 'wakoo' ), __( 'Copiar', 'wakoo' ) ],
			'wpadmin'  => [ __( 'Enlace: escritorio', 'wakoo' ), __( 'Abrir el escritorio de WordPress', 'wakoo' ) ],
		];
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		echo '<div class="wkt wkt-hub">';
		$this->notice();
		if ( ! is_user_logged_in() && ! $this->in_editor() ) { $this->login_box( $this->t( 'login' ) ); echo '</div>'; return; }
		if ( ! Module::is_staff() && ! $this->in_editor() ) { echo '<div class="wkt-card"><p>' . esc_html( $this->t( 'denied' ) ) . '</p></div></div>'; return; }

		$this->credentials();
		$tabs = [ 'solicitudes' => [ 't_cases', 'edit_others_wk_cases' ], 'usuarios' => [ 't_users', 'list_users' ], 'empresas' => [ 't_comp', 'edit_others_wk_companys' ] ];
		$tabs = array_filter( $tabs, function ( $t ) { return current_user_can( $t[1] ) || $this->in_editor(); } );
		$tab  = $this->get( 'hub' );
		if ( ! isset( $tabs[ $tab ] ) ) { $tab = (string) key( $tabs ); }

		echo '<header class="wkt-hub__head"><div><h2 class="wkt-hub__title">' . esc_html( $this->t( 'title' ) ) . '</h2><p class="wkt-muted">' . esc_html( $this->t( 'intro' ) ) . '</p></div>';
		if ( 'yes' === ( $s['wpadmin'] ?? '' ) ) { echo '<a class="wkt-btn wkt-btn--ghost" href="' . esc_url( admin_url() ) . '">' . esc_html( $this->t( 'wpadmin' ) ) . '</a>'; }
		echo '</header>';
		$this->kpis();
		if ( ! $tabs ) { echo '</div>'; return; }
		echo '<nav class="wkt-tabs wkt-hub__tabs" aria-label="' . esc_attr( $this->t( 'title' ) ) . '">';
		foreach ( $tabs as $k => $t ) {
			echo '<a href="' . esc_url( add_query_arg( 'hub', $k, remove_query_arg( [ 'pg', 'q', 'estado', 'caso', 'wkt', 'wkt_w' ], $this->here() ) ) ) . '"' . ( $k === $tab ? ' aria-current="page"' : '' ) . '>' . esc_html( $this->t( $t[0] ) ) . '</a>';
		}
		echo '</nav><div class="wkt-hub__panel">';
		$per = max( 5, (int) ( $s['per'] ?? 15 ) );
		if ( 'solicitudes' === $tab ) { $this->cases( $per ); }
		if ( 'usuarios' === $tab ) { $this->users( $per ); }
		if ( 'empresas' === $tab ) { $this->companies(); }
		echo '</div></div>';
	}

	/** Credentials created in the last request, shown once with a copy button. */
	private function credentials() {
		$rows = Hub::take_once();
		if ( ! $rows ) { return; }
		echo '<section class="wkt-card wkt-hub__once" role="alert"><h3 class="wkt-h">' . esc_html( $this->t( 'once' ) ) . '</h3><p class="wkt-small">' . esc_html( $this->t( 'once_help' ) ) . '</p>';
		echo '<div class="wkt-table-wrap"><table class="wkt-table wkt-hub__table"><thead><tr><th scope="col">' . esc_html( $this->t( 'name' ) ) . '</th><th scope="col">' . esc_html( $this->t( 'user' ) ) . '</th><th scope="col">' . esc_html( $this->t( 'pass' ) ) . '</th><th scope="col">' . esc_html( $this->t( 'email' ) ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			echo '<tr><td data-th="' . esc_attr( $this->t( 'name' ) ) . '">' . esc_html( $r[0] ) . '</td><td data-th="' . esc_attr( $this->t( 'user' ) ) . '" class="wkt-mono">' . esc_html( $r[1] ) . '</td>';
			echo '<td data-th="' . esc_attr( $this->t( 'pass' ) ) . '"><code class="wkt-code" data-wkt-secret>' . esc_html( $r[2] ) . '</code> <button type="button" class="wkt-btn wkt-btn--ghost wkt-hub__copy" data-wkt-copy="' . esc_attr( $r[1] . ' / ' . $r[2] ) . '">' . esc_html( $this->t( 'copy' ) ) . '</button></td>';
			echo '<td data-th="' . esc_attr( $this->t( 'email' ) ) . '">' . esc_html( Hub::is_placeholder( $r[3] ) ? $this->t( 'pending_mail' ) : $r[3] ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
		// The .txt is built in this same response from the rows above: nothing is written to the server.
		$txt = html_entity_decode( get_bloginfo( 'name' ), ENT_QUOTES, 'UTF-8' ) . "\n" . wp_login_url() . "\n" . wp_date( 'Y-m-d H:i' ) . "\n" . $this->t( 'dl_note' ) . "\n\n";
		foreach ( $rows as $r ) {
			$txt .= $r[0] . "\n" . $this->t( 'user' ) . ': ' . $r[1] . "\n" . $this->t( 'pass' ) . ': ' . $r[2] . "\n" . $this->t( 'email' ) . ': ' . ( Hub::is_placeholder( $r[3] ) ? $this->t( 'pending_mail' ) : $r[3] ) . "\n\n";
		}
		echo '<p><a class="wkt-btn" download="' . esc_attr( 'credenciales-' . sanitize_title( get_bloginfo( 'name' ) ) . '-' . wp_date( 'Ymd-Hi' ) . '.txt' ) . '" href="data:text/plain;charset=utf-8,' . rawurlencode( "\xEF\xBB\xBF" . $txt ) . '">' . esc_html( $this->t( 'dl' ) ) . '</a></p></section>';
	}

	private function kpis() {
		$st     = Module::statuses();
		$closed = array_keys( array_filter( $st, function ( $d ) { return ! empty( $d[1] ); } ) );
		$open   = 0;
		$mine   = 0;
		foreach ( get_posts( [ 'post_type' => Module::CASE_T, 'post_status' => [ 'private', 'publish' ], 'numberposts' => 500, 'fields' => 'ids' ] ) as $id ) {
			if ( in_array( Module::meta( $id, 'status' ), $closed, true ) ) { continue; }
			$open++;
			if ( (int) Module::meta( $id, 'assignee' ) === get_current_user_id() ) { $mine++; }
		}
		$comp  = get_posts( [ 'post_type' => Module::COMPANY, 'post_status' => [ 'publish', 'pending', 'draft' ], 'numberposts' => 500 ] );
		$noacc = count( array_filter( $comp, function ( $c ) { return ! Module::company_account( $c ); } ) );
		echo '<ul class="wkt-hub__kpis">';
		foreach ( [ [ 'k_open', $open ], [ 'k_mine', $mine ], [ 'k_comp', count( $comp ) ], [ 'k_noacc', $noacc ] ] as $k ) {
			echo '<li><strong>' . (int) $k[1] . '</strong><span>' . esc_html( $this->t( $k[0] ) ) . '</span></li>';
		}
		echo '</ul>';
	}

	/* ---------------------------------------------------------------- requests */

	private function cases( $per ) {
		$st   = Module::statuses();
		$want = sanitize_key( $this->get( 'estado' ) );
		$q    = $this->get( 'q' );
		$pg   = max( 1, (int) $this->get( 'pg' ) );
		$args = [ 'post_type' => Module::CASE_T, 'post_status' => [ 'private', 'publish' ], 'posts_per_page' => $per, 'paged' => $pg, 'orderby' => 'date', 'order' => 'DESC' ];
		if ( $want && isset( $st[ $want ] ) ) { $args['meta_query'] = [ [ 'key' => Module::PRE . 'status', 'value' => $want ] ]; } // phpcs:ignore WordPress.DB.SlowDBQuery
		if ( 'mias' === $want ) { $args['meta_query'] = [ [ 'key' => Module::PRE . 'assignee', 'value' => get_current_user_id() ] ]; } // phpcs:ignore WordPress.DB.SlowDBQuery
		if ( '' !== $q ) { $args['s'] = $q; }
		$query = new \WP_Query( $args );
		echo '<form class="wkt-filters wkt-hub__filters" method="get"><input type="hidden" name="hub" value="solicitudes">';
		$this->field( 'q', $this->t( 'search' ), 'search', [ 'value' => $q ] );
		$opts = [ '' => $this->t( 'all' ), 'mias' => $this->t( 'k_mine' ) ];
		foreach ( $st as $k => $d ) { $opts[ $k ] = $d[0]; }
		$this->field( 'estado', $this->t( 'status' ), 'select', [ 'value' => $want, 'options' => $opts ] );
		echo '<div class="wkt-filters__go"><button class="wkt-btn" type="submit">' . esc_html( $this->t( 'filter' ) ) . '</button></div></form>';
		if ( ! $query->have_posts() ) { echo '<div class="wkt-empty">' . esc_html( $this->t( 'no_cases' ) ) . '</div>'; return; }
		$staff = get_users( [ 'capability' => 'edit_others_wk_cases', 'fields' => [ 'ID', 'display_name' ] ] );
		$who   = [ 0 => $this->t( 'nobody' ) ];
		foreach ( $staff as $u ) { $who[ $u->ID ] = $u->display_name; }
		$open = (int) $this->get( 'caso' );
		echo '<ul class="wkt-hub__list">';
		foreach ( $query->posts as $c ) {
			$k   = Module::meta( $c->ID, 'status' );
			$a   = (int) Module::meta( $c->ID, 'assignee' );
			$app = get_userdata( (int) $c->post_author );
			echo '<li class="wkt-hub__item"><details' . ( $open === $c->ID ? ' open' : '' ) . '><summary>';
			echo '<span class="wkt-hub__code wkt-mono">' . esc_html( Module::meta( $c->ID, 'code' ) ) . '</span><span class="wkt-hub__name">' . esc_html( $c->post_title ) . '</span>';
			echo '<span class="wkt-hub__meta">' . $this->badge( $st[ $k ][0] ?? $k, ! empty( $st[ $k ][1] ) ? 'soft' : 'info' ) . '<span>' . esc_html( $app ? $app->display_name : '—' ) . '</span><span>' . esc_html( $who[ $a ] ?? $this->t( 'nobody' ) ) . '</span><span>' . esc_html( get_the_date( 'd/m/Y', $c ) ) . '</span></span>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<span class="wkt-hub__open" aria-hidden="true">' . esc_html( $this->t( 'manage' ) ) . '</span></summary><div class="wkt-hub__body">';
			echo '<div class="wkt-hub__cols"><div><h4 class="wkt-h">' . esc_html( $this->t( 'history' ) ) . '</h4><ol class="wkt-timeline">';
			foreach ( array_slice( array_reverse( Store::lines( Module::CASE_T, $c->ID, [ 'public', 'internal' ] ) ), 0, 12 ) as $l ) {
				$by = $l->user_id ? get_userdata( (int) $l->user_id ) : null;
				echo '<li class="' . ( 'internal' === $l->vis ? 'is-internal' : 'is-team' ) . '"><p class="wkt-timeline__meta">' . esc_html( ( $by ? $by->display_name : get_bloginfo( 'name' ) ) . ' · ' . get_date_from_gmt( $l->created, 'd/m/Y H:i' ) ) . '</p><p>' . nl2br( esc_html( $l->message ) ) . '</p></li>';
			}
			echo '</ol><p class="wkt-small"><a href="' . esc_url( admin_url( 'post.php?post=' . $c->ID . '&action=edit' ) ) . '">' . esc_html( $this->t( 'wpadmin' ) ) . ' ↗</a></p></div><div>';
			$this->form_open( 'hub_case', false, 'wkt-grid-form', add_query_arg( [ 'hub' => 'solicitudes', 'caso' => $c->ID ], $this->here() ) );
			echo '<input type="hidden" name="case" value="' . (int) $c->ID . '">';
			$this->field( 'status', $this->t( 'status' ), 'select', [ 'value' => $k, 'options' => wp_list_pluck( $st, 0 ) ] );
			$this->field( 'assignee', $this->t( 'assignee' ), 'select', [ 'value' => (string) $a, 'options' => $who ] );
			$this->field( 'public_msg', $this->t( 'public' ), 'textarea', [ 'rows' => 3, 'wide' => true ] );
			$this->field( 'internal', $this->t( 'internal' ), 'textarea', [ 'rows' => 2, 'wide' => true ] );
			echo '<div class="wkt-field wkt-field--wide">';
			$this->check( 'notify', $this->t( 'notify' ), true );
			echo '<button class="wkt-btn" type="submit">' . esc_html( $this->t( 'save' ) ) . '</button></div></form></div></div></div></details></li>';
		}
		echo '</ul>';
		$this->pager( $pg, (int) $query->max_num_pages );
	}

	/* ---------------------------------------------------------------- users */

	private function users( $per ) {
		if ( current_user_can( 'create_users' ) ) {
			echo '<section class="wkt-card wkt-hub__new"><h3 class="wkt-h">' . esc_html( $this->t( 'u_new' ) ) . '</h3><p class="wkt-small wkt-muted">' . esc_html( $this->t( 'u_help' ) ) . '</p>';
			$this->form_open( 'hub_user', false, 'wkt-grid-form', add_query_arg( 'hub', 'usuarios', $this->here() ) );
			$this->field( 'name', $this->t( 'name' ), 'text', [ 'required' => true, 'attr' => 'maxlength="100" autocomplete="off"' ] );
			$this->field( 'email', $this->t( 'email' ), 'email', [ 'required' => true, 'attr' => 'autocomplete="off"' ] );
			$this->field( 'role', $this->t( 'role' ), 'select', [ 'options' => Hub::roles() ] );
			echo '<div class="wkt-field wkt-filters__go"><button class="wkt-btn" type="submit">' . esc_html( $this->t( 'create' ) ) . '</button></div></form></section>';
		}
		$q    = $this->get( 'q' );
		$pg   = max( 1, (int) $this->get( 'pg' ) );
		$args = [ 'number' => $per, 'paged' => $pg, 'orderby' => 'registered', 'order' => 'DESC', 'count_total' => true ];
		if ( '' !== $q ) { $args['search'] = '*' . $q . '*'; $args['search_columns'] = [ 'user_login', 'user_email', 'display_name' ]; }
		$uq = new \WP_User_Query( $args );
		echo '<form class="wkt-filters wkt-hub__filters" method="get"><input type="hidden" name="hub" value="usuarios">';
		$this->field( 'q', $this->t( 'search' ), 'search', [ 'value' => $q ] );
		echo '<div class="wkt-filters__go"><button class="wkt-btn" type="submit">' . esc_html( $this->t( 'filter' ) ) . '</button></div></form>';
		$names = wp_roles()->get_names();
		echo '<div class="wkt-table-wrap"><table class="wkt-table wkt-hub__table"><thead><tr><th scope="col">' . esc_html( $this->t( 'name' ) ) . '</th><th scope="col">' . esc_html( $this->t( 'user' ) ) . '</th><th scope="col">' . esc_html( $this->t( 'email' ) ) . '</th><th scope="col">' . esc_html( $this->t( 'role' ) ) . '</th><th scope="col">' . esc_html( $this->t( 'since' ) ) . '</th><th scope="col"><span class="screen-reader-text">' . esc_html( $this->t( 'reset' ) ) . '</span></th></tr></thead><tbody>';
		foreach ( $uq->get_results() as $u ) {
			$roles = implode( ', ', array_map( function ( $r ) use ( $names ) { return translate_user_role( $names[ $r ] ?? $r ); }, $u->roles ) );
			echo '<tr><td data-th="' . esc_attr( $this->t( 'name' ) ) . '">' . esc_html( $u->display_name ) . ( Hub::must_change( $u->ID ) ? ' ' . $this->badge( $this->t( 'temp' ), 'warn' ) : '' ) . '</td>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<td data-th="' . esc_attr( $this->t( 'user' ) ) . '" class="wkt-mono">' . esc_html( $u->user_login ) . '</td><td data-th="' . esc_attr( $this->t( 'email' ) ) . '">' . esc_html( Hub::is_placeholder( $u->user_email ) ? $this->t( 'pending_mail' ) : $u->user_email ) . '</td>';
			echo '<td data-th="' . esc_attr( $this->t( 'role' ) ) . '">' . esc_html( $roles ) . '</td><td data-th="' . esc_attr( $this->t( 'since' ) ) . '">' . esc_html( mysql2date( 'd/m/Y', $u->user_registered ) ) . '</td><td>';
			if ( current_user_can( 'edit_user', $u->ID ) && ! user_can( $u, 'manage_options' ) && get_current_user_id() !== $u->ID ) {
				$this->form_open( 'hub_reset', false, 'wkt-hub__inline', add_query_arg( 'hub', 'usuarios', $this->here() ) );
				echo '<input type="hidden" name="user" value="' . (int) $u->ID . '"><button class="wkt-btn wkt-btn--ghost" type="submit">' . esc_html( $this->t( 'reset' ) ) . '</button></form>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table></div>';
		$this->pager( $pg, (int) ceil( $uq->get_total() / $per ) );
	}

	/* ---------------------------------------------------------------- companies */

	private function companies() {
		$list = get_posts( [ 'post_type' => Module::COMPANY, 'post_status' => [ 'publish', 'pending', 'draft' ], 'numberposts' => 200, 'orderby' => 'title', 'order' => 'ASC' ] );
		$can  = current_user_can( 'create_users' );
		$back = add_query_arg( 'hub', 'empresas', $this->here() );
		if ( $can && array_filter( $list, function ( $c ) { return 'referencia' === Module::meta( $c->ID, 'level' ) && ! Module::company_account( $c ); } ) ) {
			echo '<section class="wkt-card wkt-hub__new"><p class="wkt-small wkt-muted">' . esc_html( $this->t( 'give_help' ) ) . '</p>';
			$this->form_open( 'hub_access_all', false, 'wkt-hub__inline', $back );
			echo '<button class="wkt-btn" type="submit">' . esc_html( $this->t( 'give_all' ) ) . '</button></form></section>';
		}
		$lbl = [ 'publish' => $this->t( 's_pub' ), 'pending' => $this->t( 's_pend' ), 'draft' => $this->t( 's_draft' ) ];
		echo '<ul class="wkt-hub__list">';
		foreach ( $list as $c ) {
			$lv    = Module::meta( $c->ID, 'level', 'registrada' );
			$owner = Module::company_account( $c );
			$own   = (bool) $owner;
			echo '<li class="wkt-hub__item"><details><summary><span class="wkt-hub__name">' . esc_html( $c->post_title ) . '</span><span class="wkt-hub__meta">' . $this->badge( Module::levels()[ $lv ] ?? $lv, 'lvl-' . $lv ) . $this->badge( $lbl[ $c->post_status ] ?? $c->post_status, 'publish' === $c->post_status ? 'ok' : 'warn' ); // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<span>' . ( $own && $owner ? '<span class="wkt-mono">' . esc_html( $owner->user_login ) . '</span>' : esc_html( $this->t( 'no_acc' ) ) ) . '</span></span><span class="wkt-hub__open" aria-hidden="true">' . esc_html( $this->t( 'manage' ) ) . '</span></summary><div class="wkt-hub__body"><div class="wkt-hub__cols"><div>';
			$this->form_open( 'hub_company', false, 'wkt-grid-form', $back );
			echo '<input type="hidden" name="company" value="' . (int) $c->ID . '">';
			$this->field( 'level', $this->t( 'level' ), 'select', [ 'value' => $lv, 'options' => Module::levels() ] );
			$this->field( 'status', $this->t( 'pub' ), 'select', [ 'value' => $c->post_status, 'options' => $lbl ] );
			echo '<div class="wkt-field wkt-field--wide"><button class="wkt-btn" type="submit">' . esc_html( $this->t( 'save' ) ) . '</button> <a class="wkt-small" href="' . esc_url( get_permalink( $c ) ) . '">' . esc_html( $this->t( 'c_name' ) ) . ' ↗</a></div></form></div><div>';
			if ( $can && ! $own ) {
				$this->form_open( 'hub_access', false, 'wkt-grid-form', $back );
				echo '<input type="hidden" name="company" value="' . (int) $c->ID . '">';
				$this->field( 'email', $this->t( 'c_email' ), 'email', [ 'wide' => true, 'attr' => 'autocomplete="off"' ] );
				echo '<div class="wkt-field wkt-field--wide"><button class="wkt-btn wkt-btn--ghost" type="submit">' . esc_html( $this->t( 'give' ) ) . '</button></div></form>';
			} elseif ( $own && $owner ) {
				echo '<p class="wkt-small"><strong>' . esc_html( $this->t( 'account' ) ) . ':</strong> <span class="wkt-mono">' . esc_html( $owner->user_login ) . '</span> · ' . esc_html( Hub::is_placeholder( $owner->user_email ) ? $this->t( 'pending_mail' ) : $owner->user_email ) . ( Hub::must_change( $owner->ID ) ? ' ' . $this->badge( $this->t( 'temp' ), 'warn' ) : '' ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
				if ( current_user_can( 'edit_user', $owner->ID ) && ! user_can( $owner, 'manage_options' ) ) {
					$this->form_open( 'hub_reset', false, 'wkt-hub__inline', $back );
					echo '<input type="hidden" name="user" value="' . (int) $owner->ID . '"><button class="wkt-btn wkt-btn--ghost" type="submit">' . esc_html( $this->t( 'reset' ) ) . '</button></form>';
				}
			}
			echo '</div></div></div></details></li>';
		}
		echo '</ul>';
	}
}
