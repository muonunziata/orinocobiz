<?php
/**
 * Shared base of the Territorio widgets: every visible label is an editable control (so each
 * language version of a page carries its own words and Wakoo Idiomas can sync them), plus
 * the status messages that come back in the URL and small form helpers.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

abstract class Base extends Widget_Base {

	/** [ id => [ label in the panel, default text ] ] */
	abstract protected function texts();

	public function get_categories() { return [ 'wakoo-territorio', 'basic' ]; }
	public function get_style_depends() { return [ 'wakoo-territorio' ]; }
	public function get_script_depends() { return [ 'wakoo-territorio' ]; }

	/** Widget-specific controls (before the texts). */
	protected function controls() {}

	protected function register_controls() {
		$this->controls();
		$this->start_controls_section( 'sec_texts', [ 'label' => __( 'Textos', 'wakoo' ) ] );
		foreach ( $this->texts() as $id => $d ) {
			$this->add_control( 'lbl_' . $id, [ 'label' => $d[0], 'type' => mb_strlen( $d[1] ) > 70 ? Controls_Manager::TEXTAREA : Controls_Manager::TEXT, 'default' => $d[1], 'label_block' => true ] );
		}
		$this->end_controls_section();
		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'c_accent', [ 'label' => __( 'Color principal', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}}' => '--wkt-primary: {{VALUE}};' ] ] );
		$this->add_control( 'c_gold', [ 'label' => __( 'Color de acento', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}}' => '--wkt-accent: {{VALUE}};' ] ] );
		$this->add_control( 'c_radius', [ 'label' => __( 'Redondez (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 30, 'selectors' => [ '{{WRAPPER}}' => '--wkt-radius: {{VALUE}}px;' ] ] );
		$this->end_controls_section();
	}

	protected function t( $id ) {
		$v = $this->get_settings_for_display( 'lbl_' . $id );
		if ( null === $v || '' === $v ) { $v = $this->texts()[ $id ][1] ?? ''; }
		return Module::tr( (string) $v );
	}

	protected function e( $id ) { echo esc_html( $this->t( $id ) ); }

	protected function here() {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
		return remove_query_arg( [ 'wkt', 'wkt_code', 'wkt_w' ], home_url( $uri ) );
	}

	protected function in_editor() {
		return class_exists( '\Elementor\Plugin' ) && ( \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode() );
	}

	/** Message from the last form (?wkt=code), as a live region, only in the widget that sent it (?wkt_w=id). */
	protected function notice() {
		$c = isset( $_GET['wkt'] ) ? sanitize_key( wp_unslash( $_GET['wkt'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$m = Forms::messages()[ $c ] ?? null;
		if ( ! $m ) { return; }
		$w = $this->get( 'wkt_w' );
		if ( '' !== $w && $w !== $this->get_id() ) { return; }
		if ( '' === $w && 'login' !== $c && ! $this->owns_notice() ) { return; }
		$extra = '';
		if ( 'case_ok' === $c && ! empty( $_GET['wkt_code'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$extra = ' <strong>' . esc_html( preg_replace( '/[^A-Z0-9\-]/', '', strtoupper( sanitize_text_field( wp_unslash( $_GET['wkt_code'] ) ) ) ) ) . '</strong>'; // phpcs:ignore WordPress.Security.NonceVerification
		}
		echo '<div id="wkt-n-' . esc_attr( $this->get_id() ) . '" tabindex="-1" class="wkt-notice wkt-notice--' . esc_attr( $m[0] ) . '" role="' . ( 'err' === $m[0] ? 'alert' : 'status' ) . '">' . esc_html( $m[1] ) . $extra . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	/** Without ?wkt_w (links from e-mails, old bookmarks) the first widget printing a notice shows it. */
	private function owns_notice() {
		static $done = false;
		if ( $done ) { return false; }
		$done = true;
		return true;
	}

	/** Opening of a front form posting to admin-post.php. $back: page to return to (default: this one). */
	protected function form_open( $action, $files = false, $cls = '', $back = '' ) {
		$back = add_query_arg( 'wkt_w', $this->get_id(), $back ?: $this->here() ) . '#wkt-n-' . $this->get_id();
		echo '<form class="wkt-form ' . esc_attr( $cls ) . '" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"' . ( $files ? ' enctype="multipart/form-data"' : '' ) . ' novalidate>';
		echo '<input type="hidden" name="action" value="wakoo_t_' . esc_attr( $action ) . '">';
		echo '<input type="hidden" name="_wkt" value="' . esc_attr( wp_create_nonce( 'wakoo_t_' . $action ) ) . '">';
		echo '<input type="hidden" name="_back" value="' . esc_attr( $back ) . '">';
		echo '<div class="wkt-hp" aria-hidden="true"><label>Web <input type="text" name="wkt_hp" tabindex="-1" autocomplete="off"></label></div>';
	}

	/** One labelled field. $type: text | email | password | number | date | url | textarea | select | file. */
	protected function field( $name, $label, $type = 'text', $args = [] ) {
		$id   = 'wkt-' . $this->get_id() . '-' . $name;
		$req  = ! empty( $args['required'] );
		$val  = (string) ( $args['value'] ?? '' );
		$help = $args['help'] ?? '';
		$attr = ( $req ? ' required aria-required="true"' : '' ) . ( $help ? ' aria-describedby="' . esc_attr( $id ) . '-h"' : '' ) . ( ! empty( $args['attr'] ) ? ' ' . $args['attr'] : '' );
		echo '<div class="wkt-field' . ( ! empty( $args['wide'] ) ? ' wkt-field--wide' : '' ) . '"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . ( $req ? ' <span class="wkt-req" aria-hidden="true">*</span>' : '' ) . '</label>';
		switch ( $type ) {
			case 'textarea':
				echo '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" rows="' . (int) ( $args['rows'] ?? 5 ) . '"' . $attr . '>' . esc_textarea( $val ) . '</textarea>'; // phpcs:ignore WordPress.Security.EscapeOutput
				break;
			case 'select':
				echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '"' . $attr . '>'; // phpcs:ignore WordPress.Security.EscapeOutput
				foreach ( (array) ( $args['options'] ?? [] ) as $k => $l ) { echo '<option value="' . esc_attr( $k ) . '"' . selected( $val, (string) $k, false ) . '>' . esc_html( $l ) . '</option>'; }
				echo '</select>';
				break;
			case 'file':
				echo '<input type="file" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '[]" multiple accept=".pdf,.jpg,.jpeg,.png,.webp,.doc,.docx,.xls,.xlsx,.odt,.ods,.csv,.txt,.zip"' . $attr . '>'; // phpcs:ignore WordPress.Security.EscapeOutput
				break;
			default:
				echo '<input type="' . esc_attr( $type ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '"' . $attr . '>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		if ( $help ) { echo '<small id="' . esc_attr( $id ) . '-h" class="wkt-help">' . esc_html( $help ) . '</small>'; }
		echo '</div>';
	}

	protected function check( $name, $label, $checked = false, $required = false ) {
		echo '<label class="wkt-check"><input type="checkbox" name="' . esc_attr( $name ) . '" value="1"' . checked( $checked, true, false ) . ( $required ? ' required aria-required="true"' : '' ) . '> <span>' . wp_kses( $label, [ 'a' => [ 'href' => [], 'target' => [] ] ] ) . '</span></label>';
	}

	/** Options of a taxonomy for a select: [ '' => $all, id => name ]. */
	protected function term_options( $tax, $all = '' ) {
		$o = [ '' => $all ];
		$terms = get_terms( [ 'taxonomy' => $tax, 'hide_empty' => false, 'orderby' => 'term_order', 'order' => 'ASC' ] );
		if ( is_array( $terms ) ) {
			usort( $terms, function ( $a, $b ) { return ( (int) get_term_meta( $a->term_id, 'wk_order', true ) <=> (int) get_term_meta( $b->term_id, 'wk_order', true ) ) ?: strcmp( $a->name, $b->name ); } );
			foreach ( $terms as $t ) { $o[ $t->term_id ] = Module::term_label( $t ); }
		}
		return $o;
	}

	/** Sign-in invitation for private panels. */
	protected function login_box( $text ) {
		$acc = Module::page_url( 'access', [ 'volver' => rawurlencode( $this->here() ) ] );
		echo '<div class="wkt-card wkt-login"><p>' . esc_html( $text ) . '</p><p class="wkt-actions">';
		echo '<a class="wkt-btn" href="' . esc_url( $acc ?: wp_login_url( $this->here() ) ) . '">' . esc_html__( 'Iniciar sesión o crear cuenta', 'wakoo' ) . '</a></p></div>';
	}

	protected function badge( $text, $kind = '' ) {
		return '<span class="wkt-badge' . ( $kind ? ' wkt-badge--' . esc_attr( $kind ) : '' ) . '">' . esc_html( $text ) . '</span>';
	}

	/** Pagination links keeping the current filters. */
	protected function pager( $page, $pages, $param = 'pg' ) {
		if ( $pages < 2 ) { return; }
		echo '<nav class="wkt-pager" aria-label="' . esc_attr__( 'Paginación', 'wakoo' ) . '">';
		for ( $i = 1; $i <= $pages; $i++ ) {
			$u = add_query_arg( $param, $i, $this->here() );
			echo $i === $page ? '<span aria-current="page">' . (int) $i . '</span>' : '<a href="' . esc_url( $u ) . '">' . (int) $i . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</nav>';
	}

	protected function get( $k ) {
		return isset( $_GET[ $k ] ) ? sanitize_text_field( wp_unslash( $_GET[ $k ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	}

	/** Post shown by a "sheet" widget: the single being viewed, a chosen one, or (editor) the latest. */
	protected function current( $type, $chosen = 0 ) {
		$q = get_queried_object();
		if ( $q instanceof \WP_Post && $type === $q->post_type ) { return $q; }
		if ( $chosen && ( $p = get_post( (int) $chosen ) ) && $type === $p->post_type ) { return $p; }
		if ( $this->in_editor() ) {
			$l = get_posts( [ 'post_type' => $type, 'numberposts' => 1, 'post_status' => 'publish' ] );
			return $l ? $l[0] : null;
		}
		return null;
	}

	/** Lines "Título|URL" → links. */
	protected function link_lines( $text ) {
		$out = [];
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $l ) {
			$p = array_map( 'trim', explode( '|', $l, 2 ) );
			if ( ! empty( $p[1] ) && wp_http_validate_url( $p[1] ) || ( ! empty( $p[1] ) && 0 === strpos( $p[1], '/' ) ) ) { $out[] = [ $p[0] ?: $p[1], $p[1] ]; }
			elseif ( '' !== $p[0] ) { $out[] = [ $p[0], '' ]; }
		}
		return $out;
	}
}
