<?php
/**
 * «Mapa del territorio (Wakoo)»: Leaflet + OpenStreetMap (bundled Leaflet, tiles from the
 * provider set in Ajustes). Shows only public geodata layers and projects whose location is
 * verified; nothing is placed on the map without coordinates someone entered with a source.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class W_Gis extends Base {

	public function get_name() { return 'wakoo-t-gis'; }
	public function get_title() { return __( 'Mapa del territorio (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-google-maps'; }
	public function get_keywords() { return [ 'mapa', 'gis', 'leaflet', 'capas', 'territorio', 'proyectos', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-territorio', 'wakoo-territorio-map' ]; }
	public function get_style_depends() { return [ 'wakoo-leaflet', 'wakoo-territorio' ]; }

	protected function controls() {
		$this->start_controls_section( 'sec_main', [ 'label' => __( 'Mapa', 'wakoo' ) ] );
		$this->add_responsive_control( 'height', [ 'label' => __( 'Alto (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 560, 'min' => 240, 'max' => 1200, 'selectors' => [ '{{WRAPPER}} .wkt-gis__map' => 'height: {{VALUE}}px;' ] ] );
		$this->add_control( 'projects', [ 'label' => __( 'Capa de proyectos (solo ubicaciones verificadas)', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'sector', [ 'label' => __( 'Solo proyectos del sector (slug, opcional)', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$this->add_control( 'filter', [ 'label' => __( 'Filtro por sector sobre el mapa', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'center', [ 'label' => __( 'Centro «lat,lng» (vacío = el de Ajustes)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'description' => __( 'Solo encuadra la vista: no marca ningún punto.', 'wakoo' ) ] );
		$this->add_control( 'zoom', [ 'label' => __( 'Zoom inicial (vacío = el de Ajustes)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 3, 'max' => 18 ] );
		$this->end_controls_section();
	}

	protected function texts() {
		return [
			'label'    => [ __( 'Descripción accesible', 'wakoo' ), __( 'Mapa interactivo del territorio con capas de información verificada', 'wakoo' ) ],
			'layers'   => [ __( 'Título: capas', 'wakoo' ), __( 'Capas', 'wakoo' ) ],
			'projects' => [ __( 'Capa de proyectos', 'wakoo' ), __( 'Proyectos con ubicación verificada', 'wakoo' ) ],
			'sector'   => [ __( 'Filtro: sector', 'wakoo' ), __( 'Sector', 'wakoo' ) ],
			'all'      => [ __( 'Filtro: todos', 'wakoo' ), __( 'Todos los sectores', 'wakoo' ) ],
			'empty'    => [ __( 'Sin capas', 'wakoo' ), __( 'Todavía no hay capas públicas con información verificada. Las capas se publican a medida que las instituciones responsables validan cada dato y su fuente.', 'wakoo' ) ],
			'pending'  => [ __( 'Ubicaciones pendientes', 'wakoo' ), __( '%d proyectos de la cartera aún no tienen una ubicación verificada y por eso no aparecen en el mapa.', 'wakoo' ) ],
			'verified' => [ __( 'Etiqueta: verificado', 'wakoo' ), __( 'Información verificada', 'wakoo' ) ],
			'unverif'  => [ __( 'Etiqueta: sin verificar', 'wakoo' ), __( 'Pendiente de validación', 'wakoo' ) ],
			'source'   => [ __( 'Etiqueta: fuente', 'wakoo' ), __( 'Fuente', 'wakoo' ) ],
			'more'     => [ __( 'Enlace: ficha', 'wakoo' ), __( 'Ver ficha', 'wakoo' ) ],
			'note'     => [ __( 'Nota al pie', 'wakoo' ), __( 'Cartografía base © colaboradores de OpenStreetMap. Las capas muestran solo información con fuente; no sustituyen levantamientos técnicos ni documentos oficiales.', 'wakoo' ) ],
		];
	}

	private function layers() {
		$out = [];
		$terms = get_terms( [ 'taxonomy' => Module::T_LAYER, 'hide_empty' => false ] );
		foreach ( is_array( $terms ) ? $terms : [] as $t ) {
			if ( 'no' === get_term_meta( $t->term_id, 'wk_public', true ) ) { continue; }
			$feats = [];
			foreach ( get_posts( [ 'post_type' => Module::GEO, 'post_status' => 'publish', 'numberposts' => 500, 'tax_query' => [ [ 'taxonomy' => Module::T_LAYER, 'terms' => $t->term_id ] ] ] ) as $g ) { // phpcs:ignore WordPress.DB.SlowDBQuery
				if ( 'yes' !== Module::meta( $g->ID, 'public' ) ) { continue; }
				$f = [ 'name' => $g->post_title, 'desc' => wp_strip_all_tags( $g->post_content ), 'ok' => 'yes' === Module::meta( $g->ID, 'verified' ), 'src' => (string) Module::meta( $g->ID, 'source' ), 'date' => (string) Module::meta( $g->ID, 'date' ), 'url' => esc_url_raw( (string) Module::meta( $g->ID, 'url' ) ) ];
				$geo = json_decode( (string) Module::meta( $g->ID, 'geojson' ), true );
				if ( is_array( $geo ) && ! empty( $geo['type'] ) ) {
					$f['geo'] = $geo;
				} elseif ( is_numeric( Module::meta( $g->ID, 'lat' ) ) && is_numeric( Module::meta( $g->ID, 'lng' ) ) ) {
					$f['pt'] = [ (float) Module::meta( $g->ID, 'lat' ), (float) Module::meta( $g->ID, 'lng' ) ];
				} else {
					continue;
				}
				$feats[] = $f;
			}
			if ( $feats ) { $out[] = [ 'name' => Module::term_label( $t ), 'color' => sanitize_hex_color( get_term_meta( $t->term_id, 'wk_color', true ) ) ?: '#174A7E', 'items' => $feats ]; }
		}
		return $out;
	}

	private function projects( $sector, &$pending ) {
		$args = [ 'post_type' => Module::PROJECT, 'post_status' => 'publish', 'numberposts' => 500 ];
		if ( $sector ) { $args['tax_query'] = [ [ 'taxonomy' => Module::T_SECTOR, 'field' => 'slug', 'terms' => $sector ] ]; } // phpcs:ignore WordPress.DB.SlowDBQuery
		$out = [];
		$pending = 0;
		foreach ( Module::lang_posts( $args ) as $p ) {
			$lat = Module::meta( $p->ID, 'lat' );
			$lng = Module::meta( $p->ID, 'lng' );
			if ( 'yes' !== Module::meta( $p->ID, 'geo_ok' ) || ! is_numeric( $lat ) || ! is_numeric( $lng ) ) { $pending++; continue; }
			$out[] = [ 'name' => $p->post_title, 'pt' => [ (float) $lat, (float) $lng ], 'ok' => true, 'src' => (string) Module::meta( $p->ID, 'geo_source' ), 'url' => get_permalink( $p ), 'stage' => Module::stages()[ Module::meta( $p->ID, 'stage', 'conceptual' ) ] ?? '', 'sectors' => wp_list_pluck( Module::terms( $p->ID, Module::T_SECTOR ), 'slug' ) ];
		}
		return $out;
	}

	protected function render() {
		$s   = $this->get_settings_for_display();
		$set = Module::settings();
		$c   = array_map( 'floatval', explode( ',', (string) ( trim( (string) ( $s['center'] ?? '' ) ) ?: $set['center'] ) ) );
		$pending = 0;
		$layers  = $this->layers();
		$prj     = 'yes' === ( $s['projects'] ?? '' ) ? $this->projects( sanitize_title( (string) ( $s['sector'] ?? '' ) ), $pending ) : [];
		$cfg = [
			'center'   => [ $c[0] ?? 8.35, $c[1] ?? -64.15 ],
			'zoom'     => (int) ( ( $s['zoom'] ?? '' ) ?: $set['zoom'] ),
			'tiles'    => esc_url_raw( $set['tiles'] ),
			'attr'     => wp_kses( $set['attr'], [ 'a' => [ 'href' => [] ] ] ),
			'layers'   => $layers,
			'projects' => $prj ? [ 'name' => $this->t( 'projects' ), 'color' => '#C5A15B', 'items' => $prj ] : null,
			'i18n'     => [ 'ok' => $this->t( 'verified' ), 'ko' => $this->t( 'unverif' ), 'src' => $this->t( 'source' ), 'more' => $this->t( 'more' ) ],
		];
		echo '<div class="wkt wkt-gis" data-wkt-gis="' . esc_attr( wp_json_encode( $cfg ) ) . '">';
		$sectors = [];
		foreach ( $prj as $p ) { $sectors = array_merge( $sectors, $p['sectors'] ); }
		if ( 'yes' === ( $s['filter'] ?? '' ) && count( array_unique( $sectors ) ) > 1 ) {
			echo '<div class="wkt-filters"><div class="wkt-field"><label for="wkt-gis-' . esc_attr( $this->get_id() ) . '">' . esc_html( $this->t( 'sector' ) ) . '</label><select id="wkt-gis-' . esc_attr( $this->get_id() ) . '" data-wkt-gis-sector><option value="">' . esc_html( $this->t( 'all' ) ) . '</option>';
			foreach ( array_unique( $sectors ) as $slug ) {
				$t = get_term_by( 'slug', $slug, Module::T_SECTOR );
				if ( $t ) { echo '<option value="' . esc_attr( $slug ) . '">' . esc_html( Module::term_label( $t ) ) . '</option>'; }
			}
			echo '</select></div></div>';
		}
		echo '<div class="wkt-gis__wrap"><div class="wkt-gis__map" role="region" aria-label="' . esc_attr( $this->t( 'label' ) ) . '"></div>';
		echo '<aside class="wkt-gis__panel"><h3 class="wkt-h">' . esc_html( $this->t( 'layers' ) ) . '</h3><div class="wkt-gis__toggles" data-wkt-gis-toggles></div>';
		if ( ! $layers && ! $prj ) { echo '<p class="wkt-empty">' . esc_html( $this->t( 'empty' ) ) . '</p>'; }
		if ( $pending ) { echo '<p class="wkt-small wkt-muted">' . esc_html( sprintf( $this->t( 'pending' ), $pending ) ) . '</p>'; }
		echo '</aside></div><p class="wkt-small wkt-muted">' . esc_html( $this->t( 'note' ) ) . '</p></div>';
	}
}
