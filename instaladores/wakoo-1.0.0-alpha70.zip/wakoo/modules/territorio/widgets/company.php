<?php
/**
 * «Perfil de empresa»: public profile (only owner-authorised contact fields), verification
 * level and a contact / quote form that goes to the owner's panel (no email exposed).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class W_Company extends Base {

	public function get_name() { return 'wakoo-t-company'; }
	public function get_title() { return __( 'Perfil de empresa (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-person'; }
	public function get_keywords() { return [ 'empresa', 'perfil', 'proveedor', 'cotizacion', 'wakoo' ]; }

	protected function controls() {
		$this->start_controls_section( 'sec_main', [ 'label' => __( 'Empresa', 'wakoo' ) ] );
		$this->add_control( 'company', [ 'label' => __( 'Empresa (ID; vacío = la que se está viendo)', 'wakoo' ), 'type' => Controls_Manager::NUMBER ] );
		$this->end_controls_section();
	}

	protected function texts() {
		return [
			'about'   => [ __( 'Título: presentación', 'wakoo' ), __( 'Presentación', 'wakoo' ) ],
			'products'=> [ __( 'Título: productos', 'wakoo' ), __( 'Productos y servicios', 'wakoo' ) ],
			'caps'    => [ __( 'Título: capacidades', 'wakoo' ), __( 'Capacidades técnicas', 'wakoo' ) ],
			'equip'   => [ __( 'Título: equipos', 'wakoo' ), __( 'Equipos disponibles', 'wakoo' ) ],
			'certs'   => [ __( 'Título: certificaciones', 'wakoo' ), __( 'Certificaciones declaradas', 'wakoo' ) ],
			'level'   => [ __( 'Título: verificación', 'wakoo' ), __( 'Nivel de verificación', 'wakoo' ) ],
			'homol'   => [ __( 'Homologada por', 'wakoo' ), __( 'Homologada como proveedor por', 'wakoo' ) ],
			'contact' => [ __( 'Título: contacto', 'wakoo' ), __( 'Contacto', 'wakoo' ) ],
			'web'     => [ __( 'Sitio web', 'wakoo' ), __( 'Sitio web', 'wakoo' ) ],
			'email'   => [ __( 'Correo', 'wakoo' ), __( 'Correo', 'wakoo' ) ],
			'phone'   => [ __( 'Teléfono', 'wakoo' ), __( 'Teléfono', 'wakoo' ) ],
			'address' => [ __( 'Dirección', 'wakoo' ), __( 'Dirección', 'wakoo' ) ],
			'no_pub'  => [ __( 'Sin datos públicos', 'wakoo' ), __( 'La empresa no ha publicado datos de contacto. Escríbale con el formulario: su mensaje llegará a su panel.', 'wakoo' ) ],
			'form'    => [ __( 'Título: formulario', 'wakoo' ), __( 'Enviar una consulta o solicitar cotización', 'wakoo' ) ],
			'kind'    => [ __( 'Campo: tipo', 'wakoo' ), __( 'Tipo de mensaje', 'wakoo' ) ],
			'k_c'     => [ __( 'Tipo: contacto', 'wakoo' ), __( 'Contacto comercial', 'wakoo' ) ],
			'k_q'     => [ __( 'Tipo: cotización', 'wakoo' ), __( 'Solicitud de cotización', 'wakoo' ) ],
			'subject' => [ __( 'Campo: asunto', 'wakoo' ), __( 'Asunto', 'wakoo' ) ],
			'message' => [ __( 'Campo: mensaje', 'wakoo' ), __( 'Mensaje (detalle cantidades, plazos y lugar de entrega si pide cotización)', 'wakoo' ) ],
			'send'    => [ __( 'Botón: enviar', 'wakoo' ), __( 'Enviar consulta', 'wakoo' ) ],
			'login'   => [ __( 'Sin sesión', 'wakoo' ), __( 'Inicie sesión para contactar con esta empresa. Su consulta quedará registrada en su panel.', 'wakoo' ) ],
			'ref'     => [ __( 'Aviso: perfil de referencia', 'wakoo' ), __( 'Perfil de referencia elaborado por el portal con información pública. La empresa todavía no lo administra ni ha validado estos datos.', 'wakoo' ) ],
			'sources' => [ __( 'Título: fuentes', 'wakoo' ), __( 'Fuentes públicas consultadas', 'wakoo' ) ],
			'no_acc'  => [ __( 'Sin cuenta de la empresa', 'wakoo' ), __( 'Esta empresa aún no tiene cuenta en el portal, así que no puede recibir mensajes por aquí. Use los canales oficiales de la empresa.', 'wakoo' ) ],
			'note'    => [ __( 'Aviso', 'wakoo' ), __( 'El portal pone en contacto a las empresas. No interviene en precios, contratos ni adjudicaciones.', 'wakoo' ) ],
		];
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$c = $this->current( Module::COMPANY, $s['company'] ?? 0 );
		if ( ! $c || ( 'publish' !== $c->post_status && ! current_user_can( 'edit_post', $c->ID ) ) ) { echo '<div class="wkt-empty">' . esc_html__( 'Empresa no disponible.', 'wakoo' ) . '</div>'; return; }
		$m   = function ( $k ) use ( $c ) { return (string) Module::meta( $c->ID, $k ); };
		$lv  = $m( 'level' ) ?: 'registrada';
		$pub = (array) Module::meta( $c->ID, 'public', [] );
		echo '<article class="wkt wkt-sheet">';
		$this->notice();
		echo '<header class="wkt-sheet__head"><p class="wkt-sheet__meta">' . $this->badge( Module::levels()[ $lv ] ?? '', 'lvl-' . $lv ) . '<span>' . esc_html( implode( ' · ', array_filter( [ Module::term_names( $c->ID, Module::T_CCAT ), Module::term_names( $c->ID, Module::T_SECTOR ), Module::term_names( $c->ID, Module::T_MUN ) ] ) ) ) . '</span></p><h1 class="wkt-sheet__title">' . esc_html( $c->post_title ) . '</h1></header>'; // phpcs:ignore WordPress.Security.EscapeOutput
		$src = array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $m( 'source' ) ) ) );
		if ( 'referencia' === $lv ) { echo '<div class="wkt-refnote" role="note"><p>' . esc_html( $this->t( 'ref' ) ) . '</p></div>'; }
		echo '<div class="wkt-sheet__body"><div class="wkt-sheet__main"><section><h2 class="wkt-h">' . esc_html( $this->t( 'about' ) ) . '</h2><div class="wkt-prose">' . wp_kses_post( wpautop( esc_html( $c->post_content ) ) ) . '</div></section>';
		foreach ( [ 'products' => 'products', 'capabilities' => 'caps', 'equipment' => 'equip', 'certs' => 'certs' ] as $k => $t ) {
			if ( '' === $m( $k ) ) { continue; }
			echo '<section><h2 class="wkt-h">' . esc_html( $this->t( $t ) ) . '</h2><ul class="wkt-list">';
			foreach ( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $m( $k ) ) ) ) as $l ) { echo '<li>' . esc_html( ltrim( $l, '-•· ' ) ) . '</li>'; }
			echo '</ul></section>';
		}
		if ( $src ) {
			echo '<section><h2 class="wkt-h">' . esc_html( $this->t( 'sources' ) ) . '</h2><ul class="wkt-sources">';
			foreach ( $src as $l ) {
				$p = array_map( 'trim', explode( '|', $l, 2 ) );
				echo '<li>' . ( ! empty( $p[1] ) ? '<a href="' . esc_url( $p[1] ) . '" rel="nofollow noopener" target="_blank">' . esc_html( $p[0] ) . '</a>' : esc_html( $p[0] ) ) . '</li>';
			}
			echo '</ul></section>';
		}
		echo '</div><aside class="wkt-sheet__side"><section class="wkt-card"><h2 class="wkt-h">' . esc_html( $this->t( 'level' ) ) . '</h2>' . $this->badge( Module::levels()[ $lv ] ?? '', 'lvl-' . $lv ); // phpcs:ignore WordPress.Security.EscapeOutput
		if ( 'homologada' === $lv && $m( 'homologated' ) ) { echo '<p class="wkt-small">' . esc_html( $this->t( 'homol' ) ) . ': ' . esc_html( implode( ', ', array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $m( 'homologated' ) ) ) ) ) ) . '</p>'; }
		echo '</section><section class="wkt-card"><h2 class="wkt-h">' . esc_html( $this->t( 'contact' ) ) . '</h2>';
		$shown = 0;
		echo '<dl class="wkt-dl">';
		foreach ( [ 'web', 'email', 'phone', 'address' ] as $k ) {
			if ( ! in_array( $k, $pub, true ) || '' === $m( $k ) ) { continue; }
			$v = $m( $k );
			$h = 'web' === $k ? '<a href="' . esc_url( $v ) . '" rel="nofollow noopener" target="_blank">' . esc_html( preg_replace( '#^https?://#', '', $v ) ) . '</a>' : ( 'email' === $k ? '<a href="mailto:' . esc_attr( antispambot( $v ) ) . '">' . esc_html( antispambot( $v ) ) . '</a>' : ( 'phone' === $k ? '<a href="tel:' . esc_attr( preg_replace( '/[^0-9+]/', '', $v ) ) . '">' . esc_html( $v ) . '</a>' : esc_html( $v ) ) );
			echo '<div><dt>' . esc_html( $this->t( $k ) ) . '</dt><dd>' . $h . '</dd></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
			$shown++;
		}
		echo '</dl>' . ( $shown ? '' : '<p class="wkt-muted">' . esc_html( $this->t( 'no_pub' ) ) . '</p>' ) . '</section></aside></div>';
		echo '<section class="wkt-card wkt-rfq"><h2 class="wkt-h">' . esc_html( $this->t( 'form' ) ) . '</h2>';
		if ( ! Module::has_owner( $c ) ) {
			echo '<p class="wkt-muted">' . esc_html( $this->t( 'no_acc' ) ) . '</p>';
		} elseif ( ! is_user_logged_in() ) {
			$this->login_box( $this->t( 'login' ) );
		} elseif ( (int) $c->post_author !== get_current_user_id() ) {
			$this->form_open( 'rfq', false, 'wkt-grid-form' );
			echo '<input type="hidden" name="to" value="' . (int) $c->ID . '">';
			$this->field( 'kind', $this->t( 'kind' ), 'select', [ 'options' => [ 'contacto' => $this->t( 'k_c' ), 'cotizacion' => $this->t( 'k_q' ) ] ] );
			$this->field( 'subject', $this->t( 'subject' ), 'text', [ 'required' => true, 'attr' => 'maxlength="160"' ] );
			$this->field( 'message', $this->t( 'message' ), 'textarea', [ 'required' => true, 'wide' => true, 'attr' => 'minlength="20"' ] );
			echo '<div class="wkt-field wkt-field--wide"><button class="wkt-btn" type="submit">' . esc_html( $this->t( 'send' ) ) . '</button></div></form>';
		}
		echo '<p class="wkt-small wkt-muted">' . esc_html( $this->t( 'note' ) ) . '</p></section></article>';
	}
}
