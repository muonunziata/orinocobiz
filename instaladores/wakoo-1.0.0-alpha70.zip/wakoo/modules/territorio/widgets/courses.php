<?php
/**
 * «Cursos de la academia (Wakoo)»: course catalogue, optionally grouped by school. Two layouts:
 * cards, or compact icon tiles (filterable by school) that open the course in a popup.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class W_Courses extends Base {

	public function get_name() { return 'wakoo-t-courses'; }
	public function get_title() { return __( 'Cursos de la academia (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-library-open'; }
	public function get_keywords() { return [ 'academia', 'cursos', 'formación', 'escuelas', 'lms', 'wakoo' ]; }

	protected function controls() {
		$this->start_controls_section( 'sec_main', [ 'label' => __( 'Cursos', 'wakoo' ) ] );
		$this->add_control( 'layout', [ 'label' => __( 'Diseño', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'cards', 'options' => [ 'cards' => __( 'Tarjetas', 'wakoo' ), 'icons' => __( 'Iconos con ventana emergente', 'wakoo' ) ] ] );
		$this->add_control( 'school', [ 'label' => __( 'Solo la escuela (slug, opcional)', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$this->add_control( 'group', [ 'label' => __( 'Agrupar por escuela', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'demo', [ 'label' => __( 'Incluir cursos de demostración', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'cols', [ 'label' => __( 'Columnas', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => '3', 'options' => [ '1' => '1', '2' => '2', '3' => '3', '4' => '4' ], 'selectors' => [ '{{WRAPPER}} .wkt-grid' => '--cols: {{VALUE}};' ], 'condition' => [ 'layout' => 'cards' ] ] );
		$this->add_responsive_control( 'tile', [ 'label' => __( 'Ancho mínimo del icono (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 90, 'max' => 320, 'default' => 150, 'selectors' => [ '{{WRAPPER}} .wkt-ctiles' => '--tile: {{VALUE}}px;' ], 'condition' => [ 'layout' => 'icons' ] ] );
		$this->end_controls_section();
	}

	protected function texts() {
		return [
			'empty'  => [ __( 'Sin cursos', 'wakoo' ), __( 'La oferta de cursos de esta escuela está en diseño.', 'wakoo' ) ],
			'open'   => [ __( 'Estado: abierto', 'wakoo' ), __( 'Inscripción abierta', 'wakoo' ) ],
			'design' => [ __( 'Estado: en diseño', 'wakoo' ), __( 'En diseño · registre su interés', 'wakoo' ) ],
			'closed' => [ __( 'Estado: cerrado', 'wakoo' ), __( 'Cerrado', 'wakoo' ) ],
			'demo'   => [ __( 'Etiqueta: demostración', 'wakoo' ), __( 'Curso de demostración', 'wakoo' ) ],
			'hours'  => [ __( 'Horas (%s)', 'wakoo' ), __( '%s horas', 'wakoo' ) ],
			'free'   => [ __( 'Gratuito', 'wakoo' ), __( 'Gratuito', 'wakoo' ) ],
			'more'   => [ __( 'Enlace', 'wakoo' ), __( 'Ver el curso', 'wakoo' ) ],
			'all'    => [ __( 'Filtro: todas', 'wakoo' ), __( 'Todas las escuelas', 'wakoo' ) ],
			'close'  => [ __( 'Botón: cerrar', 'wakoo' ), __( 'Cerrar', 'wakoo' ) ],
			'cost'   => [ __( 'Etiqueta: costo', 'wakoo' ), __( 'Costo', 'wakoo' ) ],
			'school' => [ __( 'Etiqueta: escuela', 'wakoo' ), __( 'Escuela', 'wakoo' ) ],
			'go'     => [ __( 'Botón: abrir curso', 'wakoo' ), __( 'Ir al curso e inscribirse', 'wakoo' ) ],
			'go_int' => [ __( 'Botón: registrar interés', 'wakoo' ), __( 'Ir al curso y registrar interés', 'wakoo' ) ],
		];
	}

	private function card( $c ) {
		$st   = Academy::status( $c->ID );
		$mode = [ 'virtual' => __( 'Virtual', 'wakoo' ), 'mixta' => __( 'Mixta', 'wakoo' ), 'presencial' => __( 'Presencial', 'wakoo' ) ][ Module::meta( $c->ID, 'mode' ) ] ?? '';
		$h    = Module::meta( $c->ID, 'hours' );
		echo '<article class="wkt-card wkt-course-card">';
		echo '<p class="wkt-badges">' . $this->badge( $this->t( $st ), 'open' === $st ? 'ok' : ( 'design' === $st ? 'info' : 'soft' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		if ( 'yes' === Module::meta( $c->ID, 'demo' ) ) { echo ' ' . $this->badge( $this->t( 'demo' ), 'warn' ); } // phpcs:ignore WordPress.Security.EscapeOutput
		echo '</p><h3 class="wkt-card__t"><a href="' . esc_url( get_permalink( $c ) ) . '">' . esc_html( $c->post_title ) . '</a></h3>';
		if ( $c->post_excerpt ) { echo '<p class="wkt-muted">' . esc_html( $c->post_excerpt ) . '</p>'; }
		echo '<p class="wkt-small wkt-muted">' . esc_html( implode( ' · ', array_filter( [ $h ? sprintf( $this->t( 'hours' ), $h ) : '', $mode, Module::meta( $c->ID, 'cost' ) ?: $this->t( 'free' ) ] ) ) ) . '</p>';
		echo '<a class="wkt-more-link" href="' . esc_url( get_permalink( $c ) ) . '" aria-label="' . esc_attr( $this->t( 'more' ) . ': ' . $c->post_title ) . '">' . esc_html( $this->t( 'more' ) ) . ' <span aria-hidden="true">→</span></a></article>';
	}

	/** Font Awesome icon of a course: its own, its school's, or a cap. */
	private function icon_of( $c ) {
		$i = (string) Module::meta( $c->ID, 'icon' );
		if ( '' === $i ) {
			$t = Module::terms( $c->ID, Module::T_SCHOOL );
			$i = $t ? (string) get_term_meta( $t[0]->term_id, 'wk_icon', true ) : '';
		}
		$i = preg_replace( '/[^a-z0-9 \-]/', '', strtolower( $i ) ) ?: 'fas fa-graduation-cap';
		$lib = 0 === strpos( $i, 'far ' ) ? 'fa-regular' : ( 0 === strpos( $i, 'fab ' ) ? 'fa-brands' : 'fa-solid' );
		ob_start();
		\Elementor\Icons_Manager::render_icon( [ 'value' => $i, 'library' => $lib ], [ 'aria-hidden' => 'true' ] );
		return ob_get_clean();
	}

	/** Icon layout: school chips, tiles and one <dialog> per course. */
	private function tiles( $list ) {
		$uid    = 'wkt-c-' . $this->get_id();
		$by     = [];
		$school = [];
		foreach ( $list as $c ) {
			$t = Module::terms( $c->ID, Module::T_SCHOOL );
			$school[ $c->ID ] = $t ? $t[0] : null;
			if ( $t ) { $by[ $t[0]->term_id ] = $t[0]; }
		}
		$order = array_keys( $this->term_options( Module::T_SCHOOL ) );
		usort( $list, function ( $a, $b ) use ( $order, $school ) {
			$pa = $school[ $a->ID ] ? array_search( $school[ $a->ID ]->term_id, $order, true ) : 999;
			$pb = $school[ $b->ID ] ? array_search( $school[ $b->ID ]->term_id, $order, true ) : 999;
			return ( $pa <=> $pb ) ?: ( $a->menu_order <=> $b->menu_order );
		} );
		if ( count( $by ) > 1 ) {
			echo '<div class="wkt-chips" role="group" aria-label="' . esc_attr( $this->t( 'school' ) ) . '"><button type="button" class="wkt-chip" aria-pressed="true" data-wkt-chip="">' . esc_html( $this->t( 'all' ) ) . '</button>';
			foreach ( $order as $tid ) {
				if ( '' === $tid || empty( $by[ $tid ] ) ) { continue; }
				echo '<button type="button" class="wkt-chip" aria-pressed="false" data-wkt-chip="' . (int) $tid . '">' . esc_html( Module::term_label( $by[ $tid ] ) ) . '</button>';
			}
			echo '</div>';
		}
		echo '<ul class="wkt-ctiles">';
		foreach ( $list as $c ) {
			$st = Academy::status( $c->ID );
			$sc = $school[ $c->ID ];
			echo '<li data-wkt-school="' . (int) ( $sc ? $sc->term_id : 0 ) . '"><button type="button" class="wkt-ctile wkt-ctile--' . esc_attr( $st ) . '" data-wkt-dialog="' . esc_attr( $uid . '-' . $c->ID ) . '" aria-haspopup="dialog">';
			echo '<span class="wkt-ctile__ico">' . $this->icon_of( $c ) . '</span><span class="wkt-ctile__t">' . esc_html( $c->post_title ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<span class="wkt-ctile__st">' . esc_html( 'yes' === Module::meta( $c->ID, 'demo' ) ? $this->t( 'demo' ) : $this->t( $st ) ) . '</span></button></li>';
		}
		echo '</ul>';
		foreach ( $list as $c ) {
			$st   = Academy::status( $c->ID );
			$sc   = $school[ $c->ID ];
			$mode = [ 'virtual' => __( 'Virtual', 'wakoo' ), 'mixta' => __( 'Mixta', 'wakoo' ), 'presencial' => __( 'Presencial', 'wakoo' ) ][ Module::meta( $c->ID, 'mode' ) ] ?? '';
			$h    = Module::meta( $c->ID, 'hours' );
			$id   = $uid . '-' . $c->ID;
			echo '<dialog class="wkt wkt-dialog" id="' . esc_attr( $id ) . '" aria-labelledby="' . esc_attr( $id ) . '-t"><div class="wkt-dialog__in">';
			echo '<button type="button" class="wkt-dialog__x" data-wkt-close aria-label="' . esc_attr( $this->t( 'close' ) ) . '"><span aria-hidden="true">×</span></button>';
			echo '<div class="wkt-dialog__head"><span class="wkt-ctile__ico">' . $this->icon_of( $c ) . '</span><div><p class="wkt-badges">' . $this->badge( $this->t( $st ), 'open' === $st ? 'ok' : ( 'design' === $st ? 'info' : 'soft' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
			if ( 'yes' === Module::meta( $c->ID, 'demo' ) ) { echo ' ' . $this->badge( $this->t( 'demo' ), 'warn' ); } // phpcs:ignore WordPress.Security.EscapeOutput
			echo '</p><h3 class="wkt-dialog__t" id="' . esc_attr( $id ) . '-t">' . esc_html( $c->post_title ) . '</h3>' . ( $sc ? '<p class="wkt-small wkt-muted">' . esc_html( Module::term_label( $sc ) ) . '</p>' : '' ) . '</div></div>';
			if ( $c->post_excerpt ) { echo '<p class="wkt-dialog__lead">' . esc_html( $c->post_excerpt ) . '</p>'; }
			echo '<div class="wkt-prose">' . wp_kses_post( wpautop( $c->post_content ) ) . '</div>';
			echo '<p class="wkt-small wkt-muted">' . esc_html( implode( ' · ', array_filter( [ $h ? sprintf( $this->t( 'hours' ), $h ) : '', $mode, $this->t( 'cost' ) . ': ' . ( Module::meta( $c->ID, 'cost' ) ?: $this->t( 'free' ) ) ] ) ) ) . '</p>';
			echo '<p class="wkt-actions"><a class="wkt-btn" href="' . esc_url( get_permalink( $c ) ) . '">' . esc_html( 'design' === $st ? $this->t( 'go_int' ) : $this->t( 'go' ) ) . '</a> <button type="button" class="wkt-btn wkt-btn--ghost" data-wkt-close>' . esc_html( $this->t( 'close' ) ) . '</button></p>';
			echo '</div></dialog>';
		}
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$args = [ 'post_type' => Module::COURSE, 'post_status' => 'publish', 'numberposts' => 200, 'orderby' => [ 'menu_order' => 'ASC', 'title' => 'ASC' ] ];
		if ( ! empty( $s['school'] ) ) { $args['tax_query'] = [ [ 'taxonomy' => Module::T_SCHOOL, 'field' => 'slug', 'terms' => sanitize_title( $s['school'] ) ] ]; } // phpcs:ignore WordPress.DB.SlowDBQuery
		$list = Module::lang_posts( $args );
		if ( 'yes' !== ( $s['demo'] ?? '' ) ) { $list = array_filter( $list, function ( $c ) { return 'yes' !== Module::meta( $c->ID, 'demo' ); } ); }
		echo '<div class="wkt wkt-courses">';
		if ( ! $list ) { echo '<div class="wkt-empty">' . esc_html( $this->t( 'empty' ) ) . '</div></div>'; return; }
		if ( 'icons' === ( $s['layout'] ?? '' ) ) {
			$this->tiles( array_values( $list ) );
			echo '</div>';
			return;
		}
		if ( 'yes' === ( $s['group'] ?? '' ) && empty( $s['school'] ) ) {
			$groups = [];
			foreach ( $list as $c ) {
				$t = Module::terms( $c->ID, Module::T_SCHOOL );
				$groups[ $t ? $t[0]->term_id : 0 ][] = $c;
			}
			$order = array_keys( $this->term_options( Module::T_SCHOOL ) );
			foreach ( array_merge( $order, [ 0 ] ) as $tid ) {
				if ( '' === $tid || empty( $groups[ $tid ] ) ) { continue; }
				$term = $tid ? get_term( $tid ) : null;
				echo '<section class="wkt-school"><h3 class="wkt-h">' . esc_html( $term ? Module::term_label( $term ) : '—' ) . '</h3>';
				if ( $term && $term->description ) { echo '<p class="wkt-muted">' . esc_html( $term->description ) . '</p>'; }
				echo '<div class="wkt-grid">';
				foreach ( $groups[ $tid ] as $c ) { $this->card( $c ); }
				echo '</div></section>';
			}
		} else {
			echo '<div class="wkt-grid">';
			foreach ( $list as $c ) { $this->card( $c ); }
			echo '</div>';
		}
		echo '</div>';
	}
}
