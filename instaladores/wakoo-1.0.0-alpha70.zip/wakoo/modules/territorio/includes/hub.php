<?php
/**
 * Front-end admin hub: staff (the same WordPress users) handle ventanilla cases, create
 * accounts and give companies access with a temporary password. Temporary passwords are
 * generated on the server, shown once to whoever created them and never stored in clear;
 * the account must choose its own password at the first sign-in.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

defined( 'ABSPATH' ) || die();

class Hub {

	/** User meta: the account still uses a temporary password. */
	const MUST = '_wakoo_t_must_change';

	public static function init() {
		foreach ( [ 'hub_case', 'hub_user', 'hub_company', 'hub_access', 'hub_access_all', 'hub_reset' ] as $a ) {
			add_action( 'admin_post_wakoo_t_' . $a, [ __CLASS__, $a ] );
			add_action( 'admin_post_nopriv_wakoo_t_' . $a, [ Forms::class, 'need_login' ] );
		}
		add_action( 'admin_post_wakoo_t_newpass', [ __CLASS__, 'newpass' ] );
		add_action( 'template_redirect', [ __CLASS__, 'force_front' ], 1 );
		add_action( 'admin_init', [ __CLASS__, 'force_admin' ], 1 );
		add_action( 'admin_notices', [ __CLASS__, 'admin_notice' ] );
		add_action( 'profile_update', [ __CLASS__, 'profile_changed' ], 10, 2 );
		add_filter( 'login_redirect', [ __CLASS__, 'login_redirect' ], 20, 3 );
	}

	/** Straight to «choose your password» after signing in with a temporary one. */
	public static function login_redirect( $to, $requested, $user ) {
		if ( $user instanceof \WP_User && self::must_change( $user->ID ) && ( $acc = Module::page_url( 'access' ) ) ) { return $acc; }
		return $to;
	}

	/** Roles the hub may give: subscribers and the portal roles (never administrator). */
	public static function roles() {
		$r = [ 'subscriber' => __( 'Usuario del portal (empresa, inversionista o alumno)', 'wakoo' ) ];
		foreach ( Module::role_map() as $k => $d ) { $r[ $k ] = $d[0]; }
		return $r;
	}

	public static function must_change( $uid = 0 ) {
		$uid = $uid ?: get_current_user_id();
		return $uid && get_user_meta( $uid, self::MUST, true );
	}

	/* ---------------------------------------------------------------- forced password change */

	public static function force_front() {
		if ( ! self::must_change() ) { return; }
		$acc = (int) ( Module::settings()['page_access'] ?? 0 );
		if ( ! $acc ) { wp_safe_redirect( admin_url( 'profile.php' ) ); exit; }
		$here = get_queried_object_id();
		if ( $here && ( $here === $acc || $here === Module::translated( $acc ) ) ) { return; }
		wp_safe_redirect( Module::page_url( 'access' ) );
		exit;
	}

	public static function force_admin() {
		if ( ! self::must_change() || wp_doing_ajax() ) { return; }
		$page = isset( $GLOBALS['pagenow'] ) ? $GLOBALS['pagenow'] : '';
		if ( in_array( $page, [ 'admin-post.php', 'profile.php' ], true ) ) { return; }
		$acc = Module::page_url( 'access' );
		wp_safe_redirect( $acc ?: admin_url( 'profile.php' ) );
		exit;
	}

	public static function admin_notice() {
		if ( self::must_change() ) {
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'Está usando una contraseña temporal. Elija una contraseña nueva aquí abajo para continuar.', 'wakoo' ) . '</p></div>';
		}
	}

	/** Password changed from wp-admin → profile.php: the flag goes away. */
	public static function profile_changed( $uid, $old ) {
		$u = get_userdata( $uid );
		if ( $u && $old && $u->user_pass !== $old->user_pass && get_current_user_id() === (int) $uid ) {
			delete_user_meta( $uid, self::MUST );
			Store::log( 'user', $uid, 'password', 'Contraseña temporal sustituida por el titular', 'audit', $uid );
		}
	}

	public static function newpass() {
		self::check( 'newpass' );
		$uid  = get_current_user_id();
		$pass = (string) wp_unslash( $_POST['pass'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput
		$rep  = (string) wp_unslash( $_POST['pass2'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput
		if ( strlen( $pass ) < 10 ) { Forms::back( 'password' ); }
		if ( $pass !== $rep ) { Forms::back( 'mismatch' ); }
		$u = get_userdata( $uid );
		if ( wp_check_password( $pass, $u->user_pass, $uid ) ) { Forms::back( 'samepass' ); }
		wp_set_password( $pass, $uid );
		delete_user_meta( $uid, self::MUST );
		wp_set_current_user( $uid );
		wp_set_auth_cookie( $uid, false, is_ssl() );
		Store::log( 'user', $uid, 'password', 'Contraseña temporal sustituida por el titular', 'audit', $uid );
		Forms::back( 'newpass_ok' );
	}

	/* ---------------------------------------------------------------- helpers */

	private static function check( $action, $cap = '' ) {
		if ( ! isset( $_POST['_wkt'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wkt'] ) ), 'wakoo_t_' . $action ) ) { Forms::back( 'expired' ); }
		if ( ! is_user_logged_in() ) { Forms::back( 'login' ); }
		if ( $cap && ! current_user_can( $cap ) ) { Forms::back( 'denied' ); }
	}

	/** Temporary password: random, readable (no look-alike characters), 14 characters. */
	public static function temp_password() {
		$abc = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
		$out = '';
		for ( $i = 0; $i < 12; $i++ ) { $out .= $abc[ random_int( 0, strlen( $abc ) - 1 ) ]; }
		return substr( $out, 0, 4 ) . '-' . substr( $out, 4, 4 ) . '-' . substr( $out, 8, 4 );
	}

	/** Credentials to show once to the staff member who created them (5 minutes, then gone). */
	private static function once( array $rows ) {
		set_transient( 'wkt_hub_once_' . get_current_user_id(), $rows, 5 * MINUTE_IN_SECONDS );
	}

	public static function take_once() {
		$k = 'wkt_hub_once_' . get_current_user_id();
		$v = get_transient( $k );
		delete_transient( $k );
		return is_array( $v ) ? $v : [];
	}

	/** New account with a temporary password that must be changed at the first sign-in. */
	private static function make_user( $name, $email, $role, $login = '' ) {
		$login = sanitize_user( $login ?: strtolower( strtok( $email, '@' ) ), true ) ?: 'usuario';
		$base  = $login;
		for ( $i = 2; username_exists( $login ); $i++ ) { $login = $base . $i; }
		$pass = self::temp_password();
		$uid  = wp_insert_user( [ 'user_login' => $login, 'user_email' => $email, 'user_pass' => $pass, 'display_name' => $name, 'first_name' => $name, 'role' => $role ] );
		if ( is_wp_error( $uid ) ) { return $uid; }
		update_user_meta( $uid, self::MUST, 1 );
		update_user_meta( $uid, Module::PRE . 'created_by', get_current_user_id() );
		Store::log( 'user', $uid, 'create', sprintf( 'Cuenta creada desde el hub con contraseña temporal (rol: %s)', $role ), 'audit' );
		return [ 'id' => $uid, 'login' => $login, 'pass' => $pass, 'email' => $email, 'name' => $name ];
	}

	/** Placeholder address on the reserved .invalid domain, so it can never reach anybody. */
	public static function placeholder_email( $slug ) {
		return sanitize_key( $slug ) . '@correo-pendiente.invalid';
	}

	public static function is_placeholder( $email ) {
		return (bool) preg_match( '/\.invalid$/', (string) $email );
	}

	/* ---------------------------------------------------------------- handlers */

	public static function hub_case() {
		self::check( 'hub_case', 'edit_others_wk_cases' );
		$id = (int) ( $_POST['case'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( Module::CASE_T !== get_post_type( $id ) ) { Forms::back( 'denied' ); }
		$in = [
			'status'     => sanitize_key( wp_unslash( $_POST['status'] ?? '' ) ), // phpcs:ignore WordPress.Security.NonceVerification
			'assignee'   => (int) ( $_POST['assignee'] ?? 0 ), // phpcs:ignore WordPress.Security.NonceVerification
			'checklist'  => Module::meta( $id, 'checklist', [] ),
			'public_msg' => Forms::area( 'public_msg', 4000 ),
			'internal'   => Forms::area( 'internal', 4000 ),
			'notify'     => ! empty( $_POST['notify'] ), // phpcs:ignore WordPress.Security.NonceVerification
		];
		Admin::save_case( $id, $in );
		Forms::back( 'hub_saved' );
	}

	public static function hub_user() {
		self::check( 'hub_user', 'create_users' );
		if ( ! Module::rate( 'hub_user', 60 ) ) { Forms::back( 'limit' ); }
		$name  = Forms::txt( 'name', 100 );
		$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$role  = sanitize_key( wp_unslash( $_POST['role'] ?? 'subscriber' ) ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( '' === $name || ! isset( self::roles()[ $role ] ) ) { Forms::back( 'invalid' ); }
		if ( ! is_email( $email ) || email_exists( $email ) ) { Forms::back( 'email' ); }
		$u = self::make_user( $name, $email, $role );
		if ( is_wp_error( $u ) ) { Forms::back( 'email' ); }
		self::once( [ [ $name, $u['login'], $u['pass'], $email ] ] );
		Forms::back( 'hub_user_ok' );
	}

	public static function hub_company() {
		self::check( 'hub_company', 'edit_others_wk_companys' );
		$id = (int) ( $_POST['company'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( Module::COMPANY !== get_post_type( $id ) ) { Forms::back( 'denied' ); }
		$lv = sanitize_key( wp_unslash( $_POST['level'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( isset( Module::levels()[ $lv ] ) && Module::meta( $id, 'level' ) !== $lv ) {
			update_post_meta( $id, Module::PRE . 'level', $lv );
			Store::log( Module::COMPANY, $id, 'level', sprintf( 'Nivel: %s', Module::levels()[ $lv ] ), 'internal' );
		}
		$st = sanitize_key( wp_unslash( $_POST['status'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( in_array( $st, [ 'publish', 'pending', 'draft' ], true ) && get_post_status( $id ) !== $st ) {
			wp_update_post( [ 'ID' => $id, 'post_status' => $st ] );
		}
		Forms::back( 'hub_saved' );
	}

	/** One company → its own account (the profile passes to that account). */
	private static function give_access( $id, $email = '' ) {
		$c = get_post( $id );
		if ( ! $c || Module::COMPANY !== $c->post_type ) { return null; }
		if ( Module::company_account( $c ) ) { return null; } // Already has its own account.
		$email = $email ?: self::placeholder_email( $c->post_name ?: 'empresa-' . $id );
		if ( email_exists( $email ) ) { return new \WP_Error( 'email' ); }
		$u = self::make_user( $c->post_title, $email, 'subscriber', $c->post_name );
		if ( is_wp_error( $u ) ) { return $u; }
		wp_update_post( [ 'ID' => $id, 'post_author' => $u['id'] ] );
		if ( self::is_placeholder( $email ) ) { update_user_meta( $u['id'], Module::PRE . 'email_pending', 1 ); }
		Store::log( Module::COMPANY, $id, 'access', sprintf( 'Acceso creado para la empresa (usuario %s)', $u['login'] ), 'internal' );
		return [ $c->post_title, $u['login'], $u['pass'], $email ];
	}

	public static function hub_access() {
		self::check( 'hub_access', 'create_users' );
		$id    = (int) ( $_POST['company'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification
		$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( '' !== $email && ! is_email( $email ) ) { Forms::back( 'email' ); }
		$r = self::give_access( $id, $email );
		if ( is_wp_error( $r ) ) { Forms::back( 'email' ); }
		if ( ! $r ) { Forms::back( 'denied' ); }
		self::once( [ $r ] );
		Forms::back( 'hub_access_ok' );
	}

	public static function hub_access_all() {
		self::check( 'hub_access_all', 'create_users' );
		$rows = [];
		foreach ( get_posts( [ 'post_type' => Module::COMPANY, 'post_status' => [ 'publish', 'pending', 'draft' ], 'numberposts' => 100, 'orderby' => 'title', 'order' => 'ASC' ] ) as $c ) {
			if ( 'referencia' !== Module::meta( $c->ID, 'level' ) || Module::company_account( $c ) ) { continue; }
			$r = self::give_access( $c->ID );
			if ( is_array( $r ) ) { $rows[] = $r; }
		}
		if ( ! $rows ) { Forms::back( 'hub_none' ); }
		self::once( $rows );
		Forms::back( 'hub_access_ok' );
	}

	/** New temporary password for an account (never for administrators). */
	public static function hub_reset() {
		self::check( 'hub_reset', 'edit_users' );
		$uid = (int) ( $_POST['user'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification
		$u   = get_userdata( $uid );
		if ( ! $u || user_can( $u, 'manage_options' ) || $uid === get_current_user_id() || ! current_user_can( 'edit_user', $uid ) ) { Forms::back( 'denied' ); }
		$pass = self::temp_password();
		wp_set_password( $pass, $uid );
		update_user_meta( $uid, self::MUST, 1 );
		Store::log( 'user', $uid, 'reset', 'Contraseña temporal nueva generada desde el hub', 'audit' );
		self::once( [ [ $u->display_name, $u->user_login, $pass, $u->user_email ] ] );
		Forms::back( 'hub_access_ok' );
	}
}
