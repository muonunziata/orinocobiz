/* Wakoo Territorio: small front helpers (accessible form validation). */
( function () {
	'use strict';
	function boot( root ) {
		( root || document ).querySelectorAll( '.wkt-form' ).forEach( function ( f ) {
			if ( f.dataset.wktReady ) { return; }
			f.dataset.wktReady = '1';
			f.addEventListener( 'submit', function ( e ) {
				var bad = Array.prototype.filter.call( f.querySelectorAll( '[required]' ), function ( el ) {
					if ( el.type === 'checkbox' ) { return ! el.checked; }
					if ( el.type === 'radio' ) { return ! f.querySelector( 'input[name="' + el.name + '"]:checked' ); }
					return ! String( el.value || '' ).trim();
				} );
				f.querySelectorAll( '[aria-invalid]' ).forEach( function ( el ) { el.removeAttribute( 'aria-invalid' ); } );
				if ( bad.length ) {
					e.preventDefault();
					bad.forEach( function ( el ) { el.setAttribute( 'aria-invalid', 'true' ); } );
					bad[0].focus();
					return;
				}
				var b = f.querySelector( 'button[type="submit"]' );
				if ( b ) { setTimeout( function () { b.disabled = true; }, 0 ); }
			} );
		} );
	}
	// Courses (icon layout): school chips filter the tiles; a tile opens its <dialog>.
	document.addEventListener( 'click', function ( e ) {
		var t = e.target.closest ? e.target : null;
		if ( ! t ) { return; }
		var chip = t.closest( '[data-wkt-chip]' );
		if ( chip ) {
			var box = chip.closest( '.wkt-courses' ), v = chip.getAttribute( 'data-wkt-chip' );
			box.querySelectorAll( '[data-wkt-chip]' ).forEach( function ( c ) { c.setAttribute( 'aria-pressed', c === chip ? 'true' : 'false' ); } );
			box.querySelectorAll( '[data-wkt-school]' ).forEach( function ( li ) { li.hidden = !! v && li.getAttribute( 'data-wkt-school' ) !== v; } );
			return;
		}
		var open = t.closest( '[data-wkt-dialog]' );
		if ( open ) {
			var d = document.getElementById( open.getAttribute( 'data-wkt-dialog' ) );
			if ( d && d.showModal ) { d._wktFrom = open; d.showModal(); document.documentElement.classList.add( 'wkt-modal-open' ); }
			return;
		}
		var dlg = t.closest( 'dialog.wkt-dialog' );
		if ( dlg && ( t.closest( '[data-wkt-close]' ) || t === dlg ) ) { dlg.close(); }
	} );
	document.addEventListener( 'close', function ( e ) {
		if ( ! e.target.classList || ! e.target.classList.contains( 'wkt-dialog' ) ) { return; }
		document.documentElement.classList.remove( 'wkt-modal-open' );
		if ( e.target._wktFrom ) { e.target._wktFrom.focus(); }
	}, true );

	// Hub: copy a temporary credential to the clipboard.
	document.addEventListener( 'click', function ( e ) {
		var b = e.target.closest && e.target.closest( '[data-wkt-copy]' );
		if ( ! b || ! navigator.clipboard ) { return; }
		navigator.clipboard.writeText( b.getAttribute( 'data-wkt-copy' ) ).then( function () {
			var t = b.textContent;
			b.textContent = '✓';
			setTimeout( function () { b.textContent = t; }, 1500 );
		} );
	} );
	document.addEventListener( 'DOMContentLoaded', function () { boot(); } );
	window.addEventListener( 'elementor/frontend/init', function () {
		if ( window.elementorFrontend && elementorFrontend.hooks ) {
			elementorFrontend.hooks.addAction( 'frontend/element_ready/global', function ( $el ) { boot( $el[0] ); } );
		}
	} );
} )();
