<?php
/**
 * Wakoo: Motion effects + sticky.
 *
 * Adds a "Movimiento (Wakoo)" control group to every widget, container and
 * section (Advanced tab) with three effects Elementor free doesn't offer:
 *   - Reveal on scroll (fade / fade-up / fade-down / zoom / slide) powered by
 *     Motion One (inView + animate).
 *   - Sticky on scroll via native CSS position:sticky (top or bottom + offset), with an
 *     optional scroll effect (condense / smart hide) and a reading progress bar.
 *   - 3D tilt on hover powered by vanilla-tilt.js.
 * Both libraries are MIT and bundled in vendor/ with their licences (CREDITS.txt).
 * No GSAP.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Motion;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Module {

	public static function init() {
		$control_anchors = [
			'common'    => '_section_responsive',
			'container' => 'section_layout',
			'section'   => 'section_layout',
		];
		foreach ( $control_anchors as $el => $anchor ) {
			add_action( "elementor/element/{$el}/{$anchor}/after_section_end", [ __CLASS__, 'controls' ], 10, 2 );
		}
		foreach ( [ 'widget', 'container', 'section' ] as $el ) {
			add_action( "elementor/frontend/{$el}/before_render", [ __CLASS__, 'before_render' ], 10, 1 );
		}
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
		add_action( 'elementor/preview/enqueue_scripts', [ __CLASS__, 'enqueue' ] );
	}

	public static function controls( $element, $args ) {
		$element->start_controls_section( 'wakoo_motion_section', [
			'label' => __( 'Movimiento (Wakoo)', 'wakoo' ),
			'tab'   => Controls_Manager::TAB_ADVANCED,
		] );

		// --- Reveal on scroll ---
		$element->add_control( 'wakoo_reveal', [
			'label'   => __( 'Revelar al hacer scroll', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => '',
			'options' => [
				''            => __( 'Ninguno', 'wakoo' ),
				'fade'        => __( 'Aparecer', 'wakoo' ),
				'fade-up'     => __( 'Subir y aparecer', 'wakoo' ),
				'fade-down'   => __( 'Bajar y aparecer', 'wakoo' ),
				'zoom-in'     => __( 'Acercar', 'wakoo' ),
				'slide-left'  => __( 'Entrar desde la derecha', 'wakoo' ),
				'slide-right' => __( 'Entrar desde la izquierda', 'wakoo' ),
			],
		] );
		$element->add_control( 'wakoo_reveal_duration', [
			'label'     => __( 'Duración (s)', 'wakoo' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => [ 'px' => [ 'min' => 0.1, 'max' => 3, 'step' => 0.1 ] ],
			'default'   => [ 'size' => 0.6 ],
			'condition' => [ 'wakoo_reveal!' => '' ],
		] );
		$element->add_control( 'wakoo_reveal_delay', [
			'label'     => __( 'Retardo (s)', 'wakoo' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => [ 'px' => [ 'min' => 0, 'max' => 2, 'step' => 0.1 ] ],
			'default'   => [ 'size' => 0 ],
			'condition' => [ 'wakoo_reveal!' => '' ],
		] );

		// --- Sticky ---
		$element->add_control( 'wakoo_sticky', [
			'label'        => __( 'Fijar al hacer scroll (sticky)', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => '',
			'separator'    => 'before',
		] );
		$element->add_control( 'wakoo_sticky_pos', [
			'label'     => __( 'Posición', 'wakoo' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'top',
			'options'   => [ 'top' => __( 'Arriba', 'wakoo' ), 'bottom' => __( 'Abajo', 'wakoo' ) ],
			'condition' => [ 'wakoo_sticky' => 'yes' ],
		] );
		$element->add_control( 'wakoo_sticky_offset', [
			'label'     => __( 'Separación (px)', 'wakoo' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => [ 'px' => [ 'min' => 0, 'max' => 200 ] ],
			'default'   => [ 'size' => 0 ],
			'condition' => [ 'wakoo_sticky' => 'yes' ],
		] );
		$element->add_control( 'wakoo_sticky_z', [
			'label'     => __( 'Z-index', 'wakoo' ),
			'type'      => Controls_Manager::NUMBER,
			'default'   => 100,
			'condition' => [ 'wakoo_sticky' => 'yes' ],
		] );
		$element->add_control( 'wakoo_sticky_fx', [
			'label'       => __( 'Efecto al hacer scroll', 'wakoo' ),
			'type'        => Controls_Manager::SELECT,
			'default'     => '',
			'options'     => [
				''         => __( 'Ninguno', 'wakoo' ),
				'condense' => __( 'Compactar: se reduce y gana sombra y desenfoque', 'wakoo' ),
				'smart'    => __( 'Inteligente: se esconde al bajar y vuelve al subir', 'wakoo' ),
			],
			'description' => __( 'Añade las clases wk-stuck (tras bajar unos píxeles) y wk-hidden (modo inteligente, bajando) para dar estilo propio con CSS.', 'wakoo' ),
			'condition'   => [ 'wakoo_sticky' => 'yes', 'wakoo_sticky_pos' => 'top' ],
		] );
		$element->add_control( 'wakoo_sticky_progress', [
			'label'        => __( 'Barra de progreso de lectura', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => '',
			'condition'    => [ 'wakoo_sticky' => 'yes', 'wakoo_sticky_pos' => 'top' ],
		] );
		$element->add_control( 'wakoo_sticky_progress_color', [
			'label'     => __( 'Color de la barra', 'wakoo' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#C5A15B',
			'selectors' => [ '{{WRAPPER}}' => '--wk-progress-color: {{VALUE}};' ],
			'condition' => [ 'wakoo_sticky' => 'yes', 'wakoo_sticky_progress' => 'yes' ],
		] );

		// --- Tilt ---
		$element->add_control( 'wakoo_tilt', [
			'label'        => __( 'Inclinación 3D al pasar el ratón', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => '',
			'separator'    => 'before',
		] );
		$element->add_control( 'wakoo_tilt_max', [
			'label'     => __( 'Ángulo máximo (°)', 'wakoo' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => [ 'px' => [ 'min' => 2, 'max' => 30 ] ],
			'default'   => [ 'size' => 12 ],
			'condition' => [ 'wakoo_tilt' => 'yes' ],
		] );
		$element->add_control( 'wakoo_tilt_glare', [
			'label'        => __( 'Brillo', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => '',
			'condition'    => [ 'wakoo_tilt' => 'yes' ],
		] );

		$element->end_controls_section();
	}

	public static function before_render( $element ) {
		$s = $element->get_settings_for_display();

		$reveal = $s['wakoo_reveal'] ?? '';
		$sticky = ( ! empty( $s['wakoo_sticky'] ) && 'yes' === $s['wakoo_sticky'] );
		$tilt   = ( ! empty( $s['wakoo_tilt'] ) && 'yes' === $s['wakoo_tilt'] );

		if ( ! $reveal && ! $sticky && ! $tilt ) {
			return;
		}

		if ( $reveal ) {
			$element->add_render_attribute( '_wrapper', 'class', 'wakoo-reveal' );
			$element->add_render_attribute( '_wrapper', 'data-wakoo-reveal', $reveal );
			$element->add_render_attribute( '_wrapper', 'data-wakoo-reveal-dur', (string) ( $s['wakoo_reveal_duration']['size'] ?? 0.6 ) );
			$element->add_render_attribute( '_wrapper', 'data-wakoo-reveal-delay', (string) ( $s['wakoo_reveal_delay']['size'] ?? 0 ) );
		}

		if ( $sticky ) {
			$pos    = ( 'bottom' === ( $s['wakoo_sticky_pos'] ?? 'top' ) ) ? 'bottom' : 'top';
			$offset = (int) ( $s['wakoo_sticky_offset']['size'] ?? 0 );
			$z      = (int) ( $s['wakoo_sticky_z'] ?? 100 );
			$element->add_render_attribute( '_wrapper', 'class', 'wakoo-sticky' );
			$fx = 'top' === $pos ? ( $s['wakoo_sticky_fx'] ?? '' ) : '';
			if ( in_array( $fx, [ 'condense', 'smart' ], true ) ) {
				$element->add_render_attribute( '_wrapper', 'data-wakoo-sticky-fx', $fx );
			}
			if ( 'top' === $pos && 'yes' === ( $s['wakoo_sticky_progress'] ?? '' ) ) {
				$element->add_render_attribute( '_wrapper', 'data-wakoo-sticky-progress', '1' );
			}
			$element->add_render_attribute( '_wrapper', 'style', sprintf(
				'position:sticky;%s:%dpx;z-index:%d;',
				$pos, $offset, $z
			) );
		}

		if ( $tilt ) {
			$element->add_render_attribute( '_wrapper', 'class', 'wakoo-tilt' );
			$element->add_render_attribute( '_wrapper', 'data-wakoo-tilt-max', (string) ( $s['wakoo_tilt_max']['size'] ?? 12 ) );
			if ( ! empty( $s['wakoo_tilt_glare'] ) && 'yes' === $s['wakoo_tilt_glare'] ) {
				$element->add_render_attribute( '_wrapper', 'data-wakoo-tilt-glare', '1' );
			}
		}
	}

	public static function enqueue() {
		wp_enqueue_style( 'wakoo-motion', WAKOO_MODULES_URL . 'motion/assets/motion.css', [], WAKOO_VERSION );
		wp_register_script( 'wakoo-motion-lib', WAKOO_MODULES_URL . 'motion/vendor/motion.umd.js', [], '10.18.0', true );
		wp_register_script( 'wakoo-tilt-lib', WAKOO_MODULES_URL . 'motion/vendor/vanilla-tilt.min.js', [], '1.8.1', true );
		wp_enqueue_script( 'wakoo-motion', WAKOO_MODULES_URL . 'motion/assets/motion.js', [ 'wakoo-motion-lib', 'wakoo-tilt-lib' ], WAKOO_VERSION, true );
	}
}

Module::init();
