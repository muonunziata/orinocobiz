=== Wakoo ===
Requires Plugins: elementor
Requires PHP: 8.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Widgets, Theme Builder, popups, forms and design extensions for the Elementor editor.

== Credits ==
Wakoo is a fork of Happy Elementor Addons 3.50.1 by Leevio (https://github.com/team-leevio/happy-elementor-addons),
distributed under the GNU General Public License v2 or later. The original copyright notices are kept in the source files.
Wakoo is not affiliated with Elementor Ltd. or Leevio.
