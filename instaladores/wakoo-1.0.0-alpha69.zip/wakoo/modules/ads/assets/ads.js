( function () {
	'use strict';

	var cfg = window.WakooAds || {};

	function esc( s ) {
		var d = document.createElement( 'div' );
		d.textContent = s == null ? '' : String( s );
		return d.innerHTML;
	}

	/* ------------------------------------------------------------ visitor rules */

	var store = {
		get: function ( k ) { try { return JSON.parse( localStorage.getItem( k ) || 'null' ); } catch ( e ) { return null; } },
		set: function ( k, v ) { try { localStorage.setItem( k, JSON.stringify( v ) ); } catch ( e ) {} }
	};

	/** Site-local date and time (the days/hours rules follow the site's time zone, not the visitor's). */
	function siteNow() {
		var n = new Date();
		return new Date( n.getTime() + ( n.getTimezoneOffset() + ( cfg.tz || 0 ) ) * 60000 );
	}

	function device() {
		var w = window.innerWidth || document.documentElement.clientWidth;
		return w < 768 ? 'mobile' : ( w < 1025 ? 'tablet' : 'desktop' );
	}

	/** Views of each ad today in this browser (for the daily cap). No cookies. */
	function capLog() {
		var today = siteNow().toISOString().slice( 0, 10 ), log = store.get( 'wkAdsCap' );
		if ( ! log || log.d !== today ) { log = { d: today, n: {} }; }
		return log;
	}

	function allowed( ad ) {
		var now = siteNow();
		if ( ad.devices && ad.devices.length && ad.devices.indexOf( device() ) === -1 ) { return false; }
		if ( ad.days && ad.days.length && ad.days.indexOf( now.getDay() ) === -1 ) { return false; }
		if ( ad.hours && ad.hours.length === 2 ) {
			var h = now.getHours(), from = ad.hours[ 0 ], to = ad.hours[ 1 ];
			if ( from <= to ? ( h < from || h >= to ) : ( h < from && h >= to ) ) { return false; } // 22–6 crosses midnight.
		}
		if ( ad.cap && ( capLog().n[ ad.id ] || 0 ) >= ad.cap ) { return false; }
		return true;
	}

	/** Fixed ads first (in order), then a weighted pick, skipping ads already on the page. */
	function pick( list, used ) {
		var pool = list.filter( function ( a ) { return used.indexOf( a.id ) === -1 && allowed( a ); } );
		if ( ! pool.length ) { return null; }
		var fixed = pool.filter( function ( a ) { return a.fixed; } );
		if ( fixed.length ) { pool = fixed; }
		var total = pool.reduce( function ( n, a ) { return n + ( a.w || 1 ); }, 0 ), r = Math.random() * total;
		for ( var i = 0; i < pool.length; i++ ) {
			r -= pool[ i ].w || 1;
			if ( r <= 0 ) { return pool[ i ]; }
		}
		return pool[ pool.length - 1 ];
	}

	/* ------------------------------------------------------------ drawing */

	function textPart( ad, link ) {
		return '<div class="wk-ad__txt">' + ( ad.headline ? '<p class="wk-ad__title">' + ( link ? '<a' + link + '>' + esc( ad.headline ) + '</a>' : esc( ad.headline ) ) + '</p>' : '' ) +
			( ad.text ? '<p class="wk-ad__text">' + esc( ad.text ) + '</p>' : '' ) + '</div>' +
			( link ? '<a class="wk-ad__btn"' + link + '>' + esc( ad.cta || '→' ) + '</a>' : '' );
	}

	function draw( box, ad ) {
		var body = box.querySelector( '.wk-ad__body' );
		if ( ! body ) { return; }
		var fmt = box.dataset.format, html = '',
			link = ad.href ? ' href="' + esc( ad.href ) + '" rel="sponsored noopener" target="_blank"' : '';
		box.classList.remove( 'wk-ad--k-image', 'wk-ad--k-video', 'wk-ad--k-audio', 'wk-ad--k-html', 'wk-ad--k-text' );
		box.classList.add( 'wk-ad--k-' + ad.kind );
		if ( 'html' === ad.kind ) {
			// The advertiser's code runs isolated: no access to the page, cookies or the visitor's session.
			html = '<iframe class="wk-ad__frame" title="' + esc( ad.headline || 'Ad' ) + '" sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox" loading="lazy" referrerpolicy="no-referrer"></iframe>';
			body.innerHTML = html;
			body.querySelector( 'iframe' ).srcdoc = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><base target="_blank">' +
				'<style>html,body{margin:0;height:100%;overflow:hidden}</style></head><body>' + ad.code + '</body></html>';
		} else if ( 'video' === ad.kind ) {
			html = '<a class="wk-ad__media wk-ad__media--video"' + link + ' aria-label="' + esc( ad.headline || ad.cta || '' ) + '"><video class="wk-ad__video" src="' + esc( ad.media ) + '"' +
				( ad.img ? ' poster="' + esc( ad.img ) + '"' : '' ) + ' muted autoplay loop playsinline preload="metadata"></video></a>';
			if ( 'image' !== fmt && ( ad.headline || ad.text ) ) { html += textPart( ad, link ); }
			body.innerHTML = html;
		} else if ( 'audio' === ad.kind ) {
			html = ( ad.img ? '<a class="wk-ad__media"' + link + ' tabindex="-1"><img class="wk-ad__img" src="' + esc( ad.img ) + '" alt="' + esc( ad.alt || ad.headline ) + '" loading="lazy"></a>' : '' ) +
				'<div class="wk-ad__txt">' + ( ad.headline ? '<p class="wk-ad__title"><a' + link + '>' + esc( ad.headline ) + '</a></p>' : '' ) +
				'<audio class="wk-ad__audio" controls preload="none" src="' + esc( ad.media ) + '"></audio></div>' +
				( link ? '<a class="wk-ad__btn"' + link + '>' + esc( ad.cta || '→' ) + '</a>' : '' );
			body.innerHTML = html;
		} else {
			if ( ad.img && 'text' !== ad.kind ) {
				html += '<a class="wk-ad__media"' + link + ' tabindex="-1"><img class="wk-ad__img" src="' + esc( ad.img ) + '" alt="' + esc( ad.alt || ad.headline ) + '" loading="lazy"></a>';
			}
			if ( 'image' !== fmt || ! ad.img || 'text' === ad.kind ) { html += textPart( ad, link ); }
			body.innerHTML = html;
		}
		box.dataset.ad = ad.id;
		box.classList.add( 'is-served' );
		watch( box );
	}

	/* ------------------------------------------------------------ viewable impressions */

	var queue = [], timer = null, observer = null;

	function flush() {
		timer = null;
		if ( ! queue.length ) { return; }
		var seen = cfg.api.replace( /\/ads(\?|$)/, '/ads/seen$1' ), body = JSON.stringify( { ids: queue.splice( 0, queue.length ) } );
		if ( navigator.sendBeacon ) {
			navigator.sendBeacon( seen, new Blob( [ body ], { type: 'application/json' } ) );
		} else {
			fetch( seen, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: body, keepalive: true, credentials: 'omit' } );
		}
	}

	function count( id ) {
		var log = capLog();
		log.n[ id ] = ( log.n[ id ] || 0 ) + 1;
		store.set( 'wkAdsCap', log );
		queue.push( id );
		if ( ! timer ) { timer = setTimeout( flush, 2000 ); }
	}

	/** An impression counts once at least half of the ad was on screen for one second. */
	function watch( box ) {
		var id = parseInt( box.dataset.ad, 10 );
		if ( ! id ) { return; }
		box.dataset.counted = '';
		if ( ! ( 'IntersectionObserver' in window ) ) { count( id ); box.dataset.counted = '1'; return; }
		if ( ! observer ) {
			observer = new IntersectionObserver( function ( entries ) {
				entries.forEach( function ( e ) {
					var b = e.target;
					clearTimeout( b._wkT );
					if ( e.isIntersecting && ! b.dataset.counted ) {
						b._wkT = setTimeout( function () {
							if ( b.dataset.ad && ! b.dataset.counted ) { b.dataset.counted = '1'; count( parseInt( b.dataset.ad, 10 ) ); }
						}, 1000 );
					}
				} );
			}, { threshold: 0.5 } );
		}
		observer.unobserve( box );
		observer.observe( box );
	}

	/* ------------------------------------------------------------ Google AdSense fallback */

	/** Google AdSense fills a space that has no ad, if the widget allows it (and, in basic consent mode, after marketing consent). */
	function adsense( box ) {
		var a = cfg.adsense || {}, unit = 'default' === box.dataset.adsense ? a.unit : box.dataset.adsense;
		if ( ! box.dataset.adsense || ! a.client || ! unit || box.classList.contains( 'is-adsense' ) ) { return; }
		if ( a.gate && ! ( window.WakooConsent && window.WakooConsent.has( 'marketing' ) ) ) {
			window.addEventListener( 'wakoo:consent', function on( e ) {
				if ( e.detail && e.detail.marketing ) { window.removeEventListener( 'wakoo:consent', on ); adsense( box ); }
			} );
			return;
		}
		var body = box.querySelector( '.wk-ad__body' ), label = box.querySelector( '.wk-ad__label' );
		if ( ! body ) { return; }
		if ( label && box.dataset.adsenseLabel ) { label.textContent = box.dataset.adsenseLabel; }
		body.innerHTML = '<ins class="adsbygoogle" style="display:block;width:100%" data-ad-client="' + esc( a.client ) + '" data-ad-slot="' + esc( unit ) +
			'" data-ad-format="auto" data-full-width-responsive="true"></ins>';
		box.classList.add( 'is-adsense' );
		try { ( window.adsbygoogle = window.adsbygoogle || [] ).push( {} ); } catch ( e ) {}
	}

	/* ------------------------------------------------------------ boot */

	function boot() {
		// Marketplace listings featured by the ad server: counted like any ad.
		document.querySelectorAll( '[data-wk-ad-view]:not([data-ad])' ).forEach( function ( el ) { el.dataset.ad = el.dataset.wkAdView; watch( el ); } );
		var boxes = Array.prototype.slice.call( document.querySelectorAll( '.wk-ad[data-slot]:not([data-wakoo-init])' ) );
		if ( ! boxes.length || ! cfg.api || ( window.elementorFrontend && elementorFrontend.isEditMode && elementorFrontend.isEditMode() ) ) { return; }
		boxes.forEach( function ( b ) { b.dataset.wakooInit = '1'; } );
		var slots = boxes.map( function ( b ) { return b.dataset.slot; } ),
			lang = document.documentElement.getAttribute( 'data-wakoo-lang' ) || ( document.documentElement.lang || '' ).slice( 0, 2 ).toLowerCase(),
			url = cfg.api + ( cfg.api.indexOf( '?' ) > -1 ? '&' : '?' ) + 'slots=' + encodeURIComponent( slots.join( ',' ) ) + '&lang=' + encodeURIComponent( lang ) + '&v=' + ( cfg.ver || 1 );
		fetch( url, { credentials: 'omit' } ).then( function ( r ) { return r.ok ? r.json() : { ads: [] }; } ).then( function ( data ) {
			var ads = ( data && data.ads ) || [], used = [];
			boxes.forEach( function ( box ) {
				var fit = ads.filter( function ( a ) { return a.slots.indexOf( box.dataset.slot ) > -1; } ), ad = pick( fit, used );
				if ( ad ) { used.push( ad.id ); draw( box, ad ); }
				// Rotation: another ad of this space every N seconds (only while the tab is visible).
				var every = parseInt( box.dataset.rotate || '0', 10 );
				if ( every > 0 && fit.length > 1 ) {
					setInterval( function () {
						if ( document.hidden ) { return; }
						var others = used.filter( function ( id ) { return id !== parseInt( box.dataset.ad, 10 ); } ), next = pick( fit, others.concat( [ parseInt( box.dataset.ad, 10 ) ] ) );
						if ( next ) { draw( box, next ); }
					}, every * 1000 );
				}
			} );
			boxes.forEach( function ( box ) { if ( ! box.dataset.ad ) { adsense( box ); } } );
		} ).catch( function () { boxes.forEach( adsense ); } );
		window.addEventListener( 'pagehide', flush );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}
}() );
