<?php
/**
 * Wakoo Anuncios: a small ad server for the site's own ad spaces.
 *
 * - Ads (`wakoo_ad`) are an image, a video, an audio clip, HTML code, a text
 *   ad or a marketplace listing to feature. Each one has the spaces it may
 *   appear in, languages, dates, days and hours, devices, a daily cap per
 *   visitor, a priority (fixed ads go before the rotation) and a weight.
 * - The "Espacio publicitario (Wakoo)" widget is a numbered frame (Espacio 1,
 *   2, 3… across the whole site, in page order) of a standard or custom size.
 *   It prints its own house ad; in the browser ads.js asks /wakoo/v1/ads for
 *   the live ads of the spaces on the page, applies the visitor rules, picks
 *   by priority and weight (never the same ad twice on a page) and can rotate
 *   them every N seconds. It keeps working behind page caches.
 * - Impressions are counted when at least half of the ad was on screen for a
 *   second (viewable impression), in one small request; clicks go through
 *   /?wk_ad=<id>. Totals and a 60-day history per ad feed the hub.
 * - Marketplace: «listing» ads put a member listing in the first positions of
 *   the «Marketplace de miembros» widget.
 * No cookies (the daily cap lives in the visitor's browser), no third-party service.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Ads;

defined( 'ABSPATH' ) || die();

class Module {

	const CPT     = 'wakoo_ad';
	const NS      = 'wakoo/v1';
	const SLOTS   = 'wakoo_ads_slots';  // Registry of the numbered spaces found on the site.
	const MENU    = 'edit.php?post_type=wakoo_ad';
	const DAYS    = 60;                 // History kept per ad.
	const MAX_IDS = 24;                 // Ads counted per "seen" request.
	const MARKET  = 3;                  // Marketplace positions the ad server can fill.
	const NONE    = '-';                // «No space»: the ad waits (an empty list means every space).

	/** Ad kinds. */
	const KINDS = [ 'image', 'video', 'audio', 'html', 'text', 'listing' ];

	/** Standard frame sizes (IAB), width x height. */
	public static function sizes() {
		return [
			'auto'    => __( 'Ancho completo (se adapta)', 'wakoo' ),
			'728x90'  => __( 'Leaderboard 728 × 90', 'wakoo' ),
			'970x90'  => __( 'Leaderboard grande 970 × 90', 'wakoo' ),
			'970x250' => __( 'Billboard 970 × 250', 'wakoo' ),
			'468x60'  => __( 'Banner 468 × 60', 'wakoo' ),
			'300x250' => __( 'Rectángulo mediano 300 × 250', 'wakoo' ),
			'336x280' => __( 'Rectángulo grande 336 × 280', 'wakoo' ),
			'250x250' => __( 'Cuadrado 250 × 250', 'wakoo' ),
			'300x600' => __( 'Media página 300 × 600', 'wakoo' ),
			'160x600' => __( 'Rascacielos 160 × 600', 'wakoo' ),
			'320x100' => __( 'Móvil grande 320 × 100', 'wakoo' ),
			'320x50'  => __( 'Móvil 320 × 50', 'wakoo' ),
			'custom'  => __( 'Personalizado', 'wakoo' ),
		];
	}

	public static function init() {
		add_action( 'init', [ __CLASS__, 'register' ] );
		add_action( 'init', [ __CLASS__, 'click' ], 1 );
		add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'assets' ] );
		add_action( 'elementor/frontend/after_register_styles', [ __CLASS__, 'styles' ] );
		add_action( 'save_post_' . self::CPT, [ __CLASS__, 'bump' ] );
		add_action( 'deleted_post', [ __CLASS__, 'bump' ] );
		// Number new spaces in page order when a page is saved in Elementor.
		add_action( 'elementor/document/after_save', [ __CLASS__, 'after_save' ], 10, 2 );
		// Packs can carry ads with their fields.
		add_filter( 'wakoo_portable_types', function ( $t ) { $t[] = self::CPT; return $t; } );
		add_filter( 'wakoo_portable_meta_prefixes', function ( $p ) { $p[] = '_wk_ad_'; return $p; } );
		if ( is_admin() ) {
			require_once __DIR__ . '/includes/admin.php';
			Admin::init();
		}
	}

	public static function register() {
		register_post_type( self::CPT, [
			'labels'          => [
				'name'          => __( 'Anuncios', 'wakoo' ),
				'singular_name' => __( 'Anuncio', 'wakoo' ),
				'menu_name'     => __( 'Anuncios Wakoo', 'wakoo' ),
				'add_new'       => __( 'Nuevo anuncio', 'wakoo' ),
				'add_new_item'  => __( 'Nuevo anuncio', 'wakoo' ),
				'edit_item'     => __( 'Editar anuncio', 'wakoo' ),
				'all_items'     => __( 'Anuncios', 'wakoo' ),
			],
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => true,
			'menu_icon'       => 'dashicons-megaphone',
			'menu_position'   => 58,
			'supports'        => [ 'title', 'thumbnail' ],
			'capability_type' => 'post',
			'map_meta_cap'    => true,
		] );
	}

	public static function register_widget( $wm ) {
		require_once __DIR__ . '/widget.php';
		$wm->register( new Widget() );
	}

	public static function assets() {
		wp_register_script( 'wakoo-ads', WAKOO_MODULES_URL . 'ads/assets/ads.js', [], WAKOO_VERSION, true );
		$adsense = [ 'client' => '', 'unit' => '', 'gate' => false ];
		if ( class_exists( '\Wakoo\Modules\Seo\Module' ) ) {
			$o       = \Wakoo\Modules\Seo\Module::opts();
			$adsense = [ 'client' => $o['adsense_client'], 'unit' => $o['adsense_unit'], 'gate' => 'basic' === \Wakoo\Modules\Seo\Module::consent_mode() ];
		}
		wp_localize_script( 'wakoo-ads', 'WakooAds', [
			'api'     => esc_url_raw( rest_url( self::NS . '/ads' ) ),
			'ver'     => (int) get_option( 'wakoo_ads_ver', 1 ), // Changes with every ad change: a fresh list, not the browser's cached one.
			'adsense' => $adsense,
			'tz'      => (int) round( (float) get_option( 'gmt_offset', 0 ) * 60 ), // Site time zone (minutes) for days/hours rules.
		] );
	}

	public static function styles() {
		wp_register_style( 'wakoo-ads', WAKOO_MODULES_URL . 'ads/assets/ads.css', [], WAKOO_VERSION );
	}

	/* ---------------------------------------------------------------- data */

	/** Ad fields stored as meta (`_wk_ad_<key>`). */
	const FIELDS = [ 'kind', 'headline', 'text', 'cta', 'url', 'member', 'media', 'code', 'listing', 'slots', 'langs', 'start', 'end',
		'weekdays', 'hours_from', 'hours_to', 'devices', 'cap', 'priority', 'weight', 'position' ];

	public static function get( $id ) {
		$d = [ 'id' => (int) $id, 'title' => get_the_title( $id ) ];
		foreach ( self::FIELDS as $k ) {
			$d[ $k ] = get_post_meta( $id, '_wk_ad_' . $k, true );
		}
		$d['kind']     = in_array( $d['kind'], self::KINDS, true ) ? $d['kind'] : 'image';
		$d['slots']    = array_values( array_filter( (array) $d['slots'] ) );
		$d['langs']    = array_values( array_filter( (array) $d['langs'] ) );
		$d['weekdays'] = array_values( array_map( 'intval', array_filter( (array) $d['weekdays'], 'is_numeric' ) ) );
		$d['devices']  = array_values( array_filter( (array) $d['devices'] ) );
		$d['weight']   = max( 1, min( 10, (int) ( $d['weight'] ?: 5 ) ) );
		$d['cap']      = max( 0, (int) $d['cap'] );
		$d['priority'] = 'fixed' === $d['priority'] ? 'fixed' : 'rotate';
		$d['position'] = max( 0, min( self::MARKET, (int) $d['position'] ) );
		$d['media']    = (int) $d['media'];
		$d['listing']  = (int) $d['listing'];
		$d['image']    = (int) get_post_thumbnail_id( $id );
		return $d;
	}

	/** Where a click goes: the ad's own link, else the member's public profile. */
	public static function target( array $d ) {
		if ( $d['url'] ) {
			return $d['url'];
		}
		if ( $d['member'] && 'publish' === get_post_status( (int) $d['member'] ) ) {
			return get_permalink( (int) $d['member'] );
		}
		return '';
	}

	/** Has what its kind needs to be drawn. */
	private static function complete( array $d ) {
		switch ( $d['kind'] ) {
			case 'html':
				return '' !== trim( (string) $d['code'] );
			case 'listing':
				return $d['listing'] && 'publish' === get_post_status( $d['listing'] );
			case 'video':
			case 'audio':
				return $d['media'] && self::target( $d );
			default:
				return (bool) self::target( $d );
		}
	}

	/** Published, inside its dates, with what its kind needs. */
	public static function is_live( array $d, $today = null ) {
		$today = $today ?: current_time( 'Y-m-d' );
		if ( 'publish' !== get_post_status( $d['id'] ) || ! self::complete( $d ) ) {
			return false;
		}
		return ( ! $d['start'] || $d['start'] <= $today ) && ( ! $d['end'] || $d['end'] >= $today );
	}

	/** Cached list of live ads; rebuilt when an ad changes or the day changes. */
	public static function live() {
		$key  = 'wakoo_ads_live_' . (int) get_option( 'wakoo_ads_ver', 1 ) . '_' . current_time( 'Ymd' );
		$list = get_transient( $key );
		if ( is_array( $list ) ) {
			return $list;
		}
		$list = [];
		foreach ( get_posts( [ 'post_type' => self::CPT, 'post_status' => 'publish', 'posts_per_page' => 300, 'fields' => 'ids' ] ) as $id ) {
			$d = self::get( $id );
			if ( ! self::is_live( $d ) ) {
				continue;
			}
			$list[] = self::payload( $d );
		}
		set_transient( $key, $list, DAY_IN_SECONDS );
		return $list;
	}

	/** What the browser needs to draw one ad (and the rules it applies). */
	private static function payload( array $d ) {
		$p = [
			'id'       => $d['id'],
			'kind'     => $d['kind'],
			'slots'    => $d['slots'],
			'langs'    => $d['langs'],
			'w'        => $d['weight'],
			'fixed'    => 'fixed' === $d['priority'],
			'img'      => $d['image'] ? (string) wp_get_attachment_image_url( $d['image'], 'large' ) : '',
			'alt'      => $d['image'] ? (string) get_post_meta( $d['image'], '_wp_attachment_image_alt', true ) : '',
			'headline' => (string) $d['headline'],
			'text'     => (string) $d['text'],
			'cta'      => (string) $d['cta'],
			'href'     => self::target( $d ) ? add_query_arg( 'wk_ad', $d['id'], home_url( '/' ) ) : '',
			'days'     => $d['weekdays'],
			'hours'    => '' !== (string) $d['hours_from'] || '' !== (string) $d['hours_to'] ? [ (int) $d['hours_from'], '' === (string) $d['hours_to'] ? 24 : (int) $d['hours_to'] ] : [],
			'devices'  => $d['devices'],
			'cap'      => $d['cap'],
		];
		if ( in_array( $d['kind'], [ 'video', 'audio' ], true ) ) {
			$p['media'] = (string) wp_get_attachment_url( $d['media'] );
			$p['mime']  = (string) get_post_mime_type( $d['media'] );
		}
		if ( 'html' === $d['kind'] ) {
			// Drawn in a sandboxed iframe (no access to the site). {{click}} = the counted click link (to the ad's «Enlace»).
			$p['code'] = str_replace( '{{click}}', esc_url( $p['href'] ?: home_url( '/' ) ), (string) $d['code'] );
		}
		if ( 'listing' === $d['kind'] ) {
			$p['listing']  = $d['listing'];
			$p['position'] = $d['position'];
		}
		return $p;
	}

	public static function bump( $post_id = 0 ) {
		if ( ! $post_id || self::CPT === get_post_type( $post_id ) ) {
			update_option( 'wakoo_ads_ver', (int) get_option( 'wakoo_ads_ver', 1 ) + 1, false );
		}
	}

	/* ---------------------------------------------------------------- numbered spaces */

	/** [ key => [ num, label, url, post, size, order ] ], sorted by number. */
	public static function slots() {
		$all = get_option( self::SLOTS, [] );
		$all = is_array( $all ) ? $all : [];
		uasort( $all, function ( $a, $b ) { return ( (int) ( $a['num'] ?? 0 ) ) <=> ( (int) ( $b['num'] ?? 0 ) ); } );
		return $all;
	}

	/** «Espacio 4» (or its label when it has one). */
	public static function slot_name( $key, $with_label = true ) {
		$s = self::slots()[ $key ] ?? null;
		if ( ! $s ) {
			return $key;
		}
		/* translators: %d: space number */
		$name = sprintf( __( 'Espacio %d', 'wakoo' ), (int) $s['num'] );
		return $with_label && ! empty( $s['label'] ) ? $name . ' · ' . $s['label'] : $name;
	}

	/**
	 * Called by the widget on render (also in the editor, as soon as it is dropped): the
	 * space gets the next free number and remembers its page and size. Returns the number.
	 */
	public static function register_slot( $key, array $info ) {
		$key = sanitize_key( $key );
		if ( ! $key ) {
			return 0;
		}
		$all = get_option( self::SLOTS, [] );
		$all = is_array( $all ) ? $all : [];
		$old = $all[ $key ] ?? [];
		$num = (int) ( $old['num'] ?? 0 );
		if ( ! $num ) {
			$num = 1 + (int) max( array_merge( [ 0 ], array_map( function ( $s ) { return (int) ( $s['num'] ?? 0 ); }, $all ) ) );
		}
		$new = [
			'num'   => $num,
			'label' => sanitize_text_field( $info['label'] ?? '' ),
			'url'   => esc_url_raw( $info['url'] ?? ( $old['url'] ?? '' ) ),
			'post'  => (int) ( $info['post'] ?? ( $old['post'] ?? 0 ) ),
			'size'  => sanitize_text_field( $info['size'] ?? '' ),
			'order' => (int) ( $old['order'] ?? 0 ),
		];
		if ( $old !== $new ) {
			$all[ $key ] = $new;
			update_option( self::SLOTS, array_slice( $all, 0, 300, true ), false );
		}
		return $num;
	}

	/** Key of a widget's space: its legacy name if it has one, else its element id. */
	public static function key_of( array $settings, $element_id ) {
		$k = sanitize_key( $settings['slot'] ?? '' );
		return $k ? $k : 'e' . sanitize_key( $element_id );
	}

	/** Spaces of an Elementor document, in the order they appear. */
	private static function find_spaces( array $elements, array &$out ) {
		foreach ( $elements as $el ) {
			if ( 'wakoo-ad-slot' === ( $el['widgetType'] ?? '' ) ) {
				$out[] = self::key_of( (array) ( $el['settings'] ?? [] ), (string) ( $el['id'] ?? '' ) );
			}
			if ( ! empty( $el['elements'] ) ) {
				self::find_spaces( (array) $el['elements'], $out );
			}
		}
	}

	/** After saving a page in Elementor: its spaces keep the page order (new ones get the next numbers). */
	public static function after_save( $document, $data ) {
		$els = $data['elements'] ?? null;
		if ( ! is_array( $els ) ) {
			return;
		}
		$keys = [];
		self::find_spaces( $els, $keys );
		if ( ! $keys ) {
			return;
		}
		$all = get_option( self::SLOTS, [] );
		$all = is_array( $all ) ? $all : [];
		foreach ( $keys as $i => $k ) {
			if ( isset( $all[ $k ] ) ) {
				$all[ $k ]['order'] = $i;
				$all[ $k ]['post']  = (int) $document->get_main_id();
			}
		}
		update_option( self::SLOTS, $all, false );
	}

	/**
	 * Renumber every space: pages in menu order (home first), then the order inside each page.
	 * Languages share numbers (translations keep the element ids). Spaces no longer on any page are dropped.
	 */
	public static function renumber() {
		$all   = get_option( self::SLOTS, [] );
		$all   = is_array( $all ) ? $all : [];
		$front = (int) get_option( 'page_on_front' );
		$pages = get_posts( [ 'post_type' => [ 'page', 'post', 'elementor_library', 'wakoo_popup' ], 'post_status' => 'publish', 'posts_per_page' => 500, 'orderby' => [ 'menu_order' => 'ASC', 'ID' => 'ASC' ], 'fields' => 'ids', 'meta_key' => '_elementor_data' ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
		usort( $pages, function ( $a, $b ) use ( $front ) { return ( $b === $front ) <=> ( $a === $front ); } );
		$seq = [];
		foreach ( $pages as $pid ) {
			$data = json_decode( (string) get_post_meta( $pid, '_elementor_data', true ), true );
			if ( ! is_array( $data ) ) { continue; }
			$keys = [];
			self::find_spaces( $data, $keys );
			foreach ( $keys as $i => $k ) {
				if ( ! isset( $seq[ $k ] ) ) { $seq[ $k ] = [ $pid, $i ]; }
			}
		}
		$out = [];
		$n   = 0;
		foreach ( $seq as $k => $where ) {
			$out[ $k ] = array_merge( [ 'label' => '', 'url' => get_permalink( $where[0] ), 'size' => '' ], $all[ $k ] ?? [], [ 'num' => ++$n, 'post' => $where[0], 'order' => $where[1] ] );
		}
		update_option( self::SLOTS, $out, false );
		return $n;
	}

	/* ---------------------------------------------------------------- marketplace */

	/**
	 * Listings the ad server puts in the first marketplace positions: [ position => [ ad id, listing id ] ].
	 * Fixed ads go first; the rest are picked by weight. Positions left empty keep the newest listings.
	 */
	public static function market_picks() {
		$fixed = [];
		$pool  = [];
		foreach ( self::live() as $ad ) {
			if ( 'listing' !== $ad['kind'] ) { continue; }
			if ( $ad['days'] && ! in_array( (int) current_time( 'w' ), $ad['days'], true ) ) { continue; }
			if ( $ad['fixed'] ) { $fixed[] = $ad; } else { $pool[] = $ad; }
		}
		$picks = [];
		$used  = [];
		$place = function ( $ad ) use ( &$picks, &$used ) {
			if ( in_array( $ad['listing'], $used, true ) ) { return; }
			$pos = (int) $ad['position'];
			if ( ! $pos || isset( $picks[ $pos ] ) ) { // No position or taken: the first free one.
				$free = array_diff( range( 1, self::MARKET ), array_keys( $picks ) );
				if ( ! $free ) { return; }
				$pos = min( $free );
			}
			$picks[ $pos ] = [ $ad['id'], $ad['listing'] ];
			$used[]        = $ad['listing'];
		};
		foreach ( $fixed as $ad ) { $place( $ad ); }
		while ( $pool && count( $picks ) < self::MARKET ) {
			$total = array_sum( wp_list_pluck( $pool, 'w' ) );
			$r     = wp_rand( 1, max( 1, $total ) );
			foreach ( $pool as $i => $ad ) {
				$r -= $ad['w'];
				if ( $r <= 0 ) { $place( $ad ); unset( $pool[ $i ] ); break; }
			}
		}
		ksort( $picks );
		return $picks;
	}

	/* ---------------------------------------------------------------- stats */

	private static function count( $id, $what ) {
		$i     = 'click' === $what ? 1 : 0;
		$total = (int) get_post_meta( $id, '_wk_ad_' . ( $i ? 'clicks' : 'views' ), true );
		update_post_meta( $id, '_wk_ad_' . ( $i ? 'clicks' : 'views' ), $total + 1 );
		$days = self::log( $id );
		$day  = current_time( 'Y-m-d' );
		$days[ $day ]       = $days[ $day ] ?? [ 0, 0 ];
		$days[ $day ][ $i ] = (int) $days[ $day ][ $i ] + 1;
		ksort( $days );
		update_post_meta( $id, '_wk_ad_days', array_slice( $days, -self::DAYS, null, true ) );
	}

	/** Daily history [ Y-m-d => [ views, clicks ] ]. */
	public static function log( $id ) {
		$days = get_post_meta( $id, '_wk_ad_days', true );
		return is_array( $days ) ? $days : [];
	}

	/** [ views, clicks ] over the last $days days (0 = all time). */
	public static function totals( $id, $days = 0 ) {
		if ( ! $days ) {
			return [ (int) get_post_meta( $id, '_wk_ad_views', true ), (int) get_post_meta( $id, '_wk_ad_clicks', true ) ];
		}
		$from = gmdate( 'Y-m-d', strtotime( current_time( 'Y-m-d' ) . ' -' . ( $days - 1 ) . ' days' ) );
		$v    = 0;
		$c    = 0;
		foreach ( self::log( $id ) as $day => $n ) {
			if ( $day >= $from ) {
				$v += (int) ( $n[0] ?? 0 );
				$c += (int) ( $n[1] ?? 0 );
			}
		}
		return [ $v, $c ];
	}

	/* ---------------------------------------------------------------- public endpoints */

	public static function routes() {
		register_rest_route( self::NS, '/ads', [
			'methods'             => 'GET',
			'permission_callback' => '__return_true',
			'callback'            => [ __CLASS__, 'rest_ads' ],
		] );
		register_rest_route( self::NS, '/ads/seen', [
			'methods'             => 'POST',
			'permission_callback' => '__return_true',
			'callback'            => [ __CLASS__, 'rest_seen' ],
		] );
	}

	/** Live ads for the requested spaces and language (only what the browser needs to draw them). */
	public static function rest_ads( \WP_REST_Request $r ) {
		$slots = array_filter( array_map( 'sanitize_key', explode( ',', (string) $r->get_param( 'slots' ) ) ) );
		$lang  = sanitize_key( (string) $r->get_param( 'lang' ) );
		$out   = [];
		foreach ( self::live() as $ad ) {
			if ( 'listing' === $ad['kind'] ) { continue; } // Drawn by the marketplace widget itself.
			if ( $lang && $ad['langs'] && ! in_array( $lang, $ad['langs'], true ) ) {
				continue;
			}
			$fits = $ad['slots'] ? array_values( array_intersect( $ad['slots'], $slots ) ) : $slots;
			if ( ! $fits ) {
				continue;
			}
			$ad['slots'] = $fits;
			unset( $ad['langs'] );
			$out[] = $ad;
		}
		$res = new \WP_REST_Response( [ 'ads' => $out ] );
		$res->header( 'Cache-Control', 'public, max-age=300' );
		return $res;
	}

	/** One request with the ads that were seen (viewable). */
	public static function rest_seen( \WP_REST_Request $r ) {
		$ids  = array_slice( array_unique( array_map( 'intval', (array) $r->get_param( 'ids' ) ) ), 0, self::MAX_IDS );
		$live = wp_list_pluck( self::live(), 'id' );
		foreach ( array_intersect( $ids, $live ) as $id ) {
			self::count( $id, 'view' );
		}
		return new \WP_REST_Response( [ 'ok' => true ] );
	}

	/** /?wk_ad=<id>: count the click and go to the ad's destination. */
	public static function click() {
		if ( empty( $_GET['wk_ad'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$id = (int) $_GET['wk_ad']; // phpcs:ignore WordPress.Security.NonceVerification
		if ( self::CPT !== get_post_type( $id ) ) {
			return;
		}
		$d  = self::get( $id );
		$to = self::target( $d );
		if ( ! $to ) {
			return;
		}
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? strtolower( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) ) : '';
		if ( self::is_live( $d ) && $ua && ! preg_match( '/bot|crawl|spider|slurp|preview|facebookexternalhit/', $ua ) ) {
			self::count( $id, 'click' );
		}
		nocache_headers();
		wp_redirect( esc_url_raw( $to ), 302, 'Wakoo Ads' ); // phpcs:ignore WordPress.Security.SafeRedirect -- destination set by an editor.
		exit;
	}
}

Module::init();
