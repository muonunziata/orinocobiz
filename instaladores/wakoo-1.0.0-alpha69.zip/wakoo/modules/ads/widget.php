<?php
/**
 * "Espacio publicitario (Wakoo)": a numbered ad frame served by the Wakoo ad
 * server. Dropped on a page it becomes «Espacio N» (numbers follow the pages,
 * home first). It has a standard or custom size, prints its own house ad
 * (kept when no ad is in rotation or JavaScript is off) and ads.js swaps in
 * the ads, rotating them every N seconds if asked.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Ads;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Widget extends Widget_Base {

	public function get_name() { return 'wakoo-ad-slot'; }
	public function get_title() { return __( 'Espacio publicitario (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-banner'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'anuncio', 'publicidad', 'ad', 'banner', 'patrocinio', 'espacio', 'miembros', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-ads' ]; }
	public function get_style_depends() { return [ 'wakoo-ads' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_slot', [ 'label' => __( 'Espacio', 'wakoo' ) ] );
		$this->add_control( 'slot_info', [ 'type' => Controls_Manager::RAW_HTML, 'content_classes' => 'elementor-descriptor',
			'raw' => esc_html__( 'Cada espacio recibe un número al soltarlo en la página (Espacio 1, 2, 3… en todo el sitio, empezando por la portada). Los anuncios se asignan a esos números en Anuncios Wakoo → Panel.', 'wakoo' ) ] );
		$this->add_control( 'slot_name', [ 'label' => __( 'Nombre (opcional, para el panel)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '', 'label_block' => true, 'placeholder' => __( 'p. ej. Portada, bajo el buscador', 'wakoo' ) ] );
		$this->add_control( 'size', [ 'label' => __( 'Tamaño del marco', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'auto', 'options' => Module::sizes() ] );
		$this->add_control( 'width', [ 'label' => __( 'Ancho (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 50, 'max' => 1600, 'default' => 600, 'condition' => [ 'size' => 'custom' ] ] );
		$this->add_control( 'height', [ 'label' => __( 'Alto (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 40, 'max' => 1200, 'default' => 200, 'condition' => [ 'size' => 'custom' ] ] );
		$this->add_control( 'align', [ 'label' => __( 'Alineación', 'wakoo' ), 'type' => Controls_Manager::CHOOSE, 'default' => 'center', 'toggle' => false, 'options' => [
			'left'   => [ 'title' => __( 'Izquierda', 'wakoo' ), 'icon' => 'eicon-text-align-left' ],
			'center' => [ 'title' => __( 'Centro', 'wakoo' ), 'icon' => 'eicon-text-align-center' ],
			'right'  => [ 'title' => __( 'Derecha', 'wakoo' ), 'icon' => 'eicon-text-align-right' ],
		], 'condition' => [ 'size!' => 'auto' ] ] );
		$this->add_control( 'format', [ 'label' => __( 'Diseño de los anuncios de texto e imagen', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'banner', 'options' => [
			'banner' => __( 'Banner (imagen, texto y botón en fila)', 'wakoo' ),
			'card'   => __( 'Tarjeta (imagen arriba)', 'wakoo' ),
			'image'  => __( 'Solo imagen', 'wakoo' ),
		] ] );
		$this->add_control( 'rotate', [ 'label' => __( 'Cambiar de anuncio cada (segundos)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 300, 'default' => 0, 'description' => __( '0 = un anuncio por visita.', 'wakoo' ) ] );
		$this->add_control( 'label', [ 'label' => __( 'Etiqueta visible', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Publicidad', 'wakoo' ), 'description' => __( 'Indica que es publicidad. Vacío = sin etiqueta.', 'wakoo' ) ] );
		$this->add_control( 'slot', [ 'label' => __( 'Identificador antiguo (avanzado)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '', 'separator' => 'before', 'description' => __( 'Solo para espacios creados antes de la numeración automática (p. ej. home-1). Déjalo vacío en espacios nuevos.', 'wakoo' ) ] );
		$this->add_control( 'adsense', [ 'label' => __( 'Usar Google AdSense si no hay anuncio propio', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => '', 'separator' => 'before', 'description' => __( 'Necesita el ID de editor y una unidad en Wakoo SEO. Sin consentimiento de marketing (modo básico) se queda el anuncio propio.', 'wakoo' ) ] );
		$this->add_control( 'adsense_unit', [ 'label' => __( 'Unidad de AdSense (opcional)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'description' => __( 'Vacío = la unidad por defecto de Wakoo SEO.', 'wakoo' ), 'condition' => [ 'adsense' => 'yes' ] ] );
		$this->add_control( 'adsense_label', [ 'label' => __( 'Etiqueta sobre AdSense', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Publicidad', 'wakoo' ), 'condition' => [ 'adsense' => 'yes' ] ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_house', [ 'label' => __( 'Anuncio propio (cuando no hay otro)', 'wakoo' ) ] );
		$this->add_control( 'house_image', [ 'label' => __( 'Imagen o icono', 'wakoo' ), 'type' => Controls_Manager::MEDIA ] );
		$this->add_control( 'house_title', [ 'label' => __( 'Titular', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Tu negocio aquí', 'wakoo' ), 'label_block' => true ] );
		$this->add_control( 'house_text', [ 'label' => __( 'Texto', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'default' => __( 'Este espacio está reservado a los miembros. Hazte miembro y llega a vecinos y visitantes.', 'wakoo' ) ] );
		$this->add_control( 'house_cta', [ 'label' => __( 'Botón', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Hazte miembro', 'wakoo' ) ] );
		$this->add_control( 'house_url', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'accent', [ 'label' => __( 'Color de acento', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}}' => '--wk-ad-accent: {{VALUE}};' ] ] );
		$this->add_control( 'bg', [ 'label' => __( 'Fondo', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}}' => '--wk-ad-bg: {{VALUE}};' ] ] );
		$this->add_control( 'radius', [ 'label' => __( 'Redondez (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 40, 'selectors' => [ '{{WRAPPER}}' => '--wk-ad-radius: {{VALUE}}px;' ] ] );
		$this->end_controls_section();
	}

	/** [ width, height ] of the frame, or null when it follows the column. */
	private function dims( array $s ) {
		$size = $s['size'] ?? 'auto';
		if ( 'custom' === $size ) {
			return [ max( 50, (int) ( $s['width'] ?? 600 ) ), max( 40, (int) ( $s['height'] ?? 200 ) ) ];
		}
		return preg_match( '/^(\d+)x(\d+)$/', (string) $size, $m ) ? [ (int) $m[1], (int) $m[2] ] : null;
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$slot = Module::key_of( $s, $this->get_id() );
		$pid  = get_queried_object_id() ?: get_the_ID(); // In the editor the page being edited.
		$dim  = $this->dims( $s );
		$num  = Module::register_slot( $slot, [
			'label' => $s['slot_name'] ?? '',
			'url'   => $pid ? get_permalink( $pid ) : home_url( '/' ),
			'post'  => $pid,
			'size'  => $dim ? $dim[0] . '×' . $dim[1] : '',
		] );
		$edit  = class_exists( '\Elementor\Plugin' ) && \Elementor\Plugin::$instance->editor && \Elementor\Plugin::$instance->editor->is_edit_mode();
		$fmt   = in_array( $s['format'] ?? '', [ 'banner', 'card', 'image' ], true ) ? $s['format'] : 'banner';
		$href  = ! empty( $s['house_url']['url'] ) ? $s['house_url']['url'] : '';
		$img   = ! empty( $s['house_image']['id'] ) ? wp_get_attachment_image( (int) $s['house_image']['id'], 'medium_large', false, [ 'class' => 'wk-ad__img', 'loading' => 'lazy' ] )
			: ( ! empty( $s['house_image']['url'] ) ? '<img class="wk-ad__img" src="' . esc_url( $s['house_image']['url'] ) . '" alt="" loading="lazy">' : '' );
		$style = $dim ? '--wk-ad-w:' . $dim[0] . 'px;--wk-ad-ratio:' . $dim[0] . '/' . $dim[1] . ';' : '';
		$cls   = 'wk-ad wk-ad--' . $fmt . ( $dim ? ' wk-ad--sized wk-ad--' . esc_attr( $s['align'] ?? 'center' ) : '' );
		echo '<aside class="' . esc_attr( $cls ) . '" id="wk-ad-' . esc_attr( $slot ) . '" data-slot="' . esc_attr( $slot ) . '" data-num="' . (int) $num . '" data-format="' . esc_attr( $fmt ) . '"'
			. ( $style ? ' style="' . esc_attr( $style ) . '"' : '' )
			. ( (int) ( $s['rotate'] ?? 0 ) > 0 ? ' data-rotate="' . (int) $s['rotate'] . '"' : '' )
			. ( 'yes' === ( $s['adsense'] ?? '' ) ? ' data-adsense="' . esc_attr( preg_replace( '/\D/', '', (string) ( $s['adsense_unit'] ?? '' ) ) ?: 'default' ) . '" data-adsense-label="' . esc_attr( $s['adsense_label'] ?? '' ) . '"' : '' )
			. ' aria-label="' . esc_attr( $s['label'] ?: __( 'Publicidad', 'wakoo' ) ) . '">';
		if ( $edit ) { // In the editor: the space number and size, so the editor sees where each one goes.
			/* translators: %d: space number */
			echo '<span class="wk-ad__num">' . esc_html( sprintf( __( 'Espacio %d', 'wakoo' ), $num ) . ( $dim ? ' · ' . $dim[0] . '×' . $dim[1] : '' ) ) . '</span>';
		}
		if ( ! empty( $s['label'] ) ) {
			echo '<span class="wk-ad__label">' . esc_html( $s['label'] ) . '</span>';
		}
		echo '<div class="wk-ad__body">';
		echo $img ? '<div class="wk-ad__media">' . $img . '</div>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<div class="wk-ad__txt">';
		echo ! empty( $s['house_title'] ) ? '<p class="wk-ad__title">' . esc_html( $s['house_title'] ) . '</p>' : '';
		echo ! empty( $s['house_text'] ) ? '<p class="wk-ad__text">' . esc_html( $s['house_text'] ) . '</p>' : '';
		echo '</div>';
		if ( $href && ! empty( $s['house_cta'] ) ) {
			echo '<a class="wk-ad__btn" href="' . esc_url( $href ) . '">' . esc_html( $s['house_cta'] ) . '</a>';
		}
		echo '</div></aside>';
	}
}
