<?php
/**
 * Wakoo Anuncios: ad editing box, list columns and the hub (Panel): numbered
 * spaces with the thumbnails of their ads, quick changes (add / remove /
 * weight / marketplace position), renumbering and the report.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Ads;

defined( 'ABSPATH' ) || die();

class Admin {

	const HUB = 'wakoo-ads-report'; // Old «Informe» address, kept.

	public static function init() {
		add_action( 'add_meta_boxes_' . Module::CPT, [ __CLASS__, 'boxes' ] );
		add_action( 'save_post_' . Module::CPT, [ __CLASS__, 'save' ], 5, 2 );
		add_filter( 'manage_' . Module::CPT . '_posts_columns', [ __CLASS__, 'columns' ] );
		add_action( 'manage_' . Module::CPT . '_posts_custom_column', [ __CLASS__, 'column' ], 10, 2 );
		add_action( 'admin_menu', [ __CLASS__, 'menu' ] );
		add_filter( 'admin_post_thumbnail_html', [ __CLASS__, 'image_hint' ], 10, 2 );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
		add_action( 'wp_ajax_wakoo_ads_hub', [ __CLASS__, 'ajax' ] );
	}

	public static function menu() {
		add_submenu_page( Module::MENU, __( 'Panel de anuncios', 'wakoo' ), __( 'Panel', 'wakoo' ), 'edit_posts', self::HUB, [ __CLASS__, 'hub' ], 0 );
	}

	public static function enqueue( $hook ) {
		$screen = get_current_screen();
		if ( $screen && Module::CPT === $screen->post_type && 'post' === $screen->base ) {
			wp_enqueue_media();
			if ( current_user_can( 'unfiltered_html' ) ) {
				$cm = wp_enqueue_code_editor( [ 'type' => 'text/html' ] );
				if ( $cm ) {
					wp_add_inline_script( 'code-editor', 'jQuery(function(){var t=document.getElementById("wk_ad_code");if(t){wp.codeEditor.initialize(t,' . wp_json_encode( $cm ) . ');}});' );
				}
			}
		}
	}

	public static function boxes() {
		add_meta_box( 'wakoo_ad', __( 'Anuncio', 'wakoo' ), [ __CLASS__, 'box' ], Module::CPT, 'normal', 'high' );
		add_meta_box( 'wakoo_ad_stats', __( 'Resultados', 'wakoo' ), [ __CLASS__, 'stats_box' ], Module::CPT, 'side', 'default' );
	}

	public static function image_hint( $html, $post_id ) {
		if ( Module::CPT === get_post_type( $post_id ) ) {
			$html .= '<p class="description">' . esc_html__( 'Imagen del anuncio (o portada del vídeo / audio). Horizontal 1200×628 para banners, del tamaño del espacio para marcos fijos (p. ej. 728×90). Pon un texto alternativo.', 'wakoo' ) . '</p>';
		}
		return $html;
	}

	private static function languages() {
		if ( class_exists( '\Wakoo\Modules\Idiomas\Module' ) ) {
			return \Wakoo\Modules\Idiomas\Module::languages();
		}
		return [];
	}

	public static function kinds() {
		return [
			'image'   => [ __( 'Imagen', 'wakoo' ), 'dashicons-format-image' ],
			'video'   => [ __( 'Vídeo', 'wakoo' ), 'dashicons-format-video' ],
			'audio'   => [ __( 'Audio', 'wakoo' ), 'dashicons-format-audio' ],
			'html'    => [ __( 'Código HTML', 'wakoo' ), 'dashicons-editor-code' ],
			'text'    => [ __( 'Solo texto', 'wakoo' ), 'dashicons-editor-paragraph' ],
			'listing' => [ __( 'Destacado del marketplace', 'wakoo' ), 'dashicons-star-filled' ],
		];
	}

	/** Every space, as «Espacio N · name · size · page». */
	private static function slot_label( $key, array $s ) {
		$bits = [ Module::slot_name( $key ) ];
		if ( ! empty( $s['size'] ) ) { $bits[] = $s['size']; }
		if ( ! empty( $s['url'] ) ) { $bits[] = wp_parse_url( $s['url'], PHP_URL_PATH ) ?: '/'; }
		return implode( ' · ', $bits );
	}

	public static function box( $post ) {
		wp_nonce_field( 'wakoo_ad_save', '_wkad' );
		$d = Module::get( $post->ID );
		if ( 'auto-draft' === $post->post_status && isset( $_GET['wk_kind'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$k = sanitize_key( wp_unslash( $_GET['wk_kind'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
			$d['kind'] = in_array( $k, Module::KINDS, true ) ? $k : $d['kind'];
		}
		$row = function ( $label, $field, $kinds = '' ) {
			echo '<tr' . ( $kinds ? ' data-wk-kinds="' . esc_attr( $kinds ) . '"' : '' ) . '><th scope="row">' . $label . '</th><td>' . $field . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		};
		echo '<style>.wk-kinds{display:flex;flex-wrap:wrap;gap:8px}.wk-kinds label{display:flex;flex-direction:column;align-items:center;gap:4px;width:110px;padding:12px 6px;border:1px solid #dcdcde;border-radius:10px;cursor:pointer;text-align:center;font-weight:600}'
			. '.wk-kinds input{position:absolute;opacity:0}.wk-kinds label:has(input:checked){border-color:#7a3bd1;box-shadow:0 0 0 2px rgba(122,59,209,.25);color:#5a28a0}.wk-kinds .dashicons{font-size:26px;width:26px;height:26px}'
			. '.wk-days label,.wk-dev label{margin-right:12px}.wk-media-name{margin-left:8px;font-style:italic}</style>';
		echo '<table class="form-table"><tbody>';

		$k = '';
		foreach ( self::kinds() as $id => $kd ) {
			$k .= '<label><input type="radio" name="wk_ad[kind]" value="' . esc_attr( $id ) . '" ' . checked( $d['kind'], $id, false ) . '><span class="dashicons ' . esc_attr( $kd[1] ) . '"></span>' . esc_html( $kd[0] ) . '</label>';
		}
		$row( esc_html__( 'Tipo de anuncio', 'wakoo' ), '<div class="wk-kinds">' . $k . '</div><p class="description">' . esc_html__( 'Imagen, vídeo y audio usan la «Imagen destacada» de la derecha como imagen o portada.', 'wakoo' ) . '</p>' );

		// Video / audio file from the media library.
		$name = $d['media'] ? basename( (string) get_attached_file( $d['media'] ) ) : '';
		$row( esc_html__( 'Archivo', 'wakoo' ), '<input type="hidden" id="wk_ad_media" name="wk_ad[media]" value="' . (int) $d['media'] . '"><button type="button" class="button" id="wk_ad_media_btn">' . esc_html__( 'Elegir o subir archivo', 'wakoo' ) . '</button>'
			. '<span class="wk-media-name" id="wk_ad_media_name">' . esc_html( $name ) . '</span><p class="description">' . esc_html__( 'Vídeo MP4 o WebM (se reproduce sin sonido y en bucle) o audio MP3 / M4A / OGG.', 'wakoo' ) . '</p>', 'video audio' );

		// HTML code: only for users allowed to publish unfiltered HTML; drawn in a sandboxed frame.
		if ( current_user_can( 'unfiltered_html' ) ) {
			$code = '<textarea id="wk_ad_code" name="wk_ad[code]" rows="12" class="large-text code">' . esc_textarea( (string) $d['code'] ) . '</textarea>'
				. '<p class="description">' . esc_html__( 'HTML, CSS y JavaScript del anuncio (por ejemplo, uno que te genere Claude). Se muestra aislado en un marco: no puede leer la página, las cookies ni la sesión del visitante. Los enlaces se abren en una pestaña nueva.', 'wakoo' ) . '</p>'
				. '<p class="description">' . esc_html__( 'Escribe {{click}} como dirección de los enlaces (href="{{click}}") para contar los clics: llevan al «Enlace» de abajo.', 'wakoo' ) . '</p>';
		} else {
			$code = '<p class="description">' . esc_html__( 'Solo un administrador puede añadir o cambiar el código de un anuncio.', 'wakoo' ) . '</p>';
		}
		$row( '<label for="wk_ad_code">' . esc_html__( 'Código', 'wakoo' ) . '</label>', $code, 'html' );

		// Marketplace listing to feature.
		$listings = post_type_exists( 'wakoo_listing' ) ? get_posts( [ 'post_type' => 'wakoo_listing', 'post_status' => 'publish', 'posts_per_page' => 300, 'orderby' => 'date', 'order' => 'DESC' ] ) : [];
		$sel      = '<select id="wk_ad_listing" name="wk_ad[listing]"><option value="0">' . esc_html__( '— Elige un anuncio del marketplace —', 'wakoo' ) . '</option>';
		foreach ( $listings as $l ) {
			$sel .= '<option value="' . (int) $l->ID . '"' . selected( $d['listing'], $l->ID, false ) . '>' . esc_html( $l->post_title ) . '</option>';
		}
		$sel .= '</select>';
		$pos = '<select name="wk_ad[position]"><option value="0">' . esc_html__( 'El primer puesto libre', 'wakoo' ) . '</option>';
		for ( $i = 1; $i <= Module::MARKET; $i++ ) {
			/* translators: %d: position */
			$pos .= '<option value="' . $i . '"' . selected( $d['position'], $i, false ) . '>' . esc_html( sprintf( __( 'Puesto %d', 'wakoo' ), $i ) ) . '</option>';
		}
		$pos .= '</select>';
		$row( '<label for="wk_ad_listing">' . esc_html__( 'Anuncio a destacar', 'wakoo' ) . '</label>', $sel . ' ' . $pos . '<p class="description">' . esc_html__( 'Aparece en los 3 primeros puestos del «Marketplace de miembros» con la etiqueta «Destacado». Los puestos libres muestran los anuncios más nuevos.', 'wakoo' ) . '</p>', 'listing' );

		$row( '<label for="wk_ad_headline">' . esc_html__( 'Titular', 'wakoo' ) . '</label>', '<input id="wk_ad_headline" class="large-text" name="wk_ad[headline]" maxlength="80" value="' . esc_attr( $d['headline'] ) . '">', 'image video audio text html' );
		$row( '<label for="wk_ad_text">' . esc_html__( 'Texto', 'wakoo' ) . '</label>', '<textarea id="wk_ad_text" class="large-text" rows="3" name="wk_ad[text]" maxlength="220">' . esc_textarea( $d['text'] ) . '</textarea>', 'image video audio text' );
		$row( '<label for="wk_ad_cta">' . esc_html__( 'Texto del botón', 'wakoo' ) . '</label>', '<input id="wk_ad_cta" class="regular-text" name="wk_ad[cta]" maxlength="30" value="' . esc_attr( $d['cta'] ) . '" placeholder="' . esc_attr__( 'Ver más', 'wakoo' ) . '">', 'image video audio text' );

		$members = post_type_exists( 'wakoo_member' ) ? get_posts( [ 'post_type' => 'wakoo_member', 'post_status' => 'publish', 'posts_per_page' => 300, 'orderby' => 'title', 'order' => 'ASC' ] ) : [];
		$msel    = '<select id="wk_ad_member" name="wk_ad[member]"><option value="0">' . esc_html__( '— Ninguno —', 'wakoo' ) . '</option>';
		foreach ( $members as $m ) {
			$msel .= '<option value="' . (int) $m->ID . '"' . selected( (int) $d['member'], $m->ID, false ) . '>' . esc_html( $m->post_title ) . '</option>';
		}
		$msel .= '</select><p class="description">' . esc_html__( 'Si no pones un enlace, el anuncio lleva al perfil del miembro.', 'wakoo' ) . '</p>';
		if ( $members || $d['member'] ) {
			$row( '<label for="wk_ad_member">' . esc_html__( 'Miembro anunciante', 'wakoo' ) . '</label>', $msel, 'image video audio text' );
		}
		$row( '<label for="wk_ad_url">' . esc_html__( 'Enlace', 'wakoo' ) . '</label>', '<input id="wk_ad_url" type="url" class="large-text" name="wk_ad[url]" value="' . esc_attr( $d['url'] ) . '" placeholder="https://">', 'image video audio text html' );

		$slots  = Module::slots();
		$checks = '<label style="display:block;margin-bottom:6px"><input type="checkbox" name="wk_ad[slots][]" value="*" ' . checked( ! $d['slots'], true, false ) . ' data-wk-all> <strong>' . esc_html__( 'Todos los espacios', 'wakoo' ) . '</strong></label>';
		foreach ( $slots as $id => $s ) {
			$checks .= '<label style="display:inline-block;min-width:300px;margin:0 12px 6px 0"><input type="checkbox" name="wk_ad[slots][]" value="' . esc_attr( $id ) . '" ' . checked( in_array( $id, $d['slots'], true ), true, false ) . '> ' . esc_html( self::slot_label( $id, $s ) ) . '</label>';
		}
		if ( ! $slots ) {
			$checks .= '<p class="description">' . esc_html__( 'Los espacios aparecen aquí al poner el widget «Espacio publicitario (Wakoo)» en una página.', 'wakoo' ) . '</p>';
		}
		$row( esc_html__( 'Dónde se muestra', 'wakoo' ), $checks, 'image video audio text html' );

		$langs = self::languages();
		if ( $langs ) {
			$l = '';
			foreach ( $langs as $code => $name ) {
				$l .= '<label style="margin-right:14px"><input type="checkbox" name="wk_ad[langs][]" value="' . esc_attr( $code ) . '" ' . checked( in_array( $code, $d['langs'], true ), true, false ) . '> ' . esc_html( $name ) . '</label>';
			}
			$row( esc_html__( 'Idiomas', 'wakoo' ), $l . '<p class="description">' . esc_html__( 'Ninguno marcado = en todos los idiomas.', 'wakoo' ) . '</p>', 'image video audio text html' );
		}

		// Schedule and rotation.
		$row( esc_html__( 'Fechas', 'wakoo' ), '<label>' . esc_html__( 'Desde', 'wakoo' ) . ' <input type="date" name="wk_ad[start]" value="' . esc_attr( $d['start'] ) . '"></label> &nbsp; <label>' . esc_html__( 'Hasta', 'wakoo' ) . ' <input type="date" name="wk_ad[end]" value="' . esc_attr( $d['end'] ) . '"></label><p class="description">' . esc_html__( 'Vacío = sin límite.', 'wakoo' ) . '</p>' );
		global $wp_locale;
		$days = '';
		foreach ( [ 1, 2, 3, 4, 5, 6, 0 ] as $wd ) {
			$days .= '<label><input type="checkbox" name="wk_ad[weekdays][]" value="' . $wd . '" ' . checked( in_array( $wd, $d['weekdays'], true ), true, false ) . '> ' . esc_html( $wp_locale->get_weekday_abbrev( $wp_locale->get_weekday( $wd ) ) ) . '</label>';
		}
		$row( esc_html__( 'Días', 'wakoo' ), '<div class="wk-days">' . $days . '</div><p class="description">' . esc_html__( 'Ninguno marcado = todos los días.', 'wakoo' ) . '</p>' );
		$hour = function ( $name, $val, $to ) {
			$o = '<select name="wk_ad[' . $name . ']"><option value="">—</option>';
			for ( $h = $to ? 1 : 0; $h <= ( $to ? 24 : 23 ); $h++ ) {
				$o .= '<option value="' . $h . '"' . selected( (string) $val, (string) $h, false ) . '>' . sprintf( '%02d:00', $h ) . '</option>';
			}
			return $o . '</select>';
		};
		$row( esc_html__( 'Horario', 'wakoo' ), esc_html__( 'De', 'wakoo' ) . ' ' . $hour( 'hours_from', $d['hours_from'], false ) . ' ' . esc_html__( 'a', 'wakoo' ) . ' ' . $hour( 'hours_to', $d['hours_to'], true )
			. '<p class="description">' . esc_html__( 'Hora del sitio. Vacío = todo el día. Puede cruzar la medianoche (de 22:00 a 06:00).', 'wakoo' ) . '</p>', 'image video audio text html' );
		$dev = '';
		foreach ( [ 'desktop' => __( 'Ordenador', 'wakoo' ), 'tablet' => __( 'Tablet', 'wakoo' ), 'mobile' => __( 'Móvil', 'wakoo' ) ] as $dk => $dl ) {
			$dev .= '<label><input type="checkbox" name="wk_ad[devices][]" value="' . esc_attr( $dk ) . '" ' . checked( in_array( $dk, $d['devices'], true ), true, false ) . '> ' . esc_html( $dl ) . '</label>';
		}
		$row( esc_html__( 'Dispositivos', 'wakoo' ), '<div class="wk-dev">' . $dev . '</div><p class="description">' . esc_html__( 'Ninguno marcado = en todos.', 'wakoo' ) . '</p>', 'image video audio text html' );
		$row( '<label for="wk_ad_cap">' . esc_html__( 'Máximo por visitante y día', 'wakoo' ) . '</label>', '<input id="wk_ad_cap" type="number" min="0" max="100" name="wk_ad[cap]" value="' . (int) $d['cap'] . '"><p class="description">' . esc_html__( '0 = sin límite. Se cuenta en el navegador del visitante, sin cookies.', 'wakoo' ) . '</p>', 'image video audio text html' );
		$row( esc_html__( 'Prioridad', 'wakoo' ), '<label style="margin-right:14px"><input type="radio" name="wk_ad[priority]" value="rotate" ' . checked( $d['priority'], 'rotate', false ) . '> ' . esc_html__( 'En rotación', 'wakoo' ) . '</label>'
			. '<label><input type="radio" name="wk_ad[priority]" value="fixed" ' . checked( $d['priority'], 'fixed', false ) . '> ' . esc_html__( 'Fijo (va antes que la rotación)', 'wakoo' ) . '</label>'
			. '<p class="description">' . esc_html__( 'Un anuncio fijo ocupa sus espacios mientras esté activo (p. ej. un patrocinio). Si hay varios fijos, se reparten por peso.', 'wakoo' ) . '</p>' );
		$row( '<label for="wk_ad_weight">' . esc_html__( 'Peso en la rotación', 'wakoo' ) . '</label>', '<input id="wk_ad_weight" type="number" min="1" max="10" name="wk_ad[weight]" value="' . (int) $d['weight'] . '"><p class="description">' . esc_html__( 'De 1 a 10. Un anuncio con peso 10 sale el doble que uno con peso 5 en el mismo espacio.', 'wakoo' ) . '</p>' );
		echo '</tbody></table>';
		?>
		<script>
		( function () {
			function sync() {
				var k = ( document.querySelector( 'input[name="wk_ad[kind]"]:checked' ) || {} ).value || 'image';
				document.querySelectorAll( '[data-wk-kinds]' ).forEach( function ( r ) { r.hidden = r.dataset.wkKinds.split( ' ' ).indexOf( k ) === -1; } );
			}
			document.addEventListener( 'change', function ( e ) {
				var t = e.target;
				if ( t.name === 'wk_ad[kind]' ) { sync(); }
				if ( t.name !== 'wk_ad[slots][]' ) { return; }
				var all = document.querySelector( '[data-wk-all]' );
				if ( t === all && all.checked ) { document.querySelectorAll( 'input[name="wk_ad[slots][]"]' ).forEach( function ( c ) { if ( c !== all ) { c.checked = false; } } ); }
				else if ( t !== all && t.checked ) { all.checked = false; }
			} );
			sync();
			var btn = document.getElementById( 'wk_ad_media_btn' ), frame;
			if ( btn && window.wp && wp.media ) {
				btn.addEventListener( 'click', function () {
					var k = ( document.querySelector( 'input[name="wk_ad[kind]"]:checked' ) || {} ).value;
					frame = wp.media( { title: btn.textContent, library: { type: k === 'audio' ? 'audio' : 'video' }, multiple: false } );
					frame.on( 'select', function () {
						var a = frame.state().get( 'selection' ).first().toJSON();
						document.getElementById( 'wk_ad_media' ).value = a.id;
						document.getElementById( 'wk_ad_media_name' ).textContent = a.filename || a.title;
					} );
					frame.open();
				} );
			}
		}() );
		</script>
		<?php
	}

	public static function stats_box( $post ) {
		list( $v30, $c30 ) = Module::totals( $post->ID, 30 );
		list( $v, $c )     = Module::totals( $post->ID );
		$d    = Module::get( $post->ID );
		$live = Module::is_live( $d );
		echo '<p><strong>' . ( $live ? '<span style="color:#1f7a63">● ' . esc_html__( 'En rotación', 'wakoo' ) . '</span>' : '<span style="color:#b32d2e">● ' . esc_html__( 'No se muestra', 'wakoo' ) . '</span>' ) . '</strong></p>';
		if ( ! $live ) {
			echo '<p class="description">' . esc_html__( 'Revisa que esté publicado, dentro de sus fechas y con lo que su tipo necesita (enlace o miembro; archivo; código; anuncio del marketplace).', 'wakoo' ) . '</p>';
		}
		echo '<table class="widefat striped"><thead><tr><th></th><th>' . esc_html__( '30 días', 'wakoo' ) . '</th><th>' . esc_html__( 'Total', 'wakoo' ) . '</th></tr></thead><tbody>';
		echo '<tr><td>' . esc_html__( 'Vistas', 'wakoo' ) . '</td><td>' . (int) $v30 . '</td><td>' . (int) $v . '</td></tr>';
		echo '<tr><td>' . esc_html__( 'Clics', 'wakoo' ) . '</td><td>' . (int) $c30 . '</td><td>' . (int) $c . '</td></tr>';
		echo '<tr><td>CTR</td><td>' . esc_html( self::ctr( $v30, $c30 ) ) . '</td><td>' . esc_html( self::ctr( $v, $c ) ) . '</td></tr></tbody></table>';
		echo '<p class="description">' . esc_html__( 'Una vista cuenta cuando al menos la mitad del anuncio estuvo en pantalla un segundo.', 'wakoo' ) . '</p>';
	}

	private static function ctr( $v, $c ) {
		return $v ? number_format_i18n( 100 * $c / $v, 1 ) . ' %' : '—';
	}

	public static function save( $id, $post ) {
		if ( ! isset( $_POST['_wkad'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wkad'] ) ), 'wakoo_ad_save' ) || ! current_user_can( 'edit_post', $id ) ) {
			return;
		}
		$in   = isset( $_POST['wk_ad'] ) ? (array) wp_unslash( $_POST['wk_ad'] ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized below.
		$date = function ( $v ) { return preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $v ) ? $v : ''; };
		$hour = function ( $v, $max ) { return '' === (string) $v ? '' : (string) max( 0, min( $max, (int) $v ) ); };
		$vals = [
			'kind'       => in_array( $in['kind'] ?? '', Module::KINDS, true ) ? $in['kind'] : 'image',
			'headline'   => sanitize_text_field( $in['headline'] ?? '' ),
			'text'       => sanitize_textarea_field( $in['text'] ?? '' ),
			'cta'        => sanitize_text_field( $in['cta'] ?? '' ),
			'url'        => esc_url_raw( $in['url'] ?? '' ),
			'member'     => (int) ( $in['member'] ?? 0 ),
			'media'      => (int) ( $in['media'] ?? 0 ),
			'listing'    => (int) ( $in['listing'] ?? 0 ),
			'position'   => max( 0, min( Module::MARKET, (int) ( $in['position'] ?? 0 ) ) ),
			'slots'      => self::slots_in( (array) ( $in['slots'] ?? [] ) ),
			'langs'      => array_values( array_filter( array_map( 'sanitize_key', (array) ( $in['langs'] ?? [] ) ) ) ),
			'start'      => $date( $in['start'] ?? '' ),
			'end'        => $date( $in['end'] ?? '' ),
			'weekdays'   => array_values( array_unique( array_map( function ( $v ) { return max( 0, min( 6, (int) $v ) ); }, (array) ( $in['weekdays'] ?? [] ) ) ) ),
			'hours_from' => $hour( $in['hours_from'] ?? '', 23 ),
			'hours_to'   => $hour( $in['hours_to'] ?? '', 24 ),
			'devices'    => array_values( array_intersect( (array) ( $in['devices'] ?? [] ), [ 'desktop', 'tablet', 'mobile' ] ) ),
			'cap'        => max( 0, min( 100, (int) ( $in['cap'] ?? 0 ) ) ),
			'priority'   => 'fixed' === ( $in['priority'] ?? '' ) ? 'fixed' : 'rotate',
			'weight'     => max( 1, min( 10, (int) ( $in['weight'] ?? 5 ) ) ),
		];
		// The code is kept as written (it runs in a sandboxed frame), and only from users who may publish unfiltered HTML.
		if ( current_user_can( 'unfiltered_html' ) && isset( $in['code'] ) ) {
			$vals['code'] = (string) $in['code'];
		}
		foreach ( $vals as $k => $v ) {
			update_post_meta( $id, '_wk_ad_' . $k, $v );
		}
		Module::bump( $id );
	}

	/** «*» = every space (stored as []); nothing ticked = no space (the ad waits, stored as [ Module::NONE ]). */
	private static function slots_in( array $raw ) {
		if ( in_array( '*', $raw, true ) ) {
			return [];
		}
		$keys = array_values( array_filter( array_map( 'sanitize_key', $raw ) ) );
		return $keys ? $keys : [ Module::NONE ];
	}

	/* ---------------------------------------------------------------- list */

	public static function columns( $cols ) {
		return [
			'cb'        => $cols['cb'] ?? '',
			'wk_img'    => '',
			'title'     => __( 'Anuncio', 'wakoo' ),
			'wk_kind'   => __( 'Tipo', 'wakoo' ),
			'wk_where'  => __( 'Espacios', 'wakoo' ),
			'wk_dates'  => __( 'Programación', 'wakoo' ),
			'wk_views'  => __( 'Vistas (30 d)', 'wakoo' ),
			'wk_clicks' => __( 'Clics (30 d)', 'wakoo' ),
			'wk_ctr'    => 'CTR',
		];
	}

	public static function column( $col, $id ) {
		$d = Module::get( $id );
		list( $v, $c ) = Module::totals( $id, 30 );
		switch ( $col ) {
			case 'wk_img':
				echo self::thumb( $d, 64 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				break;
			case 'wk_kind':
				echo esc_html( self::kinds()[ $d['kind'] ][0] ?? '' );
				echo 'fixed' === $d['priority'] ? '<br><small>' . esc_html__( 'Fijo', 'wakoo' ) . '</small>' : '';
				break;
			case 'wk_where':
				echo esc_html( self::where( $d ) );
				echo $d['langs'] ? '<br><small>' . esc_html( strtoupper( implode( ' · ', $d['langs'] ) ) ) . '</small>' : '';
				break;
			case 'wk_dates':
				echo esc_html( self::schedule( $d ) );
				echo Module::is_live( $d ) ? '' : '<br><small style="color:#b32d2e">' . esc_html__( 'No se muestra', 'wakoo' ) . '</small>';
				break;
			case 'wk_views':
				echo (int) $v;
				break;
			case 'wk_clicks':
				echo (int) $c;
				break;
			case 'wk_ctr':
				echo esc_html( self::ctr( $v, $c ) );
				break;
		}
	}

	private static function where( array $d ) {
		if ( 'listing' === $d['kind'] ) {
			/* translators: %d: position */
			return __( 'Marketplace', 'wakoo' ) . ( $d['position'] ? ' · ' . sprintf( __( 'puesto %d', 'wakoo' ), $d['position'] ) : '' );
		}
		if ( [ Module::NONE ] === $d['slots'] ) {
			return __( 'Ningún espacio (en espera)', 'wakoo' );
		}
		return $d['slots'] ? implode( ', ', array_map( function ( $k ) { return Module::slot_name( $k, false ); }, $d['slots'] ) ) : __( 'Todos los espacios', 'wakoo' );
	}

	private static function schedule( array $d ) {
		global $wp_locale;
		$bits = [ ( $d['start'] ?: '…' ) . ' → ' . ( $d['end'] ?: '…' ) ];
		if ( $d['weekdays'] && count( $d['weekdays'] ) < 7 ) {
			$bits[] = implode( ' ', array_map( function ( $w ) use ( $wp_locale ) { return $wp_locale->get_weekday_abbrev( $wp_locale->get_weekday( $w ) ); }, $d['weekdays'] ) );
		}
		if ( '' !== (string) $d['hours_from'] || '' !== (string) $d['hours_to'] ) {
			$bits[] = sprintf( '%02d–%02d h', (int) $d['hours_from'], '' === (string) $d['hours_to'] ? 24 : (int) $d['hours_to'] );
		}
		if ( $d['devices'] && count( $d['devices'] ) < 3 ) { $bits[] = implode( '/', $d['devices'] ); }
		/* translators: %d: views per day */
		if ( $d['cap'] ) { $bits[] = sprintf( __( 'máx. %d/día', 'wakoo' ), $d['cap'] ); }
		return implode( ' · ', $bits );
	}

	/** Thumbnail of an ad: its image (or the video poster / listing photo), else the icon of its kind. */
	public static function thumb( array $d, $size = 72 ) {
		$img = $d['image'];
		if ( ! $img && 'listing' === $d['kind'] && $d['listing'] && class_exists( '\Wakoo\Modules\Members\Board' ) ) {
			$it  = \Wakoo\Modules\Members\Board::item( $d['listing'] );
			$img = $it ? (int) $it['image'] : 0;
		}
		$k = self::kinds()[ $d['kind'] ] ?? self::kinds()['image'];
		if ( $img ) {
			$html = wp_get_attachment_image( $img, [ $size * 2, $size * 2 ], false, [ 'style' => 'width:100%;height:100%;object-fit:cover;display:block', 'alt' => '' ] );
		} else {
			$html = '<span class="dashicons ' . esc_attr( $k[1] ) . '" style="font-size:' . (int) ( $size / 2.4 ) . 'px;width:auto;height:auto;color:#7a3bd1"></span>';
		}
		return '<span class="wk-thumb" style="position:relative;display:inline-grid;place-items:center;width:' . (int) $size . 'px;height:' . (int) round( $size * .75 ) . 'px;border-radius:8px;overflow:hidden;background:#f3eefc;flex:none">'
			. $html . ( $img && 'image' !== $d['kind'] ? '<span class="dashicons ' . esc_attr( $k[1] ) . '" style="position:absolute;right:3px;bottom:3px;font-size:14px;width:18px;height:18px;line-height:18px;border-radius:4px;background:rgba(0,0,0,.6);color:#fff"></span>' : '' ) . '</span>';
	}

	/* ---------------------------------------------------------------- hub */

	public static function ajax() {
		check_ajax_referer( 'wakoo_ads_hub' );
		$op = sanitize_key( wp_unslash( $_POST['op'] ?? '' ) );
		if ( 'renumber' === $op ) {
			if ( ! current_user_can( 'edit_pages' ) ) { wp_send_json_error( null, 403 ); }
			wp_send_json_success( [ 'n' => Module::renumber() ] );
		}
		$id = (int) ( $_POST['ad'] ?? 0 );
		if ( Module::CPT !== get_post_type( $id ) || ! current_user_can( 'edit_post', $id ) ) {
			wp_send_json_error( null, 403 );
		}
		$slot = sanitize_key( wp_unslash( $_POST['slot'] ?? '' ) );
		$d    = Module::get( $id );
		switch ( $op ) {
			case 'add':
				$d['slots'] = array_values( array_diff( $d['slots'], [ Module::NONE ] ) );
				if ( $slot && ! in_array( $slot, $d['slots'], true ) ) { $d['slots'][] = $slot; }
				update_post_meta( $id, '_wk_ad_slots', $d['slots'] );
				break;
			case 'remove':
				$left = array_values( array_diff( $d['slots'], [ $slot, Module::NONE ] ) );
				update_post_meta( $id, '_wk_ad_slots', $left ? $left : [ Module::NONE ] );
				break;
			case 'weight':
				update_post_meta( $id, '_wk_ad_weight', max( 1, min( 10, (int) ( $_POST['value'] ?? 5 ) ) ) );
				break;
			case 'position':
				update_post_meta( $id, '_wk_ad_position', max( 0, min( Module::MARKET, (int) ( $_POST['value'] ?? 0 ) ) ) );
				break;
			case 'priority':
				update_post_meta( $id, '_wk_ad_priority', 'fixed' === ( $_POST['value'] ?? '' ) ? 'fixed' : 'rotate' );
				break;
			default:
				wp_send_json_error( null, 400 );
		}
		Module::bump( $id );
		wp_send_json_success();
	}

	public static function hub() {
		$days  = isset( $_GET['days'] ) ? max( 1, min( 60, (int) $_GET['days'] ) ) : 30; // phpcs:ignore WordPress.Security.NonceVerification
		$posts = get_posts( [ 'post_type' => Module::CPT, 'post_status' => [ 'publish', 'draft', 'future', 'pending' ], 'posts_per_page' => 300, 'orderby' => 'date', 'order' => 'DESC' ] );
		$ads   = array_map( function ( $p ) { return Module::get( $p->ID ); }, $posts );
		$slots = Module::slots();
		$new   = admin_url( 'post-new.php?post_type=' . Module::CPT );
		$tv    = 0;
		$tc    = 0;
		$stats = [];
		foreach ( $ads as $d ) {
			$stats[ $d['id'] ] = Module::totals( $d['id'], $days );
			$tv += $stats[ $d['id'] ][0];
			$tc += $stats[ $d['id'] ][1];
		}
		$live = array_filter( $ads, function ( $d ) { return Module::is_live( $d ); } );
		self::hub_style();
		echo '<div class="wrap wk-hub"><h1 class="wp-heading-inline">' . esc_html__( 'Panel de anuncios', 'wakoo' ) . '</h1>';
		echo '<div class="wk-hub__new">';
		foreach ( self::kinds() as $k => $kd ) {
			echo '<a class="button" href="' . esc_url( add_query_arg( 'wk_kind', $k, $new ) ) . '"><span class="dashicons ' . esc_attr( $kd[1] ) . '"></span> ' . esc_html( $kd[0] ) . '</a>';
		}
		echo '</div><hr class="wp-header-end">';

		// Key figures.
		echo '<div class="wk-hub__kpis">';
		foreach ( [
			[ __( 'Anuncios activos', 'wakoo' ), count( $live ) . ' / ' . count( $ads ) ],
			[ __( 'Espacios', 'wakoo' ), count( $slots ) ],
			/* translators: %d: days */
			[ sprintf( __( 'Vistas (%d días)', 'wakoo' ), $days ), number_format_i18n( $tv ) ],
			[ __( 'Clics', 'wakoo' ), number_format_i18n( $tc ) ],
			[ 'CTR', self::ctr( $tv, $tc ) ],
		] as $kpi ) {
			echo '<div class="wk-hub__kpi"><strong>' . esc_html( (string) $kpi[1] ) . '</strong><span>' . esc_html( $kpi[0] ) . '</span></div>';
		}
		echo '<div class="wk-hub__range">';
		foreach ( [ 7, 30, 60 ] as $n ) {
			/* translators: %d: days */
			echo '<a class="button' . ( $n === $days ? ' button-primary' : '' ) . '" href="' . esc_url( add_query_arg( 'days', $n ) ) . '">' . esc_html( sprintf( __( '%d días', 'wakoo' ), $n ) ) . '</a> ';
		}
		echo '</div></div>';

		// Spaces with the thumbnails of their ads.
		echo '<h2>' . esc_html__( 'Espacios', 'wakoo' ) . ' <button type="button" class="button" data-wk-op="renumber">' . esc_html__( 'Renumerar en el orden de las páginas', 'wakoo' ) . '</button></h2>';
		echo '<p class="description">' . esc_html__( 'Cada widget «Espacio publicitario (Wakoo)» recibe un número al soltarlo en una página. Añade o quita anuncios de cada espacio y ajusta su peso: los cambios se aplican al momento.', 'wakoo' ) . '</p>';
		echo '<div class="wk-hub__slots">';
		$rot = array_filter( $ads, function ( $d ) { return ! in_array( $d['kind'], [ 'listing' ], true ); } );
		foreach ( $slots as $key => $s ) {
			$in  = array_filter( $rot, function ( $d ) use ( $key ) { return in_array( $key, $d['slots'], true ); } );
			$all = array_filter( $rot, function ( $d ) { return ! $d['slots']; } );
			echo '<section class="wk-hub__slot" data-slot="' . esc_attr( $key ) . '"><header><strong>' . esc_html( Module::slot_name( $key, false ) ) . '</strong>'
				. ( ! empty( $s['size'] ) ? '<span class="wk-hub__size">' . esc_html( $s['size'] ) . '</span>' : '' )
				. ( ! empty( $s['url'] ) ? '<a href="' . esc_url( $s['url'] ) . '" target="_blank">' . esc_html( wp_parse_url( $s['url'], PHP_URL_PATH ) ?: '/' ) . '</a>' : '' ) . '</header>'
				. ( ! empty( $s['label'] ) ? '<p class="wk-hub__label">' . esc_html( $s['label'] ) . '</p>' : '' ) . '<ul>';
			foreach ( array_merge( $in, $all ) as $d ) {
				$shared = ! $d['slots'];
				echo '<li class="' . ( $shared ? 'is-shared' : '' ) . ( Module::is_live( $d ) ? '' : ' is-off' ) . '">' . self::thumb( $d, 64 ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					. '<div><a href="' . esc_url( get_edit_post_link( $d['id'] ) ) . '">' . esc_html( $d['title'] ?: __( '(sin título)', 'wakoo' ) ) . '</a><small>' . esc_html( self::schedule( $d ) ) . ( $shared ? ' · ' . esc_html__( 'en todos los espacios', 'wakoo' ) : '' ) . '</small>'
					. '<label>' . esc_html__( 'Peso', 'wakoo' ) . ' <input type="number" min="1" max="10" value="' . (int) $d['weight'] . '" data-wk-op="weight" data-ad="' . (int) $d['id'] . '"></label>'
					. ( 'fixed' === $d['priority'] ? '<span class="wk-hub__fixed">' . esc_html__( 'Fijo', 'wakoo' ) . '</span>' : '' ) . '</div>'
					. ( $shared ? '' : '<button type="button" class="wk-hub__x" title="' . esc_attr__( 'Quitar de este espacio', 'wakoo' ) . '" data-wk-op="remove" data-ad="' . (int) $d['id'] . '">×</button>' ) . '</li>';
			}
			if ( ! $in && ! $all ) {
				echo '<li class="wk-hub__empty">' . esc_html__( 'Sin anuncios: se ve el anuncio propio del widget.', 'wakoo' ) . '</li>';
			}
			echo '</ul><select data-wk-op="add"><option value="">' . esc_html__( '+ Añadir un anuncio…', 'wakoo' ) . '</option>';
			foreach ( $rot as $d ) {
				if ( ! $d['slots'] || in_array( $key, $d['slots'], true ) ) { continue; }
				echo '<option value="' . (int) $d['id'] . '">' . esc_html( $d['title'] ?: '#' . $d['id'] ) . '</option>';
			}
			echo '</select></section>';
		}
		if ( ! $slots ) {
			echo '<p>' . esc_html__( 'Aún no hay espacios. Arrastra el widget «Espacio publicitario (Wakoo)» a una página.', 'wakoo' ) . '</p>';
		}
		echo '</div>';

		// Marketplace featured positions.
		$listing_ads = array_filter( $ads, function ( $d ) { return 'listing' === $d['kind']; } );
		echo '<h2>' . esc_html__( 'Marketplace: los 3 primeros puestos', 'wakoo' ) . '</h2><p class="description">' . esc_html__( 'Por defecto salen los anuncios más nuevos. Un anuncio «Destacado del marketplace» ocupa el puesto que le pongas (o el primero libre) mientras esté activo.', 'wakoo' ) . '</p>';
		echo '<div class="wk-hub__slots">';
		foreach ( $listing_ads as $d ) {
			$it  = class_exists( '\Wakoo\Modules\Members\Board' ) && $d['listing'] ? \Wakoo\Modules\Members\Board::item( $d['listing'] ) : null;
			$sel = '<select data-wk-op="position" data-ad="' . (int) $d['id'] . '"><option value="0">' . esc_html__( 'Primer puesto libre', 'wakoo' ) . '</option>';
			for ( $i = 1; $i <= Module::MARKET; $i++ ) {
				/* translators: %d: position */
				$sel .= '<option value="' . $i . '"' . selected( $d['position'], $i, false ) . '>' . esc_html( sprintf( __( 'Puesto %d', 'wakoo' ), $i ) ) . '</option>';
			}
			$sel .= '</select>';
			echo '<section class="wk-hub__slot' . ( Module::is_live( $d ) ? '' : ' is-off' ) . '"><ul><li>' . self::thumb( $d, 64 ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				. '<div><a href="' . esc_url( get_edit_post_link( $d['id'] ) ) . '">' . esc_html( $d['title'] ?: __( '(sin título)', 'wakoo' ) ) . '</a><small>' . esc_html( $it ? $it['title'] : __( 'Sin anuncio del marketplace', 'wakoo' ) ) . ' · ' . esc_html( self::schedule( $d ) ) . '</small>' . $sel . '</div></li></ul></section>';
		}
		echo '<p><a class="button" href="' . esc_url( add_query_arg( 'wk_kind', 'listing', $new ) ) . '">' . esc_html__( '+ Destacar un anuncio del marketplace', 'wakoo' ) . '</a></p></div>';

		// All ads.
		echo '<h2>' . esc_html__( 'Todos los anuncios', 'wakoo' ) . '</h2><div class="wk-hub__ads">';
		foreach ( $ads as $d ) {
			list( $v, $c ) = $stats[ $d['id'] ];
			echo '<a class="wk-hub__ad' . ( Module::is_live( $d ) ? '' : ' is-off' ) . '" href="' . esc_url( get_edit_post_link( $d['id'] ) ) . '">' . self::thumb( $d, 220 ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				. '<strong>' . esc_html( $d['title'] ?: __( '(sin título)', 'wakoo' ) ) . '</strong><small>' . esc_html( ( self::kinds()[ $d['kind'] ][0] ?? '' ) . ' · ' . self::where( $d ) ) . '</small>'
				. '<small>' . esc_html( self::schedule( $d ) ) . '</small><small>' . esc_html( sprintf( '%s · %s · CTR %s', number_format_i18n( $v ) . ' ' . __( 'vistas', 'wakoo' ), number_format_i18n( $c ) . ' ' . __( 'clics', 'wakoo' ), self::ctr( $v, $c ) ) ) . '</small></a>';
		}
		if ( ! $ads ) {
			echo '<p>' . esc_html__( 'Aún no hay anuncios.', 'wakoo' ) . '</p>';
		}
		echo '</div></div>';
		self::hub_script();
	}

	private static function hub_style() {
		echo '<style>
		.wk-hub__new{display:inline-flex;flex-wrap:wrap;gap:6px;margin:0 0 0 10px;vertical-align:middle}.wk-hub__new .dashicons{vertical-align:middle;font-size:16px}
		.wk-hub__kpis{display:flex;flex-wrap:wrap;gap:12px;align-items:stretch;margin:16px 0}
		.wk-hub__kpi{background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:12px 18px;min-width:130px}.wk-hub__kpi strong{display:block;font-size:22px;line-height:1.2}.wk-hub__kpi span{color:#646970}
		.wk-hub__range{margin-left:auto;align-self:center}
		.wk-hub h2 .button{margin-left:10px;vertical-align:middle}
		.wk-hub__slots{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:14px;margin:12px 0 26px}
		.wk-hub__slot{background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:14px}.wk-hub__slot.is-off{opacity:.6}
		.wk-hub__slot header{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.wk-hub__slot header strong{font-size:15px}.wk-hub__slot header a{margin-left:auto}
		.wk-hub__size{background:#f3eefc;color:#5a28a0;border-radius:99px;padding:1px 8px;font-size:12px}.wk-hub__label{margin:4px 0 0;color:#646970}
		.wk-hub__slot ul{margin:10px 0}.wk-hub__slot li{display:flex;gap:10px;align-items:center;padding:6px 0;border-top:1px solid #f0f0f1}.wk-hub__slot li:first-child{border-top:0}
		.wk-hub__slot li > div{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}.wk-hub__slot li small{color:#646970}.wk-hub__slot li.is-shared{opacity:.75}.wk-hub__slot li.is-off{opacity:.45}
		.wk-hub__slot li input[type=number]{width:56px}.wk-hub__fixed{align-self:flex-start;background:#fff4d6;color:#8a5a00;border-radius:4px;padding:0 6px;font-size:11px}
		.wk-hub__x{border:0;background:none;font-size:20px;cursor:pointer;color:#b32d2e}.wk-hub__empty{color:#646970;font-style:italic}
		.wk-hub__ads{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px}
		.wk-hub__ad{display:flex;flex-direction:column;gap:4px;background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:10px;text-decoration:none;color:#1d2327}
		.wk-hub__ad:hover{border-color:#7a3bd1}.wk-hub__ad .wk-thumb{width:100%!important;height:140px!important}.wk-hub__ad small{color:#646970}.wk-hub__ad.is-off{opacity:.55}
		</style>';
	}

	private static function hub_script() {
		$cfg = [ 'ajax' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'wakoo_ads_hub' ), 'done' => __( 'Hecho', 'wakoo' ) ];
		?>
		<script>
		( function ( cfg ) {
			function send( data, reload ) {
				data.action = 'wakoo_ads_hub';
				data._ajax_nonce = cfg.nonce;
				return fetch( cfg.ajax, { method: 'POST', credentials: 'same-origin', body: new URLSearchParams( data ) } ).then( function ( r ) { return r.json(); } ).then( function ( res ) {
					if ( reload && res.success ) { location.reload(); }
					return res;
				} );
			}
			document.addEventListener( 'click', function ( e ) {
				var b = e.target.closest( '[data-wk-op]' );
				if ( ! b || 'BUTTON' !== b.tagName ) { return; }
				var slot = b.closest( '[data-slot]' );
				send( { op: b.dataset.wkOp, ad: b.dataset.ad || 0, slot: slot ? slot.dataset.slot : '' }, true );
			} );
			document.addEventListener( 'change', function ( e ) {
				var t = e.target;
				if ( ! t.dataset || ! t.dataset.wkOp ) { return; }
				var slot = t.closest( '[data-slot]' );
				if ( 'add' === t.dataset.wkOp ) {
					if ( t.value ) { send( { op: 'add', ad: t.value, slot: slot.dataset.slot }, true ); }
					return;
				}
				send( { op: t.dataset.wkOp, ad: t.dataset.ad, value: t.value }, false ).then( function () { t.style.outline = '2px solid #1f7a63'; setTimeout( function () { t.style.outline = ''; }, 900 ); } );
			} );
		}( <?php echo wp_json_encode( $cfg ); ?> ) );
		</script>
		<?php
	}
}
