( function () {
	'use strict';
	function init( root ) {
		if ( root.dataset.wakooInit ) { return; }
		root.dataset.wakooInit = '1';
		var opts = root.querySelectorAll( '.wakoo-price__opt' );
		var track = root.querySelector( '.wakoo-price__track' );

		function set( p ) {
			root.setAttribute( 'data-period', p );
			Array.prototype.forEach.call( opts, function ( o ) { o.setAttribute( 'aria-pressed', o.getAttribute( 'data-p' ) === p ? 'true' : 'false' ); } );
			if ( track ) { track.setAttribute( 'aria-checked', 'y' === p ? 'true' : 'false' ); }
			Array.prototype.forEach.call( root.querySelectorAll( '.wakoo-price__num' ), function ( n ) { n.textContent = n.getAttribute( 'data-' + p ); } );
			Array.prototype.forEach.call( root.querySelectorAll( '.wakoo-price__btn' ), function ( b ) {
				var h = b.getAttribute( 'data-href-' + p ); if ( h ) { b.setAttribute( 'href', h ); }
			} );
		}
		Array.prototype.forEach.call( opts, function ( o ) { o.addEventListener( 'click', function () { set( o.getAttribute( 'data-p' ) ); } ); } );
		if ( track ) { track.addEventListener( 'click', function () { set( 'y' === root.getAttribute( 'data-period' ) ? 'm' : 'y' ); } ); }
		set( root.getAttribute( 'data-period' ) || 'm' );
	}
	function boot( scope ) {
		( scope && scope.querySelectorAll ? scope : document ).querySelectorAll( '.wakoo-price' ).forEach( init );
	}
	if ( 'loading' === document.readyState ) { document.addEventListener( 'DOMContentLoaded', function () { boot( document ); } ); } else { boot( document ); }
	if ( window.jQuery ) {
		window.jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend && window.elementorFrontend.hooks ) {
				window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-pricing.default', function ( $s ) { boot( $s[ 0 ] ); } );
			}
		} );
	}
}() );
