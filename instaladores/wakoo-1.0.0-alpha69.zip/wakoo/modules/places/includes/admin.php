<?php
/**
 * Wakoo Lugares in wp-admin: the place form (meta box), category names per
 * language, list columns and the "Importar y ajustes" screen (CSV in/out,
 * Place Finder import, missing coordinates, finder page and map tiles).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Places;

defined( 'ABSPATH' ) || die();

class Admin {

	const PAGE = 'wakoo-places-tools';

	public static function init() {
		add_action( 'add_meta_boxes_' . Module::CPT, [ __CLASS__, 'boxes' ] );
		add_action( 'save_post_' . Module::CPT, [ __CLASS__, 'save' ], 10, 2 );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'assets' ] );
		add_action( 'admin_menu', [ __CLASS__, 'menu' ] );
		add_filter( 'manage_' . Module::CPT . '_posts_columns', [ __CLASS__, 'columns' ] );
		add_action( 'manage_' . Module::CPT . '_posts_custom_column', [ __CLASS__, 'column' ], 10, 2 );
		add_action( Module::TAX . '_add_form_fields', [ __CLASS__, 'term_add' ] );
		add_action( Module::TAX . '_edit_form_fields', [ __CLASS__, 'term_edit' ] );
		add_action( 'created_' . Module::TAX, [ __CLASS__, 'term_save' ] );
		add_action( 'edited_' . Module::TAX, [ __CLASS__, 'term_save' ] );
		foreach ( [ 'settings', 'import', 'export', 'lapf', 'coords', 'quick', 'trash' ] as $a ) {
			add_action( 'admin_post_wakoo_places_' . $a, [ __CLASS__, 'handle_' . $a ] );
		}
	}

	/* ---------------------------------------------------------------- place form */

	public static function boxes() {
		add_meta_box( 'wakoo-place', __( 'Datos del lugar', 'wakoo' ), [ __CLASS__, 'box' ], Module::CPT, 'normal', 'high' );
	}

	public static function assets( $hook ) {
		$screen = get_current_screen();
		if ( $screen && Module::CPT === $screen->post_type && in_array( $hook, [ 'post.php', 'post-new.php' ], true ) ) {
			wp_enqueue_media();
		}
	}

	private static function row( $label, $html, $help = '' ) {
		return '<p class="wk-pl-row"><label><strong>' . esc_html( $label ) . '</strong><br>' . $html . '</label>'
			. ( $help ? '<br><span class="description">' . esc_html( $help ) . '</span>' : '' ) . '</p>';
	}

	public static function box( $post ) {
		wp_nonce_field( Module::NONCE, 'wakoo_place_nonce' );
		$v   = function ( $k ) use ( $post ) { return Module::get( $post->ID, $k ); };
		$in  = function ( $k, $type = 'text', $ph = '' ) use ( $v ) {
			return '<input type="' . esc_attr( $type ) . '" name="wk_place[' . esc_attr( $k ) . ']" value="' . esc_attr( $v( $k ) ) . '" class="widefat" placeholder="' . esc_attr( $ph ) . '">';
		};
		$master = Module::master();
		echo '<style>.wk-pl-row{margin:0 0 14px}.wk-pl-grid{display:grid;grid-template-columns:1fr 1fr;gap:0 18px}.wk-pl-photos{display:flex;gap:8px;flex-wrap:wrap;margin:6px 0}.wk-pl-photos img{width:72px;height:72px;object-fit:cover;border-radius:8px}</style>';
		echo self::row( __( 'Dirección', 'wakoo' ), $in( 'address', 'text', '1500 Lee Blvd, Lehigh Acres, FL 33936' ), __( 'Si dejas las coordenadas vacías, se buscan solas a partir de la dirección al guardar.', 'wakoo' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<div class="wk-pl-grid">';
		echo self::row( __( 'Latitud', 'wakoo' ), $in( 'lat', 'text', '26.6124' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo self::row( __( 'Longitud', 'wakoo' ), $in( 'lng', 'text', '-81.6558' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo self::row( __( 'Teléfono', 'wakoo' ), $in( 'phone', 'tel' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo self::row( __( 'Email', 'wakoo' ), $in( 'email', 'email' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo self::row( __( 'Sitio web', 'wakoo' ), $in( 'website', 'url', 'https://' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo self::row( __( 'Enlace de Google Maps (opcional)', 'wakoo' ), $in( 'maps_url', 'url', 'https://maps.google.com/…' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo '</div>';
		$lab = $master ? sprintf( /* translators: %s: language code */ __( 'Descripción (%s, idioma maestro)', 'wakoo' ), strtoupper( $master ) ) : __( 'Descripción', 'wakoo' );
		echo self::row( $lab, '<textarea name="wk_place[desc]" rows="4" class="widefat">' . esc_textarea( $v( 'desc' ) ) . '</textarea>' ); // phpcs:ignore WordPress.Security.EscapeOutput
		foreach ( Module::other_langs() as $code => $name ) {
			echo self::row( sprintf( /* translators: %s: language name */ __( 'Descripción en %s', 'wakoo' ), $name ), '<textarea name="wk_place[desc_' . esc_attr( $code ) . ']" rows="3" class="widefat">' . esc_textarea( $v( 'desc_' . $code ) ) . '</textarea>', __( 'Vacía = se muestra la descripción maestra (texto pendiente de traducir).', 'wakoo' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo self::row( __( 'Palabras clave para el buscador', 'wakoo' ), $in( 'tags', 'text', 'farmacia pharmacy 24h drive-thru' ), __( 'Separadas por espacios, en cualquier idioma: así lo encuentran también quienes buscan con otras palabras.', 'wakoo' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo self::row( __( 'Opiniones (opcional)', 'wakoo' ), '<textarea name="wk_place[reviews]" rows="3" class="widefat">' . esc_textarea( $v( 'reviews' ) ) . '</textarea>', __( 'Solo opiniones reales y con permiso de quien las escribió.', 'wakoo' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		$photos = Module::photos( $post->ID );
		$thumbs = '';
		foreach ( $photos as $ph ) { $thumbs .= '<img src="' . esc_url( $ph['url'] ) . '" alt="">'; }
		echo '<div class="wk-pl-row"><strong>' . esc_html__( 'Fotos', 'wakoo' ) . '</strong><div class="wk-pl-photos" id="wk-pl-photos">' . $thumbs . '</div>' // phpcs:ignore WordPress.Security.EscapeOutput
			. '<input type="hidden" name="wk_place[photos]" id="wk-pl-photo-ids" value="' . esc_attr( implode( ',', array_filter( wp_list_pluck( $photos, 'id' ) ) ) ) . '">'
			. '<button type="button" class="button" id="wk-pl-pick">' . esc_html__( 'Elegir fotos', 'wakoo' ) . '</button> '
			. '<button type="button" class="button-link" id="wk-pl-clear">' . esc_html__( 'Quitar fotos', 'wakoo' ) . '</button></div>';
		?>
		<script>
		( function () {
			var pick = document.getElementById( 'wk-pl-pick' ), clear = document.getElementById( 'wk-pl-clear' ),
				ids = document.getElementById( 'wk-pl-photo-ids' ), box = document.getElementById( 'wk-pl-photos' ), frame;
			pick.addEventListener( 'click', function () {
				frame = frame || wp.media( { title: pick.textContent, multiple: true, library: { type: 'image' } } );
				frame.off( 'select' ).on( 'select', function () {
					var sel = frame.state().get( 'selection' ).toJSON();
					ids.value = sel.map( function ( a ) { return a.id; } ).join( ',' );
					box.textContent = '';
					sel.forEach( function ( a ) { var i = document.createElement( 'img' ); i.src = ( a.sizes && a.sizes.thumbnail ? a.sizes.thumbnail.url : a.url ); i.alt = ''; box.appendChild( i ); } );
				} );
				frame.open();
			} );
			clear.addEventListener( 'click', function () { ids.value = ''; box.textContent = ''; } );
		}() );
		</script>
		<?php
	}

	public static function save( $id, $post ) {
		if ( ! isset( $_POST['wakoo_place_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['wakoo_place_nonce'] ) ), Module::NONCE ) ) { return; }
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $id ) ) { return; }
		$in = isset( $_POST['wk_place'] ) && is_array( $_POST['wk_place'] ) ? wp_unslash( $_POST['wk_place'] ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$set = function ( $k, $val ) use ( $id ) { update_post_meta( $id, Module::PRE . $k, $val ); };
		$set( 'address', sanitize_text_field( $in['address'] ?? '' ) );
		$set( 'phone', sanitize_text_field( $in['phone'] ?? '' ) );
		$set( 'email', sanitize_email( $in['email'] ?? '' ) );
		$set( 'website', esc_url_raw( $in['website'] ?? '' ) );
		$set( 'maps_url', esc_url_raw( $in['maps_url'] ?? '' ) );
		$set( 'lat', is_numeric( $in['lat'] ?? '' ) ? (string) (float) $in['lat'] : '' );
		$set( 'lng', is_numeric( $in['lng'] ?? '' ) ? (string) (float) $in['lng'] : '' );
		$set( 'reviews', sanitize_textarea_field( $in['reviews'] ?? '' ) );
		$set( 'tags', sanitize_text_field( $in['tags'] ?? '' ) );
		$set( 'desc', sanitize_textarea_field( $in['desc'] ?? '' ) );
		foreach ( array_keys( Module::other_langs() ) as $code ) {
			$set( 'desc_' . $code, sanitize_textarea_field( $in[ 'desc_' . $code ] ?? '' ) );
		}
		$photos = [];
		foreach ( array_filter( array_map( 'absint', explode( ',', (string) ( $in['photos'] ?? '' ) ) ) ) as $aid ) {
			$url = wp_get_attachment_image_url( $aid, 'large' );
			if ( $url ) { $photos[] = [ 'id' => $aid, 'url' => $url ]; }
		}
		$set( 'photos', $photos );
		Module::fill_coords( $id );
		// The excerpt (used by the live search) follows the master description.
		$excerpt = wp_trim_words( (string) ( $in['desc'] ?? '' ), 40, '…' );
		if ( $excerpt !== $post->post_excerpt ) {
			remove_action( 'save_post_' . Module::CPT, [ __CLASS__, 'save' ], 10 );
			wp_update_post( [ 'ID' => $id, 'post_excerpt' => sanitize_textarea_field( $excerpt ) ] );
			add_action( 'save_post_' . Module::CPT, [ __CLASS__, 'save' ], 10, 2 );
		}
	}

	public static function columns( $cols ) {
		$new = [];
		foreach ( $cols as $k => $v ) {
			$new[ $k ] = $v;
			if ( 'title' === $k ) {
				$new['wk_address'] = __( 'Dirección', 'wakoo' );
				$new['wk_coords']  = __( 'En el mapa', 'wakoo' );
			}
		}
		return $new;
	}

	public static function column( $col, $id ) {
		if ( 'wk_address' === $col ) { echo esc_html( Module::get( $id, 'address' ) ); }
		if ( 'wk_coords' === $col ) {
			echo '' !== Module::get( $id, 'lat' ) ? '<span style="color:#1f7a63">✔</span>' : '<span class="description">' . esc_html__( 'sin coordenadas', 'wakoo' ) . '</span>';
		}
	}

	/* ---------------------------------------------------------------- category names per language */

	public static function term_add() {
		foreach ( Module::other_langs() as $code => $name ) {
			echo '<div class="form-field"><label for="wk-label-' . esc_attr( $code ) . '">' . esc_html( sprintf( /* translators: %s: language */ __( 'Nombre en %s', 'wakoo' ), $name ) ) . '</label><input id="wk-label-' . esc_attr( $code ) . '" type="text" name="wk_label[' . esc_attr( $code ) . ']"></div>';
		}
		wp_nonce_field( Module::NONCE, 'wakoo_place_term' );
	}

	public static function term_edit( $term ) {
		foreach ( Module::other_langs() as $code => $name ) {
			echo '<tr class="form-field"><th><label for="wk-label-' . esc_attr( $code ) . '">' . esc_html( sprintf( /* translators: %s: language */ __( 'Nombre en %s', 'wakoo' ), $name ) ) . '</label></th><td><input id="wk-label-' . esc_attr( $code ) . '" type="text" name="wk_label[' . esc_attr( $code ) . ']" value="' . esc_attr( get_term_meta( $term->term_id, 'wk_label_' . $code, true ) ) . '"></td></tr>';
		}
		wp_nonce_field( Module::NONCE, 'wakoo_place_term' );
	}

	public static function term_save( $term_id ) {
		if ( ! isset( $_POST['wakoo_place_term'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['wakoo_place_term'] ) ), Module::NONCE ) || ! current_user_can( 'manage_categories' ) ) { return; }
		$in = isset( $_POST['wk_label'] ) && is_array( $_POST['wk_label'] ) ? wp_unslash( $_POST['wk_label'] ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		foreach ( array_keys( Module::other_langs() ) as $code ) {
			update_term_meta( $term_id, 'wk_label_' . $code, sanitize_text_field( $in[ $code ] ?? '' ) );
		}
	}

	/* ---------------------------------------------------------------- tools screen */

	public static function menu() {
		add_submenu_page( 'edit.php?post_type=' . Module::CPT, __( 'Importar y ajustes', 'wakoo' ), __( 'Importar y ajustes', 'wakoo' ), 'edit_others_posts', self::PAGE, [ __CLASS__, 'page' ] );
	}

	private static function guard( $action ) {
		if ( ! current_user_can( 'edit_others_posts' ) || ! check_admin_referer( 'wakoo_places_' . $action ) ) { wp_die( esc_html__( 'No autorizado.', 'wakoo' ) ); }
	}

	/** Back to the tools screen, or to the page of the "Gestor de lugares" widget that sent the form. */
	private static function back( $msg, $n = 0 ) {
		$from = isset( $_REQUEST['wk_back'] ) ? wp_validate_redirect( esc_url_raw( wp_unslash( $_REQUEST['wk_back'] ) ), '' ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		if ( $from ) {
			wp_safe_redirect( add_query_arg( [ 'wk_pl_msg' => $msg, 'wk_pl_n' => (int) $n ], remove_query_arg( [ 'wk_pl_msg', 'wk_pl_n' ], $from ) ) . '#wk-pl-manager' );
			exit;
		}
		wp_safe_redirect( add_query_arg( [ 'post_type' => Module::CPT, 'page' => self::PAGE, 'msg' => $msg, 'n' => (int) $n ], admin_url( 'edit.php' ) ) );
		exit;
	}

	/** "Gestor de lugares": add a place from the front end. */
	public static function handle_quick() {
		self::guard( 'quick' );
		$in = isset( $_POST['wk'] ) && is_array( $_POST['wk'] ) ? wp_unslash( $_POST['wk'] ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$id = Module::save( [
			'name' => $in['name'] ?? '', 'category' => $in['category'] ?? '', 'address' => $in['address'] ?? '', 'phone' => $in['phone'] ?? '',
			'email' => $in['email'] ?? '', 'website' => $in['website'] ?? '', 'description' => $in['description'] ?? '', 'tags' => $in['tags'] ?? '',
			'lat' => $in['lat'] ?? '', 'lng' => $in['lng'] ?? '',
		] );
		if ( ! $id ) { self::back( 'noname' ); }
		Module::fill_coords( $id );
		self::back( 'added', 1 );
	}

	/** "Gestor de lugares": send a place to the trash (it can be restored from wp-admin). */
	public static function handle_trash() {
		$id = isset( $_REQUEST['id'] ) ? absint( $_REQUEST['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! check_admin_referer( 'wakoo_places_trash_' . $id ) || Module::CPT !== get_post_type( $id ) || ! current_user_can( 'delete_post', $id ) ) { wp_die( esc_html__( 'No autorizado.', 'wakoo' ) ); }
		wp_trash_post( $id );
		self::back( 'trashed', 1 );
	}

	public static function handle_settings() {
		self::guard( 'settings' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'No autorizado.', 'wakoo' ) ); }
		$in  = isset( $_POST['wk'] ) && is_array( $_POST['wk'] ) ? wp_unslash( $_POST['wk'] ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$opt = Module::settings();
		$opt['page']    = absint( $in['page'] ?? 0 );
		$tiles          = esc_url_raw( (string) ( $in['tiles'] ?? '' ), [ 'https' ] );
		$opt['tiles']   = $tiles ? str_replace( [ '%7B', '%7D' ], [ '{', '}' ], $tiles ) : $opt['tiles'];
		$opt['attr']    = wp_kses( (string) ( $in['attr'] ?? '' ), [ 'a' => [ 'href' => [] ] ] ) ?: $opt['attr'];
		$opt['geocode'] = empty( $in['geocode'] ) ? 0 : 1;
		update_option( Module::OPTION, $opt );
		self::back( 'saved' );
	}

	public static function handle_import() {
		self::guard( 'import' );
		$f = $_FILES['wk_csv'] ?? null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( ! $f || ! empty( $f['error'] ) || ! is_uploaded_file( $f['tmp_name'] ) || 'csv' !== strtolower( pathinfo( (string) $f['name'], PATHINFO_EXTENSION ) ) || $f['size'] > 5242880 ) { self::back( 'nofile' ); }
		self::back( 'imported', Module::import_csv( $f['tmp_name'] ) );
	}

	public static function handle_lapf() {
		self::guard( 'lapf' );
		self::back( 'imported', Module::import_place_finder() );
	}

	public static function handle_coords() {
		self::guard( 'coords' );
		if ( function_exists( 'set_time_limit' ) ) { @set_time_limit( 120 ); } // phpcs:ignore
		self::back( 'coords', Module::fill_missing() );
	}

	public static function handle_export() {
		self::guard( 'export' );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="lugares-' . gmdate( 'Y-m-d' ) . '.csv"' );
		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fputcsv( $out, Module::CSV, ',', '"', '\\' );
		foreach ( Module::csv_rows() as $row ) {
			// A cell starting with = + - @ would run as a formula in a spreadsheet.
			$row = array_map( function ( $c ) { return preg_match( '/^[=+\-@\t\r]/', (string) $c ) && ! is_numeric( $c ) ? "'" . $c : $c; }, $row );
			fputcsv( $out, $row, ',', '"', '\\' );
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		exit;
	}

	public static function page() {
		$msgs = [
			'saved'    => [ 'success', __( 'Ajustes guardados.', 'wakoo' ) ],
			'imported' => [ 'success', __( 'Lugares importados o actualizados: %d.', 'wakoo' ) ],
			'coords'   => [ 'success', __( 'Coordenadas encontradas: %d. Si faltan más, vuelve a pulsar el botón.', 'wakoo' ) ],
			'nofile'   => [ 'error', __( 'Sube un archivo .csv de hasta 5 MB.', 'wakoo' ) ],
		];
		$m = isset( $_GET['msg'] ) ? sanitize_key( $_GET['msg'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$n = isset( $_GET['n'] ) ? (int) $_GET['n'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$o = Module::settings();
		$post = esc_url( admin_url( 'admin-post.php' ) );
		echo '<div class="wrap"><h1>' . esc_html__( 'Lugares: importar y ajustes', 'wakoo' ) . '</h1>';
		if ( isset( $msgs[ $m ] ) ) { echo '<div class="notice notice-' . esc_attr( $msgs[ $m ][0] ) . '"><p>' . esc_html( sprintf( $msgs[ $m ][1], $n ) ) . '</p></div>'; }

		if ( current_user_can( 'manage_options' ) ) {
			echo '<h2>' . esc_html__( 'Ajustes', 'wakoo' ) . '</h2><form method="post" action="' . $post . '">'; // phpcs:ignore WordPress.Security.EscapeOutput
			wp_nonce_field( 'wakoo_places_settings' );
			echo '<input type="hidden" name="action" value="wakoo_places_settings"><table class="form-table">';
			echo '<tr><th>' . esc_html__( 'Página del buscador', 'wakoo' ) . '</th><td>' . wp_dropdown_pages( [ 'name' => 'wk[page]', 'selected' => (int) $o['page'], 'show_option_none' => '—', 'option_none_value' => 0, 'echo' => 0 ] ) // phpcs:ignore WordPress.Security.EscapeOutput
				. '<p class="description">' . esc_html__( 'Donde está el widget «Buscador de lugares». El buscador del sitio y la barra de búsqueda abren ahí cada lugar (en el idioma del visitante si la página tiene traducción).', 'wakoo' ) . '</p></td></tr>';
			echo '<tr><th>' . esc_html__( 'Teselas del mapa', 'wakoo' ) . '</th><td><input type="url" class="large-text code" name="wk[tiles]" value="' . esc_attr( $o['tiles'] ) . '"><p class="description">' . esc_html__( 'Por defecto, OpenStreetMap. Puedes poner la URL de otro proveedor con {z}, {x} y {y}.', 'wakoo' ) . '</p></td></tr>';
			echo '<tr><th>' . esc_html__( 'Atribución del mapa', 'wakoo' ) . '</th><td><input type="text" class="large-text" name="wk[attr]" value="' . esc_attr( $o['attr'] ) . '"></td></tr>';
			echo '<tr><th>' . esc_html__( 'Coordenadas automáticas', 'wakoo' ) . '</th><td><label><input type="checkbox" name="wk[geocode]" value="1"' . checked( $o['geocode'], 1, false ) . '> ' . esc_html__( 'Buscar latitud y longitud a partir de la dirección (Nominatim / OpenStreetMap; solo se envía la dirección).', 'wakoo' ) . '</label></td></tr>';
			echo '</table>';
			submit_button( __( 'Guardar ajustes', 'wakoo' ) );
			echo '</form>';
		}

		echo '<h2>' . esc_html__( 'Importar desde CSV', 'wakoo' ) . '</h2><p class="description">' . esc_html( sprintf( /* translators: %s: columns */ __( 'Columnas: %s (las 12 primeras, como el plugin Place Finder; «Tags» es opcional). Las categorías se crean solas; un lugar con el mismo nombre se actualiza.', 'wakoo' ), implode( ', ', Module::CSV ) ) ) . '</p>';
		echo '<form method="post" enctype="multipart/form-data" action="' . $post . '">'; // phpcs:ignore WordPress.Security.EscapeOutput
		wp_nonce_field( 'wakoo_places_import' );
		echo '<input type="hidden" name="action" value="wakoo_places_import"><input type="file" name="wk_csv" accept=".csv,text/csv" required> ';
		submit_button( __( 'Importar CSV', 'wakoo' ), 'secondary', 'submit', false );
		echo '</form>';

		if ( get_option( 'lapf_places_data' ) ) {
			echo '<h2>' . esc_html__( 'Importar desde Place Finder', 'wakoo' ) . '</h2><p>' . esc_html( sprintf( /* translators: %d: places */ __( 'Esta web tiene %d lugares guardados por el plugin «Lehigh Acres Place Finder». Puedes pasarlos a Wakoo Lugares (no se borran del plugin).', 'wakoo' ), count( (array) get_option( 'lapf_places_data' ) ) ) ) . '</p>';
			echo '<form method="post" action="' . $post . '">'; // phpcs:ignore WordPress.Security.EscapeOutput
			wp_nonce_field( 'wakoo_places_lapf' );
			echo '<input type="hidden" name="action" value="wakoo_places_lapf">';
			submit_button( __( 'Importar lugares del Place Finder', 'wakoo' ), 'secondary', 'submit', false );
			echo '</form>';
		}

		echo '<h2>' . esc_html__( 'Exportar y coordenadas', 'wakoo' ) . '</h2><form method="post" action="' . $post . '" style="display:inline-block;margin-right:8px">'; // phpcs:ignore WordPress.Security.EscapeOutput
		wp_nonce_field( 'wakoo_places_export' );
		echo '<input type="hidden" name="action" value="wakoo_places_export">';
		submit_button( __( 'Descargar CSV', 'wakoo' ), 'secondary', 'submit', false );
		echo '</form><form method="post" action="' . $post . '" style="display:inline-block">'; // phpcs:ignore WordPress.Security.EscapeOutput
		wp_nonce_field( 'wakoo_places_coords' );
		echo '<input type="hidden" name="action" value="wakoo_places_coords">';
		submit_button( __( 'Buscar coordenadas que faltan', 'wakoo' ), 'secondary', 'submit', false );
		echo '</form><p class="description">' . esc_html__( 'Busca hasta 20 direcciones por vez (una por segundo, como pide OpenStreetMap).', 'wakoo' ) . '</p></div>';
	}
}
