<?php
/**
 * Wakoo Lugares: a directory of places (parks, beaches, services, shops...)
 * with a live finder, an interactive map and a detail popup.
 *
 * - Places are `wakoo_place` posts with categories (`wakoo_place_cat`), managed
 *   in wp-admin (Lugares): address, phone, email, website, Google Maps link,
 *   coordinates, photos, opinions and a description per language.
 * - Coordinates are found from the address when missing (Nominatim / OSM,
 *   server side and cached), so the map never geocodes in the visitor's browser.
 * - CSV import/export uses the same 12 columns as the "Lehigh Acres Place
 *   Finder" plugin, and a site that has that plugin's data can import it in one click.
 * - Widgets: "Buscador de lugares" (search, category buttons, map, cards and a
 *   popup with the details) and "Barra de búsqueda de lugares" (sends to the finder).
 * - The finder's cards are drawn on the server (search engines read them) with
 *   ItemList/Place JSON-LD; Leaflet is bundled (vendor/), no CDN.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Places;

defined( 'ABSPATH' ) || die();

class Module {

	const CPT    = 'wakoo_place';
	const TAX    = 'wakoo_place_cat';
	const OPTION = 'wakoo_places';
	const NONCE  = 'wakoo_places';
	const PRE    = '_wakoo_place_';
	const FIELDS = [ 'address', 'phone', 'email', 'website', 'maps_url', 'lat', 'lng', 'reviews', 'tags' ];
	/** CSV columns of the Place Finder plugin (same order), so its exports import as they are. */
	const CSV    = [ 'Name', 'Category', 'Address', 'Phone', 'Email', 'Website', 'Description', 'Photos', 'Maps URL', 'Reviews', 'Lat', 'Lng', 'Tags' ];
	const GEO_MAX = 20; // Addresses geocoded per request (Nominatim allows 1 per second).

	public static function init() {
		add_action( 'init', [ __CLASS__, 'register' ] );
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widgets' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'scripts' ] );
		add_action( 'elementor/frontend/after_register_styles', [ __CLASS__, 'styles' ] );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'styles' ], 5 );
		add_filter( 'post_type_link', [ __CLASS__, 'link' ], 10, 2 );
		// Live search (modules/search) finds places too; a place is the same in every language.
		add_filter( 'wakoo_search_types', function ( $t ) { $t[] = self::CPT; return $t; } );
		add_filter( 'wakoo_search_type_labels', function ( $l ) { $l[ self::CPT ] = __( 'Lugares', 'wakoo' ); return $l; } );
		add_filter( 'wakoo_search_neutral_types', function ( $t ) { $t[] = self::CPT; return $t; } );
		if ( is_admin() ) {
			require_once __DIR__ . '/includes/admin.php';
			Admin::init();
		}
	}

	public static function register() {
		register_post_type( self::CPT, [
			'labels'              => [
				'name'          => __( 'Lugares', 'wakoo' ),
				'singular_name' => __( 'Lugar', 'wakoo' ),
				'menu_name'     => __( 'Lugares Wakoo', 'wakoo' ),
				'add_new'       => __( 'Añadir lugar', 'wakoo' ),
				'add_new_item'  => __( 'Añadir lugar', 'wakoo' ),
				'edit_item'     => __( 'Editar lugar', 'wakoo' ),
				'all_items'     => __( 'Todos los lugares', 'wakoo' ),
				'search_items'  => __( 'Buscar lugares', 'wakoo' ),
				'not_found'     => __( 'No hay lugares.', 'wakoo' ),
			],
			'public'              => false,
			'publicly_queryable'  => false,
			'exclude_from_search' => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_rest'        => false,
			'menu_icon'           => 'dashicons-location-alt',
			'menu_position'       => 58,
			'supports'            => [ 'title' ],
		] );
		register_taxonomy( self::TAX, self::CPT, [
			'labels'            => [
				'name'          => __( 'Categorías de lugares', 'wakoo' ),
				'singular_name' => __( 'Categoría', 'wakoo' ),
				'menu_name'     => __( 'Categorías', 'wakoo' ),
				'add_new_item'  => __( 'Añadir categoría', 'wakoo' ),
			],
			'public'            => false,
			'show_ui'           => true,
			'show_admin_column' => true,
			'hierarchical'      => true,
			'show_in_rest'      => false,
		] );
	}

	public static function register_widgets( $wm ) {
		require_once __DIR__ . '/widgets/finder.php';
		require_once __DIR__ . '/widgets/bar.php';
		require_once __DIR__ . '/widgets/manager.php';
		require_once __DIR__ . '/widgets/categories.php';
		require_once __DIR__ . '/widgets/logos.php';
		$wm->register( new Finder() );
		$wm->register( new Bar() );
		$wm->register( new Manager() );
		$wm->register( new Categories() );
		$wm->register( new Logos() );
	}

	public static function scripts() {
		$u = WAKOO_MODULES_URL . 'places/';
		wp_register_script( 'wakoo-leaflet', $u . 'vendor/leaflet/leaflet.js', [], '1.9.4', true );
		wp_register_script( 'wakoo-leaflet-cluster', $u . 'vendor/markercluster/leaflet.markercluster.js', [ 'wakoo-leaflet' ], '1.5.3', true );
		if ( ! wp_script_is( 'wakoo-fuse', 'registered' ) ) { // Fuzzy search (bundled by the Wakoo search module).
			wp_register_script( 'wakoo-fuse', WAKOO_MODULES_URL . 'search/vendor/fuse.min.js', [], '7.0.0', true );
		}
		wp_register_script( 'wakoo-places', $u . 'assets/places.js', [ 'wakoo-leaflet', 'wakoo-leaflet-cluster', 'wakoo-fuse' ], WAKOO_VERSION, true );
	}

	public static function styles() {
		$u = WAKOO_MODULES_URL . 'places/';
		if ( ! wp_style_is( 'wakoo-leaflet', 'registered' ) ) {
			wp_register_style( 'wakoo-leaflet', $u . 'vendor/leaflet/leaflet.css', [], '1.9.4' );
		}
		if ( ! wp_style_is( 'wakoo-leaflet-cluster', 'registered' ) ) {
			wp_register_style( 'wakoo-leaflet-cluster', $u . 'vendor/markercluster/MarkerCluster.css', [ 'wakoo-leaflet' ], '1.5.3' );
		}
		if ( ! wp_style_is( 'wakoo-places', 'registered' ) ) {
			wp_register_style( 'wakoo-places', $u . 'assets/places.css', [ 'wakoo-leaflet', 'wakoo-leaflet-cluster' ], WAKOO_VERSION );
		}
	}

	/* ---------------------------------------------------------------- settings */

	public static function settings() {
		$o = get_option( self::OPTION, [] );
		return wp_parse_args( is_array( $o ) ? $o : [], [
			'page'    => 0,      // Page with the finder: places link there (?wk_place=slug opens the popup).
			'tiles'   => 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
			'attr'    => '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
			'geocode' => 1,
		] );
	}

	/* ---------------------------------------------------------------- languages */

	private static function idiomas() {
		return class_exists( '\Wakoo\Modules\Idiomas\Module' ) ? '\Wakoo\Modules\Idiomas\Module' : '';
	}

	/** Master language (the first one in Wakoo Idiomas), '' without a language layer. */
	public static function master() {
		$i = self::idiomas();
		return $i ? (string) $i::default_lang() : '';
	}

	/** Other configured languages, [ code => name ]. */
	public static function other_langs() {
		$i = self::idiomas();
		if ( ! $i ) { return []; }
		$all = $i::languages();
		unset( $all[ self::master() ] );
		return $all;
	}

	/** Language of the page being drawn. */
	public static function lang_of_page( $pid = 0 ) {
		$i   = self::idiomas();
		$pid = $pid ?: (int) get_the_ID();
		return ( $i && $pid ) ? (string) $i::lang_of( $pid ) : '';
	}

	/* ---------------------------------------------------------------- data */

	public static function get( $id, $field ) {
		return (string) get_post_meta( $id, self::PRE . $field, true );
	}

	/** Description in a language, falling back to the master one. */
	public static function desc( $id, $lang = '' ) {
		$d = ( $lang && $lang !== self::master() ) ? self::get( $id, 'desc_' . $lang ) : '';
		return '' !== trim( $d ) ? $d : self::get( $id, 'desc' );
	}

	/** The category's name in every language (so a search in any language finds it). */
	public static function term_words( $term ) {
		$w = [ $term->name ];
		foreach ( array_keys( self::other_langs() ) as $code ) { $w[] = (string) get_term_meta( $term->term_id, 'wk_label_' . $code, true ); }
		return implode( ' ', array_filter( $w ) );
	}

	/** Category name in a language (term meta wk_label_<lang>), else its own name. */
	public static function term_label( $term, $lang = '' ) {
		$l = ( $lang && $lang !== self::master() ) ? (string) get_term_meta( $term->term_id, 'wk_label_' . $lang, true ) : '';
		return '' !== trim( $l ) ? $l : $term->name;
	}

	/** Photos: [ [ id, url ] ] (kept as {id,url} so packs map them to the new library). */
	public static function photos( $id ) {
		$out = [];
		foreach ( (array) get_post_meta( $id, self::PRE . 'photos', true ) as $ph ) {
			$aid = is_array( $ph ) ? (int) ( $ph['id'] ?? 0 ) : (int) $ph;
			$url = $aid ? wp_get_attachment_image_url( $aid, 'large' ) : ( is_array( $ph ) ? (string) ( $ph['url'] ?? '' ) : '' );
			if ( $url ) { $out[] = [ 'id' => $aid, 'url' => $url ]; }
		}
		return $out;
	}

	public static function maps_url( $id ) {
		$u = self::get( $id, 'maps_url' );
		if ( $u ) { return $u; }
		$lat = self::get( $id, 'lat' );
		$lng = self::get( $id, 'lng' );
		$q   = ( '' !== $lat && '' !== $lng ) ? $lat . ',' . $lng : self::get( $id, 'address' );
		return '' !== $q ? 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $q ) : '';
	}

	public static function directions_url( $id ) {
		$lat = self::get( $id, 'lat' );
		$lng = self::get( $id, 'lng' );
		$q   = self::get( $id, 'address' ) ?: ( ( '' !== $lat && '' !== $lng ) ? $lat . ',' . $lng : '' );
		return '' !== $q ? 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode( $q ) : '';
	}

	/**
	 * Published places as plain arrays for the finder.
	 *
	 * @param string[] $cats Category slugs (empty = all).
	 */
	public static function places( array $cats = [], $lang = '' ) {
		$q = [ 'post_type' => self::CPT, 'post_status' => 'publish', 'posts_per_page' => 500, 'orderby' => 'title', 'order' => 'ASC', 'no_found_rows' => true ];
		if ( $cats ) { $q['tax_query'] = [ [ 'taxonomy' => self::TAX, 'field' => 'slug', 'terms' => $cats ] ]; } // phpcs:ignore WordPress.DB.SlowDBQuery
		$out = [];
		foreach ( get_posts( $q ) as $p ) {
			$terms = get_the_terms( $p, self::TAX );
			$terms = is_array( $terms ) ? $terms : [];
			$lat   = self::get( $p->ID, 'lat' );
			$lng   = self::get( $p->ID, 'lng' );
			$out[] = [
				'id'      => $p->ID,
				'slug'    => $p->post_name ?: (string) $p->ID,
				'name'    => html_entity_decode( get_the_title( $p ), ENT_QUOTES, 'UTF-8' ), // Plain text: the finder escapes it.
				'cats'    => wp_list_pluck( $terms, 'slug' ),
				'cat'     => $terms ? self::term_label( $terms[0], $lang ) : '',
				'address' => self::get( $p->ID, 'address' ),
				'phone'   => self::get( $p->ID, 'phone' ),
				'email'   => self::get( $p->ID, 'email' ),
				'website' => self::get( $p->ID, 'website' ),
				'maps'    => self::maps_url( $p->ID ),
				'dir'     => self::directions_url( $p->ID ),
				'lat'     => is_numeric( $lat ) ? (float) $lat : null,
				'lng'     => is_numeric( $lng ) ? (float) $lng : null,
				'desc'    => self::desc( $p->ID, $lang ),
				'reviews' => self::get( $p->ID, 'reviews' ),
				// Extra words for the search: the place's keywords and its categories in every language.
				'words'   => trim( self::get( $p->ID, 'tags' ) . ' ' . implode( ' ', array_map( [ __CLASS__, 'term_words' ], $terms ) ) ),
				'photos'  => wp_list_pluck( self::photos( $p->ID ), 'url' ),
			];
		}
		return $out;
	}

	/**
	 * A place that lives in a widget (its own list or a CSV file), in the same shape as places().
	 *
	 * @param array  $d   name, category, address, phone, email, website, description, photos, maps_url, reviews, lat, lng, tags.
	 * @param string $key Unique key inside the widget (the slug for ?wk_place=).
	 */
	public static function from_row( array $d, $key ) {
		$name = sanitize_text_field( $d['name'] ?? '' );
		if ( '' === $name ) { return null; }
		$labels = array_values( array_filter( array_map( 'trim', explode( ',', sanitize_text_field( $d['category'] ?? '' ) ) ) ) );
		$lat = is_numeric( $d['lat'] ?? '' ) ? (float) $d['lat'] : null;
		$lng = is_numeric( $d['lng'] ?? '' ) ? (float) $d['lng'] : null;
		$address = sanitize_text_field( $d['address'] ?? '' );
		if ( ( null === $lat || null === $lng ) && '' !== $address ) {
			$geo = self::geocode_soft( $address );
			if ( $geo ) { list( $lat, $lng ) = $geo; }
		}
		$q   = ( null !== $lat ) ? $lat . ',' . $lng : $address;
		$web = esc_url_raw( $d['website'] ?? '' );
		$photos = [];
		foreach ( array_filter( array_map( 'trim', explode( ',', (string) ( $d['photos'] ?? '' ) ) ) ) as $u ) { $u = esc_url_raw( $u ); if ( $u ) { $photos[] = $u; } }
		return [
			'id'      => 0,
			'slug'    => sanitize_title( $name ) . '-' . sanitize_key( $key ),
			'name'    => $name,
			'cats'    => array_map( 'sanitize_title', $labels ),
			'cat'     => $labels ? $labels[0] : '',
			'labels'  => $labels,
			'address' => $address,
			'phone'   => sanitize_text_field( $d['phone'] ?? '' ),
			'email'   => sanitize_email( $d['email'] ?? '' ),
			'website' => preg_match( '#^https?://#i', $web ) ? $web : '',
			'maps'    => esc_url_raw( $d['maps_url'] ?? '' ) ?: ( '' !== $q ? 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $q ) : '' ),
			'dir'     => '' !== ( $address ?: $q ) ? 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode( $address ?: $q ) : '',
			'lat'     => $lat,
			'lng'     => $lng,
			'desc'    => sanitize_textarea_field( $d['description'] ?? '' ),
			'reviews' => sanitize_textarea_field( wp_strip_all_tags( (string) ( $d['reviews'] ?? '' ) ) ),
			'photos'  => $photos,
			'words'   => sanitize_text_field( ( $d['tags'] ?? '' ) . ' ' . implode( ' ', $labels ) ),
		];
	}

	/** Rows of a CSV in the media library (Place Finder columns + optional Tags), cached until the file changes. */
	public static function csv_file_rows( $attachment_id ) {
		$file = $attachment_id ? get_attached_file( (int) $attachment_id ) : '';
		if ( ! $file || ! is_readable( $file ) || 'csv' !== strtolower( pathinfo( $file, PATHINFO_EXTENSION ) ) || filesize( $file ) > 5242880 ) { return []; }
		$key  = 'wakoo_pl_csv_' . (int) $attachment_id . '_' . filemtime( $file );
		$rows = get_transient( $key );
		if ( is_array( $rows ) ) { return $rows; }
		$rows = [];
		$h    = fopen( $file, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$first = true;
		while ( $h && ( $r = fgetcsv( $h, 20000, ',', '"', '\\' ) ) !== false && count( $rows ) < 2000 ) {
			if ( $first ) { $first = false; if ( isset( $r[0] ) && 0 === strcasecmp( trim( $r[0], "\xEF\xBB\xBF \t" ), 'Name' ) ) { continue; } }
			$rows[] = array_combine( [ 'name', 'category', 'address', 'phone', 'email', 'website', 'description', 'photos', 'maps_url', 'reviews', 'lat', 'lng', 'tags' ], array_pad( array_slice( $r, 0, 13 ), 13, '' ) );
		}
		if ( $h ) { fclose( $h ); } // phpcs:ignore WordPress.WP.AlternativeFunctions
		set_transient( $key, $rows, WEEK_IN_SECONDS );
		return $rows;
	}

	/**
	 * Geocoding while a page is drawn: cached answers only, plus at most two new
	 * lookups per request (Nominatim allows one per second), so a long list fills in over a few visits.
	 */
	public static function geocode_soft( $address ) {
		static $new = 0;
		$hit = get_transient( 'wakoo_geo_' . md5( strtolower( trim( (string) $address ) ) ) );
		if ( is_array( $hit ) ) { return $hit ?: null; }
		if ( $new >= 2 ) { return null; }
		if ( $new++ ) { sleep( 1 ); }
		return self::geocode( $address );
	}

	/** Categories in use: [ slug => label ]. */
	public static function categories( array $only = [], $lang = '' ) {
		$terms = get_terms( [ 'taxonomy' => self::TAX, 'hide_empty' => true, 'orderby' => 'name' ] );
		$out   = [];
		foreach ( is_wp_error( $terms ) ? [] : $terms as $t ) {
			if ( ! $only || in_array( $t->slug, $only, true ) ) { $out[ $t->slug ] = self::term_label( $t, $lang ); }
		}
		return $out;
	}

	/** URL of the finder page (in the visitor's language when it has a translation). */
	public static function page_url( $lang = '' ) {
		$pid = (int) self::settings()['page'];
		if ( ! $pid || 'publish' !== get_post_status( $pid ) ) { return ''; }
		$i = self::idiomas();
		if ( $i && $lang ) {
			$tr = $i::translations( $pid );
			if ( ! empty( $tr[ $lang ] ) ) { $pid = (int) $tr[ $lang ]; }
		}
		return (string) get_permalink( $pid );
	}

	/** A place has no page of its own: it opens in the finder's popup. */
	public static function link( $url, $post ) {
		if ( self::CPT !== $post->post_type ) { return $url; }
		$lang = isset( $_REQUEST['lang'] ) ? sanitize_key( wp_unslash( $_REQUEST['lang'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$page = self::page_url( $lang );
		return $page ? add_query_arg( 'wk_place', $post->post_name ?: $post->ID, $page ) : $url;
	}

	/* ---------------------------------------------------------------- geocoding */

	/** [ lat, lng ] for an address (Nominatim / OpenStreetMap, cached a month), or null. */
	public static function geocode( $address ) {
		$address = trim( (string) $address );
		if ( '' === $address || ! self::settings()['geocode'] ) { return null; }
		$key = 'wakoo_geo_' . md5( strtolower( $address ) );
		$hit = get_transient( $key );
		if ( is_array( $hit ) ) { return $hit ?: null; }
		$res = wp_remote_get( add_query_arg( [ 'format' => 'json', 'limit' => 1, 'q' => $address ], 'https://nominatim.openstreetmap.org/search' ), [
			'timeout'    => 8,
			'user-agent' => 'Wakoo/' . ( defined( 'WAKOO_VERSION' ) ? WAKOO_VERSION : '1' ) . ' (' . home_url( '/' ) . ')',
		] );
		if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) { return null; } // Not cached: try again later.
		$data = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		$geo  = ( is_array( $data ) && isset( $data[0]['lat'], $data[0]['lon'] ) ) ? [ round( (float) $data[0]['lat'], 6 ), round( (float) $data[0]['lon'], 6 ) ] : [];
		set_transient( $key, $geo, MONTH_IN_SECONDS );
		return $geo ?: null;
	}

	/** Fill the coordinates of a place from its address when they are missing. */
	public static function fill_coords( $id ) {
		if ( '' !== self::get( $id, 'lat' ) && '' !== self::get( $id, 'lng' ) ) { return false; }
		$geo = self::geocode( self::get( $id, 'address' ) );
		if ( ! $geo ) { return false; }
		update_post_meta( $id, self::PRE . 'lat', (string) $geo[0] );
		update_post_meta( $id, self::PRE . 'lng', (string) $geo[1] );
		return true;
	}

	/* ---------------------------------------------------------------- saving (admin, CSV, Place Finder) */

	/**
	 * Create or update a place from plain data.
	 *
	 * @param array $d name, category (comma separated), address, phone, email, website, description, photos (URLs, comma separated), maps_url, reviews, lat, lng.
	 */
	public static function save( array $d, $id = 0 ) {
		$name = sanitize_text_field( $d['name'] ?? '' );
		if ( '' === $name ) { return 0; }
		$desc = sanitize_textarea_field( $d['description'] ?? '' );
		$arr  = [ 'post_type' => self::CPT, 'post_status' => 'publish', 'post_title' => $name, 'post_excerpt' => wp_trim_words( $desc, 40, '…' ) ];
		if ( $id ) { $arr['ID'] = $id; }
		$id = $id ? wp_update_post( $arr, true ) : wp_insert_post( $arr, true );
		if ( is_wp_error( $id ) || ! $id ) { return 0; }
		$clean = [
			'address'  => sanitize_text_field( $d['address'] ?? '' ),
			'phone'    => sanitize_text_field( $d['phone'] ?? '' ),
			'email'    => sanitize_email( $d['email'] ?? '' ),
			'website'  => esc_url_raw( $d['website'] ?? '' ),
			'maps_url' => esc_url_raw( $d['maps_url'] ?? '' ),
			'reviews'  => sanitize_textarea_field( wp_strip_all_tags( (string) ( $d['reviews'] ?? '' ) ) ),
			'tags'     => sanitize_text_field( $d['tags'] ?? '' ),
			'lat'      => is_numeric( $d['lat'] ?? '' ) ? (string) (float) $d['lat'] : '',
			'lng'      => is_numeric( $d['lng'] ?? '' ) ? (string) (float) $d['lng'] : '',
			'desc'     => $desc,
		];
		foreach ( $clean as $k => $v ) { update_post_meta( $id, self::PRE . $k, $v ); }
		$photos = [];
		foreach ( array_filter( array_map( 'trim', explode( ',', (string) ( $d['photos'] ?? '' ) ) ) ) as $u ) {
			$u = esc_url_raw( $u );
			if ( $u ) { $photos[] = [ 'id' => (int) attachment_url_to_postid( $u ), 'url' => $u ]; }
		}
		update_post_meta( $id, self::PRE . 'photos', $photos );
		$cats = array_filter( array_map( 'trim', explode( ',', (string) ( $d['category'] ?? '' ) ) ) );
		if ( $cats ) { wp_set_object_terms( $id, array_map( 'sanitize_text_field', $cats ), self::TAX ); }
		return (int) $id;
	}

	/** Rows of a CSV file (Place Finder columns), header skipped. */
	public static function import_csv( $file ) {
		$h = fopen( $file, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $h ) { return 0; }
		$n = 0; $first = true;
		while ( ( $row = fgetcsv( $h, 20000, ',', '"', '\\' ) ) !== false ) {
			if ( $first ) { $first = false; if ( isset( $row[0] ) && 0 === strcasecmp( trim( $row[0], "\xEF\xBB\xBF \t" ), 'Name' ) ) { continue; } }
			$d = array_combine( [ 'name', 'category', 'address', 'phone', 'email', 'website', 'description', 'photos', 'maps_url', 'reviews', 'lat', 'lng', 'tags' ], array_pad( array_slice( $row, 0, 13 ), 13, '' ) );
			$id = self::save( $d, self::find_by_name( $d['name'] ) );
			if ( $id ) { $n++; }
		}
		fclose( $h ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return $n;
	}

	/** The Place Finder plugin keeps its places in the option lapf_places_data. */
	public static function import_place_finder() {
		$n = 0;
		foreach ( (array) get_option( 'lapf_places_data', [] ) as $p ) {
			if ( is_array( $p ) && self::save( $p, self::find_by_name( $p['name'] ?? '' ) ) ) { $n++; }
		}
		return $n;
	}

	/** Same name = same place, so importing twice updates instead of duplicating. */
	private static function find_by_name( $name ) {
		$name = sanitize_text_field( (string) $name );
		if ( '' === $name ) { return 0; }
		$q = get_posts( [ 'post_type' => self::CPT, 'post_status' => 'any', 'title' => $name, 'posts_per_page' => 1, 'fields' => 'ids' ] );
		return $q ? (int) $q[0] : 0;
	}

	/** Places with an address and no coordinates yet (a few per call: Nominatim allows one request per second). */
	public static function fill_missing() {
		$ids = get_posts( [ 'post_type' => self::CPT, 'post_status' => 'any', 'posts_per_page' => 200, 'fields' => 'ids' ] );
		$done = 0; $tried = 0;
		foreach ( $ids as $id ) {
			if ( '' !== self::get( $id, 'lat' ) || '' === self::get( $id, 'address' ) ) { continue; }
			if ( $tried++ >= self::GEO_MAX ) { break; }
			if ( $tried > 1 ) { sleep( 1 ); }
			if ( self::fill_coords( $id ) ) { $done++; }
		}
		return $done;
	}

	public static function csv_rows() {
		$rows = [];
		foreach ( get_posts( [ 'post_type' => self::CPT, 'post_status' => 'any', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ] ) as $p ) {
			$terms  = get_the_terms( $p, self::TAX );
			$rows[] = [
				$p->post_title, is_array( $terms ) ? implode( ', ', wp_list_pluck( $terms, 'name' ) ) : '',
				self::get( $p->ID, 'address' ), self::get( $p->ID, 'phone' ), self::get( $p->ID, 'email' ), self::get( $p->ID, 'website' ),
				self::get( $p->ID, 'desc' ), implode( ',', wp_list_pluck( self::photos( $p->ID ), 'url' ) ), self::get( $p->ID, 'maps_url' ),
				self::get( $p->ID, 'reviews' ), self::get( $p->ID, 'lat' ), self::get( $p->ID, 'lng' ), self::get( $p->ID, 'tags' ),
			];
		}
		return $rows;
	}
}

Module::init();
