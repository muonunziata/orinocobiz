<?php
/**
 * "Barra de búsqueda de lugares": a compact search (text + category) that
 * sends the visitor to the page with the "Buscador de lugares" widget, which
 * opens with that search already applied (?wk_q=…&wk_cat=…).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Places;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Bar extends Widget_Base {

	public function get_name() { return 'wakoo-places-bar'; }
	public function get_title() { return __( 'Barra de búsqueda de lugares', 'wakoo' ); }
	public function get_icon() { return 'eicon-search'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'lugares', 'places', 'buscar', 'search', 'wakoo' ]; }
	public function get_style_depends() { return [ 'wakoo-places' ]; }

	public static function texts() {
		return [
			'ph'     => [ __( 'Texto del buscador', 'wakoo' ), __( '¿Qué lugar buscas?', 'wakoo' ) ],
			'label'  => [ __( 'Etiqueta (lectores de pantalla)', 'wakoo' ), __( 'Buscar lugares', 'wakoo' ) ],
			'all'    => [ __( 'Opción: todas las categorías', 'wakoo' ), __( 'Todas las categorías', 'wakoo' ) ],
			'button' => [ __( 'Botón', 'wakoo' ), __( 'Buscar', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_bar', [ 'label' => __( 'Barra de búsqueda', 'wakoo' ) ] );
		$this->add_control( 'target', [
			'label'       => __( 'Página de resultados', 'wakoo' ),
			'type'        => Controls_Manager::URL,
			'description' => __( 'La página con el «Buscador de lugares». Vacío = la de Lugares Wakoo → Importar y ajustes.', 'wakoo' ),
		] );
		$this->add_control( 'show_cats', [ 'label' => __( 'Elegir categoría', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		foreach ( self::texts() as $id => $d ) {
			$this->add_control( 'lbl_' . $id, [ 'label' => $d[0], 'type' => Controls_Manager::TEXT, 'default' => $d[1], 'label_block' => true ] );
		}
		$this->end_controls_section();
		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'accent', [ 'label' => __( 'Color de acento', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wk-plb' => '--wk-pl-accent: {{VALUE}};' ] ] );
		$this->end_controls_section();
	}

	private function t( $id ) {
		$v = $this->get_settings_for_display( 'lbl_' . $id );
		return ( null === $v || '' === $v ) ? self::texts()[ $id ][1] : (string) $v;
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$lang = Module::lang_of_page();
		$url  = ! empty( $s['target']['url'] ) ? $s['target']['url'] : Module::page_url( $lang );
		$uid  = 'wkplb-' . $this->get_id();
		echo '<form class="wk-plb" role="search" method="get" action="' . esc_url( $url ) . '">'
			. '<label class="screen-reader-text" for="' . esc_attr( $uid ) . '">' . esc_html( $this->t( 'label' ) ) . '</label>'
			. '<input id="' . esc_attr( $uid ) . '" class="wk-plb__q" type="search" name="wk_q" autocomplete="off" placeholder="' . esc_attr( $this->t( 'ph' ) ) . '">';
		if ( 'yes' === ( $s['show_cats'] ?? '' ) ) {
			$cats = Module::categories( [], $lang );
			if ( $cats ) {
				echo '<select class="wk-plb__cat" name="wk_cat" aria-label="' . esc_attr( $this->t( 'all' ) ) . '"><option value="">' . esc_html( $this->t( 'all' ) ) . '</option>';
				foreach ( $cats as $slug => $label ) { echo '<option value="' . esc_attr( $slug ) . '">' . esc_html( $label ) . '</option>'; }
				echo '</select>';
			}
		}
		echo '<button type="submit" class="wk-plb__btn">' . esc_html( $this->t( 'button' ) ) . '</button></form>';
	}
}
