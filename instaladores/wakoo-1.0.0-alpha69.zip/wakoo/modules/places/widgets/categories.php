<?php
/**
 * "Categorías de lugares": a drop-down with the categories of Wakoo Lugares
 * (they appear as places are added) and, when one is chosen, a popup with
 * all the places of that category: filter, directions, call, website and
 * "see on the map" (it opens the place in the "Buscador de lugares" of the
 * same page, or in the finder page).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Places;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Categories extends Widget_Base {

	public function get_name() { return 'wakoo-places-cats'; }
	public function get_title() { return __( 'Categorías de lugares', 'wakoo' ); }
	public function get_icon() { return 'eicon-select'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'lugares', 'places', 'categorias', 'categories', 'menu', 'desplegable', 'wakoo' ]; }
	public function get_style_depends() { return [ 'wakoo-places' ]; }
	public function get_script_depends() { return [ 'wakoo-places' ]; }

	public static function texts() {
		return [
			'label'   => [ __( 'Etiqueta', 'wakoo' ), __( 'Explora por categoría', 'wakoo' ) ],
			'choose'  => [ __( 'Primera opción', 'wakoo' ), __( 'Elige una categoría…', 'wakoo' ) ],
			'count'   => [ __( 'Contador ({n} = número)', 'wakoo' ), __( '{n} lugares', 'wakoo' ) ],
			'count1'  => [ __( 'Contador con un lugar', 'wakoo' ), __( '1 lugar', 'wakoo' ) ],
			'filter'  => [ __( 'Filtro dentro de la ventana', 'wakoo' ), __( 'Filtrar por nombre o calle…', 'wakoo' ) ],
			'dir'     => [ __( 'Botón: cómo llegar', 'wakoo' ), __( 'Cómo llegar', 'wakoo' ) ],
			'call'    => [ __( 'Botón: llamar', 'wakoo' ), __( 'Llamar', 'wakoo' ) ],
			'web'     => [ __( 'Botón: sitio web', 'wakoo' ), __( 'Sitio web', 'wakoo' ) ],
			'map'     => [ __( 'Botón: ver en el mapa', 'wakoo' ), __( 'Ver en el mapa', 'wakoo' ) ],
			'close'   => [ __( 'Botón: cerrar', 'wakoo' ), __( 'Cerrar', 'wakoo' ) ],
			'none'    => [ __( 'Sin resultados en el filtro', 'wakoo' ), __( 'Ningún lugar coincide con el filtro.', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_cats', [ 'label' => __( 'Categorías de lugares', 'wakoo' ) ] );
		$this->add_control( 'note', [
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => esc_html__( 'Las categorías salen solas de Lugares Wakoo (solo las que tienen lugares), con su nombre en el idioma de la página.', 'wakoo' ),
			'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
		] );
		$this->add_control( 'show_counts', [ 'label' => __( 'Número de lugares en cada categoría', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'inline', [ 'label' => __( 'Etiqueta al lado del menú', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		foreach ( self::texts() as $id => $d ) {
			$this->add_control( 'lbl_' . $id, [ 'label' => $d[0], 'type' => Controls_Manager::TEXT, 'default' => $d[1], 'label_block' => true ] );
		}
		$this->end_controls_section();
		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'accent', [ 'label' => __( 'Color de acento', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wk-plc' => '--wk-pl-accent: {{VALUE}};' ] ] );
		$this->end_controls_section();
	}

	private function t( $id ) {
		$v = $this->get_settings_for_display( 'lbl_' . $id );
		return ( null === $v || '' === $v ) ? self::texts()[ $id ][1] : (string) $v;
	}

	protected function render() {
		$s      = $this->get_settings_for_display();
		$lang   = Module::lang_of_page();
		$places = Module::places( [], $lang );
		$labels = Module::categories( [], $lang );
		$groups = [];
		foreach ( $places as $p ) {
			foreach ( $p['cats'] as $c ) {
				if ( isset( $labels[ $c ] ) ) {
					$groups[ $c ][] = [ 'slug' => $p['slug'], 'name' => $p['name'], 'address' => $p['address'], 'desc' => wp_trim_words( $p['desc'], 16, '…' ), 'phone' => $p['phone'], 'website' => $p['website'], 'dir' => $p['dir'] ];
				}
			}
		}
		if ( ! $groups ) { return; }
		uksort( $groups, function ( $a, $b ) use ( $labels ) { return strcasecmp( $labels[ $a ], $labels[ $b ] ); } );
		$uid   = 'wkplc-' . $this->get_id();
		$texts = [];
		foreach ( array_keys( self::texts() ) as $k ) { $texts[ $k ] = $this->t( $k ); }
		$data = [ 'page' => Module::page_url( $lang ), 't' => $texts, 'cats' => [] ];
		foreach ( $groups as $slug => $items ) { $data['cats'][ $slug ] = [ 'label' => $labels[ $slug ], 'items' => $items ]; }

		echo '<div class="wk-plc' . ( 'yes' === ( $s['inline'] ?? '' ) ? ' wk-plc--inline' : '' ) . '">';
		echo '<label class="wk-plc__label" for="' . esc_attr( $uid ) . '">' . esc_html( $texts['label'] ) . '</label>';
		echo '<span class="wk-plc__wrap"><select id="' . esc_attr( $uid ) . '" class="wk-plc__select"><option value="">' . esc_html( $texts['choose'] ) . '</option>';
		foreach ( $groups as $slug => $items ) {
			echo '<option value="' . esc_attr( $slug ) . '">' . esc_html( $labels[ $slug ] . ( 'yes' === ( $s['show_counts'] ?? '' ) ? ' (' . count( $items ) . ')' : '' ) ) . '</option>';
		}
		echo '</select></span>';
		echo '<dialog class="wk-plc__modal" aria-labelledby="' . esc_attr( $uid ) . '-t"><div class="wk-plc__sheet">'
			. '<div class="wk-plc__head"><div><h2 class="wk-plc__title" id="' . esc_attr( $uid ) . '-t"></h2><p class="wk-plc__count"></p></div>'
			. '<button type="button" class="wk-plc__close" aria-label="' . esc_attr( $texts['close'] ) . '">×</button></div>'
			. '<input type="search" class="wk-plc__filter" placeholder="' . esc_attr( $texts['filter'] ) . '" aria-label="' . esc_attr( $texts['filter'] ) . '">'
			. '<ul class="wk-plc__list" role="list"></ul><p class="wk-plc__none" hidden>' . esc_html( $texts['none'] ) . '</p></div></dialog>';
		echo '<script type="application/json" class="wk-plc__data">' . wp_json_encode( $data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE ) . '</script>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '</div>';
	}
}
