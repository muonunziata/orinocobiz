<?php
/**
 * "Buscador de lugares": an advanced place finder.
 *
 * - Search that forgives typos and works in any language (Fuse.js + the
 *   category names of every language and each place's keywords).
 * - Several categories at once, each button with its number of results.
 * - "Cerca de mí": distance on every card, sort by distance and a radius.
 * - Sort (relevance, A–Z, nearest), "only what the map shows", "Ver más"
 *   paging and "Limpiar filtros".
 * - Map with grouped pins (Leaflet + markercluster, bundled) that follows
 *   the list; a card lights up its pin.
 * - Every place opens a popup with the details (?wk_place=<slug> opens it;
 *   ?wk_q= and ?wk_cat= pre-fill the search, as the "Barra de búsqueda de
 *   lugares" widget sends them).
 * - The cards are drawn here (search engines read them) with ItemList/Place JSON-LD.
 *
 * Ideas from open-source locators (behaviour only): jQuery Store Locator,
 * Google js-store-locator, storelocatorjs and leaflet-search.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Places;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;

defined( 'ABSPATH' ) || die();

class Finder extends Widget_Base {

	public function get_name() { return 'wakoo-places'; }
	public function get_title() { return __( 'Buscador de lugares', 'wakoo' ); }
	public function get_icon() { return 'eicon-google-maps'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'lugares', 'places', 'mapa', 'map', 'directorio', 'buscador', 'finder', 'locator', 'wakoo' ]; }
	public function get_style_depends() { return [ 'wakoo-leaflet', 'wakoo-leaflet-cluster', 'wakoo-places' ]; }
	public function get_script_depends() { return [ 'wakoo-leaflet', 'wakoo-leaflet-cluster', 'wakoo-fuse', 'wakoo-places' ]; }

	/** [ id => [ label in the panel, default ] ]: every visible word is editable, so each language version carries its own. */
	public static function texts() {
		return [
			'search_ph'  => [ __( 'Texto del buscador', 'wakoo' ), __( 'Busca un lugar: farmacia, restaurante, parque…', 'wakoo' ) ],
			'search_lb'  => [ __( 'Etiqueta del buscador (lectores de pantalla)', 'wakoo' ), __( 'Buscar lugares', 'wakoo' ) ],
			'cats_lb'    => [ __( 'Etiqueta de las categorías (lectores de pantalla)', 'wakoo' ), __( 'Categorías', 'wakoo' ) ],
			'all'        => [ __( 'Botón: todas las categorías', 'wakoo' ), __( 'Todos', 'wakoo' ) ],
			'count'      => [ __( 'Contador ({n} = número)', 'wakoo' ), __( '{n} lugares', 'wakoo' ) ],
			'count1'     => [ __( 'Contador con un solo lugar', 'wakoo' ), __( '1 lugar', 'wakoo' ) ],
			'near'       => [ __( 'Botón: cerca de mí', 'wakoo' ), __( 'Cerca de mí', 'wakoo' ) ],
			'near_wait'  => [ __( 'Buscando tu ubicación', 'wakoo' ), __( 'Buscando tu ubicación…', 'wakoo' ) ],
			'geo_err'    => [ __( 'Sin permiso de ubicación', 'wakoo' ), __( 'No pudimos saber dónde estás. Revisa el permiso de ubicación del navegador.', 'wakoo' ) ],
			'sort_lb'    => [ __( 'Etiqueta: ordenar', 'wakoo' ), __( 'Ordenar', 'wakoo' ) ],
			'sort_rel'   => [ __( 'Orden: relevancia', 'wakoo' ), __( 'Más relevantes', 'wakoo' ) ],
			'sort_az'    => [ __( 'Orden: A–Z', 'wakoo' ), __( 'Nombre (A–Z)', 'wakoo' ) ],
			'sort_near'  => [ __( 'Orden: más cercanos', 'wakoo' ), __( 'Más cercanos', 'wakoo' ) ],
			'radius_lb'  => [ __( 'Etiqueta: distancia', 'wakoo' ), __( 'Distancia', 'wakoo' ) ],
			'radius_any' => [ __( 'Distancia: cualquiera', 'wakoo' ), __( 'Cualquier distancia', 'wakoo' ) ],
			'within'     => [ __( 'Distancia: a menos de ({d} = distancia)', 'wakoo' ), __( 'A menos de {d}', 'wakoo' ) ],
			'inmap'      => [ __( 'Casilla: solo lo visible en el mapa', 'wakoo' ), __( 'Solo lo que se ve en el mapa', 'wakoo' ) ],
			'more'       => [ __( 'Botón: ver más ({n} = cuántos faltan)', 'wakoo' ), __( 'Ver más ({n})', 'wakoo' ) ],
			'reset'      => [ __( 'Botón: limpiar filtros', 'wakoo' ), __( 'Limpiar filtros', 'wakoo' ) ],
			'none'       => [ __( 'Sin resultados', 'wakoo' ), __( 'No encontramos lugares con esa búsqueda. Prueba con otra palabra, otra categoría o más distancia.', 'wakoo' ) ],
			'details'    => [ __( 'Enlace de cada tarjeta', 'wakoo' ), __( 'Ver detalles', 'wakoo' ) ],
			'map_lb'     => [ __( 'Nombre del mapa (lectores de pantalla)', 'wakoo' ), __( 'Mapa de lugares', 'wakoo' ) ],
			'locate'     => [ __( 'Botón del mapa: mi ubicación', 'wakoo' ), __( 'Mi ubicación', 'wakoo' ) ],
			'you'        => [ __( 'Marcador: estás aquí', 'wakoo' ), __( 'Estás aquí', 'wakoo' ) ],
			'dir'        => [ __( 'Botón: cómo llegar', 'wakoo' ), __( 'Cómo llegar', 'wakoo' ) ],
			'call'       => [ __( 'Botón: llamar', 'wakoo' ), __( 'Llamar', 'wakoo' ) ],
			'mail'       => [ __( 'Botón: email', 'wakoo' ), __( 'Escribir', 'wakoo' ) ],
			'web'        => [ __( 'Botón: sitio web', 'wakoo' ), __( 'Sitio web', 'wakoo' ) ],
			'maps'       => [ __( 'Botón: Google Maps', 'wakoo' ), __( 'Ver en Google Maps', 'wakoo' ) ],
			'reviews'    => [ __( 'Título de opiniones', 'wakoo' ), __( 'Opiniones', 'wakoo' ) ],
			'close'      => [ __( 'Botón: cerrar', 'wakoo' ), __( 'Cerrar', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		// Where the places come from: the Lugares Wakoo list, this widget's own list / CSV file, or both.
		$this->start_controls_section( 'sec_source', [ 'label' => __( 'Cargar lugares', 'wakoo' ) ] );
		$this->add_control( 'source', [
			'label'   => __( 'Origen de los lugares', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'db',
			'options' => [ 'db' => __( 'Lugares Wakoo (todo el sitio)', 'wakoo' ), 'widget' => __( 'Solo los de este widget', 'wakoo' ), 'both' => __( 'Los dos', 'wakoo' ) ],
		] );
		$this->add_control( 'db_help', [
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => '<p>' . esc_html__( 'Los lugares de todo el sitio se gestionan en el escritorio de WordPress:', 'wakoo' ) . '</p><p>'
				. '<a class="elementor-button elementor-button-default" style="margin:4px 4px 0 0" target="_blank" href="' . esc_url( admin_url( 'post-new.php?post_type=' . Module::CPT ) ) . '">' . esc_html__( 'Añadir lugar', 'wakoo' ) . '</a>'
				. '<a class="elementor-button elementor-button-default" style="margin:4px 4px 0 0" target="_blank" href="' . esc_url( admin_url( 'edit.php?post_type=' . Module::CPT . '&page=wakoo-places-tools' ) ) . '">' . esc_html__( 'Importar CSV', 'wakoo' ) . '</a>'
				. '<a class="elementor-button elementor-button-default" style="margin:4px 0 0" target="_blank" href="' . esc_url( admin_url( 'edit.php?post_type=' . Module::CPT ) ) . '">' . esc_html__( 'Ver todos', 'wakoo' ) . '</a></p>'
				. '<p style="margin-top:6px">' . esc_html__( 'Guarda y recarga el editor para ver los cambios.', 'wakoo' ) . '</p>',
			'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			'condition'       => [ 'source!' => 'widget' ],
		] );
		$rep = new Repeater();
		$rep->add_control( 'name', [ 'label' => __( 'Nombre', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'label_block' => true ] );
		$rep->add_control( 'category', [ 'label' => __( 'Categoría', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'label_block' => true, 'description' => __( 'Varias, separadas por comas.', 'wakoo' ) ] );
		$rep->add_control( 'address', [ 'label' => __( 'Dirección', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'label_block' => true, 'description' => __( 'Sin coordenadas, se buscan solas a partir de la dirección.', 'wakoo' ) ] );
		$rep->add_control( 'lat', [ 'label' => __( 'Latitud', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$rep->add_control( 'lng', [ 'label' => __( 'Longitud', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$rep->add_control( 'phone', [ 'label' => __( 'Teléfono', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$rep->add_control( 'email', [ 'label' => __( 'Email', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$rep->add_control( 'website', [ 'label' => __( 'Sitio web', 'wakoo' ), 'type' => Controls_Manager::URL, 'options' => false ] );
		$rep->add_control( 'description', [ 'label' => __( 'Descripción', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA ] );
		$rep->add_control( 'photo', [ 'label' => __( 'Foto', 'wakoo' ), 'type' => Controls_Manager::MEDIA ] );
		$rep->add_control( 'tags', [ 'label' => __( 'Palabras clave', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'label_block' => true ] );
		$this->add_control( 'items', [
			'label'       => __( 'Lugares de este widget', 'wakoo' ),
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $rep->get_controls(),
			'title_field' => '{{{ name }}}',
			'default'     => [],
			'condition'   => [ 'source!' => 'db' ],
		] );
		$this->add_control( 'csv', [
			'label'       => __( 'Archivo CSV de lugares', 'wakoo' ),
			'type'        => Controls_Manager::MEDIA,
			'media_types' => [ 'text/csv' ],
			/* translators: %s: CSV columns */
			'description' => sprintf( __( 'Sube un .csv con las columnas del plugin Place Finder: %s. Se lee de nuevo cada vez que cambias el archivo.', 'wakoo' ), implode( ', ', Module::CSV ) ),
			'condition'   => [ 'source!' => 'db' ],
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_places', [ 'label' => __( 'Lugares', 'wakoo' ) ] );
		$terms = get_terms( [ 'taxonomy' => Module::TAX, 'hide_empty' => false ] );
		$this->add_control( 'cats', [
			'label'       => __( 'Categorías', 'wakoo' ),
			'type'        => Controls_Manager::SELECT2,
			'multiple'    => true,
			'label_block' => true,
			'options'     => is_wp_error( $terms ) ? [] : wp_list_pluck( $terms, 'name', 'slug' ),
			'description' => __( 'Vacío = todas.', 'wakoo' ),
		] );
		$this->add_control( 'show_search', [ 'label' => __( 'Buscador', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'show_pills', [ 'label' => __( 'Botones de categorías', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'show_tools', [ 'label' => __( 'Cerca de mí, distancia y orden', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'units', [ 'label' => __( 'Unidades', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'mi', 'options' => [ 'mi' => __( 'Millas', 'wakoo' ), 'km' => __( 'Kilómetros', 'wakoo' ) ], 'condition' => [ 'show_tools' => 'yes' ] ] );
		$this->add_control( 'radii', [ 'label' => __( 'Distancias a elegir', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '1, 3, 5, 10, 25', 'condition' => [ 'show_tools' => 'yes' ] ] );
		$this->add_control( 'per_page', [ 'label' => __( 'Lugares por página («Ver más»)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 4, 'max' => 200, 'default' => 12 ] );
		$this->add_control( 'show_map', [ 'label' => __( 'Mapa', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes', 'separator' => 'before' ] );
		$this->add_control( 'cluster', [ 'label' => __( 'Agrupar marcadores cercanos', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes', 'condition' => [ 'show_map' => 'yes' ] ] );
		$this->add_control( 'layout', [
			'label'     => __( 'Disposición', 'wakoo' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'side',
			'options'   => [ 'side' => __( 'Mapa al lado de la lista', 'wakoo' ), 'stack' => __( 'Mapa encima de la lista', 'wakoo' ) ],
			'condition' => [ 'show_map' => 'yes' ],
		] );
		$this->add_responsive_control( 'map_height', [
			'label'      => __( 'Alto del mapa', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px', 'vh' ],
			'range'      => [ 'px' => [ 'min' => 200, 'max' => 900 ], 'vh' => [ 'min' => 20, 'max' => 90 ] ],
			'default'    => [ 'unit' => 'px', 'size' => 560 ],
			'selectors'  => [ '{{WRAPPER}} .wk-pl' => '--wk-pl-map-h: {{SIZE}}{{UNIT}};' ],
			'condition'  => [ 'show_map' => 'yes' ],
		] );
		$this->add_responsive_control( 'columns', [
			'label'     => __( 'Columnas de tarjetas', 'wakoo' ),
			'type'      => Controls_Manager::NUMBER,
			'min'       => 1,
			'max'       => 4,
			'selectors' => [ '{{WRAPPER}} .wk-pl' => '--wk-pl-cols: {{VALUE}};' ],
		] );
		$this->add_control( 'zoom', [ 'label' => __( 'Zoom con un solo lugar', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 3, 'max' => 18, 'default' => 14 ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_texts', [ 'label' => __( 'Textos', 'wakoo' ) ] );
		foreach ( self::texts() as $id => $d ) {
			$this->add_control( 'lbl_' . $id, [ 'label' => $d[0], 'type' => mb_strlen( $d[1] ) > 60 ? Controls_Manager::TEXTAREA : Controls_Manager::TEXT, 'default' => $d[1], 'label_block' => true ] );
		}
		$this->end_controls_section();

		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'accent', [ 'label' => __( 'Color de acento', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wk-pl' => '--wk-pl-accent: {{VALUE}};' ] ] );
		$this->add_control( 'card_bg', [ 'label' => __( 'Fondo de las tarjetas', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wk-pl' => '--wk-pl-card: {{VALUE}};' ] ] );
		$this->add_control( 'text_color', [ 'label' => __( 'Color del texto', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wk-pl' => '--wk-pl-text: {{VALUE}};' ] ] );
		$this->add_control( 'radius', [ 'label' => __( 'Redondez (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 40, 'selectors' => [ '{{WRAPPER}} .wk-pl' => '--wk-pl-radius: {{VALUE}}px;' ] ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'name_typo', 'label' => __( 'Nombre del lugar', 'wakoo' ), 'selector' => '{{WRAPPER}} .wk-pl__name' ] );
		$this->end_controls_section();
	}

	private function t( $id ) {
		$v = $this->get_settings_for_display( 'lbl_' . $id );
		return ( null === $v || '' === $v ) ? ( self::texts()[ $id ][1] ?? '' ) : (string) $v;
	}

	protected function render() {
		$s       = $this->get_settings_for_display();
		$lang    = Module::lang_of_page();
		$only    = array_values( array_filter( array_map( 'sanitize_title', (array) ( $s['cats'] ?? [] ) ) ) );
		$places  = $this->collect( $s, $only, $lang );
		$uid     = 'wkpl-' . $this->get_id();
		$opt     = Module::settings();
		$has_map = 'yes' === ( $s['show_map'] ?? '' );
		$tools   = 'yes' === ( $s['show_tools'] ?? '' );
		$units   = 'km' === ( $s['units'] ?? 'mi' ) ? 'km' : 'mi';

		// Category buttons: only the categories these places use, in the page's language, biggest first.
		$used = [];
		foreach ( $places as $p ) { foreach ( $p['cats'] as $c ) { $used[ $c ] = ( $used[ $c ] ?? 0 ) + 1; } }
		$labels = Module::categories( $only, $lang );
		foreach ( $places as $p ) { foreach ( (array) ( $p['labels'] ?? [] ) as $l ) { $labels += [ sanitize_title( $l ) => $l ]; } }
		$cats = array_intersect_key( $labels, $used );
		uksort( $cats, function ( $a, $b ) use ( $used ) { return $used[ $b ] <=> $used[ $a ]; } );

		$texts = [];
		foreach ( array_keys( self::texts() ) as $k ) { $texts[ $k ] = $this->t( $k ); }
		$cfg = [
			'tiles'   => $opt['tiles'],
			'attr'    => $opt['attr'],
			'zoom'    => (int) ( $s['zoom'] ?? 14 ),
			'units'   => $units,
			'perPage' => max( 4, (int) ( $s['per_page'] ?? 12 ) ),
			'cluster' => 'yes' === ( $s['cluster'] ?? '' ),
			'lang'    => $lang ?: substr( get_locale(), 0, 2 ),
			't'       => $texts,
		];

		echo '<div class="wk-pl wk-pl--' . esc_attr( $has_map ? ( $s['layout'] ?? 'side' ) : 'nomap' ) . '" id="' . esc_attr( $uid ) . '" data-wk-pl="' . esc_attr( wp_json_encode( $cfg ) ) . '">';
		echo '<div class="wk-pl__tools">';
		if ( 'yes' === ( $s['show_search'] ?? '' ) ) {
			echo '<div class="wk-pl__bar"><label class="screen-reader-text" for="' . esc_attr( $uid ) . '-q">' . esc_html( $texts['search_lb'] ) . '</label>'
				. '<svg class="wk-pl__icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M10.5 3a7.5 7.5 0 0 1 5.96 12.06l4.24 4.24-1.4 1.4-4.24-4.24A7.5 7.5 0 1 1 10.5 3zm0 2a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11z"/></svg>'
				. '<input id="' . esc_attr( $uid ) . '-q" class="wk-pl__q" type="search" autocomplete="off" enterkeyhint="search" placeholder="' . esc_attr( $texts['search_ph'] ) . '">'
				. '<kbd class="wk-pl__kbd" aria-hidden="true">/</kbd>'
				. '<span class="wk-pl__count" aria-live="polite">' . esc_html( str_replace( '{n}', (string) count( $places ), $texts['count'] ) ) . '</span></div>';
		}
		if ( 'yes' === ( $s['show_pills'] ?? '' ) && count( $cats ) > 1 ) {
			echo '<div class="wk-pl__pills" role="group" aria-label="' . esc_attr( $texts['cats_lb'] ) . '">';
			echo '<button type="button" class="wk-pl__pill is-on" data-cat="" aria-pressed="true">' . esc_html( $texts['all'] ) . '</button>';
			foreach ( $cats as $slug => $label ) {
				echo '<button type="button" class="wk-pl__pill" data-cat="' . esc_attr( $slug ) . '" aria-pressed="false">' . esc_html( $label ) . ' <span class="wk-pl__n">' . (int) $used[ $slug ] . '</span></button>';
			}
			echo '</div>';
		}
		if ( $tools ) {
			$radii = array_values( array_filter( array_map( 'floatval', preg_split( '/[,\s]+/', (string) ( $s['radii'] ?? '' ) ) ) ) );
			echo '<div class="wk-pl__opts">';
			echo '<button type="button" class="wk-pl__near" aria-pressed="false"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2 4.5 20.3l.7.7L12 18l6.8 3 .7-.7z"/></svg><span>' . esc_html( $texts['near'] ) . '</span></button>';
			echo '<label class="wk-pl__opt"><span>' . esc_html( $texts['radius_lb'] ) . '</span><select class="wk-pl__radius" disabled><option value="">' . esc_html( $texts['radius_any'] ) . '</option>';
			foreach ( $radii as $r ) {
				$d = rtrim( rtrim( number_format( $r, 1, '.', '' ), '0' ), '.' ) . ' ' . $units;
				echo '<option value="' . esc_attr( $r ) . '">' . esc_html( str_replace( '{d}', $d, $texts['within'] ) ) . '</option>';
			}
			echo '</select></label>';
			echo '<label class="wk-pl__opt"><span>' . esc_html( $texts['sort_lb'] ) . '</span><select class="wk-pl__sort"><option value="rel">' . esc_html( $texts['sort_rel'] ) . '</option><option value="az">' . esc_html( $texts['sort_az'] ) . '</option><option value="near" disabled>' . esc_html( $texts['sort_near'] ) . '</option></select></label>';
			if ( $has_map ) {
				echo '<label class="wk-pl__check"><input type="checkbox" class="wk-pl__inmap"> <span>' . esc_html( $texts['inmap'] ) . '</span></label>';
			}
			echo '<button type="button" class="wk-pl__reset" hidden>' . esc_html( $texts['reset'] ) . '</button>';
			echo '<span class="wk-pl__geo" role="status" aria-live="polite"></span>';
			echo '</div>';
		}
		echo '</div>';

		echo '<div class="wk-pl__body">';
		if ( $has_map ) {
			echo '<div class="wk-pl__map" role="region" aria-label="' . esc_attr( $texts['map_lb'] ) . '"></div>';
		}
		echo '<div class="wk-pl__results"><ul class="wk-pl__list" role="list">';
		foreach ( $places as $i => $p ) {
			echo '<li class="wk-pl__item" data-i="' . (int) $i . '" data-slug="' . esc_attr( $p['slug'] ) . '" data-cats="' . esc_attr( implode( ' ', $p['cats'] ) ) . '"><article class="wk-pl__card">';
			echo '<div class="wk-pl__meta">';
			if ( $p['cat'] ) { echo '<span class="wk-pl__badge">' . esc_html( $p['cat'] ) . '</span>'; }
			echo '<span class="wk-pl__dist" hidden></span></div>';
			echo '<h3 class="wk-pl__name"><button type="button" class="wk-pl__open" aria-haspopup="dialog" aria-controls="' . esc_attr( $uid ) . '-dlg">' . esc_html( $p['name'] ) . '</button></h3>';
			if ( $p['address'] ) { echo '<p class="wk-pl__addr">' . esc_html( $p['address'] ) . '</p>'; }
			if ( $p['desc'] ) { echo '<p class="wk-pl__desc">' . esc_html( wp_trim_words( $p['desc'], 18, '…' ) ) . '</p>'; }
			echo '<span class="wk-pl__more" aria-hidden="true">' . esc_html( $texts['details'] ) . ' →</span></article></li>';
		}
		echo '</ul><div class="wk-pl__none" hidden><p>' . esc_html( $texts['none'] ) . '</p><button type="button" class="wk-pl__reset2">' . esc_html( $texts['reset'] ) . '</button></div>'
			. '<button type="button" class="wk-pl__page" hidden></button></div></div>';

		// The popup, filled by places.js with the chosen place.
		echo '<dialog class="wk-pl__modal" id="' . esc_attr( $uid ) . '-dlg" aria-labelledby="' . esc_attr( $uid ) . '-title"><div class="wk-pl__sheet">'
			. '<button type="button" class="wk-pl__close" aria-label="' . esc_attr( $texts['close'] ) . '">×</button>'
			. '<div class="wk-pl__photos"></div><div class="wk-pl__mbody"><p class="wk-pl__mcat"></p><h2 class="wk-pl__mtitle" id="' . esc_attr( $uid ) . '-title"></h2>'
			. '<p class="wk-pl__maddr"></p><div class="wk-pl__mdesc"></div><div class="wk-pl__actions"></div>'
			. '<div class="wk-pl__mmap" role="img"></div><div class="wk-pl__mreviews"><h3>' . esc_html( $texts['reviews'] ) . '</h3><div class="wk-pl__mreviews-text"></div></div></div></div></dialog>';

		echo '<script type="application/json" class="wk-pl__data">' . wp_json_encode( $places, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE ) . '</script>'; // phpcs:ignore WordPress.Security.EscapeOutput
		$this->json_ld( $places );
		echo '</div>';
	}

	/** The places to show: the site's (Lugares Wakoo) and/or this widget's own list and CSV file. */
	private function collect( array $s, array $only, $lang ) {
		$src    = $s['source'] ?? 'db';
		$places = 'widget' === $src ? [] : Module::places( $only, $lang );
		if ( 'db' === $src ) { return $places; }
		$rows = [];
		foreach ( (array) ( $s['items'] ?? [] ) as $n => $it ) {
			$rows[ 'w' . ( $it['_id'] ?? $n ) ] = [
				'name' => $it['name'] ?? '', 'category' => $it['category'] ?? '', 'address' => $it['address'] ?? '', 'lat' => $it['lat'] ?? '', 'lng' => $it['lng'] ?? '',
				'phone' => $it['phone'] ?? '', 'email' => $it['email'] ?? '', 'website' => $it['website']['url'] ?? '', 'description' => $it['description'] ?? '',
				'photos' => $it['photo']['url'] ?? '', 'tags' => $it['tags'] ?? '',
			];
		}
		foreach ( Module::csv_file_rows( (int) ( $s['csv']['id'] ?? 0 ) ) as $n => $r ) { $rows[ 'c' . $n ] = $r; }
		foreach ( $rows as $key => $r ) {
			$p = Module::from_row( $r, $key );
			if ( $p && ( ! $only || array_intersect( $only, $p['cats'] ) ) ) { $places[] = $p; }
		}
		if ( 'both' === $src ) { usort( $places, function ( $a, $b ) { return strcasecmp( $a['name'], $b['name'] ); } ); }
		return $places;
	}

	/** ItemList of Place: lets search engines and AI assistants read every place of the finder. */
	private function json_ld( array $places ) {
		if ( ! $places || ( class_exists( '\Elementor\Plugin' ) && \Elementor\Plugin::$instance->editor->is_edit_mode() ) ) { return; }
		$items = [];
		foreach ( array_slice( $places, 0, 200 ) as $n => $p ) {
			$place = array_filter( [ '@type' => 'Place', 'name' => $p['name'], 'description' => $p['desc'], 'address' => $p['address'], 'telephone' => $p['phone'], 'url' => $p['website'] ?: null, 'hasMap' => $p['maps'] ] );
			if ( null !== $p['lat'] ) { $place['geo'] = [ '@type' => 'GeoCoordinates', 'latitude' => $p['lat'], 'longitude' => $p['lng'] ]; }
			$items[] = [ '@type' => 'ListItem', 'position' => $n + 1, 'item' => $place ];
		}
		echo '<script type="application/ld+json">' . wp_json_encode( [ '@context' => 'https://schema.org', '@type' => 'ItemList', 'itemListElement' => $items ], JSON_HEX_TAG | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}
