<?php
/**
 * "Gestor de lugares": manage the places from any page, like the Place
 * Finder plugin's dashboard. Only people who can edit others' posts see it
 * (editors and administrators); everyone else sees nothing.
 *
 * Add a place, import a CSV (Place Finder columns), import the Place Finder
 * plugin's own data, export a CSV, find coordinates, and a list of the places
 * with edit and delete (to the trash). Every form goes through admin-post.php
 * with its own nonce and comes back to this page.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Places;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Manager extends Widget_Base {

	public function get_name() { return 'wakoo-places-manager'; }
	public function get_title() { return __( 'Gestor de lugares', 'wakoo' ); }
	public function get_icon() { return 'eicon-database'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'lugares', 'places', 'csv', 'importar', 'gestor', 'dashboard', 'wakoo' ]; }
	public function get_style_depends() { return [ 'wakoo-places' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_manager', [ 'label' => __( 'Gestor de lugares', 'wakoo' ) ] );
		$this->add_control( 'note', [
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => esc_html__( 'Solo lo ven los editores y administradores con la sesión iniciada. Los visitantes no ven nada. Pon este widget en una página privada o en la misma página del buscador.', 'wakoo' ),
			'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
		] );
		$this->add_control( 'title', [ 'label' => __( 'Título', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Gestor de lugares', 'wakoo' ), 'label_block' => true ] );
		$this->add_control( 'show_list', [ 'label' => __( 'Lista de lugares', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->end_controls_section();
		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'accent', [ 'label' => __( 'Color de acento', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wk-plm' => '--wk-pl-accent: {{VALUE}};' ] ] );
		$this->end_controls_section();
	}

	private static function form_open( $action, $extra = '' ) {
		global $wp;
		$here = home_url( add_query_arg( [], $wp->request ? trailingslashit( $wp->request ) : '/' ) );
		return '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"' . $extra . '>'
			. wp_nonce_field( 'wakoo_places_' . $action, '_wpnonce', true, false )
			. '<input type="hidden" name="action" value="wakoo_places_' . esc_attr( $action ) . '">'
			. '<input type="hidden" name="wk_back" value="' . esc_attr( remove_query_arg( [ 'wk_pl_msg', 'wk_pl_n' ], $here ) ) . '">';
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			if ( class_exists( '\Elementor\Plugin' ) && \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				echo '<p class="wk-plm__note">' . esc_html__( 'Gestor de lugares: solo visible para editores.', 'wakoo' ) . '</p>';
			}
			return;
		}
		$msgs = [
			'added'    => __( 'Lugar añadido.', 'wakoo' ),
			'trashed'  => __( 'Lugar enviado a la papelera (se puede recuperar desde el escritorio).', 'wakoo' ),
			'imported' => __( 'Lugares importados o actualizados: %d.', 'wakoo' ),
			'coords'   => __( 'Coordenadas encontradas: %d.', 'wakoo' ),
			'nofile'   => __( 'Sube un archivo .csv de hasta 5 MB.', 'wakoo' ),
			'noname'   => __( 'El lugar necesita un nombre.', 'wakoo' ),
		];
		$m = isset( $_GET['wk_pl_msg'] ) ? sanitize_key( wp_unslash( $_GET['wk_pl_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$n = isset( $_GET['wk_pl_n'] ) ? (int) $_GET['wk_pl_n'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$all = get_posts( [ 'post_type' => Module::CPT, 'post_status' => [ 'publish', 'draft', 'pending' ], 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ] );
		$terms = get_terms( [ 'taxonomy' => Module::TAX, 'hide_empty' => false ] );
		$terms = is_wp_error( $terms ) ? [] : $terms;
		$uid = 'wkplm-' . $this->get_id();

		echo '<div class="wk-plm" id="wk-pl-manager">';
		echo '<div class="wk-plm__head"><h2>' . esc_html( $s['title'] ?: __( 'Gestor de lugares', 'wakoo' ) ) . '</h2><div class="wk-plm__stats">'
			. '<span><strong>' . count( $all ) . '</strong> ' . esc_html__( 'lugares', 'wakoo' ) . '</span>'
			. '<span><strong>' . count( $terms ) . '</strong> ' . esc_html__( 'categorías', 'wakoo' ) . '</span></div></div>';
		if ( isset( $msgs[ $m ] ) ) {
			echo '<div class="wk-plm__notice' . ( in_array( $m, [ 'nofile', 'noname' ], true ) ? ' is-error' : '' ) . '" role="status">' . esc_html( sprintf( $msgs[ $m ], $n ) ) . '</div>';
		}

		echo '<div class="wk-plm__grid">';
		// Add a place.
		echo '<details class="wk-plm__card" open><summary>' . esc_html__( 'Añadir un lugar', 'wakoo' ) . '</summary>' . self::form_open( 'quick', ' class="wk-plm__form"' ); // phpcs:ignore WordPress.Security.EscapeOutput
		$f = function ( $name, $label, $type = 'text', $req = false, $attrs = '' ) use ( $uid ) {
			return '<label for="' . esc_attr( $uid . '-' . $name ) . '">' . esc_html( $label ) . ( $req ? ' *' : '' )
				. ( 'textarea' === $type ? '<textarea id="' . esc_attr( $uid . '-' . $name ) . '" name="wk[' . esc_attr( $name ) . ']" rows="3"></textarea>'
					: '<input id="' . esc_attr( $uid . '-' . $name ) . '" type="' . esc_attr( $type ) . '" name="wk[' . esc_attr( $name ) . ']"' . ( $req ? ' required' : '' ) . $attrs . '>' ) . '</label>';
		};
		echo $f( 'name', __( 'Nombre', 'wakoo' ), 'text', true ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo $f( 'category', __( 'Categoría (elige o escribe una nueva)', 'wakoo' ), 'text', false, ' list="' . esc_attr( $uid ) . '-cats"' ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<datalist id="' . esc_attr( $uid ) . '-cats">';
		foreach ( $terms as $t ) { echo '<option value="' . esc_attr( $t->name ) . '">'; }
		echo '</datalist>';
		echo $f( 'address', __( 'Dirección', 'wakoo' ) ) . $f( 'phone', __( 'Teléfono', 'wakoo' ), 'tel' ) . $f( 'email', __( 'Email', 'wakoo' ), 'email' ) // phpcs:ignore WordPress.Security.EscapeOutput
			. $f( 'website', __( 'Sitio web', 'wakoo' ), 'url' ) . $f( 'description', __( 'Descripción', 'wakoo' ), 'textarea' ) . $f( 'tags', __( 'Palabras clave', 'wakoo' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<p class="wk-plm__help">' . esc_html__( 'Las coordenadas se buscan solas a partir de la dirección. Para fotos, opiniones y textos en otros idiomas, abre el lugar en el escritorio.', 'wakoo' ) . '</p>';
		echo '<button type="submit" class="wk-plm__btn wk-plm__btn--main">' . esc_html__( 'Guardar lugar', 'wakoo' ) . '</button></form></details>';

		// Import / export.
		echo '<div class="wk-plm__card"><h3>' . esc_html__( 'Cargar desde un archivo', 'wakoo' ) . '</h3>';
		echo '<p class="wk-plm__help">' . esc_html( sprintf( /* translators: %s: columns */ __( 'CSV con las columnas: %s. Un lugar con el mismo nombre se actualiza; las categorías se crean solas.', 'wakoo' ), implode( ', ', Module::CSV ) ) ) . '</p>';
		echo self::form_open( 'import', ' enctype="multipart/form-data" class="wk-plm__row"' ) . '<input type="file" name="wk_csv" accept=".csv,text/csv" required aria-label="' . esc_attr__( 'Archivo CSV', 'wakoo' ) . '"><button type="submit" class="wk-plm__btn wk-plm__btn--main">' . esc_html__( 'Importar CSV', 'wakoo' ) . '</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<div class="wk-plm__row">' . self::form_open( 'export' ) . '<button type="submit" class="wk-plm__btn">' . esc_html__( 'Descargar CSV', 'wakoo' ) . '</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo self::form_open( 'coords' ) . '<button type="submit" class="wk-plm__btn">' . esc_html__( 'Buscar coordenadas que faltan', 'wakoo' ) . '</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( get_option( 'lapf_places_data' ) ) {
			echo self::form_open( 'lapf' ) . '<button type="submit" class="wk-plm__btn">' . esc_html( sprintf( /* translators: %d: places */ __( 'Importar del Place Finder (%d)', 'wakoo' ), count( (array) get_option( 'lapf_places_data' ) ) ) ) . '</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div><p class="wk-plm__help"><a href="' . esc_url( admin_url( 'edit.php?post_type=' . Module::CPT ) ) . '">' . esc_html__( 'Abrir Lugares Wakoo en el escritorio', 'wakoo' ) . ' →</a></p></div>';
		echo '</div>';

		if ( 'yes' === ( $s['show_list'] ?? '' ) && $all ) {
			echo '<div class="wk-plm__card wk-plm__table"><div class="wk-plm__row"><h3>' . esc_html__( 'Lugares', 'wakoo' ) . '</h3>'
				. '<input type="search" class="wk-plm__filter" placeholder="' . esc_attr__( 'Filtrar…', 'wakoo' ) . '" aria-label="' . esc_attr__( 'Filtrar lugares', 'wakoo' ) . '" oninput="var v=this.value.toLowerCase();this.closest(\'.wk-plm__table\').querySelectorAll(\'tbody tr\').forEach(function(r){r.hidden=v&&r.textContent.toLowerCase().indexOf(v)<0;})"></div>';
			echo '<div class="wk-plm__scroll"><table><thead><tr><th>' . esc_html__( 'Nombre', 'wakoo' ) . '</th><th>' . esc_html__( 'Categoría', 'wakoo' ) . '</th><th>' . esc_html__( 'Dirección', 'wakoo' ) . '</th><th>' . esc_html__( 'Mapa', 'wakoo' ) . '</th><th><span class="screen-reader-text">' . esc_html__( 'Acciones', 'wakoo' ) . '</span></th></tr></thead><tbody>';
			foreach ( $all as $p ) {
				$tt   = get_the_terms( $p, Module::TAX );
				$del  = wp_nonce_url( add_query_arg( [ 'action' => 'wakoo_places_trash', 'id' => $p->ID, 'wk_back' => rawurlencode( get_permalink() ?: home_url( '/' ) ) ], admin_url( 'admin-post.php' ) ), 'wakoo_places_trash_' . $p->ID );
				echo '<tr><td><strong>' . esc_html( $p->post_title ) . '</strong>' . ( 'publish' !== $p->post_status ? ' <em>(' . esc_html( $p->post_status ) . ')</em>' : '' ) . '</td>'
					. '<td>' . esc_html( is_array( $tt ) ? implode( ', ', wp_list_pluck( $tt, 'name' ) ) : '' ) . '</td>'
					. '<td>' . esc_html( Module::get( $p->ID, 'address' ) ) . '</td>'
					. '<td>' . ( '' !== Module::get( $p->ID, 'lat' ) ? '✔' : '—' ) . '</td>'
					. '<td class="wk-plm__acts"><a href="' . esc_url( get_edit_post_link( $p->ID ) ) . '" target="_blank" rel="noopener">' . esc_html__( 'Editar', 'wakoo' ) . '</a>'
					. ( current_user_can( 'delete_post', $p->ID ) ? ' <a class="wk-plm__del" href="' . esc_url( $del ) . '" onclick="return confirm(\'' . esc_js( __( '¿Enviar este lugar a la papelera?', 'wakoo' ) ) . '\')">' . esc_html__( 'Borrar', 'wakoo' ) . '</a>' : '' ) . '</td></tr>';
			}
			echo '</tbody></table></div></div>';
		}
		echo '</div>';
	}
}
