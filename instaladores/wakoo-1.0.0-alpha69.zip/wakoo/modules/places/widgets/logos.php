<?php
/**
 * "Logos de lugares": a band with the logos of the places of some categories
 * (institutions, clubs, NGOs, sponsors…) with their name and address. A place
 * without a logo shows its initials. Each logo opens the place: in the
 * "Buscador de lugares" of the same page, or in the finder page.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Places;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Logos extends Widget_Base {

	const STOP = [ 'of', 'the', 'de', 'del', 'la', 'el', 'and', 'y', 'club', 'post', 'lodge', 'greater', 'lehigh', 'acres', 'no', 'inc' ];

	public function get_name() { return 'wakoo-places-logos'; }
	public function get_title() { return __( 'Logos de lugares', 'wakoo' ); }
	public function get_icon() { return 'eicon-logo'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'logos', 'lugares', 'places', 'ong', 'instituciones', 'patrocinadores', 'sponsors', 'wakoo' ]; }
	public function get_style_depends() { return [ 'wakoo-places' ]; }
	public function get_script_depends() { return [ 'wakoo-places' ]; }

	public static function texts() {
		return [
			'prev' => [ __( 'Botón: anteriores', 'wakoo' ), __( 'Anteriores', 'wakoo' ) ],
			'next' => [ __( 'Botón: siguientes', 'wakoo' ), __( 'Siguientes', 'wakoo' ) ],
			'more' => [ __( 'Enlace de cada logo', 'wakoo' ), __( 'Ver ficha', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_logos', [ 'label' => __( 'Logos de lugares', 'wakoo' ) ] );
		$terms = get_terms( [ 'taxonomy' => Module::TAX, 'hide_empty' => false ] );
		$this->add_control( 'cats', [
			'label'       => __( 'Categorías', 'wakoo' ),
			'type'        => Controls_Manager::SELECT2,
			'multiple'    => true,
			'label_block' => true,
			'options'     => is_wp_error( $terms ) ? [] : wp_list_pluck( $terms, 'name', 'slug' ),
			'description' => __( 'Por ejemplo «Comunidad y ONG». El logo es la primera foto de cada lugar (Lugares Wakoo); sin foto se ven sus iniciales.', 'wakoo' ),
		] );
		$this->add_control( 'layout', [ 'label' => __( 'Disposición', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'band', 'options' => [ 'band' => __( 'Banda con flechas', 'wakoo' ), 'grid' => __( 'Cuadrícula', 'wakoo' ) ] ] );
		$this->add_control( 'show_address', [ 'label' => __( 'Dirección', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'show_desc', [ 'label' => __( 'Descripción corta', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'words', [ 'label' => __( 'Palabras de la descripción', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 4, 'max' => 40, 'default' => 14, 'condition' => [ 'show_desc' => 'yes' ] ] );
		foreach ( self::texts() as $id => $d ) {
			$this->add_control( 'lbl_' . $id, [ 'label' => $d[0], 'type' => Controls_Manager::TEXT, 'default' => $d[1], 'label_block' => true ] );
		}
		$this->end_controls_section();
		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'accent', [ 'label' => __( 'Color de acento', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wk-pll' => '--wk-pl-accent: {{VALUE}};' ] ] );
		$this->add_control( 'card_w', [ 'label' => __( 'Ancho de cada logo (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 140, 'max' => 400, 'default' => 220, 'selectors' => [ '{{WRAPPER}} .wk-pll' => '--wk-pll-w: {{VALUE}}px;' ] ] );
		$this->end_controls_section();
	}

	private function t( $id ) {
		$v = $this->get_settings_for_display( 'lbl_' . $id );
		return ( null === $v || '' === $v ) ? self::texts()[ $id ][1] : (string) $v;
	}

	/** "VFW Post 4174" → VFW, "Lions Club of Lehigh Acres" → L, "Chamber of Commerce" → CC. */
	public static function initials( $name ) {
		$words = array_values( array_filter( preg_split( '/[\s\-·]+/u', (string) $name ), function ( $w ) { return '' !== $w && ! is_numeric( $w ) && ! in_array( strtolower( $w ), self::STOP, true ); } ) );
		if ( ! $words ) { return mb_strtoupper( mb_substr( (string) $name, 0, 1 ) ); }
		if ( mb_strlen( $words[0] ) >= 2 && mb_strlen( $words[0] ) <= 4 && $words[0] === mb_strtoupper( $words[0] ) ) { return $words[0]; }
		return mb_strtoupper( implode( '', array_map( function ( $w ) { return mb_substr( $w, 0, 1 ); }, array_slice( $words, 0, 2 ) ) ) );
	}

	protected function render() {
		$s      = $this->get_settings_for_display();
		$lang   = Module::lang_of_page();
		$only   = array_values( array_filter( array_map( 'sanitize_title', (array) ( $s['cats'] ?? [] ) ) ) );
		$places = Module::places( $only, $lang );
		if ( ! $places ) {
			if ( class_exists( '\Elementor\Plugin' ) && \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				echo '<p class="wk-pll__empty">' . esc_html__( 'Logos de lugares: elige una categoría que tenga lugares.', 'wakoo' ) . '</p>';
			}
			return;
		}
		$page = Module::page_url( $lang );
		$band = 'grid' !== ( $s['layout'] ?? 'band' );
		echo '<div class="wk-pll wk-pll--' . ( $band ? 'band' : 'grid' ) . '">';
		if ( $band ) { echo '<button type="button" class="wk-pll__nav wk-pll__prev" aria-label="' . esc_attr( $this->t( 'prev' ) ) . '">‹</button>'; }
		echo '<ul class="wk-pll__track" role="list">';
		foreach ( $places as $p ) {
			$href = $page ? add_query_arg( 'wk_place', $p['slug'], $page ) . '#lugares' : ( $p['website'] ?: $p['maps'] );
			$logo = $p['photos'][0] ?? '';
			echo '<li class="wk-pll__item"><a class="wk-pll__card" href="' . esc_url( $href ) . '" data-slug="' . esc_attr( $p['slug'] ) . '">';
			echo '<span class="wk-pll__logo">' . ( $logo ? '<img src="' . esc_url( $logo ) . '" alt="' . esc_attr( sprintf( /* translators: %s: organisation */ __( 'Logo de %s', 'wakoo' ), $p['name'] ) ) . '" loading="lazy">' : '<span class="wk-pll__initials" aria-hidden="true">' . esc_html( self::initials( $p['name'] ) ) . '</span>' ) . '</span>';
			echo '<strong class="wk-pll__name">' . esc_html( $p['name'] ) . '</strong>';
			if ( 'yes' === ( $s['show_address'] ?? '' ) && $p['address'] ) { echo '<span class="wk-pll__addr">' . esc_html( $p['address'] ) . '</span>'; }
			if ( 'yes' === ( $s['show_desc'] ?? '' ) && $p['desc'] ) { echo '<span class="wk-pll__desc">' . esc_html( wp_trim_words( $p['desc'], (int) ( $s['words'] ?? 14 ), '…' ) ) . '</span>'; }
			echo '<span class="wk-pll__more" aria-hidden="true">' . esc_html( $this->t( 'more' ) ) . ' →</span></a></li>';
		}
		echo '</ul>';
		if ( $band ) { echo '<button type="button" class="wk-pll__nav wk-pll__next" aria-label="' . esc_attr( $this->t( 'next' ) ) . '">›</button>'; }
		echo '</div>';
	}
}
