( function () {
	'use strict';

	var PIN = '<span class="wk-pl__pin-dot"></span>';
	var LOCATE = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zm8.94 3A9 9 0 0 0 13 3.06V1h-2v2.06A9 9 0 0 0 3.06 11H1v2h2.06A9 9 0 0 0 11 20.94V23h2v-2.06A9 9 0 0 0 20.94 13H23v-2h-2.06zM12 19a7 7 0 1 1 0-14 7 7 0 0 1 0 14z"/></svg>';

	/** Lower case, no accents, no apostrophes: "Culver’s" = "culvers", "Farmácia" = "farmacia". */
	function norm( s ) {
		return String( s || '' ).toLowerCase().normalize( 'NFD' ).replace( /[̀-ͯ]/g, '' ).replace( /['’`]/g, '' );
	}

	function el( tag, cls, text ) {
		var n = document.createElement( tag );
		if ( cls ) { n.className = cls; }
		if ( text ) { n.textContent = text; }
		return n;
	}

	function link( href, text, cls, blank ) {
		var a = el( 'a', 'wk-pl__btn ' + ( cls || '' ), text );
		a.href = href;
		if ( blank ) { a.target = '_blank'; a.rel = 'noopener'; }
		return a;
	}

	function safeUrl( u ) {
		return /^https?:\/\//i.test( u || '' ) ? u : '';
	}

	function tiles( cfg ) {
		return L.tileLayer( cfg.tiles, { attribution: cfg.attr, maxZoom: 19 } );
	}

	function pin() {
		return L.divIcon( { className: 'wk-pl__pin', html: PIN, iconSize: [ 30, 30 ], iconAnchor: [ 15, 30 ] } );
	}

	/** Straight-line distance in miles or km. */
	function distance( a, b, units ) {
		var r = 'km' === units ? 6371 : 3958.8, rad = Math.PI / 180,
			dLat = ( b[ 0 ] - a[ 0 ] ) * rad, dLng = ( b[ 1 ] - a[ 1 ] ) * rad,
			h = Math.sin( dLat / 2 ) * Math.sin( dLat / 2 ) + Math.cos( a[ 0 ] * rad ) * Math.cos( b[ 0 ] * rad ) * Math.sin( dLng / 2 ) * Math.sin( dLng / 2 );
		return 2 * r * Math.asin( Math.min( 1, Math.sqrt( h ) ) );
	}

	/** One "Buscador de lugares" widget. */
	function finder( root ) {
		if ( root.dataset.wkInit ) { return; }
		root.dataset.wkInit = '1';
		var cfg = {}, places = [];
		try { cfg = JSON.parse( root.getAttribute( 'data-wk-pl' ) || '{}' ); } catch ( e ) {}
		try { places = JSON.parse( root.querySelector( '.wk-pl__data' ).textContent || '[]' ); } catch ( e ) {}
		var t = cfg.t || {}, units = cfg.units || 'mi', perPage = cfg.perPage || 12;
		var $ = function ( s ) { return root.querySelector( s ); };
		var q = $( '.wk-pl__q' ), count = $( '.wk-pl__count' ), none = $( '.wk-pl__none' ), list = $( '.wk-pl__list' ),
			pageBtn = $( '.wk-pl__page' ), nearBtn = $( '.wk-pl__near' ), radiusSel = $( '.wk-pl__radius' ), sortSel = $( '.wk-pl__sort' ),
			inmapBox = $( '.wk-pl__inmap' ), resetBtn = $( '.wk-pl__reset' ), geoMsg = $( '.wk-pl__geo' ), mapEl = $( '.wk-pl__map' ), dlg = $( '.wk-pl__modal' ),
			pills = Array.prototype.slice.call( root.querySelectorAll( '.wk-pl__pill' ) ),
			items = Array.prototype.slice.call( root.querySelectorAll( '.wk-pl__item' ) );
		var state = { term: '', cats: [], near: null, radius: 0, sort: 'rel', inmap: false, shown: perPage };
		var map = null, layer = null, markers = [], you = null, mini = null, lastOpener = null, fitting = false, matches = [];

		// Search index: name first, then the words of every language, the address and the description.
		var docs = places.map( function ( p, i ) {
			return { i: i, name: norm( p.name ), words: norm( ( p.words || '' ) + ' ' + p.cat ), addr: norm( p.address ), desc: norm( p.desc ) };
		} );
		var fuse = window.Fuse ? new window.Fuse( docs, {
			keys: [ { name: 'name', weight: 0.5 }, { name: 'words', weight: 0.3 }, { name: 'addr', weight: 0.1 }, { name: 'desc', weight: 0.1 } ],
			threshold: 0.34, ignoreLocation: true, minMatchCharLength: 2, includeScore: true
		} ) : null;

		function search( term ) {
			if ( ! term ) { return null; }
			if ( fuse ) { return fuse.search( term ).map( function ( r ) { return r.item.i; } ); }
			return docs.filter( function ( d ) { return ( d.name + ' ' + d.words + ' ' + d.addr + ' ' + d.desc ).indexOf( term ) > -1; } ).map( function ( d ) { return d.i; } );
		}

		function dist( i ) {
			var p = places[ i ];
			return ( state.near && null !== p.lat ) ? distance( state.near, [ p.lat, p.lng ], units ) : null;
		}

		function fmt( d ) {
			return ( d < 10 ? d.toFixed( 1 ) : Math.round( d ) ) + ' ' + units;
		}

		/** Everything except the category: used for the results and for the number on each category button. */
		function passesBase( i ) {
			var p = places[ i ];
			if ( state.radius && state.near ) { var d = dist( i ); if ( null === d || d > state.radius ) { return false; } }
			if ( state.inmap && map && null !== p.lat && ! map.getBounds().contains( [ p.lat, p.lng ] ) ) { return false; }
			if ( state.inmap && map && null === p.lat ) { return false; }
			return true;
		}

		function inCats( i ) {
			if ( ! state.cats.length ) { return true; }
			var c = places[ i ].cats || [];
			return state.cats.some( function ( x ) { return c.indexOf( x ) > -1; } );
		}

		function apply( keepPage, fromMap ) {
			if ( ! keepPage ) { state.shown = perPage; }
			var found = search( state.term );
			var pool = found || places.map( function ( p, i ) { return i; } );
			var base = pool.filter( passesBase );
			matches = base.filter( inCats );
			if ( 'az' === state.sort || ( 'rel' === state.sort && ! found ) ) {
				matches.sort( function ( a, b ) { return places[ a ].name.localeCompare( places[ b ].name ); } );
			} else if ( 'near' === state.sort && state.near ) {
				matches.sort( function ( a, b ) { return ( dist( a ) === null ? 1e9 : dist( a ) ) - ( dist( b ) === null ? 1e9 : dist( b ) ); } );
			}
			// Cards: the matches in order, the first page visible.
			var on = {};
			matches.forEach( function ( i, n ) {
				on[ i ] = true;
				var it = items[ i ];
				list.appendChild( it );
				it.hidden = n >= state.shown;
				var dEl = it.querySelector( '.wk-pl__dist' ), d = dist( i );
				dEl.hidden = null === d;
				dEl.textContent = null === d ? '' : fmt( d );
			} );
			items.forEach( function ( it, i ) { if ( ! on[ i ] ) { it.hidden = true; } } );
			var left = matches.length - Math.min( state.shown, matches.length );
			if ( pageBtn ) {
				pageBtn.hidden = left <= 0;
				pageBtn.textContent = String( t.more || '+{n}' ).replace( '{n}', left );
			}
			// Category buttons: state and how many results each would give.
			pills.forEach( function ( b ) {
				var c = b.dataset.cat || '', active = c ? state.cats.indexOf( c ) > -1 : ! state.cats.length;
				b.classList.toggle( 'is-on', active );
				b.setAttribute( 'aria-pressed', active ? 'true' : 'false' );
				var n = b.querySelector( '.wk-pl__n' );
				if ( n && c ) {
					var k = base.filter( function ( i ) { return ( places[ i ].cats || [] ).indexOf( c ) > -1; } ).length;
					n.textContent = k;
					b.classList.toggle( 'is-empty', ! k );
				}
			} );
			if ( count ) { count.textContent = 1 === matches.length && t.count1 ? t.count1 : String( t.count || '{n}' ).replace( '{n}', matches.length ); }
			if ( none ) { none.hidden = matches.length > 0; }
			if ( resetBtn ) { resetBtn.hidden = ! ( state.term || state.cats.length || state.radius || state.inmap || 'rel' !== state.sort || state.near ); }
			drawMarkers( ! fromMap && ! state.inmap );
			saveUrl();
		}

		function drawMarkers( refit ) {
			if ( ! map ) { return; }
			var add = matches.map( function ( i ) { return markers[ i ]; } ).filter( Boolean );
			if ( layer.clearLayers ) { layer.clearLayers(); }
			if ( layer.addLayers ) { layer.addLayers( add ); } else { add.forEach( function ( m ) { layer.addLayer( m ); } ); }
			if ( refit ) { fit(); }
		}

		function fit() {
			var pts = matches.map( function ( i ) { return places[ i ]; } ).filter( function ( p ) { return null !== p.lat; } ).map( function ( p ) { return [ p.lat, p.lng ]; } );
			if ( state.near ) { pts.push( state.near ); }
			if ( ! pts.length ) { return; }
			fitting = true;
			if ( 1 === pts.length ) { map.setView( pts[ 0 ], cfg.zoom || 14 ); } else { map.fitBounds( pts, { padding: [ 34, 34 ], maxZoom: 15 } ); }
			setTimeout( function () { fitting = false; }, 400 );
		}

		var urlTimer;
		function saveUrl() {
			clearTimeout( urlTimer );
			urlTimer = setTimeout( function () {
				try {
					var u = new URL( window.location.href );
					if ( state.term ) { u.searchParams.set( 'wk_q', q.value.trim() ); } else { u.searchParams.delete( 'wk_q' ); }
					if ( state.cats.length ) { u.searchParams.set( 'wk_cat', state.cats.join( ',' ) ); } else { u.searchParams.delete( 'wk_cat' ); }
					window.history.replaceState( null, '', u );
				} catch ( e ) {}
			}, 400 );
		}

		function makeMap() {
			if ( map || ! mapEl || ! window.L ) { return; }
			map = L.map( mapEl, { scrollWheelZoom: false, center: [ 26.6, -81.7 ], zoom: 11 } );
			tiles( cfg ).addTo( map );
			layer = ( cfg.cluster && L.markerClusterGroup ) ? L.markerClusterGroup( { showCoverageOnHover: false, maxClusterRadius: 46, spiderfyOnMaxZoom: true } ) : L.layerGroup();
			layer.addTo( map );
			places.forEach( function ( p, i ) {
				if ( null === p.lat ) { return; }
				var m = L.marker( [ p.lat, p.lng ], { icon: pin(), title: p.name, alt: p.name, keyboard: true } );
				m.bindTooltip( p.name, { direction: 'top', offset: [ 0, -28 ] } );
				m.on( 'click', function () { open( i, null ); } );
				markers[ i ] = m;
			} );
			var Locate = L.Control.extend( {
				options: { position: 'topright' },
				onAdd: function () {
					var b = L.DomUtil.create( 'button', 'wk-pl__locate' );
					b.type = 'button';
					b.title = t.locate || '';
					b.setAttribute( 'aria-label', t.locate || '' );
					b.innerHTML = LOCATE;
					L.DomEvent.on( b, 'click', function ( e ) { L.DomEvent.stop( e ); locate( true ); } );
					return b;
				}
			} );
			map.addControl( new Locate() );
			map.on( 'moveend', function () { if ( state.inmap && ! fitting ) { apply( false, true ); } } );
			drawMarkers( true );
			setTimeout( function () { map.invalidateSize(); fit(); }, 200 );
		}

		/** "Cerca de mí": the visitor's position sorts the list and shows distances. */
		function locate( force ) {
			if ( state.near && ! force ) { // Second click: back to normal.
				state.near = null;
				state.radius = 0;
				if ( 'near' === state.sort ) { state.sort = 'rel'; }
				syncTools();
				if ( you ) { you.remove(); you = null; }
				apply();
				return;
			}
			if ( ! navigator.geolocation ) { if ( geoMsg ) { geoMsg.textContent = t.geo_err || ''; } return; }
			if ( geoMsg ) { geoMsg.textContent = t.near_wait || ''; }
			navigator.geolocation.getCurrentPosition( function ( pos ) {
				state.near = [ pos.coords.latitude, pos.coords.longitude ];
				state.sort = 'near';
				if ( geoMsg ) { geoMsg.textContent = ''; }
				syncTools();
				if ( map ) {
					if ( you ) { you.remove(); }
					you = L.circleMarker( state.near, { radius: 9, color: '#1d4ed8', fillColor: '#3b82f6', fillOpacity: 0.6 } ).addTo( map ).bindTooltip( t.you || '', { permanent: true, direction: 'top' } );
				}
				apply();
			}, function () {
				if ( geoMsg ) { geoMsg.textContent = t.geo_err || ''; }
			}, { enableHighAccuracy: false, timeout: 12000, maximumAge: 600000 } );
		}

		function syncTools() {
			if ( nearBtn ) { nearBtn.setAttribute( 'aria-pressed', state.near ? 'true' : 'false' ); nearBtn.classList.toggle( 'is-on', !! state.near ); }
			if ( radiusSel ) { radiusSel.disabled = ! state.near; radiusSel.value = state.radius ? String( state.radius ) : ''; }
			if ( sortSel ) {
				var o = sortSel.querySelector( 'option[value="near"]' );
				if ( o ) { o.disabled = ! state.near; }
				sortSel.value = state.sort;
			}
			if ( inmapBox ) { inmapBox.checked = state.inmap; }
		}

		function reset() {
			state.term = ''; state.cats = []; state.radius = 0; state.inmap = false; state.sort = state.near ? 'near' : 'rel';
			if ( q ) { q.value = ''; }
			syncTools();
			apply();
		}

		/** Fill the popup with place i and open it. */
		function open( i, opener ) {
			var p = places[ i ];
			if ( ! p || ! dlg ) { return; }
			lastOpener = opener || document.activeElement;
			var photos = dlg.querySelector( '.wk-pl__photos' ), desc = dlg.querySelector( '.wk-pl__mdesc' ), actions = dlg.querySelector( '.wk-pl__actions' ),
				rev = dlg.querySelector( '.wk-pl__mreviews' ), mm = dlg.querySelector( '.wk-pl__mmap' ), d = dist( i );
			dlg.querySelector( '.wk-pl__mcat' ).textContent = p.cat || '';
			dlg.querySelector( '.wk-pl__mtitle' ).textContent = p.name || '';
			dlg.querySelector( '.wk-pl__maddr' ).textContent = ( p.address || '' ) + ( null !== d ? ' · ' + fmt( d ) : '' );
			photos.textContent = '';
			( p.photos || [] ).slice( 0, 8 ).forEach( function ( u ) {
				if ( ! safeUrl( u ) ) { return; }
				var img = el( 'img' );
				if ( /\.(png|svg)(\?|$)/i.test( u ) ) { img.className = 'is-logo'; } // Logos are shown whole, not cropped.
				img.src = u;
				img.alt = p.name;
				img.loading = 'lazy';
				photos.appendChild( img );
			} );
			photos.hidden = ! photos.children.length;
			desc.textContent = '';
			String( p.desc || '' ).split( /\n\s*\n|\r\n\s*\r\n/ ).forEach( function ( para ) { if ( para.trim() ) { desc.appendChild( el( 'p', '', para.trim() ) ); } } );
			actions.textContent = '';
			if ( safeUrl( p.dir ) ) { actions.appendChild( link( p.dir, t.dir, 'wk-pl__btn--main', true ) ); }
			if ( p.phone ) { actions.appendChild( link( 'tel:' + String( p.phone ).replace( /[^0-9+]/g, '' ), t.call + ' · ' + p.phone ) ); }
			if ( p.email ) { actions.appendChild( link( 'mailto:' + p.email, t.mail ) ); }
			if ( safeUrl( p.website ) ) { actions.appendChild( link( p.website, t.web, '', true ) ); }
			if ( safeUrl( p.maps ) ) { actions.appendChild( link( p.maps, t.maps, '', true ) ); }
			rev.hidden = ! p.reviews;
			dlg.querySelector( '.wk-pl__mreviews-text' ).textContent = p.reviews || '';
			mm.hidden = null === p.lat;
			mm.setAttribute( 'aria-label', p.name );

			if ( dlg.showModal ) { dlg.showModal(); } else { dlg.setAttribute( 'open', '' ); }
			document.documentElement.classList.add( 'wk-pl-lock' );

			// Small OpenStreetMap map inside the popup (no third-party cookies).
			if ( null !== p.lat && window.L ) {
				if ( ! mini ) {
					mini = L.map( mm, { zoomControl: true, scrollWheelZoom: false } );
					tiles( cfg ).addTo( mini );
					mini._pin = L.marker( [ p.lat, p.lng ], { icon: pin(), keyboard: false } ).addTo( mini );
				}
				mini.setView( [ p.lat, p.lng ], 15 );
				mini._pin.setLatLng( [ p.lat, p.lng ] );
				// Again once the opening animation is over, so the tiles fill the whole box.
				[ 60, 280 ].forEach( function ( ms ) { setTimeout( function () { mini.invalidateSize(); mini.setView( [ p.lat, p.lng ], 15 ); }, ms ); } );
			}
			try {
				var u = new URL( window.location.href );
				u.searchParams.set( 'wk_place', p.slug );
				window.history.replaceState( null, '', u );
			} catch ( e ) {}
		}

		function closed() {
			document.documentElement.classList.remove( 'wk-pl-lock' );
			try {
				var u = new URL( window.location.href );
				u.searchParams.delete( 'wk_place' );
				window.history.replaceState( null, '', u );
			} catch ( e ) {}
			if ( lastOpener && lastOpener.focus ) { lastOpener.focus(); }
		}

		/** A card lights up its pin on the map (when the pin is not inside a group). */
		function hot( i, on ) {
			var m = markers[ i ];
			if ( m && m._icon ) { m._icon.classList.toggle( 'is-hot', on ); if ( on ) { m.setZIndexOffset( 1000 ); } else { m.setZIndexOffset( 0 ); } }
		}

		// ---- events
		if ( dlg ) {
			dlg.querySelector( '.wk-pl__close' ).addEventListener( 'click', function () { if ( dlg.close ) { dlg.close(); } else { dlg.removeAttribute( 'open' ); closed(); } } );
			dlg.addEventListener( 'close', closed );
			dlg.addEventListener( 'click', function ( e ) { if ( e.target === dlg && dlg.close ) { dlg.close(); } } ); // Click on the backdrop.
		}
		items.forEach( function ( it ) {
			var i = +it.dataset.i;
			it.querySelector( '.wk-pl__card' ).addEventListener( 'click', function () { open( i, it.querySelector( '.wk-pl__open' ) ); } );
			it.addEventListener( 'mouseenter', function () { hot( i, true ); } );
			it.addEventListener( 'mouseleave', function () { hot( i, false ); } );
			it.addEventListener( 'focusin', function () { hot( i, true ); } );
			it.addEventListener( 'focusout', function () { hot( i, false ); } );
		} );
		var typing;
		if ( q ) { q.addEventListener( 'input', function () { clearTimeout( typing ); typing = setTimeout( function () { state.term = norm( q.value.trim() ); apply(); }, 120 ); } ); }
		pills.forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				var c = b.dataset.cat || '';
				if ( ! c ) { state.cats = []; } else {
					var k = state.cats.indexOf( c );
					if ( k > -1 ) { state.cats.splice( k, 1 ); } else { state.cats.push( c ); }
				}
				apply();
			} );
		} );
		if ( nearBtn ) { nearBtn.addEventListener( 'click', function () { locate( false ); } ); }
		if ( radiusSel ) { radiusSel.addEventListener( 'change', function () { state.radius = parseFloat( radiusSel.value ) || 0; apply(); } ); }
		if ( sortSel ) { sortSel.addEventListener( 'change', function () { state.sort = sortSel.value; apply(); } ); }
		if ( inmapBox ) { inmapBox.addEventListener( 'change', function () { state.inmap = inmapBox.checked; if ( state.inmap ) { makeMap(); } apply(); } ); }
		if ( resetBtn ) { resetBtn.addEventListener( 'click', reset ); }
		var reset2 = $( '.wk-pl__reset2' );
		if ( reset2 ) { reset2.addEventListener( 'click', reset ); }
		if ( pageBtn ) {
			pageBtn.addEventListener( 'click', function () {
				var first = state.shown;
				state.shown += perPage;
				apply( true, true );
				var next = items[ matches[ first ] ];
				if ( next ) { var b = next.querySelector( '.wk-pl__open' ); if ( b ) { b.focus( { preventScroll: true } ); } }
			} );
		}
		// "/" jumps to the search box (like many search sites), except while typing somewhere else.
		document.addEventListener( 'keydown', function ( e ) {
			if ( '/' !== e.key || ! q || e.ctrlKey || e.metaKey || e.altKey ) { return; }
			var a = document.activeElement;
			if ( a && ( /^(input|textarea|select)$/i.test( a.tagName ) || a.isContentEditable ) ) { return; }
			if ( ! root.getBoundingClientRect().height ) { return; }
			e.preventDefault();
			q.focus();
		} );

		// ---- start: query string, list, map when visible, deep link
		var params = new URLSearchParams( window.location.search );
		if ( q && params.get( 'wk_q' ) ) { q.value = params.get( 'wk_q' ); state.term = norm( q.value.trim() ); }
		if ( params.get( 'wk_cat' ) ) { state.cats = params.get( 'wk_cat' ).split( ',' ).filter( Boolean ); }
		syncTools();
		apply();
		if ( mapEl ) {
			if ( 'IntersectionObserver' in window ) {
				var io = new IntersectionObserver( function ( en ) { if ( en[ 0 ].isIntersecting ) { io.disconnect(); makeMap(); } }, { rootMargin: '200px' } );
				io.observe( mapEl );
			} else { makeMap(); }
		}
		// The "Categorías de lugares" widget asks to show a place of this finder.
		document.addEventListener( 'wakoo:place-open', function ( e ) {
			var slug = e.detail && e.detail.slug, i = -1;
			places.forEach( function ( p, n ) { if ( p.slug === slug ) { i = n; } } );
			if ( i < 0 ) { return; }
			root.scrollIntoView( { behavior: 'smooth', block: 'start' } );
			setTimeout( function () { open( i, null ); }, 450 );
		} );
		var deep = params.get( 'wk_place' );
		if ( deep ) {
			places.forEach( function ( p, i ) { if ( p.slug === deep ) { setTimeout( function () { open( i, null ); }, 150 ); } } );
		}
	}

	/** "Categorías de lugares": a drop-down; each category opens a popup with all its places. */
	function categories( root ) {
		if ( root.dataset.wkInit ) { return; }
		root.dataset.wkInit = '1';
		var d = {};
		try { d = JSON.parse( root.querySelector( '.wk-plc__data' ).textContent || '{}' ); } catch ( e ) {}
		var t = d.t || {}, sel = root.querySelector( '.wk-plc__select' ), dlg = root.querySelector( '.wk-plc__modal' );
		if ( ! sel || ! dlg ) { return; }
		var list = dlg.querySelector( '.wk-plc__list' ), filter = dlg.querySelector( '.wk-plc__filter' ), none = dlg.querySelector( '.wk-plc__none' );

		function mapUrl( slug ) {
			var base = d.page || window.location.pathname;
			return base + ( base.indexOf( '?' ) > -1 ? '&' : '?' ) + 'wk_place=' + encodeURIComponent( slug ) + '#lugares';
		}

		function show( slug ) {
			var c = ( d.cats || {} )[ slug ];
			if ( ! c ) { return; }
			dlg.querySelector( '.wk-plc__title' ).textContent = c.label;
			dlg.querySelector( '.wk-plc__count' ).textContent = 1 === c.items.length && t.count1 ? t.count1 : String( t.count || '{n}' ).replace( '{n}', c.items.length );
			list.textContent = '';
			filter.value = '';
			none.hidden = true;
			c.items.forEach( function ( p ) {
				var li = el( 'li', 'wk-plc__item' ), acts = el( 'div', 'wk-plc__acts' );
				li.dataset.q = norm( p.name + ' ' + p.address + ' ' + p.desc );
				li.appendChild( el( 'h3', 'wk-plc__name', p.name ) );
				if ( p.address ) { li.appendChild( el( 'p', 'wk-plc__addr', p.address ) ); }
				if ( p.desc ) { li.appendChild( el( 'p', 'wk-plc__desc', p.desc ) ); }
				if ( safeUrl( p.dir ) ) { acts.appendChild( link( p.dir, t.dir, 'wk-pl__btn--main', true ) ); }
				if ( p.phone ) { acts.appendChild( link( 'tel:' + String( p.phone ).replace( /[^0-9+]/g, '' ), t.call ) ); }
				if ( safeUrl( p.website ) ) { acts.appendChild( link( p.website, t.web, '', true ) ); }
				var m = link( mapUrl( p.slug ), t.map, '' );
				m.addEventListener( 'click', function ( e ) {
					// A finder on this same page shows the place without reloading.
					if ( document.querySelector( '.wk-pl__item[data-slug="' + p.slug + '"]' ) ) {
						e.preventDefault();
						dlg.close();
						document.dispatchEvent( new CustomEvent( 'wakoo:place-open', { detail: { slug: p.slug } } ) );
					}
				} );
				acts.appendChild( m );
				li.appendChild( acts );
				list.appendChild( li );
			} );
			if ( dlg.showModal ) { dlg.showModal(); } else { dlg.setAttribute( 'open', '' ); }
			document.documentElement.classList.add( 'wk-pl-lock' );
			filter.focus();
		}

		sel.addEventListener( 'change', function () { if ( sel.value ) { show( sel.value ); } } );
		dlg.addEventListener( 'close', function () { document.documentElement.classList.remove( 'wk-pl-lock' ); sel.value = ''; sel.focus(); } );
		dlg.querySelector( '.wk-plc__close' ).addEventListener( 'click', function () { if ( dlg.close ) { dlg.close(); } else { dlg.removeAttribute( 'open' ); } } );
		dlg.addEventListener( 'click', function ( e ) { if ( e.target === dlg && dlg.close ) { dlg.close(); } } );
		filter.addEventListener( 'input', function () {
			var q = norm( filter.value.trim() ), shown = 0;
			list.querySelectorAll( '.wk-plc__item' ).forEach( function ( li ) { var ok = ! q || li.dataset.q.indexOf( q ) > -1; li.hidden = ! ok; if ( ok ) { shown++; } } );
			none.hidden = shown > 0;
		} );
	}

	/** "Logos de lugares": arrows for the band; a logo opens the place in the finder of the same page. */
	function logos( root ) {
		if ( root.dataset.wkInit ) { return; }
		root.dataset.wkInit = '1';
		var track = root.querySelector( '.wk-pll__track' ), prev = root.querySelector( '.wk-pll__prev' ), next = root.querySelector( '.wk-pll__next' );
		function step( dir ) { track.scrollBy( { left: dir * Math.max( 200, track.clientWidth * 0.8 ), behavior: 'smooth' } ); }
		function arrows() {
			if ( ! prev ) { return; }
			prev.disabled = track.scrollLeft <= 2;
			next.disabled = track.scrollLeft + track.clientWidth >= track.scrollWidth - 2;
		}
		if ( prev ) {
			prev.addEventListener( 'click', function () { step( -1 ); } );
			next.addEventListener( 'click', function () { step( 1 ); } );
			track.addEventListener( 'scroll', arrows, { passive: true } );
			window.addEventListener( 'resize', arrows );
			arrows();
		}
		root.querySelectorAll( '.wk-pll__card' ).forEach( function ( a ) {
			a.addEventListener( 'click', function ( e ) {
				var slug = a.dataset.slug;
				if ( document.querySelector( '.wk-pl__item[data-slug="' + slug + '"]' ) ) {
					e.preventDefault();
					document.dispatchEvent( new CustomEvent( 'wakoo:place-open', { detail: { slug: slug } } ) );
				}
			} );
		} );
	}

	function boot( scope ) {
		( scope || document ).querySelectorAll( '.wk-pl' ).forEach( finder );
		( scope || document ).querySelectorAll( '.wk-plc' ).forEach( categories );
		( scope || document ).querySelectorAll( '.wk-pll' ).forEach( logos );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', function () { boot(); } );
	} else {
		boot();
	}
	if ( window.jQuery ) {
		jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend && elementorFrontend.hooks ) {
				elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-places.default', function ( $el ) { boot( $el[ 0 ] ); } );
				elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-places-cats.default', function ( $el ) { boot( $el[ 0 ] ); } );
				elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-places-logos.default', function ( $el ) { boot( $el[ 0 ] ); } );
			}
		} );
	}
}() );
