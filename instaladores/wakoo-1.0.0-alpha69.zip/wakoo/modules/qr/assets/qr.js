( function () {
	'use strict';
	function esc( s ) { return String( s ).replace( /[^#a-zA-Z0-9(),.%\- ]/g, '' ); }

	function svgOf( cfg ) {
		var q = qrcode( 0, cfg.ecc );
		q.addData( cfg.data || ' ', 'Byte' );
		q.make();
		var n = q.getModuleCount(), m = 4, total = n + m * 2, path = '';
		for ( var r = 0; r < n; r++ ) {
			for ( var c = 0; c < n; c++ ) {
				if ( q.isDark( r, c ) ) { path += 'M' + ( c + m ) + ' ' + ( r + m ) + 'h1v1h-1z'; }
			}
		}
		var fg = esc( cfg.fg ), bg = esc( cfg.bg );
		return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + total + ' ' + total + '" width="' + cfg.size + '" height="' + cfg.size + '" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="' + bg + '"/><path d="' + path + '" fill="' + fg + '"/></svg>';
	}

	function save( blob, name ) {
		var a = document.createElement( 'a' );
		a.href = URL.createObjectURL( blob ); a.download = name;
		document.body.appendChild( a ); a.click();
		setTimeout( function () { URL.revokeObjectURL( a.href ); a.remove(); }, 500 );
	}

	function init( root ) {
		if ( root.dataset.wakooInit ) { return; }
		root.dataset.wakooInit = '1';
		var cfg; try { cfg = JSON.parse( root.getAttribute( 'data-wakoo' ) || '{}' ); } catch ( e ) { return; }
		var box = root.querySelector( '.wakoo-qr__code' ), svg;
		try { svg = svgOf( cfg ); } catch ( e ) { box.textContent = '—'; return; }
		box.innerHTML = svg;
		Array.prototype.forEach.call( root.querySelectorAll( '.wakoo-qr__dl button' ), function ( b ) {
			b.addEventListener( 'click', function () {
				if ( 'svg' === b.getAttribute( 'data-f' ) ) { save( new Blob( [ svg ], { type: 'image/svg+xml' } ), 'qr.svg' ); return; }
				var img = new Image(), px = Math.max( cfg.size, 600 );
				img.onload = function () {
					var cv = document.createElement( 'canvas' ); cv.width = cv.height = px;
					var cx = cv.getContext( '2d' ); cx.imageSmoothingEnabled = false; cx.drawImage( img, 0, 0, px, px );
					cv.toBlob( function ( bl ) { save( bl, 'qr.png' ); }, 'image/png' );
				};
				img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent( svg );
			} );
		} );
	}
	function boot( scope ) { ( scope && scope.querySelectorAll ? scope : document ).querySelectorAll( '.wakoo-qr' ).forEach( init ); }
	if ( 'loading' === document.readyState ) { document.addEventListener( 'DOMContentLoaded', function () { boot( document ); } ); } else { boot( document ); }
	if ( window.jQuery ) {
		window.jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend && window.elementorFrontend.hooks ) {
				window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-qr.default', function ( $s ) { boot( $s[ 0 ] ); } );
			}
		} );
	}
}() );
