<?php
/**
 * Wakoo QR widget.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\QR;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Widget extends Widget_Base {

	public function get_name() { return 'wakoo-qr'; }
	public function get_title() { return __( 'Código QR (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-barcode'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'qr', 'codigo', 'wifi', 'whatsapp', 'vcard', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-qr' ]; }
	public function get_style_depends() { return [ 'wakoo-qr' ]; }

	protected function register_controls() {

		$this->start_controls_section( 'sec_data', [ 'label' => __( 'Contenido', 'wakoo' ) ] );
		$this->add_control( 'kind', [
			'label'   => __( 'Tipo', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'url',
			'options' => [
				'url'      => __( 'Enlace o texto', 'wakoo' ),
				'wifi'     => __( 'WiFi', 'wakoo' ),
				'email'    => __( 'Email', 'wakoo' ),
				'phone'    => __( 'Teléfono', 'wakoo' ),
				'whatsapp' => __( 'WhatsApp', 'wakoo' ),
				'vcard'    => __( 'Tarjeta de contacto', 'wakoo' ),
			],
		] );
		$this->add_control( 'url', [ 'label' => __( 'Enlace o texto', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'default' => home_url( '/' ), 'condition' => [ 'kind' => 'url' ] ] );
		$this->add_control( 'ssid', [ 'label' => __( 'Nombre de la red', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'condition' => [ 'kind' => 'wifi' ] ] );
		$this->add_control( 'wifi_pass', [ 'label' => __( 'Contraseña', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'condition' => [ 'kind' => 'wifi' ] ] );
		$this->add_control( 'wifi_sec', [ 'label' => __( 'Seguridad', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'WPA', 'options' => [ 'WPA' => 'WPA/WPA2', 'WEP' => 'WEP', 'nopass' => __( 'Sin contraseña', 'wakoo' ) ], 'condition' => [ 'kind' => 'wifi' ] ] );
		$this->add_control( 'email', [ 'label' => __( 'Email', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'condition' => [ 'kind' => [ 'email', 'vcard' ] ] ] );
		$this->add_control( 'subject', [ 'label' => __( 'Asunto', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'condition' => [ 'kind' => 'email' ] ] );
		$this->add_control( 'phone', [ 'label' => __( 'Teléfono (con prefijo, ej. +34600000000)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'condition' => [ 'kind' => [ 'phone', 'whatsapp', 'vcard' ] ] ] );
		$this->add_control( 'wa_text', [ 'label' => __( 'Mensaje inicial', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'condition' => [ 'kind' => 'whatsapp' ] ] );
		$this->add_control( 'v_name', [ 'label' => __( 'Nombre', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'condition' => [ 'kind' => 'vcard' ] ] );
		$this->add_control( 'v_org', [ 'label' => __( 'Empresa', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'condition' => [ 'kind' => 'vcard' ] ] );
		$this->add_control( 'v_url', [ 'label' => __( 'Web', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'condition' => [ 'kind' => 'vcard' ] ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_look', [ 'label' => __( 'Aspecto', 'wakoo' ) ] );
		$this->add_control( 'size', [ 'label' => __( 'Tamaño (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 240, 'min' => 80, 'max' => 800 ] );
		$this->add_control( 'fg', [ 'label' => __( 'Color del código', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#111111' ] );
		$this->add_control( 'bg', [ 'label' => __( 'Fondo', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#FFFFFF' ] );
		$this->add_control( 'ecc', [ 'label' => __( 'Corrección de errores', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'M', 'options' => [ 'L' => 'L (7%)', 'M' => 'M (15%)', 'Q' => 'Q (25%)', 'H' => 'H (30%)' ] ] );
		$this->add_control( 'align', [ 'label' => __( 'Alineación', 'wakoo' ), 'type' => Controls_Manager::CHOOSE, 'options' => [ 'left' => [ 'title' => 'L', 'icon' => 'eicon-text-align-left' ], 'center' => [ 'title' => 'C', 'icon' => 'eicon-text-align-center' ], 'right' => [ 'title' => 'R', 'icon' => 'eicon-text-align-right' ] ], 'default' => 'center', 'selectors' => [ '{{WRAPPER}} .wakoo-qr' => 'text-align: {{VALUE}};' ] ] );
		$this->add_control( 'download', [ 'label' => __( 'Botones de descarga', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();
	}

	/** Escape the special characters of the WiFi QR format. */
	private function wifi_esc( $v ) {
		return preg_replace( '/([\\\;,:"])/', '\\\\$1', (string) $v );
	}

	private function payload( array $s ) {
		switch ( $s['kind'] ?? 'url' ) {
			case 'wifi':
				$sec = in_array( $s['wifi_sec'], [ 'WPA', 'WEP', 'nopass' ], true ) ? $s['wifi_sec'] : 'WPA';
				return 'WIFI:T:' . $sec . ';S:' . $this->wifi_esc( $s['ssid'] ) . ';' . ( 'nopass' === $sec ? '' : 'P:' . $this->wifi_esc( $s['wifi_pass'] ) . ';' ) . ';';
			case 'email':
				return 'mailto:' . trim( (string) $s['email'] ) . ( ! empty( $s['subject'] ) ? '?subject=' . rawurlencode( $s['subject'] ) : '' );
			case 'phone':
				return 'tel:' . preg_replace( '/[^0-9+]/', '', (string) $s['phone'] );
			case 'whatsapp':
				return 'https://wa.me/' . preg_replace( '/\D/', '', (string) $s['phone'] ) . ( ! empty( $s['wa_text'] ) ? '?text=' . rawurlencode( $s['wa_text'] ) : '' );
			case 'vcard':
				$v = static function ( $t ) { return str_replace( [ "\r", "\n", ',', ';' ], [ '', ' ', '\,', '\;' ], (string) $t ); };
				return "BEGIN:VCARD\nVERSION:3.0\nFN:" . $v( $s['v_name'] ) . "\n" . ( $s['v_org'] ? 'ORG:' . $v( $s['v_org'] ) . "\n" : '' ) . ( $s['phone'] ? 'TEL:' . $v( $s['phone'] ) . "\n" : '' ) . ( $s['email'] ? 'EMAIL:' . $v( $s['email'] ) . "\n" : '' ) . ( $s['v_url'] ? 'URL:' . $v( $s['v_url'] ) . "\n" : '' ) . 'END:VCARD';
			default:
				return (string) $s['url'];
		}
	}

	protected function render() {
		$s   = $this->get_settings_for_display();
		$cfg = [
			'data' => $this->payload( $s ),
			'size' => max( 80, (int) $s['size'] ),
			'fg'   => $s['fg'] ?: '#111111',
			'bg'   => $s['bg'] ?: '#FFFFFF',
			'ecc'  => in_array( $s['ecc'], [ 'L', 'M', 'Q', 'H' ], true ) ? $s['ecc'] : 'M',
		];
		echo '<div class="wakoo-qr" data-wakoo="' . esc_attr( wp_json_encode( $cfg ) ) . '"><div class="wakoo-qr__code" role="img" aria-label="' . esc_attr__( 'Código QR', 'wakoo' ) . '"></div>';
		if ( 'yes' === ( $s['download'] ?? '' ) ) {
			echo '<div class="wakoo-qr__dl"><button type="button" data-f="png">PNG</button><button type="button" data-f="svg">SVG</button></div>';
		}
		echo '</div>';
	}
}
