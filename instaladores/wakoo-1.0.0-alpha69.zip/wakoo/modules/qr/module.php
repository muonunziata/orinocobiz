<?php
/**
 * Wakoo QR: a QR code generator widget (URL, text, WiFi, email, phone,
 * WhatsApp, contact card). Drawn in the visitor's browser with a bundled MIT
 * library; no external service. Downloadable as SVG and PNG.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\QR;

defined( 'ABSPATH' ) || die();

class Module {

	public static function init() {
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_action( 'elementor/frontend/after_register_scripts', function () {
			wp_register_script( 'wakoo-qrlib', WAKOO_MODULES_URL . 'qr/assets/vendor/qrcode.js', [], '2.0.4', true );
			wp_register_script( 'wakoo-qr', WAKOO_MODULES_URL . 'qr/assets/qr.js', [ 'wakoo-qrlib' ], WAKOO_VERSION, true );
		} );
		add_action( 'elementor/frontend/after_register_styles', function () {
			wp_register_style( 'wakoo-qr', WAKOO_MODULES_URL . 'qr/assets/qr.css', [], WAKOO_VERSION );
		} );
	}

	public static function register_widget( $wm ) {
		require_once __DIR__ . '/widget.php';
		$wm->register( new Widget() );
	}
}

Module::init();
