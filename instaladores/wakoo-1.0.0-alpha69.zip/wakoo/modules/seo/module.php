<?php
/**
 * Wakoo SEO + Analytics.
 *
 * A single hub page (Wakoo → SEO) that:
 *  - injects Google Analytics 4 from a measurement ID (gtag.js),
 *  - outputs meta description, canonical, Open Graph and Twitter Card tags and a
 *    JSON-LD WebSite/Organization block on the frontend,
 *  - offers an "Optimizar SEO ahora" button that fills a missing SEO title and
 *    description for every published page/post from its own content.
 *
 * Per-post overrides live in `_wakoo_seo_title` / `_wakoo_seo_desc`.
 *
 * Note: Google does not allow creating an Analytics account from a plugin, so
 * Wakoo takes the GA4 measurement ID (G-XXXXXXXXXX) and wires it up automatically.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Seo;

defined( 'ABSPATH' ) || die();

class Module {

	const OPTION = 'wakoo_seo_options';
	const T_META = '_wakoo_seo_title';
	const D_META = '_wakoo_seo_desc';

	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ] );
		add_action( 'admin_init', [ __CLASS__, 'register_settings' ] );
		add_action( 'admin_post_wakoo_seo_auto', [ __CLASS__, 'run_auto' ] );
		add_action( 'wp_head', [ __CLASS__, 'head' ], 1 );
		add_action( 'init', [ __CLASS__, 'ads_txt' ], 0 );
		// AI search engines: /llms.txt (a Markdown guide to the site) and a robots.txt that welcomes their crawlers.
		add_action( 'init', [ __CLASS__, 'llms_txt' ], 99 ); // After every post type (places too) is registered.
		add_filter( 'robots_txt', [ __CLASS__, 'robots' ], 20, 2 );
		add_action( 'save_post', function () { delete_transient( 'wakoo_llms_txt' ); } );
		// Avoid a duplicate canonical: we output our own when meta tags are on.
		$o = self::opts();
		if ( $o['meta_desc'] ) {
			remove_action( 'wp_head', 'rel_canonical' );
		}
		// Per-post SEO fields.
		add_action( 'add_meta_boxes', [ __CLASS__, 'meta_box' ] );
		add_action( 'save_post', [ __CLASS__, 'save_meta' ] );
	}

	public static function opts() {
		return wp_parse_args( (array) get_option( self::OPTION, [] ), [
			'ga4_id'    => '',
			'meta_desc' => 1,
			'og'        => 1,
			'twitter'   => 1,
			'jsonld'    => 1,
			'org_name'  => get_bloginfo( 'name' ),
			'ga_admins' => 0, // track logged-in admins too
			'ga_consent' => 0, // wait for the Wakoo cookies widget (analytics category)
			// Google consent / Ads / AdSense (alpha45). consent_mode: off | basic (tags load after consent) | advanced (load at once, denied by default).
			'consent_mode'   => '',
			'consent_region' => 'all', // all | eu: in advanced mode, deny by default only in the EEA, UK and Switzerland.
			'ads_id'         => '',    // AW-XXXXXXXXX
			'ads_conv'       => '',    // AW-XXXXXXXXX/label fired after a membership application
			'adsense_client' => '',    // ca-pub-XXXXXXXXXXXXXXXX
			'adsense_unit'   => '',    // default ad unit for Wakoo ad spaces
			'ads_txt_extra'  => '',
			'llms'           => 1, // /llms.txt for AI assistants (ChatGPT, Claude, Perplexity, Gemini…)
			'ai_bots'        => 1, // robots.txt: allow the AI search crawlers and point to the sitemap and llms.txt
		] );
	}

	/** Consent mode in effect (sites saved before alpha45 keep their old "wait for consent" choice). */
	public static function consent_mode() {
		$o = self::opts();
		if ( in_array( $o['consent_mode'], [ 'off', 'basic', 'advanced' ], true ) ) {
			return $o['consent_mode'];
		}
		return $o['ga_consent'] ? 'basic' : 'off';
	}

	/** EEA + UK + Switzerland (ISO 3166-1), for region-specific consent defaults. */
	const EEA = [ 'AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IS', 'IE', 'IT', 'LV', 'LI', 'LT', 'LU', 'MT', 'NL', 'NO', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE', 'GB', 'CH' ];

	/* ---------------- admin hub ---------------- */

	public static function menu() {
		add_menu_page( __( 'Wakoo SEO', 'wakoo' ), __( 'Wakoo SEO', 'wakoo' ), 'manage_options', 'wakoo-seo', [ __CLASS__, 'page' ], 'dashicons-chart-area', 59 );
	}

	public static function register_settings() {
		register_setting( 'wakoo_seo_group', self::OPTION, [ __CLASS__, 'sanitize' ] );
	}

	public static function sanitize( $in ) {
		$in = (array) $in;
		return [
			'ga4_id'    => preg_replace( '/[^A-Z0-9\-]/', '', strtoupper( (string) ( $in['ga4_id'] ?? '' ) ) ),
			'meta_desc' => empty( $in['meta_desc'] ) ? 0 : 1,
			'og'        => empty( $in['og'] ) ? 0 : 1,
			'twitter'   => empty( $in['twitter'] ) ? 0 : 1,
			'jsonld'    => empty( $in['jsonld'] ) ? 0 : 1,
			'org_name'  => sanitize_text_field( (string) ( $in['org_name'] ?? '' ) ),
			'ga_admins' => empty( $in['ga_admins'] ) ? 0 : 1,
			'ga_consent' => empty( $in['ga_consent'] ) ? 0 : 1,
			'consent_mode'   => in_array( $in['consent_mode'] ?? '', [ 'off', 'basic', 'advanced' ], true ) ? $in['consent_mode'] : 'basic',
			'consent_region' => 'eu' === ( $in['consent_region'] ?? '' ) ? 'eu' : 'all',
			'ads_id'         => preg_match( '/^AW-\d{6,15}$/', strtoupper( trim( (string) ( $in['ads_id'] ?? '' ) ) ) ) ? strtoupper( trim( $in['ads_id'] ) ) : '',
			'ads_conv'       => preg_match( '#^AW-\d{6,15}/[A-Za-z0-9_\-]{4,40}$#', trim( (string) ( $in['ads_conv'] ?? '' ) ) ) ? trim( $in['ads_conv'] ) : '',
			'adsense_client' => self::clean_client( (string) ( $in['adsense_client'] ?? '' ) ),
			'adsense_unit'   => preg_replace( '/\D/', '', (string) ( $in['adsense_unit'] ?? '' ) ),
			'ads_txt_extra'  => sanitize_textarea_field( (string) ( $in['ads_txt_extra'] ?? '' ) ),
			'llms'           => empty( $in['llms'] ) ? 0 : 1,
			'ai_bots'        => empty( $in['ai_bots'] ) ? 0 : 1,
		];
	}

	/** Accepts "pub-123…" or "ca-pub-123…" (16 digits) and returns "ca-pub-…", or ''. */
	public static function clean_client( $v ) {
		return preg_match( '/(?:ca-)?pub-(\d{16})/', $v, $m ) ? 'ca-pub-' . $m[1] : '';
	}

	public static function page() {
		$o = self::opts();
		$done = isset( $_GET['wakoo_seo_done'] ) ? (int) $_GET['wakoo_seo_done'] : -1; // phpcs:ignore WordPress.Security.NonceVerification
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Wakoo SEO y Analítica', 'wakoo' ); ?></h1>
			<?php if ( $done >= 0 ) : ?>
				<div class="notice notice-success is-dismissible"><p>
					<?php printf( esc_html__( 'Optimización completada: %d entradas actualizadas.', 'wakoo' ), (int) $done ); ?>
				</p></div>
			<?php endif; ?>

			<form method="post" action="options.php">
				<?php settings_fields( 'wakoo_seo_group' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="wk_ga4"><?php esc_html_e( 'ID de medición GA4', 'wakoo' ); ?></label></th>
						<td>
							<input name="<?php echo esc_attr( self::OPTION ); ?>[ga4_id]" id="wk_ga4" type="text" class="regular-text" placeholder="G-XXXXXXXXXX" value="<?php echo esc_attr( $o['ga4_id'] ); ?>">
							<p class="description"><?php esc_html_e( 'Pégalo desde Google Analytics (Administrar → Flujos de datos). Wakoo inyecta el seguimiento automáticamente.', 'wakoo' ); ?>
							<a href="https://analytics.google.com/" target="_blank" rel="noopener">analytics.google.com</a></p>
							<label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[ga_admins]" value="1" <?php checked( $o['ga_admins'], 1 ); ?>> <?php esc_html_e( 'Contar también a administradores conectados', 'wakoo' ); ?></label>
							<input type="hidden" name="<?php echo esc_attr( self::OPTION ); ?>[ga_consent]" value="<?php echo (int) $o['ga_consent']; ?>">
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Etiquetas SEO', 'wakoo' ); ?></th>
						<td>
							<label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[meta_desc]" value="1" <?php checked( $o['meta_desc'], 1 ); ?>> <?php esc_html_e( 'Meta descripción + canonical', 'wakoo' ); ?></label><br>
							<label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[og]" value="1" <?php checked( $o['og'], 1 ); ?>> <?php esc_html_e( 'Open Graph (Facebook, WhatsApp…)', 'wakoo' ); ?></label><br>
							<label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[twitter]" value="1" <?php checked( $o['twitter'], 1 ); ?>> <?php esc_html_e( 'Twitter Card', 'wakoo' ); ?></label><br>
							<label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[jsonld]" value="1" <?php checked( $o['jsonld'], 1 ); ?>> <?php esc_html_e( 'Datos estructurados JSON-LD', 'wakoo' ); ?></label>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Buscadores con IA', 'wakoo' ); ?></th>
						<td>
							<label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[llms]" value="1" <?php checked( $o['llms'], 1 ); ?>> <?php esc_html_e( 'Publicar /llms.txt: una guía del sitio en Markdown (páginas por idioma, noticias y lugares) para ChatGPT, Claude, Perplexity, Gemini y otros asistentes', 'wakoo' ); ?></label>
							<?php if ( $o['llms'] ) : ?> · <a href="<?php echo esc_url( home_url( '/llms.txt' ) ); ?>" target="_blank" rel="noopener">llms.txt</a><?php endif; ?><br>
							<label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[ai_bots]" value="1" <?php checked( $o['ai_bots'], 1 ); ?>> <?php esc_html_e( 'robots.txt: permitir los rastreadores de los buscadores con IA (OpenAI, Anthropic, Perplexity, Google, Apple) y anunciar el sitemap y llms.txt', 'wakoo' ); ?></label>
							<p class="description"><?php esc_html_e( 'Los datos estructurados (JSON-LD) describen cada página, su idioma, su imagen y su ruta, y los lugares, preguntas frecuentes y ofertas de empleo: es lo que leen Google y los asistentes con IA para citarte.', 'wakoo' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="wk_org"><?php esc_html_e( 'Nombre de la organización', 'wakoo' ); ?></label></th>
						<td><input name="<?php echo esc_attr( self::OPTION ); ?>[org_name]" id="wk_org" type="text" class="regular-text" value="<?php echo esc_attr( $o['org_name'] ); ?>"></td>
					</tr>
					<?php $cm = self::consent_mode(); ?>
					<tr>
						<th scope="row"><?php esc_html_e( 'Consentimiento (Google Consent Mode v2)', 'wakoo' ); ?></th>
						<td>
							<fieldset>
								<label><input type="radio" name="<?php echo esc_attr( self::OPTION ); ?>[consent_mode]" value="basic" <?php checked( $cm, 'basic' ); ?>> <strong><?php esc_html_e( 'Básico (recomendado):', 'wakoo' ); ?></strong> <?php esc_html_e( 'las etiquetas de Google se cargan solo cuando el visitante acepta analítica o marketing en el widget Cookies de Wakoo; AdSense, solo con marketing.', 'wakoo' ); ?></label><br>
								<label><input type="radio" name="<?php echo esc_attr( self::OPTION ); ?>[consent_mode]" value="advanced" <?php checked( $cm, 'advanced' ); ?>> <strong><?php esc_html_e( 'Avanzado:', 'wakoo' ); ?></strong> <?php esc_html_e( 'se cargan siempre con el consentimiento denegado por defecto (Google modela las conversiones sin cookies) y se actualizan cuando el visitante elige.', 'wakoo' ); ?></label><br>
								<label><input type="radio" name="<?php echo esc_attr( self::OPTION ); ?>[consent_mode]" value="off" <?php checked( $cm, 'off' ); ?>> <?php esc_html_e( 'Desactivado: las etiquetas se cargan siempre, sin señales de consentimiento.', 'wakoo' ); ?></label>
							</fieldset>
							<p><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>[consent_region]" value="eu" <?php checked( $o['consent_region'], 'eu' ); ?>> <?php esc_html_e( 'En modo avanzado, denegar por defecto solo en el Espacio Económico Europeo, Reino Unido y Suiza', 'wakoo' ); ?></label></p>
							<p class="description"><?php esc_html_e( 'Pon el widget «Consentimiento de cookies (Wakoo)» en el pie global. Sus categorías Analítica y Marketing se traducen a analytics_storage y ad_storage / ad_user_data / ad_personalization.', 'wakoo' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="wk_aw"><?php esc_html_e( 'Google Ads', 'wakoo' ); ?></label></th>
						<td>
							<input name="<?php echo esc_attr( self::OPTION ); ?>[ads_id]" id="wk_aw" type="text" class="regular-text" placeholder="AW-123456789" value="<?php echo esc_attr( $o['ads_id'] ); ?>">
							<p class="description"><?php esc_html_e( 'ID de la etiqueta de Google Ads (Objetivos → Conversiones → Configuración de la etiqueta de Google).', 'wakoo' ); ?> <a href="https://ads.google.com/" target="_blank" rel="noopener">ads.google.com</a></p>
							<p><label for="wk_awc"><?php esc_html_e( 'Conversión «solicitud de membresía enviada» (ID/etiqueta):', 'wakoo' ); ?></label><br>
							<input name="<?php echo esc_attr( self::OPTION ); ?>[ads_conv]" id="wk_awc" type="text" class="regular-text" placeholder="AW-123456789/AbCdEfGhIj" value="<?php echo esc_attr( $o['ads_conv'] ); ?>"></p>
							<p class="description"><?php esc_html_e( 'También cuenta como conversión cualquier clic en un elemento con la clase «wakoo-conversion».', 'wakoo' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="wk_ca"><?php esc_html_e( 'Google AdSense', 'wakoo' ); ?></label></th>
						<td>
							<input name="<?php echo esc_attr( self::OPTION ); ?>[adsense_client]" id="wk_ca" type="text" class="regular-text" placeholder="ca-pub-0000000000000000" value="<?php echo esc_attr( $o['adsense_client'] ); ?>">
							<p class="description"><?php esc_html_e( 'ID de editor (AdSense → Cuenta → Información de la cuenta). Wakoo añade el código de AdSense a todas las páginas (los anuncios automáticos se activan desde AdSense) y publica /ads.txt.', 'wakoo' ); ?> <a href="https://adsense.google.com/" target="_blank" rel="noopener">adsense.google.com</a></p>
							<p><label for="wk_cu"><?php esc_html_e( 'Unidad de anuncio para los espacios publicitarios de Wakoo (data-ad-slot):', 'wakoo' ); ?></label><br>
							<input name="<?php echo esc_attr( self::OPTION ); ?>[adsense_unit]" id="wk_cu" type="text" class="regular-text" placeholder="1234567890" value="<?php echo esc_attr( $o['adsense_unit'] ); ?>"></p>
							<p class="description"><?php esc_html_e( 'Los widgets «Espacio publicitario (Wakoo)» con «Usar AdSense si no hay anuncio de miembro» muestran esta unidad cuando no hay ningún anuncio propio en rotación.', 'wakoo' ); ?></p>
							<p><label for="wk_atx"><?php esc_html_e( 'Líneas extra de ads.txt (otras redes):', 'wakoo' ); ?></label><br>
							<textarea name="<?php echo esc_attr( self::OPTION ); ?>[ads_txt_extra]" id="wk_atx" rows="3" class="large-text code"><?php echo esc_textarea( $o['ads_txt_extra'] ); ?></textarea></p>
							<p class="description"><?php esc_html_e( 'Visitantes del EEE, Reino Unido y Suiza: Google exige una plataforma de consentimiento certificada (TCF) para servir AdSense. Activa «Privacidad y mensajes» en tu cuenta de AdSense para esas regiones.', 'wakoo' ); ?></p>
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>

			<hr>
			<h2><?php esc_html_e( 'Optimización automática', 'wakoo' ); ?></h2>
			<p><?php esc_html_e( 'Rellena el título y la meta descripción que falten en todas las páginas y entradas publicadas, usando su propio contenido. No sobrescribe lo que ya tengas.', 'wakoo' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="wakoo_seo_auto">
				<?php wp_nonce_field( 'wakoo_seo_auto' ); ?>
				<?php submit_button( __( 'Optimizar SEO ahora (Auto)', 'wakoo' ), 'primary', 'submit', false ); ?>
			</form>
		</div>
		<?php
	}

	/* ---------------- auto optimizer ---------------- */

	public static function run_auto() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'wakoo_seo_auto' ) ) {
			wp_die( esc_html__( 'No autorizado', 'wakoo' ) );
		}
		$posts = get_posts( [
			'post_type'      => [ 'post', 'page' ],
			'post_status'    => 'publish',
			'posts_per_page' => 500,
			'no_found_rows'  => true,
			'fields'         => 'ids',
		] );
		$count = 0;
		foreach ( $posts as $pid ) {
			$changed = false;
			if ( '' === (string) get_post_meta( $pid, self::T_META, true ) ) {
				update_post_meta( $pid, self::T_META, self::derive_title( $pid ) );
				$changed = true;
			}
			if ( '' === (string) get_post_meta( $pid, self::D_META, true ) ) {
				update_post_meta( $pid, self::D_META, self::derive_desc( $pid ) );
				$changed = true;
			}
			if ( $changed ) {
				$count++;
			}
		}
		wp_safe_redirect( add_query_arg( [ 'page' => 'wakoo-seo', 'wakoo_seo_done' => $count ], admin_url( 'admin.php' ) ) );
		exit;
	}

	private static function derive_title( $pid ) {
		return wp_strip_all_tags( get_the_title( $pid ) ) . ' – ' . get_bloginfo( 'name' );
	}

	private static function derive_desc( $pid ) {
		$post = get_post( $pid );
		if ( ! $post ) {
			return '';
		}
		$raw = $post->post_excerpt ? $post->post_excerpt : $post->post_content;
		// Elementor stores content in meta; fall back to a rendered excerpt.
		if ( '' === trim( wp_strip_all_tags( $raw ) ) && class_exists( '\Elementor\Plugin' ) ) {
			$raw = \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $pid );
		}
		$text = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( strip_shortcodes( $raw ) ) ) );
		if ( mb_strlen( $text ) > 155 ) {
			$text = mb_substr( $text, 0, 152 ) . '…';
		}
		return $text;
	}

	/* ---------------- per-post box ---------------- */

	public static function meta_box() {
		foreach ( [ 'post', 'page' ] as $pt ) {
			add_meta_box( 'wakoo_seo_box', __( 'Wakoo SEO', 'wakoo' ), [ __CLASS__, 'box_html' ], $pt, 'normal', 'low' );
		}
	}

	public static function box_html( $post ) {
		wp_nonce_field( 'wakoo_seo_box', 'wakoo_seo_box_nonce' );
		$t = get_post_meta( $post->ID, self::T_META, true );
		$d = get_post_meta( $post->ID, self::D_META, true );
		echo '<p><label><strong>' . esc_html__( 'Título SEO', 'wakoo' ) . '</strong></label><br>';
		echo '<input type="text" name="wakoo_seo_title" style="width:100%" value="' . esc_attr( $t ) . '"></p>';
		echo '<p><label><strong>' . esc_html__( 'Meta descripción', 'wakoo' ) . '</strong></label><br>';
		echo '<textarea name="wakoo_seo_desc" rows="3" style="width:100%">' . esc_textarea( $d ) . '</textarea></p>';
	}

	public static function save_meta( $pid ) {
		if ( ! isset( $_POST['wakoo_seo_box_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['wakoo_seo_box_nonce'] ), 'wakoo_seo_box' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $pid ) ) {
			return;
		}
		if ( isset( $_POST['wakoo_seo_title'] ) ) {
			update_post_meta( $pid, self::T_META, sanitize_text_field( wp_unslash( $_POST['wakoo_seo_title'] ) ) );
		}
		if ( isset( $_POST['wakoo_seo_desc'] ) ) {
			update_post_meta( $pid, self::D_META, sanitize_textarea_field( wp_unslash( $_POST['wakoo_seo_desc'] ) ) );
		}
	}

	/* ---------------- frontend head ---------------- */

	public static function head() {
		$o = self::opts();

		// Google tag (GA4 + Google Ads) with Consent Mode, and AdSense.
		self::google_tags( $o );

		if ( ! is_singular() ) {
			if ( $o['jsonld'] ) {
				self::jsonld( $o );
			}
			return;
		}

		$pid   = get_queried_object_id();
		$title = (string) get_post_meta( $pid, self::T_META, true );
		$desc  = (string) get_post_meta( $pid, self::D_META, true );
		if ( '' === $desc ) {
			$desc = self::derive_desc( $pid );
		}
		$url   = get_permalink( $pid );
		$image = self::image_of( $pid );

		if ( $o['meta_desc'] && $desc ) {
			echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
			echo '<link rel="canonical" href="' . esc_url( $url ) . '">' . "\n";
		}
		$og_title = $title ? $title : get_the_title( $pid );
		if ( $o['og'] ) {
			echo '<meta property="og:type" content="' . ( is_front_page() || 'page' === get_post_type( $pid ) ? 'website' : 'article' ) . '">' . "\n";
			$loc = self::lang_tag( $pid );
			// Facebook wants language_TERRITORY (en_US): add the usual territory when the tag has none.
			$terr = [ 'en' => 'en_US', 'es' => 'es_ES', 'fr' => 'fr_FR', 'it' => 'it_IT', 'de' => 'de_DE', 'pt' => 'pt_BR', 'nl' => 'nl_NL', 'zh' => 'zh_CN' ];
			$loc  = str_replace( '-', '_', $loc );
			$loc  = false === strpos( $loc, '_' ) ? ( $terr[ strtolower( $loc ) ] ?? $loc ) : $loc;
			if ( $loc ) { echo '<meta property="og:locale" content="' . esc_attr( $loc ) . '">' . "\n"; }
			echo '<meta property="og:title" content="' . esc_attr( $og_title ) . '">' . "\n";
			echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
			if ( $desc ) { echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n"; }
			if ( $image ) { echo '<meta property="og:image" content="' . esc_url( $image ) . '">' . "\n"; }
			echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . "\n";
		}
		if ( $o['twitter'] ) {
			echo '<meta name="twitter:card" content="' . ( $image ? 'summary_large_image' : 'summary' ) . '">' . "\n";
			echo '<meta name="twitter:title" content="' . esc_attr( $og_title ) . '">' . "\n";
			if ( $desc ) { echo '<meta name="twitter:description" content="' . esc_attr( $desc ) . '">' . "\n"; }
			if ( $image ) { echo '<meta name="twitter:image" content="' . esc_url( $image ) . '">' . "\n"; }
		}
		if ( $o['jsonld'] ) {
			self::jsonld( $o );
		}
	}

	/**
	 * Google tag (one gtag.js for GA4 and Google Ads) with Consent Mode v2 fed by
	 * the Wakoo cookies widget, plus the AdSense code.
	 *
	 * - Defaults come from the visitor's saved choice (cookie `wakoo_consent`), else
	 *   denied (in "eu" region mode: denied only in the EEA/UK/CH).
	 * - basic: gtag.js is injected once the visitor grants analytics or marketing;
	 *   advanced / off: right away. Every later choice sends a consent update.
	 * - AdSense: in basic mode it waits for marketing; otherwise it loads at once and
	 *   asks for non-personalised ads while marketing is not granted.
	 */
	private static function google_tags( $o ) {
		$mode   = self::consent_mode();
		$track  = $o['ga_admins'] || ! current_user_can( 'manage_options' );
		$ga     = $track ? $o['ga4_id'] : '';
		$aw     = $track ? $o['ads_id'] : '';
		$client = $o['adsense_client'];
		if ( ! $ga && ! $aw && ! $client ) {
			return;
		}
		$cfg = [
			'mode'   => $mode,
			'region' => 'eu' === $o['consent_region'] ? self::EEA : [],
			'ids'    => array_values( array_filter( [ $ga, $aw ] ) ),
			'conv'   => $aw ? $o['ads_conv'] : '',
		];
		echo "\n<!-- Wakoo: Google tag + Consent Mode v2 -->\n<script>";
		echo 'window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}';
		echo '(function(w,d,C){var c=null;try{var m=d.cookie.match(/(?:^|; )wakoo_consent=([^;]*)/);c=m?JSON.parse(decodeURIComponent(m[1])).c:null;}catch(e){}';
		echo 'function st(x){x=x||{};var a=x.analytics?"granted":"denied",k=x.marketing?"granted":"denied";return{ad_storage:k,ad_user_data:k,ad_personalization:k,analytics_storage:a};}';
		echo 'if("off"!==C.mode){if(c){gtag("consent","default",st(c));}else if(C.region.length){var g=st({analytics:1,marketing:1});gtag("consent","default",g);var r=st({});r.region=C.region;r.wait_for_update=500;gtag("consent","default",r);}else{var x=st({});x.wait_for_update=500;gtag("consent","default",x);}}';
		echo 'w.wakooConsentState=st(c);';
		echo 'if(!C.ids.length){return;}gtag("js",new Date());C.ids.forEach(function(id){gtag("config",id);});';
		echo 'var on=false;function load(){if(on){return;}on=true;var s=d.createElement("script");s.async=true;s.src="https://www.googletagmanager.com/gtag/js?id="+encodeURIComponent(C.ids[0]);d.head.appendChild(s);}';
		echo 'if("basic"!==C.mode||(c&&(c.analytics||c.marketing))){load();}';
		echo 'w.addEventListener("wakoo:consent",function(e){var x=e.detail||{};if("off"!==C.mode){gtag("consent","update",st(x));}if(x.analytics||x.marketing){load();}});';
		echo 'if(C.conv){if(/[?&]wk_member=sent\b/.test(w.location.search)){gtag("event","conversion",{send_to:C.conv});}d.addEventListener("click",function(e){var t=e.target.closest&&e.target.closest(".wakoo-conversion");if(t){gtag("event","conversion",{send_to:C.conv});}});}';
		echo '})(window,document,' . wp_json_encode( $cfg ) . ');</script>' . "\n";

		if ( $client ) {
			$src  = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' . rawurlencode( $client );
			$gate = 'basic' === $mode ? ' type="text/plain" data-wakoo-consent="marketing"' : '';
			echo "<!-- Wakoo: Google AdSense -->\n";
			if ( 'advanced' === $mode ) {
				// Until the visitor accepts marketing, ask AdSense for non-personalised ads.
				echo '<script>(function(){var s=window.wakooConsentState||{};if("granted"!==s.ad_personalization){(window.adsbygoogle=window.adsbygoogle||[]).requestNonPersonalizedAds=1;}})();</script>' . "\n";
			}
			echo '<script async' . $gate . ' src="' . esc_url( $src ) . '" crossorigin="anonymous"></script>' . "\n";
		}
	}

	/** /ads.txt for AdSense (only when the site has no real ads.txt file, which the web server would serve first). */
	public static function ads_txt() {
		$path = wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '', PHP_URL_PATH );
		$home = trailingslashit( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
		if ( $home . 'ads.txt' !== $path ) {
			return;
		}
		$o     = self::opts();
		$lines = [];
		if ( $o['adsense_client'] ) {
			$lines[] = 'google.com, ' . substr( $o['adsense_client'], 3 ) . ', DIRECT, f08c47fec0942fa0';
		}
		foreach ( preg_split( '/\R/', (string) $o['ads_txt_extra'] ) as $l ) {
			if ( '' !== trim( $l ) ) {
				$lines[] = trim( $l );
			}
		}
		if ( ! $lines ) {
			return;
		}
		status_header( 200 );
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'Cache-Control: public, max-age=3600' );
		echo implode( "\n", $lines ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plain text, sanitized on save.
		exit;
	}

	/** BCP 47 language of a page (Wakoo Idiomas), else the site's. */
	private static function lang_tag( $pid ) {
		if ( class_exists( '\\Wakoo\\Modules\\Idiomas\\Module' ) && $pid ) {
			$I = '\\Wakoo\\Modules\\Idiomas\\Module';
			return (string) $I::tag( $I::lang_of( $pid ) );
		}
		return str_replace( '_', '-', get_locale() );
	}

	/** Share image: the featured image, else the first image of the Elementor design (hero background, first photo). */
	private static function image_of( $pid ) {
		$img = get_the_post_thumbnail_url( $pid, 'full' );
		if ( $img ) { return $img; }
		$raw = (string) get_post_meta( $pid, '_elementor_data', true );
		$up  = preg_quote( str_replace( '/', '\\/', trailingslashit( wp_get_upload_dir()['baseurl'] ) ), '#' );
		if ( $raw && preg_match( '#"url":"(' . $up . '[^"]+?\.(?:jpe?g|png|webp))"#i', $raw, $m ) ) {
			return str_replace( '\\/', '/', $m[1] );
		}
		return '';
	}

	/**
	 * Structured data as one @graph: WebSite (with site search) and Organization everywhere; on a page or post,
	 * WebPage / Article with language, image, dates and the breadcrumb trail. Places, FAQs and jobs add their own.
	 */
	private static function jsonld( $o ) {
		$home  = home_url( '/' );
		$name  = $o['org_name'] ? $o['org_name'] : get_bloginfo( 'name' );
		$logo  = get_site_icon_url( 512 );
		$graph = [
			array_filter( [
				'@type'           => 'WebSite',
				'@id'             => $home . '#website',
				'url'             => $home,
				'name'            => $name,
				'description'     => get_bloginfo( 'description' ) ?: null,
				'publisher'       => [ '@id' => $home . '#organization' ],
				'potentialAction' => [ '@type' => 'SearchAction', 'target' => [ '@type' => 'EntryPoint', 'urlTemplate' => $home . '?s={search_term_string}' ], 'query-input' => 'required name=search_term_string' ],
			] ),
			array_filter( [
				'@type' => 'Organization',
				'@id'   => $home . '#organization',
				'name'  => $name,
				'url'   => $home,
				'logo'  => $logo ? [ '@type' => 'ImageObject', 'url' => $logo ] : null,
			] ),
		];
		if ( is_singular() ) {
			$pid   = get_queried_object_id();
			$url   = get_permalink( $pid );
			$desc  = (string) get_post_meta( $pid, self::D_META, true );
			$image = self::image_of( $pid );
			$title = wp_strip_all_tags( get_the_title( $pid ) );
			$crumbs = [ [ '@type' => 'ListItem', 'position' => 1, 'name' => $name, 'item' => $home ] ];
			$pos = 2;
			foreach ( array_reverse( get_post_ancestors( $pid ) ) as $a ) {
				if ( (int) get_option( 'page_on_front' ) === (int) $a ) { continue; }
				$crumbs[] = [ '@type' => 'ListItem', 'position' => $pos++, 'name' => wp_strip_all_tags( get_the_title( $a ) ), 'item' => get_permalink( $a ) ];
			}
			if ( ! is_front_page() ) { $crumbs[] = [ '@type' => 'ListItem', 'position' => $pos, 'name' => $title, 'item' => $url ]; }
			$page = array_filter( [
				'@type'              => 'post' === get_post_type( $pid ) ? 'Article' : 'WebPage',
				'@id'                => $url . '#webpage',
				'url'                => $url,
				'name'               => $title,
				'headline'           => 'post' === get_post_type( $pid ) ? $title : null,
				'description'        => $desc ?: null,
				'inLanguage'         => self::lang_tag( $pid ),
				'isPartOf'           => [ '@id' => $home . '#website' ],
				'primaryImageOfPage' => $image ? [ '@type' => 'ImageObject', 'url' => $image ] : null,
				'image'              => 'post' === get_post_type( $pid ) && $image ? $image : null,
				'datePublished'      => get_the_date( 'c', $pid ),
				'dateModified'       => get_the_modified_date( 'c', $pid ),
				'author'             => 'post' === get_post_type( $pid ) ? [ '@id' => $home . '#organization' ] : null,
				'publisher'          => 'post' === get_post_type( $pid ) ? [ '@id' => $home . '#organization' ] : null,
				'breadcrumb'         => count( $crumbs ) > 1 ? [ '@type' => 'BreadcrumbList', 'itemListElement' => $crumbs ] : null,
			] );
			$graph[] = $page;
		}
		echo '<script type="application/ld+json">' . wp_json_encode( [ '@context' => 'https://schema.org', '@graph' => $graph ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	/* ---------------- AI search engines ---------------- */

	/** robots.txt: say yes to the AI search crawlers and point to the sitemap and llms.txt (only when the site is public). */
	public static function robots( $out, $public ) {
		$o = self::opts();
		if ( ! $public || ! $o['ai_bots'] ) { return $out; }
		$out .= "\n# Wakoo SEO: AI search engines may read and cite this site.\n";
		foreach ( [ 'GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'ClaudeBot', 'Claude-SearchBot', 'Claude-User', 'PerplexityBot', 'Perplexity-User', 'Google-Extended', 'Applebot-Extended', 'Bingbot' ] as $bot ) {
			$out .= "User-agent: {$bot}\nAllow: /\nDisallow: /wp-admin/\n\n";
		}
		if ( false === stripos( $out, 'Sitemap:' ) ) { $out .= 'Sitemap: ' . home_url( '/wp-sitemap.xml' ) . "\n"; }
		if ( $o['llms'] ) { $out .= '# LLM guide: ' . home_url( '/llms.txt' ) . "\n"; }
		return $out;
	}

	/** /llms.txt (https://llmstxt.org): the site explained in Markdown for AI assistants. Cached until something is saved. */
	public static function llms_txt() {
		$path = wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '', PHP_URL_PATH );
		$home = trailingslashit( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
		if ( $home . 'llms.txt' !== $path || ! self::opts()['llms'] || ! get_option( 'blog_public' ) ) { return; }
		$txt = get_transient( 'wakoo_llms_txt' );
		if ( ! is_string( $txt ) ) {
			$txt = self::llms_build();
			set_transient( 'wakoo_llms_txt', $txt, 12 * HOUR_IN_SECONDS );
		}
		status_header( 200 );
		header( 'Content-Type: text/markdown; charset=utf-8' );
		header( 'Cache-Control: public, max-age=3600' );
		header( 'X-Robots-Tag: noindex' );
		echo $txt; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plain Markdown built from titles and descriptions.
		exit;
	}

	private static function md( $s ) {
		return trim( preg_replace( '/\s+/', ' ', str_replace( [ '[', ']' ], [ '(', ')' ], wp_strip_all_tags( html_entity_decode( (string) $s, ENT_QUOTES, 'UTF-8' ) ) ) ) );
	}

	private static function llms_build() {
		$o     = self::opts();
		$name  = $o['org_name'] ? $o['org_name'] : get_bloginfo( 'name' );
		$front = (int) get_option( 'page_on_front' );
		$intro = $front ? ( (string) get_post_meta( $front, self::D_META, true ) ?: self::derive_desc( $front ) ) : get_bloginfo( 'description' );
		$I     = class_exists( '\\Wakoo\\Modules\\Idiomas\\Module' ) ? '\\Wakoo\\Modules\\Idiomas\\Module' : '';
		$langs = $I ? $I::public_langs() : [ '' => '' ];
		$lines = [ '# ' . self::md( $name ), '', '> ' . self::md( $intro ), '', '- ' . home_url( '/' ) ];
		if ( $I ) { $lines[] = '- ' . sprintf( 'Languages: %s', implode( ', ', array_map( [ __CLASS__, 'md' ], $langs ) ) ); }
		$lines[] = '';
		foreach ( $langs as $code => $lname ) {
			foreach ( [ 'page' => 'Pages', 'post' => 'News' ] as $type => $label ) {
				$q = [ 'post_type' => $type, 'post_status' => 'publish', 'posts_per_page' => 'post' === $type ? 40 : 100, 'orderby' => 'post' === $type ? 'date' : 'menu_order title', 'order' => 'post' === $type ? 'DESC' : 'ASC', 'has_password' => false ];
				if ( $I && $code ) { $q['meta_query'] = [ 'relation' => 'OR', [ 'key' => '_wakoo_lang', 'value' => $code ], $code === $I::default_lang() ? [ 'key' => '_wakoo_lang', 'compare' => 'NOT EXISTS' ] : [ 'key' => '_wakoo_lang', 'value' => $code ] ]; } // phpcs:ignore WordPress.DB.SlowDBQuery
				$posts = get_posts( $q );
				if ( ! $posts ) { continue; }
				$lines[] = '## ' . $label . ( $lname ? ' (' . self::md( $lname ) . ')' : '' );
				$lines[] = '';
				foreach ( $posts as $p ) {
					if ( (string) get_post_meta( $p->ID, '_wp_page_template', true ) && 'noindex' === get_post_meta( $p->ID, '_wakoo_robots', true ) ) { continue; }
					$d = (string) get_post_meta( $p->ID, self::D_META, true ) ?: ( $p->post_excerpt ?: '' );
					$lines[] = '- [' . self::md( get_the_title( $p ) ) . '](' . get_permalink( $p ) . ')' . ( $d ? ': ' . self::md( $d ) : '' );
				}
				$lines[] = '';
			}
		}
		// Places of Wakoo Lugares (name, category, address): what people ask assistants about a town.
		if ( post_type_exists( 'wakoo_place' ) ) {
			$places = get_posts( [ 'post_type' => 'wakoo_place', 'post_status' => 'publish', 'posts_per_page' => 500, 'orderby' => 'title', 'order' => 'ASC' ] );
			if ( $places ) {
				$by = [];
				foreach ( $places as $p ) {
					$t   = get_the_terms( $p, 'wakoo_place_cat' );
					$cat = is_array( $t ) && $t ? self::md( $t[0]->name ) : '—';
					$adr = (string) get_post_meta( $p->ID, '_wakoo_place_address', true );
					$web = (string) get_post_meta( $p->ID, '_wakoo_place_website', true );
					$by[ $cat ][] = '- ' . self::md( get_the_title( $p ) ) . ( $adr ? ' — ' . self::md( $adr ) : '' ) . ( $web ? ' — ' . esc_url_raw( $web ) : '' );
				}
				ksort( $by );
				$lines[] = '## Places';
				$lines[] = '';
				foreach ( $by as $cat => $rows ) {
					$lines[] = '### ' . $cat;
					$lines   = array_merge( $lines, $rows );
					$lines[] = '';
				}
			}
		}
		$lines[] = '## Optional';
		$lines[] = '';
		$lines[] = '- [Sitemap](' . home_url( '/wp-sitemap.xml' ) . ')';
		return implode( "\n", $lines ) . "\n";
	}

	/** Replace the <title> with the SEO title when set. */
	public static function filter_title( $parts ) {
		if ( is_singular() ) {
			$t = (string) get_post_meta( get_queried_object_id(), self::T_META, true );
			if ( $t ) {
				$parts['title'] = $t;
			}
		}
		return $parts;
	}
}

add_filter( 'document_title_parts', [ Module::class, 'filter_title' ] );
Module::init();
