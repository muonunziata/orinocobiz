<?php
/**
 * Wakoo Dynamic Tags: fields that fill themselves (title, author, date, price…).
 *
 * Registers a "Wakoo" group of dynamic tags on top of Elementor's free dynamic
 * tags engine, so any text/URL/image control can pull live data instead of a
 * fixed value.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Dynamic_Tags;

defined( 'ABSPATH' ) || die();

class Module {

	const GROUP = 'wakoo';

	public static function init() {
		add_action( 'elementor/dynamic_tags/register', [ __CLASS__, 'register' ] );
	}

	public static function register( $dynamic_tags ) {
		$mgr = \Elementor\Plugin::instance()->dynamic_tags;
		$mgr->register_group( self::GROUP, [ 'title' => __( 'Wakoo', 'wakoo' ) ] );
		require_once __DIR__ . '/tags.php';
		foreach ( tags() as $class ) {
			$dynamic_tags->register( new $class() );
		}
	}
}

Module::init();
