<?php
/**
 * Wakoo dynamic tag classes. Loaded on elementor/dynamic_tags/register, when the
 * Elementor tag base classes exist.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Dynamic_Tags;

use Elementor\Core\DynamicTags\Tag;
use Elementor\Core\DynamicTags\Data_Tag;
use Elementor\Controls_Manager;
use Elementor\Modules\DynamicTags\Module as Tags;

defined( 'ABSPATH' ) || die();

function tags() {
	return [
		Post_Title::class, Post_Excerpt::class, Post_Date::class, Post_Author::class,
		Site_Title::class, Site_Tagline::class, Current_Year::class, User_Name::class,
		Query_Param::class, Shortcode_Tag::class, Product_Price::class,
		Post_Url::class, Site_Url::class, Featured_Image::class,
	];
}

abstract class Text_Base extends Tag {
	public function get_group() { return Module::GROUP; }
	public function get_categories() { return [ Tags::TEXT_CATEGORY ]; }
}

class Post_Title extends Text_Base {
	public function get_name() { return 'wakoo-post-title'; }
	public function get_title() { return __( 'Título de la entrada', 'wakoo' ); }
	public function render() { echo esc_html( get_the_title() ); }
}
class Post_Excerpt extends Text_Base {
	public function get_name() { return 'wakoo-post-excerpt'; }
	public function get_title() { return __( 'Extracto', 'wakoo' ); }
	public function render() { echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); }
}
class Post_Date extends Text_Base {
	public function get_name() { return 'wakoo-post-date'; }
	public function get_title() { return __( 'Fecha de la entrada', 'wakoo' ); }
	protected function register_controls() {
		$this->add_control( 'format', [ 'label' => __( 'Formato', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => get_option( 'date_format' ) ] );
	}
	public function render() {
		$fmt = $this->get_settings( 'format' );
		echo esc_html( get_the_date( $fmt ? $fmt : '' ) );
	}
}
class Post_Author extends Text_Base {
	public function get_name() { return 'wakoo-post-author'; }
	public function get_title() { return __( 'Autor', 'wakoo' ); }
	public function render() { echo esc_html( get_the_author_meta( 'display_name', (int) get_post_field( 'post_author', get_the_ID() ) ) ); }
}
class Site_Title extends Text_Base {
	public function get_name() { return 'wakoo-site-title'; }
	public function get_title() { return __( 'Nombre del sitio', 'wakoo' ); }
	public function render() { echo esc_html( get_bloginfo( 'name' ) ); }
}
class Site_Tagline extends Text_Base {
	public function get_name() { return 'wakoo-site-tagline'; }
	public function get_title() { return __( 'Descripción del sitio', 'wakoo' ); }
	public function render() { echo esc_html( get_bloginfo( 'description' ) ); }
}
class Current_Year extends Text_Base {
	public function get_name() { return 'wakoo-year'; }
	public function get_title() { return __( 'Año actual', 'wakoo' ); }
	public function render() { echo esc_html( wp_date( 'Y' ) ); }
}
class User_Name extends Text_Base {
	public function get_name() { return 'wakoo-user-name'; }
	public function get_title() { return __( 'Nombre del usuario conectado', 'wakoo' ); }
	public function render() {
		$u = wp_get_current_user();
		echo esc_html( $u && $u->ID ? $u->display_name : '' );
	}
}
class Query_Param extends Text_Base {
	public function get_name() { return 'wakoo-query-param'; }
	public function get_title() { return __( 'Parámetro de URL', 'wakoo' ); }
	protected function register_controls() {
		$this->add_control( 'param', [ 'label' => __( 'Nombre del parámetro', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'placeholder' => 'utm_source' ] );
	}
	public function render() {
		$p = sanitize_key( (string) $this->get_settings( 'param' ) );
		echo $p && isset( $_GET[ $p ] ) ? esc_html( sanitize_text_field( wp_unslash( $_GET[ $p ] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	}
}
class Shortcode_Tag extends Text_Base {
	public function get_name() { return 'wakoo-shortcode'; }
	public function get_title() { return __( 'Shortcode', 'wakoo' ); }
	protected function register_controls() {
		$this->add_control( 'shortcode', [ 'label' => __( 'Shortcode', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'placeholder' => '[mi_shortcode]' ] );
	}
	public function render() {
		$sc = (string) $this->get_settings( 'shortcode' );
		echo $sc ? do_shortcode( $sc ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
class Product_Price extends Text_Base {
	public function get_name() { return 'wakoo-product-price'; }
	public function get_title() { return __( 'Precio del producto (WooCommerce)', 'wakoo' ); }
	public function render() {
		if ( function_exists( 'wc_get_product' ) ) {
			$p = wc_get_product( get_the_ID() );
			if ( $p ) { echo wp_kses_post( $p->get_price_html() ); }
		}
	}
}

/* ---- data tags (url / image) ---- */

class Post_Url extends Data_Tag {
	public function get_name() { return 'wakoo-post-url'; }
	public function get_title() { return __( 'Enlace de la entrada', 'wakoo' ); }
	public function get_group() { return Module::GROUP; }
	public function get_categories() { return [ Tags::URL_CATEGORY ]; }
	protected function get_value( array $options = [] ) { return get_permalink( get_the_ID() ); }
}
class Site_Url extends Data_Tag {
	public function get_name() { return 'wakoo-site-url'; }
	public function get_title() { return __( 'Enlace del sitio', 'wakoo' ); }
	public function get_group() { return Module::GROUP; }
	public function get_categories() { return [ Tags::URL_CATEGORY ]; }
	protected function get_value( array $options = [] ) { return home_url( '/' ); }
}
class Featured_Image extends Data_Tag {
	public function get_name() { return 'wakoo-featured-image'; }
	public function get_title() { return __( 'Imagen destacada', 'wakoo' ); }
	public function get_group() { return Module::GROUP; }
	public function get_categories() { return [ Tags::IMAGE_CATEGORY ]; }
	protected function get_value( array $options = [] ) {
		$id = get_post_thumbnail_id( get_the_ID() );
		return [ 'id' => $id, 'url' => $id ? wp_get_attachment_image_url( $id, 'full' ) : '' ];
	}
}
