<?php
/**
 * Wakoo Idiomas: the same site in several languages without a translation plugin.
 *
 * Each page carries its language (`_wakoo_lang`) and a translation group
 * (`_wakoo_tr`): pages that share a group are translations of each other.
 * The module then:
 *  - prints the right <html lang> and hreflang alternates (+ x-default),
 *  - offers a language switcher (shortcode [wakoo_idiomas] and an Elementor widget)
 *    that links each language to the translation of the current page,
 *  - adds a "Idioma" box to the page editor to set or change both values.
 *
 * Languages are configured in Wakoo → Idiomas (code|name per line); the first one is the default.
 * The default-language page is the master: saving it updates its translations (see sync.php).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Idiomas;

defined( 'ABSPATH' ) || die();

class Module {

	const LANG   = '_wakoo_lang';
	const GROUP  = '_wakoo_tr';
	const OPTION = 'wakoo_langs';
	/** Languages offered in the settings; any other code can be added as an extra. */
	const CATALOG = [ 'es' => 'Español', 'en' => 'English', 'fr' => 'Français', 'de' => 'Deutsch', 'it' => 'Italiano', 'pt' => 'Português', 'zh-tw' => '繁體中文', 'zh' => '中文 (简体)', 'ja' => '日本語', 'ko' => '한국어', 'nl' => 'Nederlands', 'ru' => 'Русский', 'ar' => 'العربية', 'tr' => 'Türkçe', 'pl' => 'Polski' ];
	const PAGE_LANGS = '_wakoo_tr_langs';
	const HIDDEN     = 'wakoo_langs_hidden';
	const PUBDEF     = 'wakoo_lang_public_default';
	const DEFAULTS = "es|Español\nfr|Français\nen|English\nzh-tw|繁體中文\nit|Italiano\nde|Deutsch";

	/** BCP 47 tags for <html lang> and hreflang, for the codes people usually type. */
	const TAGS = [ 'es' => 'es', 'en' => 'en', 'zh' => 'zh-Hans', 'zh-tw' => 'zh-Hant', 'zh-hk' => 'zh-Hant', 'pt' => 'pt', 'fr' => 'fr', 'it' => 'it', 'de' => 'de', 'ar' => 'ar', 'ru' => 'ru' ];

	public static function init() {
		add_filter( 'language_attributes', [ __CLASS__, 'html_lang' ], 20 );
		add_action( 'wp_head', [ __CLASS__, 'hreflang' ], 2 );
		add_action( 'template_redirect', [ __CLASS__, 'redirect_hidden' ], 1 );
		add_filter( 'wp_robots', [ __CLASS__, 'robots' ], 20 );
		add_filter( 'wp_sitemaps_posts_query_args', [ __CLASS__, 'sitemap_args' ] );
		// Pages with their own language win over the in-page switch of Wakoo Escena (which boots at priority 1).
		add_action( 'wp_head', [ __CLASS__, 'lock_lang' ], 2 );
		add_filter( 'wakoo_lang_default', [ __CLASS__, 'default_for_page' ] );
		add_filter( 'body_class', [ __CLASS__, 'body_class' ] );
		add_shortcode( 'wakoo_idiomas', [ __CLASS__, 'shortcode' ] );
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_action( 'add_meta_boxes', [ __CLASS__, 'meta_box' ] );
		add_action( 'save_post', [ __CLASS__, 'save_meta' ] );
		add_action( 'admin_menu', [ __CLASS__, 'menu' ], 31 );
		add_action( 'admin_init', [ __CLASS__, 'settings' ] );
		add_action( 'admin_post_wakoo_idiomas_langs', [ __CLASS__, 'save_languages' ] );
		add_filter( 'manage_pages_columns', [ __CLASS__, 'column' ] );
		add_action( 'manage_pages_custom_column', [ __CLASS__, 'column_value' ], 10, 2 );
	}

	/** [ code => name ] in the configured order; the first is the default language. */
	public static function languages() {
		$raw = (string) get_option( self::OPTION, self::DEFAULTS );
		$out = [];
		foreach ( preg_split( '/\R/', $raw ) as $line ) {
			$p    = array_map( 'trim', explode( '|', $line, 2 ) );
			$code = sanitize_key( $p[0] ?? '' );
			if ( $code ) { $out[ $code ] = '' !== ( $p[1] ?? '' ) ? $p[1] : strtoupper( $code ); }
		}
		return $out ?: [ 'es' => 'Español' ];
	}

	public static function default_lang() {
		$l = array_keys( self::languages() );
		return $l[0];
	}

	public static function tag( $code ) {
		return self::TAGS[ $code ] ?? $code;
	}

	/** Languages (other than the default) a master page is translated into: its own choice, else all the active ones. */
	public static function page_langs( $pid ) {
		$all = array_keys( self::languages() );
		$all = array_values( array_diff( $all, [ self::default_lang() ], self::hidden_langs() ) );
		$own = get_post_meta( $pid, self::PAGE_LANGS, true );
		if ( ! is_array( $own ) || ! $own ) { return $all; }
		return array_values( array_intersect( array_keys( self::languages() ), $own ) );
	}

	/** Languages kept out of the public site (editing only), e.g. the Spanish master. At least one stays public. */
	public static function hidden_langs() {
		$h   = array_values( array_intersect( array_keys( self::languages() ), (array) get_option( self::HIDDEN, [] ) ) );
		$all = array_keys( self::languages() );
		return count( $h ) >= count( $all ) ? [] : $h;
	}

	public static function public_langs() {
		return array_diff_key( self::languages(), array_flip( self::hidden_langs() ) );
	}

	public static function is_public( $code ) {
		return isset( self::public_langs()[ $code ] );
	}

	/** Language a visitor lands on by default: the chosen public one, else the first public language. */
	public static function public_default() {
		$pub = array_keys( self::public_langs() );
		$sel = (string) get_option( self::PUBDEF, '' );
		return in_array( $sel, $pub, true ) ? $sel : $pub[0];
	}

	/**
	 * Order for the language switcher: the language visitors land on first (e.g. English), then the
	 * rest as configured. The master (first configured language) does not change.
	 */
	public static function display_order() {
		$all = self::languages();
		$def = self::public_default();
		return isset( $all[ $def ] ) ? [ $def => $all[ $def ] ] + $all : $all;
	}

	/** Public languages a page and its translations are offered in (honours the master's own language choice). */
	public static function allowed_for( $pid ) {
		$allowed = array_keys( self::public_langs() );
		$tr      = self::translations( $pid );
		$master  = $tr[ self::default_lang() ] ?? 0;
		$own     = $master ? get_post_meta( $master, self::PAGE_LANGS, true ) : null;
		if ( is_array( $own ) && $own ) {
			$allowed = array_values( array_intersect( $allowed, array_merge( $own, [ self::default_lang() ] ) ) );
		}
		return $allowed;
	}

	/** Visitors never see a language kept out of the public site: they are sent to its public translation. */
	public static function redirect_hidden() {
		if ( is_admin() || current_user_can( 'edit_pages' ) || isset( $_GET['elementor-preview'] ) ) { return; } // phpcs:ignore WordPress.Security.NonceVerification
		$pid = self::current_id();
		if ( ! $pid || ! in_array( self::lang_of( $pid ), self::hidden_langs(), true ) ) { return; }
		$tr = array_filter( self::translations( $pid ), function ( $id ) { return 'publish' === get_post_status( $id ); } );
		foreach ( array_merge( [ self::public_default() ], array_keys( self::public_langs() ) ) as $code ) {
			if ( isset( $tr[ $code ] ) && (int) $tr[ $code ] !== $pid ) {
				wp_safe_redirect( get_permalink( $tr[ $code ] ), 302 );
				exit;
			}
		}
	}

	public static function robots( $robots ) {
		$pid = self::current_id();
		if ( $pid && in_array( self::lang_of( $pid ), self::hidden_langs(), true ) ) { $robots['noindex'] = true; $robots['nofollow'] = true; unset( $robots['max-image-preview'] ); }
		return $robots;
	}

	public static function sitemap_args( $args ) {
		$hidden = self::hidden_langs();
		if ( $hidden ) {
			$args['meta_query'] = array_merge( (array) ( $args['meta_query'] ?? [] ), [ [ 'relation' => 'OR', [ 'key' => self::LANG, 'compare' => 'NOT EXISTS' ], [ 'key' => self::LANG, 'value' => $hidden, 'compare' => 'NOT IN' ] ] ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
		}
		return $args;
	}

	/** Older packs and sites used other codes for the same language. */
	const ALIASES = [ 'zh' => 'zh-tw', 'zh-cn' => 'zh-tw', 'zh-hans' => 'zh-tw', 'zh-hant' => 'zh-tw', 'zh-hk' => 'zh-tw', 'zh_tw' => 'zh-tw', 'zh_cn' => 'zh-tw', 'jp' => 'ja', 'cn' => 'zh-tw' ];

	/** Maps a stored code to one of the configured languages ('' when it is none of them). */
	public static function normalize( $code ) {
		$code = sanitize_key( str_replace( '_', '-', (string) $code ) );
		$all  = self::languages();
		if ( isset( $all[ $code ] ) ) { return $code; }
		$alt = self::ALIASES[ $code ] ?? '';
		return ( $alt && isset( $all[ $alt ] ) ) ? $alt : '';
	}

	/**
	 * Language of a post: its stored code (old codes such as zh are mapped to zh-tw), the default
	 * language when none is set. A code that is not configured is returned as it is, so such a page
	 * is never taken for a master.
	 */
	public static function lang_of( $pid ) {
		$raw = $pid ? (string) get_post_meta( $pid, self::LANG, true ) : '';
		if ( '' === $raw ) { return self::default_lang(); }
		$n = self::normalize( $raw );
		return '' !== $n ? $n : sanitize_key( $raw );
	}

	private static function current_id() {
		if ( is_singular() ) { return (int) get_queried_object_id(); }
		if ( is_front_page() ) { return (int) get_option( 'page_on_front' ); }
		return 0;
	}

	/** [ code => post id ] of the published translations in the same group (includes $pid itself). */
	public static function translations( $pid ) {
		$group = $pid ? (string) get_post_meta( $pid, self::GROUP, true ) : '';
		if ( '' === $group ) { return $pid ? [ self::lang_of( $pid ) => $pid ] : []; }
		$ids = get_posts( [
			'post_type'      => get_post_type( $pid ) ?: 'page',
			'post_status'    => current_user_can( 'edit_pages' ) ? [ 'publish', 'draft', 'private' ] : 'publish',
			'posts_per_page' => 50,
			'fields'         => 'ids',
			'meta_key'       => self::GROUP, // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_value'     => $group, // phpcs:ignore WordPress.DB.SlowDBQuery
		] );
		$out = [];
		foreach ( $ids as $id ) {
			$l = self::lang_of( $id );
			if ( ! isset( $out[ $l ] ) || $id === $pid ) { $out[ $l ] = (int) $id; }
		}
		return $out;
	}

	/** Translation of the site's front page, used when a page has no version in a language. */
	private static function home_in( $lang ) {
		$front = (int) get_option( 'page_on_front' );
		$tr    = $front ? self::translations( $front ) : [];
		return isset( $tr[ $lang ] ) ? get_permalink( $tr[ $lang ] ) : home_url( '/' );
	}

	public static function html_lang( $out ) {
		$pid = self::current_id();
		if ( ! $pid ) { return $out; }
		$tag = self::tag( self::lang_of( $pid ) );
		$out = preg_replace( '/lang="[^"]*"/', 'lang="' . esc_attr( $tag ) . '"', $out, 1, $n );
		return $n ? $out : trim( $out . ' lang="' . esc_attr( $tag ) . '"' );
	}

	/** Language set explicitly on the current page, or ''. */
	private static function page_lang() {
		$pid = self::current_id();
		$l   = $pid ? (string) get_post_meta( $pid, self::LANG, true ) : '';
		return self::normalize( $l );
	}

	public static function default_for_page( $lang ) {
		$l = self::page_lang();
		return $l ? $l : $lang;
	}

	/** Keeps html[lang] and html[data-wakoo-lang] on the page's own language even if the visitor chose another one elsewhere. */
	public static function lock_lang() {
		$l = self::page_lang();
		if ( ! $l ) { return; }
		echo '<script id="wakoo-idiomas-lang">(function(h){h.setAttribute("data-wakoo-lang",' . wp_json_encode( $l ) . ');h.lang=' . wp_json_encode( self::tag( $l ) ) . ';})(document.documentElement);</script>' . "\n";
	}

	public static function body_class( $c ) {
		$pid = self::current_id();
		if ( $pid ) { $c[] = 'wakoo-lang-' . sanitize_html_class( self::lang_of( $pid ) ); }
		return $c;
	}

	public static function hreflang() {
		$pid = self::current_id();
		if ( ! $pid || 'publish' !== get_post_status( $pid ) ) { return; }
		$tr = self::translations( $pid );
		if ( count( $tr ) < 2 ) { return; }
		$allowed = self::allowed_for( $pid );
		foreach ( $tr as $code => $id ) {
			if ( ! in_array( $code, $allowed, true ) || 'publish' !== get_post_status( $id ) ) { continue; }
			printf( '<link rel="alternate" hreflang="%s" href="%s">' . "\n", esc_attr( self::tag( $code ) ), esc_url( get_permalink( $id ) ) );
		}
		$def = self::public_default();
		if ( ! in_array( $def, $allowed, true ) ) { $def = $allowed[0] ?? ''; }
		if ( $def && isset( $tr[ $def ] ) ) {
			printf( '<link rel="alternate" hreflang="x-default" href="%s">' . "\n", esc_url( get_permalink( $tr[ $def ] ) ) );
		}
	}

	/**
	 * Switcher markup. $style: list (names), codes (ES · EN · 中文 as short labels), dropdown
	 * (a compact «🌐 EN ▾» button that opens the list of links) or select.
	 * Elementor's preview renders it for the page being edited.
	 */
	public static function render( $style = 'list', $label = '' ) {
		$pid = self::current_id();
		if ( ! $pid && class_exists( '\Elementor\Plugin' ) && \Elementor\Plugin::$instance->documents ) {
			$doc = \Elementor\Plugin::$instance->documents->get_current();
			$pid = $doc ? (int) $doc->get_main_id() : 0;
		}
		$langs = self::display_order();
		$cur   = $pid ? self::lang_of( $pid ) : self::default_lang();
		$tr    = $pid ? self::translations( $pid ) : [];
		$label = '' !== $label ? $label : __( 'Idioma', 'wakoo' );
		$links = [];
		$ok         = $pid && ! is_admin() ? self::allowed_for( $pid ) : array_keys( self::public_langs() );
		$restricted = $pid && is_array( get_post_meta( $tr[ self::default_lang() ] ?? 0, self::PAGE_LANGS, true ) ) && get_post_meta( $tr[ self::default_lang() ] ?? 0, self::PAGE_LANGS, true );
		foreach ( $langs as $code => $name ) {
			if ( ! in_array( $code, $ok, true ) || ( $restricted && ! isset( $tr[ $code ] ) ) ) { continue; }
			$url  = isset( $tr[ $code ] ) ? get_permalink( $tr[ $code ] ) : self::home_in( $code );
			$text = 'codes' === $style ? ( 'zh' === $code ? '中文' : ( 'zh-tw' === $code ? '繁體' : strtoupper( $code ) ) ) : $name;
			$links[ $code ] = [ $url, $text, $name ];
		}
		if ( 'dropdown' === $style && $links ) {
			$now  = $links[ $cur ] ?? reset( $links );
			$code = isset( $links[ $cur ] ) ? $cur : key( $links );
			$html = '<details class="wakoo-langs wakoo-langs--dropdown"><summary aria-label="' . esc_attr( $label . ': ' . $now[2] ) . '">'
				. '<svg class="wakoo-langs__globe" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="1.8" d="M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm-9 9h18M12 3c2.5 2.6 3.8 5.6 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3Z"/></svg>'
				. '<span>' . esc_html( 'zh' === $code ? '中文' : ( 'zh-tw' === $code ? '繁體' : strtoupper( $code ) ) ) . '</span><span class="wakoo-langs__caret" aria-hidden="true"></span></summary><ul>';
			foreach ( $links as $c => $l ) {
				$tag   = esc_attr( self::tag( $c ) );
				$html .= '<li><a href="' . esc_url( $l[0] ) . '" lang="' . $tag . '" hreflang="' . $tag . '"' . ( $c === $cur ? ' aria-current="true" class="is-current"' : '' ) . '>'
					. '<span class="wakoo-langs__code">' . esc_html( strtoupper( $c ) ) . '</span>' . esc_html( $l[2] ) . '</a></li>';
			}
			return $html . '</ul></details>';
		}
		if ( 'select' === $style ) {
			$id   = 'wk-lang-' . wp_unique_id();
			$html = '<div class="wakoo-langs wakoo-langs--select"><label class="screen-reader-text" for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label><select id="' . esc_attr( $id ) . '" onchange="if(this.value)location.href=this.value">';
			foreach ( $links as $code => $l ) {
				$html .= '<option value="' . esc_url( $l[0] ) . '" lang="' . esc_attr( self::tag( $code ) ) . '"' . selected( $code, $cur, false ) . '>' . esc_html( $l[2] ) . '</option>';
			}
			return $html . '</select></div>';
		}
		$html = '<nav class="wakoo-langs" aria-label="' . esc_attr( $label ) . '"><ul>';
		foreach ( $links as $code => $l ) {
			$attrs = ' lang="' . esc_attr( self::tag( $code ) ) . '" hreflang="' . esc_attr( self::tag( $code ) ) . '"';
			if ( $code === $cur ) {
				$html .= '<li><a href="' . esc_url( $l[0] ) . '" aria-current="true" class="is-current"' . $attrs . ' title="' . esc_attr( $l[2] ) . '">' . esc_html( $l[1] ) . '</a></li>';
			} else {
				$html .= '<li><a href="' . esc_url( $l[0] ) . '"' . $attrs . ' title="' . esc_attr( $l[2] ) . '">' . esc_html( $l[1] ) . '</a></li>';
			}
		}
		return $html . '</ul></nav>';
	}

	public static function shortcode( $atts ) {
		$atts = shortcode_atts( [ 'style' => 'list', 'label' => '' ], $atts, 'wakoo_idiomas' );
		self::style();
		return self::render( sanitize_key( $atts['style'] ), sanitize_text_field( $atts['label'] ) );
	}

	public static function style() {
		static $done = false;
		if ( $done ) { return; }
		$done = true;
		wp_register_style( 'wakoo-idiomas', false, [], WAKOO_VERSION );
		wp_enqueue_style( 'wakoo-idiomas' );
		// Dropdown: the list floats under the button; one open at a time, closes on a click outside or Esc.
		wp_register_script( 'wakoo-idiomas', false, [], WAKOO_VERSION, true );
		wp_enqueue_script( 'wakoo-idiomas' );
		wp_add_inline_script( 'wakoo-idiomas', '(function(){function all(){return document.querySelectorAll(".wakoo-langs--dropdown[open]")}document.addEventListener("click",function(e){all().forEach(function(d){if(!d.contains(e.target)){d.open=false}})});document.addEventListener("keydown",function(e){if(e.key==="Escape"){all().forEach(function(d){d.open=false;d.querySelector("summary").focus()})}})})();' );
		wp_add_inline_style( 'wakoo-idiomas', '.wakoo-langs--dropdown{position:relative;display:inline-block}.wakoo-langs--dropdown summary{list-style:none;display:inline-flex;align-items:center;gap:6px;padding:.4rem .7rem;border-radius:999px;border:1px solid rgba(127,127,127,.35);cursor:pointer;font-weight:700;font-size:.85em;line-height:1.2;user-select:none}.wakoo-langs--dropdown summary::-webkit-details-marker{display:none}.wakoo-langs--dropdown summary:hover,.wakoo-langs--dropdown[open] summary{background:rgba(127,127,127,.14)}.wakoo-langs__caret{width:0;height:0;border:4px solid transparent;border-top-color:currentColor;margin-top:4px;transition:transform .2s}.wakoo-langs--dropdown[open] .wakoo-langs__caret{transform:rotate(180deg);margin-top:-4px}.wakoo-langs--dropdown ul{position:absolute;right:0;top:calc(100% + 8px);z-index:100;display:flex;flex-direction:column;gap:2px;min-width:170px;padding:6px;background:#fff;color:#1b2a33;border-radius:12px;box-shadow:0 18px 40px -12px rgba(0,0,0,.3);border:1px solid rgba(0,0,0,.08)}.wakoo-langs--dropdown a{display:flex;align-items:center;gap:10px;padding:.5rem .6rem;font-size:.92em}.wakoo-langs.wakoo-langs--dropdown a.is-current{box-shadow:none;background:rgba(127,127,127,.12)}.wakoo-langs__code{display:inline-block;min-width:26px;font-size:.75em;font-weight:800;opacity:.6}' );
		wp_add_inline_style( 'wakoo-idiomas', '.wakoo-langs ul{display:flex;gap:.25rem;list-style:none;margin:0;padding:0;flex-wrap:wrap}.wakoo-langs a{display:inline-block;padding:.3rem .55rem;border-radius:6px;text-decoration:none;color:inherit;font-size:.85em;line-height:1.2}.wakoo-langs a:hover,.wakoo-langs a:focus-visible{background:rgba(127,127,127,.18)}.wakoo-langs a.is-current{font-weight:700;box-shadow:inset 0 -2px 0 currentColor}' );
	}

	public static function register_widget( $wm ) {
		require_once __DIR__ . '/widget.php';
		$wm->register( new Widget() );
	}

	/* ---------- admin ---------- */

	public static function meta_box() {
		foreach ( [ 'page', 'post', 'elementor_library' ] as $pt ) {
			add_meta_box( 'wakoo_lang_box', __( 'Idioma (Wakoo)', 'wakoo' ), [ __CLASS__, 'box_html' ], $pt, 'side' );
		}
	}

	public static function box_html( $post ) {
		wp_nonce_field( 'wakoo_lang_box', 'wakoo_lang_nonce' );
		$cur = self::lang_of( $post->ID );
		echo '<p><label for="wakoo_lang">' . esc_html__( 'Idioma de esta página', 'wakoo' ) . '</label><br><select name="wakoo_lang" id="wakoo_lang" style="width:100%">';
		foreach ( self::languages() as $code => $name ) {
			echo '<option value="' . esc_attr( $code ) . '"' . selected( $code, $cur, false ) . '>' . esc_html( $name ) . '</option>';
		}
		echo '</select></p><p><label for="wakoo_tr">' . esc_html__( 'Grupo de traducción', 'wakoo' ) . '</label><br><input type="text" name="wakoo_tr" id="wakoo_tr" style="width:100%" value="' . esc_attr( get_post_meta( $post->ID, self::GROUP, true ) ) . '"></p>';
		echo '<p class="description">' . esc_html__( 'Las páginas con el mismo grupo son traducciones entre sí; el selector de idioma enlaza unas con otras.', 'wakoo' ) . '</p>';
		$tr = self::translations( $post->ID );
		unset( $tr[ $cur ] );
		if ( $tr ) {
			echo '<ul>';
			foreach ( $tr as $code => $id ) {
				$pend = Sync::pending_count( get_post_meta( $id, Sync::MAP, true ) );
				echo '<li>' . esc_html( self::languages()[ $code ] ?? $code ) . ': <a href="' . esc_url( get_edit_post_link( $id ) ) . '">' . esc_html( get_the_title( $id ) ) . '</a>' . ( $pend ? ' · ' . esc_html( sprintf( _n( '%d texto por traducir', '%d textos por traducir', $pend, 'wakoo' ), $pend ) ) : '' ) . '</li>';
			}
			echo '</ul>';
		}
		if ( $tr && $post->ID && 'auto-draft' !== $post->post_status && get_post_meta( $post->ID, '_elementor_data', true ) ) {
			echo '<p><a class="button button-primary" href="' . esc_url( Sync::replicate_url( $post->ID ) ) . '" onclick="return confirm(' . esc_attr( wp_json_encode( __( 'Los cambios de esta página (diseño, fotos, secciones y textos editados) se copiarán a todos los idiomas. ¿Continuar?', 'wakoo' ) ) ) . ')">' . esc_html__( 'Replicar en todos los idiomas', 'wakoo' ) . '</a></p>'
				. '<p class="description">' . esc_html__( 'Copia los cambios de esta versión a todas las demás, también desde un idioma que no sea el maestro. Cada idioma conserva sus traducciones.', 'wakoo' ) . '</p>';
		}
		if ( $cur === self::default_lang() ) {
			echo '<p class="description">' . esc_html__( 'Esta es la versión maestra: al guardarla en Elementor, sus traducciones reciben los mismos cambios de diseño, fotos y enlaces, y solo se traducen los textos que cambiaron.', 'wakoo' ) . '</p>';
			if ( $post->ID && 'auto-draft' !== $post->post_status ) {
				$url = wp_nonce_url( admin_url( 'admin-post.php?action=wakoo_idiomas_make&post=' . $post->ID ), 'wakoo_idiomas_make_' . $post->ID );
				echo '<p><a class="button button-primary" href="' . esc_url( $url ) . '">' . esc_html__( 'Clonar esta página a los demás idiomas', 'wakoo' ) . '</a></p><p class="description">' . esc_html__( 'Crea las versiones que faltan y actualiza las existentes con el diseño de esta página; los textos que ya corregiste a mano se conservan.', 'wakoo' ) . '</p>';
				if ( $tr ) {
					echo '<p><a class="button" href="' . esc_url( $url . '&overwrite=1' ) . '" onclick="return confirm(' . esc_attr( wp_json_encode( __( 'Se reemplazarán TODAS las versiones en los demás idiomas por una copia de esta página, incluidas las correcciones manuales (se guarda una copia de seguridad). ¿Continuar?', 'wakoo' ) ) ) . ')">' . esc_html__( 'Sobrescribir todo', 'wakoo' ) . '</a></p>';
				}
			}
		} else {
			$pend = Sync::pending_count( get_post_meta( $post->ID, Sync::MAP, true ) );
			if ( $pend ) { echo '<p><strong>' . esc_html( sprintf( _n( '%d texto por traducir', '%d textos por traducir', $pend, 'wakoo' ), $pend ) ) . '</strong></p>'; }
			echo '<p><label><input type="checkbox" name="wakoo_tr_nosync" value="1"' . checked( (bool) get_post_meta( $post->ID, Sync::OFF, true ), true, false ) . '> ' . esc_html__( 'No actualizar desde la versión maestra', 'wakoo' ) . '</label></p>';
		}
	}

	public static function save_meta( $pid ) {
		if ( ! isset( $_POST['wakoo_lang_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['wakoo_lang_nonce'] ), 'wakoo_lang_box' ) ) { return; }
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $pid ) ) { return; }
		$l = sanitize_key( wp_unslash( $_POST['wakoo_lang'] ?? '' ) );
		$l = self::normalize( $l );
		if ( '' !== $l ) { update_post_meta( $pid, self::LANG, $l ); }
		$g = sanitize_key( wp_unslash( $_POST['wakoo_tr'] ?? '' ) );
		if ( '' === $g ) { delete_post_meta( $pid, self::GROUP ); } else { update_post_meta( $pid, self::GROUP, $g ); }
		if ( empty( $_POST['wakoo_tr_nosync'] ) ) { delete_post_meta( $pid, Sync::OFF ); } else { update_post_meta( $pid, Sync::OFF, 1 ); }
	}

	public static function column( $cols ) {
		$cols['wakoo_lang'] = __( 'Idioma', 'wakoo' );
		return $cols;
	}

	public static function column_value( $col, $pid ) {
		if ( 'wakoo_lang' !== $col ) { return; }
		echo esc_html( strtoupper( self::lang_of( $pid ) ) );
		$pend = Sync::pending_count( get_post_meta( $pid, Sync::MAP, true ) );
		if ( $pend ) { echo ' · <span style="color:#b32d2e">' . esc_html( sprintf( _n( '%d por traducir', '%d por traducir', $pend, 'wakoo' ), $pend ) ) . '</span>'; }
	}

	public static function menu() {
		add_submenu_page( 'wakoo-seo', __( 'Idiomas', 'wakoo' ), __( 'Idiomas', 'wakoo' ), 'manage_options', 'wakoo-idiomas', [ __CLASS__, 'page' ] );
	}

	public static function settings() {
		register_setting( 'wakoo_idiomas', self::OPTION, [ 'sanitize_callback' => 'sanitize_textarea_field' ] );
	}

	/** Which languages are active and which one is the master. */
	public static function languages_form() {
		if ( isset( $_GET['wk_langs'] ) ) { echo '<div class="notice notice-success inline"><p>' . esc_html__( 'Idiomas guardados.', 'wakoo' ) . '</p></div>'; } // phpcs:ignore WordPress.Security.NonceVerification
		$cur = self::languages();
		$def = self::default_lang();
		$all = self::CATALOG;
		$hid  = self::hidden_langs();
		$pdef = self::public_default();
		$extra = [];
		foreach ( $cur as $c => $n ) { if ( ! isset( $all[ $c ] ) ) { $extra[] = $c . '|' . $n; } }
		echo '<h2>' . esc_html__( 'Idiomas del sitio', 'wakoo' ) . '</h2><p>' . esc_html__( 'Marca los idiomas que usa el sitio y elige cuál es el maestro (donde haces los cambios; los demás se rellenan desde él). «Público» decide qué idiomas ve el visitante: puedes dejar el maestro (por ejemplo el español) solo para editar. Quien lo visite es enviado a su traducción en el idioma público por defecto.', 'wakoo' ) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="wakoo_idiomas_langs">';
		wp_nonce_field( 'wakoo_idiomas_langs' );
		echo '<table class="widefat striped" style="max-width:640px"><thead><tr><th>' . esc_html__( 'Activo', 'wakoo' ) . '</th><th>' . esc_html__( 'Idioma', 'wakoo' ) . '</th><th>' . esc_html__( 'Maestro', 'wakoo' ) . '</th><th>' . esc_html__( 'Público', 'wakoo' ) . '</th><th>' . esc_html__( 'Por defecto al visitante', 'wakoo' ) . '</th></tr></thead><tbody>';
		foreach ( $all as $c => $n ) {
			echo '<tr><td><input type="checkbox" name="on[]" value="' . esc_attr( $c ) . '"' . checked( isset( $cur[ $c ] ), true, false ) . '></td><td>' . esc_html( $n ) . ' <code>' . esc_html( $c ) . '</code></td><td><input type="radio" name="def" value="' . esc_attr( $c ) . '"' . checked( $c, $def, false ) . '></td><td><input type="checkbox" name="pub[]" value="' . esc_attr( $c ) . '"' . checked( ! in_array( $c, $hid, true ), true, false ) . '></td><td><input type="radio" name="pubdef" value="' . esc_attr( $c ) . '"' . checked( $c, $pdef, false ) . '></td></tr>';
		}
		echo '</tbody></table><p><label>' . esc_html__( 'Otros idiomas (uno por línea: código|nombre)', 'wakoo' ) . '<br><textarea name="extra" rows="3" cols="30">' . esc_textarea( implode( "\n", $extra ) ) . '</textarea></label></p>';
		submit_button( __( 'Guardar idiomas', 'wakoo' ), 'secondary', 'submit', false );
		echo '</form>';
	}

	public static function save_languages() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'Sin permiso.', 'wakoo' ) ); }
		check_admin_referer( 'wakoo_idiomas_langs' );
		$on  = array_map( 'sanitize_key', (array) ( $_POST['on'] ?? [] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$def = sanitize_key( wp_unslash( $_POST['def'] ?? '' ) );
		$set = [];
		foreach ( self::CATALOG as $c => $n ) { if ( in_array( $c, $on, true ) ) { $set[ $c ] = $n; } }
		foreach ( preg_split( '/\R/', sanitize_textarea_field( wp_unslash( $_POST['extra'] ?? '' ) ) ) as $line ) {
			$p = array_map( 'trim', explode( '|', $line, 2 ) );
			$c = sanitize_key( $p[0] ?? '' );
			if ( $c ) { $set[ $c ] = '' !== ( $p[1] ?? '' ) ? $p[1] : strtoupper( $c ); }
		}
		if ( ! $set ) { $set = [ 'es' => 'Español' ]; }
		if ( ! isset( $set[ $def ] ) ) { $def = array_key_first( $set ); }
		$ordered = [ $def => $set[ $def ] ] + $set;
		$lines   = [];
		foreach ( $ordered as $c => $n ) { $lines[] = $c . '|' . $n; }
		update_option( self::OPTION, implode( "\n", $lines ) );
		$pub    = array_map( 'sanitize_key', (array) ( $_POST['pub'] ?? [] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$pub    = array_values( array_intersect( array_keys( $ordered ), $pub ) );
		$hidden = $pub ? array_values( array_diff( array_keys( $ordered ), $pub ) ) : [];
		update_option( self::HIDDEN, $hidden );
		$pd = sanitize_key( wp_unslash( $_POST['pubdef'] ?? '' ) );
		update_option( self::PUBDEF, in_array( $pd, $pub, true ) ? $pd : '' );
		wp_safe_redirect( add_query_arg( [ 'page' => 'wakoo-idiomas', 'wk_langs' => 1 ], admin_url( 'admin.php' ) ) );
		exit;
	}

	public static function page() {
		echo '<div class="wrap"><h1>' . esc_html__( 'Idiomas', 'wakoo' ) . '</h1>';
		self::languages_form();
		echo '<form method="post" action="options.php">';
		settings_fields( 'wakoo_idiomas' );
		echo '<p>' . esc_html__( 'Selector: shortcode [wakoo_idiomas] (style="list", "codes" o "select") o el widget «Selector de idioma (Wakoo)».', 'wakoo' ) . '</p>';
		$o = Sync::opts();
		$n = Sync::OPTION;
		echo '<h2>' . esc_html__( 'Versión maestra', 'wakoo' ) . '</h2>';
		echo '<p>' . esc_html__( 'La página en el idioma por defecto es la maestra. Al guardarla en Elementor, sus traducciones (mismo grupo) reciben los cambios de diseño, fotos, enlaces y widgets nuevos o borrados. Los textos ya traducidos se conservan, y las correcciones hechas a mano en una traducción se respetan. El diseño se cambia siempre en la maestra.', 'wakoo' ) . '</p>';
		echo '<p><label><input type="checkbox" name="' . esc_attr( $n ) . '[auto]" value="1"' . checked( $o['auto'], true, false ) . '> ' . esc_html__( 'Actualizar las traducciones al guardar la versión maestra', 'wakoo' ) . '</label></p>';
		echo '<p><label>' . esc_html__( 'Traducción automática de los textos nuevos o cambiados', 'wakoo' ) . '<br><select name="' . esc_attr( $n ) . '[provider]">';
		foreach ( [ '' => __( 'Ninguna: copiar el texto y marcarlo «por traducir»', 'wakoo' ), 'deepl' => 'DeepL', 'google' => 'Google Cloud Translation' ] as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $o['provider'], $k, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select></label></p>';
		echo '<p><label>' . esc_html__( 'Clave del servicio', 'wakoo' ) . '<br><input type="password" autocomplete="off" name="' . esc_attr( $n ) . '[key]" value="' . esc_attr( $o['key'] ) . '" style="width:28em"></label><br><span class="description">' . esc_html__( 'DeepL: clave de la cuenta (las del plan gratis terminan en :fx). Google: clave de API con Cloud Translation activado. Los textos se envían a ese servicio para traducirlos.', 'wakoo' ) . '</span></p>';
		$err = get_transient( 'wakoo_idiomas_error' );
		if ( $err ) { echo '<div class="notice notice-error inline"><p>' . esc_html__( 'Último error de traducción:', 'wakoo' ) . ' ' . esc_html( $err ) . '</p></div>'; }
		wp_nonce_field( 'wakoo_idiomas_test', 'wakoo_test_nonce' );
		$tr = isset( $_GET['wk_test'] ) ? get_transient( 'wakoo_idiomas_test_' . get_current_user_id() ) : false; // phpcs:ignore WordPress.Security.NonceVerification
		if ( $tr ) {
			delete_transient( 'wakoo_idiomas_test_' . get_current_user_id() );
			echo '<div class="notice notice-' . ( $tr['ok'] ? 'success' : 'error' ) . ' inline"><p>' . esc_html( $tr['msg'] ) . '</p></div>';
		}
		submit_button( null, 'primary', 'submit', false );
		echo ' <button type="submit" class="button" formaction="' . esc_url( admin_url( 'admin-post.php?action=wakoo_idiomas_test' ) ) . '" name="action" value="wakoo_idiomas_test">' . esc_html__( 'Probar conexión', 'wakoo' ) . '</button>';
		echo '</form>';

		if ( isset( $_GET['wk_synced'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-success inline"><p>' . esc_html( sprintf( __( 'Sincronizadas %d páginas y plantillas maestras.', 'wakoo' ), absint( $_GET['wk_synced'] ) ) ) . '</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="wakoo_idiomas_sync_all">';
		wp_nonce_field( 'wakoo_idiomas_sync_all' );
		submit_button( __( 'Actualizar ahora todas las traducciones', 'wakoo' ), 'secondary', 'submit', false );
		echo '</form>';

		if ( isset( $_GET['wk_import_err'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-error inline"><p>' . esc_html__( 'El archivo no es válido. Sube el archivo .json que descargaste con «Exportar textos por traducir», ya traducido.', 'wakoo' ) . '</p></div>';
		} elseif ( isset( $_GET['wk_imp_done'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-success inline"><p>' . esc_html( sprintf( __( 'Traducciones aplicadas: %1$d. Omitidas: %2$d (sin traducción, ya corregidas a mano o el texto maestro cambió).', 'wakoo' ), absint( $_GET['wk_imp_done'] ), absint( $_GET['wk_imp_skip'] ?? 0 ) ) ) . '</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification
		}
		echo '<p><a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=wakoo-traductor' ) ) . '">' . esc_html__( 'Abrir el Traductor (copiar texto para Claude y pegar su respuesta)', 'wakoo' ) . '</a></p>';
		echo '<h2>' . esc_html__( 'Traducir sin servicio externo', 'wakoo' ) . '</h2><p>' . esc_html__( '1) Descarga los textos por traducir. 2) Súbelos al chat con Claude para que los traduzca. 3) Sube aquí el archivo traducido: se rellenan EN/ZH sin tocar lo que corregiste a mano.', 'wakoo' ) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block;margin-right:16px"><input type="hidden" name="action" value="wakoo_idiomas_export">';
		wp_nonce_field( 'wakoo_idiomas_export' );
		submit_button( __( 'Exportar textos por traducir', 'wakoo' ), 'secondary', 'submit', false );
		echo '</form><form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block"><input type="hidden" name="action" value="wakoo_idiomas_import">';
		wp_nonce_field( 'wakoo_idiomas_import' );
		echo '<input type="file" name="wakoo_tr_file" accept=".json,application/json" required> ';
		submit_button( __( 'Importar traducciones', 'wakoo' ), 'secondary', 'submit', false );
		echo '</form>';

		$rows = get_posts( [ 'post_type' => [ 'page', 'post', 'elementor_library' ], 'post_status' => [ 'publish', 'draft', 'private' ], 'posts_per_page' => 500, 'meta_key' => Sync::MAP ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
		$list = '';
		foreach ( $rows as $r ) {
			$pend = Sync::pending_count( get_post_meta( $r->ID, Sync::MAP, true ) );
			if ( ! $pend ) { continue; }
			$edit  = class_exists( '\Elementor\Plugin' ) ? admin_url( 'post.php?post=' . $r->ID . '&action=elementor' ) : get_edit_post_link( $r->ID );
			$list .= '<li><a href="' . esc_url( $edit ) . '">' . esc_html( get_the_title( $r ) ) . '</a> (' . esc_html( strtoupper( self::lang_of( $r->ID ) ) ) . '): ' . esc_html( sprintf( _n( '%d texto', '%d textos', $pend, 'wakoo' ), $pend ) ) . '</li>';
		}
		echo '<h2>' . esc_html__( 'Textos por traducir', 'wakoo' ) . '</h2>' . ( $list ? '<ul>' . $list . '</ul>' : '<p>' . esc_html__( 'Ninguno.', 'wakoo' ) . '</p>' ) . '</div>';
	}
}

Module::init();
require_once __DIR__ . '/sync.php';
require_once __DIR__ . '/traductor.php';
