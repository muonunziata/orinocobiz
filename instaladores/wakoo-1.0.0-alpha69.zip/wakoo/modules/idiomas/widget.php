<?php
/**
 * "Selector de idioma" widget. Loaded when Elementor registers widgets.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Idiomas;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;

defined( 'ABSPATH' ) || die();

class Widget extends Widget_Base {

	public function get_name() { return 'wakoo-idiomas'; }
	public function get_title() { return __( 'Selector de idioma (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-globe'; }
	public function get_categories() { return [ 'general' ]; }
	public function get_keywords() { return [ 'idioma', 'language', 'traduccion', 'wakoo' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec', [ 'label' => __( 'Selector', 'wakoo' ) ] );
		$this->add_control( 'style', [
			'label'   => __( 'Formato', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'codes',
			'options' => [ 'codes' => __( 'Códigos (ES · EN · 中文)', 'wakoo' ), 'list' => __( 'Nombres', 'wakoo' ), 'dropdown' => __( 'Menú desplegable (botón con el idioma actual)', 'wakoo' ), 'select' => __( 'Lista del navegador (select)', 'wakoo' ) ],
		] );
		$this->add_control( 'label', [ 'label' => __( 'Nombre accesible', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Idioma', 'wakoo' ) ] );
		$this->add_control( 'help', [ 'type' => Controls_Manager::RAW_HTML, 'raw' => __( 'Cada página indica su idioma y su grupo de traducción en el cuadro «Idioma (Wakoo)» del editor de WordPress.', 'wakoo' ), 'content_classes' => 'elementor-descriptor' ] );
		$this->end_controls_section();
		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'color', [ 'label' => __( 'Color', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-langs a, {{WRAPPER}} .wakoo-langs select' => 'color: {{VALUE}};' ] ] );
		$this->add_responsive_control( 'align', [
			'label' => __( 'Alineación', 'wakoo' ), 'type' => Controls_Manager::CHOOSE,
			'options' => [ 'flex-start' => [ 'title' => __( 'Izquierda', 'wakoo' ), 'icon' => 'eicon-text-align-left' ], 'center' => [ 'title' => __( 'Centro', 'wakoo' ), 'icon' => 'eicon-text-align-center' ], 'flex-end' => [ 'title' => __( 'Derecha', 'wakoo' ), 'icon' => 'eicon-text-align-right' ] ],
			'selectors' => [ '{{WRAPPER}} .wakoo-langs:not(.wakoo-langs--dropdown) ul' => 'justify-content: {{VALUE}};' ],
		] );
		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		Module::style();
		echo Module::render( $s['style'] ?? 'codes', $s['label'] ?? '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in render().
	}
}
