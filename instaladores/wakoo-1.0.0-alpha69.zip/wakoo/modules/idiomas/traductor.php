<?php
/**
 * Wakoo Traductor: translate the Spanish master pages with Claude, no external service.
 *
 * 1. Pick master pages → Wakoo clones them into the other languages (texts marked «por traducir») and builds a prompt.
 * 2. The prompt is pasted in the chat; the answer is a JSON that is pasted back here.
 * 3. Preview, then apply: every language version is filled, hand-corrected texts are kept.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Idiomas;

defined( 'ABSPATH' ) || die();

class Traductor {

	const SLUG = 'wakoo-traductor';

	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ], 32 );
		add_action( 'admin_post_wakoo_traductor_prompt', [ __CLASS__, 'action_prompt' ] );
		add_action( 'admin_post_wakoo_traductor_preview', [ __CLASS__, 'action_preview' ] );
		add_action( 'admin_post_wakoo_traductor_apply', [ __CLASS__, 'action_apply' ] );
	}

	public static function menu() {
		add_submenu_page( 'wakoo-seo', __( 'Traductor', 'wakoo' ), __( 'Traductor', 'wakoo' ), 'edit_pages', self::SLUG, [ __CLASS__, 'page' ] );
	}

	public static function url( $args = [] ) {
		return add_query_arg( array_merge( [ 'page' => self::SLUG ], $args ), admin_url( 'admin.php' ) );
	}

	/** Default-language pages, posts and templates built with Elementor. */
	public static function masters() {
		$ids = get_posts( [
			'post_type'      => [ 'page', 'post', 'elementor_library' ],
			'post_status'    => [ 'publish', 'draft', 'private' ],
			'posts_per_page' => 500,
			'orderby'        => 'title',
			'order'          => 'ASC',
			'fields'         => 'ids',
			'meta_key'       => '_elementor_data', // phpcs:ignore WordPress.DB.SlowDBQuery
		] );
		$def = Module::default_lang();
		return array_values( array_filter( $ids, function ( $id ) use ( $def ) { return Module::lang_of( $id ) === $def; } ) );
	}

	/** Pending texts of the given masters, one entry per text with the languages that still need it. */
	public static function entries( array $pids, array $langs = [] ) {
		$by = [];
		foreach ( Sync::pending_items() as $it ) {
			if ( ! in_array( (int) $it['post'], $pids, true ) ) { continue; }
			if ( $langs && ! in_array( $it['lang'], $langs, true ) ) { continue; }
			$id = Sync::item_id( $it['post'], $it['element'], $it['field'], $it['source'] );
			if ( ! isset( $by[ $id ] ) ) {
				$by[ $id ] = [ 'id' => $id, 'page' => $it['page'], 'widget' => $it['widget'], 'field' => $it['field'], Module::default_lang() => $it['source'], 'langs' => [] ];
			}
			$by[ $id ]['langs'][] = $it['lang'];
		}
		return array_values( $by );
	}

	public static function build_prompt( array $entries, array $only = [] ) {
		$def   = Module::default_lang();
		$langs = Module::languages();
		$src   = $langs[ $def ];
		unset( $langs[ $def ] );
		if ( $only ) { $langs = array_intersect_key( $langs, array_flip( $only ) ); }
		$names = [];
		foreach ( $langs as $code => $name ) { $names[] = $code . ' = ' . $name; }
		$codes = implode( ', ', array_keys( $langs ) );
		$tpl   = [ 'id' => '<id>' ];
		foreach ( array_keys( $langs ) as $c ) { $tpl[ $c ] = '…'; }
		$p  = "Eres traductor profesional de sitios web. Traduce los textos de abajo del idioma original (" . $src . ", clave «" . $def . "») a estos idiomas: " . implode( '; ', $names ) . ".\n\n";
		$p .= "REGLAS\n- Traduce con tono natural y de marca, no literal. Cada entrada tiene su página, widget y campo para que entiendas el contexto (un botón es corto, un título es breve, etc.).\n";
		$p .= "- Conserva exactamente las etiquetas HTML, los shortcodes, los {marcadores}, las URL, los números, los correos y los nombres propios o de marca.\n";
		$p .= "" . ( isset( $langs['zh-tw'] ) ? "- El chino es tradicional (zh-tw, como en Taiwán), nunca simplificado.\n" : '' ) . "- Cada texto trae «langs»: tradúcelo solo a esos idiomas (no incluyas los demás).\n- No inventes ni omitas nada. Si un texto no necesita traducción, devuélvelo igual.\n\n";
		$p .= "FORMATO DE RESPUESTA: devuelve SOLO un JSON válido (sin explicaciones, puedes ponerlo en un bloque de código) con esta forma, con una entrada por cada «id» recibido y el «id» copiado tal cual:\n";
		$p .= wp_json_encode( [ 'wakoo_translations' => 2, 'items' => [ $tpl ] ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "\n";
		$p .= "Claves de idioma: " . $codes . " (solo las de «langs» de cada texto).\n\nTEXTOS (" . count( $entries ) . "):\n";
		foreach ( $entries as $e ) { $p .= wp_json_encode( $e, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "\n"; }
		return $p;
	}

	/* ---------- actions ---------- */

	private static function guard( $nonce ) {
		if ( ! current_user_can( 'edit_pages' ) ) { wp_die( esc_html__( 'Sin permiso.', 'wakoo' ) ); }
		check_admin_referer( $nonce );
		if ( function_exists( 'set_time_limit' ) ) { @set_time_limit( 300 ); } // phpcs:ignore WordPress.PHP.NoSilencedErrors
	}

	public static function action_prompt() {
		self::guard( 'wakoo_traductor_prompt' );
		$pids = array_filter( array_map( 'absint', (array) ( $_POST['pages'] ?? [] ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$pids = array_values( array_intersect( $pids, self::masters() ) );
		if ( ! $pids ) { wp_safe_redirect( self::url( [ 'wk_none' => 1 ] ) ); exit; }
		$active = array_diff( array_keys( Module::languages() ), [ Module::default_lang() ] );
		$sel    = [];
		foreach ( $pids as $pid ) {
			$mine = array_values( array_intersect( $active, array_map( 'sanitize_key', (array) ( $_POST['langs'][ $pid ] ?? [] ) ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			if ( ! $mine ) { continue; }
			$sel[ $pid ] = $mine;
			if ( current_user_can( 'edit_post', $pid ) ) { Sync::clone_all( $pid, false, $mine ); }
		}
		if ( ! $sel ) { wp_safe_redirect( self::url( [ 'wk_none' => 1 ] ) ); exit; }
		$pids    = array_keys( $sel );
		$entries = [];
		foreach ( $sel as $pid => $mine ) { $entries = array_merge( $entries, self::entries( [ $pid ], $mine ) ); }
		set_transient( 'wakoo_traductor_prompt_' . get_current_user_id(), [ 'text' => self::build_prompt( $entries, array_values( array_unique( array_merge( ...array_values( $sel ) ) ) ) ), 'n' => count( $entries ), 'pages' => count( $pids ) ], DAY_IN_SECONDS );
		wp_safe_redirect( self::url( [ 'wk_prompt' => 1 ] ) );
		exit;
	}

	public static function action_preview() {
		self::guard( 'wakoo_traductor_preview' );
		$raw   = wp_unslash( $_POST['wakoo_json'] ?? '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$items = strlen( $raw ) < 20 * MB_IN_BYTES ? Sync::parse_json( $raw ) : null;
		if ( ! $items ) { wp_safe_redirect( self::url( [ 'wk_bad' => 1 ] ) ); exit; }
		set_transient( 'wakoo_traductor_json_' . get_current_user_id(), $items, HOUR_IN_SECONDS );
		wp_safe_redirect( self::url( [ 'wk_preview' => 1 ] ) );
		exit;
	}

	public static function action_apply() {
		self::guard( 'wakoo_traductor_apply' );
		$items = get_transient( 'wakoo_traductor_json_' . get_current_user_id() );
		if ( ! is_array( $items ) ) { wp_safe_redirect( self::url( [ 'wk_bad' => 1 ] ) ); exit; }
		$r = Sync::import_items( $items );
		delete_transient( 'wakoo_traductor_json_' . get_current_user_id() );
		wp_safe_redirect( self::url( [ 'wk_done' => $r['done'], 'wk_skip' => $r['skipped'] ] ) );
		exit;
	}

	/* ---------- page ---------- */

	public static function page() {
		$uid = get_current_user_id();
		echo '<div class="wrap"><h1>' . esc_html__( 'Traductor', 'wakoo' ) . '</h1>';
		echo '<p>' . esc_html__( 'Crea tus páginas en español (maestras). Aquí eliges cuáles traducir, copias el texto que se genera, lo pegas en el chat con Claude y pegas de vuelta su respuesta. Las demás versiones se rellenan solas y no se pisa lo que corregiste a mano.', 'wakoo' ) . '</p>';

		if ( isset( $_GET['wk_none'] ) ) { echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Marca al menos una página.', 'wakoo' ) . '</p></div>'; } // phpcs:ignore WordPress.Security.NonceVerification
		if ( isset( $_GET['wk_bad'] ) ) { echo '<div class="notice notice-error inline"><p>' . esc_html__( 'No pude leer la respuesta. Pega el JSON completo que te devolvió Claude (con o sin el bloque de código).', 'wakoo' ) . '</p></div>'; } // phpcs:ignore WordPress.Security.NonceVerification
		if ( isset( $_GET['wk_done'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-success inline"><p>' . esc_html( sprintf( __( 'Traducciones aplicadas: %1$d. Omitidas: %2$d (ya corregidas a mano, sin traducción o el texto maestro cambió).', 'wakoo' ), absint( $_GET['wk_done'] ), absint( $_GET['wk_skip'] ?? 0 ) ) ) . '</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification
		}

		// 1. choose pages
		echo '<h2>' . esc_html__( '1. Elige las páginas', 'wakoo' ) . '</h2>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="wakoo_traductor_prompt">';
		wp_nonce_field( 'wakoo_traductor_prompt' );
		$masters = self::masters();
		if ( ! $masters ) {
			echo '<p>' . esc_html__( 'Todavía no hay páginas maestras hechas con Elementor.', 'wakoo' ) . '</p>';
		} else {
			echo '<table class="widefat striped" style="max-width:760px"><thead><tr><td class="check-column"><input type="checkbox" onclick="document.querySelectorAll(\'.wk-tr-pg\').forEach(function(c){c.checked=this.checked}.bind(this))"></td><th>' . esc_html__( 'Página', 'wakoo' ) . '</th><th>' . esc_html__( 'Traducir a', 'wakoo' ) . '</th><th>' . esc_html__( 'Por traducir', 'wakoo' ) . '</th></tr></thead><tbody>';
			$langs = Module::languages();
			foreach ( $masters as $id ) {
				$tr   = Module::translations( $id );
				$pend = 0;
				foreach ( $tr as $l => $tid ) { if ( $tid !== $id ) { $pend += Sync::pending_count( get_post_meta( $tid, Sync::MAP, true ) ); } }
				$chk  = '';
				foreach ( Module::page_langs( $id ) as $l ) {
					$chk .= '<label style="margin-right:10px"><input type="checkbox" name="langs[' . (int) $id . '][]" value="' . esc_attr( $l ) . '" checked> ' . esc_html( $langs[ $l ] ?? $l ) . ( isset( $tr[ $l ] ) ? ' ✓' : '' ) . '</label>';
				}
				foreach ( array_diff( array_keys( $langs ), [ Module::default_lang() ], Module::page_langs( $id ) ) as $l ) {
					$chk .= '<label style="margin-right:10px;opacity:.7"><input type="checkbox" name="langs[' . (int) $id . '][]" value="' . esc_attr( $l ) . '"> ' . esc_html( $langs[ $l ] ?? $l ) . '</label>';
				}
				$tpl  = 'elementor_library' === get_post_type( $id ) ? ' <em>(' . esc_html__( 'plantilla', 'wakoo' ) . ')</em>' : '';
				echo '<tr><th class="check-column"><input type="checkbox" class="wk-tr-pg" name="pages[]" value="' . esc_attr( $id ) . '"></th><td>' . esc_html( get_the_title( $id ) ) . $tpl . '</td><td>' . $chk . '</td><td>' . ( $pend ? esc_html( $pend ) : '—' ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '</tbody></table>';
			echo '<p class="description">' . esc_html__( 'Al generar el texto, Wakoo crea las versiones que falten en los otros idiomas (como borrador).', 'wakoo' ) . '</p>';
			submit_button( __( 'Generar texto para Claude', 'wakoo' ), 'primary', 'submit', false );
		}
		echo '</form>';

		// 2. prompt
		$pr = get_transient( 'wakoo_traductor_prompt_' . $uid );
		if ( is_array( $pr ) ) {
			echo '<h2>' . esc_html__( '2. Copia esto y pégalo en el chat con Claude', 'wakoo' ) . '</h2>';
			if ( ! $pr['n'] ) {
				echo '<div class="notice notice-info inline"><p>' . esc_html__( 'No hay textos por traducir en esas páginas: ya están al día.', 'wakoo' ) . '</p></div>';
			} else {
				echo '<p>' . esc_html( sprintf( __( '%1$d textos de %2$d páginas · %3$s caracteres.', 'wakoo' ), $pr['n'], $pr['pages'], number_format_i18n( strlen( $pr['text'] ) ) ) ) . '</p>';
				echo '<textarea id="wk-tr-prompt" readonly rows="10" style="width:100%;max-width:900px;font-family:monospace">' . esc_textarea( $pr['text'] ) . '</textarea><p><button type="button" class="button button-primary" onclick="var t=document.getElementById(\'wk-tr-prompt\');t.select();(navigator.clipboard?navigator.clipboard.writeText(t.value):Promise.reject()).catch(function(){document.execCommand(\'copy\')});this.textContent=\'' . esc_js( __( '¡Copiado!', 'wakoo' ) ) . '\'">' . esc_html__( 'Copiar', 'wakoo' ) . '</button></p>';
			}
		}

		// 3. paste back
		echo '<h2>' . esc_html__( '3. Pega aquí la respuesta de Claude', 'wakoo' ) . '</h2>';
		$items = get_transient( 'wakoo_traductor_json_' . $uid );
		if ( isset( $_GET['wk_preview'] ) && is_array( $items ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$r = Sync::import_items( $items, true );
			$by = [];
			foreach ( $r['by_lang'] as $l => $n ) { $by[] = ( Module::languages()[ $l ] ?? $l ) . ': ' . $n; }
			echo '<div class="notice notice-info inline"><p><strong>' . esc_html__( 'Vista previa', 'wakoo' ) . '</strong><br>' . esc_html( sprintf( __( 'Se rellenarán %1$d textos (%3$s). Se omitirán %2$d (sin traducción, corregidos a mano o cuyo texto maestro cambió).', 'wakoo' ), $r['done'], $r['skipped'], implode( ', ', $by ) ) ) . '</p></div>';
			if ( $r['done'] ) {
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="wakoo_traductor_apply">';
				wp_nonce_field( 'wakoo_traductor_apply' );
				submit_button( __( 'Aplicar traducciones', 'wakoo' ), 'primary', 'submit', false );
				echo '</form>';
			}
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="wakoo_traductor_preview">';
		wp_nonce_field( 'wakoo_traductor_preview' );
		echo '<textarea name="wakoo_json" rows="8" style="width:100%;max-width:900px;font-family:monospace" placeholder="{&quot;wakoo_translations&quot;: 2, &quot;items&quot;: [ … ]}"></textarea>';
		submit_button( __( 'Vista previa', 'wakoo' ), 'secondary', 'submit', false );
		echo '</form></div>';
	}
}

Traductor::init();
