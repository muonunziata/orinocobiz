<?php
/**
 * Wakoo Idiomas · Sincronización: the default-language page is the master copy.
 *
 * When a page (or saved template) in the default language is saved with Elementor, its
 * translations receive the same structure: layout, images, styles, links, new and removed
 * widgets. Texts stay translated. Each translation remembers, per element and field, the
 * source text it was translated from (`_wakoo_tr_map`), so only the texts that changed are
 * translated again: with DeepL or Google when a key is configured, otherwise the new text
 * is copied as is and marked "por traducir". Editing a text in a translation by hand
 * updates that memory, so the correction survives the next sync.
 *
 * Values that differ by language without being text (links, menus, templates) are learned
 * the first time two existing pages are aligned, and links to pages are mapped through
 * their translation groups.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Idiomas;

defined( 'ABSPATH' ) || die();

class Sync {

	const MAP    = '_wakoo_tr_map';
	const OFF    = '_wakoo_tr_nosync';
	const BACKUP = '_wakoo_tr_backup';
	const STALE  = '_wakoo_tr_stale';
	const VALUES = 'wakoo_idiomas_values';
	const OPTION = 'wakoo_idiomas_sync';

	const TEXT_TYPES = [ 'text', 'textarea', 'wysiwyg' ];

	/** Post fields translated with the content, stored under this pseudo element id. */
	const POST = '_post';

	private static $busy = false;
	private static $controls = [];
	private static $links = [];

	public static function init() {
		add_action( 'elementor/document/before_save', [ __CLASS__, 'before_save' ], 10, 1 );
		add_action( 'elementor/document/after_save', [ __CLASS__, 'after_save' ], 20, 1 );
		add_action( 'admin_post_wakoo_idiomas_sync_all', [ __CLASS__, 'action_sync_all' ] );
		add_action( 'admin_post_wakoo_idiomas_make', [ __CLASS__, 'action_make' ] );
		add_action( 'admin_post_wakoo_idiomas_test', [ __CLASS__, 'action_test' ] );
		add_action( 'admin_post_wakoo_idiomas_five', [ __CLASS__, 'action_five' ] );
		add_action( 'admin_post_wakoo_idiomas_export', [ __CLASS__, 'action_export' ] );
		add_action( 'admin_post_wakoo_idiomas_import', [ __CLASS__, 'action_import' ] );
		// «Replicar en todos los idiomas» from any language version.
		add_action( 'admin_post_wakoo_idiomas_replicate', [ __CLASS__, 'action_replicate' ] );
		add_action( 'wp_ajax_wakoo_idiomas_replicate', [ __CLASS__, 'ajax_replicate' ] );
		add_action( 'admin_notices', [ __CLASS__, 'replicate_notice' ] );
		add_filter( 'page_row_actions', [ __CLASS__, 'row_action' ], 10, 2 );
		add_filter( 'post_row_actions', [ __CLASS__, 'row_action' ], 10, 2 );
		add_action( 'elementor/documents/register_controls', [ __CLASS__, 'editor_controls' ] );
		add_action( 'elementor/editor/after_enqueue_scripts', [ __CLASS__, 'editor_script' ] );
		add_action( 'admin_init', [ __CLASS__, 'register_setting' ] );
		add_action( 'added_post_meta', [ __CLASS__, 'meta_written' ], 10, 3 );
		add_action( 'updated_post_meta', [ __CLASS__, 'meta_written' ], 10, 3 );
	}

	/**
	 * A translation whose content was written by something else (an import, another plugin,
	 * the editor) is learned again on the next sync, so its current texts are kept.
	 */
	public static function meta_written( $meta_id, $pid, $key ) {
		if ( self::$busy || '_elementor_data' !== $key || ! metadata_exists( 'post', $pid, self::MAP ) ) { return; }
		update_post_meta( $pid, self::STALE, 1 );
	}

	/* ---------- settings ---------- */

	public static function opts() {
		$o = get_option( self::OPTION, [] );
		$o = is_array( $o ) ? $o : [];
		return [
			'auto'     => ! isset( $o['auto'] ) || ! empty( $o['auto'] ),
			'provider' => in_array( $o['provider'] ?? '', [ 'deepl', 'google' ], true ) ? $o['provider'] : '',
			'key'      => (string) ( $o['key'] ?? '' ),
		];
	}

	public static function register_setting() {
		register_setting( 'wakoo_idiomas', self::OPTION, [ 'sanitize_callback' => [ __CLASS__, 'sanitize' ] ] );
	}

	public static function sanitize( $in ) {
		$in = is_array( $in ) ? $in : [];
		return [
			'auto'     => empty( $in['auto'] ) ? 0 : 1,
			'provider' => in_array( $in['provider'] ?? '', [ 'deepl', 'google' ], true ) ? $in['provider'] : '',
			'key'      => sanitize_text_field( $in['key'] ?? '' ),
		];
	}

	public static function has_provider() {
		$o = self::opts();
		return ( $o['provider'] && $o['key'] ) || has_filter( 'wakoo_idiomas_translate' );
	}

	/* ---------- hooks ---------- */

	public static function after_save( $document ) {
		if ( self::$busy || ! $document ) { return; }
		$pid = (int) $document->get_main_id();
		if ( ! $pid || (int) $document->get_post()->ID !== $pid ) { return; } // autosave / revision
		if ( Module::lang_of( $pid ) === Module::default_lang() ) {
			if ( self::opts()['auto'] ) { self::sync_from( $pid ); }
		} else {
			self::learn_manual( $pid );
		}
	}

	/**
	 * Before a translation that was never synced (or was written from outside, e.g. an import) is saved,
	 * learn it as it is now. The memory then tells which texts the person edits (needed to replicate them).
	 */
	public static function before_save( $document ) {
		if ( self::$busy || ! $document ) { return; }
		$pid = (int) $document->get_main_id();
		if ( ! $pid || (int) $document->get_post()->ID !== $pid ) { return; }
		$def = Module::default_lang();
		if ( Module::lang_of( $pid ) === $def ) {
			self::prime( $pid ); // The master is about to change: its translations learn it as it still is.
			return;
		}
		$mid = (int) ( Module::translations( $pid )[ $def ] ?? 0 );
		if ( $mid ) { self::prime_one( $mid, $pid ); }
	}

	/** Every translation of $mid without a reliable memory learns it against the master as it is now. */
	private static function prime( $mid, $skip = 0 ) {
		foreach ( Module::translations( $mid ) as $lang => $id ) {
			if ( $id !== $mid && $id !== $skip ) { self::prime_one( $mid, $id ); }
		}
	}

	private static function prime_one( $mid, $id ) {
		$map = get_post_meta( $id, self::MAP, true );
		if ( is_array( $map ) && $map && ! get_post_meta( $id, self::STALE, true ) ) { return; }
		$old = self::data( $id );
		if ( ! $old ) { return; }
		$lang = Module::lang_of( $id );
		$prev = is_array( $map ) ? $map : [];
		$map  = self::learn( self::only_for( self::data( $mid ), $lang ), $old, $lang );
		$map[ self::POST ] = self::learn_post( $mid, $id );
		// Texts still waiting for a translation stay marked.
		foreach ( $prev as $eid => $paths ) {
			foreach ( (array) $paths as $path => $e ) {
				if ( isset( $map[ $eid ][ $path ] ) && is_array( $e ) && ! empty( $e['p'] ) && ( $e['t'] ?? null ) === $map[ $eid ][ $path ]['t'] ) { $map[ $eid ][ $path ]['p'] = true; }
			}
		}
		update_post_meta( $id, self::MAP, wp_slash( $map ) );
		delete_post_meta( $id, self::STALE );
	}

	/** Syncs every translation of a default-language post. Returns [ lang => [ id, translated, pending ] ]. */
	public static function sync_from( $pid ) {
		$out = [];
		$only = Module::page_langs( $pid );
		foreach ( Module::translations( $pid ) as $lang => $id ) {
			if ( $id === $pid || ! in_array( $lang, $only, true ) || get_post_meta( $id, self::OFF, true ) ) { continue; }
			$out[ $lang ] = array_merge( [ $id ], self::sync( $pid, $id, $lang ) );
		}
		return $out;
	}

	/* ---------- core ---------- */

	private static function data( $pid ) {
		$raw = get_post_meta( $pid, '_elementor_data', true );
		$d   = is_string( $raw ) ? json_decode( $raw, true ) : $raw;
		return is_array( $d ) ? $d : [];
	}

	/** Copies $src_id into its translation $dst_id. Returns [ translated now, pending ]. */
	public static function sync( $src_id, $dst_id, $lang ) {
		$src = self::only_for( self::data( $src_id ), $lang );
		if ( ! $src ) { return [ 0, 0 ]; }

		$map = get_post_meta( $dst_id, self::MAP, true );
		if ( ! is_array( $map ) || get_post_meta( $dst_id, self::STALE, true ) ) {
			// First sync, or content written from outside: learn the translation as it is now by aligning both trees.
			$prev = is_array( $map ) ? $map : null;
			$map  = [];
			$old  = self::data( $dst_id );
			if ( $old ) {
				if ( null === $prev ) { update_post_meta( $dst_id, self::BACKUP, wp_slash( get_post_meta( $dst_id, '_elementor_data', true ) ) ); }
				$map = self::learn( $src, $old, $lang );
			}
			$map[ self::POST ] = self::learn_post( $src_id, $dst_id );
			// Texts still waiting for a translation stay marked; a text whose master changed since the last sync
			// keeps its old source, so it is detected as changed below instead of being learned as translated.
			foreach ( (array) $prev as $id => $paths ) {
				foreach ( (array) $paths as $path => $e ) {
					if ( ! isset( $map[ $id ][ $path ] ) || ! is_array( $e ) || ! isset( $e['s'] ) ) { continue; }
					if ( ! empty( $e['p'] ) && $map[ $id ][ $path ]['t'] === $e['t'] ) { $map[ $id ][ $path ]['p'] = true; }
					if ( $e['s'] !== $map[ $id ][ $path ]['s'] ) { $map[ $id ][ $path ]['s'] = $e['s']; $map[ $id ][ $path ]['t'] = $e['t']; }
				}
			}
			delete_post_meta( $dst_id, self::STALE );
		}

		$retry = self::has_provider();
		$todo  = [];
		$used  = [];
		$check = function ( $id, $path, $v ) use ( &$map, &$todo, &$used, $retry ) {
			$used[ $id ][ $path ] = true;
			$e = $map[ $id ][ $path ] ?? null;
			if ( $e && $e['s'] === $v && ! ( ! empty( $e['p'] ) && $retry ) ) { return; }
			$todo[] = [ $id, $path, $v ];
		};
		self::walk( $src, function ( &$v, $id, $path, $text ) use ( $check ) {
			if ( $text ) { $check( $id, $path, $v ); }
		}, $lang );
		$post = self::post_fields( $src_id );
		foreach ( $post as $k => $v ) { $check( self::POST, $k, $v ); }

		// Translate what is new or changed; without a service the source text is kept and marked.
		$done = 0;
		if ( $todo ) {
			$res = self::translate( array_column( $todo, 2 ), $lang );
			foreach ( $todo as $i => $t ) {
				$ok = is_array( $res ) && isset( $res[ $i ] ) && '' !== $res[ $i ];
				$map[ $t[0] ][ $t[1] ] = [ 's' => $t[2], 't' => $ok ? $res[ $i ] : $t[2], 'p' => ! $ok, 'a' => $ok, 'w' => $ok ? $res[ $i ] : $t[2] ];
				$done += $ok ? 1 : 0;
			}
		}

		// Forget texts that are gone from the source.
		foreach ( $map as $id => $paths ) {
			foreach ( array_keys( (array) $paths ) as $path ) {
				if ( empty( $used[ $id ][ $path ] ) ) { unset( $map[ $id ][ $path ] ); }
			}
			if ( empty( $map[ $id ] ) ) { unset( $map[ $id ] ); }
		}

		$new = $src;
		self::walk( $new, function ( &$v, $id, $path, $text, $key ) use ( $map, $lang ) {
			if ( $text ) {
				$v = self::links_in_html( $map[ $id ][ $path ]['t'] ?? $v, $lang );
			} else {
				$v = self::map_value( $key, $v, $lang );
			}
		}, $lang );

		$settings = get_post_meta( $src_id, '_elementor_page_settings', true );
		$settings = is_array( $settings ) ? $settings : [];
		array_walk_recursive( $settings, function ( &$v, $key ) use ( $lang ) { $v = self::map_value( (string) $key, $v, $lang ); } );
		if ( isset( $map[ self::POST ]['title'] ) ) { $settings['post_title'] = $map[ self::POST ]['title']['t']; }

		self::$busy = true;
		$doc = class_exists( '\Elementor\Plugin' ) ? \Elementor\Plugin::$instance->documents->get( $dst_id, false ) : null;
		$saved = $doc ? $doc->save( [ 'elements' => $new, 'settings' => $settings ] ) : false;
		if ( ! $saved ) {
			// No editing rights in this request (e.g. cron): write the data directly.
			update_post_meta( $dst_id, '_elementor_data', wp_slash( wp_json_encode( $new ) ) );
			if ( isset( $settings['post_title'] ) ) { wp_update_post( [ 'ID' => $dst_id, 'post_title' => $settings['post_title'] ] ); }
			if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) { \Elementor\Core\Files\CSS\Post::create( $dst_id )->delete(); }
		}
		foreach ( [ 'seo_title' => '_wakoo_seo_title', 'seo_desc' => '_wakoo_seo_desc' ] as $k => $meta ) {
			if ( isset( $map[ self::POST ][ $k ] ) ) {
				update_post_meta( $dst_id, $meta, wp_slash( $map[ self::POST ][ $k ]['t'] ) );
			} else {
				delete_post_meta( $dst_id, $meta );
			}
		}
		update_post_meta( $dst_id, self::MAP, wp_slash( $map ) );
		self::$busy = false;

		return [ $done, self::pending_count( $map ) ];
	}

	private static function post_fields( $pid ) {
		$out = [ 'title' => (string) get_post_field( 'post_title', $pid ) ];
		foreach ( [ 'seo_title' => '_wakoo_seo_title', 'seo_desc' => '_wakoo_seo_desc' ] as $k => $meta ) {
			$v = (string) get_post_meta( $pid, $meta, true );
			if ( '' !== $v ) { $out[ $k ] = $v; }
		}
		return array_filter( $out, [ __CLASS__, 'has_letters' ] );
	}

	private static function learn_post( $src_id, $dst_id ) {
		$out = [];
		$dst = self::post_fields( $dst_id );
		foreach ( self::post_fields( $src_id ) as $k => $v ) {
			if ( isset( $dst[ $k ] ) ) { $out[ $k ] = [ 's' => $v, 't' => $dst[ $k ], 'p' => false ]; }
		}
		return $out;
	}

	public static function pending_count( $map ) {
		$n = 0;
		foreach ( (array) $map as $paths ) {
			foreach ( (array) $paths as $e ) { $n += empty( $e['p'] ) ? 0 : 1; }
		}
		return $n;
	}

	/**
	 * Learns an existing translation: elements in the same place with the same type are the
	 * same element. Text fields give the translation memory; other values that differ
	 * (links, menus, templates) are stored as value pairs for this language.
	 */
	private static function learn( array $src, array $dst, $lang ) {
		$pairs = [];
		self::align( $src, $dst, $pairs );
		$map    = [];
		$values = get_option( self::VALUES, [] );
		$values = is_array( $values ) ? $values : [];
		foreach ( $pairs as $p ) {
			$a = self::leaves( $p[0], $lang );
			$b = self::leaves( $p[1], $lang );
			foreach ( $a as $ipath => $l ) {
				if ( ! isset( $b[ $ipath ] ) ) { continue; }
				$d = $b[ $ipath ]['v'];
				if ( $l['text'] ) {
					$map[ $p[0]['id'] ][ $l['path'] ] = [ 's' => $l['v'], 't' => (string) $d, 'p' => false, 'w' => (string) $d ];
				} elseif ( $l['v'] !== $d && self::learnable( $l['k'], $l['v'] ) ) {
					$values[ $lang ][ $l['k'] . "\x1f" . $l['v'] ] = $d;
					if ( self::is_template_key( $l['k'] ) ) { self::link_templates( (int) $l['v'], (int) $d, $lang ); }
				}
			}
		}
		update_option( self::VALUES, $values, false );
		return $map;
	}

	/** template_id, template_id_2, foot_template_id…: values that hold a saved template ID. */
	private static function is_template_key( $key ) {
		return (bool) preg_match( '/(^|_)template_id(_\d+)?$/', (string) $key );
	}

	/** Puts two saved templates in the same translation group, so editing the master header also updates the others. */
	private static function link_templates( $a, $b, $lang ) {
		if ( ! $a || ! $b || ! get_post( $a ) || ! get_post( $b ) ) { return; }
		$g = (string) get_post_meta( $a, Module::GROUP, true );
		if ( '' === $g ) {
			$g = (string) get_post_meta( $b, Module::GROUP, true );
			$g = '' !== $g ? $g : 'tpl-' . $a;
			update_post_meta( $a, Module::GROUP, $g );
		}
		update_post_meta( $b, Module::GROUP, $g );
		if ( ! get_post_meta( $a, Module::LANG, true ) ) { update_post_meta( $a, Module::LANG, Module::default_lang() ); }
		if ( ! get_post_meta( $b, Module::LANG, true ) ) { update_post_meta( $b, Module::LANG, $lang ); }
	}

	private static function align( array $src, array $dst, array &$pairs ) {
		foreach ( array_values( $src ) as $i => $s ) {
			$d = array_values( $dst )[ $i ] ?? null;
			if ( ! is_array( $d ) || ( $s['elType'] ?? '' ) !== ( $d['elType'] ?? '' ) || ( $s['widgetType'] ?? '' ) !== ( $d['widgetType'] ?? '' ) ) { continue; }
			$pairs[] = [ $s, $d ];
			self::align( $s['elements'] ?? [], $d['elements'] ?? [], $pairs );
		}
	}

	/** [ index path => [ v, text, k, path ] ] of one element, without its children. */
	private static function leaves( array $el, $lang ) {
		$el['elements'] = [];
		$els = [ $el ];
		$out = [];
		self::walk( $els, function ( &$v, $id, $path, $text, $key, $ipath ) use ( &$out ) {
			$out[ $ipath ] = [ 'v' => $v, 'text' => $text, 'k' => $key, 'path' => $path ];
		}, $lang );
		return $out;
	}

	/**
	 * Non-text values worth remembering per language: the saved template, the menu, the form
	 * name and links that are not media files. Everything else (images, sizes, colors) comes
	 * from the master as is.
	 */
	private static function learnable( $key, $v ) {
		if ( ( ! is_string( $v ) && ! is_int( $v ) ) || '' === $v ) { return false; }
		$keys = apply_filters( 'wakoo_idiomas_value_keys', [ 'template_id', 'menu', 'form_name', 'link.url' ] );
		if ( ! in_array( $key, $keys, true ) && ! preg_match( '/(^|_)link\.url$/', $key ) && ! self::is_template_key( $key ) ) { return false; }
		return false === strpos( (string) $v, '/wp-content/uploads/' );
	}

	/** A text in a translation edited by hand becomes the translation of the current source text. */
	public static function learn_manual( $pid ) {
		$map = get_post_meta( $pid, self::MAP, true );
		if ( ! is_array( $map ) ) { return; }
		delete_post_meta( $pid, self::STALE );
		$changed = false;
		$data    = self::data( $pid );
		$check   = function ( $id, $path, $v ) use ( &$map, &$changed ) {
			if ( ! isset( $map[ $id ][ $path ] ) || $map[ $id ][ $path ]['t'] === $v ) { return; }
			$map[ $id ][ $path ] = [ 's' => $map[ $id ][ $path ]['s'], 't' => $v, 'p' => false, 'm' => true, 'w' => $map[ $id ][ $path ]['w'] ?? $map[ $id ][ $path ]['t'] ];
			$changed = true;
		};
		self::walk( $data, function ( &$v, $id, $path, $text ) use ( $check ) {
			if ( $text ) { $check( $id, $path, $v ); }
		}, Module::lang_of( $pid ) );
		foreach ( self::post_fields( $pid ) as $k => $v ) { $check( self::POST, $k, $v ); }
		if ( $changed ) { update_post_meta( $pid, self::MAP, wp_slash( $map ) ); }
	}

	/* ---------- walking Elementor data ---------- */

	/**
	 * Calls $fn( &$value, $element_id, $path, $is_text, $key, $index_path ) for every scalar setting,
	 * repeaters and link/image arrays included. Repeater rows are named by their _id in $path
	 * and by their position in $index_path. Elements shown only in $lang (Advanced → Idioma)
	 * are already written in that language, so their texts are not treated as text.
	 */
	private static function walk( array &$els, callable $fn, $lang = '', $frozen = false ) {
		foreach ( $els as &$el ) {
			if ( ! is_array( $el ) ) { continue; }
			$id  = (string) ( $el['id'] ?? '' );
			$wt  = (string) ( $el['widgetType'] ?? '' );
			$ctl = self::controls( $el );
			$fz  = $frozen || ( '' !== $lang && $lang === ( $el['settings']['wk_lang_only'] ?? '' ) );
			if ( isset( $el['settings'] ) && is_array( $el['settings'] ) ) {
				foreach ( $el['settings'] as $key => &$val ) {
					if ( '__dynamic__' === $key || '__globals__' === $key ) { continue; }
					$c = $ctl[ $key ] ?? [];
					if ( is_array( $val ) && 'repeater' === ( $c['type'] ?? '' ) ) {
						$fields = [];
						foreach ( (array) ( $c['fields'] ?? [] ) as $f ) { if ( isset( $f['name'] ) ) { $fields[ $f['name'] ] = $f; } }
						$n = 0;
						foreach ( $val as $i => &$row ) {
							if ( ! is_array( $row ) ) { continue; }
							$rid = (string) ( $row['_id'] ?? $i );
							foreach ( $row as $rk => &$rv ) {
								if ( '_id' === $rk || '__dynamic__' === $rk ) { continue; }
								self::leaf( $rv, $id, $key . '/' . $rid . '/' . $rk, ! $fz && self::is_text( $rk, $fields[ $rk ] ?? [], $wt ), $rk, $fn, $key . '/#' . $n . '/' . $rk );
							}
							$n++;
							unset( $rv );
						}
						unset( $row );
						continue;
					}
					self::leaf( $val, $id, $key, ! $fz && self::is_text( $key, $c, $wt ), $key, $fn, $key );
				}
				unset( $val );
			}
			if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) { self::walk( $el['elements'], $fn, $lang, $fz ); }
		}
		unset( $el );
	}

	private static function leaf( &$v, $id, $path, $text, $key, callable $fn, $ipath ) {
		if ( is_array( $v ) ) {
			foreach ( $v as $k => &$x ) {
				if ( is_scalar( $x ) ) { $fn( $x, $id, $path . '.' . $k, false, $key . '.' . $k, $ipath . '.' . $k ); }
			}
			unset( $x );
			return;
		}
		if ( is_scalar( $v ) ) { $fn( $v, $id, $path, $text && is_string( $v ) && self::has_letters( $v ), $key, $ipath ); }
	}

	/** Drops the elements set to show only in another language (Advanced → Idioma). */
	private static function only_for( array $els, $lang ) {
		$out = [];
		foreach ( $els as $el ) {
			$only = is_array( $el ) ? (string) ( $el['settings']['wk_lang_only'] ?? '' ) : '';
			if ( '' !== $only && $only !== $lang ) { continue; }
			if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) { $el['elements'] = self::only_for( $el['elements'], $lang ); }
			$out[] = $el;
		}
		return $out;
	}

	private static function has_letters( $v ) {
		return is_string( $v ) && preg_match( '/\p{L}/u', wp_strip_all_tags( preg_replace( '/\[[^\]]*\]/', '', $v ) ) );
	}

	/** Visible text: text, textarea and editor controls, plus the HTML widget. Ids, classes, CSS, addresses and shortcodes are not. */
	private static function is_text( $key, $control, $widget ) {
		$key = (string) $key;
		if ( '' === $key || '_' === $key[0] || preg_match( '/css|class|(^|_)id$|anchor|shortcode|email_to|slug|url|form_name|custom_|attributes|(^|_)(key|token|api)$/', $key ) ) { return false; }
		if ( 'html' === $key && 'html' === $widget ) { return true; }
		$type = (string) ( $control['type'] ?? '' );
		return in_array( $type, self::TEXT_TYPES, true ) && ! empty( apply_filters( 'wakoo_idiomas_is_text', true, $key, $control, $widget ) );
	}

	private static function controls( array $el ) {
		$type = 'widget' === ( $el['elType'] ?? '' ) ? 'w:' . ( $el['widgetType'] ?? '' ) : 'e:' . ( $el['elType'] ?? '' );
		if ( isset( self::$controls[ $type ] ) ) { return self::$controls[ $type ]; }
		$out = [];
		if ( class_exists( '\Elementor\Plugin' ) ) {
			$p   = \Elementor\Plugin::$instance;
			$obj = 'w:' === substr( $type, 0, 2 ) ? $p->widgets_manager->get_widget_types( $el['widgetType'] ?? '' ) : $p->elements_manager->get_element_types( $el['elType'] ?? '' );
			if ( $obj ) { $out = (array) $obj->get_controls(); }
		}
		return self::$controls[ $type ] = $out;
	}

	/* ---------- values and links by language ---------- */

	private static function map_value( $key, $v, $lang ) {
		if ( ! is_string( $v ) && ! is_int( $v ) ) { return $v; }
		$values = get_option( self::VALUES, [] );
		$k = $key . "\x1f" . $v;
		if ( isset( $values[ $lang ][ $k ] ) ) { return $values[ $lang ][ $k ]; }
		if ( self::is_template_key( $key ) && is_numeric( $v ) ) {
			$tr = Module::translations( (int) $v );
			if ( isset( $tr[ $lang ] ) ) { return is_int( $v ) ? $tr[ $lang ] : (string) $tr[ $lang ]; }
		}
		if ( is_string( $v ) && '' !== $v ) {
			$links = self::links( $lang );
			$n     = untrailingslashit( $v );
			if ( isset( $links[ $n ] ) ) { return $links[ $n ]; }
		}
		return $v;
	}

	/** [ default-language permalink without trailing slash => permalink in $lang ]. */
	private static function links( $lang ) {
		if ( isset( self::$links[ $lang ] ) ) { return self::$links[ $lang ]; }
		$out = [];
		$ids = get_posts( [
			'post_type'      => 'any',
			'post_status'    => [ 'publish', 'draft', 'private' ],
			'posts_per_page' => 500,
			'fields'         => 'ids',
			'meta_key'       => Module::GROUP, // phpcs:ignore WordPress.DB.SlowDBQuery
		] );
		$def = Module::default_lang();
		foreach ( $ids as $id ) {
			if ( Module::lang_of( $id ) !== $def || 'elementor_library' === get_post_type( $id ) ) { continue; }
			$tr = Module::translations( $id );
			if ( isset( $tr[ $lang ] ) ) {
				$from = get_permalink( $id );
				$to   = get_permalink( $tr[ $lang ] );
				$out[ untrailingslashit( $from ) ] = $to;
				$out[ untrailingslashit( wp_make_link_relative( $from ) ) ] = wp_make_link_relative( $to );
			}
		}
		unset( $out[''] );
		return self::$links[ $lang ] = $out;
	}

	private static function links_in_html( $html, $lang ) {
		if ( ! is_string( $html ) || false === stripos( $html, 'href' ) ) { return $html; }
		$links = self::links( $lang );
		return preg_replace_callback( '/href=(["\'])(.*?)\1/i', function ( $m ) use ( $links ) {
			$n = untrailingslashit( html_entity_decode( $m[2] ) );
			return isset( $links[ $n ] ) ? 'href=' . $m[1] . esc_attr( $links[ $n ] ) . $m[1] : $m[0];
		}, $html );
	}

	/* ---------- replicate from any language ---------- */

	/**
	 * «Replicar en todos los idiomas» from any language version: $pid becomes the model.
	 * 1. Its structure goes to the default-language master. Texts not edited since the last sync keep
	 *    the master's words; new or edited ones are translated into the master language (DeepL / Google)
	 *    or copied as they are. Links, menus and templates are mapped back to the master language, and
	 *    the master's elements reserved to other languages (Avanzado → Idioma) stay where they were.
	 * 2. The master is synced to every translation as usual; $pid keeps its own texts.
	 * Returns [ ok, msg, master, copied (texts left in the model's language), langs (as sync_from) ].
	 */
	public static function replicate( $pid, $force = false ) {
		$def  = Module::default_lang();
		$lang = Module::lang_of( $pid );
		$mid  = (int) ( Module::translations( $pid )[ $def ] ?? 0 );
		$name = Module::languages()[ $def ] ?? $def;
		if ( ! $mid ) {
			/* translators: %s: master language */
			return [ 'ok' => false, 'msg' => sprintf( __( 'Esta página no tiene versión en %s (el idioma maestro). Revisa su «Grupo de traducción» en el cuadro «Idioma (Wakoo)».', 'wakoo' ), $name ) ];
		}
		if ( $mid === (int) $pid ) {
			return [ 'ok' => true, 'msg' => '', 'master' => $mid, 'copied' => [], 'langs' => self::sync_from( $mid ) ];
		}
		$page   = self::data( $pid );
		$master = self::data( $mid );
		if ( ! $page ) {
			return [ 'ok' => false, 'msg' => __( 'Esta página no tiene contenido de Elementor.', 'wakoo' ) ];
		}
		// The same page in two languages shares its element ids. If they do not, copying would lose every translation.
		$a = self::ids( $page );
		$b = self::ids( $master );
		if ( $b && count( array_intersect_key( $a, $b ) ) < 0.5 * min( count( $a ), count( $b ) ) ) {
			/* translators: %s: master language */
			return [ 'ok' => false, 'msg' => sprintf( __( 'Esta versión no comparte la estructura con la versión en %s, así que no se puede replicar sin perder las traducciones. Haz el cambio en la versión en %s o usa allí «Clonar esta página a los demás idiomas».', 'wakoo' ), $name, $name ) ];
		}
		$map  = get_post_meta( $pid, self::MAP, true );
		$map  = is_array( $map ) ? $map : [];
		$base = self::baseline( $pid, $mid, $lang, $map );

		// Texts of the master as they are now, by element and field.
		$mtext = [];
		self::walk( $master, function ( &$v, $id, $path, $text ) use ( &$mtext ) {
			if ( $text ) { $mtext[ $id ][ $path ] = $v; }
		}, $def );

		// The model with the master's words where nothing was edited; edited or new texts go back to the master language.
		// Its list rows take the ids of the master's rows in the same place (the editor gives new ids to rows
		// that had none), so texts match the master and the translations keep theirs.
		$new  = self::align_rows( $page, $master );
		$todo = [];
		$dflt = self::text_defaults( $page );
		$strip = [];
		self::walk( $new, function ( &$v, $id, $path, $text, $key ) use ( $base, $mtext, $dflt, $lang, &$todo, &$strip ) {
			if ( ! $text ) {
				$v = self::unmap_value( $key, $v, $lang );
				return;
			}
			// The master has this text and it was not edited (or the memory does not know it: then it is not
			// counted as edited, so an old or partial memory never sends texts by mistake): the master's words stay.
			if ( isset( $mtext[ $id ][ $path ] ) && ( ! isset( $base['texts'][ $id ][ $path ] ) || $base['texts'][ $id ][ $path ] === $v ) ) {
				$v = $mtext[ $id ][ $path ];
				return;
			}
			// A field the master does not have holding the control's default: the editor wrote the default when
			// saving (e.g. «Anterior», «I am a tooltip»); it is not a change and needs no translation.
			if ( ! isset( $mtext[ $id ][ $path ] ) && self::is_default( $dflt, $id, $path, $v ) ) {
				$strip[ $id ][ $path ] = true; // Left out: the master and the translations keep using the default.
				return;
			}
			$todo[ $id . "\x1f" . $path ] = $v;
		}, $lang );
		$total = 0;
		self::walk( $page, function ( &$v, $id, $path, $text ) use ( &$total ) { $total += $text ? 1 : 0; }, $lang );
		if ( ! $force && count( $todo ) > 20 && count( $todo ) > 0.5 * $total ) {
			/* translators: 1: changed texts, 2: all texts, 3: master language */
			return [ 'ok' => false, 'many' => true, 'msg' => sprintf( __( 'Parece que cambiaron casi todos los textos de esta página (%1$d de %2$d). Si replicas, la versión en %3$s recibirá esos textos y los demás idiomas tendrán que traducirlos de nuevo. Revisa que sea lo que quieres.', 'wakoo' ), count( $todo ), $total, $name ) ];
		}
		$new    = self::strip_settings( $new, $strip );
		$back   = [];
		$copied = [];
		if ( $todo ) {
			$res = self::translate( array_values( $todo ), $def, $lang );
			$i   = 0;
			foreach ( $todo as $k => $v ) {
				$ok         = is_array( $res ) && isset( $res[ $i ] ) && '' !== $res[ $i ];
				$back[ $k ] = self::unlinks_in_html( $ok ? $res[ $i ] : $v, $lang );
				if ( ! $ok ) { $copied[] = wp_strip_all_tags( $v ); }
				$i++;
			}
			self::walk( $new, function ( &$v, $id, $path, $text ) use ( $back ) {
				if ( $text && isset( $back[ $id . "\x1f" . $path ] ) ) { $v = $back[ $id . "\x1f" . $path ]; }
			}, $lang );
		}
		$new = self::keep_reserved( $new, $master, $lang );

		$settings = get_post_meta( $pid, '_elementor_page_settings', true );
		$settings = is_array( $settings ) ? $settings : [];
		array_walk_recursive( $settings, function ( &$v, $key ) use ( $lang ) { $v = self::unmap_value( (string) $key, $v, $lang ); } );
		$settings['post_title'] = get_post_field( 'post_title', $mid );

		// The other translations learn the master as it still is, so its changes are seen as changes.
		self::prime( $mid, $pid );

		// Save the master (a copy of what it had stays in _wakoo_tr_backup).
		self::$busy = true;
		update_post_meta( $mid, self::BACKUP, wp_slash( get_post_meta( $mid, '_elementor_data', true ) ) );
		$doc   = class_exists( '\Elementor\Plugin' ) ? \Elementor\Plugin::$instance->documents->get( $mid, false ) : null;
		$saved = $doc ? $doc->save( [ 'elements' => $new, 'settings' => $settings ] ) : false;
		if ( ! $saved ) {
			update_post_meta( $mid, '_elementor_data', wp_slash( wp_json_encode( $new ) ) );
			if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) { \Elementor\Core\Files\CSS\Post::create( $mid )->delete(); }
		}

		// The model keeps its texts: each one becomes the translation of the master's new text.
		$ntext = [];
		self::walk( $new, function ( &$v, $id, $path, $text ) use ( &$ntext ) {
			if ( $text ) { $ntext[ $id ][ $path ] = $v; }
		}, $lang );
		// Title and SEO fields of the model stay exactly as they are now.
		$keep = [ self::POST => self::learn_post( $mid, $pid ) ];
		$ptext = [];
		self::walk( $page, function ( &$v, $id, $path, $text, $key, $ipath ) use ( &$ptext ) {
			if ( $text ) { $ptext[ $id ][ $ipath ] = $v; }
		}, $lang );
		self::walk( $new, function ( &$v, $id, $path, $text, $key, $ipath ) use ( $ntext, $ptext, &$keep ) {
			if ( ! $text || ! isset( $ntext[ $id ][ $path ], $ptext[ $id ][ $ipath ] ) ) { return; }
			$t = $ptext[ $id ][ $ipath ];
			$keep[ $id ][ $path ] = [ 's' => $ntext[ $id ][ $path ], 't' => $t, 'p' => false, 'w' => $t ];
		}, $lang );
		update_post_meta( $pid, self::MAP, wp_slash( $keep ) );
		delete_post_meta( $pid, self::STALE );
		self::$busy = false;

		return [ 'ok' => true, 'msg' => '', 'master' => $mid, 'copied' => $copied, 'langs' => self::sync_from( $mid ), 'guess' => $base['guess'] ];
	}

	/**
	 * Texts of the model as they were after the last sync: [ texts => [ id => [ path => text ] ], guess => bool ].
	 * From the memory when there is one ('w', or 't' in memories older than alpha68) and it is not out of date.
	 * For a page without a usable memory (e.g. imported already translated and edited before this button existed), from its previous
	 * revision, but only if that revision is clearly the same page. Otherwise the current texts (then only the
	 * structure and new elements are replicated, and 'guess' is true).
	 */
	private static function baseline( $pid, $mid, $lang, array $map ) {
		$out = [];
		foreach ( $map as $id => $paths ) {
			if ( self::POST === $id ) { continue; }
			foreach ( (array) $paths as $path => $e ) {
				if ( is_array( $e ) && isset( $e['t'] ) ) { $out[ $id ][ $path ] = $e['w'] ?? $e['t']; }
			}
		}
		if ( $out && ! get_post_meta( $pid, self::STALE, true ) ) {
			return [ 'texts' => $out, 'guess' => false ];
		}
		$now = [];
		self::walk( self::data( $pid ), function ( &$v, $id, $path, $text ) use ( &$now ) {
			if ( $text ) { $now[ $id ][ $path ] = $v; }
		}, $lang );
		$count = function ( array $t ) { return array_sum( array_map( 'count', $t ) ); };
		$raw_now = (string) get_post_meta( $pid, '_elementor_data', true );
		foreach ( wp_get_post_revisions( $pid, [ 'posts_per_page' => 10 ] ) as $rev ) {
			$raw = (string) get_post_meta( $rev->ID, '_elementor_data', true );
			if ( '' === $raw || $raw === $raw_now ) { continue; }
			$old = json_decode( $raw, true );
			if ( ! is_array( $old ) ) { break; }
			$texts = [];
			foreach ( self::learn( self::only_for( self::data( $mid ), $lang ), $old, $lang ) as $id => $paths ) {
				foreach ( (array) $paths as $path => $e ) { $texts[ $id ][ $path ] = $e['t']; }
			}
			// Same page only if most of its texts are still there unchanged.
			$same = 0;
			foreach ( $now as $id => $paths ) {
				foreach ( $paths as $path => $v ) { $same += ( isset( $texts[ $id ][ $path ] ) && $texts[ $id ][ $path ] === $v ) ? 1 : 0; }
			}
			if ( $same >= 0.6 * $count( $now ) ) {
				return [ 'texts' => $texts, 'guess' => false ];
			}
			break; // Only the revision just before the current content counts.
		}
		return [ 'texts' => $now, 'guess' => true ];
	}

	/** [ element id => [ key => default, key/field => default ] ] of the text controls of every element. */
	private static function text_defaults( array $els, array &$out = [] ) {
		foreach ( $els as $el ) {
			if ( ! is_array( $el ) ) { continue; }
			foreach ( self::controls( $el ) as $key => $c ) {
				if ( isset( $c['default'] ) && is_string( $c['default'] ) ) { $out[ (string) ( $el['id'] ?? '' ) ][ $key ] = $c['default']; }
				foreach ( (array) ( $c['fields'] ?? [] ) as $f ) {
					if ( isset( $f['name'], $f['default'] ) && is_string( $f['default'] ) ) { $out[ (string) ( $el['id'] ?? '' ) ][ $key . '/' . $f['name'] ] = $f['default']; }
				}
			}
			if ( ! empty( $el['elements'] ) ) { self::text_defaults( (array) $el['elements'], $out ); }
		}
		return $out;
	}

	/** Removes the settings listed in $strip ([ id => [ key => true ] ]; rows of lists stay). */
	private static function strip_settings( array $els, array $strip ) {
		if ( ! $strip ) { return $els; }
		foreach ( $els as &$el ) {
			if ( ! is_array( $el ) ) { continue; }
			foreach ( array_keys( $strip[ (string) ( $el['id'] ?? '' ) ] ?? [] ) as $path ) {
				if ( false === strpos( $path, '/' ) ) { unset( $el['settings'][ $path ] ); }
			}
			if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) { $el['elements'] = self::strip_settings( $el['elements'], $strip ); }
		}
		unset( $el );
		return $els;
	}

	/** $v is the default of the control at $path ('key' or 'key/row/field'). */
	private static function is_default( array $dflt, $id, $path, $v ) {
		$parts = explode( '/', (string) $path );
		$k     = 3 === count( $parts ) ? $parts[0] . '/' . $parts[2] : $parts[0];
		return isset( $dflt[ $id ][ $k ] ) && $dflt[ $id ][ $k ] === $v;
	}

	/** The rows of every list (repeater) in $els take the _id of the row in the same place in $master. */
	private static function align_rows( array $els, array $master ) {
		$by = [];
		$index = function ( array $list ) use ( &$index, &$by ) {
			foreach ( $list as $el ) {
				if ( ! is_array( $el ) ) { continue; }
				if ( isset( $el['id'] ) ) { $by[ (string) $el['id'] ] = (array) ( $el['settings'] ?? [] ); }
				if ( ! empty( $el['elements'] ) ) { $index( (array) $el['elements'] ); }
			}
		};
		$index( $master );
		$fix = function ( array &$list ) use ( &$fix, $by ) {
			foreach ( $list as &$el ) {
				if ( ! is_array( $el ) ) { continue; }
				$ms = $by[ (string) ( $el['id'] ?? '' ) ] ?? null;
				if ( $ms && ! empty( $el['settings'] ) && is_array( $el['settings'] ) ) {
					foreach ( $el['settings'] as $key => &$rows ) {
						if ( ! is_array( $rows ) || ! isset( $ms[ $key ] ) || ! is_array( $ms[ $key ] ) ) { continue; }
						$mrows = array_values( $ms[ $key ] );
						foreach ( array_values( array_keys( $rows ) ) as $n => $k ) {
							if ( ! is_array( $rows[ $k ] ) || ! isset( $rows[ $k ]['_id'] ) || ! is_array( $mrows[ $n ] ?? null ) ) { continue; }
							if ( isset( $mrows[ $n ]['_id'] ) ) {
								$rows[ $k ]['_id'] = $mrows[ $n ]['_id'];
							} else {
								unset( $rows[ $k ]['_id'] ); // The master's row has none: both are matched by position.
							}
						}
					}
					unset( $rows );
				}
				if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) { $fix( $el['elements'] ); }
			}
			unset( $el );
		};
		$fix( $els );
		return $els;
	}

	/** [ element id => true ] of every element in a tree. */
	private static function ids( array $els, array &$out = [] ) {
		foreach ( $els as $el ) {
			if ( ! is_array( $el ) ) { continue; }
			if ( isset( $el['id'] ) ) { $out[ (string) $el['id'] ] = true; }
			if ( ! empty( $el['elements'] ) ) { self::ids( (array) $el['elements'], $out ); }
		}
		return $out;
	}

	/** Puts back, in the same parent and place, the master's elements reserved to other languages (the model never had them). */
	private static function keep_reserved( array $new, array $master, $lang ) {
		$index = function () use ( &$new ) {
			$by = [];
			foreach ( $new as $i => $el ) { if ( is_array( $el ) && isset( $el['id'] ) ) { $by[ (string) $el['id'] ] = $i; } }
			return $by;
		};
		$new = array_values( $new );
		$by  = $index();
		foreach ( array_values( $master ) as $i => $m ) {
			if ( ! is_array( $m ) ) { continue; }
			$id   = (string) ( $m['id'] ?? '' );
			$only = (string) ( $m['settings']['wk_lang_only'] ?? '' );
			if ( '' !== $only && $only !== $lang ) {
				if ( ! isset( $by[ $id ] ) ) {
					array_splice( $new, min( $i, count( $new ) ), 0, [ $m ] );
					$by = $index();
				}
				continue;
			}
			if ( isset( $by[ $id ] ) && ! empty( $m['elements'] ) ) {
				$new[ $by[ $id ] ]['elements'] = self::keep_reserved( (array) ( $new[ $by[ $id ] ]['elements'] ?? [] ), (array) $m['elements'], $lang );
			}
		}
		return $new;
	}

	/** The value of $lang back in the default language (the reverse of map_value). */
	private static function unmap_value( $key, $v, $lang ) {
		if ( ( ! is_string( $v ) && ! is_int( $v ) ) || '' === $v ) { return $v; }
		static $rev = [];
		if ( ! isset( $rev[ $lang ] ) ) {
			$rev[ $lang ] = [];
			$values       = get_option( self::VALUES, [] );
			foreach ( (array) ( $values[ $lang ] ?? [] ) as $k => $to ) {
				$p = strpos( $k, "\x1f" );
				if ( false !== $p && ( is_string( $to ) || is_int( $to ) ) ) { $rev[ $lang ][ substr( $k, 0, $p ) . "\x1f" . $to ] = substr( $k, $p + 1 ); }
			}
		}
		if ( isset( $rev[ $lang ][ $key . "\x1f" . $v ] ) ) {
			$src = $rev[ $lang ][ $key . "\x1f" . $v ];
			return is_int( $v ) && is_numeric( $src ) ? (int) $src : $src;
		}
		if ( self::is_template_key( $key ) && is_numeric( $v ) ) {
			$tr = Module::translations( (int) $v );
			$def = Module::default_lang();
			if ( isset( $tr[ $def ] ) ) { return is_int( $v ) ? $tr[ $def ] : (string) $tr[ $def ]; }
		}
		if ( is_string( $v ) ) {
			$links = self::back_links( $lang );
			$n     = untrailingslashit( $v );
			if ( isset( $links[ $n ] ) ) { return '/' === substr( $v, -1 ) ? trailingslashit( $links[ $n ] ) : $links[ $n ]; }
		}
		return $v;
	}

	/** [ permalink in $lang without trailing slash => default-language permalink ]. */
	private static function back_links( $lang ) {
		$out = [];
		foreach ( self::links( $lang ) as $from => $to ) { $out[ untrailingslashit( $to ) ] = $from; }
		return $out;
	}

	private static function unlinks_in_html( $html, $lang ) {
		if ( ! is_string( $html ) || false === stripos( $html, 'href' ) ) { return $html; }
		$links = self::back_links( $lang );
		return preg_replace_callback( '/href=(["\'])(.*?)\1/i', function ( $m ) use ( $links ) {
			$n = untrailingslashit( html_entity_decode( $m[2] ) );
			return isset( $links[ $n ] ) ? 'href=' . $m[1] . esc_attr( $links[ $n ] ) . $m[1] : $m[0];
		}, $html );
	}

	/** Short summary of a replicate() result, for notices. */
	public static function replicate_message( array $r ) {
		if ( empty( $r['ok'] ) ) { return $r['msg']; }
		$names = Module::languages();
		$bits  = [];
		foreach ( (array) $r['langs'] as $l => $x ) {
			/* translators: 1: language, 2: texts waiting for a translation */
			$bits[] = ( $names[ $l ] ?? $l ) . ( ! empty( $x[2] ) ? ' (' . sprintf( _n( '%d texto por traducir', '%d textos por traducir', $x[2], 'wakoo' ), $x[2] ) . ')' : '' );
		}
		/* translators: %s: list of languages */
		$msg = sprintf( __( 'Cambios replicados en: %s.', 'wakoo' ), implode( ', ', $bits ) );
		if ( ! empty( $r['guess'] ) ) {
			$msg .= ' ' . __( 'No se sabía qué textos habías cambiado antes (esta página nunca se había sincronizado y no hay una revisión anterior): se replicaron el diseño y los elementos nuevos, pero los textos que ya existían conservan su traducción en cada idioma.', 'wakoo' );
		}
		if ( ! empty( $r['copied'] ) ) {
			$def = $names[ Module::default_lang() ] ?? Module::default_lang();
			/* translators: 1: number of texts, 2: master language */
			$msg .= ' ' . sprintf( _n( '%1$d texto nuevo quedó sin traducir en la versión en %2$s (no hay DeepL ni Google configurado): revísalo allí.', '%1$d textos nuevos quedaron sin traducir en la versión en %2$s (no hay DeepL ni Google configurado): revísalos allí.', count( $r['copied'] ), 'wakoo' ), count( $r['copied'] ), $def );
		}
		return $msg;
	}

	/** Button in the WordPress editor box and in the page list. */
	public static function action_replicate() {
		$pid = absint( $_GET['post'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! $pid || ! current_user_can( 'edit_post', $pid ) ) { wp_die( esc_html__( 'Sin permiso.', 'wakoo' ) ); }
		check_admin_referer( 'wakoo_idiomas_replicate_' . $pid );
		if ( function_exists( 'set_time_limit' ) ) { @set_time_limit( 300 ); } // phpcs:ignore WordPress.PHP.NoSilencedErrors
		$r = self::replicate( $pid, ! empty( $_GET['force'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		set_transient( 'wakoo_idiomas_replicated_' . get_current_user_id(), [ 'ok' => ! empty( $r['ok'] ), 'msg' => self::replicate_message( $r ), 'force' => ! empty( $r['many'] ) ? self::replicate_url( $pid ) . '&force=1' : '' ], 300 );
		$back = wp_get_referer();
		wp_safe_redirect( $back ? $back : get_edit_post_link( $pid, 'url' ) );
		exit;
	}

	/** Button in the Elementor editor (Ajustes de la página → Idiomas). */
	public static function ajax_replicate() {
		$pid = absint( $_POST['post'] ?? 0 );
		check_ajax_referer( 'wakoo_idiomas_replicate', 'nonce' );
		if ( ! $pid || ! current_user_can( 'edit_post', $pid ) ) { wp_send_json_error( [ 'msg' => __( 'Sin permiso.', 'wakoo' ) ], 403 ); }
		if ( function_exists( 'set_time_limit' ) ) { @set_time_limit( 300 ); } // phpcs:ignore WordPress.PHP.NoSilencedErrors
		$r = self::replicate( $pid, ! empty( $_POST['force'] ) );
		$m = self::replicate_message( $r );
		if ( empty( $r['ok'] ) ) { wp_send_json_error( [ 'msg' => $m, 'many' => ! empty( $r['many'] ) ] ); }
		wp_send_json_success( [ 'msg' => $m ] );
	}

	public static function replicate_url( $pid ) {
		return wp_nonce_url( admin_url( 'admin-post.php?action=wakoo_idiomas_replicate&post=' . $pid ), 'wakoo_idiomas_replicate_' . $pid );
	}

	/** Notice after replicating from the editor box or the page list. */
	public static function replicate_notice() {
		$k = 'wakoo_idiomas_replicated_' . get_current_user_id();
		$r = get_transient( $k );
		if ( ! is_array( $r ) ) { return; }
		delete_transient( $k );
		echo '<div class="notice notice-' . ( $r['ok'] ? 'success' : 'error' ) . ' is-dismissible"><p>' . esc_html( $r['msg'] ) . '</p>'
			. ( ! empty( $r['force'] ) ? '<p><a class="button" href="' . esc_url( $r['force'] ) . '">' . esc_html__( 'Replicar igualmente', 'wakoo' ) . '</a></p>' : '' ) . '</div>';
	}

	public static function row_action( $actions, $post ) {
		if ( current_user_can( 'edit_post', $post->ID ) && count( Module::translations( $post->ID ) ) > 1 && get_post_meta( $post->ID, '_elementor_data', true ) ) {
			$actions['wakoo_replicate'] = '<a href="' . esc_url( self::replicate_url( $post->ID ) ) . '" onclick="return confirm(' . esc_attr( wp_json_encode( __( 'Los cambios de esta página (diseño, fotos, secciones y textos editados) se copiarán a todos los idiomas. ¿Continuar?', 'wakoo' ) ) ) . ')">' . esc_html__( 'Replicar en todos los idiomas', 'wakoo' ) . '</a>';
		}
		return $actions;
	}

	/** Elementor editor: Ajustes de la página → «Idiomas (Wakoo)» with the button. */
	public static function editor_controls( $document ) {
		if ( ! $document instanceof \Elementor\Core\Base\Document ) { return; }
		$pid = (int) $document->get_main_id();
		if ( ! $pid || count( Module::translations( $pid ) ) < 2 ) { return; }
		$document->start_controls_section( 'wakoo_idiomas_section', [ 'label' => __( 'Idiomas (Wakoo)', 'wakoo' ), 'tab' => \Elementor\Controls_Manager::TAB_SETTINGS ] );
		$document->add_control( 'wakoo_idiomas_replicate', [
			'type'        => \Elementor\Controls_Manager::BUTTON,
			'text'        => __( 'Replicar en todos los idiomas', 'wakoo' ),
			'button_type' => 'success',
			'event'       => 'wakoo:idiomas:replicate',
			'label_block' => true,
			'description' => __( 'Guarda esta página y copia sus cambios (diseño, fotos, secciones y textos editados) a todas sus versiones en otros idiomas. Cada idioma conserva sus traducciones; los textos nuevos se traducen con DeepL o Google si están configurados.', 'wakoo' ),
		] );
		$document->end_controls_section();
	}

	public static function editor_script() {
		$cfg = [
			'ajax'    => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'wakoo_idiomas_replicate' ),
			'confirm' => __( 'Los cambios de esta página se copiarán a todos los idiomas. ¿Continuar?', 'wakoo' ),
			'working' => __( 'Replicando en todos los idiomas…', 'wakoo' ),
			'error'   => __( 'No se pudo replicar.', 'wakoo' ),
			'again'   => __( '¿Replicar igualmente?', 'wakoo' ),
		];
		wp_add_inline_script( 'elementor-editor', '(function(c){if(window.wkReplicateBound){return;}window.wkReplicateBound=1;'
			. 'function note(m,ok){elementor.notifications.showToast({message:m,classes:ok?"":"elementor-error"});}'
			. 'function send(id,force){var b=new URLSearchParams({action:"wakoo_idiomas_replicate",nonce:c.nonce,post:id,force:force?1:0});'
			. 'return fetch(c.ajax,{method:"POST",credentials:"same-origin",body:b}).then(function(r){return r.json();}).then(function(j){'
			. 'var m=(j&&j.data&&j.data.msg)||c.error;if(j&&!j.success&&j.data&&j.data.many&&!force){if(window.confirm(m+"\n\n"+c.again)){note(c.working,true);return send(id,true);}note(m,false);return;}note(m,!!(j&&j.success));});}'
			. 'function run(){if(!window.confirm(c.confirm)){return;}var id=elementor.documents.getCurrent().id;note(c.working,true);'
			. 'Promise.resolve($e.run("document/save/default",{force:true})).then(function(){return send(id,false);}).catch(function(){note(c.error,false);});}'
			. 'function bind(){elementor.channels.editor.on("wakoo:idiomas:replicate",run);}'
			. 'if(window.elementor&&elementor.channels){bind();}else{window.addEventListener("elementor/init",bind);}})(' . wp_json_encode( $cfg ) . ');', 'after' );
	}

	/* ---------- machine translation ---------- */

	/** Translated strings in the same order, or null when no service is available or it failed. $src: default language. */
	public static function translate( array $texts, $lang, $src = null ) {
		$texts = array_values( $texts );
		$src   = $src ? $src : Module::default_lang();
		$out   = apply_filters( 'wakoo_idiomas_translate', null, $texts, $lang, $src );
		if ( is_array( $out ) ) { return array_values( $out ); }
		$o = self::opts();
		if ( ! $o['provider'] || ! $o['key'] ) { return null; }
		$res = [];
		foreach ( array_chunk( $texts, 'deepl' === $o['provider'] ? 50 : 100 ) as $chunk ) {
			$part = 'deepl' === $o['provider'] ? self::deepl( $chunk, $src, $lang, $o['key'] ) : self::google( $chunk, $src, $lang, $o['key'] );
			if ( ! is_array( $part ) || count( $part ) !== count( $chunk ) ) { return null; }
			$res = array_merge( $res, $part );
		}
		foreach ( $res as $i => $t ) {
			// Plain texts come back with entities (&#39;); texts with markup keep them.
			if ( false === strpos( $texts[ $i ], '<' ) ) { $res[ $i ] = html_entity_decode( $t, ENT_QUOTES | ENT_HTML5, 'UTF-8' ); }
		}
		return $res;
	}

	private static function fail( $msg ) {
		set_transient( 'wakoo_idiomas_error', $msg, DAY_IN_SECONDS );
		return null;
	}

	private static function deepl( array $texts, $src, $lang, $key ) {
		$target = [ 'en' => 'EN-US', 'zh' => 'ZH-HANS', 'zh-tw' => 'ZH-HANT', 'zh-hk' => 'ZH-HANT', 'pt' => 'PT-BR' ][ $lang ] ?? strtoupper( $lang );
		$host   = ':fx' === substr( $key, -3 ) ? 'https://api-free.deepl.com' : 'https://api.deepl.com';
		$r = wp_remote_post( $host . '/v2/translate', [
			'timeout' => 25,
			'headers' => [ 'Authorization' => 'DeepL-Auth-Key ' . $key, 'Content-Type' => 'application/json' ],
			'body'    => wp_json_encode( [ 'text' => $texts, 'source_lang' => strtoupper( strtok( $src, '-' ) ), 'target_lang' => $target, 'tag_handling' => 'html' ] ),
		] );
		if ( is_wp_error( $r ) ) { return self::fail( 'DeepL: ' . $r->get_error_message() ); }
		$b = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( 200 !== wp_remote_retrieve_response_code( $r ) || empty( $b['translations'] ) ) {
			return self::fail( 'DeepL: ' . wp_remote_retrieve_response_code( $r ) . ' ' . ( $b['message'] ?? '' ) );
		}
		return array_column( $b['translations'], 'text' );
	}

	private static function google( array $texts, $src, $lang, $key ) {
		$target = [ 'zh' => 'zh-CN', 'zh-tw' => 'zh-TW', 'zh-hk' => 'zh-TW' ][ $lang ] ?? $lang;
		$r = wp_remote_post( 'https://translation.googleapis.com/language/translate/v2?key=' . rawurlencode( $key ), [
			'timeout' => 25,
			'headers' => [ 'Content-Type' => 'application/json' ],
			'body'    => wp_json_encode( [ 'q' => $texts, 'source' => [ 'zh' => 'zh-CN', 'zh-tw' => 'zh-TW', 'zh-hk' => 'zh-TW' ][ $src ] ?? $src, 'target' => $target, 'format' => 'html' ] ),
		] );
		if ( is_wp_error( $r ) ) { return self::fail( 'Google: ' . $r->get_error_message() ); }
		$b = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( 200 !== wp_remote_retrieve_response_code( $r ) || empty( $b['data']['translations'] ) ) {
			return self::fail( 'Google: ' . wp_remote_retrieve_response_code( $r ) . ' ' . ( $b['error']['message'] ?? '' ) );
		}
		return array_column( $b['data']['translations'], 'translatedText' );
	}


	/* ---------- connection test ---------- */

	/** Test the provider/key typed in the form (not saved) with a tiny translation. */
	public static function test_connection( $provider, $key ) {
		$key = trim( (string) $key );
		if ( ! in_array( $provider, [ 'deepl', 'google' ], true ) ) { return [ false, __( 'Elige primero DeepL o Google en «Traducción automática».', 'wakoo' ) ]; }
		if ( '' === $key ) { return [ false, __( 'Falta la clave del servicio. Pégala en el campo «Clave del servicio» y vuelve a probar.', 'wakoo' ) ]; }
		if ( 'deepl' === $provider ) {
			$free = ':fx' === substr( $key, -3 );
			$host = $free ? 'https://api-free.deepl.com' : 'https://api.deepl.com';
			$name = $free ? 'DeepL (plan gratis)' : 'DeepL (plan Pro)';
			$r = wp_remote_post( $host . '/v2/translate', [
				'timeout' => 20,
				'headers' => [ 'Authorization' => 'DeepL-Auth-Key ' . $key, 'Content-Type' => 'application/json' ],
				'body'    => wp_json_encode( [ 'text' => [ 'Hola, ¿cómo estás?' ], 'source_lang' => 'ES', 'target_lang' => 'EN-US' ] ),
			] );
			if ( is_wp_error( $r ) ) { return [ false, sprintf( /* translators: 1: service 2: error */ __( 'No se pudo conectar con %1$s: %2$s. Comprueba que tu servidor puede salir a Internet (api%3$s.deepl.com).', 'wakoo' ), $name, $r->get_error_message(), $free ? '-free' : '' ) ]; }
			$code = (int) wp_remote_retrieve_response_code( $r );
			$b    = json_decode( wp_remote_retrieve_body( $r ), true );
			if ( 200 === $code && ! empty( $b['translations'][0]['text'] ) ) {
				$msg = sprintf( __( 'Conexión correcta con %1$s. Prueba: «Hola, ¿cómo estás?» → «%2$s».', 'wakoo' ), $name, $b['translations'][0]['text'] );
				$u = wp_remote_get( $host . '/v2/usage', [ 'timeout' => 15, 'headers' => [ 'Authorization' => 'DeepL-Auth-Key ' . $key ] ] );
				if ( ! is_wp_error( $u ) && 200 === (int) wp_remote_retrieve_response_code( $u ) ) {
					$ub = json_decode( wp_remote_retrieve_body( $u ), true );
					if ( isset( $ub['character_count'], $ub['character_limit'] ) ) { $msg .= ' ' . sprintf( __( 'Uso este periodo: %1$s de %2$s caracteres.', 'wakoo' ), number_format_i18n( (int) $ub['character_count'] ), number_format_i18n( (int) $ub['character_limit'] ) ); }
				}
				return [ true, $msg ];
			}
			$map = [
				403 => __( 'DeepL rechazó la clave (403). Revisa que sea la clave de API (no la contraseña de la cuenta) y que la hayas copiado completa. Las del plan gratis terminan en :fx.', 'wakoo' ),
				401 => __( 'DeepL rechazó la clave (401).', 'wakoo' ),
				456 => __( 'Se agotó la cuota de caracteres de tu plan DeepL (456).', 'wakoo' ),
				429 => __( 'DeepL recibió demasiadas peticiones seguidas (429). Espera un momento y prueba otra vez.', 'wakoo' ),
				400 => __( 'DeepL no aceptó la petición (400).', 'wakoo' ),
			];
			$msg = $map[ $code ] ?? sprintf( __( 'DeepL respondió con el código %d.', 'wakoo' ), $code );
			if ( ! empty( $b['message'] ) ) { $msg .= ' ' . sanitize_text_field( $b['message'] ); }
			return [ false, $msg ];
		}
		$r = wp_remote_post( 'https://translation.googleapis.com/language/translate/v2?key=' . rawurlencode( $key ), [
			'timeout' => 20,
			'headers' => [ 'Content-Type' => 'application/json' ],
			'body'    => wp_json_encode( [ 'q' => [ 'Hola, ¿cómo estás?' ], 'source' => 'es', 'target' => 'en', 'format' => 'text' ] ),
		] );
		if ( is_wp_error( $r ) ) { return [ false, sprintf( __( 'No se pudo conectar con Google Cloud Translation: %s. Comprueba que tu servidor puede salir a Internet.', 'wakoo' ), $r->get_error_message() ) ]; }
		$code = (int) wp_remote_retrieve_response_code( $r );
		$b    = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( 200 === $code && ! empty( $b['data']['translations'][0]['translatedText'] ) ) {
			return [ true, sprintf( __( 'Conexión correcta con Google Cloud Translation. Prueba: «Hola, ¿cómo estás?» → «%s».', 'wakoo' ), html_entity_decode( $b['data']['translations'][0]['translatedText'], ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) ];
		}
		$msg = sprintf( __( 'Google respondió con el código %d.', 'wakoo' ), $code );
		if ( ! empty( $b['error']['message'] ) ) { $msg .= ' ' . sanitize_text_field( $b['error']['message'] ); }
		if ( in_array( $code, [ 400, 403 ], true ) ) { $msg .= ' ' . __( 'Revisa que la clave sea correcta y que Cloud Translation API esté activada en tu proyecto.', 'wakoo' ); }
		return [ false, $msg ];
	}

	public static function action_test() {
		if ( ! current_user_can( 'manage_options' ) || ! isset( $_POST['wakoo_test_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['wakoo_test_nonce'] ) ), 'wakoo_idiomas_test' ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			wp_die( esc_html__( 'No autorizado.', 'wakoo' ) );
		}
		$in  = isset( $_POST[ self::OPTION ] ) && is_array( $_POST[ self::OPTION ] ) ? wp_unslash( $_POST[ self::OPTION ] ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$prov = in_array( $in['provider'] ?? '', [ 'deepl', 'google' ], true ) ? $in['provider'] : '';
		$key  = sanitize_text_field( $in['key'] ?? '' );
		if ( '' === $key && $prov ) { $saved = self::opts(); $key = $saved['key']; }
		list( $ok, $msg ) = self::test_connection( $prov, $key );
		set_transient( 'wakoo_idiomas_test_' . get_current_user_id(), [ 'ok' => $ok, 'msg' => $msg ], 300 );
		wp_safe_redirect( admin_url( 'admin.php?page=wakoo-idiomas&wk_test=1' ) );
		exit;
	}

	/* ---------- exchange file (translate outside, no external service) ---------- */

	/** Every text marked "por traducir", with where it lives, as a list the translator fills in. */
	public static function pending_items() {
		$items = [];
		$rows  = get_posts( [ 'post_type' => [ 'page', 'post', 'elementor_library' ], 'post_status' => [ 'publish', 'draft', 'private' ], 'posts_per_page' => 500, 'meta_key' => self::MAP ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
		foreach ( $rows as $r ) {
			$map = get_post_meta( $r->ID, self::MAP, true );
			if ( ! self::pending_count( $map ) ) { continue; }
			$lang   = Module::lang_of( $r->ID );
			$master = 0;
			foreach ( Module::translations( $r->ID ) as $l => $id ) { if ( Module::default_lang() === $l ) { $master = (int) $id; } }
			if ( ! $master || $master === $r->ID ) { continue; }
			$types = [];
			$stack = self::data( $master );
			while ( $stack ) {
				$el = array_pop( $stack );
				if ( ! is_array( $el ) ) { continue; }
				if ( isset( $el['id'] ) ) { $types[ (string) $el['id'] ] = (string) ( $el['widgetType'] ?? $el['elType'] ?? '' ); }
				foreach ( (array) ( $el['elements'] ?? [] ) as $c ) { $stack[] = $c; }
			}
			foreach ( $map as $id => $paths ) {
				foreach ( (array) $paths as $path => $e ) {
					if ( empty( $e['p'] ) ) { continue; }
					$items[] = [
						'page'        => get_the_title( $master ),
						'post'        => $master,
						'lang'        => $lang,
						'element'     => (string) $id,
						'widget'      => self::POST === (string) $id ? 'page' : ( $types[ (string) $id ] ?? '' ),
						'field'       => (string) $path,
						'source'      => $e['s'],
						'translation' => '',
					];
				}
			}
		}
		return $items;
	}

	public static function action_export() {
		if ( ! current_user_can( 'edit_pages' ) ) { wp_die( esc_html__( 'Sin permiso.', 'wakoo' ) ); }
		check_admin_referer( 'wakoo_idiomas_export' );
		$out = [
			'wakoo_translations' => 1,
			'instructions'       => 'Fill "translation" of every item with the text of "source" translated into the language "lang" (es = Spanish, fr = French, en = English, zh-tw = Traditional Chinese as used in Taiwan, it = Italian). Keep HTML tags, shortcodes, {placeholders}, URLs and numbers exactly as they are. Do not change any other field.',
			'items'              => self::pending_items(),
		];
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="wakoo-textos-por-traducir-' . gmdate( 'Ymd-His' ) . '.json"' );
		echo wp_json_encode( $out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ); // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	/** Opaque id of a pending text: post, element, field and a checksum of the master text it was made from. */
	public static function item_id( $post, $element, $field, $source ) {
		return $post . '|' . $element . '|' . $field . '|' . sprintf( '%08x', crc32( (string) $source ) );
	}

	/**
	 * Applies translated items: [ post, lang, element, field, translation, source|crc ]. Only texts still pending
	 * and unchanged in the master are filled. With $dry nothing is written. Returns [ done, skipped, by_lang ].
	 */
	public static function import_items( array $items, $dry = false ) {
		$res   = [ 'done' => 0, 'skipped' => 0, 'by_lang' => [] ];
		$dst   = [];
		$maps  = [];
		foreach ( $items as $it ) {
			$t = isset( $it['translation'] ) ? trim( (string) $it['translation'] ) : '';
			if ( '' === $t || empty( $it['post'] ) || empty( $it['lang'] ) ) { $res['skipped']++; continue; }
			$pid  = absint( $it['post'] );
			$lang = sanitize_key( $it['lang'] );
			$id   = Module::translations( $pid )[ $lang ] ?? 0;
			if ( ! $id || ! current_user_can( 'edit_post', $id ) ) { $res['skipped']++; continue; }
			if ( ! isset( $maps[ $id ] ) ) { $maps[ $id ] = get_post_meta( $id, self::MAP, true ); $dst[ $id ] = [ $pid, $lang ]; }
			$el = (string) ( $it['element'] ?? '' );
			$fd = (string) ( $it['field'] ?? '' );
			$e  = $maps[ $id ][ $el ][ $fd ] ?? null;
			$ok = $e && ! empty( $e['p'] ) && ( isset( $it['crc'] ) ? sprintf( '%08x', crc32( $e['s'] ) ) === (string) $it['crc'] : $e['s'] === (string) ( $it['source'] ?? '' ) );
			if ( ! $ok ) { $res['skipped']++; continue; }
			$e['t'] = wp_kses_post( $t );
			$e['p'] = false;
			$e['a'] = false;
			$maps[ $id ][ $el ][ $fd ] = $e;
			$res['done']++;
			$res['by_lang'][ $lang ] = ( $res['by_lang'][ $lang ] ?? 0 ) + 1;
		}
		if ( $dry ) { return $res; }
		foreach ( $maps as $id => $map ) {
			update_post_meta( $id, self::MAP, wp_slash( $map ) );
			self::sync( $dst[ $id ][0], $id, $dst[ $id ][1] );
		}
		return $res;
	}

	/** Turns a pasted or uploaded JSON (v1 one item per language, or v2 one item per text with all languages) into import_items() input. */
	public static function parse_json( $raw ) {
		$raw = trim( (string) $raw );
		$raw = preg_replace( '/^```[a-z]*\s*|\s*```$/i', '', $raw );
		$j   = json_decode( $raw, true );
		if ( is_array( $j ) && ! isset( $j['items'] ) && isset( $j[0] ) ) { $j = [ 'wakoo_translations' => 2, 'items' => $j ]; }
		if ( ! is_array( $j ) || empty( $j['items'] ) || ! is_array( $j['items'] ) ) { return null; }
		$out = [];
		foreach ( $j['items'] as $it ) {
			if ( ! is_array( $it ) ) { continue; }
			if ( isset( $it['id'] ) ) {
				$p = explode( '|', (string) $it['id'] );
				if ( 4 !== count( $p ) ) { continue; }
				foreach ( array_keys( Module::languages() ) as $lang ) {
					if ( isset( $it[ $lang ] ) && is_string( $it[ $lang ] ) ) {
						$out[] = [ 'post' => $p[0], 'lang' => $lang, 'element' => $p[1], 'field' => $p[2], 'crc' => $p[3], 'translation' => $it[ $lang ] ];
					}
				}
			} else {
				$out[] = $it;
			}
		}
		return $out;
	}

	public static function action_import() {
		if ( ! current_user_can( 'edit_pages' ) ) { wp_die( esc_html__( 'Sin permiso.', 'wakoo' ) ); }
		check_admin_referer( 'wakoo_idiomas_import' );
		if ( function_exists( 'set_time_limit' ) ) { @set_time_limit( 300 ); } // phpcs:ignore WordPress.PHP.NoSilencedErrors
		$args = [ 'page' => 'wakoo-idiomas' ];
		$file = $_FILES['wakoo_tr_file']['tmp_name'] ?? ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$size = (int) ( $_FILES['wakoo_tr_file']['size'] ?? 0 );
		$items = ( $file && is_uploaded_file( $file ) && $size > 0 && $size <= 20 * MB_IN_BYTES ) ? self::parse_json( file_get_contents( $file ) ) : null; // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! $items ) {
			$args['wk_import_err'] = 1;
		} else {
			$r = self::import_items( $items );
			$args['wk_imp_done'] = $r['done'];
			$args['wk_imp_skip'] = $r['skipped'];
		}
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	/* ---------- admin actions ---------- */

	/** Default-language posts that have translations (pages, posts and saved templates). */
	public static function masters() {
		$ids = get_posts( [
			'post_type'      => [ 'page', 'post', 'elementor_library' ],
			'post_status'    => [ 'publish', 'draft', 'private' ],
			'posts_per_page' => 500,
			'fields'         => 'ids',
			'meta_key'       => Module::GROUP, // phpcs:ignore WordPress.DB.SlowDBQuery
		] );
		$def = Module::default_lang();
		return array_values( array_filter( $ids, function ( $id ) use ( $def ) {
			return Module::lang_of( $id ) === $def && count( Module::translations( $id ) ) > 1;
		} ) );
	}

	/** Syncs every master. Pages first, so their alignment links the header and footer templates. */
	public static function sync_all() {
		$n = 0;
		foreach ( [ false, true ] as $templates ) {
			foreach ( self::masters() as $id ) {
				if ( ( 'elementor_library' === get_post_type( $id ) ) !== $templates ) { continue; }
				self::sync_from( $id );
				$n++;
			}
		}
		return $n;
	}

	public static function action_sync_all() {
		if ( ! current_user_can( 'edit_pages' ) ) { wp_die( esc_html__( 'Sin permiso.', 'wakoo' ) ); }
		check_admin_referer( 'wakoo_idiomas_sync_all' );
		if ( function_exists( 'set_time_limit' ) ) { @set_time_limit( 300 ); } // phpcs:ignore WordPress.PHP.NoSilencedErrors
		$n = self::sync_all();
		wp_safe_redirect( add_query_arg( [ 'page' => 'wakoo-idiomas', 'wk_synced' => $n ], admin_url( 'admin.php' ) ) );
		exit;
	}

	/** Clones a default-language page into every other language: creates the missing ones, updates the rest. */
	public static function action_make() {
		$pid = absint( $_GET['post'] ?? 0 ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! $pid || ! current_user_can( 'edit_post', $pid ) ) { wp_die( esc_html__( 'Sin permiso.', 'wakoo' ) ); }
		check_admin_referer( 'wakoo_idiomas_make_' . $pid );
		if ( function_exists( 'set_time_limit' ) ) { @set_time_limit( 300 ); } // phpcs:ignore WordPress.PHP.NoSilencedErrors
		self::clone_all( $pid, ! empty( $_GET['overwrite'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		wp_safe_redirect( get_edit_post_link( $pid, 'url' ) );
		exit;
	}

	public static function action_five() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'Sin permiso.', 'wakoo' ) ); }
		check_admin_referer( 'wakoo_idiomas_five' );
		update_option( Module::OPTION, Module::DEFAULTS );
		wp_safe_redirect( add_query_arg( 'page', 'wakoo-idiomas', admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Makes every language version of $pid. Missing ones are created; existing ones get the master's
	 * design and keep their hand-corrected texts. With $overwrite they are rebuilt from scratch
	 * (a backup of each is kept in _wakoo_tr_backup).
	 */
	public static function clone_all( $pid, $overwrite = false, $only = null ) {
		if ( is_array( $only ) ) { update_post_meta( $pid, Module::PAGE_LANGS, array_values( $only ) ); }
		$only = Module::page_langs( $pid );
		$made = self::make_translations( $pid, $only );
		foreach ( Module::translations( $pid ) as $lang => $id ) {
			if ( $id === $pid || isset( $made[ $lang ] ) || ! in_array( $lang, $only, true ) ) { continue; }
			if ( $overwrite ) {
				update_post_meta( $id, self::BACKUP, wp_slash( get_post_meta( $id, '_elementor_data', true ) ) );
				delete_post_meta( $id, self::OFF );
				update_post_meta( $id, self::MAP, [] );
			} elseif ( get_post_meta( $id, self::OFF, true ) ) {
				continue;
			}
			self::sync( $pid, $id, $lang );
		}
		return $made;
	}

	public static function make_translations( $pid, $only = null ) {
		$post = get_post( $pid );
		if ( ! $post || Module::lang_of( $pid ) !== Module::default_lang() ) { return []; }
		$group = (string) get_post_meta( $pid, Module::GROUP, true );
		if ( '' === $group ) {
			$group = $post->post_name ? $post->post_name : 'tr-' . $pid;
			update_post_meta( $pid, Module::GROUP, $group );
			update_post_meta( $pid, Module::LANG, Module::default_lang() );
		}
		$have  = Module::translations( $pid );
		$front = (int) get_option( 'page_on_front' );
		$made  = [];
		foreach ( null === $only ? Module::page_langs( $pid ) : $only as $lang ) {
			if ( isset( $have[ $lang ] ) ) { continue; }
			$parent = 0;
			if ( $post->post_parent ) {
				$ptr    = Module::translations( $post->post_parent );
				$parent = $ptr[ $lang ] ?? 0;
			} elseif ( $front && $front !== $pid && 'page' === $post->post_type ) {
				$ptr    = Module::translations( $front );
				$parent = $ptr[ $lang ] ?? 0;
			}
			$id = wp_insert_post( [
				'post_type'   => $post->post_type,
				'post_title'  => $post->post_title,
				'post_name'   => $parent ? $post->post_name : $post->post_name . '-' . $lang,
				'post_status' => 'draft',
				'post_parent' => $parent,
			] );
			if ( ! $id || is_wp_error( $id ) ) { continue; }
			foreach ( [ '_elementor_edit_mode', '_elementor_template_type', '_wp_page_template', '_elementor_version' ] as $m ) {
				$v = get_post_meta( $pid, $m, true );
				if ( '' !== $v ) { update_post_meta( $id, $m, $v ); }
			}
			update_post_meta( $id, Module::LANG, $lang );
			update_post_meta( $id, Module::GROUP, $group );
			update_post_meta( $id, self::MAP, [] );
			self::sync( $pid, $id, $lang );
			$made[ $lang ] = $id;
		}
		return $made;
	}
}

Sync::init();
