<?php
/**
 * Wakoo Events: event data access and recurrence expansion.
 *
 * Every event stores its first start/end in site-local time plus a simple
 * recurrence rule (daily / weekly on chosen days / monthly by date or by
 * "nth weekday" / yearly, every N, until a date or N times, with excluded
 * and extra dates). This class turns that into concrete occurrences for any
 * date range, and into an iCalendar RRULE for .ics export.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Events;

defined( 'ABSPATH' ) || die();

class Recurrence {

	const P        = '_wk_ev_';
	const MAX_LOOP = 6000;
	const DAYS     = [ 'mo', 'tu', 'we', 'th', 'fr', 'sa', 'su' ];

	/** Normalized event data (meta) for a post. */
	public static function get( $post_id ) {
		$m   = function ( $k, $d = '' ) use ( $post_id ) {
			$v = get_post_meta( $post_id, self::P . $k, true );
			return ( '' === $v || null === $v ) ? $d : $v;
		};
		$byday = $m( 'byday', [] );
		return [
			'start'      => $m( 'start' ),
			'end'        => $m( 'end' ),
			'allday'     => (bool) $m( 'allday', 0 ),
			'freq'       => $m( 'freq', 'none' ),
			'interval'   => max( 1, (int) $m( 'interval', 1 ) ),
			'byday'      => is_array( $byday ) ? $byday : [],
			'monthly'    => $m( 'monthly', 'date' ),
			'ends'       => $m( 'ends', 'never' ),
			'until'      => $m( 'until' ),
			'count'      => max( 0, (int) $m( 'count', 0 ) ),
			'exdates'    => self::date_list( $m( 'exdates' ) ),
			'rdates'     => self::date_list( $m( 'rdates' ) ),
			'location'   => $m( 'location' ),
			'address'    => $m( 'address' ),
			'online'     => $m( 'online' ),
			'organizer'  => $m( 'organizer' ),
			'price'      => $m( 'price' ),
			'currency'   => $m( 'currency', 'EUR' ),
			'ticket'     => $m( 'ticket' ),
			'color'      => $m( 'color' ),
			'status'     => $m( 'status', 'scheduled' ),
			'rsvp'       => (bool) $m( 'rsvp', 0 ),
			'capacity'   => max( 0, (int) $m( 'capacity', 0 ) ),
			'max_seats'  => max( 1, (int) $m( 'max_seats', 4 ) ),
			'booked'     => (array) $m( 'booked', [] ),
		];
	}

	public static function date_list( $raw ) {
		$out = [];
		foreach ( preg_split( '/[\s,;]+/', (string) $raw ) as $d ) {
			if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) ) {
				$out[] = $d;
			}
		}
		return array_values( array_unique( $out ) );
	}

	public static function parse( $local ) {
		if ( ! $local ) {
			return null;
		}
		$local = str_replace( ' ', 'T', trim( (string) $local ) );
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $local ) ) {
			$local .= 'T00:00';
		}
		$dt = \DateTimeImmutable::createFromFormat( 'Y-m-d\TH:i', substr( $local, 0, 16 ), wp_timezone() );
		return $dt ?: null;
	}

	/** First start and end (end exclusive for all-day events). */
	public static function bounds( array $e ) {
		$start = self::parse( $e['start'] );
		if ( ! $start ) {
			return null;
		}
		if ( $e['allday'] ) {
			$start = $start->setTime( 0, 0 );
		}
		$end = self::parse( $e['end'] );
		if ( $e['allday'] ) {
			$end = ( $end && $end >= $start ) ? $end->setTime( 0, 0 )->modify( '+1 day' ) : $start->modify( '+1 day' );
		} elseif ( ! $end || $end <= $start ) {
			$end = $start->modify( '+1 hour' );
		}
		return [ $start, $end ];
	}

	/**
	 * Occurrences overlapping [$from, $to). Returns a list of [start, end, key]
	 * where key is the local Y-m-d of the occurrence start.
	 */
	public static function occurrences( array $e, \DateTimeImmutable $from, \DateTimeImmutable $to, $limit = 500 ) {
		$b = self::bounds( $e );
		if ( ! $b ) {
			return [];
		}
		list( $start, $end ) = $b;
		$dur  = $end->getTimestamp() - $start->getTimestamp();
		$out  = [];
		$push = function ( \DateTimeImmutable $s ) use ( &$out, $dur, $from, $to, $e ) {
			$key = $s->format( 'Y-m-d' );
			if ( in_array( $key, $e['exdates'], true ) ) {
				return;
			}
			$en = $s->modify( '+' . $dur . ' seconds' );
			if ( $s < $to && $en > $from ) {
				$out[ $key . $s->format( 'Hi' ) ] = [ $s, $en, $key ];
			}
		};

		foreach ( self::series( $e, $start, $to->modify( '+1 day' ) ) as $s ) {
			$push( $s );
			if ( count( $out ) >= $limit ) {
				break;
			}
		}
		foreach ( $e['rdates'] as $d ) {
			$s = self::parse( $d );
			if ( $s ) {
				$push( $s->setTime( (int) $start->format( 'H' ), (int) $start->format( 'i' ) ) );
			}
		}
		ksort( $out );
		return array_values( array_slice( $out, 0, $limit ) );
	}

	/** Generator over the rule's occurrence starts, in order, until $stop. */
	public static function series( array $e, \DateTimeImmutable $start, \DateTimeImmutable $stop ) {
		$freq  = in_array( $e['freq'], [ 'daily', 'weekly', 'monthly', 'yearly' ], true ) ? $e['freq'] : 'none';
		$n     = $e['interval'];
		$until = ( 'until' === $e['ends'] && $e['until'] ) ? self::parse( $e['until'] ) : null;
		if ( $until ) {
			$until = $until->setTime( 23, 59, 59 );
			if ( $until < $stop ) {
				$stop = $until;
			}
		}
		$count = ( 'count' === $e['ends'] && $e['count'] > 0 ) ? $e['count'] : 0;
		$made  = 0;
		$h     = (int) $start->format( 'H' );
		$i     = (int) $start->format( 'i' );

		if ( 'none' === $freq ) {
			yield $start;
			return;
		}

		$loops = 0;
		$k     = 0;
		while ( $loops++ < self::MAX_LOOP ) {
			$batch = [];
			if ( 'daily' === $freq ) {
				$batch[] = $start->modify( '+' . ( $k * $n ) . ' days' );
			} elseif ( 'weekly' === $freq ) {
				$days = $e['byday'] ?: [ self::DAYS[ (int) $start->format( 'N' ) - 1 ] ];
				$monday = $start->modify( '-' . ( (int) $start->format( 'N' ) - 1 ) . ' days' )->modify( '+' . ( $k * $n ) . ' weeks' );
				foreach ( self::DAYS as $idx => $code ) {
					if ( in_array( $code, $days, true ) ) {
						$batch[] = $monday->modify( '+' . $idx . ' days' )->setTime( $h, $i );
					}
				}
			} elseif ( 'monthly' === $freq ) {
				$first = $start->modify( 'first day of this month' )->modify( '+' . ( $k * $n ) . ' months' );
				if ( 'nth' === $e['monthly'] ) {
					$batch[] = self::nth_weekday( $start, $first )->setTime( $h, $i );
				} else {
					$day = (int) $start->format( 'j' );
					if ( $day <= (int) $first->format( 't' ) ) {
						$batch[] = $first->setDate( (int) $first->format( 'Y' ), (int) $first->format( 'n' ), $day )->setTime( $h, $i );
					}
				}
			} else {
				$y = (int) $start->format( 'Y' ) + $k * $n;
				$mo = (int) $start->format( 'n' );
				$d  = (int) $start->format( 'j' );
				if ( checkdate( $mo, $d, $y ) ) {
					$batch[] = $start->setDate( $y, $mo, $d );
				}
			}
			$k++;
			foreach ( $batch as $s ) {
				if ( $s < $start ) {
					continue;
				}
				if ( $s > $stop ) {
					return;
				}
				yield $s;
				if ( $count && ++$made >= $count ) {
					return;
				}
			}
			if ( empty( $batch ) && $k > 2400 ) {
				return;
			}
		}
	}

	/** Same "nth weekday" as $ref (e.g. 2nd Tuesday, or last Friday) in the month of $month. */
	public static function nth_weekday( \DateTimeImmutable $ref, \DateTimeImmutable $month ) {
		$names = [ 1 => 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday' ];
		$wd    = $names[ (int) $ref->format( 'N' ) ];
		$nth   = self::nth_of( $ref );
		$label = -1 === $nth ? 'last' : [ 1 => 'first', 'second', 'third', 'fourth' ][ $nth ];
		return $month->modify( $label . ' ' . $wd . ' of this month' );
	}

	/** 1..4, or -1 when the date is the last such weekday and the 5th. */
	public static function nth_of( \DateTimeImmutable $d ) {
		$n = (int) ceil( (int) $d->format( 'j' ) / 7 );
		return $n >= 5 ? -1 : $n;
	}

	/** Timestamp of the last occurrence end (for range queries); far future when endless. */
	public static function last_ts( array $e ) {
		$b = self::bounds( $e );
		if ( ! $b ) {
			return 0;
		}
		$last = $b[1]->getTimestamp();
		if ( 'none' !== $e['freq'] ) {
			if ( 'until' === $e['ends'] && $e['until'] ) {
				$u    = self::parse( $e['until'] );
				$last = $u ? $u->setTime( 23, 59, 59 )->getTimestamp() + ( $b[1]->getTimestamp() - $b[0]->getTimestamp() ) : $last;
			} elseif ( 'count' === $e['ends'] && $e['count'] > 0 ) {
				$s = null;
				foreach ( self::series( $e, $b[0], $b[0]->modify( '+200 years' ) ) as $s ) {} // phpcs:ignore
				$last = $s ? $s->getTimestamp() + ( $b[1]->getTimestamp() - $b[0]->getTimestamp() ) : $last;
			} else {
				$last = 4102444800; // 2100-01-01.
			}
		}
		foreach ( $e['rdates'] as $d ) {
			$s = self::parse( $d );
			if ( $s ) {
				$last = max( $last, $s->getTimestamp() + DAY_IN_SECONDS );
			}
		}
		return $last;
	}

	/** Human readable rule, in Spanish ("Cada 2 semanas: lun, mié · 10 veces"). */
	public static function describe( array $e ) {
		if ( 'none' === $e['freq'] ) {
			return '';
		}
		$n     = $e['interval'];
		$units = [
			'daily'   => [ __( 'Cada día', 'wakoo' ), __( 'Cada %d días', 'wakoo' ) ],
			'weekly'  => [ __( 'Cada semana', 'wakoo' ), __( 'Cada %d semanas', 'wakoo' ) ],
			'monthly' => [ __( 'Cada mes', 'wakoo' ), __( 'Cada %d meses', 'wakoo' ) ],
			'yearly'  => [ __( 'Cada año', 'wakoo' ), __( 'Cada %d años', 'wakoo' ) ],
		];
		$txt = 1 === $n ? $units[ $e['freq'] ][0] : sprintf( $units[ $e['freq'] ][1], $n );
		if ( 'weekly' === $e['freq'] && $e['byday'] ) {
			$names = [ 'mo' => 'lun', 'tu' => 'mar', 'we' => 'mié', 'th' => 'jue', 'fr' => 'vie', 'sa' => 'sáb', 'su' => 'dom' ];
			$txt  .= ': ' . implode( ', ', array_map( function ( $d ) use ( $names ) { return $names[ $d ] ?? $d; }, $e['byday'] ) );
		}
		if ( 'monthly' === $e['freq'] && 'nth' === $e['monthly'] ) {
			$s = self::parse( $e['start'] );
			if ( $s ) {
				$nth  = self::nth_of( $s );
				$ord  = -1 === $nth ? __( 'último', 'wakoo' ) : [ 1 => '1.º', '2.º', '3.º', '4.º' ][ $nth ];
				$txt .= ' (' . $ord . ' ' . wp_date( 'l', $s->getTimestamp() ) . ')';
			}
		}
		if ( 'until' === $e['ends'] && $e['until'] ) {
			$u = self::parse( $e['until'] );
			if ( $u ) {
				$txt .= ' · ' . sprintf( __( 'hasta el %s', 'wakoo' ), wp_date( get_option( 'date_format' ), $u->getTimestamp() ) );
			}
		} elseif ( 'count' === $e['ends'] && $e['count'] ) {
			$txt .= ' · ' . sprintf( _n( '%d vez', '%d veces', $e['count'], 'wakoo' ), $e['count'] );
		}
		return $txt;
	}

	/** iCalendar RRULE (without the "RRULE:" prefix), or '' for one-off events. */
	public static function rrule( array $e ) {
		if ( 'none' === $e['freq'] ) {
			return '';
		}
		$r = [ 'FREQ=' . strtoupper( $e['freq'] ) ];
		if ( $e['interval'] > 1 ) {
			$r[] = 'INTERVAL=' . $e['interval'];
		}
		if ( 'weekly' === $e['freq'] && $e['byday'] ) {
			$r[] = 'BYDAY=' . strtoupper( implode( ',', $e['byday'] ) );
		}
		if ( 'monthly' === $e['freq'] && 'nth' === $e['monthly'] ) {
			$s = self::parse( $e['start'] );
			if ( $s ) {
				$r[] = 'BYDAY=' . self::nth_of( $s ) . strtoupper( self::DAYS[ (int) $s->format( 'N' ) - 1 ] );
			}
		}
		if ( 'until' === $e['ends'] && $e['until'] ) {
			$u = self::parse( $e['until'] );
			if ( $u ) {
				$r[] = 'UNTIL=' . gmdate( 'Ymd\THis\Z', $u->setTime( 23, 59, 59 )->getTimestamp() );
			}
		} elseif ( 'count' === $e['ends'] && $e['count'] ) {
			$r[] = 'COUNT=' . $e['count'];
		}
		return implode( ';', $r );
	}
}
