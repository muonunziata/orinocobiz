<?php
/**
 * "Lista de eventos (Wakoo)" widget: upcoming events as cards, list or timeline.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Events;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;

defined( 'ABSPATH' ) || die();

class List_Widget extends Widget_Base {

	public function get_name() { return 'wakoo-events-list'; }
	public function get_title() { return __( 'Lista de eventos (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-post-list'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'eventos', 'events', 'próximos', 'agenda', 'lista', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-events' ]; }
	public function get_style_depends() { return [ 'wakoo-events' ]; }

	protected function register_controls() {
		$cats  = [];
		$terms = get_terms( [ 'taxonomy' => Module::TAX, 'hide_empty' => false ] );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$cats[ $t->slug ] = $t->name;
			}
		}
		$this->start_controls_section( 'sec_q', [ 'label' => __( 'Eventos', 'wakoo' ) ] );
		$this->add_control( 'cats', [ 'label' => __( 'Solo estas categorías', 'wakoo' ), 'type' => Controls_Manager::SELECT2, 'multiple' => true, 'label_block' => true, 'options' => $cats ] );
		$this->add_control( 'when', [
			'label'   => __( 'Qué eventos', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'upcoming',
			'options' => [ 'upcoming' => __( 'Próximos', 'wakoo' ), 'past' => __( 'Pasados (más recientes primero)', 'wakoo' ) ],
		] );
		$this->add_control( 'count', [ 'label' => __( 'Cantidad', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 60, 'default' => 6 ] );
		$this->add_control( 'days', [ 'label' => __( 'Buscar en los próximos (días)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 1500, 'default' => 365 ] );
		$this->add_control( 'group', [ 'label' => __( 'Repeticiones: solo la siguiente fecha', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'description' => __( 'Si está apagado, un evento semanal aparece una vez por semana.', 'wakoo' ) ] );
		$this->add_control( 'empty', [ 'label' => __( 'Texto si no hay eventos', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Pronto anunciaremos nuevos eventos.', 'wakoo' ) ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_layout', [ 'label' => __( 'Diseño', 'wakoo' ) ] );
		$this->add_control( 'layout', [
			'label'   => __( 'Diseño', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'cards',
			'options' => [ 'cards' => __( 'Tarjetas', 'wakoo' ), 'rows' => __( 'Filas con fecha', 'wakoo' ), 'timeline' => __( 'Línea de tiempo', 'wakoo' ) ],
		] );
		$this->add_responsive_control( 'cols', [
			'label'          => __( 'Columnas', 'wakoo' ),
			'type'           => Controls_Manager::SELECT,
			'default'        => '3',
			'tablet_default' => '2',
			'mobile_default' => '1',
			'options'        => [ '1' => '1', '2' => '2', '3' => '3', '4' => '4' ],
			'selectors'      => [ '{{WRAPPER}} .wakoo-evlist--cards' => 'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));' ],
			'condition'      => [ 'layout' => 'cards' ],
		] );
		foreach ( [ 'image' => __( 'Imagen', 'wakoo' ), 'badge' => __( 'Fecha destacada', 'wakoo' ), 'time' => __( 'Hora', 'wakoo' ), 'place' => __( 'Lugar', 'wakoo' ), 'price' => __( 'Precio', 'wakoo' ), 'excerpt' => __( 'Resumen', 'wakoo' ), 'cats' => __( 'Categorías', 'wakoo' ), 'spots' => __( 'Plazas libres', 'wakoo' ), 'button' => __( 'Botón', 'wakoo' ) ] as $k => $l ) {
			$this->add_control( 'show_' . $k, [ 'label' => $l, 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => in_array( $k, [ 'excerpt', 'spots' ], true ) ? '' : 'yes' ] );
		}
		$this->add_control( 'btn_txt', [ 'label' => __( 'Texto del botón', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Ver evento', 'wakoo' ), 'condition' => [ 'show_button' => 'yes' ] ] );
		$this->end_controls_section();

		$this->start_controls_section( 'st', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'accent', [ 'label' => __( 'Color principal', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#6C5CE7', 'selectors' => [ '{{WRAPPER}} .wakoo-evlist' => '--wk-accent: {{VALUE}};' ] ] );
		$this->add_control( 'card_bg', [ 'label' => __( 'Fondo', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-evlist' => '--wk-card: {{VALUE}};' ] ] );
		$this->add_control( 'txt', [ 'label' => __( 'Texto', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-evlist' => '--wk-text: {{VALUE}};' ] ] );
		$this->add_responsive_control( 'gap', [ 'label' => __( 'Separación (px)', 'wakoo' ), 'type' => Controls_Manager::SLIDER, 'range' => [ 'px' => [ 'min' => 0, 'max' => 80 ] ], 'default' => [ 'size' => 24, 'unit' => 'px' ], 'selectors' => [ '{{WRAPPER}} .wakoo-evlist' => 'gap: {{SIZE}}px;' ] ] );
		$this->add_control( 'radius', [ 'label' => __( 'Redondez (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 16, 'selectors' => [ '{{WRAPPER}} .wakoo-evlist' => '--wk-radius: {{VALUE}}px;' ] ] );
		$this->add_group_control( Group_Control_Box_Shadow::get_type(), [ 'name' => 'shadow', 'selector' => '{{WRAPPER}} .wakoo-evitem' ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'ty_title', 'label' => __( 'Título', 'wakoo' ), 'selector' => '{{WRAPPER}} .wakoo-evitem__title' ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'ty_meta', 'label' => __( 'Datos', 'wakoo' ), 'selector' => '{{WRAPPER}} .wakoo-evitem__meta' ] );
		$this->end_controls_section();
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$tz    = wp_timezone();
		$now   = new \DateTimeImmutable( 'now', $tz );
		$days  = max( 1, (int) ( $s['days'] ?? 365 ) );
		$past  = 'past' === ( $s['when'] ?? '' );
		$from  = $past ? $now->modify( '-' . $days . ' days' ) : $now;
		$to    = $past ? $now : $now->modify( '+' . $days . ' days' );
		$count = max( 1, (int) ( $s['count'] ?? 6 ) );
		$list  = Module::query( $from, $to, [ 'cats' => array_filter( (array) ( $s['cats'] ?? [] ) ), 'limit' => 1000 ] );
		if ( $past ) {
			$list = array_reverse( array_filter( $list, function ( $o ) use ( $now ) { return $o['end'] <= $now; } ) );
		}
		if ( 'yes' === ( $s['group'] ?? 'yes' ) ) {
			$seen = [];
			$list = array_filter( $list, function ( $o ) use ( &$seen ) {
				if ( isset( $seen[ $o['post']->ID ] ) ) {
					return false;
				}
				return $seen[ $o['post']->ID ] = true;
			} );
		}
		$list   = array_slice( array_values( $list ), 0, $count );
		$layout = in_array( $s['layout'] ?? '', [ 'cards', 'rows', 'timeline' ], true ) ? $s['layout'] : 'cards';
		$on     = function ( $k ) use ( $s ) { return 'yes' === ( $s[ 'show_' . $k ] ?? '' ); };

		if ( ! $list ) {
			echo '<p class="wakoo-evlist__empty">' . esc_html( $s['empty'] ?? '' ) . '</p>';
			return;
		}
		echo '<div class="wakoo-evlist wakoo-evlist--' . esc_attr( $layout ) . '">';
		foreach ( $list as $o ) {
			$post = $o['post'];
			$e    = $o['e'];
			$url  = get_permalink( $post );
			$ts   = $o['start']->getTimestamp();
			$cats = Module::terms_of( $post->ID );
			$col  = $e['color'] ?: ( $cats[0]['color'] ?? '' );
			echo '<article class="wakoo-evitem wakoo-evitem--' . esc_attr( $e['status'] ) . '"' . ( $col ? ' style="--wk-ev:' . esc_attr( $col ) . '"' : '' ) . '>';
			if ( $on( 'image' ) && 'cards' === $layout && has_post_thumbnail( $post ) ) {
				echo '<a class="wakoo-evitem__img" href="' . esc_url( $url ) . '" tabindex="-1" aria-hidden="true">' . get_the_post_thumbnail( $post, 'medium_large', [ 'loading' => 'lazy' ] ) . '</a>';
			}
			if ( $on( 'badge' ) ) {
				echo '<div class="wakoo-evitem__badge" aria-hidden="true"><span class="wakoo-evitem__d">' . esc_html( wp_date( 'j', $ts ) ) . '</span><span class="wakoo-evitem__m">' . esc_html( wp_date( 'M', $ts ) ) . '</span></div>';
			}
			echo '<div class="wakoo-evitem__body">';
			if ( 'scheduled' !== $e['status'] ) {
				echo '<span class="wakoo-evitem__status">' . esc_html( Module::statuses()[ $e['status'] ] ) . '</span>';
			}
			if ( $on( 'cats' ) && $cats ) {
				echo '<div class="wakoo-evitem__cats">';
				foreach ( $cats as $c ) {
					echo '<span' . ( $c['color'] ? ' style="--wk-chip:' . esc_attr( $c['color'] ) . '"' : '' ) . '>' . esc_html( $c['name'] ) . '</span>';
				}
				echo '</div>';
			}
			echo '<h3 class="wakoo-evitem__title"><a href="' . esc_url( $url ) . '">' . esc_html( get_the_title( $post ) ) . '</a></h3><ul class="wakoo-evitem__meta">';
			if ( $on( 'time' ) ) {
				echo '<li class="wakoo-evitem__when"><time datetime="' . esc_attr( $o['start']->format( 'c' ) ) . '">' . esc_html( Module::format_range( $o['start'], $o['end'], $e['allday'] ) ) . '</time></li>';
			}
			if ( $on( 'place' ) && ( $e['location'] || $e['online'] ) ) {
				echo '<li class="wakoo-evitem__where">' . esc_html( $e['location'] ?: __( 'En línea', 'wakoo' ) ) . '</li>';
			}
			if ( $on( 'price' ) ) {
				echo '<li class="wakoo-evitem__price">' . esc_html( Module::price_label( $e ) ) . '</li>';
			}
			if ( $on( 'spots' ) && $e['rsvp'] ) {
				$left = Module::spots_left( $e, $o['key'] );
				if ( null !== $left ) {
					echo '<li class="wakoo-evitem__spots">' . esc_html( $left ? sprintf( __( 'Quedan %d plazas', 'wakoo' ), $left ) : __( 'Completo', 'wakoo' ) ) . '</li>';
				}
			}
			echo '</ul>';
			if ( $on( 'excerpt' ) ) {
				echo '<p class="wakoo-evitem__excerpt">' . esc_html( wp_trim_words( wp_strip_all_tags( $post->post_excerpt ?: strip_shortcodes( $post->post_content ) ), 22 ) ) . '</p>';
			}
			if ( $on( 'button' ) ) {
				echo '<a class="wakoo-evbtn" href="' . esc_url( $url ) . '">' . esc_html( $s['btn_txt'] ?? '' ) . '</a>';
			}
			echo '</div></article>';
		}
		echo '</div>';
	}
}
