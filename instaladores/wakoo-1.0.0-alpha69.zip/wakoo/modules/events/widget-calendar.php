<?php
/**
 * "Calendario de eventos (Wakoo)" widget.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Events;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

defined( 'ABSPATH' ) || die();

class Calendar_Widget extends Widget_Base {

	public function get_name() { return 'wakoo-events-calendar'; }
	public function get_title() { return __( 'Calendario de eventos (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-calendar'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'calendario', 'calendar', 'eventos', 'events', 'agenda', 'reservas', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-fullcalendar', 'wakoo-fullcalendar-locales', 'wakoo-events' ]; }
	public function get_style_depends() { return [ 'wakoo-events' ]; }

	public static function views() {
		return [
			'dayGridMonth'   => __( 'Mes', 'wakoo' ),
			'timeGridWeek'   => __( 'Semana (horas)', 'wakoo' ),
			'dayGridWeek'    => __( 'Semana (compacta)', 'wakoo' ),
			'timeGridDay'    => __( 'Día', 'wakoo' ),
			'listWeek'       => __( 'Agenda de la semana', 'wakoo' ),
			'listMonth'      => __( 'Agenda del mes', 'wakoo' ),
			'listYear'       => __( 'Agenda del año', 'wakoo' ),
			'multiMonthYear' => __( 'Año', 'wakoo' ),
		];
	}

	private function cat_options() {
		$out   = [];
		$terms = get_terms( [ 'taxonomy' => Module::TAX, 'hide_empty' => false ] );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$out[ $t->slug ] = $t->name;
			}
		}
		return $out;
	}

	protected function register_controls() {
		/* Events ---------------------------------------------------------- */
		$this->start_controls_section( 'sec_source', [ 'label' => __( 'Eventos', 'wakoo' ) ] );
		$this->add_control( 'source', [
			'label'   => __( 'Origen', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'native',
			'options' => [
				'native' => __( 'Eventos Wakoo (menú Eventos)', 'wakoo' ),
				'manual' => __( 'Escritos aquí', 'wakoo' ),
				'both'   => __( 'Ambos', 'wakoo' ),
			],
		] );
		$this->add_control( 'source_note', [
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => sprintf(
				/* translators: %s: admin link */
				__( 'Crea y gestiona eventos (con repeticiones, aforo e inscripciones) en <a href="%s" target="_blank">Eventos Wakoo</a>.', 'wakoo' ),
				esc_url( admin_url( 'edit.php?post_type=' . Module::CPT ) )
			),
			'content_classes' => 'elementor-descriptor',
			'condition'       => [ 'source!' => 'manual' ],
		] );
		$this->add_control( 'cats', [
			'label'       => __( 'Solo estas categorías', 'wakoo' ),
			'type'        => Controls_Manager::SELECT2,
			'multiple'    => true,
			'label_block' => true,
			'options'     => $this->cat_options(),
			'condition'   => [ 'source!' => 'manual' ],
		] );

		$rep = new Repeater();
		$rep->add_control( 'title', [ 'label' => __( 'Título', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Evento', 'wakoo' ), 'label_block' => true, 'dynamic' => [ 'active' => true ] ] );
		$rep->add_control( 'start', [ 'label' => __( 'Empieza', 'wakoo' ), 'type' => Controls_Manager::DATE_TIME, 'picker_options' => [ 'enableTime' => true ] ] );
		$rep->add_control( 'end', [ 'label' => __( 'Termina', 'wakoo' ), 'type' => Controls_Manager::DATE_TIME, 'picker_options' => [ 'enableTime' => true ] ] );
		$rep->add_control( 'allday', [ 'label' => __( 'Todo el día', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ] );
		$rep->add_control( 'repeat', [
			'label'   => __( 'Se repite', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => '',
			'options' => [ '' => __( 'No', 'wakoo' ), 'weekly' => __( 'Cada semana', 'wakoo' ), 'monthly' => __( 'Cada mes', 'wakoo' ) ],
		] );
		$rep->add_control( 'repeat_until', [ 'label' => __( 'Hasta', 'wakoo' ), 'type' => Controls_Manager::DATE_TIME, 'picker_options' => [ 'enableTime' => false ], 'condition' => [ 'repeat!' => '' ] ] );
		$rep->add_control( 'category', [ 'label' => __( 'Categoría (texto)', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$rep->add_control( 'color', [ 'label' => __( 'Color', 'wakoo' ), 'type' => Controls_Manager::COLOR ] );
		$rep->add_control( 'location', [ 'label' => __( 'Lugar', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$rep->add_control( 'desc', [ 'label' => __( 'Descripción', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA ] );
		$rep->add_control( 'image', [ 'label' => __( 'Imagen', 'wakoo' ), 'type' => Controls_Manager::MEDIA ] );
		$rep->add_control( 'link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL, 'dynamic' => [ 'active' => true ] ] );
		$base = ( new \DateTimeImmutable( 'today', wp_timezone() ) );
		$this->add_control( 'manual', [
			'label'       => __( 'Eventos', 'wakoo' ),
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $rep->get_controls(),
			'title_field' => '{{{ title }}}',
			'condition'   => [ 'source!' => 'native' ],
			'default'     => [
				[ 'title' => __( 'Taller de diseño', 'wakoo' ), 'start' => $base->modify( '+2 days' )->format( 'Y-m-d' ) . ' 10:00', 'end' => $base->modify( '+2 days' )->format( 'Y-m-d' ) . ' 13:00', 'category' => __( 'Talleres', 'wakoo' ), 'color' => '#6C5CE7', 'location' => __( 'Sala 1', 'wakoo' ) ],
				[ 'title' => __( 'Concierto al aire libre', 'wakoo' ), 'start' => $base->modify( '+6 days' )->format( 'Y-m-d' ) . ' 20:30', 'end' => $base->modify( '+6 days' )->format( 'Y-m-d' ) . ' 23:00', 'category' => __( 'Música', 'wakoo' ), 'color' => '#E84393', 'location' => __( 'Parque central', 'wakoo' ) ],
				[ 'title' => __( 'Club de lectura', 'wakoo' ), 'start' => $base->modify( '+1 day' )->format( 'Y-m-d' ) . ' 18:00', 'end' => $base->modify( '+1 day' )->format( 'Y-m-d' ) . ' 19:30', 'repeat' => 'weekly', 'category' => __( 'Comunidad', 'wakoo' ), 'color' => '#00B894' ],
			],
		] );
		$this->end_controls_section();

		/* Views ----------------------------------------------------------- */
		$this->start_controls_section( 'sec_views', [ 'label' => __( 'Vistas', 'wakoo' ) ] );
		$this->add_control( 'view', [ 'label' => __( 'Vista inicial', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'dayGridMonth', 'options' => self::views() ] );
		$this->add_control( 'views', [
			'label'       => __( 'Botones de vista', 'wakoo' ),
			'type'        => Controls_Manager::SELECT2,
			'multiple'    => true,
			'label_block' => true,
			'options'     => self::views(),
			'default'     => [ 'dayGridMonth', 'timeGridWeek', 'timeGridDay', 'listMonth' ],
		] );
		$this->add_control( 'mobile_view', [
			'label'       => __( 'Vista en móvil', 'wakoo' ),
			'type'        => Controls_Manager::SELECT,
			'default'     => 'listMonth',
			'options'     => [ '' => __( 'La misma', 'wakoo' ) ] + self::views(),
			'description' => __( 'Se usa en pantallas de menos de 768 px.', 'wakoo' ),
		] );
		$this->add_control( 'first_day', [
			'label'   => __( 'La semana empieza en', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'wp',
			'options' => [ 'wp' => __( 'Ajuste de WordPress', 'wakoo' ), '1' => __( 'Lunes', 'wakoo' ), '0' => __( 'Domingo', 'wakoo' ), '6' => __( 'Sábado', 'wakoo' ) ],
		] );
		$this->add_control( 'weekends', [ 'label' => __( 'Mostrar fines de semana', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'week_numbers', [ 'label' => __( 'Números de semana', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ] );
		$this->add_control( 'max_events', [
			'label'       => __( 'Eventos por día antes de "+ más"', 'wakoo' ),
			'type'        => Controls_Manager::NUMBER,
			'min'         => 0,
			'max'         => 20,
			'default'     => 3,
			'description' => __( '0 = mostrar todos.', 'wakoo' ),
		] );
		$this->add_control( 'slot_min', [ 'label' => __( 'Hora de inicio (vistas por horas)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '07:00', 'placeholder' => '07:00' ] );
		$this->add_control( 'slot_max', [ 'label' => __( 'Hora de fin', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '23:00', 'placeholder' => '23:00' ] );
		$this->add_control( 'hour12', [ 'label' => __( 'Formato 12 h (am/pm)', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ] );
		$this->add_control( 'now_line', [ 'label' => __( 'Línea de "ahora"', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'past', [
			'label'   => __( 'Eventos pasados', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'dim',
			'options' => [ 'show' => __( 'Normales', 'wakoo' ), 'dim' => __( 'Atenuados', 'wakoo' ), 'hide' => __( 'Ocultos', 'wakoo' ) ],
		] );
		$this->add_control( 'display', [
			'label'   => __( 'Estilo de los eventos (mes)', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'block',
			'options' => [ 'block' => __( 'Bloque de color', 'wakoo' ), 'list-item' => __( 'Punto + texto', 'wakoo' ), 'auto' => __( 'Automático', 'wakoo' ) ],
		] );
		$this->add_control( 'height', [
			'label'   => __( 'Altura', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'auto',
			'options' => [ 'auto' => __( 'Automática', 'wakoo' ), 'fixed' => __( 'Fija', 'wakoo' ) ],
		] );
		$this->add_control( 'height_px', [ 'label' => __( 'Altura (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 700, 'condition' => [ 'height' => 'fixed' ] ] );
		$this->end_controls_section();

		/* Tools ----------------------------------------------------------- */
		$this->start_controls_section( 'sec_tools', [ 'label' => __( 'Barra y filtros', 'wakoo' ) ] );
		$this->add_control( 'show_today', [ 'label' => __( 'Botón "Hoy"', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'show_filters', [ 'label' => __( 'Filtros por categoría', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'show_search', [ 'label' => __( 'Buscador', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'search_ph', [ 'label' => __( 'Texto del buscador', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Buscar eventos…', 'wakoo' ), 'condition' => [ 'show_search' => 'yes' ] ] );
		$this->add_control( 'show_subscribe', [ 'label' => __( 'Botón "Suscribirse" (.ics)', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'condition' => [ 'source!' => 'manual' ] ] );
		$this->add_control( 'subscribe_txt', [ 'label' => __( 'Texto', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Suscribirse al calendario', 'wakoo' ), 'condition' => [ 'source!' => 'manual', 'show_subscribe' => 'yes' ] ] );
		$this->add_control( 'h_labels', [ 'label' => __( 'Textos de los botones', 'wakoo' ), 'type' => Controls_Manager::HEADING, 'separator' => 'before' ] );
		$this->add_control( 'l_today', [ 'label' => __( 'Hoy', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Hoy', 'wakoo' ) ] );
		foreach ( [ 'dayGridMonth' => 'Mes', 'timeGridWeek' => 'Semana', 'dayGridWeek' => 'Semana', 'timeGridDay' => 'Día', 'listWeek' => 'Agenda', 'listMonth' => 'Agenda', 'listYear' => 'Agenda', 'multiMonthYear' => 'Año' ] as $v => $l ) {
			$this->add_control( 'l_' . $v, [ 'label' => self::views()[ $v ], 'type' => Controls_Manager::TEXT, 'default' => $l ] );
		}
		$this->end_controls_section();

		/* Click ----------------------------------------------------------- */
		$this->start_controls_section( 'sec_click', [ 'label' => __( 'Al pulsar un evento', 'wakoo' ) ] );
		$this->add_control( 'click', [
			'label'   => __( 'Acción', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'modal',
			'options' => [ 'modal' => __( 'Ventana con detalles', 'wakoo' ), 'link' => __( 'Ir a la página del evento', 'wakoo' ), 'none' => __( 'Nada', 'wakoo' ) ],
		] );
		$this->add_control( 'modal_image', [ 'label' => __( 'Imagen', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'condition' => [ 'click' => 'modal' ] ] );
		$this->add_control( 'modal_rsvp', [ 'label' => __( 'Formulario de inscripción', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'condition' => [ 'click' => 'modal' ], 'description' => __( 'Solo en eventos con inscripción activada.', 'wakoo' ) ] );
		$this->add_control( 'modal_ics', [ 'label' => __( 'Botón "Añadir a mi calendario"', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'condition' => [ 'click' => 'modal' ] ] );
		$this->add_control( 'modal_link', [ 'label' => __( 'Botón "Ver evento"', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'condition' => [ 'click' => 'modal' ] ] );
		$this->add_control( 'tooltip', [ 'label' => __( 'Resumen al pasar el ratón', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();

		/* Style ----------------------------------------------------------- */
		$this->start_controls_section( 'st_cal', [ 'label' => __( 'Calendario', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'accent', [ 'label' => __( 'Color principal', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#6C5CE7', 'selectors' => [ '{{WRAPPER}} .wakoo-evcal' => '--wk-accent: {{VALUE}};' ] ] );
		$this->add_control( 'bg', [ 'label' => __( 'Fondo', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-evcal' => '--wk-bg: {{VALUE}};' ] ] );
		$this->add_control( 'text', [ 'label' => __( 'Texto', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-evcal' => '--wk-text: {{VALUE}};' ] ] );
		$this->add_control( 'line', [ 'label' => __( 'Líneas', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-evcal' => '--wk-line: {{VALUE}};' ] ] );
		$this->add_control( 'head_bg', [ 'label' => __( 'Fondo de la cabecera de días', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-evcal' => '--wk-head: {{VALUE}};' ] ] );
		$this->add_control( 'today_bg', [ 'label' => __( 'Fondo de hoy', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-evcal' => '--wk-today: {{VALUE}};' ] ] );
		$this->add_control( 'ev_text', [ 'label' => __( 'Texto de los eventos', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#FFFFFF', 'selectors' => [ '{{WRAPPER}} .wakoo-evcal' => '--wk-ev-text: {{VALUE}};' ] ] );
		$this->add_responsive_control( 'radius', [
			'label'      => __( 'Redondez', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'range'      => [ 'px' => [ 'min' => 0, 'max' => 30 ] ],
			'default'    => [ 'size' => 14, 'unit' => 'px' ],
			'selectors'  => [ '{{WRAPPER}} .wakoo-evcal' => '--wk-radius: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_group_control( Group_Control_Border::get_type(), [ 'name' => 'box_border', 'selector' => '{{WRAPPER}} .wakoo-evcal' ] );
		$this->add_group_control( Group_Control_Box_Shadow::get_type(), [ 'name' => 'box_shadow', 'selector' => '{{WRAPPER}} .wakoo-evcal' ] );
		$this->add_responsive_control( 'pad', [ 'label' => __( 'Relleno', 'wakoo' ), 'type' => Controls_Manager::DIMENSIONS, 'size_units' => [ 'px', 'em' ], 'selectors' => [ '{{WRAPPER}} .wakoo-evcal' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ] ] );
		$this->end_controls_section();

		$this->start_controls_section( 'st_type', [ 'label' => __( 'Tipografía', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'ty_title', 'label' => __( 'Título (mes/semana)', 'wakoo' ), 'selector' => '{{WRAPPER}} .fc .fc-toolbar-title' ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'ty_head', 'label' => __( 'Días de la semana', 'wakoo' ), 'selector' => '{{WRAPPER}} .fc .fc-col-header-cell-cushion' ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'ty_event', 'label' => __( 'Eventos', 'wakoo' ), 'selector' => '{{WRAPPER}} .fc .fc-event-title, {{WRAPPER}} .fc .fc-event-time, {{WRAPPER}} .fc .fc-list-event-title' ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'ty_btn', 'label' => __( 'Botones', 'wakoo' ), 'selector' => '{{WRAPPER}} .fc .fc-button, {{WRAPPER}} .wakoo-evcal__chip' ] );
		$this->end_controls_section();

		$this->start_controls_section( 'st_btn', [ 'label' => __( 'Botones y filtros', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'btn_bg', [ 'label' => __( 'Fondo', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-evcal' => '--wk-btn-bg: {{VALUE}};' ] ] );
		$this->add_control( 'btn_color', [ 'label' => __( 'Texto', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-evcal' => '--wk-btn-text: {{VALUE}};' ] ] );
		$this->add_control( 'btn_active', [ 'label' => __( 'Fondo activo', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-evcal' => '--wk-btn-active: {{VALUE}};' ] ] );
		$this->add_control( 'btn_radius', [ 'label' => __( 'Redondez (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 999, 'selectors' => [ '{{WRAPPER}} .wakoo-evcal' => '--wk-btn-radius: {{VALUE}}px;' ] ] );
		$this->end_controls_section();

		$this->start_controls_section( 'st_modal', [ 'label' => __( 'Ventana de detalles', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE, 'condition' => [ 'click' => 'modal' ] ] );
		$this->add_control( 'm_bg', [ 'label' => __( 'Fondo', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-evcal' => '--wk-m-bg: {{VALUE}};' ] ] );
		$this->add_control( 'm_text', [ 'label' => __( 'Texto', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-evcal' => '--wk-m-text: {{VALUE}};' ] ] );
		$this->add_control( 'm_overlay', [ 'label' => __( 'Fondo exterior', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-evcal' => '--wk-m-overlay: {{VALUE}};' ] ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'ty_m_title', 'label' => __( 'Título', 'wakoo' ), 'selector' => '{{WRAPPER}} .wakoo-evm__title' ] );
		$this->end_controls_section();
	}

	/** Manual repeater rows → FullCalendar events (weekly/monthly repeats expanded up to "until" or 1 year). */
	private function manual_events( array $rows ) {
		$tz  = wp_timezone();
		$out = [];
		foreach ( $rows as $i => $r ) {
			$s = Recurrence::parse( $r['start'] ?? '' );
			if ( ! $s ) {
				continue;
			}
			$allday = 'yes' === ( $r['allday'] ?? '' );
			$en     = Recurrence::parse( $r['end'] ?? '' );
			$e      = [
				'start'   => $s->format( 'Y-m-d\TH:i' ),
				'end'     => $en ? $en->format( 'Y-m-d\TH:i' ) : '',
				'allday'  => $allday,
				'freq'    => in_array( $r['repeat'] ?? '', [ 'weekly', 'monthly' ], true ) ? $r['repeat'] : 'none',
				'interval'=> 1,
				'byday'   => [],
				'monthly' => 'date',
				'ends'    => ! empty( $r['repeat_until'] ) ? 'until' : 'never',
				'until'   => ! empty( $r['repeat_until'] ) ? substr( $r['repeat_until'], 0, 10 ) : '',
				'count'   => 0,
				'exdates' => [],
				'rdates'  => [],
			];
			$from  = $s->modify( '-1 day' );
			$to    = 'none' === $e['freq'] ? $s->modify( '+400 days' ) : ( new \DateTimeImmutable( 'now', $tz ) )->modify( '+1 year' );
			$color = $r['color'] ?? '';
			$cat   = trim( (string) ( $r['category'] ?? '' ) );
			$link  = $r['link']['url'] ?? '';
			foreach ( Recurrence::occurrences( $e, $from, $to, 120 ) as $o ) {
				$fmt = $allday ? 'Y-m-d' : 'Y-m-d\TH:i:s';
				$ev  = [
					'id'            => 'm' . $i . ':' . $o[2],
					'title'         => (string) ( $r['title'] ?? '' ),
					'start'         => $o[0]->format( $fmt ),
					'end'           => $o[1]->format( $fmt ),
					'allDay'        => $allday,
					'extendedProps' => [
						'manual'   => true,
						'excerpt'  => (string) ( $r['desc'] ?? '' ),
						'image'    => $r['image']['url'] ?? '',
						'location' => (string) ( $r['location'] ?? '' ),
						'cats'     => $cat ? [ [ 'slug' => sanitize_title( $cat ), 'name' => $cat, 'color' => $color ] ] : [],
						'status'   => 'scheduled',
						'when'     => Module::format_range( $o[0], $o[1], $allday ),
						'link'     => $link,
						'repeats'  => 'none' === $e['freq'] ? '' : Recurrence::describe( $e ),
					],
				];
				if ( $color ) {
					$ev['backgroundColor'] = $color;
					$ev['borderColor']     = $color;
				}
				$out[] = $ev;
			}
		}
		return $out;
	}

	protected function render() {
		$s      = $this->get_settings_for_display();
		$source = $s['source'] ?? 'native';
		$views  = array_values( array_intersect( array_keys( self::views() ), (array) ( $s['views'] ?? [] ) ) );
		$view   = isset( self::views()[ $s['view'] ?? '' ] ) ? $s['view'] : 'dayGridMonth';
		if ( ! in_array( $view, $views, true ) && $views ) {
			array_unshift( $views, $view );
		}
		$labels = [ 'today' => $s['l_today'] ?? __( 'Hoy', 'wakoo' ) ];
		foreach ( array_keys( self::views() ) as $v ) {
			$labels[ $v ] = $s[ 'l_' . $v ] ?? $v;
		}
		$cats = array_values( array_filter( (array) ( $s['cats'] ?? [] ) ) );

		// Filter chips: chosen categories (or all that have events) + manual categories.
		$chips = [];
		if ( 'manual' !== $source ) {
			$terms = get_terms( [ 'taxonomy' => Module::TAX, 'hide_empty' => true, 'slug' => $cats ?: '' ] );
			if ( ! is_wp_error( $terms ) ) {
				foreach ( $terms as $t ) {
					$chips[ $t->slug ] = [ 'slug' => $t->slug, 'name' => $t->name, 'color' => get_term_meta( $t->term_id, 'wk_color', true ) ?: '' ];
				}
			}
		}
		$manual = 'native' !== $source ? $this->manual_events( (array) ( $s['manual'] ?? [] ) ) : [];
		foreach ( $manual as $m ) {
			foreach ( $m['extendedProps']['cats'] as $c ) {
				$chips[ $c['slug'] ] = $chips[ $c['slug'] ] ?? $c;
			}
		}

		$first = 'wp' === ( $s['first_day'] ?? 'wp' ) ? (int) get_option( 'start_of_week', 1 ) : (int) $s['first_day'];
		$time  = function ( $v, $d ) { return preg_match( '/^\d{1,2}:\d{2}$/', (string) $v ) ? $v . ':00' : $d; };
		$cfg   = [
			'native'    => 'manual' !== $source,
			'manual'    => $manual,
			'cats'      => $cats,
			'view'      => $view,
			'views'     => $views,
			'mobile'    => isset( self::views()[ $s['mobile_view'] ?? '' ] ) ? $s['mobile_view'] : '',
			'labels'    => $labels,
			'locale'    => str_replace( '_', '-', strtolower( get_locale() ) ),
			'firstDay'  => $first,
			'weekends'  => 'yes' === ( $s['weekends'] ?? 'yes' ),
			'weekNums'  => 'yes' === ( $s['week_numbers'] ?? '' ),
			'maxEvents' => (int) ( $s['max_events'] ?? 3 ),
			'slotMin'   => $time( $s['slot_min'] ?? '', '07:00:00' ),
			'slotMax'   => $time( $s['slot_max'] ?? '', '23:00:00' ),
			'hour12'    => 'yes' === ( $s['hour12'] ?? '' ),
			'nowLine'   => 'yes' === ( $s['now_line'] ?? 'yes' ),
			'past'      => $s['past'] ?? 'dim',
			'display'   => $s['display'] ?? 'block',
			'height'    => 'fixed' === ( $s['height'] ?? 'auto' ) ? max( 300, (int) ( $s['height_px'] ?? 700 ) ) : 'auto',
			'today'     => 'yes' === ( $s['show_today'] ?? 'yes' ),
			'click'     => $s['click'] ?? 'modal',
			'tooltip'   => 'yes' === ( $s['tooltip'] ?? 'yes' ),
			'modal'     => [
				'image' => 'yes' === ( $s['modal_image'] ?? 'yes' ),
				'rsvp'  => 'yes' === ( $s['modal_rsvp'] ?? 'yes' ),
				'ics'   => 'yes' === ( $s['modal_ics'] ?? 'yes' ),
				'link'  => 'yes' === ( $s['modal_link'] ?? 'yes' ),
			],
			'tz'        => wp_timezone_string(),
		];

		echo '<div class="wakoo-evcal" data-wakoo="' . esc_attr( wp_json_encode( $cfg ) ) . '">';
		$tools = ( 'yes' === ( $s['show_filters'] ?? '' ) && count( $chips ) > 1 ) || 'yes' === ( $s['show_search'] ?? '' ) || ( 'manual' !== $source && 'yes' === ( $s['show_subscribe'] ?? '' ) );
		if ( $tools ) {
			echo '<div class="wakoo-evcal__tools">';
			if ( 'yes' === ( $s['show_filters'] ?? '' ) && count( $chips ) > 1 ) {
				echo '<div class="wakoo-evcal__chips" role="group" aria-label="' . esc_attr__( 'Filtrar por categoría', 'wakoo' ) . '">';
				echo '<button type="button" class="wakoo-evcal__chip is-active" data-cat="" aria-pressed="true">' . esc_html__( 'Todos', 'wakoo' ) . '</button>';
				foreach ( $chips as $c ) {
					$style = $c['color'] ? ' style="--wk-chip:' . esc_attr( $c['color'] ) . '"' : '';
					echo '<button type="button" class="wakoo-evcal__chip" data-cat="' . esc_attr( $c['slug'] ) . '" aria-pressed="false"' . $style . '><i></i>' . esc_html( $c['name'] ) . '</button>'; // phpcs:ignore
				}
				echo '</div>';
			}
			if ( 'yes' === ( $s['show_search'] ?? '' ) ) {
				echo '<label class="wakoo-evcal__search"><span class="screen-reader-text">' . esc_html__( 'Buscar', 'wakoo' ) . '</span><input type="search" placeholder="' . esc_attr( $s['search_ph'] ?? '' ) . '"></label>';
			}
			if ( 'manual' !== $source && 'yes' === ( $s['show_subscribe'] ?? '' ) ) {
				echo '<a class="wakoo-evcal__sub" href="' . esc_url( Module::ics_url( 0, implode( ',', $cats ) ) ) . '">' . esc_html( $s['subscribe_txt'] ?? '' ) . '</a>';
			}
			echo '</div>';
		}
		echo '<div class="wakoo-evcal__cal"></div>';
		echo '</div>';
	}
}
