<?php
/**
 * Wakoo Events: a native events calendar (no third-party plugin or service).
 *
 * - "Eventos" post type with dates, all-day, recurrence (daily / weekly on
 *   chosen days / monthly by date or nth weekday / yearly, until or N times,
 *   excluded and extra dates), place, online link, organizer, price, ticket
 *   link, status (cancelled, postponed, sold out) and color. Categories carry
 *   their own color. Events can be designed with Elementor.
 * - Native sign-up (RSVP) with capacity per occurrence; entries are saved as
 *   `wakoo_rsvp`, both sides get an email, and the list exports to CSV.
 * - Public JSON feed for the calendar, .ics download per event and an .ics
 *   subscription feed (works with Google, Apple and Outlook calendars).
 * - Single event pages get a details box, sign-up form, "add to calendar"
 *   button and schema.org Event data for search engines.
 * - Widgets: "Calendario de eventos (Wakoo)" and "Lista de eventos (Wakoo)".
 *
 * Calendar UI built on FullCalendar 6 (MIT), bundled locally in vendor/.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Events;

defined( 'ABSPATH' ) || die();

require_once __DIR__ . '/recurrence.php';

class Module {

	const CPT  = 'wakoo_event';
	const TAX  = 'wakoo_event_cat';
	const RSVP = 'wakoo_rsvp';
	const P    = Recurrence::P;
	const NS   = 'wakoo/v1';

	public static function init() {
		add_action( 'init', [ __CLASS__, 'register_types' ] );
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widgets' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'register_scripts' ] );
		add_action( 'elementor/frontend/after_register_styles', [ __CLASS__, 'register_styles' ] );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'single_assets' ] );
		add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );

		// Admin: event fields, category colors, columns, sign-ups.
		add_action( 'add_meta_boxes', [ __CLASS__, 'meta_boxes' ] );
		// Classic screen: the date/repeat fields sit right under the title (design the page with Elementor).
		add_filter( 'use_block_editor_for_post_type', function ( $use, $type ) { return self::CPT === $type ? false : $use; }, 10, 2 );
		add_action( 'save_post_' . self::CPT, [ __CLASS__, 'save' ], 10, 2 );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'admin_assets' ] );
		add_action( self::TAX . '_add_form_fields', [ __CLASS__, 'term_color_add' ] );
		add_action( self::TAX . '_edit_form_fields', [ __CLASS__, 'term_color_edit' ] );
		add_action( 'created_' . self::TAX, [ __CLASS__, 'term_color_save' ] );
		add_action( 'edited_' . self::TAX, [ __CLASS__, 'term_color_save' ] );
		add_filter( 'manage_' . self::CPT . '_posts_columns', [ __CLASS__, 'columns' ] );
		add_action( 'manage_' . self::CPT . '_posts_custom_column', [ __CLASS__, 'column' ], 10, 2 );
		add_filter( 'manage_edit-' . self::CPT . '_sortable_columns', function ( $c ) { $c['wk_when'] = 'wk_when'; return $c; } );
		add_action( 'pre_get_posts', [ __CLASS__, 'admin_order' ] );
		add_filter( 'manage_' . self::RSVP . '_posts_columns', [ __CLASS__, 'rsvp_columns' ] );
		add_action( 'manage_' . self::RSVP . '_posts_custom_column', [ __CLASS__, 'rsvp_column' ], 10, 2 );
		add_action( 'admin_post_wakoo_events_csv', [ __CLASS__, 'export_csv' ] );
		add_action( 'before_delete_post', [ __CLASS__, 'rsvp_removed' ] );
		add_action( 'wp_trash_post', [ __CLASS__, 'rsvp_removed' ] );
		add_action( 'untrashed_post', [ __CLASS__, 'rsvp_restored' ] );
		add_filter( 'wp_untrash_post_status', function ( $status, $id, $previous ) { return self::RSVP === get_post_type( $id ) ? $previous : $status; }, 10, 3 );

		// Front: single event page.
		add_filter( 'the_content', [ __CLASS__, 'single_content' ], 9 );
		add_action( 'wp_head', [ __CLASS__, 'schema' ] );
	}

	/* ------------------------------------------------------------------ */
	/* Types                                                               */
	/* ------------------------------------------------------------------ */

	public static function register_types() {
		register_post_type( self::CPT, [
			'labels'       => [
				'name'          => __( 'Eventos', 'wakoo' ),
				'singular_name' => __( 'Evento', 'wakoo' ),
				'add_new'       => __( 'Añadir evento', 'wakoo' ),
				'add_new_item'  => __( 'Añadir evento', 'wakoo' ),
				'edit_item'     => __( 'Editar evento', 'wakoo' ),
				'all_items'     => __( 'Todos los eventos', 'wakoo' ),
				'menu_name'     => __( 'Eventos Wakoo', 'wakoo' ),
				'search_items'  => __( 'Buscar eventos', 'wakoo' ),
				'not_found'     => __( 'No hay eventos', 'wakoo' ),
			],
			'public'       => true,
			'has_archive'  => true,
			'rewrite'      => [ 'slug' => _x( 'eventos', 'slug', 'wakoo' ) ],
			'menu_icon'    => 'dashicons-calendar-alt',
			'menu_position'=> 56,
			'show_in_rest' => true,
			'supports'     => [ 'title', 'editor', 'thumbnail', 'excerpt', 'elementor' ],
		] );
		register_taxonomy( self::TAX, self::CPT, [
			'labels'            => [
				'name'          => __( 'Categorías de eventos', 'wakoo' ),
				'singular_name' => __( 'Categoría de evento', 'wakoo' ),
				'menu_name'     => __( 'Categorías', 'wakoo' ),
			],
			'hierarchical'      => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'rewrite'           => [ 'slug' => _x( 'categoria-evento', 'slug', 'wakoo' ) ],
		] );
		register_post_type( self::RSVP, [
			'labels'          => [
				'name'          => __( 'Inscripciones', 'wakoo' ),
				'singular_name' => __( 'Inscripción', 'wakoo' ),
				'menu_name'     => __( 'Inscripciones', 'wakoo' ),
			],
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => 'edit.php?post_type=' . self::CPT,
			'capability_type' => 'post',
			'capabilities'    => [ 'create_posts' => 'do_not_allow' ],
			'map_meta_cap'    => true,
			'supports'        => [ 'title' ],
		] );
	}

	public static function register_widgets( $wm ) {
		require_once __DIR__ . '/widget-calendar.php';
		require_once __DIR__ . '/widget-list.php';
		$wm->register( new Calendar_Widget() );
		$wm->register( new List_Widget() );
	}

	public static function register_scripts() {
		$u = WAKOO_MODULES_URL . 'events/';
		wp_register_script( 'wakoo-fullcalendar', $u . 'vendor/fullcalendar.global.min.js', [], '6.1.22', true );
		wp_register_script( 'wakoo-fullcalendar-locales', $u . 'vendor/locales-all.global.min.js', [ 'wakoo-fullcalendar' ], '6.1.22', true );
		wp_register_script( 'wakoo-events', $u . 'assets/events.js', [], WAKOO_VERSION, true );
		wp_localize_script( 'wakoo-events', 'WakooEvents', self::js_globals() );
	}

	public static function register_styles() {
		wp_register_style( 'wakoo-events', WAKOO_MODULES_URL . 'events/assets/events.css', [], WAKOO_VERSION );
	}

	public static function js_globals() {
		return [
			'api'   => esc_url_raw( rest_url( self::NS . '/events' ) ),
			'i18n'  => [
				'close'     => __( 'Cerrar', 'wakoo' ),
				'allday'    => __( 'Todo el día', 'wakoo' ),
				'where'     => __( 'Lugar', 'wakoo' ),
				'online'    => __( 'Unirse en línea', 'wakoo' ),
				'price'     => __( 'Precio', 'wakoo' ),
				'free'      => __( 'Gratis', 'wakoo' ),
				'tickets'   => __( 'Entradas', 'wakoo' ),
				'ics'       => __( 'Añadir a mi calendario', 'wakoo' ),
				'more'      => __( 'Ver evento', 'wakoo' ),
				'signup'    => __( 'Inscribirme', 'wakoo' ),
				'name'      => __( 'Nombre', 'wakoo' ),
				'email'     => __( 'Email', 'wakoo' ),
				'seats'     => __( 'Plazas', 'wakoo' ),
				'send'      => __( 'Confirmar inscripción', 'wakoo' ),
				'sending'   => __( 'Enviando…', 'wakoo' ),
				'left'      => __( 'Quedan %d plazas', 'wakoo' ),
				'full'      => __( 'Completo', 'wakoo' ),
				'cancelled' => __( 'Cancelado', 'wakoo' ),
				'postponed' => __( 'Aplazado', 'wakoo' ),
				'soldout'   => __( 'Entradas agotadas', 'wakoo' ),
				'error'     => __( 'No se pudo enviar. Inténtalo de nuevo.', 'wakoo' ),
				'none'      => __( 'No hay eventos que coincidan.', 'wakoo' ),
				'all'       => __( 'Todos', 'wakoo' ),
				'repeats'   => __( 'Se repite', 'wakoo' ),
				'required'  => __( 'Escribe tu nombre y un email válido.', 'wakoo' ),
			],
		];
	}

	/** Single event pages: details box needs the shared CSS/JS. */
	public static function single_assets() {
		if ( ! is_singular( self::CPT ) ) {
			return;
		}
		self::register_scripts();
		self::register_styles();
		wp_enqueue_style( 'wakoo-events' );
		wp_enqueue_script( 'wakoo-events' );
	}

	/* ------------------------------------------------------------------ */
	/* Admin: event fields                                                 */
	/* ------------------------------------------------------------------ */

	public static function meta_boxes() {
		add_meta_box( 'wakoo-event-when', __( 'Fecha, repetición y detalles', 'wakoo' ), [ __CLASS__, 'box' ], self::CPT, 'normal', 'high' );
		add_meta_box( 'wakoo-event-rsvp', __( 'Inscripciones', 'wakoo' ), [ __CLASS__, 'box_rsvp' ], self::CPT, 'side' );
		add_meta_box( 'wakoo-rsvp-detail', __( 'Datos de la inscripción', 'wakoo' ), [ __CLASS__, 'box_rsvp_detail' ], self::RSVP, 'normal', 'high' );
	}

	public static function admin_assets( $hook ) {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ( self::CPT !== $screen->post_type ) ) {
			return;
		}
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wakoo-events-admin', WAKOO_MODULES_URL . 'events/assets/admin.js', [ 'wp-color-picker' ], WAKOO_VERSION, true );
		wp_enqueue_style( 'wakoo-events-admin', WAKOO_MODULES_URL . 'events/assets/admin.css', [], WAKOO_VERSION );
	}

	public static function box( $post ) {
		$e = Recurrence::get( $post->ID );
		if ( ! $e['start'] ) {
			$next       = ( new \DateTimeImmutable( 'tomorrow', wp_timezone() ) )->setTime( 19, 0 );
			$e['start'] = $next->format( 'Y-m-d\TH:i' );
			$e['end']   = $next->modify( '+2 hours' )->format( 'Y-m-d\TH:i' );
		}
		wp_nonce_field( 'wakoo_event_save', 'wakoo_event_nonce' );
		$f = function ( $k ) { return 'wk_ev[' . $k . ']'; };
		$days = [ 'mo' => 'L', 'tu' => 'M', 'we' => 'X', 'th' => 'J', 'fr' => 'V', 'sa' => 'S', 'su' => 'D' ];
		?>
		<div class="wakoo-evbox">
			<div class="wakoo-evbox__row">
				<label><?php esc_html_e( 'Empieza', 'wakoo' ); ?>
					<input type="datetime-local" name="<?php echo esc_attr( $f( 'start' ) ); ?>" value="<?php echo esc_attr( $e['start'] ); ?>" required></label>
				<label><?php esc_html_e( 'Termina', 'wakoo' ); ?>
					<input type="datetime-local" name="<?php echo esc_attr( $f( 'end' ) ); ?>" value="<?php echo esc_attr( $e['end'] ); ?>"></label>
				<label class="wakoo-evbox__check"><input type="checkbox" name="<?php echo esc_attr( $f( 'allday' ) ); ?>" value="1" <?php checked( $e['allday'] ); ?>> <?php esc_html_e( 'Todo el día', 'wakoo' ); ?></label>
			</div>

			<fieldset class="wakoo-evbox__rec">
				<legend><?php esc_html_e( 'Repetición', 'wakoo' ); ?></legend>
				<div class="wakoo-evbox__row">
					<label><?php esc_html_e( 'Se repite', 'wakoo' ); ?>
						<select name="<?php echo esc_attr( $f( 'freq' ) ); ?>" data-wk-freq>
							<?php foreach ( [ 'none' => __( 'No se repite', 'wakoo' ), 'daily' => __( 'Cada día', 'wakoo' ), 'weekly' => __( 'Cada semana', 'wakoo' ), 'monthly' => __( 'Cada mes', 'wakoo' ), 'yearly' => __( 'Cada año', 'wakoo' ) ] as $k => $l ) : ?>
								<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $e['freq'], $k ); ?>><?php echo esc_html( $l ); ?></option>
							<?php endforeach; ?>
						</select></label>
					<label data-wk-show="daily weekly monthly yearly"><?php esc_html_e( 'Cada', 'wakoo' ); ?>
						<input type="number" min="1" max="99" name="<?php echo esc_attr( $f( 'interval' ) ); ?>" value="<?php echo esc_attr( $e['interval'] ); ?>" style="width:70px"></label>
				</div>
				<div class="wakoo-evbox__row" data-wk-show="weekly">
					<span><?php esc_html_e( 'Días', 'wakoo' ); ?></span>
					<?php foreach ( $days as $code => $l ) : ?>
						<label class="wakoo-evbox__day"><input type="checkbox" name="<?php echo esc_attr( $f( 'byday' ) ); ?>[]" value="<?php echo esc_attr( $code ); ?>" <?php checked( in_array( $code, $e['byday'], true ) ); ?>><span><?php echo esc_html( $l ); ?></span></label>
					<?php endforeach; ?>
				</div>
				<div class="wakoo-evbox__row" data-wk-show="monthly">
					<label><input type="radio" name="<?php echo esc_attr( $f( 'monthly' ) ); ?>" value="date" <?php checked( 'nth' !== $e['monthly'] ); ?>> <?php esc_html_e( 'El mismo día del mes (p. ej. el 15)', 'wakoo' ); ?></label>
					<label><input type="radio" name="<?php echo esc_attr( $f( 'monthly' ) ); ?>" value="nth" <?php checked( 'nth' === $e['monthly'] ); ?>> <?php esc_html_e( 'El mismo día de la semana (p. ej. el 2.º martes)', 'wakoo' ); ?></label>
				</div>
				<div class="wakoo-evbox__row" data-wk-show="daily weekly monthly yearly">
					<label><?php esc_html_e( 'Termina', 'wakoo' ); ?>
						<select name="<?php echo esc_attr( $f( 'ends' ) ); ?>" data-wk-ends>
							<option value="never" <?php selected( $e['ends'], 'never' ); ?>><?php esc_html_e( 'Nunca', 'wakoo' ); ?></option>
							<option value="until" <?php selected( $e['ends'], 'until' ); ?>><?php esc_html_e( 'En una fecha', 'wakoo' ); ?></option>
							<option value="count" <?php selected( $e['ends'], 'count' ); ?>><?php esc_html_e( 'Tras N veces', 'wakoo' ); ?></option>
						</select></label>
					<label data-wk-ends-show="until"><input type="date" name="<?php echo esc_attr( $f( 'until' ) ); ?>" value="<?php echo esc_attr( $e['until'] ); ?>"></label>
					<label data-wk-ends-show="count"><input type="number" min="1" max="999" name="<?php echo esc_attr( $f( 'count' ) ); ?>" value="<?php echo esc_attr( $e['count'] ?: 10 ); ?>" style="width:80px"> <?php esc_html_e( 'veces', 'wakoo' ); ?></label>
				</div>
				<div class="wakoo-evbox__row" data-wk-show="daily weekly monthly yearly">
					<label class="wakoo-evbox__wide"><?php esc_html_e( 'Saltar estas fechas', 'wakoo' ); ?>
						<input type="text" name="<?php echo esc_attr( $f( 'exdates' ) ); ?>" value="<?php echo esc_attr( implode( ', ', $e['exdates'] ) ); ?>" placeholder="2026-12-25, 2027-01-01"></label>
				</div>
				<div class="wakoo-evbox__row">
					<label class="wakoo-evbox__wide"><?php esc_html_e( 'Fechas extra (misma hora)', 'wakoo' ); ?>
						<input type="text" name="<?php echo esc_attr( $f( 'rdates' ) ); ?>" value="<?php echo esc_attr( implode( ', ', $e['rdates'] ) ); ?>" placeholder="2026-11-03, 2026-11-17"></label>
				</div>
				<p class="description" data-wk-preview><?php echo esc_html( Recurrence::describe( $e ) ); ?></p>
			</fieldset>

			<div class="wakoo-evbox__grid">
				<label><?php esc_html_e( 'Lugar', 'wakoo' ); ?><input type="text" name="<?php echo esc_attr( $f( 'location' ) ); ?>" value="<?php echo esc_attr( $e['location'] ); ?>" placeholder="<?php esc_attr_e( 'Auditorio Central', 'wakoo' ); ?>"></label>
				<label><?php esc_html_e( 'Dirección', 'wakoo' ); ?><input type="text" name="<?php echo esc_attr( $f( 'address' ) ); ?>" value="<?php echo esc_attr( $e['address'] ); ?>"></label>
				<label><?php esc_html_e( 'Enlace para asistir en línea', 'wakoo' ); ?><input type="url" name="<?php echo esc_attr( $f( 'online' ) ); ?>" value="<?php echo esc_attr( $e['online'] ); ?>" placeholder="https://"></label>
				<label><?php esc_html_e( 'Organiza', 'wakoo' ); ?><input type="text" name="<?php echo esc_attr( $f( 'organizer' ) ); ?>" value="<?php echo esc_attr( $e['organizer'] ); ?>"></label>
				<label><?php esc_html_e( 'Precio (vacío o 0 = gratis)', 'wakoo' ); ?><input type="text" name="<?php echo esc_attr( $f( 'price' ) ); ?>" value="<?php echo esc_attr( $e['price'] ); ?>" placeholder="15"></label>
				<label><?php esc_html_e( 'Moneda', 'wakoo' ); ?><input type="text" maxlength="3" name="<?php echo esc_attr( $f( 'currency' ) ); ?>" value="<?php echo esc_attr( $e['currency'] ); ?>" style="width:70px"></label>
				<label><?php esc_html_e( 'Enlace de entradas', 'wakoo' ); ?><input type="url" name="<?php echo esc_attr( $f( 'ticket' ) ); ?>" value="<?php echo esc_attr( $e['ticket'] ); ?>" placeholder="https://"></label>
				<label><?php esc_html_e( 'Estado', 'wakoo' ); ?>
					<select name="<?php echo esc_attr( $f( 'status' ) ); ?>">
						<?php foreach ( self::statuses() as $k => $l ) : ?>
							<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $e['status'], $k ); ?>><?php echo esc_html( $l ); ?></option>
						<?php endforeach; ?>
					</select></label>
				<label><span><?php esc_html_e( 'Color (si no, el de la categoría)', 'wakoo' ); ?></span><input type="text" class="wakoo-color" name="<?php echo esc_attr( $f( 'color' ) ); ?>" value="<?php echo esc_attr( $e['color'] ); ?>"></label>
			</div>
		</div>
		<?php
	}

	public static function statuses() {
		return [
			'scheduled' => __( 'Programado', 'wakoo' ),
			'cancelled' => __( 'Cancelado', 'wakoo' ),
			'postponed' => __( 'Aplazado', 'wakoo' ),
			'soldout'   => __( 'Entradas agotadas', 'wakoo' ),
		];
	}

	public static function box_rsvp( $post ) {
		$e = Recurrence::get( $post->ID );
		?>
		<p><label><input type="checkbox" name="wk_ev[rsvp]" value="1" <?php checked( $e['rsvp'] ); ?>> <?php esc_html_e( 'Permitir inscribirse desde la web', 'wakoo' ); ?></label></p>
		<p><label><?php esc_html_e( 'Aforo por fecha (0 = sin límite)', 'wakoo' ); ?><br><input type="number" min="0" name="wk_ev[capacity]" value="<?php echo esc_attr( $e['capacity'] ); ?>" style="width:100px"></label></p>
		<p><label><?php esc_html_e( 'Máximo de plazas por persona', 'wakoo' ); ?><br><input type="number" min="1" max="50" name="wk_ev[max_seats]" value="<?php echo esc_attr( $e['max_seats'] ); ?>" style="width:100px"></label></p>
		<?php
		$total = array_sum( array_map( 'intval', $e['booked'] ) );
		if ( $total ) {
			echo '<p><strong>' . esc_html( sprintf( _n( '%d plaza reservada', '%d plazas reservadas', $total, 'wakoo' ), $total ) ) . '</strong></p><ul>';
			ksort( $e['booked'] );
			foreach ( $e['booked'] as $occ => $n ) {
				$t = Recurrence::parse( $occ );
				echo '<li>' . esc_html( ( $t ? wp_date( get_option( 'date_format' ), $t->getTimestamp() ) : $occ ) . ': ' . (int) $n ) . '</li>';
			}
			echo '</ul>';
		}
		$url = wp_nonce_url( admin_url( 'admin-post.php?action=wakoo_events_csv&event=' . $post->ID ), 'wakoo_events_csv' );
		echo '<p><a class="button" href="' . esc_url( $url ) . '">' . esc_html__( 'Descargar inscritos (CSV)', 'wakoo' ) . '</a></p>';
		echo '<p><a href="' . esc_url( self::ics_url( $post->ID ) ) . '">' . esc_html__( 'Descargar .ics de este evento', 'wakoo' ) . '</a></p>';
	}

	public static function save( $post_id, $post ) {
		if ( ! isset( $_POST['wakoo_event_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['wakoo_event_nonce'] ), 'wakoo_event_save' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$in = isset( $_POST['wk_ev'] ) ? wp_unslash( (array) $_POST['wk_ev'] ) : []; // phpcs:ignore
		self::save_data( $post_id, $in );
	}

	/** Validate and store event fields (also used by the demo seeder and tests). */
	public static function save_data( $post_id, array $in ) {
		$dt   = function ( $v ) { $v = sanitize_text_field( (string) $v ); return preg_match( '/^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2})?/', $v ) ? substr( $v, 0, 16 ) : ''; };
		$text = function ( $k ) use ( $in ) { return sanitize_text_field( $in[ $k ] ?? '' ); };
		$data = [
			'start'     => $dt( $in['start'] ?? '' ),
			'end'       => $dt( $in['end'] ?? '' ),
			'allday'    => empty( $in['allday'] ) ? 0 : 1,
			'freq'      => in_array( $in['freq'] ?? '', [ 'none', 'daily', 'weekly', 'monthly', 'yearly' ], true ) ? $in['freq'] : 'none',
			'interval'  => max( 1, min( 99, (int) ( $in['interval'] ?? 1 ) ) ),
			'byday'     => array_values( array_intersect( Recurrence::DAYS, array_map( 'sanitize_key', (array) ( $in['byday'] ?? [] ) ) ) ),
			'monthly'   => 'nth' === ( $in['monthly'] ?? '' ) ? 'nth' : 'date',
			'ends'      => in_array( $in['ends'] ?? '', [ 'never', 'until', 'count' ], true ) ? $in['ends'] : 'never',
			'until'     => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $in['until'] ?? '' ) ? $in['until'] : '',
			'count'     => max( 0, min( 999, (int) ( $in['count'] ?? 0 ) ) ),
			'exdates'   => implode( ',', Recurrence::date_list( $in['exdates'] ?? '' ) ),
			'rdates'    => implode( ',', Recurrence::date_list( $in['rdates'] ?? '' ) ),
			'location'  => $text( 'location' ),
			'address'   => $text( 'address' ),
			'online'    => esc_url_raw( $in['online'] ?? '' ),
			'organizer' => $text( 'organizer' ),
			'price'     => $text( 'price' ),
			'currency'  => strtoupper( substr( preg_replace( '/[^A-Za-z]/', '', $in['currency'] ?? 'EUR' ), 0, 3 ) ) ?: 'EUR',
			'ticket'    => esc_url_raw( $in['ticket'] ?? '' ),
			'status'    => array_key_exists( $in['status'] ?? '', self::statuses() ) ? $in['status'] : 'scheduled',
			'color'     => sanitize_hex_color( $in['color'] ?? '' ) ?: '',
			'rsvp'      => empty( $in['rsvp'] ) ? 0 : 1,
			'capacity'  => max( 0, (int) ( $in['capacity'] ?? 0 ) ),
			'max_seats' => max( 1, min( 50, (int) ( $in['max_seats'] ?? 4 ) ) ),
		];
		foreach ( $data as $k => $v ) {
			update_post_meta( $post_id, self::P . $k, $v );
		}
		$e = Recurrence::get( $post_id );
		$b = Recurrence::bounds( $e );
		update_post_meta( $post_id, self::P . 'start_ts', $b ? $b[0]->getTimestamp() : 0 );
		update_post_meta( $post_id, self::P . 'last_ts', Recurrence::last_ts( $e ) );
	}

	/* Category colors ---------------------------------------------------- */

	public static function term_color_add() {
		echo '<div class="form-field"><label for="wk-term-color">' . esc_html__( 'Color', 'wakoo' ) . '</label><input type="text" class="wakoo-color" id="wk-term-color" name="wk_term_color" value="#6C5CE7"><p>' . esc_html__( 'Color de los eventos de esta categoría en el calendario.', 'wakoo' ) . '</p></div>';
	}

	public static function term_color_edit( $term ) {
		$c = get_term_meta( $term->term_id, 'wk_color', true );
		echo '<tr class="form-field"><th><label for="wk-term-color">' . esc_html__( 'Color', 'wakoo' ) . '</label></th><td><input type="text" class="wakoo-color" id="wk-term-color" name="wk_term_color" value="' . esc_attr( $c ) . '"></td></tr>';
	}

	public static function term_color_save( $term_id ) {
		if ( isset( $_POST['wk_term_color'] ) && current_user_can( 'manage_categories' ) ) { // phpcs:ignore
			update_term_meta( $term_id, 'wk_color', sanitize_hex_color( wp_unslash( $_POST['wk_term_color'] ) ) ?: '' ); // phpcs:ignore
		}
	}

	/* Admin columns ------------------------------------------------------ */

	public static function columns( $c ) {
		$new = [];
		foreach ( $c as $k => $v ) {
			$new[ $k ] = $v;
			if ( 'title' === $k ) {
				$new['wk_when']  = __( 'Cuándo', 'wakoo' );
				$new['wk_rsvp']  = __( 'Inscritos', 'wakoo' );
			}
		}
		unset( $new['date'] );
		return $new;
	}

	public static function column( $col, $post_id ) {
		$e = Recurrence::get( $post_id );
		if ( 'wk_when' === $col ) {
			$b = Recurrence::bounds( $e );
			if ( $b ) {
				echo esc_html( self::format_range( $b[0], $b[1], $e['allday'] ) );
			}
			$rule = Recurrence::describe( $e );
			if ( $rule ) {
				echo '<br><small>↻ ' . esc_html( $rule ) . '</small>';
			}
			if ( 'scheduled' !== $e['status'] ) {
				echo '<br><strong>' . esc_html( self::statuses()[ $e['status'] ] ?? '' ) . '</strong>';
			}
		} elseif ( 'wk_rsvp' === $col ) {
			$n = array_sum( array_map( 'intval', $e['booked'] ) );
			echo $e['rsvp'] ? esc_html( $n . ( $e['capacity'] ? ' / ' . $e['capacity'] . ' ' . __( 'por fecha', 'wakoo' ) : '' ) ) : '—';
		}
	}

	public static function admin_order( $q ) {
		if ( ! is_admin() || ! $q->is_main_query() || self::CPT !== $q->get( 'post_type' ) ) {
			return;
		}
		if ( 'wk_when' === $q->get( 'orderby' ) || ! $q->get( 'orderby' ) ) {
			$q->set( 'meta_key', self::P . 'start_ts' );
			$q->set( 'orderby', 'meta_value_num' );
			if ( ! $q->get( 'order' ) ) {
				$q->set( 'order', 'DESC' );
			}
		}
	}

	/* ------------------------------------------------------------------ */
	/* Queries                                                             */
	/* ------------------------------------------------------------------ */

	/**
	 * Occurrences of published events in [$from, $to), sorted by start.
	 *
	 * @param array $args cats (slugs), search, limit, ids.
	 */
	public static function query( \DateTimeImmutable $from, \DateTimeImmutable $to, array $args = [] ) {
		$q = [
			'post_type'        => self::CPT,
			'post_status'      => 'publish',
			'posts_per_page'   => 500,
			'no_found_rows'    => true,
			'suppress_filters' => false,
			'meta_query'       => [ // phpcs:ignore
				'relation' => 'AND',
				[ 'key' => self::P . 'start_ts', 'value' => $to->getTimestamp(), 'compare' => '<', 'type' => 'NUMERIC' ],
				[ 'key' => self::P . 'last_ts', 'value' => $from->getTimestamp(), 'compare' => '>', 'type' => 'NUMERIC' ],
			],
		];
		if ( ! empty( $args['cats'] ) ) {
			$q['tax_query'] = [ [ 'taxonomy' => self::TAX, 'field' => 'slug', 'terms' => (array) $args['cats'] ] ]; // phpcs:ignore
		}
		if ( ! empty( $args['search'] ) ) {
			$q['s'] = $args['search'];
		}
		if ( ! empty( $args['ids'] ) ) {
			$q['post__in'] = array_map( 'intval', (array) $args['ids'] );
		}
		$limit = (int) ( $args['limit'] ?? 1000 );
		$out   = [];
		foreach ( get_posts( $q ) as $post ) {
			$e = Recurrence::get( $post->ID );
			foreach ( Recurrence::occurrences( $e, $from, $to, $limit ) as $o ) {
				$out[] = [ 'post' => $post, 'e' => $e, 'start' => $o[0], 'end' => $o[1], 'key' => $o[2] ];
			}
		}
		usort( $out, function ( $a, $b ) { return $a['start'] <=> $b['start'] ?: $a['post']->ID <=> $b['post']->ID; } );
		return array_slice( $out, 0, $limit );
	}

	public static function terms_of( $post_id ) {
		$out   = [];
		$terms = get_the_terms( $post_id, self::TAX );
		if ( $terms && ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$out[] = [ 'slug' => $t->slug, 'name' => $t->name, 'color' => get_term_meta( $t->term_id, 'wk_color', true ) ?: '' ];
			}
		}
		return $out;
	}

	/** Spots left for an occurrence, or null when unlimited. */
	public static function spots_left( array $e, $key ) {
		if ( ! $e['capacity'] ) {
			return null;
		}
		return max( 0, $e['capacity'] - (int) ( $e['booked'][ $key ] ?? 0 ) );
	}

	/** One occurrence as a FullCalendar event object. */
	public static function to_fc( array $o ) {
		$post  = $o['post'];
		$e     = $o['e'];
		$cats  = self::terms_of( $post->ID );
		$color = $e['color'] ?: ( $cats[0]['color'] ?? '' );
		$img   = get_the_post_thumbnail_url( $post, 'medium_large' );
		$fmt   = $e['allday'] ? 'Y-m-d' : 'Y-m-d\TH:i:s'; // Floating site-local time: shown as written.
		$ev    = [
			'id'            => $post->ID . ':' . $o['key'],
			'groupId'       => (string) $post->ID,
			'title'         => html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ),
			'start'         => $o['start']->format( $fmt ),
			'end'           => $o['end']->format( $fmt ),
			'allDay'        => $e['allday'],
			'url'           => get_permalink( $post ),
			'classNames'    => [ 'wakoo-ev--' . $e['status'] ],
			'extendedProps' => [
				'eid'      => $post->ID,
				'occ'      => $o['key'],
				'excerpt'  => wp_trim_words( wp_strip_all_tags( $post->post_excerpt ?: strip_shortcodes( $post->post_content ) ), 40 ),
				'image'    => $img ?: '',
				'location' => $e['location'],
				'address'  => $e['address'],
				'online'   => $e['online'],
				'organizer'=> $e['organizer'],
				'price'    => $e['price'],
				'currency' => $e['currency'],
				'ticket'   => $e['ticket'],
				'status'   => $e['status'],
				'cats'     => $cats,
				'rsvp'     => $e['rsvp'] && 'scheduled' === $e['status'] && $o['start']->getTimestamp() > time(),
				'left'     => self::spots_left( $e, $o['key'] ),
				'maxSeats' => $e['max_seats'],
				'repeats'  => Recurrence::describe( $e ),
				'ics'      => self::ics_url( $post->ID ),
				'when'     => self::format_range( $o['start'], $o['end'], $e['allday'] ),
			],
		];
		if ( $color ) {
			$ev['backgroundColor'] = $color;
			$ev['borderColor']     = $color;
		}
		return $ev;
	}

	/** "martes, 20 de octubre de 2026 · 19:00 – 21:00" style range in site locale. */
	public static function format_range( \DateTimeImmutable $s, \DateTimeImmutable $e, $allday ) {
		$df = get_option( 'date_format' );
		$tf = get_option( 'time_format' );
		if ( $allday ) {
			$last = $e->modify( '-1 day' );
			$txt  = wp_date( 'l, ' . $df, $s->getTimestamp() );
			if ( $last->format( 'Y-m-d' ) !== $s->format( 'Y-m-d' ) ) {
				$txt .= ' – ' . wp_date( 'l, ' . $df, $last->getTimestamp() );
			}
			return $txt . ' · ' . __( 'Todo el día', 'wakoo' );
		}
		if ( $s->format( 'Y-m-d' ) === $e->format( 'Y-m-d' ) ) {
			return wp_date( 'l, ' . $df, $s->getTimestamp() ) . ' · ' . wp_date( $tf, $s->getTimestamp() ) . ' – ' . wp_date( $tf, $e->getTimestamp() );
		}
		return wp_date( $df . ' ' . $tf, $s->getTimestamp() ) . ' – ' . wp_date( $df . ' ' . $tf, $e->getTimestamp() );
	}

	/* ------------------------------------------------------------------ */
	/* REST: feed, sign-up, .ics                                           */
	/* ------------------------------------------------------------------ */

	public static function routes() {
		register_rest_route( self::NS, '/events', [
			'methods'             => 'GET',
			'permission_callback' => '__return_true',
			'callback'            => [ __CLASS__, 'rest_feed' ],
		] );
		register_rest_route( self::NS, '/events/rsvp', [
			'methods'             => 'POST',
			'permission_callback' => '__return_true',
			'callback'            => [ __CLASS__, 'rest_rsvp' ],
		] );
		register_rest_route( self::NS, '/events/ics', [
			'methods'             => 'GET',
			'permission_callback' => '__return_true',
			'callback'            => [ __CLASS__, 'rest_ics' ],
		] );
	}

	private static function req_date( $v, $fallback ) {
		$v = (string) $v;
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ) {
			return Recurrence::parse( $v ) ?: $fallback;
		}
		if ( $v ) {
			try {
				return ( new \DateTimeImmutable( $v ) )->setTimezone( wp_timezone() );
			} catch ( \Exception $e ) {} // phpcs:ignore
		}
		return $fallback;
	}

	private static function req_cats( $raw ) {
		return array_filter( array_map( 'sanitize_title', explode( ',', (string) $raw ) ) );
	}

	public static function rest_feed( \WP_REST_Request $r ) {
		$tz   = wp_timezone();
		$from = self::req_date( $r['start'], new \DateTimeImmutable( 'first day of this month 00:00', $tz ) );
		$to   = self::req_date( $r['end'], $from->modify( '+6 weeks' ) );
		if ( $to <= $from || $to->getTimestamp() - $from->getTimestamp() > 400 * DAY_IN_SECONDS ) {
			$to = $from->modify( '+400 days' );
		}
		$list = self::query( $from, $to, [
			'cats'   => self::req_cats( $r['cats'] ),
			'search' => sanitize_text_field( (string) $r['search'] ),
			'limit'  => 2000,
		] );
		$resp = rest_ensure_response( array_map( [ __CLASS__, 'to_fc' ], $list ) );
		$resp->header( 'Cache-Control', 'public, max-age=60' );
		return $resp;
	}

	public static function rest_rsvp( \WP_REST_Request $r ) {
		$fail = function ( $msg, $code = 400 ) { return new \WP_Error( 'wakoo_rsvp', $msg, [ 'status' => $code ] ); };
		if ( '' !== (string) $r['website'] ) {
			return $fail( __( 'Solicitud no válida.', 'wakoo' ) ); // Honeypot.
		}
		$ip  = preg_replace( '/[^0-9a-f:.]/i', '', (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) ); // phpcs:ignore
		$key = 'wakoo_rsvp_' . md5( $ip );
		$hit = (int) get_transient( $key );
		if ( $hit >= 10 ) {
			return $fail( __( 'Demasiados intentos. Prueba en unos minutos.', 'wakoo' ), 429 );
		}
		set_transient( $key, $hit + 1, 10 * MINUTE_IN_SECONDS );

		$id   = (int) $r['event'];
		$occ  = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $r['occ'] ) ? (string) $r['occ'] : '';
		$name = sanitize_text_field( (string) $r['name'] );
		$mail = sanitize_email( (string) $r['email'] );
		$post = get_post( $id );
		if ( ! $post || self::CPT !== $post->post_type || 'publish' !== $post->post_status ) {
			return $fail( __( 'Evento no encontrado.', 'wakoo' ), 404 );
		}
		$e = Recurrence::get( $id );
		if ( ! $e['rsvp'] || 'scheduled' !== $e['status'] ) {
			return $fail( __( 'Este evento no admite inscripciones.', 'wakoo' ) );
		}
		if ( ! $name || ! is_email( $mail ) ) {
			return $fail( __( 'Escribe tu nombre y un email válido.', 'wakoo' ) );
		}
		// The date must be a real, future occurrence of this event.
		$day = $occ ? Recurrence::parse( $occ ) : null;
		$hit = $day ? Recurrence::occurrences( $e, $day->setTime( 0, 0 ), $day->setTime( 0, 0 )->modify( '+1 day' ), 5 ) : [];
		$hit = array_values( array_filter( $hit, function ( $o ) use ( $occ ) { return $o[2] === $occ; } ) );
		if ( ! $hit || $hit[0][0]->getTimestamp() < time() ) {
			return $fail( __( 'Esa fecha ya no está disponible.', 'wakoo' ) );
		}
		$seats = max( 1, min( $e['max_seats'], (int) ( $r['seats'] ?: 1 ) ) );
		$left  = self::spots_left( $e, $occ );
		if ( null !== $left && $seats > $left ) {
			return $fail( $left ? sprintf( _n( 'Solo queda %d plaza.', 'Solo quedan %d plazas.', $left, 'wakoo' ), $left ) : __( 'Ya no quedan plazas.', 'wakoo' ), 409 );
		}
		$rid = wp_insert_post( [
			'post_type'   => self::RSVP,
			'post_status' => 'publish',
			'post_title'  => $name . ' — ' . get_the_title( $post ),
			'meta_input'  => [ '_wk_event' => $id, '_wk_occ' => $occ, '_wk_name' => $name, '_wk_email' => $mail, '_wk_seats' => $seats ],
		], true );
		if ( is_wp_error( $rid ) ) {
			return $fail( __( 'No se pudo guardar la inscripción.', 'wakoo' ), 500 );
		}
		self::bump( $id, $occ, $seats );

		$when    = self::format_range( $hit[0][0], $hit[0][1], $e['allday'] );
		$title   = get_the_title( $post );
		$site    = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$lines   = [ $title, $when, $e['location'] . ( $e['address'] ? ', ' . $e['address'] : '' ), $e['online'], get_permalink( $post ) ];
		$details = implode( "\n", array_filter( $lines ) );
		wp_mail( get_option( 'admin_email' ), sprintf( __( '[%1$s] Nueva inscripción: %2$s', 'wakoo' ), $site, $title ),
			sprintf( __( "%1\$s (%2\$s) se ha inscrito con %3\$d plaza(s).\n\n%4\$s", 'wakoo' ), $name, $mail, $seats, $details ),
			[ 'Reply-To: ' . $name . ' <' . $mail . '>' ] );
		wp_mail( $mail, sprintf( __( 'Inscripción confirmada: %s', 'wakoo' ), $title ),
			sprintf( __( "Hola %1\$s,\n\nTu inscripción está confirmada (%2\$d plaza/s).\n\n%3\$s\n\nAñádelo a tu calendario: %4\$s\n\n%5\$s", 'wakoo' ), $name, $seats, $details, self::ics_url( $id ), $site ) );

		return rest_ensure_response( [
			'ok'      => true,
			'message' => sprintf( __( '¡Listo, %s! Te hemos enviado la confirmación por email.', 'wakoo' ), $name ),
			'left'    => self::spots_left( Recurrence::get( $id ), $occ ),
		] );
	}

	/** Keep the per-occurrence seat counter in sync. */
	private static function bump( $event_id, $occ, $delta ) {
		$booked         = (array) get_post_meta( $event_id, self::P . 'booked', true );
		$booked[ $occ ] = max( 0, (int) ( $booked[ $occ ] ?? 0 ) + $delta );
		if ( ! $booked[ $occ ] ) {
			unset( $booked[ $occ ] );
		}
		update_post_meta( $event_id, self::P . 'booked', array_filter( $booked ) );
	}

	public static function rsvp_removed( $post_id ) {
		$p = get_post( $post_id );
		if ( $p && self::RSVP === $p->post_type && 'trash' !== $p->post_status ) {
			self::bump( (int) get_post_meta( $post_id, '_wk_event', true ), (string) get_post_meta( $post_id, '_wk_occ', true ), -(int) get_post_meta( $post_id, '_wk_seats', true ) );
		}
	}

	public static function rsvp_restored( $post_id ) {
		$p = get_post( $post_id );
		if ( $p && self::RSVP === $p->post_type ) {
			self::bump( (int) get_post_meta( $post_id, '_wk_event', true ), (string) get_post_meta( $post_id, '_wk_occ', true ), (int) get_post_meta( $post_id, '_wk_seats', true ) );
		}
	}

	public static function ics_url( $event_id = 0, $cats = '' ) {
		$args = [];
		if ( $event_id ) {
			$args['event'] = (int) $event_id;
		}
		if ( $cats ) {
			$args['cats'] = $cats;
		}
		return add_query_arg( $args, rest_url( self::NS . '/events/ics' ) );
	}

	private static function ics_text( $s ) {
		$s = wp_strip_all_tags( html_entity_decode( (string) $s, ENT_QUOTES, 'UTF-8' ) );
		return str_replace( [ '\\', ';', ',', "\r\n", "\n" ], [ '\\\\', '\;', '\,', '\n', '\n' ], $s );
	}

	private static function ics_fold( $line ) {
		$out = '';
		while ( strlen( $line ) > 74 ) {
			$cut = 74;
			while ( $cut > 1 && ( ord( $line[ $cut ] ) & 0xC0 ) === 0x80 ) {
				$cut--; // Never split a UTF-8 character.
			}
			$out  .= substr( $line, 0, $cut ) . "\r\n ";
			$line  = substr( $line, $cut );
		}
		return $out . $line . "\r\n";
	}

	public static function ics_event( \WP_Post $post ) {
		$e = Recurrence::get( $post->ID );
		$b = Recurrence::bounds( $e );
		if ( ! $b ) {
			return '';
		}
		$tzname = wp_timezone_string();
		$named  = (bool) preg_match( '/^[A-Za-z]+\//', $tzname );
		$stamp  = function ( \DateTimeImmutable $d, $allday ) use ( $named, $tzname ) {
			if ( $allday ) {
				return ';VALUE=DATE:' . $d->format( 'Ymd' );
			}
			return $named ? ';TZID=' . $tzname . ':' . $d->format( 'Ymd\THis' ) : ':' . gmdate( 'Ymd\THis\Z', $d->getTimestamp() );
		};
		$loc = trim( $e['location'] . ( $e['address'] ? ', ' . $e['address'] : '' ), ', ' );
		$l   = [
			'BEGIN:VEVENT',
			'UID:wakoo-event-' . $post->ID . '@' . wp_parse_url( home_url(), PHP_URL_HOST ),
			'DTSTAMP:' . gmdate( 'Ymd\THis\Z', get_post_modified_time( 'U', true, $post ) ),
			'DTSTART' . $stamp( $b[0], $e['allday'] ),
			'DTEND' . $stamp( $b[1], $e['allday'] ),
			'SUMMARY:' . self::ics_text( get_the_title( $post ) ),
			'URL:' . get_permalink( $post ),
		];
		$desc = $post->post_excerpt ?: wp_trim_words( strip_shortcodes( $post->post_content ), 80 );
		$desc = trim( self::ics_text( $desc ) . ( $e['online'] ? '\n\n' . $e['online'] : '' ) . '\n\n' . get_permalink( $post ) );
		$l[]  = 'DESCRIPTION:' . $desc;
		if ( $loc ) {
			$l[] = 'LOCATION:' . self::ics_text( $loc );
		}
		$rule = Recurrence::rrule( $e );
		if ( $rule ) {
			$l[] = 'RRULE:' . $rule;
			foreach ( $e['exdates'] as $d ) {
				$x = Recurrence::parse( $d );
				if ( $x ) {
					$x   = $x->setTime( (int) $b[0]->format( 'H' ), (int) $b[0]->format( 'i' ) );
					$l[] = 'EXDATE' . $stamp( $x, $e['allday'] );
				}
			}
		}
		foreach ( $e['rdates'] as $d ) {
			$x = Recurrence::parse( $d );
			if ( $x ) {
				$x   = $x->setTime( (int) $b[0]->format( 'H' ), (int) $b[0]->format( 'i' ) );
				$l[] = 'RDATE' . $stamp( $x, $e['allday'] );
			}
		}
		if ( 'cancelled' === $e['status'] ) {
			$l[] = 'STATUS:CANCELLED';
		}
		$l[] = 'END:VEVENT';
		return implode( '', array_map( [ __CLASS__, 'ics_fold' ], $l ) );
	}

	/** VTIMEZONE built from PHP's tz database (Outlook needs it next to TZID). */
	private static function vtimezone( $name, $from_year, $to_year ) {
		try {
			$tz = new \DateTimeZone( $name );
		} catch ( \Exception $e ) {
			return '';
		}
		$trans = $tz->getTransitions( gmmktime( 0, 0, 0, 1, 1, $from_year ), gmmktime( 0, 0, 0, 12, 31, $to_year ) );
		$off   = function ( $sec ) { return ( $sec < 0 ? '-' : '+' ) . sprintf( '%02d%02d', abs( $sec ) / 3600, abs( $sec ) % 3600 / 60 ); };
		$out   = "BEGIN:VTIMEZONE\r\nTZID:" . $name . "\r\n";
		$prev  = $trans[0]['offset'];
		foreach ( $trans as $i => $t ) {
			if ( 0 === $i && count( $trans ) > 1 ) {
				continue; // First entry is just the state at $from_year.
			}
			$type  = $t['isdst'] ? 'DAYLIGHT' : 'STANDARD';
			$local = gmdate( 'Ymd\THis', $t['ts'] + $prev );
			$out  .= "BEGIN:$type\r\nDTSTART:$local\r\nTZOFFSETFROM:" . $off( $prev ) . "\r\nTZOFFSETTO:" . $off( $t['offset'] ) . "\r\nTZNAME:" . $t['abbr'] . "\r\nEND:$type\r\n";
			$prev  = $t['offset'];
		}
		if ( 1 === count( $trans ) ) {
			$t    = $trans[0];
			$out .= "BEGIN:STANDARD\r\nDTSTART:19700101T000000\r\nTZOFFSETFROM:" . $off( $t['offset'] ) . "\r\nTZOFFSETTO:" . $off( $t['offset'] ) . "\r\nTZNAME:" . $t['abbr'] . "\r\nEND:STANDARD\r\n";
		}
		return $out . "END:VTIMEZONE\r\n";
	}

	public static function rest_ics( \WP_REST_Request $r ) {
		$id = (int) $r['event'];
		if ( $id ) {
			$p     = get_post( $id );
			$posts = ( $p && self::CPT === $p->post_type && 'publish' === $p->post_status ) ? [ $p ] : [];
			$name  = $posts ? sanitize_title( $p->post_title ) : 'evento';
		} else {
			$q = [ 'post_type' => self::CPT, 'post_status' => 'publish', 'posts_per_page' => 500, 'no_found_rows' => true,
				'meta_query' => [ [ 'key' => self::P . 'last_ts', 'value' => time() - 90 * DAY_IN_SECONDS, 'compare' => '>', 'type' => 'NUMERIC' ] ] ]; // phpcs:ignore
			$cats = self::req_cats( $r['cats'] );
			if ( $cats ) {
				$q['tax_query'] = [ [ 'taxonomy' => self::TAX, 'field' => 'slug', 'terms' => $cats ] ]; // phpcs:ignore
			}
			$posts = get_posts( $q );
			$name  = sanitize_title( get_bloginfo( 'name' ) ) . '-eventos';
		}
		if ( ! $posts ) {
			return new \WP_Error( 'wakoo_ics', __( 'Evento no encontrado.', 'wakoo' ), [ 'status' => 404 ] );
		}
		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$out  = "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//Wakoo//Eventos//ES\r\nCALSCALE:GREGORIAN\r\nMETHOD:PUBLISH\r\n";
		$out .= self::ics_fold( 'X-WR-CALNAME:' . self::ics_text( $id ? get_the_title( $posts[0] ) : $site ) );
		$out .= self::ics_fold( 'X-WR-TIMEZONE:' . wp_timezone_string() );
		if ( preg_match( '/^[A-Za-z]+\//', wp_timezone_string() ) ) {
			$first = (int) gmdate( 'Y' );
			foreach ( $posts as $p ) {
				$first = min( $first, (int) substr( (string) get_post_meta( $p->ID, self::P . 'start', true ), 0, 4 ) ?: $first );
			}
			$out .= self::vtimezone( wp_timezone_string(), $first - 1, (int) gmdate( 'Y' ) + 10 );
		}
		foreach ( $posts as $p ) {
			$out .= self::ics_event( $p );
		}
		$out .= "END:VCALENDAR\r\n";

		nocache_headers();
		header( 'Content-Type: text/calendar; charset=utf-8' );
		header( 'Content-Disposition: ' . ( $id ? 'attachment' : 'inline' ) . '; filename="' . $name . '.ics"' );
		echo $out; // phpcs:ignore -- iCalendar text, escaped above.
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Sign-ups admin + CSV                                                */
	/* ------------------------------------------------------------------ */

	public static function rsvp_columns( $c ) {
		return [ 'cb' => $c['cb'] ?? '', 'title' => __( 'Inscripción', 'wakoo' ), 'wk_event' => __( 'Evento', 'wakoo' ), 'wk_occ' => __( 'Fecha', 'wakoo' ), 'wk_email' => __( 'Email', 'wakoo' ), 'wk_seats' => __( 'Plazas', 'wakoo' ), 'date' => __( 'Recibida', 'wakoo' ) ];
	}

	public static function rsvp_column( $col, $id ) {
		switch ( $col ) {
			case 'wk_event':
				$ev = (int) get_post_meta( $id, '_wk_event', true );
				echo $ev ? '<a href="' . esc_url( get_edit_post_link( $ev ) ) . '">' . esc_html( get_the_title( $ev ) ) . '</a>' : '—';
				break;
			case 'wk_occ':
				echo esc_html( get_post_meta( $id, '_wk_occ', true ) );
				break;
			case 'wk_email':
				$m = get_post_meta( $id, '_wk_email', true );
				echo '<a href="mailto:' . esc_attr( $m ) . '">' . esc_html( $m ) . '</a>';
				break;
			case 'wk_seats':
				echo (int) get_post_meta( $id, '_wk_seats', true );
				break;
		}
	}

	public static function box_rsvp_detail( $post ) {
		$ev = (int) get_post_meta( $post->ID, '_wk_event', true );
		echo '<table class="form-table"><tbody>';
		foreach ( [
			__( 'Evento', 'wakoo' ) => $ev ? get_the_title( $ev ) : '—',
			__( 'Fecha', 'wakoo' )  => get_post_meta( $post->ID, '_wk_occ', true ),
			__( 'Nombre', 'wakoo' ) => get_post_meta( $post->ID, '_wk_name', true ),
			__( 'Email', 'wakoo' )  => get_post_meta( $post->ID, '_wk_email', true ),
			__( 'Plazas', 'wakoo' ) => get_post_meta( $post->ID, '_wk_seats', true ),
		] as $k => $v ) {
			echo '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	public static function export_csv() {
		if ( ! current_user_can( 'edit_posts' ) || ! check_admin_referer( 'wakoo_events_csv' ) ) {
			wp_die( esc_html__( 'Sin permiso.', 'wakoo' ) );
		}
		$event = isset( $_GET['event'] ) ? (int) $_GET['event'] : 0;
		$q     = [ 'post_type' => self::RSVP, 'post_status' => 'publish', 'posts_per_page' => -1, 'orderby' => 'date', 'order' => 'ASC' ];
		if ( $event ) {
			$q['meta_query'] = [ [ 'key' => '_wk_event', 'value' => $event ] ]; // phpcs:ignore
		}
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="inscritos-' . ( $event ? sanitize_title( get_the_title( $event ) ) : 'eventos' ) . '.csv"' );
		$fh = fopen( 'php://output', 'w' );
		fwrite( $fh, "\xEF\xBB\xBF" );
		fputcsv( $fh, [ __( 'Evento', 'wakoo' ), __( 'Fecha', 'wakoo' ), __( 'Nombre', 'wakoo' ), __( 'Email', 'wakoo' ), __( 'Plazas', 'wakoo' ), __( 'Recibida', 'wakoo' ) ] );
		$safe = function ( $v ) { $v = (string) $v; return preg_match( '/^[=+\-@\t\r]/', $v ) ? "'" . $v : $v; };
		foreach ( get_posts( $q ) as $p ) {
			fputcsv( $fh, array_map( $safe, [
				get_the_title( (int) get_post_meta( $p->ID, '_wk_event', true ) ),
				get_post_meta( $p->ID, '_wk_occ', true ),
				get_post_meta( $p->ID, '_wk_name', true ),
				get_post_meta( $p->ID, '_wk_email', true ),
				get_post_meta( $p->ID, '_wk_seats', true ),
				get_the_date( 'Y-m-d H:i', $p ),
			] ) );
		}
		fclose( $fh );
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Single event page                                                   */
	/* ------------------------------------------------------------------ */

	/** Upcoming occurrences of one event (next $n). */
	public static function upcoming( $post_id, $n = 6 ) {
		$e   = Recurrence::get( $post_id );
		$now = new \DateTimeImmutable( 'now', wp_timezone() );
		return Recurrence::occurrences( $e, $now, $now->modify( '+3 years' ), $n );
	}

	public static function single_content( $content ) {
		if ( ! is_singular( self::CPT ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}
		$post = get_post();
		if ( ! $post || get_post_meta( $post->ID, '_wk_ev_hide_box', true ) ) {
			return $content;
		}
		return self::details_box( $post ) . $content;
	}

	/** Details box: dates, place, price, status, add-to-calendar and sign-up. */
	public static function details_box( \WP_Post $post ) {
		$e    = Recurrence::get( $post->ID );
		$next = self::upcoming( $post->ID, 8 );
		$b    = Recurrence::bounds( $e );
		if ( ! $b ) {
			return '';
		}
		$first = $next ? $next[0] : [ $b[0], $b[1], $b[0]->format( 'Y-m-d' ) ];
		ob_start();
		echo '<div class="wakoo-evd">';
		if ( 'scheduled' !== $e['status'] ) {
			echo '<p class="wakoo-evd__status wakoo-evd__status--' . esc_attr( $e['status'] ) . '">' . esc_html( self::statuses()[ $e['status'] ] ) . '</p>';
		}
		echo '<ul class="wakoo-evd__facts">';
		echo '<li><span class="wakoo-evd__k">' . esc_html__( 'Cuándo', 'wakoo' ) . '</span><span>' . esc_html( self::format_range( $first[0], $first[1], $e['allday'] ) ) . '</span></li>';
		$rule = Recurrence::describe( $e );
		if ( $rule ) {
			echo '<li><span class="wakoo-evd__k">' . esc_html__( 'Se repite', 'wakoo' ) . '</span><span>' . esc_html( $rule ) . '</span></li>';
		}
		if ( $e['location'] || $e['address'] ) {
			echo '<li><span class="wakoo-evd__k">' . esc_html__( 'Lugar', 'wakoo' ) . '</span><span>' . esc_html( trim( $e['location'] . ( $e['address'] ? ' · ' . $e['address'] : '' ), ' ·' ) ) . '</span></li>';
		}
		if ( $e['organizer'] ) {
			echo '<li><span class="wakoo-evd__k">' . esc_html__( 'Organiza', 'wakoo' ) . '</span><span>' . esc_html( $e['organizer'] ) . '</span></li>';
		}
		echo '<li><span class="wakoo-evd__k">' . esc_html__( 'Precio', 'wakoo' ) . '</span><span>' . esc_html( self::price_label( $e ) ) . '</span></li>';
		echo '</ul><div class="wakoo-evd__actions">';
		if ( $e['ticket'] && 'scheduled' === $e['status'] ) {
			echo '<a class="wakoo-evbtn" href="' . esc_url( $e['ticket'] ) . '" target="_blank" rel="noopener">' . esc_html__( 'Entradas', 'wakoo' ) . '</a>';
		}
		if ( $e['online'] ) {
			echo '<a class="wakoo-evbtn wakoo-evbtn--ghost" href="' . esc_url( $e['online'] ) . '" target="_blank" rel="noopener">' . esc_html__( 'Unirse en línea', 'wakoo' ) . '</a>';
		}
		echo '<a class="wakoo-evbtn wakoo-evbtn--ghost" href="' . esc_url( self::ics_url( $post->ID ) ) . '">' . esc_html__( 'Añadir a mi calendario', 'wakoo' ) . '</a>';
		echo '</div>';
		if ( count( $next ) > 1 ) {
			echo '<details class="wakoo-evd__next"><summary>' . esc_html__( 'Próximas fechas', 'wakoo' ) . '</summary><ul>';
			foreach ( $next as $o ) {
				$left = self::spots_left( $e, $o[2] );
				echo '<li>' . esc_html( self::format_range( $o[0], $o[1], $e['allday'] ) ) . ( null !== $left ? ' <small>(' . esc_html( $left ? sprintf( __( 'quedan %d', 'wakoo' ), $left ) : __( 'completo', 'wakoo' ) ) . ')</small>' : '' ) . '</li>';
			}
			echo '</ul></details>';
		}
		if ( $e['rsvp'] && 'scheduled' === $e['status'] && $next ) {
			echo self::rsvp_form( $post->ID, $e, $next ); // phpcs:ignore -- escaped inside.
		}
		echo '</div>';
		return ob_get_clean();
	}

	public static function price_label( array $e ) {
		$p = trim( (string) $e['price'] );
		if ( '' === $p || '0' === $p || 0.0 === (float) str_replace( ',', '.', $p ) && is_numeric( str_replace( ',', '.', $p ) ) ) {
			return __( 'Gratis', 'wakoo' );
		}
		$sym = [ 'EUR' => '€', 'USD' => '$', 'GBP' => '£', 'MXN' => '$', 'ARS' => '$', 'COP' => '$', 'CLP' => '$' ];
		return is_numeric( str_replace( ',', '.', $p ) ) ? $p . ' ' . ( $sym[ $e['currency'] ] ?? $e['currency'] ) : $p;
	}

	/** Inline sign-up form (single page). The calendar modal builds its own in JS. */
	public static function rsvp_form( $post_id, array $e, array $next ) {
		ob_start();
		echo '<form class="wakoo-evrsvp" data-event="' . (int) $post_id . '" novalidate>';
		echo '<h3 class="wakoo-evrsvp__title">' . esc_html__( 'Inscríbete', 'wakoo' ) . '</h3><div class="wakoo-evrsvp__fields">';
		echo '<label>' . esc_html__( 'Fecha', 'wakoo' ) . '<select name="occ">';
		foreach ( $next as $o ) {
			$left = self::spots_left( $e, $o[2] );
			echo '<option value="' . esc_attr( $o[2] ) . '"' . disabled( 0 === $left, true, false ) . '>' . esc_html( self::format_range( $o[0], $o[1], $e['allday'] ) . ( 0 === $left ? ' — ' . __( 'completo', 'wakoo' ) : '' ) ) . '</option>';
		}
		echo '</select></label>';
		echo '<label>' . esc_html__( 'Nombre', 'wakoo' ) . '<input name="name" required autocomplete="name"></label>';
		echo '<label>' . esc_html__( 'Email', 'wakoo' ) . '<input name="email" type="email" required autocomplete="email"></label>';
		echo '<label>' . esc_html__( 'Plazas', 'wakoo' ) . '<input name="seats" type="number" min="1" max="' . (int) $e['max_seats'] . '" value="1"></label>';
		echo '<input name="website" class="wakoo-evrsvp__hp" tabindex="-1" autocomplete="off" aria-hidden="true">';
		echo '</div><button type="submit" class="wakoo-evbtn">' . esc_html__( 'Confirmar inscripción', 'wakoo' ) . '</button><p class="wakoo-evrsvp__msg" role="status" aria-live="polite"></p></form>';
		return ob_get_clean();
	}

	/** schema.org Event (helps Google show the event in search). */
	public static function schema() {
		if ( ! is_singular( self::CPT ) ) {
			return;
		}
		$post = get_post();
		$e    = Recurrence::get( $post->ID );
		$next = self::upcoming( $post->ID, 1 );
		$b    = $next ? $next[0] : Recurrence::bounds( $e );
		if ( ! $b ) {
			return;
		}
		$status = [ 'scheduled' => 'EventScheduled', 'cancelled' => 'EventCancelled', 'postponed' => 'EventPostponed', 'soldout' => 'EventScheduled' ];
		$data   = [
			'@context'    => 'https://schema.org',
			'@type'       => 'Event',
			'name'        => get_the_title( $post ),
			'startDate'   => $e['allday'] ? $b[0]->format( 'Y-m-d' ) : $b[0]->format( 'c' ),
			'endDate'     => $e['allday'] ? $b[1]->modify( '-1 day' )->format( 'Y-m-d' ) : $b[1]->format( 'c' ),
			'eventStatus' => 'https://schema.org/' . $status[ $e['status'] ],
			'url'         => get_permalink( $post ),
			'description' => wp_strip_all_tags( get_the_excerpt( $post ) ),
		];
		$img = get_the_post_thumbnail_url( $post, 'large' );
		if ( $img ) {
			$data['image'] = [ $img ];
		}
		$places = [];
		if ( $e['location'] || $e['address'] ) {
			$places[] = [ '@type' => 'Place', 'name' => $e['location'] ?: $e['address'], 'address' => $e['address'] ?: $e['location'] ];
		}
		if ( $e['online'] ) {
			$places[] = [ '@type' => 'VirtualLocation', 'url' => $e['online'] ];
		}
		if ( $places ) {
			$data['location']            = 1 === count( $places ) ? $places[0] : $places;
			$data['eventAttendanceMode'] = 'https://schema.org/' . ( count( $places ) > 1 ? 'MixedEventAttendanceMode' : ( $e['online'] ? 'OnlineEventAttendanceMode' : 'OfflineEventAttendanceMode' ) );
		}
		if ( $e['organizer'] ) {
			$data['organizer'] = [ '@type' => 'Organization', 'name' => $e['organizer'] ];
		}
		$price          = is_numeric( str_replace( ',', '.', $e['price'] ) ) ? str_replace( ',', '.', $e['price'] ) : '0';
		$data['offers'] = [
			'@type'         => 'Offer',
			'price'         => $price ?: '0',
			'priceCurrency' => $e['currency'],
			'availability'  => 'https://schema.org/' . ( 'soldout' === $e['status'] ? 'SoldOut' : 'InStock' ),
			'url'           => $e['ticket'] ?: get_permalink( $post ),
		];
		echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . "</script>\n";
	}
}

Module::init();
