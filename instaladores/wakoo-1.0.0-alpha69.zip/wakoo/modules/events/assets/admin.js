/* Wakoo Events admin: show only the recurrence fields that apply + color pickers. */
( function ( $ ) {
	'use strict';
	$( function () {
		if ( $.fn.wpColorPicker ) { $( '.wakoo-color' ).wpColorPicker(); }
		var box = $( '.wakoo-evbox' );
		if ( ! box.length ) { return; }
		function sync() {
			var f = box.find( '[data-wk-freq]' ).val();
			var ends = box.find( '[data-wk-ends]' ).val();
			box.find( '[data-wk-show]' ).each( function () {
				$( this ).toggle( ( ' ' + this.getAttribute( 'data-wk-show' ) + ' ' ).indexOf( ' ' + f + ' ' ) > -1 );
			} );
			box.find( '[data-wk-ends-show]' ).each( function () {
				$( this ).toggle( 'none' !== f && this.getAttribute( 'data-wk-ends-show' ) === ends );
			} );
			var allday = box.find( '[name="wk_ev[allday]"]' ).is( ':checked' );
			box.find( 'input[type=datetime-local]' ).each( function () { this.step = allday ? 86400 : 60; } );
		}
		box.on( 'change', 'select,input', sync );
		sync();
	} );
}( window.jQuery ) );
