/* Wakoo Events: calendar widget (FullCalendar 6, MIT) + sign-up forms. */
( function () {
	'use strict';
	var G = window.WakooEvents || { api: '', i18n: {} };
	var T = G.i18n || {};
	var SYM = { EUR: '€', USD: '$', GBP: '£', MXN: '$', ARS: '$', COP: '$', CLP: '$' };

	function el( tag, cls, text ) {
		var n = document.createElement( tag );
		if ( cls ) { n.className = cls; }
		if ( null != text && '' !== text ) { n.textContent = text; }
		return n;
	}
	function priceLabel( p, cur ) {
		p = ( p || '' ).toString().trim();
		var num = parseFloat( p.replace( ',', '.' ) );
		if ( ! p || ( ! isNaN( num ) && 0 === num && /^[\d.,\s]+$/.test( p ) ) ) { return T.free; }
		return /^[\d.,\s]+$/.test( p ) ? p + ' ' + ( SYM[ cur ] || cur || '' ) : p;
	}
	function safeUrl( u ) { return /^(https?:)?\/\//i.test( u || '' ) || /^\//.test( u || '' ) ? u : ''; }
	function fmt( s, n ) { return ( s || '' ).replace( '%d', n ); }
	function btn( cls, text, href, ext ) {
		var a = el( 'a', 'wakoo-evbtn' + ( cls ? ' ' + cls : '' ), text );
		a.href = href;
		if ( ext ) { a.target = '_blank'; a.rel = 'noopener'; }
		return a;
	}

	/* ---------------------------------------------------------------- */
	/* Sign-up                                                           */
	/* ---------------------------------------------------------------- */
	function submitRsvp( form, eventId, done ) {
		var msg = form.querySelector( '.wakoo-evrsvp__msg' );
		var b = form.querySelector( 'button[type=submit]' );
		var data = {};
		Array.prototype.forEach.call( form.elements, function ( f ) { if ( f.name ) { data[ f.name ] = f.value; } } );
		data.event = eventId;
		if ( ! data.name || ! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test( data.email || '' ) ) {
			msg.textContent = T.required;
			msg.className = 'wakoo-evrsvp__msg is-error';
			( data.name ? form.querySelector( '[name=email]' ) : form.querySelector( '[name=name]' ) ).focus();
			return;
		}
		var label = b.textContent;
		b.disabled = true; b.textContent = T.sending;
		fetch( G.api + '/rsvp', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify( data ) } )
			.then( function ( r ) { return r.json().then( function ( j ) { return { ok: r.ok, j: j }; } ); } )
			.then( function ( res ) {
				if ( res.ok && res.j.ok ) {
					msg.textContent = res.j.message; msg.className = 'wakoo-evrsvp__msg is-ok';
					form.classList.add( 'is-done' );
					Array.prototype.forEach.call( form.querySelectorAll( 'input,select' ), function ( f ) { f.disabled = true; } );
					b.hidden = true;
					if ( done ) { done( res.j ); }
				} else {
					msg.textContent = ( res.j && res.j.message ) || T.error; msg.className = 'wakoo-evrsvp__msg is-error';
					b.disabled = false; b.textContent = label;
				}
			} )
			.catch( function () { msg.textContent = T.error; msg.className = 'wakoo-evrsvp__msg is-error'; b.disabled = false; b.textContent = label; } );
	}

	function wireStaticForms( scope ) {
		Array.prototype.forEach.call( scope.querySelectorAll( 'form.wakoo-evrsvp[data-event]' ), function ( f ) {
			if ( f.dataset.wakooInit ) { return; }
			f.dataset.wakooInit = '1';
			f.addEventListener( 'submit', function ( ev ) { ev.preventDefault(); submitRsvp( f, f.getAttribute( 'data-event' ) ); } );
		} );
	}

	/* ---------------------------------------------------------------- */
	/* Details window                                                    */
	/* ---------------------------------------------------------------- */
	function Modal( root, cfg, onBooked ) {
		var wrap = el( 'div', 'wakoo-evm' );
		wrap.hidden = true;
		wrap.innerHTML = '<div class="wakoo-evm__overlay" data-close></div><div class="wakoo-evm__box" role="dialog" aria-modal="true" tabindex="-1"><button type="button" class="wakoo-evm__x" data-close></button><div class="wakoo-evm__body"></div></div>';
		root.appendChild( wrap );
		var box = wrap.querySelector( '.wakoo-evm__box' );
		var body = wrap.querySelector( '.wakoo-evm__body' );
		var x = wrap.querySelector( '.wakoo-evm__x' );
		x.setAttribute( 'aria-label', T.close ); x.textContent = '×';
		var last = null;

		function close() {
			wrap.hidden = true;
			document.documentElement.classList.remove( 'wakoo-evm-open' );
			document.removeEventListener( 'keydown', onKey );
			if ( last && last.focus ) { last.focus(); }
		}
		function onKey( e ) {
			if ( 'Escape' === e.key ) { close(); return; }
			if ( 'Tab' !== e.key ) { return; }
			var f = box.querySelectorAll( 'a[href],button:not([disabled]),input:not([disabled]):not([tabindex="-1"]),select:not([disabled]),textarea' );
			if ( ! f.length ) { return; }
			var first = f[ 0 ], end = f[ f.length - 1 ];
			if ( e.shiftKey && document.activeElement === first ) { e.preventDefault(); end.focus(); }
			else if ( ! e.shiftKey && document.activeElement === end ) { e.preventDefault(); first.focus(); }
		}
		wrap.addEventListener( 'click', function ( e ) { if ( e.target.hasAttribute( 'data-close' ) ) { close(); } } );

		this.open = function ( ev, trigger ) {
			var p = ev.extendedProps || {};
			last = trigger || document.activeElement;
			body.innerHTML = '';
			if ( cfg.modal.image && p.image ) {
				var fig = el( 'div', 'wakoo-evm__img' ); var im = el( 'img' ); im.src = p.image; im.alt = ''; fig.appendChild( im ); body.appendChild( fig );
			}
			var inner = el( 'div', 'wakoo-evm__inner' );
			body.appendChild( inner );
			if ( p.cats && p.cats.length ) {
				var cats = el( 'div', 'wakoo-evm__cats' );
				p.cats.forEach( function ( c ) { var s = el( 'span', '', c.name ); if ( c.color ) { s.style.setProperty( '--wk-chip', c.color ); } cats.appendChild( s ); } );
				inner.appendChild( cats );
			}
			if ( p.status && 'scheduled' !== p.status ) { inner.appendChild( el( 'p', 'wakoo-evm__status wakoo-evm__status--' + p.status, T[ p.status ] ) ); }
			var h = el( 'h3', 'wakoo-evm__title', ev.title ); h.id = 'wk-evm-' + Math.random().toString( 36 ).slice( 2 );
			box.setAttribute( 'aria-labelledby', h.id );
			inner.appendChild( h );
			var facts = el( 'ul', 'wakoo-evm__facts' );
			function fact( cls, text ) { if ( text ) { facts.appendChild( el( 'li', 'wakoo-evm__f wakoo-evm__f--' + cls, text ) ); } }
			fact( 'when', p.when );
			fact( 'repeat', p.repeats ? T.repeats + ': ' + p.repeats : '' );
			fact( 'where', [ p.location, p.address ].filter( Boolean ).join( ' · ' ) );
			if ( ! p.manual ) { fact( 'price', T.price + ': ' + priceLabel( p.price, p.currency ) ); }
			if ( null != p.left && p.rsvp ) { fact( 'spots', p.left ? fmt( T.left, p.left ) : T.full ); }
			inner.appendChild( facts );
			if ( p.excerpt ) { inner.appendChild( el( 'p', 'wakoo-evm__desc', p.excerpt ) ); }

			var acts = el( 'div', 'wakoo-evm__actions' );
			if ( p.ticket && 'scheduled' === p.status && safeUrl( p.ticket ) ) { acts.appendChild( btn( '', T.tickets, p.ticket, true ) ); }
			if ( p.online && safeUrl( p.online ) ) { acts.appendChild( btn( 'wakoo-evbtn--ghost', T.online, p.online, true ) ); }
			if ( cfg.modal.ics && p.ics ) { acts.appendChild( btn( 'wakoo-evbtn--ghost', T.ics, p.ics ) ); }
			var link = ev.url || p.link;
			if ( cfg.modal.link && link && safeUrl( link ) ) { acts.appendChild( btn( 'wakoo-evbtn--ghost', T.more, link ) ); }
			if ( acts.childNodes.length ) { inner.appendChild( acts ); }

			if ( cfg.modal.rsvp && p.rsvp && ( null == p.left || p.left > 0 ) ) {
				var max = Math.max( 1, Math.min( p.maxSeats || 4, null == p.left ? 99 : p.left ) );
				var f = el( 'form', 'wakoo-evrsvp' ); f.noValidate = true;
				f.innerHTML = '<h4 class="wakoo-evrsvp__title"></h4><div class="wakoo-evrsvp__fields">' +
					'<label><span></span><input name="name" required autocomplete="name"></label>' +
					'<label><span></span><input name="email" type="email" required autocomplete="email"></label>' +
					'<label><span></span><input name="seats" type="number" min="1" value="1"></label>' +
					'<input name="website" class="wakoo-evrsvp__hp" tabindex="-1" autocomplete="off" aria-hidden="true">' +
					'<input name="occ" type="hidden"></div><button type="submit" class="wakoo-evbtn"></button><p class="wakoo-evrsvp__msg" role="status" aria-live="polite"></p>';
				f.querySelector( '.wakoo-evrsvp__title' ).textContent = T.signup;
				var spans = f.querySelectorAll( 'label span' );
				spans[ 0 ].textContent = T.name; spans[ 1 ].textContent = T.email; spans[ 2 ].textContent = T.seats;
				f.querySelector( '[name=seats]' ).max = max;
				f.querySelector( '[name=occ]' ).value = p.occ;
				f.querySelector( 'button' ).textContent = T.send;
				f.addEventListener( 'submit', function ( e ) { e.preventDefault(); submitRsvp( f, p.eid, onBooked ); } );
				inner.appendChild( f );
			}
			wrap.hidden = false;
			document.documentElement.classList.add( 'wakoo-evm-open' );
			document.addEventListener( 'keydown', onKey );
			box.focus();
		};
	}

	/* ---------------------------------------------------------------- */
	/* Calendar                                                          */
	/* ---------------------------------------------------------------- */
	function init( root ) {
		if ( root.dataset.wakooInit || ! window.FullCalendar ) { return; }
		root.dataset.wakooInit = '1';
		var cfg; try { cfg = JSON.parse( root.getAttribute( 'data-wakoo' ) || '{}' ); } catch ( e ) { cfg = {}; }
		cfg.modal = cfg.modal || {};
		var host = root.querySelector( '.wakoo-evcal__cal' );
		var cache = {};
		var active = [];
		var term = '';
		var mobile = !! cfg.mobile && window.innerWidth < 768;
		var calendar;

		function pad( n ) { return n < 10 ? '0' + n : '' + n; }
		function ymd( d ) { return d.getFullYear() + '-' + pad( d.getMonth() + 1 ) + '-' + pad( d.getDate() ); }

		function fetchNative( info ) {
			if ( ! cfg.native ) { return Promise.resolve( [] ); }
			var key = ymd( info.start ) + '|' + ymd( info.end );
			if ( cache[ key ] ) { return cache[ key ]; }
			var q = '?start=' + ymd( new Date( info.start.getTime() - 864e5 ) ) + '&end=' + ymd( new Date( info.end.getTime() + 864e5 ) );
			if ( cfg.cats && cfg.cats.length ) { q += '&cats=' + encodeURIComponent( cfg.cats.join( ',' ) ); }
			cache[ key ] = fetch( G.api + q, { credentials: 'same-origin' } )
				.then( function ( r ) { if ( ! r.ok ) { throw new Error( r.status ); } return r.json(); } )
				.catch( function ( e ) { delete cache[ key ]; throw e; } );
			return cache[ key ];
		}

		function keep( ev ) {
			var p = ev.extendedProps || {};
			if ( active.length && ! ( p.cats || [] ).some( function ( c ) { return active.indexOf( c.slug ) > -1; } ) ) { return false; }
			if ( term ) {
				var hay = ( ev.title + ' ' + ( p.excerpt || '' ) + ' ' + ( p.location || '' ) + ' ' + ( p.cats || [] ).map( function ( c ) { return c.name; } ).join( ' ' ) ).toLowerCase();
				if ( hay.indexOf( term ) < 0 ) { return false; }
			}
			if ( 'hide' === cfg.past && new Date( ev.end || ev.start ) < new Date() ) { return false; }
			return true;
		}

		var views = {};
		( cfg.views || [] ).concat( [ cfg.view, cfg.mobile ] ).forEach( function ( v ) { if ( v ) { views[ v ] = { buttonText: ( cfg.labels || {} )[ v ] || v }; } } );
		var tf = { hour: '2-digit', minute: '2-digit', hour12: !! cfg.hour12 };

		calendar = new window.FullCalendar.Calendar( host, {
			initialView: mobile ? cfg.mobile : cfg.view,
			locale: cfg.locale || 'es',
			firstDay: cfg.firstDay,
			headerToolbar: { left: 'prev,next' + ( cfg.today ? ' today' : '' ), center: 'title', right: ( cfg.views || [] ).join( ',' ) },
			buttonText: { today: ( cfg.labels || {} ).today || 'Hoy' },
			views: views,
			height: cfg.height || 'auto',
			weekends: false !== cfg.weekends,
			weekNumbers: !! cfg.weekNums,
			dayMaxEvents: cfg.maxEvents > 0 ? cfg.maxEvents : false,
			slotMinTime: cfg.slotMin || '07:00:00',
			slotMaxTime: cfg.slotMax || '23:00:00',
			scrollTime: cfg.slotMin || '08:00:00',
			nowIndicator: !! cfg.nowLine,
			eventDisplay: cfg.display || 'block',
			eventTimeFormat: tf,
			slotLabelFormat: tf,
			navLinks: true,
			noEventsContent: T.none,
			eventSources: [ {
				events: function ( info, ok, fail ) {
					fetchNative( info ).then( function ( list ) {
						ok( list.concat( cfg.manual || [] ).filter( keep ) );
					} ).catch( fail );
				},
			} ],
			eventDidMount: function ( arg ) {
				var p = arg.event.extendedProps || {};
				var end = arg.event.end || arg.event.start;
				if ( 'dim' === cfg.past && end && end < new Date() ) { arg.el.classList.add( 'wakoo-ev--past' ); }
				if ( cfg.tooltip ) { arg.el.title = [ arg.event.title, p.when, p.location ].filter( Boolean ).join( '\n' ); }
				if ( 'none' !== cfg.click ) { arg.el.style.cursor = 'pointer'; }
				var tl = arg.el.querySelector( '.fc-event-title, .fc-list-event-title a' );
				if ( tl && p.status && 'scheduled' !== p.status ) {
					var t = el( 'span', 'wakoo-ev__t', tl.textContent );
					tl.textContent = '';
					tl.appendChild( el( 'span', 'wakoo-ev__badge', T[ p.status ] || p.status ) );
					tl.appendChild( t );
				}
			},
			eventClick: function ( info ) {
				var p = info.event.extendedProps || {};
				if ( 'link' === cfg.click ) {
					var u = info.event.url || p.link;
					info.jsEvent.preventDefault();
					if ( u && safeUrl( u ) ) { window.location.href = u; }
					return;
				}
				info.jsEvent.preventDefault();
				if ( 'modal' === cfg.click ) { modal.open( info.event, info.el ); }
			},
		} );

		var modal = new Modal( root, cfg, function () { cache = {}; calendar.refetchEvents(); } );
		calendar.render();

		// Keyboard access to events (FullCalendar renders them as non-focusable when they have no URL).
		host.addEventListener( 'keydown', function ( e ) {
			if ( ( 'Enter' === e.key || ' ' === e.key ) && e.target.classList && e.target.classList.contains( 'fc-event' ) && ! e.target.href ) {
				e.preventDefault(); e.target.click();
			}
		} );

		// Filters.
		var chips = root.querySelectorAll( '.wakoo-evcal__chip' );
		Array.prototype.forEach.call( chips, function ( c ) {
			c.addEventListener( 'click', function () {
				var slug = c.getAttribute( 'data-cat' );
				if ( ! slug ) { active = []; }
				else {
					var i = active.indexOf( slug );
					if ( i > -1 ) { active.splice( i, 1 ); } else { active.push( slug ); }
				}
				Array.prototype.forEach.call( chips, function ( o ) {
					var s = o.getAttribute( 'data-cat' );
					var on = s ? active.indexOf( s ) > -1 : ! active.length;
					o.classList.toggle( 'is-active', on ); o.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
				} );
				calendar.refetchEvents();
			} );
		} );
		var search = root.querySelector( '.wakoo-evcal__search input' );
		if ( search ) {
			var t;
			search.addEventListener( 'input', function () {
				clearTimeout( t );
				t = setTimeout( function () { term = search.value.trim().toLowerCase(); calendar.refetchEvents(); }, 200 );
			} );
		}

		// Mobile view switch + size changes (tabs, accordions, editor panels).
		if ( cfg.mobile ) {
			window.addEventListener( 'resize', function () {
				var m = window.innerWidth < 768;
				if ( m !== mobile ) { mobile = m; calendar.changeView( m ? cfg.mobile : cfg.view ); }
			} );
		}
		if ( window.ResizeObserver ) { new ResizeObserver( function () { calendar.updateSize(); } ).observe( root ); }
	}

	function boot( scope ) {
		scope = scope && scope.querySelectorAll ? scope : document;
		Array.prototype.forEach.call( scope.querySelectorAll( '.wakoo-evcal' ), init );
		wireStaticForms( scope );
	}
	if ( 'loading' === document.readyState ) { document.addEventListener( 'DOMContentLoaded', function () { boot( document ); } ); } else { boot( document ); }
	if ( window.jQuery ) {
		window.jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend && window.elementorFrontend.hooks ) {
				window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-events-calendar.default', function ( $s ) { boot( $s[ 0 ] ); } );
			}
		} );
	}
}() );
