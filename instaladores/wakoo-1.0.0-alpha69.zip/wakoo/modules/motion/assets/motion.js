( function () {
	'use strict';

	var M = window.Motion || null;      // Motion One (umd global)
	var VT = window.VanillaTilt || null; // vanilla-tilt

	function reduced() {
		return window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	}

	function isEditor() {
		return document.body && document.body.classList.contains( 'elementor-editor-active' );
	}

	function fromState( type ) {
		switch ( type ) {
			case 'fade-up':     return { opacity: [ 0, 1 ], transform: [ 'translateY(30px)', 'translateY(0)' ] };
			case 'fade-down':   return { opacity: [ 0, 1 ], transform: [ 'translateY(-30px)', 'translateY(0)' ] };
			case 'zoom-in':     return { opacity: [ 0, 1 ], transform: [ 'scale(0.9)', 'scale(1)' ] };
			case 'slide-left':  return { opacity: [ 0, 1 ], transform: [ 'translateX(40px)', 'translateX(0)' ] };
			case 'slide-right': return { opacity: [ 0, 1 ], transform: [ 'translateX(-40px)', 'translateX(0)' ] };
			default:            return { opacity: [ 0, 1 ] };
		}
	}

	function initialCss( type ) {
		switch ( type ) {
			case 'fade-up':     return 'translateY(30px)';
			case 'fade-down':   return 'translateY(-30px)';
			case 'zoom-in':     return 'scale(0.9)';
			case 'slide-left':  return 'translateX(40px)';
			case 'slide-right': return 'translateX(-40px)';
			default:            return 'none';
		}
	}

	function reveal( el ) {
		if ( el.dataset.wakooRevealInit ) { return; }
		el.dataset.wakooRevealInit = '1';
		var type = el.getAttribute( 'data-wakoo-reveal' ) || 'fade';
		var dur = parseFloat( el.getAttribute( 'data-wakoo-reveal-dur' ) || '0.6' );
		var delay = parseFloat( el.getAttribute( 'data-wakoo-reveal-delay' ) || '0' );

		// In the editor or with reduced motion, show immediately.
		if ( isEditor() || reduced() ) {
			el.style.opacity = '1';
			el.style.transform = 'none';
			return;
		}

		el.style.opacity = '0';
		el.style.transform = initialCss( type );
		el.style.willChange = 'opacity, transform';

		var run = function () {
			if ( M && M.animate ) {
				M.animate( el, fromState( type ), { duration: dur, delay: delay, easing: [ 0.22, 0.61, 0.36, 1 ] } );
			} else {
				el.style.transition = 'opacity ' + dur + 's ease ' + delay + 's, transform ' + dur + 's ease ' + delay + 's';
				el.style.opacity = '1';
				el.style.transform = 'none';
			}
		};

		if ( M && M.inView ) {
			M.inView( el, function () {
				run();
				return function () {}; // run once (no re-hide on leave)
			}, { margin: '0px 0px -10% 0px' } );
		} else {
			run();
		}
	}

	function tilt( el ) {
		if ( el.dataset.wakooTiltInit ) { return; }
		el.dataset.wakooTiltInit = '1';
		if ( ! VT || isEditor() || reduced() ) { return; }
		var max = parseFloat( el.getAttribute( 'data-wakoo-tilt-max' ) || '12' );
		var glare = el.hasAttribute( 'data-wakoo-tilt-glare' );
		VT.init( el, {
			max: max,
			speed: 400,
			scale: 1.02,
			glare: glare,
			'max-glare': 0.3,
		} );
	}

	function boot( scope ) {
		var root = scope || document;
		root.querySelectorAll( '.wakoo-reveal' ).forEach( reveal );
		root.querySelectorAll( '.wakoo-tilt' ).forEach( tilt );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', function () { boot(); } );
	} else {
		boot();
	}
	if ( window.jQuery ) {
		jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend && elementorFrontend.hooks ) {
				elementorFrontend.hooks.addAction( 'frontend/element_ready/global', function ( $s ) { boot( $s[ 0 ] ); } );
			}
		} );
	}
}() );
