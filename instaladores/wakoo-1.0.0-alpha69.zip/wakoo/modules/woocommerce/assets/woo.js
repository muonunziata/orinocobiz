( function ( $ ) {
	'use strict';

	// Menu cart: open on click, close on outside click or Escape.
	$( document ).on( 'click', '.wk-woo-menu-cart[data-open="click"] .wk-woo-menu-cart__toggle', function ( e ) {
		e.preventDefault();
		var $cart = $( this ).closest( '.wk-woo-menu-cart' );
		var open = ! $cart.hasClass( 'is-open' );
		$( '.wk-woo-menu-cart.is-open' ).removeClass( 'is-open' ).find( '.wk-woo-menu-cart__toggle' ).attr( 'aria-expanded', 'false' );
		$cart.toggleClass( 'is-open', open );
		$( this ).attr( 'aria-expanded', open ? 'true' : 'false' );
	} );

	$( document ).on( 'click', function ( e ) {
		if ( ! $( e.target ).closest( '.wk-woo-menu-cart' ).length ) {
			$( '.wk-woo-menu-cart.is-open' ).removeClass( 'is-open' ).find( '.wk-woo-menu-cart__toggle' ).attr( 'aria-expanded', 'false' );
		}
	} );

	$( document ).on( 'keyup', function ( e ) {
		if ( 'Escape' === e.key ) {
			$( '.wk-woo-menu-cart.is-open' ).removeClass( 'is-open' );
		}
	} );

	// Open the mini cart after a product is added with AJAX.
	$( document.body ).on( 'added_to_cart', function () {
		$( '.wk-woo-menu-cart[data-open="click"]' ).addClass( 'is-open' );
	} );

	// Single product scripts (gallery, tabs) need re-init when Elementor renders a widget in the editor.
	$( window ).on( 'elementor/frontend/init', function () {
		[ 'wk-woo-product-images.default', 'wk-woo-product-data-tabs.default' ].forEach( function ( hook ) {
			elementorFrontend.hooks.addAction( 'frontend/element_ready/' + hook, function ( $scope ) {
				if ( $.fn.wc_product_gallery ) {
					$scope.find( '.woocommerce-product-gallery' ).each( function () {
						$( this ).trigger( 'wc-product-gallery-before-init', [ this, window.wc_single_product_params || {} ] );
						$( this ).wc_product_gallery( window.wc_single_product_params || {} );
					} );
				}
				$scope.find( '.wc-tabs-wrapper, .woocommerce-tabs' ).trigger( 'init' );
			} );
		} );
	} );
}( jQuery ) );
