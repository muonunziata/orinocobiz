<?php
/**
 * Wakoo WooCommerce builder: shop, product, cart, checkout and account widgets.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Woo;

defined( 'ABSPATH' ) || die();

class Module {

	const CATEGORY = 'wakoo_woocommerce';

	const SINGLE_CATEGORY = 'wakoo_woocommerce_single';

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public static function widgets() {
		return [
			'products'            => 'Products',
			'product-categories'  => 'Product_Categories',
			'menu-cart'           => 'Menu_Cart',
			'add-to-cart'         => 'Add_To_Cart',
			'archive-products'    => 'Archive_Products',
			'archive-description' => 'Archive_Description',
			'product-title'       => 'Product_Title',
			'product-images'      => 'Product_Images',
			'product-price'       => 'Product_Price',
			'product-add-to-cart' => 'Product_Add_To_Cart',
			'product-rating'      => 'Product_Rating',
			'product-stock'       => 'Product_Stock',
			'product-meta'        => 'Product_Meta',
			'product-short-description' => 'Product_Short_Description',
			'product-content'     => 'Product_Content',
			'product-data-tabs'   => 'Product_Data_Tabs',
			'product-additional-information' => 'Product_Additional_Information',
			'product-related'     => 'Product_Related',
			'product-upsell'      => 'Product_Upsell',
			'cart'                => 'Cart',
			'checkout'            => 'Checkout',
			'my-account'          => 'My_Account',
			'notices'             => 'Notices',
		];
	}

	private function __construct() {
		add_action( 'elementor/elements/categories_registered', [ $this, 'register_categories' ] );
		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'register_assets' ] );
		add_action( 'elementor/editor/after_enqueue_styles', [ $this, 'register_assets' ] );
		add_filter( 'woocommerce_add_to_cart_fragments', [ $this, 'menu_cart_fragments' ] );
	}

	public function register_categories( $elements_manager ) {
		$elements_manager->add_category( self::CATEGORY, [
			'title' => __( 'Wakoo WooCommerce', 'wakoo' ),
			'icon'  => 'eicon-woocommerce',
		] );
		$elements_manager->add_category( self::SINGLE_CATEGORY, [
			'title' => __( 'Wakoo Product', 'wakoo' ),
			'icon'  => 'eicon-product-images',
		] );
	}

	public function register_widgets( $widgets_manager ) {
		require_once __DIR__ . '/widgets/base.php';
		foreach ( self::widgets() as $file => $class ) {
			require_once __DIR__ . '/widgets/' . $file . '.php';
			$fqcn = __NAMESPACE__ . '\\Widgets\\' . $class;
			$widgets_manager->register( new $fqcn() );
		}
	}

	public function register_assets() {
		wp_register_style( 'wakoo-woo', WAKOO_MODULES_URL . 'woocommerce/assets/woo.css', [], WAKOO_VERSION );
		wp_register_script( 'wakoo-woo', WAKOO_MODULES_URL . 'woocommerce/assets/woo.js', [ 'jquery' ], WAKOO_VERSION, true );
	}

	/**
	 * Keep the menu cart counter and subtotal in sync after AJAX add to cart.
	 */
	public function menu_cart_fragments( $fragments ) {
		if ( ! WC()->cart ) {
			return $fragments;
		}
		$fragments['span.wk-woo-menu-cart__count'] = '<span class="wk-woo-menu-cart__count">' . esc_html( WC()->cart->get_cart_contents_count() ) . '</span>';
		$fragments['span.wk-woo-menu-cart__subtotal'] = '<span class="wk-woo-menu-cart__subtotal">' . wp_kses_post( WC()->cart->get_cart_subtotal() ) . '</span>';
		ob_start();
		woocommerce_mini_cart();
		$fragments['div.wk-woo-menu-cart__mini'] = '<div class="wk-woo-menu-cart__mini widget_shopping_cart_content">' . ob_get_clean() . '</div>';
		return $fragments;
	}
}

if ( class_exists( 'WooCommerce' ) ) {
	Module::instance();
}
