<?php
namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Product_Short_Description extends Base {

	protected $is_single = true;

	public function get_name() {
		return 'wk-woo-product-short-description';
	}

	public function get_title() {
		return __( 'Short Description', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-product-description';
	}

	protected function register_controls() {
		
		$this->add_text_style( 'text', __( 'Text', 'wakoo' ), '.wk-woo-product-short-description' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->with_product( function ( $item ) use ( $s ) {
			echo '<div class="wk-woo-product-short-description woocommerce-product-details__short-description">' . wp_kses_post( apply_filters( 'woocommerce_short_description', $item->get_short_description() ) ) . '</div>';
		} );
	}
}
