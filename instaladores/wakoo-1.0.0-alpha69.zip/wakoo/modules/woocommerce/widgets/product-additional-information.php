<?php
namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Product_Additional_Information extends Base {

	protected $is_single = true;

	public function get_name() {
		return 'wk-woo-product-additional-information';
	}

	public function get_title() {
		return __( 'Additional Information', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-product-info';
	}

	protected function register_controls() {
		
		$this->add_text_style( 'label', __( 'Labels', 'wakoo' ), '.woocommerce-product-attributes-item__label', false );
		$this->add_text_style( 'value', __( 'Values', 'wakoo' ), '.woocommerce-product-attributes-item__value', false );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->with_product( function ( $item ) use ( $s ) {
			echo '<div class="wk-woo-product-additional-information">'; wc_display_product_attributes( $item ); echo '</div>';
		} );
	}
}
