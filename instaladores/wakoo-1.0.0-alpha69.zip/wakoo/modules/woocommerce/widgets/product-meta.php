<?php
namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Product_Meta extends Base {

	protected $is_single = true;

	public function get_name() {
		return 'wk-woo-product-meta';
	}

	public function get_title() {
		return __( 'Product Meta', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-product-meta';
	}

	protected function register_controls() {
		
		$this->add_text_style( 'meta', __( 'Text', 'wakoo' ), '.product_meta' );
		$this->add_text_style( 'meta_link', __( 'Links', 'wakoo' ), '.product_meta a', false );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->with_product( function ( $item ) use ( $s ) {
			echo '<div class="wk-woo-product-meta">'; woocommerce_template_single_meta(); echo '</div>';
		} );
	}
}
