<?php
namespace Wakoo\Modules\Woo\Widgets;

defined( 'ABSPATH' ) || die();

class Archive_Description extends Base {

	public function get_name() {
		return 'wk-woo-archive-description';
	}

	public function get_title() {
		return __( 'Archive Description', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-product-description';
	}

	protected function register_controls() {
		$this->add_text_style( 'text', __( 'Text', 'wakoo' ), '.wk-woo-archive-description' );
	}

	protected function render() {
		$description = '';
		if ( is_product_taxonomy() ) {
			$description = term_description();
		} elseif ( is_shop() ) {
			$shop = get_post( wc_get_page_id( 'shop' ) );
			$description = $shop ? wc_format_content( $shop->post_content ) : '';
		} elseif ( self::in_editor() ) {
			$description = '<p>' . esc_html__( 'The description of the shop page or the current product category appears here.', 'wakoo' ) . '</p>';
		}
		if ( $description ) {
			echo '<div class="wk-woo-archive-description">' . wp_kses_post( $description ) . '</div>';
		}
	}
}
