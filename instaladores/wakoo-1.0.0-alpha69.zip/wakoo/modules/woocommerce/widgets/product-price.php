<?php
namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Product_Price extends Base {

	protected $is_single = true;

	public function get_name() {
		return 'wk-woo-product-price';
	}

	public function get_title() {
		return __( 'Product Price', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-product-price';
	}

	protected function register_controls() {
		
		$this->add_text_style( 'price', __( 'Price', 'wakoo' ), '.price' );
		$this->add_text_style( 'sale_price', __( 'Regular Price (on sale)', 'wakoo' ), '.price del', false );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->with_product( function ( $item ) use ( $s ) {
			echo '<div class="wk-woo-product-price"><p class="price">' . wp_kses_post( $item->get_price_html() ) . '</p></div>';
		} );
	}
}
