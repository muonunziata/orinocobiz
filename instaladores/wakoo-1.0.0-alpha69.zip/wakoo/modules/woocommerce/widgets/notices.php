<?php
namespace Wakoo\Modules\Woo\Widgets;

defined( 'ABSPATH' ) || die();

class Notices extends Base {

	public function get_name() {
		return 'wk-woo-notices';
	}

	public function get_title() {
		return __( 'WooCommerce Notices', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-woocommerce-notices';
	}

	protected function register_controls() {
		$this->add_text_style( 'notice', __( 'Notices', 'wakoo' ), '.woocommerce-message, {{WRAPPER}} .woocommerce-info, {{WRAPPER}} .woocommerce-error', false );
	}

	protected function render() {
		echo '<div class="wk-woo-notices woocommerce">';
		if ( self::in_editor() ) {
			echo '<div class="woocommerce-message">' . esc_html__( 'Store messages (added to cart, errors...) appear here.', 'wakoo' ) . '</div>';
		} elseif ( function_exists( 'wc_print_notices' ) && WC()->session ) {
			wc_print_notices();
		}
		echo '</div>';
	}
}
