<?php
namespace Wakoo\Modules\Woo\Widgets;

defined( 'ABSPATH' ) || die();

require_once __DIR__ . '/cart.php';

class Checkout extends Page_Widget {

	public function get_name() {
		return 'wk-woo-checkout';
	}

	public function get_title() {
		return __( 'Checkout', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-checkout';
	}

	protected function shortcode() {
		return 'woocommerce_checkout';
	}

	protected function register_controls() {
		parent::register_controls();
		$this->add_text_style( 'labels', __( 'Form Labels', 'wakoo' ), '.wk-woo-page .form-row label', false );
		$this->add_text_style( 'inputs', __( 'Form Fields', 'wakoo' ), '.wk-woo-page .input-text, {{WRAPPER}} .wk-woo-page select', false );
	}
}
