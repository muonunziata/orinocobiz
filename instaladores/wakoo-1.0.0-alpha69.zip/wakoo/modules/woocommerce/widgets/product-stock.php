<?php
namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Product_Stock extends Base {

	protected $is_single = true;

	public function get_name() {
		return 'wk-woo-product-stock';
	}

	public function get_title() {
		return __( 'Product Stock', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-product-stock';
	}

	protected function register_controls() {
		
		$this->add_text_style( 'stock', __( 'Stock', 'wakoo' ), '.stock' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->with_product( function ( $item ) use ( $s ) {
			echo '<div class="wk-woo-product-stock">' . wp_kses_post( wc_get_stock_html( $item ) ) . '</div>';
		} );
	}
}
