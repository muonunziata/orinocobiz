<?php
namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Product_Add_To_Cart extends Base {

	protected $is_single = true;

	public function get_name() {
		return 'wk-woo-product-add-to-cart';
	}

	public function get_title() {
		return __( 'Add To Cart', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-product-add-to-cart';
	}

	protected function register_controls() {
		
		$this->add_button_style( 'button', __( 'Button', 'wakoo' ), '.single_add_to_cart_button' );
		$this->add_text_style( 'qty', __( 'Quantity', 'wakoo' ), '.quantity .qty', false );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->with_product( function ( $item ) use ( $s ) {
			wp_enqueue_script( 'wc-add-to-cart-variation' ); echo '<div class="wk-woo-product-add-to-cart">'; woocommerce_template_single_add_to_cart(); echo '</div>';
		} );
	}
}
