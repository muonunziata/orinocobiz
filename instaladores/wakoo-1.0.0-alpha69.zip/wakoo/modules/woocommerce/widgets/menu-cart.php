<?php
namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Icons_Manager;

defined( 'ABSPATH' ) || die();

class Menu_Cart extends Base {

	public function get_name() {
		return 'wk-woo-menu-cart';
	}

	public function get_title() {
		return __( 'Menu Cart', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-cart';
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_cart', [ 'label' => __( 'Menu Cart', 'wakoo' ) ] );
		$this->add_control( 'icon', [
			'label'   => __( 'Icon', 'wakoo' ),
			'type'    => Controls_Manager::ICONS,
			'default' => [ 'value' => 'fas fa-shopping-cart', 'library' => 'fa-solid' ],
		] );
		$this->add_control( 'show_subtotal', [
			'label'   => __( 'Show Subtotal', 'wakoo' ),
			'type'    => Controls_Manager::SWITCHER,
			'default' => 'yes',
		] );
		$this->add_control( 'show_count', [
			'label'   => __( 'Show Items Count', 'wakoo' ),
			'type'    => Controls_Manager::SWITCHER,
			'default' => 'yes',
		] );
		$this->add_control( 'open_on', [
			'label'   => __( 'Open Mini Cart On', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'click',
			'options' => [
				'click' => __( 'Click', 'wakoo' ),
				'hover' => __( 'Hover', 'wakoo' ),
				'none'  => __( 'Go to Cart Page', 'wakoo' ),
			],
		] );
		$this->add_responsive_control( 'align', [
			'label'     => __( 'Alignment', 'wakoo' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => [
				'flex-start' => [ 'title' => __( 'Left', 'wakoo' ), 'icon' => 'eicon-text-align-left' ],
				'center'     => [ 'title' => __( 'Center', 'wakoo' ), 'icon' => 'eicon-text-align-center' ],
				'flex-end'   => [ 'title' => __( 'Right', 'wakoo' ), 'icon' => 'eicon-text-align-right' ],
			],
			'selectors' => [ '{{WRAPPER}} .wk-woo-menu-cart' => 'justify-content: {{VALUE}};' ],
		] );
		$this->end_controls_section();

		$this->add_button_style( 'toggle', __( 'Cart Button', 'wakoo' ), '.wk-woo-menu-cart__toggle' );

		$this->start_controls_section( 'section_style_icon', [
			'label' => __( 'Icon & Counter', 'wakoo' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		] );
		$this->add_responsive_control( 'icon_size', [
			'label'      => __( 'Icon Size', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'selectors'  => [ '{{WRAPPER}} .wk-woo-menu-cart__icon' => 'font-size: {{SIZE}}{{UNIT}};', '{{WRAPPER}} .wk-woo-menu-cart__icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'count_color', [
			'label'     => __( 'Counter Text Color', 'wakoo' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .wk-woo-menu-cart__count' => 'color: {{VALUE}};' ],
		] );
		$this->add_control( 'count_bg', [
			'label'     => __( 'Counter Background', 'wakoo' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .wk-woo-menu-cart__count' => 'background-color: {{VALUE}};' ],
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'section_style_mini', [
			'label' => __( 'Mini Cart', 'wakoo' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		] );
		$this->add_responsive_control( 'mini_width', [
			'label'      => __( 'Width', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'range'      => [ 'px' => [ 'min' => 200, 'max' => 600 ] ],
			'selectors'  => [ '{{WRAPPER}} .wk-woo-menu-cart__dropdown' => 'width: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'mini_bg', [
			'label'     => __( 'Background Color', 'wakoo' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .wk-woo-menu-cart__dropdown' => 'background-color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Box_Shadow::get_type(), [
			'name'     => 'mini_shadow',
			'selector' => '{{WRAPPER}} .wk-woo-menu-cart__dropdown',
		] );
		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$cart = WC()->cart;
		$count = $cart ? $cart->get_cart_contents_count() : 0;
		$subtotal = $cart ? $cart->get_cart_subtotal() : wc_price( 0 );
		?>
		<div class="wk-woo-menu-cart" data-open="<?php echo esc_attr( $s['open_on'] ); ?>">
			<a class="wk-woo-menu-cart__toggle" href="<?php echo esc_url( wc_get_cart_url() ); ?>" aria-label="<?php esc_attr_e( 'Cart', 'wakoo' ); ?>" aria-expanded="false">
				<?php if ( 'yes' === $s['show_subtotal'] ) : ?>
					<span class="wk-woo-menu-cart__subtotal"><?php echo wp_kses_post( $subtotal ); ?></span>
				<?php endif; ?>
				<span class="wk-woo-menu-cart__icon">
					<?php Icons_Manager::render_icon( $s['icon'], [ 'aria-hidden' => 'true' ] ); ?>
					<?php if ( 'yes' === $s['show_count'] ) : ?>
						<span class="wk-woo-menu-cart__count"><?php echo esc_html( $count ); ?></span>
					<?php endif; ?>
				</span>
			</a>
			<?php if ( 'none' !== $s['open_on'] ) : ?>
				<div class="wk-woo-menu-cart__dropdown">
					<div class="wk-woo-menu-cart__mini widget_shopping_cart_content">
						<?php
						if ( $cart ) {
							woocommerce_mini_cart();
						}
						?>
					</div>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}
