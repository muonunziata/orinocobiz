<?php
namespace Wakoo\Modules\Woo\Widgets;

defined( 'ABSPATH' ) || die();

require_once __DIR__ . '/cart.php';

class My_Account extends Page_Widget {

	public function get_name() {
		return 'wk-woo-my-account';
	}

	public function get_title() {
		return __( 'My Account', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-my-account';
	}

	protected function shortcode() {
		return 'woocommerce_my_account';
	}

	protected function register_controls() {
		parent::register_controls();
		$this->add_text_style( 'nav', __( 'Account Menu', 'wakoo' ), '.woocommerce-MyAccount-navigation a', false );
	}
}
