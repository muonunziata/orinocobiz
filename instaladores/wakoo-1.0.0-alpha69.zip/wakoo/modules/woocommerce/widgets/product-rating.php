<?php
namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Product_Rating extends Base {

	protected $is_single = true;

	public function get_name() {
		return 'wk-woo-product-rating';
	}

	public function get_title() {
		return __( 'Product Rating', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-product-rating';
	}

	protected function register_controls() {
		
		$this->start_controls_section( 'section_style_stars', [ 'label' => __( 'Stars', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'star_color', [
			'label'     => __( 'Star Color', 'wakoo' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .star-rating span::before, {{WRAPPER}} .star-rating::before' => 'color: {{VALUE}};' ],
		] );
		$this->end_controls_section();
		$this->add_text_style( 'link', __( 'Reviews Link', 'wakoo' ), '.woocommerce-review-link', false );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->with_product( function ( $item ) use ( $s ) {
			echo '<div class="wk-woo-product-rating woocommerce">'; woocommerce_template_single_rating(); echo '</div>';
		} );
	}
}
