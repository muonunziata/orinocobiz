<?php
namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Products extends Base {

	public function get_name() {
		return 'wk-woo-products';
	}

	public function get_title() {
		return __( 'Products', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-products';
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_query', [ 'label' => __( 'Query', 'wakoo' ) ] );
		$this->add_control( 'source', [
			'label'   => __( 'Source', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'recent',
			'options' => [
				'recent'       => __( 'Latest Products', 'wakoo' ),
				'featured'     => __( 'Featured Products', 'wakoo' ),
				'sale'         => __( 'On Sale', 'wakoo' ),
				'best_selling' => __( 'Best Selling', 'wakoo' ),
				'top_rated'    => __( 'Top Rated', 'wakoo' ),
				'manual'       => __( 'Manual Selection', 'wakoo' ),
			],
		] );
		$this->add_control( 'ids', [
			'label'       => __( 'Product IDs', 'wakoo' ),
			'type'        => Controls_Manager::TEXT,
			'placeholder' => '12, 34, 56',
			'condition'   => [ 'source' => 'manual' ],
		] );
		$this->add_control( 'categories', [
			'label'       => __( 'Categories', 'wakoo' ),
			'type'        => Controls_Manager::SELECT2,
			'multiple'    => true,
			'label_block' => true,
			'options'     => $this->category_options(),
			'condition'   => [ 'source!' => 'manual' ],
		] );
		$this->add_control( 'limit', [
			'label'   => __( 'Products Count', 'wakoo' ),
			'type'    => Controls_Manager::NUMBER,
			'default' => 8,
			'min'     => 1,
			'max'     => 100,
		] );
		$this->add_control( 'orderby', [
			'label'     => __( 'Order By', 'wakoo' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'date',
			'options'   => [
				'date'       => __( 'Date', 'wakoo' ),
				'title'      => __( 'Title', 'wakoo' ),
				'price'      => __( 'Price', 'wakoo' ),
				'popularity' => __( 'Popularity', 'wakoo' ),
				'rating'     => __( 'Rating', 'wakoo' ),
				'menu_order' => __( 'Menu Order', 'wakoo' ),
				'rand'       => __( 'Random', 'wakoo' ),
			],
			'condition' => [ 'source!' => [ 'best_selling', 'top_rated' ] ],
		] );
		$this->add_control( 'order', [
			'label'     => __( 'Order', 'wakoo' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'DESC',
			'options'   => [ 'DESC' => __( 'Descending', 'wakoo' ), 'ASC' => __( 'Ascending', 'wakoo' ) ],
			'condition' => [ 'source!' => [ 'best_selling', 'top_rated' ] ],
		] );
		$this->add_control( 'hide_out_of_stock', [
			'label' => __( 'Hide Out of Stock', 'wakoo' ),
			'type'  => Controls_Manager::SWITCHER,
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'section_layout', [ 'label' => __( 'Layout', 'wakoo' ) ] );
		$this->add_grid_controls();
		$this->end_controls_section();

		$this->add_grid_style();
	}

	protected function category_options() {
		$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => false ] );
		$options = [];
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$options[ $term->slug ] = $term->name;
			}
		}
		return $options;
	}

	protected function query_ids( array $s ) {
		$args = [
			'status' => 'publish',
			'limit'  => max( 1, (int) $s['limit'] ),
			'return' => 'ids',
		];
		if ( 'manual' === $s['source'] ) {
			$ids = array_filter( array_map( 'absint', explode( ',', (string) $s['ids'] ) ) );
			if ( ! $ids ) {
				return [];
			}
			$args['include'] = $ids;
			$args['orderby'] = 'include';
		} else {
			if ( ! empty( $s['categories'] ) ) {
				$args['category'] = (array) $s['categories'];
			}
			$args['orderby'] = $s['orderby'];
			$args['order']   = $s['order'];
			switch ( $s['source'] ) {
				case 'featured':
					$args['featured'] = true;
					break;
				case 'sale':
					$args['include'] = array_merge( [ 0 ], wc_get_product_ids_on_sale() );
					break;
				case 'best_selling':
					$args['orderby']  = 'meta_value_num';
					$args['meta_key'] = 'total_sales'; // phpcs:ignore WordPress.DB.SlowDBQuery
					$args['order']    = 'DESC';
					break;
				case 'top_rated':
					$args['orderby']  = 'meta_value_num';
					$args['meta_key'] = '_wc_average_rating'; // phpcs:ignore WordPress.DB.SlowDBQuery
					$args['order']    = 'DESC';
					break;
			}
			if ( 'price' === $args['orderby'] ) {
				$args['orderby']  = 'meta_value_num';
				$args['meta_key'] = '_price'; // phpcs:ignore WordPress.DB.SlowDBQuery
			}
		}
		if ( 'yes' === $s['hide_out_of_stock'] ) {
			$args['stock_status'] = 'instock';
		}
		return wc_get_products( $args );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->render_loop( $this->query_ids( $s ), ( $s['columns'] ?? 0 ) ?: 4 );
	}
}
