<?php
namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

/**
 * A button that adds one chosen product to the cart.
 */
class Add_To_Cart extends Base {

	public function get_name() {
		return 'wk-woo-add-to-cart';
	}

	public function get_title() {
		return __( 'Custom Add To Cart', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-woocommerce';
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_product', [ 'label' => __( 'Product', 'wakoo' ) ] );
		$this->add_control( 'product_id', [
			'label'       => __( 'Product ID', 'wakoo' ),
			'type'        => Controls_Manager::NUMBER,
			'description' => __( 'Leave empty to use the current product.', 'wakoo' ),
		] );
		$this->add_control( 'quantity', [
			'label'   => __( 'Quantity', 'wakoo' ),
			'type'    => Controls_Manager::NUMBER,
			'default' => 1,
			'min'     => 1,
		] );
		$this->add_control( 'text', [
			'label'       => __( 'Button Text', 'wakoo' ),
			'type'        => Controls_Manager::TEXT,
			'default'     => __( 'Add to cart', 'wakoo' ),
			'dynamic'     => [ 'active' => true ],
		] );
		$this->add_responsive_control( 'align', [
			'label'     => __( 'Alignment', 'wakoo' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => [
				'left'   => [ 'title' => __( 'Left', 'wakoo' ), 'icon' => 'eicon-text-align-left' ],
				'center' => [ 'title' => __( 'Center', 'wakoo' ), 'icon' => 'eicon-text-align-center' ],
				'right'  => [ 'title' => __( 'Right', 'wakoo' ), 'icon' => 'eicon-text-align-right' ],
			],
			'selectors' => [ '{{WRAPPER}}' => 'text-align: {{VALUE}};' ],
		] );
		$this->end_controls_section();

		$this->add_button_style( 'button', __( 'Button', 'wakoo' ), '.wk-woo-add-to-cart .button' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$item = $s['product_id'] ? wc_get_product( (int) $s['product_id'] ) : $this->get_product();
		if ( ! $item ) {
			if ( self::in_editor() ) {
				echo '<div class="wk-woo-placeholder">' . esc_html__( 'Choose a product.', 'wakoo' ) . '</div>';
			}
			return;
		}
		$ajax = $item->is_type( 'simple' ) && $item->is_purchasable() && $item->is_in_stock();
		$classes = [ 'button', 'product_type_' . $item->get_type() ];
		if ( $ajax ) {
			$classes[] = 'add_to_cart_button';
			$classes[] = 'ajax_add_to_cart';
		}
		$url = $ajax ? $item->add_to_cart_url() : $item->get_permalink();
		if ( $ajax && (int) $s['quantity'] > 1 ) {
			$url = add_query_arg( 'quantity', (int) $s['quantity'], $url );
		}
		printf(
			'<div class="wk-woo-add-to-cart"><a href="%1$s" data-quantity="%2$d" data-product_id="%3$d" data-product_sku="%4$s" class="%5$s" rel="nofollow">%6$s</a></div>',
			esc_url( $url ),
			max( 1, (int) $s['quantity'] ),
			(int) $item->get_id(),
			esc_attr( $item->get_sku() ),
			esc_attr( implode( ' ', $classes ) ),
			esc_html( $ajax ? $s['text'] : $item->add_to_cart_text() )
		);
	}
}
