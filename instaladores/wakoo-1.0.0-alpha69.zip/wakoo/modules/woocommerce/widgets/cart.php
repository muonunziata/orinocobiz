<?php
namespace Wakoo\Modules\Woo\Widgets;

defined( 'ABSPATH' ) || die();

/**
 * Base for page widgets that print a WooCommerce page (cart, checkout, account).
 */
abstract class Page_Widget extends Base {

	abstract protected function shortcode();

	protected function register_controls() {
		$this->add_text_style( 'text', __( 'Text', 'wakoo' ), '.wk-woo-page', false );
		$this->add_text_style( 'headings', __( 'Headings', 'wakoo' ), '.wk-woo-page h2, {{WRAPPER}} .wk-woo-page h3', false );
		$this->add_text_style( 'links', __( 'Links', 'wakoo' ), '.wk-woo-page a:not(.button)', false );
		$this->add_button_style( 'button', __( 'Buttons', 'wakoo' ), '.wk-woo-page .button' );
	}

	protected function render() {
		echo '<div class="wk-woo-page woocommerce">';
		echo do_shortcode( '[' . $this->shortcode() . ']' );
		echo '</div>';
	}
}

class Cart extends Page_Widget {

	public function get_name() {
		return 'wk-woo-cart';
	}

	public function get_title() {
		return __( 'Cart', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-woo-cart';
	}

	protected function shortcode() {
		return 'woocommerce_cart';
	}
}
