<?php
namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Product_Related extends Base {

	protected $is_single = true;

	public function get_name() {
		return 'wk-woo-product-related';
	}

	public function get_title() {
		return __( 'Related Products', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-product-related';
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_content', [ 'label' => __( 'Layout', 'wakoo' ) ] );
		$this->add_control( 'limit', [ 'label' => __( 'Products Count', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 4 ] );
		$this->add_grid_controls();
		$this->end_controls_section();
		$this->add_grid_style();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->with_product( function ( $item ) use ( $s ) {
			$cols = (int) ( ( $s['columns'] ?? 0 ) ?: 4 ); echo '<div class="wk-woo-grid woocommerce">'; woocommerce_related_products( [ 'posts_per_page' => (int) $s['limit'], 'columns' => $cols ] ); echo '</div>';
		} );
	}
}
