<?php
namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Product_Content extends Base {

	protected $is_single = true;

	public function get_name() {
		return 'wk-woo-product-content';
	}

	public function get_title() {
		return __( 'Product Content', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-post-content';
	}

	protected function register_controls() {
		
		$this->add_text_style( 'text', __( 'Text', 'wakoo' ), '.wk-woo-product-content' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->with_product( function ( $item ) use ( $s ) {
			echo '<div class="wk-woo-product-content">' . wp_kses_post( wc_format_content( $item->get_description() ) ) . '</div>';
		} );
	}
}
