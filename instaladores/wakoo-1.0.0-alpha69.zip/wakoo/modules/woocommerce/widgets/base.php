<?php
/**
 * Shared helpers for the Wakoo WooCommerce widgets.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;
use Wakoo\Modules\Woo\Module;

defined( 'ABSPATH' ) || die();

abstract class Base extends Widget_Base {

	/** Widgets that show one product (title, price...) go in the product category. */
	protected $is_single = false;

	public function get_categories() {
		return [ $this->is_single ? Module::SINGLE_CATEGORY : Module::CATEGORY ];
	}

	public function get_keywords() {
		return [ 'woocommerce', 'shop', 'store', 'product', 'wakoo' ];
	}

	public function get_style_depends(): array {
		return [ 'wakoo-woo' ];
	}

	public function get_script_depends(): array {
		return [ 'wakoo-woo' ];
	}

	protected function is_dynamic_content(): bool {
		return true;
	}

	protected static function in_editor() {
		return \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode();
	}

	/**
	 * The product being shown: the current one, or the latest product while designing a template.
	 *
	 * @return \WC_Product|false
	 */
	protected function get_product() {
		global $product;
		if ( $product instanceof \WC_Product ) {
			return $product;
		}
		$current = wc_get_product( get_the_ID() );
		if ( $current ) {
			return $current;
		}
		if ( self::in_editor() ) {
			$latest = wc_get_products( [ 'limit' => 1, 'status' => 'publish', 'orderby' => 'date', 'order' => 'DESC' ] );
			return $latest ? $latest[0] : false;
		}
		return false;
	}

	/**
	 * Runs $callback with the global $product/$post set to the product being shown.
	 */
	protected function with_product( callable $callback ) {
		$item = $this->get_product();
		if ( ! $item ) {
			if ( self::in_editor() ) {
				echo '<div class="wk-woo-placeholder">' . esc_html__( 'Add a product to see this widget.', 'wakoo' ) . '</div>';
			}
			return;
		}
		global $product, $post;
		$old_product = $product;
		$old_post    = $post;
		$product     = $item;
		$post        = get_post( $item->get_id() ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		setup_postdata( $post );
		$callback( $item );
		$product = $old_product;
		$post    = $old_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		if ( $old_post ) {
			setup_postdata( $old_post );
		}
	}

	protected function add_text_style( $id, $label, $selector, $with_align = true ) {
		$this->start_controls_section( 'section_style_' . $id, [
			'label' => $label,
			'tab'   => Controls_Manager::TAB_STYLE,
		] );
		if ( $with_align ) {
			$this->add_responsive_control( $id . '_align', [
				'label'     => __( 'Alignment', 'wakoo' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [ 'title' => __( 'Left', 'wakoo' ), 'icon' => 'eicon-text-align-left' ],
					'center' => [ 'title' => __( 'Center', 'wakoo' ), 'icon' => 'eicon-text-align-center' ],
					'right'  => [ 'title' => __( 'Right', 'wakoo' ), 'icon' => 'eicon-text-align-right' ],
				],
				'selectors' => [ '{{WRAPPER}}' => 'text-align: {{VALUE}};' ],
			] );
		}
		$this->add_control( $id . '_color', [
			'label'     => __( 'Color', 'wakoo' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} ' . $selector => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name'     => $id . '_typography',
			'selector' => '{{WRAPPER}} ' . $selector,
		] );
		$this->end_controls_section();
	}

	protected function add_button_style( $id, $label, $selector ) {
		$this->start_controls_section( 'section_style_' . $id, [
			'label' => $label,
			'tab'   => Controls_Manager::TAB_STYLE,
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name'     => $id . '_typography',
			'selector' => '{{WRAPPER}} ' . $selector,
		] );
		$this->start_controls_tabs( $id . '_tabs' );
		foreach ( [ 'normal' => __( 'Normal', 'wakoo' ), 'hover' => __( 'Hover', 'wakoo' ) ] as $state => $state_label ) {
			$sel = 'hover' === $state ? $selector . ':hover' : $selector;
			$this->start_controls_tab( $id . '_tab_' . $state, [ 'label' => $state_label ] );
			$this->add_control( $id . '_' . $state . '_color', [
				'label'     => __( 'Text Color', 'wakoo' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [ '{{WRAPPER}} ' . $sel => 'color: {{VALUE}};' ],
			] );
			$this->add_control( $id . '_' . $state . '_bg', [
				'label'     => __( 'Background Color', 'wakoo' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [ '{{WRAPPER}} ' . $sel => 'background-color: {{VALUE}};' ],
			] );
			$this->end_controls_tab();
		}
		$this->end_controls_tabs();
		$this->add_group_control( Group_Control_Border::get_type(), [
			'name'      => $id . '_border',
			'selector'  => '{{WRAPPER}} ' . $selector,
			'separator' => 'before',
		] );
		$this->add_control( $id . '_radius', [
			'label'      => __( 'Border Radius', 'wakoo' ),
			'type'       => Controls_Manager::DIMENSIONS,
			'size_units' => [ 'px', '%', 'em' ],
			'selectors'  => [ '{{WRAPPER}} ' . $selector => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
		] );
		$this->add_responsive_control( $id . '_padding', [
			'label'      => __( 'Padding', 'wakoo' ),
			'type'       => Controls_Manager::DIMENSIONS,
			'size_units' => [ 'px', 'em' ],
			'selectors'  => [ '{{WRAPPER}} ' . $selector => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
		] );
		$this->end_controls_section();
	}

	/** Columns, gap and card styles shared by the product grids. */
	protected function add_grid_controls( $default_columns = 4 ) {
		$this->add_responsive_control( 'columns', [
			'label'          => __( 'Columns', 'wakoo' ),
			'type'           => Controls_Manager::NUMBER,
			'min'            => 1,
			'max'            => 8,
			'default'        => $default_columns,
			'tablet_default' => 3,
			'mobile_default' => 2,
			'selectors'      => [ '{{WRAPPER}} ul.products' => 'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));' ],
		] );
	}

	protected function add_grid_style() {
		$this->start_controls_section( 'section_style_grid', [
			'label' => __( 'Products', 'wakoo' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		] );
		$this->add_responsive_control( 'column_gap', [
			'label'      => __( 'Columns Gap', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'default'    => [ 'size' => 20, 'unit' => 'px' ],
			'selectors'  => [ '{{WRAPPER}} ul.products' => 'column-gap: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_responsive_control( 'row_gap', [
			'label'      => __( 'Rows Gap', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'default'    => [ 'size' => 30, 'unit' => 'px' ],
			'selectors'  => [ '{{WRAPPER}} ul.products' => 'row-gap: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_responsive_control( 'card_align', [
			'label'     => __( 'Alignment', 'wakoo' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => [
				'left'   => [ 'title' => __( 'Left', 'wakoo' ), 'icon' => 'eicon-text-align-left' ],
				'center' => [ 'title' => __( 'Center', 'wakoo' ), 'icon' => 'eicon-text-align-center' ],
				'right'  => [ 'title' => __( 'Right', 'wakoo' ), 'icon' => 'eicon-text-align-right' ],
			],
			'selectors' => [ '{{WRAPPER}} ul.products li.product' => 'text-align: {{VALUE}};' ],
		] );
		$this->add_control( 'card_bg', [
			'label'     => __( 'Background Color', 'wakoo' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} ul.products li.product' => 'background-color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Border::get_type(), [
			'name'     => 'card_border',
			'selector' => '{{WRAPPER}} ul.products li.product',
		] );
		$this->add_responsive_control( 'card_padding', [
			'label'      => __( 'Padding', 'wakoo' ),
			'type'       => Controls_Manager::DIMENSIONS,
			'size_units' => [ 'px', 'em' ],
			'selectors'  => [ '{{WRAPPER}} ul.products li.product' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
		] );
		$this->end_controls_section();

		$this->add_text_style( 'grid_title', __( 'Title', 'wakoo' ), 'ul.products li.product .woocommerce-loop-product__title', false );
		$this->add_text_style( 'grid_price', __( 'Price', 'wakoo' ), 'ul.products li.product .price', false );
		$this->add_button_style( 'grid_button', __( 'Button', 'wakoo' ), 'ul.products li.product .button' );
	}

	/**
	 * Prints a product loop with the theme's WooCommerce templates.
	 *
	 * @param int[] $ids Product IDs.
	 */
	protected function render_loop( array $ids, $columns ) {
		if ( empty( $ids ) ) {
			echo '<div class="wk-woo-placeholder">' . esc_html__( 'No products found.', 'wakoo' ) . '</div>';
			return;
		}
		wc_set_loop_prop( 'columns', (int) $columns );
		wc_set_loop_prop( 'name', 'wakoo' );
		echo '<div class="woocommerce wk-woo-grid">';
		woocommerce_product_loop_start();
		foreach ( $ids as $id ) {
			$post_object = get_post( $id );
			setup_postdata( $GLOBALS['post'] =& $post_object ); // phpcs:ignore
			wc_get_template_part( 'content', 'product' );
		}
		woocommerce_product_loop_end();
		echo '</div>';
		wp_reset_postdata();
		wc_reset_loop();
	}
}
