<?php
namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Product_Title extends Base {

	protected $is_single = true;

	public function get_name() {
		return 'wk-woo-product-title';
	}

	public function get_title() {
		return __( 'Product Title', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-product-title';
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_content', [ 'label' => __( 'Title', 'wakoo' ) ] );
		$this->add_control( 'tag', [
			'label'   => __( 'HTML Tag', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'h1',
			'options' => [ 'h1' => 'H1', 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'div' => 'div', 'p' => 'p' ],
		] );
		$this->end_controls_section();
		$this->add_text_style( 'title', __( 'Title', 'wakoo' ), '.wk-woo-product-title' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->with_product( function ( $item ) use ( $s ) {
			printf( '<%1$s class="product_title entry-title wk-woo-product-title">%2$s</%1$s>', tag_escape( $s['tag'] ), esc_html( $item->get_name() ) );
		} );
	}
}
