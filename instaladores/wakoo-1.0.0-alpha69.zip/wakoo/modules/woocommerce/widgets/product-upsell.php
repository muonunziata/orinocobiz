<?php
namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Product_Upsell extends Base {

	protected $is_single = true;

	public function get_name() {
		return 'wk-woo-product-upsell';
	}

	public function get_title() {
		return __( 'Upsells', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-product-upsell';
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_content', [ 'label' => __( 'Layout', 'wakoo' ) ] );
		$this->add_control( 'limit', [ 'label' => __( 'Products Count', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 4 ] );
		$this->add_grid_controls();
		$this->end_controls_section();
		$this->add_grid_style();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->with_product( function ( $item ) use ( $s ) {
			$cols = (int) ( ( $s['columns'] ?? 0 ) ?: 4 ); echo '<div class="wk-woo-grid woocommerce">'; woocommerce_upsell_display( (int) $s['limit'], $cols ); echo '</div>';
		} );
	}
}
