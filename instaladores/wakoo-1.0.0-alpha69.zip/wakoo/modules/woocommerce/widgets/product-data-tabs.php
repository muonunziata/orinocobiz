<?php
namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Product_Data_Tabs extends Base {

	protected $is_single = true;

	public function get_name() {
		return 'wk-woo-product-data-tabs';
	}

	public function get_title() {
		return __( 'Product Data Tabs', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-product-tabs';
	}

	protected function register_controls() {
		
		$this->add_text_style( 'tab', __( 'Tabs', 'wakoo' ), '.woocommerce-tabs ul.tabs li a', false );
		$this->start_controls_section( 'section_style_active', [ 'label' => __( 'Active Tab', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'active_color', [
			'label'     => __( 'Color', 'wakoo' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .woocommerce-tabs ul.tabs li.active a' => 'color: {{VALUE}};' ],
		] );
		$this->add_control( 'active_bg', [
			'label'     => __( 'Background Color', 'wakoo' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .woocommerce-tabs ul.tabs li.active' => 'background-color: {{VALUE}};' ],
		] );
		$this->end_controls_section();
		$this->add_text_style( 'panel', __( 'Panel', 'wakoo' ), '.woocommerce-tabs .panel', false );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->with_product( function ( $item ) use ( $s ) {
			wp_enqueue_script( 'wc-single-product' ); echo '<div class="wk-woo-product-data-tabs">'; woocommerce_output_product_data_tabs(); echo '</div>';
		} );
	}
}
