<?php
namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

/**
 * The products of the current shop, category or search page, for archive templates.
 */
class Archive_Products extends Base {

	public function get_name() {
		return 'wk-woo-archive-products';
	}

	public function get_title() {
		return __( 'Archive Products', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-products-archive';
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_layout', [ 'label' => __( 'Layout', 'wakoo' ) ] );
		$this->add_grid_controls();
		$this->add_control( 'show_result_count', [
			'label'   => __( 'Show Result Count', 'wakoo' ),
			'type'    => Controls_Manager::SWITCHER,
			'default' => 'yes',
		] );
		$this->add_control( 'show_ordering', [
			'label'   => __( 'Show Sorting', 'wakoo' ),
			'type'    => Controls_Manager::SWITCHER,
			'default' => 'yes',
		] );
		$this->add_control( 'show_pagination', [
			'label'   => __( 'Show Pagination', 'wakoo' ),
			'type'    => Controls_Manager::SWITCHER,
			'default' => 'yes',
		] );
		$this->end_controls_section();

		$this->add_grid_style();
		$this->add_text_style( 'pagination', __( 'Pagination', 'wakoo' ), '.woocommerce-pagination a, .woocommerce-pagination span', false );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$columns = (int) ( ( $s['columns'] ?? 0 ) ?: 4 );

		if ( ! is_shop() && ! is_product_taxonomy() && ! is_search() ) {
			// Designing the template: show the latest products as a preview.
			if ( self::in_editor() ) {
				$this->render_loop( wc_get_products( [ 'status' => 'publish', 'limit' => $columns * 2, 'return' => 'ids' ] ), $columns );
			}
			return;
		}

		echo '<div class="woocommerce wk-woo-grid">';
		if ( woocommerce_product_loop() ) {
			wc_set_loop_prop( 'columns', $columns );
			echo '<div class="wk-woo-archive__bar">';
			if ( 'yes' === $s['show_result_count'] ) {
				woocommerce_result_count();
			}
			if ( 'yes' === $s['show_ordering'] ) {
				woocommerce_catalog_ordering();
			}
			echo '</div>';
			woocommerce_product_loop_start();
			while ( have_posts() ) {
				the_post();
				wc_get_template_part( 'content', 'product' );
			}
			woocommerce_product_loop_end();
			if ( 'yes' === $s['show_pagination'] ) {
				woocommerce_pagination();
			}
		} else {
			do_action( 'woocommerce_no_products_found' );
		}
		echo '</div>';
	}
}
