<?php
namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Product_Images extends Base {

	protected $is_single = true;

	public function get_name() {
		return 'wk-woo-product-images';
	}

	public function get_title() {
		return __( 'Product Images', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-product-images';
	}

	protected function register_controls() {
		
		$this->start_controls_section( 'section_style_images', [ 'label' => __( 'Images', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'image_radius', [
			'label'      => __( 'Border Radius', 'wakoo' ),
			'type'       => Controls_Manager::DIMENSIONS,
			'size_units' => [ 'px', '%' ],
			'selectors'  => [ '{{WRAPPER}} .woocommerce-product-gallery img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
		] );
		$this->add_responsive_control( 'thumbs_gap', [
			'label'      => __( 'Thumbnails Gap', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'selectors'  => [ '{{WRAPPER}} .flex-control-thumbs' => 'gap: {{SIZE}}{{UNIT}};' ],
		] );
		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$this->with_product( function ( $item ) use ( $s ) {
			wp_enqueue_script( 'wc-single-product' ); wp_enqueue_script( 'flexslider' ); wp_enqueue_script( 'photoswipe-ui-default' ); wp_enqueue_script( 'zoom' );
			echo '<div class="wk-woo-product-images">'; wc_get_template( 'single-product/product-image.php' ); echo '</div>';
		} );
	}
}
