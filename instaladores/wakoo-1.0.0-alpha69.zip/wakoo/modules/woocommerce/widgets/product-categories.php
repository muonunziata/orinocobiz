<?php
namespace Wakoo\Modules\Woo\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Product_Categories extends Base {

	public function get_name() {
		return 'wk-woo-product-categories';
	}

	public function get_title() {
		return __( 'Product Categories', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-product-categories';
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_query', [ 'label' => __( 'Categories', 'wakoo' ) ] );
		$this->add_control( 'number', [
			'label'   => __( 'Categories Count', 'wakoo' ),
			'type'    => Controls_Manager::NUMBER,
			'default' => 4,
		] );
		$this->add_control( 'parent_only', [
			'label'   => __( 'Only Top Level', 'wakoo' ),
			'type'    => Controls_Manager::SWITCHER,
			'default' => 'yes',
		] );
		$this->add_control( 'hide_empty', [
			'label'   => __( 'Hide Empty', 'wakoo' ),
			'type'    => Controls_Manager::SWITCHER,
			'default' => 'yes',
		] );
		$this->add_control( 'orderby', [
			'label'   => __( 'Order By', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'name',
			'options' => [
				'name'       => __( 'Name', 'wakoo' ),
				'count'      => __( 'Count', 'wakoo' ),
				'menu_order' => __( 'Menu Order', 'wakoo' ),
			],
		] );
		$this->add_grid_controls();
		$this->end_controls_section();

		$this->add_grid_style();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$terms = get_terms( [
			'taxonomy'   => 'product_cat',
			'number'     => (int) $s['number'],
			'hide_empty' => 'yes' === $s['hide_empty'],
			'parent'     => 'yes' === $s['parent_only'] ? 0 : '',
			'orderby'    => $s['orderby'],
		] );
		if ( is_wp_error( $terms ) || ! $terms ) {
			echo '<div class="wk-woo-placeholder">' . esc_html__( 'No categories found.', 'wakoo' ) . '</div>';
			return;
		}
		wc_set_loop_prop( 'columns', (int) ( ( $s['columns'] ?? 0 ) ?: 4 ) );
		echo '<div class="woocommerce wk-woo-grid">';
		woocommerce_product_loop_start();
		foreach ( $terms as $category ) {
			wc_get_template( 'content-product_cat.php', [ 'category' => $category ] );
		}
		woocommerce_product_loop_end();
		echo '</div>';
		wc_reset_loop();
	}
}
