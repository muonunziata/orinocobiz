/**
 * Wakoo Forms — native advanced forms.
 * Multi-step, conditional logic, live calculation, signature pad, voice note
 * (MediaRecorder), geolocation, and multipart AJAX submit. No third-party libs.
 */
( function () {
	'use strict';

	var CFG = window.WakooForms || {};
	var I18N = CFG.i18n || {};

	/* ---------- tiny safe arithmetic evaluator (+ - * / parens) ---------- */
	function evalExpr( expr ) {
		var tokens = expr.match( /(\d+(\.\d+)?|[+\-*/()])/g );
		if ( ! tokens ) { return ''; }
		var pos = 0;
		function peek() { return tokens[ pos ]; }
		function next() { return tokens[ pos++ ]; }
		function parseExpr() {
			var v = parseTerm();
			while ( '+' === peek() || '-' === peek() ) {
				var op = next();
				var r = parseTerm();
				v = ( '+' === op ) ? v + r : v - r;
			}
			return v;
		}
		function parseTerm() {
			var v = parseFactor();
			while ( '*' === peek() || '/' === peek() ) {
				var op = next();
				var r = parseFactor();
				v = ( '*' === op ) ? v * r : ( r ? v / r : 0 );
			}
			return v;
		}
		function parseFactor() {
			var t = next();
			if ( '(' === t ) {
				var v = parseExpr();
				next(); // ')'
				return v;
			}
			if ( '-' === t ) { return -parseFactor(); }
			return parseFloat( t ) || 0;
		}
		var out = parseExpr();
		if ( ! isFinite( out ) ) { return ''; }
		return Math.round( out * 100 ) / 100;
	}

	/* ---------- helpers ---------- */
	function fieldValue( form, name ) {
		var sel = '[name="fields[' + name + ']"]';
		var nodes = form.querySelectorAll( sel );
		if ( ! nodes.length ) { return ''; }
		var el = nodes[ 0 ];
		if ( 'radio' === el.type ) {
			var checked = form.querySelector( sel + ':checked' );
			return checked ? checked.value : '';
		}
		if ( 'checkbox' === el.type ) {
			return el.checked ? el.value : '';
		}
		return el.value || '';
	}

	function setDisabled( wrap, off ) {
		var ins = wrap.querySelectorAll( 'input, select, textarea' );
		for ( var i = 0; i < ins.length; i++ ) { ins[ i ].disabled = off; }
	}

	/* ---------- conditional logic ---------- */
	function applyConditions( form ) {
		var conds = form.querySelectorAll( '[data-cond-field]' );
		for ( var i = 0; i < conds.length; i++ ) {
			var w = conds[ i ];
			var cf = w.getAttribute( 'data-cond-field' );
			var op = w.getAttribute( 'data-cond-op' ) || 'eq';
			var cv = w.getAttribute( 'data-cond-val' ) || '';
			var val = fieldValue( form, cf );
			var show = false;
			if ( 'eq' === op ) { show = ( val === cv ); }
			else if ( 'neq' === op ) { show = ( val !== cv ); }
			else if ( 'filled' === op ) { show = ( '' !== String( val ).trim() ); }
			else if ( 'empty' === op ) { show = ( '' === String( val ).trim() ); }
			w.hidden = ! show;
			setDisabled( w, ! show ); // disabled fields are skipped by validity + submit
		}
	}

	/* ---------- live calculation ---------- */
	function applyCalc( form ) {
		var calcs = form.querySelectorAll( '.wakoo-form__calc' );
		for ( var i = 0; i < calcs.length; i++ ) {
			var c = calcs[ i ];
			var formula = c.getAttribute( 'data-formula' ) || '';
			if ( ! formula ) { continue; }
			var expr = formula.replace( /\{([a-z0-9_]+)\}/gi, function ( m, n ) {
				var v = parseFloat( fieldValue( form, n ) );
				return isNaN( v ) ? '0' : String( v );
			} );
			c.value = evalExpr( expr );
		}
	}

	/* ---------- signature pad ---------- */
	function initSignature( pad ) {
		var canvas = pad.querySelector( '.wakoo-form__sign-pad' );
		var clear = pad.querySelector( '.wakoo-form__sign-clear' );
		if ( ! canvas ) { return; }
		var ctx = canvas.getContext( '2d' );
		ctx.lineWidth = 2;
		ctx.lineCap = 'round';
		ctx.strokeStyle = '#222';
		var drawing = false, dirty = false;

		function pos( e ) {
			var r = canvas.getBoundingClientRect();
			var t = e.touches ? e.touches[ 0 ] : e;
			return {
				x: ( t.clientX - r.left ) * ( canvas.width / r.width ),
				y: ( t.clientY - r.top ) * ( canvas.height / r.height ),
			};
		}
		function start( e ) { drawing = true; dirty = true; var p = pos( e ); ctx.beginPath(); ctx.moveTo( p.x, p.y ); e.preventDefault(); }
		function move( e ) { if ( ! drawing ) { return; } var p = pos( e ); ctx.lineTo( p.x, p.y ); ctx.stroke(); e.preventDefault(); }
		function end() { drawing = false; }

		canvas.addEventListener( 'mousedown', start );
		canvas.addEventListener( 'mousemove', move );
		window.addEventListener( 'mouseup', end );
		canvas.addEventListener( 'touchstart', start, { passive: false } );
		canvas.addEventListener( 'touchmove', move, { passive: false } );
		canvas.addEventListener( 'touchend', end );
		if ( clear ) {
			clear.addEventListener( 'click', function () { ctx.clearRect( 0, 0, canvas.width, canvas.height ); dirty = false; } );
		}
		pad._getBlob = function ( cb ) {
			if ( ! dirty ) { cb( null ); return; }
			canvas.toBlob( function ( b ) { cb( b ); }, 'image/png' );
		};
	}

	/* ---------- voice note ---------- */
	function initVoice( box ) {
		var rec = box.querySelector( '.wakoo-form__voice-rec' );
		var stop = box.querySelector( '.wakoo-form__voice-stop' );
		var play = box.querySelector( '.wakoo-form__voice-play' );
		var time = box.querySelector( '.wakoo-form__voice-time' );
		var mr = null, chunks = [], blob = null, timer = null, secs = 0;

		function fmt( s ) { var m = Math.floor( s / 60 ); var r = s % 60; return m + ':' + ( r < 10 ? '0' : '' ) + r; }

		if ( ! rec ) { return; }
		if ( ! navigator.mediaDevices || ! window.MediaRecorder ) {
			rec.disabled = true;
			rec.title = I18N.noVoice || '';
			return;
		}
		rec.addEventListener( 'click', function () {
			navigator.mediaDevices.getUserMedia( { audio: true } ).then( function ( stream ) {
				chunks = [];
				var type = MediaRecorder.isTypeSupported( 'audio/webm' ) ? 'audio/webm' : '';
				mr = type ? new MediaRecorder( stream, { mimeType: type } ) : new MediaRecorder( stream );
				mr.ondataavailable = function ( e ) { if ( e.data.size ) { chunks.push( e.data ); } };
				mr.onstop = function () {
					blob = new Blob( chunks, { type: mr.mimeType || 'audio/webm' } );
					if ( play ) { play.src = URL.createObjectURL( blob ); play.hidden = false; }
					stream.getTracks().forEach( function ( t ) { t.stop(); } );
				};
				mr.start();
				rec.hidden = true;
				if ( stop ) { stop.hidden = false; }
				secs = 0;
				if ( time ) { time.textContent = fmt( 0 ); }
				timer = setInterval( function () { secs++; if ( time ) { time.textContent = fmt( secs ); } }, 1000 );
			} ).catch( function () { alert( I18N.noVoice || '' ); } );
		} );
		if ( stop ) {
			stop.addEventListener( 'click', function () {
				if ( mr && 'recording' === mr.state ) { mr.stop(); }
				clearInterval( timer );
				stop.hidden = true;
				rec.hidden = false;
			} );
		}
		box._getBlob = function ( cb ) { cb( blob ); };
		box._ext = function () { return ( blob && /ogg/.test( blob.type ) ) ? 'ogg' : 'webm'; };
	}

	/* ---------- geolocation ---------- */
	function initGeo( box ) {
		var btn = box.querySelector( '.wakoo-form__geo-btn' );
		var input = box.querySelector( 'input[type="hidden"]' );
		var out = box.querySelector( '.wakoo-form__geo-out' );
		if ( ! btn ) { return; }
		btn.addEventListener( 'click', function () {
			if ( ! navigator.geolocation ) { if ( out ) { out.textContent = I18N.noGeo || ''; } return; }
			btn.disabled = true;
			navigator.geolocation.getCurrentPosition( function ( p ) {
				var lat = p.coords.latitude.toFixed( 6 );
				var lng = p.coords.longitude.toFixed( 6 );
				if ( input ) { input.value = lat + ',' + lng; }
				if ( out ) { out.textContent = lat + ', ' + lng; }
				btn.disabled = false;
			}, function () { if ( out ) { out.textContent = I18N.noGeo || ''; } btn.disabled = false; } );
		} );
	}

	/* ---------- multi-step ---------- */
	function initSteps( form ) {
		var steps = form.querySelectorAll( '.wakoo-form__step' );
		if ( steps.length < 2 ) { return null; }
		var idx = 0;
		var prev = form.querySelector( '.wakoo-form__prev' );
		var next = form.querySelector( '.wakoo-form__next' );
		var submit = form.querySelector( '.wakoo-form__submit' );
		var bar = form.querySelector( '.wakoo-form__progress-bar' );

		function render() {
			for ( var i = 0; i < steps.length; i++ ) { steps[ i ].hidden = ( i !== idx ); }
			if ( prev ) { prev.hidden = ( 0 === idx ); }
			var last = ( idx === steps.length - 1 );
			if ( next ) { next.hidden = last; }
			if ( submit ) { submit.hidden = ! last; }
			if ( bar ) { bar.style.width = ( ( idx + 1 ) / steps.length * 100 ) + '%'; }
		}
		function validStep() {
			var ins = steps[ idx ].querySelectorAll( 'input, select, textarea' );
			for ( var i = 0; i < ins.length; i++ ) {
				if ( ! ins[ i ].disabled && ! ins[ i ].checkValidity() ) { ins[ i ].reportValidity(); return false; }
			}
			return true;
		}
		if ( next ) { next.addEventListener( 'click', function () { if ( validStep() && idx < steps.length - 1 ) { idx++; render(); } } ); }
		if ( prev ) { prev.addEventListener( 'click', function () { if ( idx > 0 ) { idx--; render(); } } ); }
		render();
		return { valid: validStep, index: function () { return idx; } };
	}

	/* ---------- submit ---------- */
	function submitForm( form, e ) {
		e.preventDefault();
		var msg = form.querySelector( '.wakoo-form__msg' );
		var submit = form.querySelector( '.wakoo-form__submit' );
		applyConditions( form );

		if ( ! form.checkValidity() ) { form.reportValidity(); return; }

		var fd = new FormData( form );
		fd.append( 'action', 'wakoo_form_submit' );
		fd.append( 'nonce', CFG.nonce || '' );
		fd.append( 'form_key', form.getAttribute( 'data-key' ) || '' );
		fd.append( 'page_url', window.location.href );

		// Gather async blobs (signature, voice), then send.
		var jobs = [];
		Array.prototype.forEach.call( form.querySelectorAll( '.wakoo-form__sign' ), function ( pad ) {
			jobs.push( new Promise( function ( res ) {
				if ( ! pad._getBlob ) { res(); return; }
				pad._getBlob( function ( b ) {
					if ( b ) { fd.append( 'wkfile_' + pad.getAttribute( 'data-name' ), b, 'firma.png' ); }
					res();
				} );
			} ) );
		} );
		Array.prototype.forEach.call( form.querySelectorAll( '.wakoo-form__voice' ), function ( box ) {
			jobs.push( new Promise( function ( res ) {
				if ( ! box._getBlob ) { res(); return; }
				box._getBlob( function ( b ) {
					if ( b ) { fd.append( 'wkfile_' + box.getAttribute( 'data-name' ), b, 'nota.' + ( box._ext ? box._ext() : 'webm' ) ); }
					res();
				} );
			} ) );
		} );

		if ( submit ) { submit.disabled = true; }
		if ( msg ) { msg.className = 'wakoo-form__msg is-info'; msg.textContent = I18N.sending || ''; }

		Promise.all( jobs ).then( function () {
			return fetch( CFG.ajax, { method: 'POST', body: fd, credentials: 'same-origin' } );
		} ).then( function ( r ) { return r.json(); } ).then( function ( json ) {
			if ( submit ) { submit.disabled = false; }
			if ( json && json.success ) {
				if ( json.data && json.data.redirect ) { window.location.href = json.data.redirect; return; }
				if ( msg ) { msg.className = 'wakoo-form__msg is-ok'; msg.textContent = ( json.data && json.data.message ) || ''; }
				form.reset();
				applyConditions( form );
				applyCalc( form );
			} else {
				if ( msg ) { msg.className = 'wakoo-form__msg is-err'; msg.textContent = ( json && json.data && json.data.message ) || I18N.generic || ''; }
			}
		} ).catch( function () {
			if ( submit ) { submit.disabled = false; }
			if ( msg ) { msg.className = 'wakoo-form__msg is-err'; msg.textContent = I18N.generic || ''; }
		} );
	}

	/* ---------- init one form ---------- */
	function initForm( form ) {
		if ( form.dataset.wakooInit ) { return; }
		form.dataset.wakooInit = '1';

		var ts = form.querySelector( 'input[name="wakoo_ts"]' );
		if ( ts ) { ts.value = Math.floor( Date.now() / 1000 ); }

		Array.prototype.forEach.call( form.querySelectorAll( '.wakoo-form__sign' ), initSignature );
		Array.prototype.forEach.call( form.querySelectorAll( '.wakoo-form__voice' ), initVoice );
		Array.prototype.forEach.call( form.querySelectorAll( '.wakoo-form__geo' ), initGeo );
		initSteps( form );

		form.addEventListener( 'input', function () { applyConditions( form ); applyCalc( form ); } );
		form.addEventListener( 'change', function () { applyConditions( form ); applyCalc( form ); } );
		applyConditions( form );
		applyCalc( form );

		form.addEventListener( 'submit', function ( e ) { submitForm( form, e ); } );
	}

	function boot( root ) {
		var scope = root && root.querySelectorAll ? root : document;
		var forms = scope.querySelectorAll( '.wakoo-form' );
		for ( var i = 0; i < forms.length; i++ ) { initForm( forms[ i ] ); }
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', function () { boot( document ); } );
	} else {
		boot( document );
	}

	// Elementor editor/preview: re-init on widget render.
	if ( window.jQuery ) {
		window.jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend && window.elementorFrontend.hooks ) {
				window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-form.default', function ( $scope ) {
					boot( $scope[ 0 ] );
				} );
			}
		} );
	}
}() );
