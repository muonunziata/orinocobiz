<?php
/**
 * Wakoo Forms: a native form builder (not a styler for third-party form plugins).
 *
 * The "Formulario (Wakoo)" widget renders fields of many types (text, email,
 * file upload, signature, voice note, geolocation, calculation, multi-step…).
 * On submit (AJAX, multipart) the server validates, stores uploads safely,
 * saves the entry as a `wakoo_submission` (so entries are never lost), and
 * emails it. Per-form settings (recipient, subject, messages, field list) are
 * saved server-side on render and looked up by an opaque key, so the recipient
 * address can never be tampered with from the browser. A CSV export of the
 * inbox is available from the admin menu.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Forms;

defined( 'ABSPATH' ) || die();

class Module {

	const CPT       = 'wakoo_submission';
	const REGISTRY  = 'wakoo_forms_registry';
	const NONCE     = 'wakoo_form';
	const MAX_BYTES = 10485760; // 10 MB per uploaded file.
	const MIN_FILL  = 2;        // Seconds: faster than this = bot (time trap).

	public static function init() {
		add_action( 'init', [ __CLASS__, 'register_cpt' ] );
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'assets' ] );
		add_action( 'wp_ajax_wakoo_form_submit', [ __CLASS__, 'handle' ] );
		add_action( 'wp_ajax_nopriv_wakoo_form_submit', [ __CLASS__, 'handle' ] );
		// Submissions admin.
		add_filter( 'manage_' . self::CPT . '_posts_columns', [ __CLASS__, 'columns' ] );
		add_action( 'manage_' . self::CPT . '_posts_custom_column', [ __CLASS__, 'column' ], 10, 2 );
		add_action( 'add_meta_boxes', [ __CLASS__, 'detail_box' ] );
		add_action( 'admin_menu', [ __CLASS__, 'export_menu' ] );
		add_action( 'admin_post_wakoo_export_csv', [ __CLASS__, 'export_csv' ] );
	}

	public static function register_cpt() {
		register_post_type( self::CPT, [
			'labels' => [
				'name'          => __( 'Mensajes (Wakoo)', 'wakoo' ),
				'singular_name' => __( 'Mensaje', 'wakoo' ),
				'menu_name'     => __( 'Mensajes Wakoo', 'wakoo' ),
			],
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => true,
			'menu_icon'       => 'dashicons-email-alt',
			'menu_position'   => 57,
			'capability_type' => 'post',
			'capabilities'    => [ 'create_posts' => 'do_not_allow' ],
			'map_meta_cap'    => true,
			'supports'        => [ 'title' ],
		] );
	}

	public static function register_widget( $wm ) {
		require_once __DIR__ . '/widget.php';
		$wm->register( new Widget() );
	}

	public static function assets() {
		wp_register_script( 'wakoo-forms', WAKOO_MODULES_URL . 'forms/assets/forms.js', [], WAKOO_VERSION, true );
		wp_register_style( 'wakoo-forms', WAKOO_MODULES_URL . 'forms/assets/forms.css', [], WAKOO_VERSION );
		wp_localize_script( 'wakoo-forms', 'WakooForms', [
			'ajax'  => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( self::NONCE ),
			'i18n'  => [
				'required'  => __( 'Revisa los campos obligatorios.', 'wakoo' ),
				'sending'   => __( 'Enviando…', 'wakoo' ),
				'generic'   => __( 'No se pudo enviar. Inténtalo de nuevo.', 'wakoo' ),
				'noGeo'     => __( 'Tu navegador no permite la geolocalización.', 'wakoo' ),
				'noVoice'   => __( 'Tu navegador no permite grabar audio.', 'wakoo' ),
			],
		] );
	}

	/** Called by the widget on render to persist its server-side config; returns the key. */
	public static function register_form( $key, $config ) {
		$reg = get_option( self::REGISTRY, [] );
		if ( ! is_array( $reg ) ) {
			$reg = [];
		}
		$reg[ $key ] = $config;
		update_option( self::REGISTRY, $reg, false );
		return $key;
	}

	public static function handle() {
		if ( ! check_ajax_referer( self::NONCE, 'nonce', false ) ) {
			wp_send_json_error( [ 'message' => __( 'Sesión caducada, recarga la página.', 'wakoo' ) ] );
		}
		$key  = isset( $_POST['form_key'] ) ? sanitize_text_field( wp_unslash( $_POST['form_key'] ) ) : '';
		$reg  = (array) get_option( self::REGISTRY, [] );
		$conf = isset( $reg[ $key ] ) ? $reg[ $key ] : null;
		if ( ! $conf ) {
			wp_send_json_error( [ 'message' => __( 'Formulario no válido.', 'wakoo' ) ] );
		}

		// Spam: honeypot (a filled hidden field = bot) → pretend success.
		if ( ! empty( $_POST['wakoo_hp'] ) ) {
			wp_send_json_success( [ 'message' => $conf['success'] ] );
		}
		// Spam: time trap (submitted implausibly fast).
		$ts = isset( $_POST['wakoo_ts'] ) ? (int) $_POST['wakoo_ts'] : 0;
		if ( $ts && ( time() - $ts ) < self::MIN_FILL ) {
			wp_send_json_success( [ 'message' => $conf['success'] ] );
		}

		$values  = [];
		$errors  = [];
		$uploads = [];
		foreach ( $conf['fields'] as $f ) {
			$name = $f['name'];
			$type = $f['type'];

			if ( in_array( $type, [ 'file', 'signature', 'voice' ], true ) ) {
				$res = self::handle_upload( 'wkfile_' . $name, $type, $f );
				if ( is_wp_error( $res ) ) {
					$errors[] = $f['label'];
				} elseif ( $res ) {
					$uploads[ $f['label'] ] = $res; // URL string.
					$values[ $f['label'] ]  = $res;
				} elseif ( ! empty( $f['required'] ) ) {
					$errors[] = $f['label'];
				}
				continue;
			}

			$raw = isset( $_POST['fields'][ $name ] ) ? wp_unslash( $_POST['fields'][ $name ] ) : '';
			if ( is_array( $raw ) ) {
				$raw = implode( ', ', array_map( 'sanitize_text_field', $raw ) );
			} elseif ( 'textarea' === $type ) {
				$raw = sanitize_textarea_field( $raw );
			} elseif ( 'email' === $type ) {
				$raw = sanitize_email( $raw );
			} elseif ( 'url' === $type ) {
				$raw = esc_url_raw( $raw );
			} elseif ( 'geo' === $type ) {
				// "lat,lng" only.
				$raw = preg_replace( '/[^0-9.,\- ]/', '', (string) $raw );
			} else {
				$raw = sanitize_text_field( $raw );
			}
			if ( ! empty( $f['required'] ) && '' === trim( (string) $raw ) ) {
				$errors[] = $f['label'];
			}
			if ( 'email' === $type && '' !== $raw && ! is_email( $raw ) ) {
				$errors[] = $f['label'];
			}
			$values[ $f['label'] ] = $raw;
		}

		if ( $errors ) {
			// Clean up any files already stored for this failed submission.
			foreach ( $uploads as $url ) {
				self::delete_by_url( $url );
			}
			wp_send_json_error( [ 'message' => __( 'Revisa los campos obligatorios.', 'wakoo' ), 'fields' => array_values( array_unique( $errors ) ) ] );
		}

		// Store submission (if enabled).
		if ( ! empty( $conf['store'] ) ) {
			$title = sprintf( '%s — %s', $conf['title'], current_time( 'Y-m-d H:i' ) );
			$pid   = wp_insert_post( [ 'post_type' => self::CPT, 'post_status' => 'publish', 'post_title' => $title ] );
			if ( $pid && ! is_wp_error( $pid ) ) {
				update_post_meta( $pid, '_wakoo_fields', $values );
				update_post_meta( $pid, '_wakoo_files', $uploads );
				update_post_meta( $pid, '_wakoo_meta', [
					'ip'   => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
					'page' => isset( $_POST['page_url'] ) ? esc_url_raw( wp_unslash( $_POST['page_url'] ) ) : '',
					'time' => current_time( 'mysql' ),
					'form' => $conf['title'],
				] );
			}
		}

		// Email.
		$to      = $conf['to'] ? $conf['to'] : get_option( 'admin_email' );
		$subject = $conf['subject'] ? $conf['subject'] : sprintf( __( 'Nuevo mensaje: %s', 'wakoo' ), $conf['title'] );
		$lines   = [];
		foreach ( $values as $label => $val ) {
			$lines[] = $label . ': ' . $val;
		}
		$body    = implode( "\n", $lines ) . "\n\n" . home_url( '/' );
		$headers = [];
		foreach ( $values as $val ) {
			if ( is_email( $val ) ) {
				$headers[] = 'Reply-To: ' . $val;
				break;
			}
		}
		wp_mail( $to, $subject, $body, $headers );

		wp_send_json_success( [
			'message'  => $conf['success'],
			'redirect' => ! empty( $conf['redirect'] ) ? $conf['redirect'] : '',
		] );
	}

	/**
	 * Validate + store one uploaded file. Returns the URL string, '' when the
	 * (optional) field was left empty, or WP_Error on a rejected upload.
	 */
	private static function handle_upload( $field, $type, $conf ) {
		if ( empty( $_FILES[ $field ] ) || empty( $_FILES[ $field ]['name'] ) ) {
			return '';
		}
		$file = $_FILES[ $field ]; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( ! empty( $file['error'] ) && UPLOAD_ERR_NO_FILE === $file['error'] ) {
			return '';
		}
		if ( ! empty( $file['size'] ) && $file['size'] > self::MAX_BYTES ) {
			return new \WP_Error( 'too_big', __( 'Archivo demasiado grande.', 'wakoo' ) );
		}

		$allowed = self::allowed_mimes( $type, $conf );

		// Validate real type (extension + content) against the whitelist.
		$check = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'], $allowed );
		if ( empty( $check['type'] ) || ! in_array( $check['type'], array_values( $allowed ), true ) ) {
			return new \WP_Error( 'bad_type', __( 'Tipo de archivo no permitido.', 'wakoo' ) );
		}

		if ( ! function_exists( 'wp_handle_upload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$moved = wp_handle_upload( $file, [ 'test_form' => false, 'mimes' => $allowed ] );
		if ( isset( $moved['error'] ) ) {
			return new \WP_Error( 'upload', $moved['error'] );
		}
		return isset( $moved['url'] ) ? esc_url_raw( $moved['url'] ) : '';
	}

	/** Whitelist of extension => mime for a field, limited to its declared kind. */
	private static function allowed_mimes( $type, $conf ) {
		if ( 'signature' === $type ) {
			return [ 'png' => 'image/png' ];
		}
		if ( 'voice' === $type ) {
			// NB: a WebM/OGG audio container is reported by libmagic as
			// video/webm or video/ogg, so the real-content check must allow those.
			return [
				'webm' => 'video/webm',
				'ogg'  => 'video/ogg',
				'oga'  => 'audio/ogg',
				'mp3'  => 'audio/mpeg',
				'm4a'  => 'audio/mp4',
				'mp4'  => 'video/mp4',
				'wav'  => 'audio/wav',
			];
		}
		// Generic file upload.
		$base = [
			'jpg'  => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png',
			'gif'  => 'image/gif', 'webp' => 'image/webp',
			'pdf'  => 'application/pdf',
			'doc'  => 'application/msword',
			'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
			'xls'  => 'application/vnd.ms-excel',
			'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
			'txt'  => 'text/plain',
			'zip'  => 'application/zip',
		];
		$accept = isset( $conf['accept'] ) ? trim( (string) $conf['accept'] ) : '';
		if ( '' === $accept ) {
			return $base;
		}
		// Narrow the whitelist to the extensions the editor allowed.
		$exts = array_filter( array_map(
			function ( $e ) { return ltrim( strtolower( trim( $e ) ), '.' ); },
			explode( ',', $accept )
		) );
		if ( ! $exts ) {
			return $base;
		}
		$out = array_intersect_key( $base, array_flip( $exts ) );
		return $out ? $out : $base;
	}

	/** Remove an uploaded file given its public URL (orphan cleanup on failed submit). */
	private static function delete_by_url( $url ) {
		if ( ! $url ) {
			return;
		}
		$up = wp_get_upload_dir();
		if ( empty( $up['baseurl'] ) || 0 !== strpos( $url, $up['baseurl'] ) ) {
			return;
		}
		$path = $up['basedir'] . substr( $url, strlen( $up['baseurl'] ) );
		if ( file_exists( $path ) ) {
			wp_delete_file( $path );
		}
	}

	/* ---- submissions admin ---- */

	public static function columns( $cols ) {
		return [
			'cb'           => $cols['cb'] ?? '',
			'title'        => __( 'Mensaje', 'wakoo' ),
			'wakoo_fields' => __( 'Contenido', 'wakoo' ),
			'date'         => $cols['date'] ?? __( 'Fecha', 'wakoo' ),
		];
	}

	public static function column( $col, $post_id ) {
		if ( 'wakoo_fields' === $col ) {
			$fields = (array) get_post_meta( $post_id, '_wakoo_fields', true );
			$parts  = [];
			foreach ( $fields as $label => $val ) {
				$parts[] = '<strong>' . esc_html( $label ) . ':</strong> ' . esc_html( wp_trim_words( (string) $val, 12 ) );
			}
			echo implode( '<br>', array_slice( $parts, 0, 4 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	public static function detail_box() {
		add_meta_box( 'wakoo_submission_box', __( 'Contenido del mensaje', 'wakoo' ), [ __CLASS__, 'detail_html' ], self::CPT, 'normal', 'high' );
	}

	public static function detail_html( $post ) {
		$fields = (array) get_post_meta( $post->ID, '_wakoo_fields', true );
		$files  = (array) get_post_meta( $post->ID, '_wakoo_files', true );
		$meta   = (array) get_post_meta( $post->ID, '_wakoo_meta', true );
		echo '<table class="widefat striped"><tbody>';
		foreach ( $fields as $label => $val ) {
			$val = (string) $val;
			if ( isset( $files[ $label ] ) ) {
				$url   = esc_url( $files[ $label ] );
				$is_img = (bool) preg_match( '/\.(png|jpe?g|gif|webp)$/i', $url );
				$cell   = $is_img
					? '<a href="' . $url . '" target="_blank"><img src="' . $url . '" style="max-width:220px;height:auto;border:1px solid #ddd"></a>'
					: '<a href="' . $url . '" target="_blank">' . esc_html__( 'Ver / descargar', 'wakoo' ) . '</a>';
				echo '<tr><th style="width:200px">' . esc_html( $label ) . '</th><td>' . $cell . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			} else {
				echo '<tr><th style="width:200px">' . esc_html( $label ) . '</th><td>' . nl2br( esc_html( $val ) ) . '</td></tr>';
			}
		}
		if ( ! empty( $meta['page'] ) ) {
			echo '<tr><th>' . esc_html__( 'Página', 'wakoo' ) . '</th><td>' . esc_html( $meta['page'] ) . '</td></tr>';
		}
		if ( ! empty( $meta['ip'] ) ) {
			echo '<tr><th>IP</th><td>' . esc_html( $meta['ip'] ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	/* ---- CSV export ---- */

	public static function export_menu() {
		add_submenu_page(
			'edit.php?post_type=' . self::CPT,
			__( 'Exportar a CSV', 'wakoo' ),
			__( 'Exportar a CSV', 'wakoo' ),
			'edit_posts',
			'wakoo-export',
			[ __CLASS__, 'export_page' ]
		);
	}

	public static function export_page() {
		$url = wp_nonce_url( admin_url( 'admin-post.php?action=wakoo_export_csv' ), 'wakoo_export' );
		echo '<div class="wrap"><h1>' . esc_html__( 'Exportar mensajes a CSV', 'wakoo' ) . '</h1>';
		echo '<p>' . esc_html__( 'Descarga todas las respuestas guardadas en un archivo CSV (se abre en Excel, Numbers o Google Sheets).', 'wakoo' ) . '</p>';
		echo '<a class="button button-primary" href="' . esc_url( $url ) . '">' . esc_html__( 'Descargar CSV', 'wakoo' ) . '</a></div>';
	}

	public static function export_csv() {
		if ( ! current_user_can( 'edit_posts' ) || ! check_admin_referer( 'wakoo_export' ) ) {
			wp_die( esc_html__( 'No autorizado.', 'wakoo' ) );
		}
		$posts = get_posts( [
			'post_type'      => self::CPT,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'orderby'        => 'date',
			'order'          => 'DESC',
		] );

		// Collect the union of all field labels for a stable header.
		$labels = [];
		$rows   = [];
		foreach ( $posts as $p ) {
			$fields = (array) get_post_meta( $p->ID, '_wakoo_fields', true );
			$meta   = (array) get_post_meta( $p->ID, '_wakoo_meta', true );
			foreach ( array_keys( $fields ) as $l ) {
				$labels[ $l ] = true;
			}
			$rows[] = [
				'form'   => $meta['form'] ?? '',
				'time'   => $meta['time'] ?? get_the_date( 'Y-m-d H:i', $p ),
				'fields' => $fields,
			];
		}
		$labels = array_keys( $labels );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="wakoo-mensajes-' . gmdate( 'Y-m-d' ) . '.csv"' );
		$out = fopen( 'php://output', 'w' );
		fprintf( $out, "\xEF\xBB\xBF" ); // UTF-8 BOM for Excel.
		fputcsv( $out, array_merge( [ __( 'Formulario', 'wakoo' ), __( 'Fecha', 'wakoo' ) ], $labels ) );
		foreach ( $rows as $r ) {
			$line = [ $r['form'], $r['time'] ];
			foreach ( $labels as $l ) {
				$line[] = isset( $r['fields'][ $l ] ) ? (string) $r['fields'][ $l ] : '';
			}
			fputcsv( $out, $line );
		}
		fclose( $out );
		exit;
	}
}

Module::init();
