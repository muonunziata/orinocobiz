<?php
/**
 * Wakoo Form widget: native advanced form (no third-party form plugin).
 *
 * Field types: text, email, tel, number, date, url, textarea, select, radio,
 * checkbox, file upload, signature (draw), voice note (audio recording),
 * geolocation, calculation, and a "step" separator for multi-step forms.
 * Per-field conditional logic (show when another field matches). Client-side
 * multi-step, conditions and live calculation; server-side validation, upload
 * handling, submissions inbox and email.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Forms;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

defined( 'ABSPATH' ) || die();

class Widget extends Widget_Base {

	public function get_name() { return 'wakoo-form'; }
	public function get_title() { return __( 'Formulario (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-form-horizontal'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'form', 'formulario', 'contacto', 'firma', 'voz', 'ubicacion', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-forms' ]; }
	public function get_style_depends() { return [ 'wakoo-forms' ]; }

	protected function register_controls() {

		$this->start_controls_section( 'sec_fields', [ 'label' => __( 'Campos', 'wakoo' ) ] );

		$rep = new Repeater();
		$rep->add_control( 'ftype', [
			'label'   => __( 'Tipo', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'text',
			'groups'  => [
				[ 'label' => __( 'Básicos', 'wakoo' ), 'options' => [
					'text'     => __( 'Texto', 'wakoo' ),
					'email'    => __( 'Email', 'wakoo' ),
					'tel'      => __( 'Teléfono', 'wakoo' ),
					'number'   => __( 'Número', 'wakoo' ),
					'date'     => __( 'Fecha', 'wakoo' ),
					'url'      => __( 'Enlace (URL)', 'wakoo' ),
					'textarea' => __( 'Área de texto', 'wakoo' ),
					'select'   => __( 'Desplegable', 'wakoo' ),
					'radio'    => __( 'Opción única', 'wakoo' ),
					'checkbox' => __( 'Casilla', 'wakoo' ),
				] ],
				[ 'label' => __( 'Avanzados', 'wakoo' ), 'options' => [
					'file'      => __( 'Subir archivo', 'wakoo' ),
					'signature' => __( 'Firma', 'wakoo' ),
					'voice'     => __( 'Nota de voz', 'wakoo' ),
					'geo'       => __( 'Ubicación (geolocalización)', 'wakoo' ),
					'calc'      => __( 'Cálculo', 'wakoo' ),
					'step'      => __( '— Separador de paso —', 'wakoo' ),
				] ],
			],
		] );
		$rep->add_control( 'flabel', [ 'label' => __( 'Etiqueta', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Campo', 'wakoo' ) ] );
		$rep->add_control( 'fplaceholder', [ 'label' => __( 'Marcador', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'condition' => [ 'ftype!' => [ 'checkbox', 'signature', 'voice', 'geo', 'calc', 'step', 'radio' ] ] ] );
		$rep->add_control( 'foptions', [
			'label'       => __( 'Opciones (una por línea)', 'wakoo' ),
			'type'        => Controls_Manager::TEXTAREA,
			'condition'   => [ 'ftype' => [ 'select', 'radio' ] ],
		] );
		$rep->add_control( 'fcalc', [
			'label'       => __( 'Fórmula', 'wakoo' ),
			'type'        => Controls_Manager::TEXT,
			'description' => __( 'Usa {nombre} de otros campos, ej. {f1} * {f2}. Los nombres son f1, f2… por orden.', 'wakoo' ),
			'label_block' => true,
			'condition'   => [ 'ftype' => 'calc' ],
		] );
		$rep->add_control( 'faccept', [
			'label'       => __( 'Tipos permitidos', 'wakoo' ),
			'type'        => Controls_Manager::TEXT,
			'placeholder' => '.pdf,.jpg,.png,.doc',
			'condition'   => [ 'ftype' => 'file' ],
		] );
		$rep->add_control( 'frequired', [ 'label' => __( 'Obligatorio', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'condition' => [ 'ftype!' => [ 'step', 'calc' ] ] ] );
		$rep->add_control( 'fwidth', [
			'label'   => __( 'Ancho', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => '100',
			'options' => [ '100' => '100%', '50' => '50%', '33' => '33%' ],
			'condition' => [ 'ftype!' => 'step' ],
		] );
		// Conditional logic.
		$rep->add_control( 'fcond_on', [ 'label' => __( 'Mostrar solo si…', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'separator' => 'before' ] );
		$rep->add_control( 'fcond_field', [ 'label' => __( 'Campo (nombre f1, f2…)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'placeholder' => 'f1', 'condition' => [ 'fcond_on' => 'yes' ] ] );
		$rep->add_control( 'fcond_op', [
			'label' => __( 'Condición', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'eq',
			'options' => [ 'eq' => __( 'es igual a', 'wakoo' ), 'neq' => __( 'no es', 'wakoo' ), 'filled' => __( 'tiene valor', 'wakoo' ), 'empty' => __( 'está vacío', 'wakoo' ) ],
			'condition' => [ 'fcond_on' => 'yes' ],
		] );
		$rep->add_control( 'fcond_val', [ 'label' => __( 'Valor', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'condition' => [ 'fcond_on' => 'yes', 'fcond_op' => [ 'eq', 'neq' ] ] ] );

		$this->add_control( 'fields', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $rep->get_controls(),
			'title_field' => '{{{ ftype === "step" ? "— Paso —" : flabel }}}',
			'default'     => [
				[ 'ftype' => 'text', 'flabel' => __( 'Nombre', 'wakoo' ), 'frequired' => 'yes', 'fwidth' => '50' ],
				[ 'ftype' => 'email', 'flabel' => __( 'Email', 'wakoo' ), 'frequired' => 'yes', 'fwidth' => '50' ],
				[ 'ftype' => 'textarea', 'flabel' => __( 'Mensaje', 'wakoo' ), 'frequired' => 'yes', 'fwidth' => '100' ],
			],
		] );

		$this->add_control( 'button_text', [ 'label' => __( 'Texto del botón', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Enviar', 'wakoo' ) ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_actions', [ 'label' => __( 'Envío y acciones', 'wakoo' ) ] );
		$this->add_control( 'email_to', [ 'label' => __( 'Enviar a (email)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'placeholder' => get_option( 'admin_email' ) ] );
		$this->add_control( 'email_subject', [ 'label' => __( 'Asunto', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$this->add_control( 'success_msg', [ 'label' => __( 'Mensaje de éxito', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( '¡Gracias! Tu mensaje se ha enviado.', 'wakoo' ) ] );
		$this->add_control( 'redirect', [ 'label' => __( 'Redirigir a (URL, opcional)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'placeholder' => 'https://…' ] );
		$this->add_control( 'form_name', [ 'label' => __( 'Nombre del formulario', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Formulario', 'wakoo' ) ] );
		$this->add_control( 'store', [ 'label' => __( 'Guardar en la bandeja', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'accent', [
			'label'     => __( 'Color principal', 'wakoo' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#6C5CE7',
			'selectors' => [
				'{{WRAPPER}} .wakoo-form__submit, {{WRAPPER}} .wakoo-form__nav button' => 'background: {{VALUE}};',
				'{{WRAPPER}} .wakoo-form__progress-bar' => 'background: {{VALUE}};',
			],
		] );
		$this->end_controls_section();
	}

	/** Build the server-side field config + render data for one field. */
	private function field_name( $i ) { return 'f' . $i; }

	protected function render() {
		$s = $this->get_settings_for_display();
		$raw_fields = (array) ( $s['fields'] ?? [] );

		// Build config (server truth) and detect steps.
		$fields_cfg = [];
		$i = 0;
		$has_steps = false;
		foreach ( $raw_fields as $f ) {
			$i++;
			$name = $this->field_name( $i );
			if ( 'step' === $f['ftype'] ) { $has_steps = true; }
			$fields_cfg[] = [
				'name'      => $name,
				'type'      => $f['ftype'],
				'label'     => $f['flabel'] ?? $name,
				'required'  => ( 'yes' === ( $f['frequired'] ?? '' ) ) && empty( $f['fcond_on'] ),
				'accept'    => $f['faccept'] ?? '',
				'conditional' => ( 'yes' === ( $f['fcond_on'] ?? '' ) ),
			];
		}
		$key = md5( get_the_ID() . '|' . $this->get_id() );
		Module::register_form( $key, [
			'title'    => $s['form_name'] ?? 'Formulario',
			'to'       => sanitize_email( $s['email_to'] ?? '' ),
			'subject'  => $s['email_subject'] ?? '',
			'success'  => $s['success_msg'] ?? '',
			'redirect' => esc_url_raw( $s['redirect'] ?? '' ),
			'store'    => ( 'yes' === ( $s['store'] ?? 'yes' ) ),
			'fields'   => $fields_cfg,
		] );

		$form_attr = 'class="wakoo-form' . ( $has_steps ? ' wakoo-form--steps' : '' ) . '" method="post" enctype="multipart/form-data" novalidate data-key="' . esc_attr( $key ) . '"';
		echo '<form ' . $form_attr . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( $has_steps ) {
			echo '<div class="wakoo-form__progress"><div class="wakoo-form__progress-bar"></div></div>';
		}
		echo '<div class="wakoo-form__steps">';
		echo '<div class="wakoo-form__step wakoo-form__grid">';

		$i = 0;
		foreach ( $raw_fields as $f ) {
			$i++;
			$type = $f['ftype'];
			if ( 'step' === $type ) {
				echo '</div><div class="wakoo-form__step wakoo-form__grid" hidden>';
				continue;
			}
			$name  = $this->field_name( $i );
			$req   = ( 'yes' === ( $f['frequired'] ?? '' ) );
			$w     = (int) ( $f['fwidth'] ?? 100 );
			$label = esc_html( $f['flabel'] ?? '' );
			$ph    = esc_attr( $f['fplaceholder'] ?? '' );
			$rattr = $req ? ' required' : '';

			// Conditional data attributes.
			$cond = '';
			if ( 'yes' === ( $f['fcond_on'] ?? '' ) ) {
				$cond = sprintf(
					' data-cond-field="%s" data-cond-op="%s" data-cond-val="%s"',
					esc_attr( $f['fcond_field'] ?? '' ),
					esc_attr( $f['fcond_op'] ?? 'eq' ),
					esc_attr( $f['fcond_val'] ?? '' )
				);
			}

			echo '<div class="wakoo-form__field wakoo-form__w-' . esc_attr( $w ) . '" data-name="' . esc_attr( $name ) . '"' . $cond . ( $cond ? ' hidden' : '' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

			$show_label = ! in_array( $type, [ 'checkbox' ], true );
			if ( $show_label && '' !== $label ) {
				echo '<label>' . $label . ( $req ? ' <span class="wakoo-form__req">*</span>' : '' ) . '</label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}

			switch ( $type ) {
				case 'textarea':
					echo '<textarea name="fields[' . esc_attr( $name ) . ']" rows="4" placeholder="' . $ph . '"' . $rattr . '></textarea>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					break;
				case 'select':
					echo '<select name="fields[' . esc_attr( $name ) . ']"' . $rattr . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo '<option value="">' . esc_html( $f['fplaceholder'] ? $f['fplaceholder'] : '—' ) . '</option>';
					foreach ( $this->opts( $f ) as $opt ) {
						echo '<option value="' . esc_attr( $opt ) . '">' . esc_html( $opt ) . '</option>';
					}
					echo '</select>';
					break;
				case 'radio':
					echo '<div class="wakoo-form__radios">';
					foreach ( $this->opts( $f ) as $k => $opt ) {
						echo '<label class="wakoo-form__radio"><input type="radio" name="fields[' . esc_attr( $name ) . ']" value="' . esc_attr( $opt ) . '"' . ( 0 === $k ? $rattr : '' ) . '> ' . esc_html( $opt ) . '</label>';
					}
					echo '</div>';
					break;
				case 'checkbox':
					echo '<label class="wakoo-form__check"><input type="checkbox" name="fields[' . esc_attr( $name ) . ']" value="1"' . $rattr . '> ' . $label . '</label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					break;
				case 'file':
					$accept = $f['faccept'] ? ' accept="' . esc_attr( $f['faccept'] ) . '"' : '';
					echo '<input type="file" name="wkfile_' . esc_attr( $name ) . '"' . $accept . $rattr . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					break;
				case 'signature':
					echo '<div class="wakoo-form__sign" data-name="' . esc_attr( $name ) . '">';
					echo '<canvas class="wakoo-form__sign-pad" width="500" height="180"></canvas>';
					echo '<button type="button" class="wakoo-form__sign-clear">' . esc_html__( 'Borrar', 'wakoo' ) . '</button>';
					echo '</div>';
					break;
				case 'voice':
					echo '<div class="wakoo-form__voice" data-name="' . esc_attr( $name ) . '">';
					echo '<button type="button" class="wakoo-form__voice-rec">● ' . esc_html__( 'Grabar', 'wakoo' ) . '</button>';
					echo '<button type="button" class="wakoo-form__voice-stop" hidden>■ ' . esc_html__( 'Detener', 'wakoo' ) . '</button>';
					echo '<audio class="wakoo-form__voice-play" controls hidden></audio>';
					echo '<span class="wakoo-form__voice-time"></span>';
					echo '</div>';
					break;
				case 'geo':
					echo '<div class="wakoo-form__geo" data-name="' . esc_attr( $name ) . '">';
					echo '<button type="button" class="wakoo-form__geo-btn">📍 ' . esc_html__( 'Compartir mi ubicación', 'wakoo' ) . '</button>';
					echo '<input type="hidden" name="fields[' . esc_attr( $name ) . ']" value="">';
					echo '<span class="wakoo-form__geo-out"></span>';
					echo '</div>';
					break;
				case 'calc':
					echo '<input type="text" class="wakoo-form__calc" name="fields[' . esc_attr( $name ) . ']" data-formula="' . esc_attr( $f['fcalc'] ?? '' ) . '" readonly>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					break;
				default: // text, email, tel, number, date, url
					echo '<input type="' . esc_attr( $type ) . '" name="fields[' . esc_attr( $name ) . ']" placeholder="' . $ph . '"' . $rattr . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</div>';
		}

		echo '</div>'; // last step
		echo '</div>'; // steps

		if ( $has_steps ) {
			echo '<div class="wakoo-form__nav">';
			echo '<button type="button" class="wakoo-form__prev" hidden>' . esc_html__( 'Anterior', 'wakoo' ) . '</button>';
			echo '<button type="button" class="wakoo-form__next">' . esc_html__( 'Siguiente', 'wakoo' ) . '</button>';
			echo '<button type="submit" class="wakoo-form__submit" hidden>' . esc_html( $s['button_text'] ?? 'Enviar' ) . '</button>';
			echo '</div>';
		} else {
			echo '<button type="submit" class="wakoo-form__submit">' . esc_html( $s['button_text'] ?? 'Enviar' ) . '</button>';
		}

		// Honeypot + time trap.
		echo '<input type="text" name="wakoo_hp" class="wakoo-form__hp" tabindex="-1" autocomplete="off" aria-hidden="true">';
		echo '<input type="hidden" name="wakoo_ts" value="">';
		echo '<div class="wakoo-form__msg" role="status" aria-live="polite"></div>';
		echo '</form>';
	}

	private function opts( $f ) {
		$out = [];
		foreach ( preg_split( '/\r\n|\r|\n/', (string) ( $f['foptions'] ?? '' ) ) as $opt ) {
			$opt = trim( $opt );
			if ( '' !== $opt ) { $out[] = $opt; }
		}
		return $out;
	}
}
