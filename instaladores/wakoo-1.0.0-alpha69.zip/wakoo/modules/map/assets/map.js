( function () {
	'use strict';
	function init( root ) {
		if ( root.dataset.wakooInit ) { return; }
		root.dataset.wakooInit = '1';
		var cfg; try { cfg = JSON.parse( root.getAttribute( 'data-wakoo' ) || '{}' ); } catch ( e ) { cfg = {}; }
		var view = root.querySelector( '.wakoo-map__view' ), stage = root.querySelector( '.wakoo-map__stage' ), img = root.querySelector( '.wakoo-map__img' );
		var card = root.querySelector( '.wakoo-map__card' );
		var S = { z: 1, x: 0, y: 0 }, maxZ = cfg.max || 4;

		function size() { return { w: stage.offsetWidth, h: stage.offsetHeight, vw: view.clientWidth, vh: view.clientHeight }; }
		function clamp() {
			var d = size();
			var minX = Math.min( 0, d.vw - d.w * S.z ), minY = Math.min( 0, d.vh - d.h * S.z );
			S.x = Math.min( 0, Math.max( minX, S.x ) ); S.y = Math.min( 0, Math.max( minY, S.y ) );
			if ( d.w * S.z < d.vw ) { S.x = ( d.vw - d.w * S.z ) / 2; }
			if ( d.h * S.z < d.vh ) { S.y = ( d.vh - d.h * S.z ) / 2; }
		}
		function apply() {
			clamp();
			stage.style.transform = 'translate(' + S.x + 'px,' + S.y + 'px) scale(' + S.z + ')';
			stage.style.setProperty( '--inv', String( 1 / S.z ) );
		}
		function zoomAt( nz, cx, cy ) {
			nz = Math.min( maxZ, Math.max( 1, nz ) );
			var k = nz / S.z;
			S.x = cx - ( cx - S.x ) * k; S.y = cy - ( cy - S.y ) * k; S.z = nz; apply();
		}
		function fit() {
			// Stage takes the image ratio, covering the view's width, then fits inside the height.
			var vw = view.clientWidth, vh = view.clientHeight, r = ( img.naturalWidth || 1200 ) / ( img.naturalHeight || 800 );
			var w = vw, h = vw / r;
			if ( h > vh ) { h = vh; w = vh * r; }
			stage.style.width = w + 'px'; stage.style.height = h + 'px';
			S = { z: 1, x: 0, y: 0 }; apply();
		}

		root.querySelectorAll( '.wakoo-map__ctrl button' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				var t = b.getAttribute( 'data-z' ), cx = view.clientWidth / 2, cy = view.clientHeight / 2;
				if ( 'in' === t ) { zoomAt( S.z * 1.5, cx, cy ); } else if ( 'out' === t ) { zoomAt( S.z / 1.5, cx, cy ); } else { fit(); }
			} );
		} );
		if ( cfg.wheel ) {
			view.addEventListener( 'wheel', function ( e ) {
				e.preventDefault();
				var r = view.getBoundingClientRect();
				zoomAt( S.z * ( e.deltaY < 0 ? 1.2 : 1 / 1.2 ), e.clientX - r.left, e.clientY - r.top );
			}, { passive: false } );
		}

		// Drag to pan (pointer events: mouse + touch).
		var drag = null, moved = false;
		view.addEventListener( 'pointerdown', function ( e ) {
			if ( e.target.closest( '.wakoo-map__ctrl, .wakoo-map__card' ) ) { return; }
			drag = { x: e.clientX, y: e.clientY, sx: S.x, sy: S.y }; moved = false;
		} );
		window.addEventListener( 'pointermove', function ( e ) {
			if ( ! drag ) { return; }
			var dx = e.clientX - drag.x, dy = e.clientY - drag.y;
			if ( Math.abs( dx ) + Math.abs( dy ) > 4 ) { moved = true; view.classList.add( 'is-drag' ); }
			if ( moved ) { S.x = drag.sx + dx; S.y = drag.sy + dy; apply(); }
		} );
		window.addEventListener( 'pointerup', function () { drag = null; view.classList.remove( 'is-drag' ); } );

		// Pins -> card.
		function showCard( pin ) {
			var src = root.querySelector( '.wakoo-map__data [data-i="' + pin.getAttribute( 'data-i' ) + '"]' );
			if ( ! src ) { return; }
			card.querySelector( 'h4' ).textContent = src.querySelector( 'b' ).textContent;
			card.querySelector( 'p' ).textContent = src.querySelector( 'p' ).textContent;
			var a = card.querySelector( 'a' ), sa = src.querySelector( 'a' );
			if ( sa ) { a.hidden = false; a.href = sa.href; a.textContent = sa.textContent; a.target = sa.target; a.rel = sa.rel; } else { a.hidden = true; }
			card.hidden = false;
			root.querySelectorAll( '.wakoo-map__pin' ).forEach( function ( p ) { p.classList.toggle( 'is-on', p === pin ); } );
		}
		root.querySelectorAll( '.wakoo-map__pin' ).forEach( function ( p ) {
			p.addEventListener( 'click', function () { if ( ! moved ) { showCard( p ); } } );
		} );
		card.querySelector( '.wakoo-map__x' ).addEventListener( 'click', function () {
			card.hidden = true; root.querySelectorAll( '.wakoo-map__pin' ).forEach( function ( p ) { p.classList.remove( 'is-on' ); } );
		} );

		window.addEventListener( 'resize', fit );
		if ( img.complete ) { fit(); } else { img.addEventListener( 'load', fit ); }
	}
	function boot( scope ) { ( scope && scope.querySelectorAll ? scope : document ).querySelectorAll( '.wakoo-map' ).forEach( init ); }
	if ( 'loading' === document.readyState ) { document.addEventListener( 'DOMContentLoaded', function () { boot( document ); } ); } else { boot( document ); }
	if ( window.jQuery ) {
		window.jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend && window.elementorFrontend.hooks ) {
				window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-map.default', function ( $s ) { boot( $s[ 0 ] ); } );
			}
		} );
	}
}() );
