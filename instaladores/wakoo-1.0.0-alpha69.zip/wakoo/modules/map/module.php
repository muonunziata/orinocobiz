<?php
/**
 * Wakoo Mapa propio: an interactive map made from YOUR image (city map, floor
 * plan, venue, campus...) with pins, zoom and drag. No map tiles, no external
 * map service or API key.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Map;

defined( 'ABSPATH' ) || die();

class Module {

	public static function init() {
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_action( 'elementor/frontend/after_register_scripts', function () {
			wp_register_script( 'wakoo-map', WAKOO_MODULES_URL . 'map/assets/map.js', [], WAKOO_VERSION, true );
		} );
		add_action( 'elementor/frontend/after_register_styles', function () {
			wp_register_style( 'wakoo-map', WAKOO_MODULES_URL . 'map/assets/map.css', [], WAKOO_VERSION );
		} );
	}

	public static function register_widget( $wm ) {
		require_once __DIR__ . '/widget.php';
		$wm->register( new Widget() );
	}
}

Module::init();
