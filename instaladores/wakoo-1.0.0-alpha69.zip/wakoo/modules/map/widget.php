<?php
/**
 * Wakoo Map widget.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Map;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

defined( 'ABSPATH' ) || die();

class Widget extends Widget_Base {

	public function get_name() { return 'wakoo-map'; }
	public function get_title() { return __( 'Mapa interactivo (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-map-pin'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'mapa', 'map', 'pines', 'ubicacion', 'plano', 'sedes', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-map' ]; }
	public function get_style_depends() { return [ 'wakoo-map' ]; }

	protected function register_controls() {

		$this->start_controls_section( 'sec_map', [ 'label' => __( 'Mapa', 'wakoo' ) ] );
		$this->add_control( 'image', [
			'label'       => __( 'Imagen del mapa', 'wakoo' ),
			'type'        => Controls_Manager::MEDIA,
			'description' => __( 'Tu plano, mapa de la ciudad, local, campus… Si la dejas vacía se usa un mapa de ejemplo.', 'wakoo' ),
		] );
		$this->add_responsive_control( 'height', [
			'label'      => __( 'Altura (px)', 'wakoo' ),
			'type'       => Controls_Manager::NUMBER,
			'default'    => 480,
			'min'        => 200,
			'max'        => 1000,
			'selectors'  => [ '{{WRAPPER}} .wakoo-map__view' => 'height: {{VALUE}}px;' ],
		] );
		$this->add_control( 'zoom_max', [ 'label' => __( 'Zoom máximo', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 4, 'min' => 1.5, 'max' => 8, 'step' => 0.5 ] );
		$this->add_control( 'wheel', [ 'label' => __( 'Zoom con la rueda del ratón', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_pins', [ 'label' => __( 'Pines', 'wakoo' ) ] );
		$r = new Repeater();
		$r->add_control( 'title', [ 'label' => __( 'Título', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Lugar', 'wakoo' ) ] );
		$r->add_control( 'text', [ 'label' => __( 'Descripción', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA ] );
		$r->add_control( 'x', [ 'label' => __( 'Posición horizontal (%)', 'wakoo' ), 'type' => Controls_Manager::SLIDER, 'range' => [ 'px' => [ 'min' => 0, 'max' => 100, 'step' => 0.5 ] ], 'default' => [ 'size' => 50 ] ] );
		$r->add_control( 'y', [ 'label' => __( 'Posición vertical (%)', 'wakoo' ), 'type' => Controls_Manager::SLIDER, 'range' => [ 'px' => [ 'min' => 0, 'max' => 100, 'step' => 0.5 ] ], 'default' => [ 'size' => 50 ] ] );
		$r->add_control( 'color', [ 'label' => __( 'Color', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#6C5CE7' ] );
		$r->add_control( 'link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$r->add_control( 'link_text', [ 'label' => __( 'Texto del enlace', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Ver más', 'wakoo' ) ] );
		$this->add_control( 'pins', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'title_field' => '{{{ title }}}',
			'default'     => [
				[ 'title' => __( 'Sede central', 'wakoo' ), 'text' => __( 'Calle Principal 1', 'wakoo' ), 'x' => [ 'size' => 32 ], 'y' => [ 'size' => 38 ] ],
				[ 'title' => __( 'Tienda norte', 'wakoo' ), 'text' => __( 'Abierto de 9 a 21 h', 'wakoo' ), 'x' => [ 'size' => 62 ], 'y' => [ 'size' => 24 ], 'color' => '#E1306C' ],
				[ 'title' => __( 'Almacén', 'wakoo' ), 'x' => [ 'size' => 78 ], 'y' => [ 'size' => 56 ], 'color' => '#1E824C' ],
			],
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'radius', [ 'label' => __( 'Redondez (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 14, 'selectors' => [ '{{WRAPPER}} .wakoo-map__view' => 'border-radius: {{VALUE}}px;' ] ] );
		$this->end_controls_section();
	}

	protected function render() {
		$s   = $this->get_settings_for_display();
		$img = ! empty( $s['image']['url'] ) ? $s['image']['url'] : WAKOO_MODULES_URL . 'map/assets/default-map.svg';
		$cfg = [ 'max' => (float) ( $s['zoom_max'] ?? 4 ), 'wheel' => ( 'yes' === ( $s['wheel'] ?? '' ) ) ];

		echo '<div class="wakoo-map" data-wakoo="' . esc_attr( wp_json_encode( $cfg ) ) . '">';
		echo '<div class="wakoo-map__view"><div class="wakoo-map__stage">';
		echo '<img class="wakoo-map__img" src="' . esc_url( $img ) . '" alt="' . esc_attr__( 'Mapa', 'wakoo' ) . '" draggable="false">';
		foreach ( (array) ( $s['pins'] ?? [] ) as $i => $p ) {
			$x = (float) ( $p['x']['size'] ?? 50 );
			$y = (float) ( $p['y']['size'] ?? 50 );
			echo '<button type="button" class="wakoo-map__pin" style="left:' . esc_attr( $x ) . '%;top:' . esc_attr( $y ) . '%;--pin:' . esc_attr( $p['color'] ?: '#6C5CE7' ) . '" aria-label="' . esc_attr( $p['title'] ) . '" data-i="' . (int) $i . '"><span></span></button>';
		}
		echo '</div>';
		echo '<div class="wakoo-map__ctrl"><button type="button" data-z="in" aria-label="' . esc_attr__( 'Acercar', 'wakoo' ) . '">+</button><button type="button" data-z="out" aria-label="' . esc_attr__( 'Alejar', 'wakoo' ) . '">−</button><button type="button" data-z="reset" aria-label="' . esc_attr__( 'Restablecer', 'wakoo' ) . '">⤢</button></div>';
		echo '<div class="wakoo-map__card" hidden><button type="button" class="wakoo-map__x" aria-label="' . esc_attr__( 'Cerrar', 'wakoo' ) . '">×</button><h4></h4><p></p><a></a></div>';
		echo '</div>';

		// Pin details live in the DOM (not in attributes) so they are escaped once, server-side.
		echo '<div class="wakoo-map__data" hidden>';
		foreach ( (array) ( $s['pins'] ?? [] ) as $i => $p ) {
			echo '<div data-i="' . (int) $i . '"><b>' . esc_html( $p['title'] ) . '</b><p>' . esc_html( $p['text'] ) . '</p>';
			if ( ! empty( $p['link']['url'] ) ) {
				echo '<a href="' . esc_url( $p['link']['url'] ) . '"' . ( ! empty( $p['link']['is_external'] ) ? ' target="_blank" rel="noopener"' : '' ) . '>' . esc_html( $p['link_text'] ) . '</a>';
			}
			echo '</div>';
		}
		echo '</div></div>';
	}
}
