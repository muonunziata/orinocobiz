<?php
/**
 * Wakoo: lightweight video background for containers and sections.
 *
 * Elementor's own video background loads the video immediately. This adds a
 * "Fondo de vídeo (Wakoo)" control group that is lazy: the <video> is only
 * created and played when the element scrolls into view (IntersectionObserver),
 * shows a poster image until then, pauses off-screen, and can show the poster
 * only on mobile so phones never download the video. Sources: an uploaded file
 * or an external URL (mp4/webm).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Video_Bg;

use Elementor\Controls_Manager;
use Elementor\Control_Media;

defined( 'ABSPATH' ) || die();

class Module {

	public static function init() {
		foreach ( [ 'section', 'container' ] as $el ) {
			add_action( "elementor/element/{$el}/section_layout/after_section_end", [ __CLASS__, 'controls' ], 10, 2 );
			add_action( "elementor/frontend/{$el}/before_render", [ __CLASS__, 'before_render' ], 10, 1 );
		}
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
		add_action( 'elementor/preview/enqueue_scripts', [ __CLASS__, 'enqueue' ] );
	}

	public static function controls( $element, $args ) {
		$element->start_controls_section( 'wakoo_bgv_section', [
			'label' => __( 'Fondo de vídeo (Wakoo)', 'wakoo' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		] );

		$element->add_control( 'wakoo_bgv_enable', [
			'label'        => __( 'Activar fondo de vídeo', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'label_on'     => __( 'Sí', 'wakoo' ),
			'label_off'    => __( 'No', 'wakoo' ),
			'return_value' => 'yes',
			'default'      => '',
		] );

		$element->add_control( 'wakoo_bgv_source', [
			'label'     => __( 'Origen', 'wakoo' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'file',
			'options'   => [ 'file' => __( 'Subir archivo', 'wakoo' ), 'url' => __( 'Enlace (URL)', 'wakoo' ) ],
			'condition' => [ 'wakoo_bgv_enable' => 'yes' ],
		] );

		$element->add_control( 'wakoo_bgv_file', [
			'label'      => __( 'Vídeo (mp4/webm)', 'wakoo' ),
			'type'       => Controls_Manager::MEDIA,
			'media_type' => 'video',
			'condition'  => [ 'wakoo_bgv_enable' => 'yes', 'wakoo_bgv_source' => 'file' ],
		] );

		$element->add_control( 'wakoo_bgv_url', [
			'label'       => __( 'URL del vídeo', 'wakoo' ),
			'type'        => Controls_Manager::URL,
			'placeholder' => 'https://.../video.mp4',
			'options'     => false,
			'condition'   => [ 'wakoo_bgv_enable' => 'yes', 'wakoo_bgv_source' => 'url' ],
		] );

		$element->add_control( 'wakoo_bgv_poster', [
			'label'     => __( 'Imagen póster', 'wakoo' ),
			'type'      => Controls_Manager::MEDIA,
			'condition' => [ 'wakoo_bgv_enable' => 'yes' ],
		] );

		$element->add_control( 'wakoo_bgv_overlay', [
			'label'     => __( 'Oscurecer (0-100%)', 'wakoo' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => [ 'px' => [ 'min' => 0, 'max' => 100 ] ],
			'default'   => [ 'size' => 30 ],
			'condition' => [ 'wakoo_bgv_enable' => 'yes' ],
		] );

		$element->add_control( 'wakoo_bgv_mobile', [
			'label'        => __( 'Mostrar vídeo en móvil', 'wakoo' ),
			'description'  => __( 'Desactívalo para que en móvil solo se vea el póster (no descarga el vídeo).', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => '',
			'condition'    => [ 'wakoo_bgv_enable' => 'yes' ],
		] );

		$element->end_controls_section();
	}

	public static function before_render( $element ) {
		$s = $element->get_settings_for_display();
		if ( empty( $s['wakoo_bgv_enable'] ) || 'yes' !== $s['wakoo_bgv_enable'] ) {
			return;
		}

		$src = '';
		if ( 'url' === ( $s['wakoo_bgv_source'] ?? 'file' ) ) {
			$src = isset( $s['wakoo_bgv_url']['url'] ) ? $s['wakoo_bgv_url']['url'] : '';
		} elseif ( ! empty( $s['wakoo_bgv_file']['url'] ) ) {
			$src = $s['wakoo_bgv_file']['url'];
		}
		if ( ! $src ) {
			return;
		}

		$cfg = [
			'src'     => esc_url_raw( $src ),
			'poster'  => ! empty( $s['wakoo_bgv_poster']['url'] ) ? esc_url_raw( $s['wakoo_bgv_poster']['url'] ) : '',
			'overlay' => isset( $s['wakoo_bgv_overlay']['size'] ) ? (int) $s['wakoo_bgv_overlay']['size'] : 30,
			'mobile'  => ( ! empty( $s['wakoo_bgv_mobile'] ) && 'yes' === $s['wakoo_bgv_mobile'] ) ? 1 : 0,
		];
		$element->add_render_attribute( '_wrapper', 'class', 'wakoo-has-bgv' );
		$element->add_render_attribute( '_wrapper', 'data-wakoo-bgvideo', wp_json_encode( $cfg ) );
	}

	public static function enqueue() {
		wp_enqueue_style( 'wakoo-video-bg', WAKOO_MODULES_URL . 'video-bg/assets/video-bg.css', [], WAKOO_VERSION );
		wp_enqueue_script( 'wakoo-video-bg', WAKOO_MODULES_URL . 'video-bg/assets/video-bg.js', [], WAKOO_VERSION, true );
	}
}

Module::init();
