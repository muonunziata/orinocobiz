( function () {
	'use strict';

	function isMobile() { return window.matchMedia( '(max-width: 767px)' ).matches; }

	function build( el ) {
		if ( el.__wakooBgv ) { return; }
		el.__wakooBgv = true;
		var cfg;
		try { cfg = JSON.parse( el.getAttribute( 'data-wakoo-bgvideo' ) || '{}' ); } catch ( e ) { return; }
		if ( ! cfg.src ) { return; }

		var wrap = document.createElement( 'div' );
		wrap.className = 'wakoo-bgv';
		if ( cfg.poster ) { wrap.style.backgroundImage = 'url("' + cfg.poster + '")'; }

		if ( cfg.overlay > 0 ) {
			var ov = document.createElement( 'div' );
			ov.className = 'wakoo-bgv__overlay';
			ov.style.opacity = ( cfg.overlay / 100 );
			wrap.appendChild( ov );
		}

		// On mobile without the video enabled, keep the poster only.
		var allowVideo = cfg.mobile || ! isMobile();

		if ( allowVideo ) {
			var v = document.createElement( 'video' );
			v.className = 'wakoo-bgv__video';
			v.muted = true; v.loop = true; v.playsInline = true; v.setAttribute( 'playsinline', '' );
			v.setAttribute( 'preload', 'none' );
			v.setAttribute( 'aria-hidden', 'true' );
			if ( cfg.poster ) { v.setAttribute( 'poster', cfg.poster ); }
			wrap.appendChild( v );
			el.__wakooVideo = v;
			el.__wakooSrc = cfg.src;
		}
		el.insertBefore( wrap, el.firstChild );
	}

	function play( el ) {
		var v = el.__wakooVideo;
		if ( ! v ) { return; }
		if ( ! v.src ) { v.src = el.__wakooSrc; }
		var p = v.play();
		if ( p && p.catch ) { p.catch( function () {} ); }
	}
	function pause( el ) { if ( el.__wakooVideo ) { try { el.__wakooVideo.pause(); } catch ( e ) {} } }

	function boot() {
		var els = document.querySelectorAll( '.wakoo-has-bgv[data-wakoo-bgvideo]' );
		if ( ! els.length ) { return; }
		for ( var i = 0; i < els.length; i++ ) { build( els[ i ] ); }

		if ( 'IntersectionObserver' in window ) {
			var io = new IntersectionObserver( function ( entries ) {
				entries.forEach( function ( e ) {
					if ( e.isIntersecting ) { play( e.target ); } else { pause( e.target ); }
				} );
			}, { rootMargin: '100px', threshold: 0.1 } );
			for ( var j = 0; j < els.length; j++ ) { io.observe( els[ j ] ); }
		} else {
			for ( var k = 0; k < els.length; k++ ) { play( els[ k ] ); }
		}
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}
}() );
