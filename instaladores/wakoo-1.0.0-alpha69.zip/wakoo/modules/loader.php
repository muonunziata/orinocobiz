<?php
/**
 * Loads the modules written for Wakoo (WooCommerce builder, popups, forms...).
 *
 * @package Wakoo
 */

defined( 'ABSPATH' ) || die();

define( 'WAKOO_MODULES_PATH', WAKOO_DIR_PATH . 'modules/' );
define( 'WAKOO_MODULES_URL', WAKOO_DIR_URL . 'modules/' );

add_action( 'wakoo_loaded', function () {
	foreach ( glob( WAKOO_MODULES_PATH . '*/module.php' ) as $module ) {
		require_once $module;
	}
} );
