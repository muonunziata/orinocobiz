<?php
/**
 * Wakoo Responsive: an automatic responsive optimizer.
 *
 * On tablet and phone widths it applies a safety-net stylesheet that stacks
 * row containers into a column, makes images and videos fluid, trims oversized
 * section padding, clamps very large headings (only where the user set no
 * explicit size, so manual values always win) and calms heavy effects. It is a
 * baseline on top of Elementor's own per-device controls, on by default and
 * switchable from Wakoo → Responsive.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Responsive;

defined( 'ABSPATH' ) || die();

class Module {

	const OPTION = 'wakoo_responsive_on';

	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ], 20 );
		add_action( 'admin_init', [ __CLASS__, 'settings' ] );
		add_filter( 'body_class', [ __CLASS__, 'body_class' ] );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue' ], 20 );
	}

	public static function enabled() {
		$on = ( '0' !== get_option( self::OPTION, '1' ) );
		return (bool) apply_filters( 'wakoo_responsive_enabled', $on );
	}

	public static function body_class( $classes ) {
		if ( self::enabled() ) {
			$classes[] = 'wakoo-rwd';
		}
		return $classes;
	}

	public static function enqueue() {
		if ( self::enabled() ) {
			wp_enqueue_style( 'wakoo-responsive', WAKOO_MODULES_URL . 'responsive/assets/responsive.css', [], WAKOO_VERSION );
		}
	}

	public static function menu() {
		// Sits under the "Wakoo SEO" top-level menu when present, else its own page.
		$parent = 'wakoo-seo';
		add_submenu_page( $parent, __( 'Responsive', 'wakoo' ), __( 'Responsive', 'wakoo' ), 'manage_options', 'wakoo-responsive', [ __CLASS__, 'page' ] );
	}

	public static function settings() {
		register_setting( 'wakoo_responsive_group', self::OPTION, [
			'type'              => 'string',
			'sanitize_callback' => function ( $v ) { return $v ? '1' : '0'; },
			'default'           => '1',
		] );
	}

	public static function page() {
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Optimizador responsive de Wakoo', 'wakoo' ); ?></h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'wakoo_responsive_group' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Optimización automática', 'wakoo' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>" value="1" <?php checked( self::enabled() ); ?>>
								<?php esc_html_e( 'Ajustar automáticamente todas las páginas en tablet y móvil', 'wakoo' ); ?>
							</label>
							<p class="description"><?php esc_html_e( 'Apila las columnas, hace fluidas las imágenes y vídeos, reduce el espaciado, limita los títulos muy grandes (sin pisar lo que ajustes a mano) y calma los efectos pesados. Funciona encima de los controles por dispositivo de Elementor.', 'wakoo' ); ?></p>
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}

Module::init();
