( function () {
	'use strict';
	var w = window, d = document;

	function bucket() { var x = w.innerWidth; return x < 768 ? 'mobile' : ( x < 1025 ? 'tablet' : 'desktop' ); }
	function docW() { return Math.max( d.documentElement.scrollWidth, d.body.scrollWidth, 1 ); }
	function docH() { return Math.max( d.documentElement.scrollHeight, d.body.scrollHeight, 1 ); }

	/** Grey-scale alpha blobs, then colourised with a blue→green→yellow→red gradient. */
	function paint( cv, pts, radius ) {
		var W = docW(), H = Math.min( docH(), 30000 );
		cv.width = W; cv.height = H;
		cv.style.width = W + 'px'; cv.style.height = H + 'px';
		var ctx = cv.getContext( '2d' ), max = 1;
		pts.forEach( function ( p ) { if ( p[ 2 ] > max ) { max = p[ 2 ]; } } );
		pts.forEach( function ( p ) {
			var x = p[ 0 ] / 10000 * W, y = p[ 1 ], a = Math.min( 1, 0.15 + 0.85 * p[ 2 ] / max );
			var g = ctx.createRadialGradient( x, y, 0, x, y, radius );
			g.addColorStop( 0, 'rgba(0,0,0,' + a + ')' ); g.addColorStop( 1, 'rgba(0,0,0,0)' );
			ctx.fillStyle = g; ctx.fillRect( x - radius, y - radius, radius * 2, radius * 2 );
		} );
		var lut = d.createElement( 'canvas' ); lut.width = 256; lut.height = 1;
		var lc = lut.getContext( '2d' ), lg = lc.createLinearGradient( 0, 0, 256, 0 );
		[ [ 0, 'rgba(0,0,255,0)' ], [ 0.2, 'rgba(0,120,255,.55)' ], [ 0.45, 'rgba(0,220,120,.7)' ], [ 0.7, 'rgba(255,230,0,.8)' ], [ 1, 'rgba(255,30,0,.9)' ] ].forEach( function ( s ) { lg.addColorStop( s[ 0 ], s[ 1 ] ); } );
		lc.fillStyle = lg; lc.fillRect( 0, 0, 256, 1 );
		var pal = lc.getImageData( 0, 0, 256, 1 ).data, img = ctx.getImageData( 0, 0, W, H ), px = img.data;
		for ( var i = 0; i < px.length; i += 4 ) {
			var al = px[ i + 3 ];
			if ( ! al ) { continue; }
			px[ i ] = pal[ al * 4 ]; px[ i + 1 ] = pal[ al * 4 + 1 ]; px[ i + 2 ] = pal[ al * 4 + 2 ]; px[ i + 3 ] = pal[ al * 4 + 3 ];
		}
		ctx.putImageData( img, 0, 0 );
	}

	WakooSuiteApi.define( 'heatmap', function ( root, cfg, S ) {
		var ctx = S.ctx( root ), B = d.body;
		if ( cfg.edit || B.classList.contains( 'elementor-editor-active' ) ) { return; }
		var admin = B.classList.contains( 'admin-bar' );

		/* ---- recording: not for admins, sampled, capped, sent in small batches ---- */
		var key = 'wks_hm_' + ctx.post, st = S.store.get( key ), sampled = null;
		if ( ! admin ) {
			sampled = S.store.get( key + '_s' );
			if ( null === sampled ) { sampled = Math.random() * 100 < cfg.sample ? '1' : '0'; S.store.set( key + '_s', sampled ); }
			if ( '1' === sampled && ! ( w.navigator.doNotTrack === '1' ) ) {
				var sent = parseInt( st || '0', 10 ) || 0, buf = [], timer = null;
				var flush = function () {
					if ( ! buf.length ) { return; }
					var pts = buf.splice( 0, 10 );
					S.api( 'heatmap/click', { data: { post: ctx.post, w: ctx.w, b: bucket(), pts: pts } } );
				};
				d.addEventListener( 'click', function ( e ) {
					if ( sent >= cfg.max ) { return; }
					sent++; S.store.set( key, String( sent ) );
					buf.push( [ Math.round( e.pageX / docW() * 10000 ), Math.round( e.pageY ) ] );
					if ( buf.length >= 5 ) { flush(); } else { clearTimeout( timer ); timer = setTimeout( flush, 2500 ); }
				}, { passive: true } );
				d.addEventListener( 'visibilitychange', function () { if ( 'hidden' === d.visibilityState ) { flush(); } } );
				w.addEventListener( 'pagehide', flush );
			}
		}

		/* ---- admin overlay ---- */
		if ( ! B.classList.contains( 'logged-in' ) ) { return; }
		var cv = null, panel = null, cur = bucket(), on = false;
		var btn = S.el( 'button', { type: 'button', 'class': 'wks-hm__btn', text: cfg.btn, 'aria-pressed': 'false' } );
		var info = S.el( 'span', { 'class': 'wks-hm__info', role: 'status' } );
		panel = S.el( 'div', { 'class': 'wks-hm__panel wks' }, [ btn, info ] );
		[ 'mobile', 'tablet', 'desktop' ].forEach( function ( b ) {
			var c = S.el( 'button', { type: 'button', 'class': 'wks-hm__b' + ( b === cur ? ' is-on' : '' ), 'data-b': b, text: cfg.l[ b ] } );
			c.addEventListener( 'click', function () { cur = b; panel.querySelectorAll( '.wks-hm__b' ).forEach( function ( x ) { x.classList.toggle( 'is-on', x === c ); } ); if ( on ) { load(); } } );
			panel.insertBefore( c, info );
		} );
		function load() {
			S.api( 'heatmap/data', { query: { post: ctx.post, b: cur }, auth: true } ).then( function ( r ) {
				if ( ! r.ok ) { panel.remove(); return; }
				if ( ! cv ) { cv = S.el( 'canvas', { 'class': 'wks-hm__cv', 'aria-hidden': 'true' } ); B.appendChild( cv ); }
				cv.hidden = false;
				paint( cv, r.pts, cfg.radius );
				info.textContent = r.total ? r.total + ' ' + cfg.l.clicks : cfg.l.none;
			} );
		}
		btn.addEventListener( 'click', function () {
			on = ! on;
			btn.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
			btn.textContent = on ? cfg.btn_off : cfg.btn;
			panel.classList.toggle( 'is-open', on );
			if ( on ) { load(); } else if ( cv ) { cv.hidden = true; info.textContent = ''; }
		} );
		B.appendChild( panel );
	} );
}() );
