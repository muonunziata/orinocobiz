( function () {
	'use strict';
	var d = document, w = window;

	/** Sends one page-view per page load (no cookies); skipped for DNT, bots and logged-in editors. */
	function hit( S ) {
		try {
			if ( w.__wksHit || w.navigator.doNotTrack === '1' || w.doNotTrack === '1' || w.navigator.webdriver ) { return; }
			if ( /bot|crawl|spider|slurp|headless/i.test( w.navigator.userAgent ) ) { return; }
			if ( d.body.classList.contains( 'admin-bar' ) || d.body.classList.contains( 'elementor-editor-active' ) ) { return; }
			w.__wksHit = 1;
			S.api( 'stats/hit', { data: { p: w.location.pathname } } );
		} catch ( e ) {}
	}

	WakooSuiteApi.define( 'stats', function ( root, cfg, S ) {
		var ctx = S.ctx( root ), items = root.querySelectorAll( '.wks-stats__item' ), reduced = S.reduced();
		hit( S );

		function fmt( v, dec ) {
			try { return v.toLocaleString( d.documentElement.lang || undefined, { minimumFractionDigits: dec, maximumFractionDigits: dec } ); } catch ( e ) { return v.toFixed( dec ); }
		}
		function run( it ) {
			var el = it.querySelector( '.wks-stats__n' ), to = parseFloat( it.getAttribute( 'data-to' ) ) || 0, dec = parseInt( it.getAttribute( 'data-dec' ), 10 ) || 0;
			if ( reduced || ! to ) { el.textContent = fmt( to, dec ); return; }
			var t0 = null;
			function step( t ) {
				if ( null === t0 ) { t0 = t; }
				var p = Math.min( 1, ( t - t0 ) / cfg.dur ), e = 1 - Math.pow( 1 - p, 3 );
				el.textContent = fmt( to * e, dec );
				if ( p < 1 ) { w.requestAnimationFrame( step ); } else { el.textContent = fmt( to, dec ); }
			}
			w.requestAnimationFrame( step );
		}
		function start() {
			var go = function () { items.forEach( run ); };
			if ( cfg.live ) {
				S.api( 'stats/values', { query: { post: ctx.post, w: ctx.w } } ).then( function ( r ) {
					if ( r && r.ok && r.values ) { items.forEach( function ( it ) { var v = r.values[ parseInt( it.getAttribute( 'data-i' ), 10 ) ]; if ( v !== undefined ) { it.setAttribute( 'data-to', v ); } } ); }
					go();
				} ).catch( go );
			} else { go(); }
		}
		items.forEach( function ( it ) { var el = it.querySelector( '.wks-stats__n' ); if ( ! reduced ) { el.textContent = fmt( 0, parseInt( it.getAttribute( 'data-dec' ), 10 ) || 0 ); } } );
		S.visible( root, start );
	} );
}() );
