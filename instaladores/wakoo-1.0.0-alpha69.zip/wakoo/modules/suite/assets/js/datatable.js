( function () {
	'use strict';
	function num( v ) {
		var n = parseFloat( String( v ).replace( /[^0-9.,\-]/g, '' ).replace( /,(?=\d{3}\b)/g, '' ).replace( ',', '.' ) );
		return isNaN( n ) ? null : n;
	}
	function cmp( a, b ) {
		var na = num( a ), nb = num( b );
		if ( na !== null && nb !== null && /\d/.test( a ) && /\d/.test( b ) ) { return na - nb; }
		var da = /^\d{4}-\d{2}-\d{2}/.test( a ) ? Date.parse( a ) : NaN, db = /^\d{4}-\d{2}-\d{2}/.test( b ) ? Date.parse( b ) : NaN;
		if ( ! isNaN( da ) && ! isNaN( db ) ) { return da - db; }
		return a.localeCompare( b, undefined, { numeric: true, sensitivity: 'base' } );
	}
	function csvCell( v ) { v = String( v ); if ( /^[=+\-@\t\r]/.test( v ) && isNaN( Number( v ) ) ) { v = "'" + v; } return /[",\n;]/.test( v ) ? '"' + v.replace( /"/g, '""' ) + '"' : v; }

	WakooSuiteApi.define( 'datatable', function ( root, cfg, S ) {
		var table = root.querySelector( 'table' ), tbody = table.tBodies[ 0 ];
		var head = table.tHead ? Array.prototype.map.call( table.tHead.rows[ 0 ].cells, function ( c ) { return c.textContent; } ) : [];
		var rows = Array.prototype.map.call( tbody.rows, function ( tr ) {
			return Array.prototype.map.call( tr.cells, function ( c ) { return c.textContent; } );
		} );
		var cols = rows.length ? rows[ 0 ].length : head.length;
		var state = { q: '', sort: -1, dir: 1, page: 0, f: {}, closed: {} };
		var search = root.querySelector( '.wks-dt__search' ), none = root.querySelector( '.wks-dt__none' ), pager = root.querySelector( '.wks-dt__pager' );
		var fbox = root.querySelector( '.wks-dt__filters' ), visible = [];

		( cfg.filters || [] ).forEach( function ( c ) {
			var idx = c - 1, vals = [];
			rows.forEach( function ( r ) { if ( r[ idx ] && vals.indexOf( r[ idx ] ) < 0 ) { vals.push( r[ idx ] ); } } );
			vals.sort( cmp );
			var sel = S.el( 'select', { 'aria-label': head[ idx ] || ( '#' + c ) }, [ S.el( 'option', { value: '', text: ( head[ idx ] || '' ) + ': ' + cfg.all } ) ].concat( vals.map( function ( v ) { return S.el( 'option', { value: v, text: v } ); } ) ) );
			sel.addEventListener( 'change', function () { state.f[ idx ] = sel.value; state.page = 0; render(); } );
			fbox.appendChild( sel );
		} );

		function filtered() {
			var q = state.q.toLowerCase();
			var out = rows.filter( function ( r ) {
				for ( var k in state.f ) { if ( state.f[ k ] && r[ k ] !== state.f[ k ] ) { return false; } }
				return ! q || r.join( ' ' ).toLowerCase().indexOf( q ) > -1;
			} );
			if ( state.sort > -1 ) { out.sort( function ( a, b ) { return state.dir * cmp( a[ state.sort ], b[ state.sort ] ); } ); }
			if ( cfg.group ) {
				var g = cfg.group - 1, order = [];
				out.forEach( function ( r ) { if ( order.indexOf( r[ g ] ) < 0 ) { order.push( r[ g ] ); } } );
				out.sort( function ( a, b ) { return order.indexOf( a[ g ] ) - order.indexOf( b[ g ] ); } );
			}
			return out;
		}

		function render() {
			visible = filtered();
			var size = cfg.page || 0, pages = size ? Math.max( 1, Math.ceil( visible.length / size ) ) : 1;
			state.page = Math.min( state.page, pages - 1 );
			var slice = size ? visible.slice( state.page * size, state.page * size + size ) : visible;
			tbody.textContent = '';
			var last = null;
			slice.forEach( function ( r ) {
				if ( cfg.group ) {
					var gv = r[ cfg.group - 1 ];
					if ( gv !== last ) {
						last = gv;
						var open = ! state.closed[ gv ];
						var btn = S.el( 'button', { type: 'button', class: 'wks-dt__gbtn', 'aria-expanded': open ? 'true' : 'false', text: ( open ? '▾ ' : '▸ ' ) + gv } );
						btn.addEventListener( 'click', function () { state.closed[ gv ] = open; render(); } );
						var td = S.el( 'td', { colspan: cols }, [ btn ] );
						tbody.appendChild( S.el( 'tr', { class: 'wks-dt__group' }, [ td ] ) );
					}
					if ( state.closed[ gv ] ) { return; }
				}
				tbody.appendChild( S.el( 'tr', {}, r.map( function ( c ) { return S.el( 'td', { text: c } ); } ) ) );
			} );
			none.hidden = visible.length > 0;
			pager.textContent = '';
			if ( pages > 1 ) {
				var prev = S.el( 'button', { type: 'button', class: 'wks-btn wks-btn--ghost', text: cfg.prev } ), next = S.el( 'button', { type: 'button', class: 'wks-btn wks-btn--ghost', text: cfg.next } );
				prev.disabled = state.page === 0; next.disabled = state.page >= pages - 1;
				prev.addEventListener( 'click', function () { state.page--; render(); } );
				next.addEventListener( 'click', function () { state.page++; render(); } );
				pager.appendChild( prev );
				pager.appendChild( S.el( 'span', { class: 'wks-dt__pageinfo', text: ( state.page + 1 ) + ' / ' + pages } ) );
				pager.appendChild( next );
			}
		}

		if ( search ) { search.addEventListener( 'input', function () { state.q = search.value.trim(); state.page = 0; render(); } ); }
		if ( table.tHead ) {
			Array.prototype.forEach.call( table.tHead.rows[ 0 ].cells, function ( th, i ) {
				th.querySelector( 'button' ).addEventListener( 'click', function () {
					state.dir = state.sort === i ? -state.dir : 1;
					state.sort = i;
					Array.prototype.forEach.call( table.tHead.rows[ 0 ].cells, function ( o, j ) { o.setAttribute( 'aria-sort', j === i ? ( state.dir > 0 ? 'ascending' : 'descending' ) : 'none' ); } );
					render();
				} );
			} );
		}
		var exp = root.querySelector( '.wks-dt__export' );
		if ( exp ) {
			exp.addEventListener( 'click', function () {
				var lines = [];
				if ( head.length ) { lines.push( head.map( csvCell ).join( ',' ) ); }
				visible.forEach( function ( r ) { lines.push( r.map( csvCell ).join( ',' ) ); } );
				var url = URL.createObjectURL( new Blob( [ '﻿' + lines.join( '\n' ) ], { type: 'text/csv;charset=utf-8' } ) );
				var a = S.el( 'a', { href: url, download: 'tabla.csv' } );
				document.body.appendChild( a ); a.click(); a.remove();
				setTimeout( function () { URL.revokeObjectURL( url ); }, 1000 );
			} );
		}
		render();
	} );
}() );
