/*! Wakoo Suite core: mount helper, REST helper, tiny DOM helpers. Original code (GPL-2.0-or-later). */
( function ( w, d ) {
	'use strict';
	var cfg = w.WakooSuite || { rest: '/wp-json/wakoo/v1/s/', nonce: '' };
	var Suite = w.WakooSuiteApi = {
		/** Registers the mount function of a widget; runs it on every .wks-<slug> root (also inside the Elementor editor). */
		define: function ( slug, fn ) {
			function boot( scope ) {
				( scope && scope.querySelectorAll ? scope : d ).querySelectorAll( '.wks-' + slug ).forEach( function ( root ) {
					if ( root.dataset.wksInit ) { return; }
					root.dataset.wksInit = '1';
					var conf = {};
					try { conf = JSON.parse( root.getAttribute( 'data-wks' ) || '{}' ); } catch ( e ) {}
					fn( root, conf, Suite );
				} );
			}
			if ( 'loading' === d.readyState ) { d.addEventListener( 'DOMContentLoaded', function () { boot( d ); } ); } else { boot( d ); }
			function hook() {
				if ( w.elementorFrontend && w.elementorFrontend.hooks ) {
					w.elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-' + slug + '.default', function ( $s ) {
						var el = $s[ 0 ];
						boot( el );
					} );
				}
			}
			if ( w.jQuery ) { w.jQuery( w ).on( 'elementor/frontend/init', hook ); }
		},
		/** fetch wrapper: api( 'poll/vote', { data: {...} } ) or api( 'x', { method: 'GET', query: {...}, auth: true } ). */
		api: function ( path, o ) {
			o = o || {};
			var method = o.method || ( o.data ? 'POST' : 'GET' );
			var url = cfg.rest + path;
			if ( o.query ) {
				var q = Object.keys( o.query ).map( function ( k ) { return encodeURIComponent( k ) + '=' + encodeURIComponent( o.query[ k ] ); } ).join( '&' );
				url += ( url.indexOf( '?' ) < 0 ? '?' : '&' ) + q;
			}
			var init = { method: method, credentials: o.auth ? 'same-origin' : 'omit', headers: {} };
			if ( o.auth ) { init.headers[ 'X-WP-Nonce' ] = cfg.nonce; }
			if ( o.data ) { init.headers[ 'Content-Type' ] = 'application/json'; init.body = JSON.stringify( o.data ); }
			return fetch( url, init ).then( function ( r ) { return r.json().catch( function () { return { ok: false, error: 'Error' }; } ); } );
		},
		/** el( 'div', { class: 'x', 'data-a': 1 }, [ child | 'text' ] ) */
		el: function ( tag, attrs, kids ) {
			var n = d.createElement( tag );
			Object.keys( attrs || {} ).forEach( function ( k ) {
				if ( attrs[ k ] === null || attrs[ k ] === undefined || attrs[ k ] === false ) { return; }
				if ( 'class' === k ) { n.className = attrs[ k ]; } else if ( 'text' === k ) { n.textContent = attrs[ k ]; } else { n.setAttribute( k, attrs[ k ] ); }
			} );
			( kids || [] ).forEach( function ( c ) { if ( c ) { n.appendChild( 'string' === typeof c ? d.createTextNode( c ) : c ); } } );
			return n;
		},
		/** localStorage that never throws. */
		store: {
			get: function ( k ) { try { return w.localStorage.getItem( k ); } catch ( e ) { return null; } },
			set: function ( k, v ) { try { w.localStorage.setItem( k, v ); } catch ( e ) {} }
		},
		reduced: function () { return w.matchMedia && w.matchMedia( '(prefers-reduced-motion: reduce)' ).matches; },
		/** Runs fn once when the root first becomes visible (lazy work). */
		visible: function ( root, fn ) {
			if ( ! ( 'IntersectionObserver' in w ) ) { fn(); return; }
			var io = new IntersectionObserver( function ( es ) {
				if ( es.some( function ( e ) { return e.isIntersecting; } ) ) { io.disconnect(); fn(); }
			}, { rootMargin: '120px' } );
			io.observe( root );
		},
		/** Context sent with every public request. */
		ctx: function ( root ) { return { post: parseInt( root.getAttribute( 'data-post' ), 10 ) || 0, w: root.getAttribute( 'data-w' ) || '' }; },
		mounted: Date.now()
	};
}( window, document ) );
