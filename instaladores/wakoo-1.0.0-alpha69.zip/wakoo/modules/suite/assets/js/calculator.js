( function () {
	'use strict';
	WakooSuiteApi.define( 'calculator', function ( root, cfg, S ) {
		var el = S.el, fieldsBox = root.querySelector( '.wks-calc__fields' ), totalBox = root.querySelector( '.wks-calc__total' ),
			sumBox = root.querySelector( '.wks-calc__sum' ), ctaBox = root.querySelector( '.wks-calc__cta' );
		var vals = cfg.fields.map( function ( f ) { return f.t === 'toggle' ? ( f.d ? 1 : 0 ) : f.t === 'select' ? Math.max( 0, Math.min( f.o.length - 1, Math.floor( f.d ) ) ) : Math.max( f.min, Math.min( f.max, f.d ) ); } );
		var outs = [];

		function money( n ) {
			var t = n.toLocaleString( undefined, { minimumFractionDigits: cfg.dec, maximumFractionDigits: cfg.dec } );
			return cfg.after ? t + ' ' + cfg.cur : cfg.cur + t;
		}
		function clamp( f, n ) { return isNaN( n ) ? f.min : Math.max( f.min, Math.min( f.max, n ) ); }

		var groups = {}, order = [];
		cfg.fields.forEach( function ( f, i ) {
			var g = f.g || '';
			if ( ! groups[ g ] ) {
				groups[ g ] = el( 'div', { class: 'wks-calc__group' }, g ? [ el( 'div', { class: 'wks-group-title', text: g } ) ] : [] );
				order.push( g );
			}
			var id = 'wks-c' + Math.random().toString( 36 ).slice( 2, 8 ) + i;
			var row = el( 'div', { class: 'wks-field wks-calc__row' } ), lab = el( 'label', { for: id, text: f.l } ), ctl, out = el( 'span', { class: 'wks-calc__val' } );
			if ( f.t === 'select' ) {
				ctl = el( 'select', { id: id } );
				f.o.forEach( function ( o, k ) { ctl.appendChild( el( 'option', { value: String( k ), text: o[ 0 ] + ( o[ 1 ] ? ' (+' + money( o[ 1 ] ) + ')' : '' ) } ) ); } );
				ctl.value = String( vals[ i ] );
				ctl.addEventListener( 'change', function () { vals[ i ] = parseInt( ctl.value, 10 ) || 0; update(); } );
			} else if ( f.t === 'toggle' ) {
				ctl = el( 'input', { id: id, type: 'checkbox' } );
				ctl.checked = !! vals[ i ];
				ctl.addEventListener( 'change', function () { vals[ i ] = ctl.checked ? 1 : 0; update(); } );
			} else {
				ctl = el( 'input', { id: id, type: f.t === 'slider' ? 'range' : 'number', min: String( f.min ), max: String( f.max ), step: String( f.st ) } );
				ctl.value = String( vals[ i ] );
				ctl.addEventListener( 'input', function () { vals[ i ] = clamp( f, parseFloat( ctl.value ) ); update(); } );
				ctl.addEventListener( 'change', function () { vals[ i ] = clamp( f, parseFloat( ctl.value ) ); if ( f.t === 'number' ) { ctl.value = String( vals[ i ] ); } update(); } );
			}
			row.appendChild( lab ); row.appendChild( ctl ); row.appendChild( out );
			groups[ g ].appendChild( row );
			outs[ i ] = out;
		} );
		order.forEach( function ( g ) { fieldsBox.appendChild( groups[ g ] ); } );

		function line( f, i ) {
			if ( f.t === 'toggle' ) { return vals[ i ] ? { t: f.l, c: f.p } : null; }
			if ( f.t === 'select' ) { var o = f.o[ vals[ i ] ]; return { t: f.l + ': ' + o[ 0 ], c: o[ 1 ] }; }
			return vals[ i ] ? { t: f.l + ': ' + vals[ i ] + ( f.u ? ' ' + f.u : '' ), c: vals[ i ] * f.p } : null;
		}
		function update() {
			var total = cfg.base, lines = [];
			cfg.fields.forEach( function ( f, i ) {
				outs[ i ].textContent = f.t === 'number' || f.t === 'slider' ? vals[ i ] + ( f.u ? ' ' + f.u : '' ) : '';
				var l = line( f, i );
				if ( l ) { total += l.c; lines.push( l ); }
			} );
			totalBox.textContent = '';
			totalBox.appendChild( el( 'span', { class: 'wks-calc__totlabel', text: cfg.totalTxt + ' ' } ) );
			totalBox.appendChild( el( 'strong', { text: money( total ) } ) );
			sumBox.textContent = '';
			if ( cfg.summary ) {
				if ( cfg.base ) { sumBox.appendChild( el( 'li', { text: money( cfg.base ) } ) ); }
				lines.forEach( function ( l ) { sumBox.appendChild( el( 'li', { text: l.t + ( l.c ? ' — ' + money( l.c ) : '' ) } ) ); } );
			}
			ctaBox.textContent = '';
			if ( cfg.url ) {
				var text = ( cfg.title ? cfg.title + '\n' : '' ) + lines.map( function ( l ) { return '- ' + l.t + ( l.c ? ' (' + money( l.c ) + ')' : '' ); } ).join( '\n' ) + '\n' + cfg.totalTxt + ': ' + money( total );
				var href = cfg.url, tail = '';
				if ( /^mailto:/i.test( href ) ) {
					href += ( href.indexOf( '?' ) < 0 ? '?' : '&' ) + 'subject=' + encodeURIComponent( cfg.title || cfg.cta ) + '&body=' + encodeURIComponent( text );
				} else {
					var h = href.indexOf( '#' ); if ( h > -1 ) { tail = href.slice( h ); href = href.slice( 0, h ); }
					href += ( href.indexOf( '?' ) < 0 ? '?' : '&' ) + encodeURIComponent( cfg.param ) + '=' + encodeURIComponent( text ) + tail;
				}
				var a = el( 'a', { class: 'wks-btn', href: href, text: cfg.cta } );
				if ( cfg.blank ) { a.target = '_blank'; a.rel = 'noopener noreferrer'; }
				ctaBox.appendChild( a );
			}
		}
		update();
	} );
}() );
