/*! Wakoo Suite · directory. Original code (GPL-2.0-or-later). Patterns only from public references (see CREDITS). */
( function () {
	'use strict';
	var D = document;

	/* ---------------------------------------------------------------- utils */
	function h( tag, attrs, kids ) {
		var n = D.createElement( tag );
		Object.keys( attrs || {} ).forEach( function ( k ) {
			var v = attrs[ k ];
			if ( null === v || undefined === v || false === v ) { return; }
			if ( 'class' === k ) { n.className = v; } else if ( 'text' === k ) { n.textContent = v; } else { n.setAttribute( k, true === v ? '' : v ); }
		} );
		( kids || [] ).forEach( function ( c ) { if ( c ) { n.appendChild( 'string' === typeof c ? D.createTextNode( c ) : c ); } } );
		return n;
	}
	function esc( s ) { return String( s ).replace( /[.*+?^${}()|[\]\\]/g, '\\$&' ); }
	function safe( u, mail ) {
		u = String( u || '' );
		return ( /^https?:\/\//i.test( u ) || ( mail && /^(mailto:|tel:)/i.test( u ) ) ) ? u : '';
	}
	function sig( n ) { return String( n || '' ).toLowerCase(); }
	function debounce( fn, ms ) { var t; return function () { var a = arguments, c = this; clearTimeout( t ); t = setTimeout( function () { fn.apply( c, a ); }, ms ); }; }

	/** Escribe `text` en `el` resaltando los términos con <mark> (solo nodos de texto, nunca HTML). */
	function marked( el, text, toks ) {
		el.textContent = '';
		text = String( text || '' );
		if ( ! toks || ! toks.length ) { el.appendChild( D.createTextNode( text ) ); return el; }
		var re = new RegExp( '(' + toks.map( esc ).join( '|' ) + ')', 'ig' ), last = 0, m;
		while ( ( m = re.exec( text ) ) ) {
			if ( ! m[ 0 ].length ) { re.lastIndex++; continue; }
			if ( m.index > last ) { el.appendChild( D.createTextNode( text.slice( last, m.index ) ) ); }
			el.appendChild( h( 'mark', { text: m[ 0 ] } ) );
			last = m.index + m[ 0 ].length;
		}
		if ( last < text.length ) { el.appendChild( D.createTextNode( text.slice( last ) ) ); }
		return el;
	}

	/* ------------------------------------------------ abierto ahora (mismo criterio que el PHP) */
	function nowIn( tz ) {
		var dow, min, d = new Date();
		try {
			if ( tz ) {
				var p = new Intl.DateTimeFormat( 'en-US', { timeZone: tz, weekday: 'short', hour: 'numeric', minute: 'numeric', hourCycle: 'h23' } ).formatToParts( d ), o = {};
				p.forEach( function ( x ) { o[ x.type ] = x.value; } );
				dow = [ 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun' ].indexOf( o.weekday );
				min = ( parseInt( o.hour, 10 ) % 24 ) * 60 + parseInt( o.minute, 10 );
			}
		} catch ( e ) { dow = -1; }
		if ( undefined === dow || dow < 0 ) { dow = ( d.getDay() + 6 ) % 7; min = d.getHours() * 60 + d.getMinutes(); }
		return [ dow, min ];
	}
	function isOpen( segs, now ) {
		var d = now[ 0 ], m = now[ 1 ];
		for ( var i = 0; i < ( segs || [] ).length; i++ ) {
			var g = segs[ i ], mask = g[ 0 ], a = g[ 1 ], b = g[ 2 ];
			if ( b > a ) { if ( ( mask >> d & 1 ) && m >= a && m < b ) { return true; } }
			else {
				if ( ( mask >> d & 1 ) && m >= a ) { return true; }
				if ( ( mask >> ( ( d + 6 ) % 7 ) & 1 ) && m < b ) { return true; }
			}
		}
		return false;
	}

	/* ---------------------------------------------------------------- modal (una sola para toda la página) */
	var M = { el: null, box: null, body: null, x: null, opener: null, gal: null };

	function buildModal( T ) {
		M.el = h( 'div', { class: 'wks wks-dir-modal', hidden: true } );
		M.box = h( 'div', { class: 'wks-dir-modal__box', role: 'dialog', 'aria-modal': 'true', tabindex: '-1' } );
		M.x = h( 'button', { type: 'button', class: 'wks-dir-modal__x', 'aria-label': T.close || 'Close', text: '×' } );
		M.body = h( 'div' );
		M.box.appendChild( M.x ); M.box.appendChild( M.body ); M.el.appendChild( M.box );
		D.body.appendChild( M.el );
		M.x.addEventListener( 'click', closeModal );
		M.el.addEventListener( 'mousedown', function ( e ) { if ( e.target === M.el ) { closeModal(); } } );
		M.el.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key ) { e.preventDefault(); closeModal(); return; }
			if ( M.gal && ( 'ArrowLeft' === e.key || 'ArrowRight' === e.key ) ) { M.gal( 'ArrowLeft' === e.key ? -1 : 1 ); e.preventDefault(); return; }
			if ( 'Tab' !== e.key ) { return; }
			var f = [].slice.call( M.box.querySelectorAll( 'a[href],button:not([disabled])' ) );
			if ( ! f.length ) { e.preventDefault(); return; }
			var first = f[ 0 ], last = f[ f.length - 1 ], a = D.activeElement;
			if ( e.shiftKey && ( a === first || a === M.box ) ) { last.focus(); e.preventDefault(); }
			else if ( ! e.shiftKey && a === last ) { first.focus(); e.preventDefault(); }
			else if ( ! M.box.contains( a ) ) { first.focus(); e.preventDefault(); }
		} );
	}

	function stars( r ) { var n = Math.round( Math.max( 0, Math.min( 5, r ) ) ); return new Array( n + 1 ).join( '★' ) + new Array( 6 - n ).join( '☆' ); }

	function fillModal( C, b, now ) {
		var T = C.t, cat = C.cats[ b.k ] || { n: '', c: '#2E7D55' }, body = M.body, ini = '';
		body.textContent = '';
		( b.n || '' ).split( /\s+/ ).slice( 0, 2 ).forEach( function ( w ) { ini += w.charAt( 0 ).toUpperCase(); } );
		function logo() { return h( 'span', { class: 'wks-dir__logo', style: '--dot:' + cat.c }, [ safe( b.lg ) ? h( 'img', { src: safe( b.lg ), alt: '', decoding: 'async' } ) : ini ] ); }

		// Galería con miniaturas.
		var photos = ( b.ph || [] ).map( function ( u ) { return safe( u ); } ).filter( Boolean ), gi = 0, slides = [], thumbs = [], cnt = null;
		M.gal = null;
		if ( photos.length ) {
			var main = h( 'div', { class: 'wks-dir__main' } );
			photos.forEach( function ( u, i ) { var im = h( 'img', { class: 'wks-dir__slide' + ( 0 === i ? ' is-on' : '' ), src: u, alt: b.n, decoding: 'async' } ); if ( i ) { im.loading = 'lazy'; } slides.push( im ); main.appendChild( im ); } );
			var gal = h( 'div', { class: 'wks-dir__gal' }, [ main ] );
			var go = function ( d, abs ) {
				gi = abs ? d : ( gi + d + photos.length ) % photos.length;
				slides.forEach( function ( s, k ) { s.classList.toggle( 'is-on', k === gi ); } );
				thumbs.forEach( function ( t, k ) { t.classList.toggle( 'is-on', k === gi ); t.setAttribute( 'aria-current', k === gi ? 'true' : 'false' ); } );
				if ( cnt ) { cnt.textContent = ( gi + 1 ) + ' / ' + photos.length; }
			};
			if ( photos.length > 1 ) {
				var pv = h( 'button', { type: 'button', class: 'wks-dir__arrow', 'data-d': '-1', 'aria-label': T.prev || '', text: '‹' } );
				var nx = h( 'button', { type: 'button', class: 'wks-dir__arrow', 'data-d': '1', 'aria-label': T.next || '', text: '›' } );
				pv.addEventListener( 'click', function () { go( -1 ); } ); nx.addEventListener( 'click', function () { go( 1 ); } );
				cnt = h( 'span', { class: 'wks-dir__counter', 'aria-hidden': 'true', text: '1 / ' + photos.length } );
				main.appendChild( pv ); main.appendChild( nx ); main.appendChild( cnt );
				var strip = h( 'div', { class: 'wks-dir__thumbs' } );
				photos.forEach( function ( u, i ) {
					var tb = h( 'button', { type: 'button', class: 'wks-dir__thumb' + ( 0 === i ? ' is-on' : '' ), 'aria-label': ( T.photo || '' ) + ' ' + ( i + 1 ), 'aria-current': 0 === i ? 'true' : 'false' }, [ h( 'img', { src: u, alt: '', loading: 'lazy', decoding: 'async' } ) ] );
					tb.addEventListener( 'click', function () { go( i, true ); } );
					thumbs.push( tb ); strip.appendChild( tb );
				} );
				gal.appendChild( strip );
				M.gal = go;
			}
			body.appendChild( gal );
		}

		var info = h( 'div', { class: 'wks-dir__info' } ), meta = h( 'p', { class: 'wks-dir__meta' } ), pname = h( 'h3', { class: 'wks-dir__pname', text: b.n } );
		pname.id = 'wks-dm-' + Math.random().toString( 36 ).slice( 2, 8 );
		M.box.setAttribute( 'aria-labelledby', pname.id );
		meta.appendChild( h( 'span', { class: 'wks-dir__cat', style: '--dot:' + cat.c }, [ h( 'i', { 'aria-hidden': 'true' } ), cat.n ] ) );
		if ( b.ra > 0 ) {
			meta.appendChild( h( 'span', { class: 'wks-stars', 'aria-label': b.ra + ' / 5', text: stars( b.ra ) } ) );
			meta.appendChild( h( 'span', { text: b.ra + ( b.rv ? ' (' + b.rv + ')' : '' ) } ) );
		}
		if ( b.ft ) { meta.appendChild( h( 'span', { class: 'wks-dir__badge', text: T.lbl_found } ) ); }
		if ( b.oh && b.oh.length ) { var op = isOpen( b.oh, now ); meta.appendChild( h( 'span', { class: 'wks-dir__state ' + ( op ? 'is-open' : 'is-closed' ), text: op ? T.lbl_is_open : T.lbl_is_closed } ) ); }
		info.appendChild( h( 'div', { class: 'wks-dir__head' }, [ logo(), h( 'div', {}, [ pname, meta ] ) ] ) );
		if ( b.de ) { info.appendChild( h( 'p', { class: 'wks-dir__desc', text: b.de } ) ); }

		var acts = h( 'div', { class: 'wks-dir__actions' } );
		function btn( href, label, ghost, ext ) { if ( href ) { acts.appendChild( h( 'a', { class: 'wks-btn' + ( ghost ? ' wks-btn--ghost' : '' ), href: href, target: ext ? '_blank' : null, rel: ext ? 'noopener noreferrer' : null, text: label } ) ); } }
		if ( C.maps ) {
			var q = encodeURIComponent( b.ad || b.n );
			btn( safe( b.mp ) || 'https://www.google.com/maps/search/?api=1&query=' + q, T.lbl_maps, false, true );
			btn( 'https://www.google.com/maps/dir/?api=1&destination=' + q, T.lbl_dir, true, true );
		}
		if ( b.tl ) { btn( 'tel:' + String( b.tl ).replace( /[^+\d]/g, '' ), T.lbl_call, true ); }
		if ( b.em ) { btn( 'mailto:' + b.em, T.lbl_email, true ); }
		if ( safe( b.wb ) ) { btn( safe( b.wb ), T.lbl_web, true, true ); }
		if ( acts.children.length ) { info.appendChild( acts ); }

		var dl = h( 'dl', { class: 'wks-dir__dl' } );
		function row( k, v ) { if ( v ) { dl.appendChild( h( 'div', {}, [ h( 'dt', { text: k } ), h( 'dd', {}, [ v ] ) ] ) ); } }
		row( T.lbl_address, b.ad ); row( T.lbl_phone, b.tl );
		row( T.lbl_email, b.em ? h( 'a', { href: 'mailto:' + b.em, text: b.em } ) : '' );
		if ( b.hr && b.hr.length ) {
			var hr = h( 'span', { class: 'wks-dir__hours' } );
			b.hr.forEach( function ( x ) { hr.appendChild( h( 'span', { text: x[ 0 ] } ) ); hr.appendChild( h( 'span', { text: x[ 1 ] } ) ); } );
			row( T.lbl_hours, hr );
		}
		if ( dl.children.length ) { info.appendChild( dl ); }
		if ( b.tg && b.tg.length ) { var tg = h( 'p', { class: 'wks-dir__tags' } ); b.tg.forEach( function ( t ) { tg.appendChild( h( 'span', { text: t } ) ); } ); info.appendChild( tg ); }
		if ( b.so && b.so.length ) {
			var so = h( 'p', { class: 'wks-dir__social' } );
			b.so.forEach( function ( x ) { var u = safe( x[ 1 ] ); if ( u ) { so.appendChild( h( 'a', { href: u, target: '_blank', rel: 'noopener noreferrer nofollow', text: x[ 0 ] } ) ); so.appendChild( D.createTextNode( ' ' ) ); } } );
			info.appendChild( so );
		}
		if ( T.sample_note ) { info.appendChild( h( 'p', { class: 'wks-dir__note', text: T.sample_note } ) ); }
		body.appendChild( info );
	}

	function openModal( C, b, now, btn ) {
		if ( ! M.el ) { buildModal( C.t ); }
		fillModal( C, b, now );
		M.opener = btn;
		M.el.hidden = false;
		D.documentElement.classList.add( 'wks-dir-lock' );
		M.x.focus();
	}
	function closeModal() {
		if ( ! M.el || M.el.hidden ) { return; }
		M.el.hidden = true; M.gal = null;
		D.documentElement.classList.remove( 'wks-dir-lock' );
		if ( M.opener && D.body.contains( M.opener ) ) { M.opener.focus(); }
	}

	/* ---------------------------------------------------------------- widget */
	WakooSuiteApi.define( 'directory', function ( root, C, Suite ) {
		var T = C.t || {}, ctx = Suite.ctx( root ), data = { items: [] };
		try { data = JSON.parse( root.querySelector( '.wks-dir__data' ).textContent ) || data; } catch ( e ) {}
		var rest = 'rest' === C.mode, all = rest ? [] : data.items, cats = C.cats || [];
		var input = root.querySelector( '.wks-dir__search input' ), clear = root.querySelector( '.wks-dir__clear' );
		var facetsBox = root.querySelector( '.wks-dir__facets' ), list = root.querySelector( '.wks-dir__list' ), pager = root.querySelector( '.wks-dir__pager' );
		var none = root.querySelector( '.wks-dir__none' ), status = root.querySelector( '.wks-dir__status' ), reset = root.querySelector( '.wks-dir__reset' );
		var st = { q: '', cat: '', tags: [], area: '', open: false, sort: C.sort || 'original', view: C.view || 'grid', page: 1 };
		var seq = 0, cache = {}, now = nowIn( C.tz ), shownItems = [], ui = {};

		/* --- URL --- */
		function readUrl() {
			if ( ! C.url ) { return; }
			var p = new URLSearchParams( location.search );
			st.q = ( p.get( 'q' ) || '' ).slice( 0, 100 ); st.cat = /^\d+$/.test( p.get( 'cat' ) || '' ) ? p.get( 'cat' ) : '';
			st.tags = ( p.get( 'tag' ) || '' ).split( '|' ).filter( Boolean ).slice( 0, 6 ); st.area = ( p.get( 'area' ) || '' ).slice( 0, 80 );
			st.open = '1' === p.get( 'open' );
			if ( [ 'original', 'az', 'za', 'rating', 'reviews', 'featured' ].indexOf( p.get( 'sort' ) ) > -1 ) { st.sort = p.get( 'sort' ); }
			if ( [ 'grid', 'list' ].indexOf( p.get( 'view' ) ) > -1 ) { st.view = p.get( 'view' ); }
			st.page = Math.max( 1, parseInt( p.get( 'p' ), 10 ) || 1 );
			input.value = st.q;
		}
		function writeUrl() {
			if ( ! C.url || ! history.replaceState ) { return; }
			var p = new URLSearchParams( location.search );
			[ 'q', 'cat', 'tag', 'area', 'open', 'sort', 'view', 'p' ].forEach( function ( k ) { p.delete( k ); } );
			if ( st.q ) { p.set( 'q', st.q ); }
			if ( '' !== st.cat ) { p.set( 'cat', st.cat ); }
			if ( st.tags.length ) { p.set( 'tag', st.tags.join( '|' ) ); }
			if ( st.area ) { p.set( 'area', st.area ); }
			if ( st.open ) { p.set( 'open', '1' ); }
			if ( st.sort !== ( C.sort || 'original' ) ) { p.set( 'sort', st.sort ); }
			if ( st.view !== ( C.view || 'grid' ) ) { p.set( 'view', st.view ); }
			if ( st.page > 1 && 'pages' === C.pager ) { p.set( 'p', st.page ); }
			var qs = p.toString();
			history.replaceState( null, '', location.pathname + ( qs ? '?' + qs : '' ) + location.hash );
		}

		/* --- consulta local (modo en página) --- */
		all.forEach( function ( b ) { b._h = sig( [ b.n, b.ty, b.ar, ( cats[ b.k ] || {} ).n, ( b.tg || [] ).join( ' ' ), b.ad ].join( ' ' ) ); } );
		function toks() { return sig( st.q ).split( /\s+/ ).filter( Boolean ).slice( 0, 8 ); }
		function match( b, tk, skip ) {
			if ( 'cat' !== skip && '' !== st.cat && parseInt( st.cat, 10 ) !== b.k ) { return false; }
			if ( 'area' !== skip && st.area && sig( st.area ) !== sig( b.ar ) ) { return false; }
			if ( 'tag' !== skip && st.tags.length ) { var mine = ( b.tg || [] ).map( sig ); for ( var i = 0; i < st.tags.length; i++ ) { if ( mine.indexOf( sig( st.tags[ i ] ) ) < 0 ) { return false; } } }
			if ( 'open' !== skip && st.open && ! isOpen( b.oh, now ) ) { return false; }
			for ( var j = 0; j < tk.length; j++ ) { if ( b._h.indexOf( tk[ j ] ) < 0 ) { return false; } }
			return true;
		}
		function score( b, tk ) {
			var n = sig( b.n ), s = 0;
			tk.forEach( function ( t ) { if ( 0 === n.indexOf( t ) ) { s += 3; } else if ( n.indexOf( t ) > -1 ) { s += 2; } else if ( sig( b.ty ).indexOf( t ) > -1 ) { s += 1; } } );
			return s;
		}
		function sorter( tk ) {
			var by = {
				az: function ( a, b ) { return a.n.localeCompare( b.n ); }, za: function ( a, b ) { return b.n.localeCompare( a.n ); },
				rating: function ( a, b ) { return ( b.ra - a.ra ) || ( b.rv - a.rv ); }, reviews: function ( a, b ) { return b.rv - a.rv; }, featured: function ( a, b ) { return b.ft - a.ft; }
			};
			if ( 'original' === st.sort && tk.length ) { return function ( a, b ) { return ( score( b, tk ) - score( a, tk ) ) || ( a.i - b.i ); }; }
			var c = by[ st.sort ];
			return function ( a, b ) { return ( c ? c( a, b ) : 0 ) || ( a.i - b.i ); };
		}
		function top( o, n ) { return Object.keys( o ).map( function ( k ) { return [ k, o[ k ] ]; } ).sort( function ( a, b ) { return b[ 1 ] - a[ 1 ]; } ).slice( 0, n ); }
		function localQuery() {
			var tk = toks(), res = all.filter( function ( b ) { return match( b, tk, '' ); } ), fc = { cats: {}, tags: [], areas: [], open: 0 }, tg = {}, ar = {};
			all.forEach( function ( b ) {
				if ( match( b, tk, 'cat' ) ) { fc.cats[ b.k ] = ( fc.cats[ b.k ] || 0 ) + 1; }
				if ( b.ar && match( b, tk, 'area' ) ) { ar[ b.ar ] = ( ar[ b.ar ] || 0 ) + 1; }
				if ( b.tg && b.tg.length && match( b, tk, 'tag' ) ) { b.tg.forEach( function ( t ) { tg[ t ] = ( tg[ t ] || 0 ) + 1; } ); }
				if ( b.oh && b.oh.length && match( b, tk, 'open' ) && isOpen( b.oh, now ) ) { fc.open++; }
			} );
			fc.tags = top( tg, 24 ); fc.areas = top( ar, 60 );
			res.sort( sorter( tk ) );
			return { total: res.length, items: res, facets: fc };
		}

		/* --- controles (se construyen una vez) --- */
		function buildControls() {
			ui.cats = h( 'div', { class: 'wks-dir__chips', role: 'group', 'aria-label': T.all_label } );
			ui.catBtns = [];
			function chip( k, label, dot ) {
				var b = h( 'button', { type: 'button', class: 'wks-chip', 'data-k': k, 'aria-pressed': 'false', style: dot ? '--dot:' + dot : null }, [ dot ? h( 'i', { 'aria-hidden': 'true' } ) : null, label + ' ', h( 'small' ) ] );
				b.addEventListener( 'click', function () { st.cat = k; st.page = 1; run(); } );
				ui.catBtns.push( b ); ui.cats.appendChild( b );
			}
			chip( '', T.all_label );
			cats.forEach( function ( c, i ) { chip( String( i ), c.n, c.c ); } );
			facetsBox.appendChild( ui.cats );

			var bar = h( 'div', { class: 'wks-dir__tools' } );
			if ( C.areas ) {
				ui.area = h( 'select', { class: 'wks-dir__select', 'aria-label': T.lbl_area } );
				ui.area.addEventListener( 'change', function () { st.area = ui.area.value; st.page = 1; run(); } );
				ui.areaWrap = h( 'span', { class: 'wks-dir__tool' }, [ ui.area ] );
				bar.appendChild( ui.areaWrap );
			}
			if ( C.open ) {
				ui.open = h( 'button', { type: 'button', class: 'wks-chip wks-dir__open-now', 'aria-pressed': 'false' }, [ h( 'i', { 'aria-hidden': 'true' } ), T.lbl_open_now + ' ', h( 'small' ) ] );
				ui.open.addEventListener( 'click', function () { st.open = ! st.open; st.page = 1; run(); } );
				bar.appendChild( ui.open );
			}
			if ( C.sortUi ) {
				ui.sort = h( 'select', { class: 'wks-dir__select', 'aria-label': T.lbl_sort } );
				[ [ 'original', T.lbl_s_original ], [ 'az', T.lbl_s_az ], [ 'za', T.lbl_s_za ], [ 'rating', T.lbl_s_rating ], [ 'reviews', T.lbl_s_reviews ], [ 'featured', T.lbl_featured_only ] ].forEach( function ( o ) { ui.sort.appendChild( h( 'option', { value: o[ 0 ], text: o[ 1 ] } ) ); } );
				ui.sort.addEventListener( 'change', function () { st.sort = ui.sort.value; st.page = 1; run(); } );
				bar.appendChild( h( 'span', { class: 'wks-dir__tool' }, [ ui.sort ] ) );
			}
			if ( C.viewUi ) {
				ui.views = h( 'span', { class: 'wks-dir__views', role: 'group' } );
				[ [ 'grid', T.lbl_view_grid, '▦' ], [ 'list', T.lbl_view_list, '☰' ] ].forEach( function ( v ) {
					var b = h( 'button', { type: 'button', class: 'wks-dir__view', 'data-v': v[ 0 ], 'aria-label': v[ 1 ], title: v[ 1 ], 'aria-pressed': 'false', text: v[ 2 ] } );
					b.addEventListener( 'click', function () { st.view = v[ 0 ]; list.classList.toggle( 'is-list', 'list' === st.view ); updateViews(); writeUrl(); } );
					ui.views.appendChild( b );
				} );
				bar.appendChild( ui.views );
			}
			if ( C.mapBtn ) { ui.map = h( 'a', { class: 'wks-btn wks-btn--ghost wks-dir__mapbtn', href: '#', target: '_blank', rel: 'noopener noreferrer', text: T.lbl_map_btn } ); bar.appendChild( ui.map ); }
			if ( bar.children.length ) { facetsBox.appendChild( bar ); }
			if ( C.tags ) { ui.tags = h( 'div', { class: 'wks-dir__tagrow', role: 'group', 'aria-label': T.lbl_tags } ); facetsBox.appendChild( ui.tags ); }
		}
		function updateViews() { if ( ui.views ) { [].forEach.call( ui.views.children, function ( b ) { var on = b.getAttribute( 'data-v' ) === st.view; b.classList.toggle( 'is-active', on ); b.setAttribute( 'aria-pressed', on ? 'true' : 'false' ); } ); } }

		function updateFacets( fc ) {
			ui.catBtns.forEach( function ( b ) {
				var k = b.getAttribute( 'data-k' ), n = '' === k ? Object.keys( fc.cats ).reduce( function ( s, x ) { return s + fc.cats[ x ]; }, 0 ) : ( fc.cats[ k ] || 0 ), on = k === st.cat;
				b.querySelector( 'small' ).textContent = n;
				b.classList.toggle( 'is-active', on ); b.classList.toggle( 'is-empty', ! n && ! on ); b.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
			} );
			if ( ui.area && D.activeElement !== ui.area ) {
				var cur = st.area, seen = false;
				ui.area.textContent = '';
				ui.area.appendChild( h( 'option', { value: '', text: T.lbl_all_areas } ) );
				( fc.areas || [] ).forEach( function ( a ) { if ( a[ 0 ] === cur ) { seen = true; } ui.area.appendChild( h( 'option', { value: a[ 0 ], text: a[ 0 ] + ' (' + a[ 1 ] + ')' } ) ); } );
				if ( cur && ! seen ) { ui.area.appendChild( h( 'option', { value: cur, text: cur } ) ); }
				ui.area.value = cur;
				ui.areaWrap.hidden = ! ( fc.areas && fc.areas.length ) && ! cur;
			}
			if ( ui.open ) { ui.open.classList.toggle( 'is-active', st.open ); ui.open.setAttribute( 'aria-pressed', st.open ? 'true' : 'false' ); ui.open.querySelector( 'small' ).textContent = fc.open || 0; }
			if ( ui.sort ) { ui.sort.value = st.sort; }
			updateViews();
			if ( ui.tags ) {
				var had = D.activeElement && ui.tags.contains( D.activeElement ) ? D.activeElement.getAttribute( 'data-t' ) : null, l2 = ( fc.tags || [] ).slice( 0, 16 );
				st.tags.forEach( function ( t ) { if ( ! l2.some( function ( x ) { return x[ 0 ] === t; } ) ) { l2.unshift( [ t, 0 ] ); } } );
				ui.tags.textContent = '';
				l2.forEach( function ( x ) {
					var on = st.tags.indexOf( x[ 0 ] ) > -1;
					var b = h( 'button', { type: 'button', class: 'wks-dir__tag' + ( on ? ' is-active' : '' ), 'data-t': x[ 0 ], 'aria-pressed': on ? 'true' : 'false' }, [ '#' + x[ 0 ] + ' ', h( 'small', { text: x[ 1 ] } ) ] );
					b.addEventListener( 'click', function () { var i = st.tags.indexOf( x[ 0 ] ); if ( i > -1 ) { st.tags.splice( i, 1 ); } else if ( st.tags.length < 6 ) { st.tags.push( x[ 0 ] ); } st.page = 1; run(); } );
					ui.tags.appendChild( b );
				} );
				ui.tags.hidden = ! l2.length;
				if ( null !== had ) { var again = [].filter.call( ui.tags.children, function ( c ) { return c.getAttribute( 'data-t' ) === had; } )[ 0 ]; if ( again ) { again.focus(); } }
			}
		}

		/* --- tarjetas --- */
		function card( b ) {
			var c = cats[ b.k ] || { n: '', c: '#2E7D55' }, tk = toks(), ini = '', op = null;
			( b.n || '' ).split( /\s+/ ).slice( 0, 2 ).forEach( function ( w ) { ini += w.charAt( 0 ).toUpperCase(); } );
			if ( b.oh && b.oh.length ) { op = isOpen( b.oh, now ); }
			var txt = h( 'span', { class: 'wks-dir__txt' } );
			txt.appendChild( marked( h( 'strong', { class: 'wks-dir__nm' } ), b.n, tk ) );
			if ( b.ty ) { txt.appendChild( marked( h( 'em', { class: 'wks-dir__ty' } ), b.ty, tk ) ); }
			var meta = h( 'small', { class: 'wks-dir__ar' } );
			if ( b.ar ) { meta.appendChild( marked( h( 'span' ), b.ar, tk ) ); }
			if ( b.ra > 0 ) { meta.appendChild( h( 'span', { class: 'wks-stars', 'aria-label': b.ra + ' / 5', text: '★ ' + b.ra } ) ); }
			if ( meta.children.length ) { txt.appendChild( meta ); }
			var tags = h( 'span', { class: 'wks-dir__chiprow' } );
			if ( b.ft ) { tags.appendChild( h( 'span', { class: 'wks-dir__badge', text: T.lbl_found } ) ); }
			if ( null !== op ) { tags.appendChild( h( 'span', { class: 'wks-dir__state ' + ( op ? 'is-open' : 'is-closed' ), text: op ? T.lbl_is_open : T.lbl_is_closed } ) ); }
			if ( tags.children.length ) { txt.appendChild( tags ); }
			var btn = h( 'button', { type: 'button', class: 'wks-dir__open', 'aria-haspopup': 'dialog' }, [
				h( 'span', { class: 'wks-sr', text: ( T.lbl_open || '' ) + ': ' } ),
				h( 'span', { class: 'wks-dir__logo', style: '--dot:' + c.c }, [ safe( b.lg ) ? h( 'img', { src: safe( b.lg ), alt: '', loading: 'lazy', decoding: 'async' } ) : ini ] ),
				txt
			] );
			btn.addEventListener( 'click', function () { openModal( C, b, now, btn ); } );
			return h( 'article', { class: 'wks-dir__card wks-card' + ( b.ft ? ' is-featured' : '' ), style: '--dot:' + c.c }, [ btn ] );
		}

		/* --- pintado --- */
		function paint( res, append ) {
			var total = res.total;
			list.classList.toggle( 'is-list', 'list' === st.view );
			if ( ! append ) { list.textContent = ''; shownItems = []; }
			var grid = list.querySelector( '.wks-dir__grid' );
			if ( ! grid ) { grid = h( 'div', { class: 'wks-dir__grid' } ); list.appendChild( grid ); }
			res.items.forEach( function ( b ) { grid.appendChild( card( b ) ); shownItems.push( b ); } );
			var filtered = !! ( st.q || '' !== st.cat || st.tags.length || st.area || st.open );
			list.hidden = ( ! filtered && ! C.showAll ) || ! total;
			none.hidden = ! filtered || !! total;
			status.textContent = ( filtered || C.showAll ) ? String( T.count || '{n}' ).replace( '{n}', total ) : '';
			reset.hidden = ! filtered; reset.textContent = T.lbl_reset || '';
			clear.hidden = ! input.value;
			updateFacets( res.facets );
			pager.textContent = '';
			var per = C.per || 12, pages = Math.max( 1, Math.ceil( total / per ) );
			if ( ! list.hidden && pages > 1 ) {
				if ( 'pages' === C.pager ) {
					var nav = h( 'nav', { class: 'wks-dir__pages', 'aria-label': String( T.lbl_page || 'Pages' ).replace( '{n}', '' ).trim() || 'Pages' } );
					for ( var p = 1; p <= pages && p <= 40; p++ ) {
						( function ( n ) {
							var b = h( 'button', { type: 'button', class: 'wks-dir__pg' + ( n === st.page ? ' is-active' : '' ), 'aria-label': String( T.lbl_page || '{n}' ).replace( '{n}', n ), 'aria-current': n === st.page ? 'page' : null, text: String( n ) } );
							b.addEventListener( 'click', function () { st.page = n; run( true ); } );
							nav.appendChild( b );
						}( p ) );
					}
					pager.appendChild( nav );
				} else if ( shownItems.length < total ) {
					var more = h( 'button', { type: 'button', class: 'wks-btn wks-btn--ghost wks-dir__more', text: T.lbl_more } );
					more.addEventListener( 'click', function () { st.page += 1; run( false, true ); } );
					pager.appendChild( more );
				}
			}
			if ( ui.map ) {
				var term = st.q || ( '' !== st.cat && cats[ st.cat ] ? cats[ st.cat ].n : '' ) || st.area || '';
				ui.map.href = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent( ( term + ' ' + ( C.locality || '' ) ).trim() || 'map' );
			}
			root.removeAttribute( 'aria-busy' );
			root.classList.remove( 'is-loading' );
			writeUrl();
		}

		/* --- ejecución --- */
		function key() { return [ st.q, st.cat, st.tags.join( '|' ), st.area, st.open ? 1 : 0, st.sort, st.page ].join( '~' ); }
		function toTop() { if ( root.scrollIntoView ) { root.scrollIntoView( { behavior: Suite.reduced() ? 'auto' : 'smooth', block: 'start' } ); } }
		/** scrollTop: subir al directorio tras cambiar de página; append: añadir la página siguiente («cargar más»). */
		function run( scrollTop, append ) {
			st.q = input.value.trim();
			var per = C.per || 12, focusMore = !! append;
			if ( rest ) { return runRest( scrollTop, append ); }
			var res = localQuery();
			if ( 'pages' === C.pager ) {
				st.page = Math.min( st.page, Math.max( 1, Math.ceil( res.total / per ) ) );
				paint( { items: res.items.slice( ( st.page - 1 ) * per, st.page * per ), total: res.total, facets: res.facets }, false );
			} else if ( append ) {
				var from = shownItems.length;
				paint( { items: res.items.slice( from, from + per ), total: res.total, facets: res.facets }, true );
			} else {
				st.page = 1;
				paint( { items: res.items.slice( 0, per ), total: res.total, facets: res.facets }, false );
			}
			if ( focusMore ) { var nb = pager.querySelector( 'button' ); if ( nb ) { nb.focus(); } }
			if ( scrollTop ) { toTop(); }
		}
		function runRest( scrollTop, append ) {
			var k = key(), mine = ++seq;
			function fail() { if ( mine === seq ) { root.removeAttribute( 'aria-busy' ); root.classList.remove( 'is-loading' ); status.textContent = T.lbl_error || ''; } }
			function done( out ) {
				if ( mine !== seq ) { return; }
				if ( ! append ) { st.page = out.page; }
				paint( { items: out.items, total: out.total, facets: out.facets }, !! append );
				if ( append ) { var nb = pager.querySelector( 'button' ); if ( nb ) { nb.focus(); } }
				if ( scrollTop ) { toTop(); }
			}
			if ( cache[ k ] ) { done( cache[ k ] ); return; }
			root.setAttribute( 'aria-busy', 'true' ); root.classList.add( 'is-loading' );
			status.textContent = T.lbl_loading || '';
			Suite.api( 'directory/list', { method: 'GET', query: { post: ctx.post, w: ctx.w, q: st.q, cat: st.cat, tag: st.tags.join( '|' ), area: st.area, open: st.open ? 1 : 0, sort: st.sort, page: st.page, per: C.per || 12 } } )
				.then( function ( r ) { if ( ! r || ! r.ok ) { fail(); return; } cache[ k ] = r; done( r ); } )
				.catch( fail );
		}

		/* --- eventos --- */
		buildControls();
		readUrl();
		var lazy = debounce( function () { st.page = 1; run(); }, rest ? 260 : 60 );
		input.addEventListener( 'input', function () { clear.hidden = ! input.value; lazy(); } );
		input.addEventListener( 'keydown', function ( e ) { if ( 'Escape' === e.key && input.value ) { input.value = ''; st.page = 1; run(); } } );
		clear.addEventListener( 'click', function () { input.value = ''; st.page = 1; run(); input.focus(); } );
		reset.addEventListener( 'click', function () { input.value = ''; st.q = ''; st.cat = ''; st.tags = []; st.area = ''; st.open = false; st.page = 1; run(); input.focus(); } );
		setInterval( function () { now = nowIn( C.tz ); }, 60000 );

		// El primer pintado de un directorio CSV usa los datos ya incluidos en la página (sin viaje al servidor).
		var firstKey = [ '', '', '', '', 0, C.sort || 'original', 1 ].join( '~' );
		if ( rest && data.items && key() === firstKey && ! input.value ) {
			cache[ firstKey ] = data;
			seq++;
			paint( { items: data.items, total: data.total, facets: data.facets }, false );
		} else { run(); }
	} );
}() );
