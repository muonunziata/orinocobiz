( function () {
	'use strict';
	WakooSuiteApi.define( 'gallery-filter', function ( root, cfg, S ) {
		var items = [].slice.call( root.querySelectorAll( '.wks-gf__item' ) );
		var chips = [].slice.call( root.querySelectorAll( '.wks-chip' ) );
		var lb = null, idx = 0, opener = null, list = [];

		function visibleItems() { return items.filter( function ( i ) { return ! i.hidden; } ); }

		function filter( tag ) {
			var first = new Map();
			items.forEach( function ( i ) { if ( ! i.hidden ) { first.set( i, i.getBoundingClientRect() ); } } );
			items.forEach( function ( i ) {
				var t = ( i.dataset.tags || '' ).split( ',' );
				i.hidden = !! tag && t.indexOf( tag ) < 0;
			} );
			if ( S.reduced() ) { return; }
			items.forEach( function ( i ) {
				if ( i.hidden ) { return; }
				var b = i.getBoundingClientRect(), a = first.get( i );
				if ( a ) {
					var dx = a.left - b.left, dy = a.top - b.top;
					if ( dx || dy ) {
						i.animate( [ { transform: 'translate(' + dx + 'px,' + dy + 'px)' }, { transform: 'none' } ], { duration: 320, easing: 'ease' } );
					}
				} else {
					i.animate( [ { opacity: 0, transform: 'scale(.92)' }, { opacity: 1, transform: 'none' } ], { duration: 320, easing: 'ease' } );
				}
			} );
		}

		chips.forEach( function ( c ) {
			c.addEventListener( 'click', function () {
				chips.forEach( function ( x ) { var on = x === c; x.classList.toggle( 'is-active', on ); x.setAttribute( 'aria-pressed', on ? 'true' : 'false' ); } );
				filter( c.dataset.tag );
			} );
		} );

		/* ---- lightbox ---- */
		function build() {
			lb = document.createElement( 'div' );
			lb.className = 'wks wks-gf-lb';
			lb.setAttribute( 'role', 'dialog' );
			lb.setAttribute( 'aria-modal', 'true' );
			lb.hidden = true;
			var img = document.createElement( 'img' ); img.alt = '';
			var cap = document.createElement( 'p' ); cap.className = 'wks-gf-lb__cap'; cap.setAttribute( 'aria-live', 'polite' );
			function btn( cls, txt, label ) {
				var b = document.createElement( 'button' ); b.type = 'button'; b.className = 'wks-gf-lb__btn ' + cls; b.textContent = txt; b.setAttribute( 'aria-label', label ); return b;
			}
			var x = btn( 'wks-gf-lb__x', '×', cfg.close || 'Close' );
			var p = btn( 'wks-gf-lb__prev', '‹', cfg.prev || 'Previous' );
			var n = btn( 'wks-gf-lb__next', '›', cfg.next || 'Next' );
			lb.appendChild( img ); lb.appendChild( cap ); lb.appendChild( x ); lb.appendChild( p ); lb.appendChild( n );
			document.body.appendChild( lb );
			x.addEventListener( 'click', closeLb );
			p.addEventListener( 'click', function () { go( -1 ); } );
			n.addEventListener( 'click', function () { go( 1 ); } );
			lb.addEventListener( 'click', function ( e ) { if ( e.target === lb ) { closeLb(); } } );
			lb.addEventListener( 'keydown', function ( e ) {
				if ( 'Escape' === e.key ) { closeLb(); e.preventDefault(); }
				else if ( 'ArrowLeft' === e.key ) { go( -1 ); }
				else if ( 'ArrowRight' === e.key ) { go( 1 ); }
				else if ( 'Tab' === e.key ) {
					var f = [ x, p, n ].filter( function ( b ) { return ! b.hidden; } );
					var a = document.activeElement, i = f.indexOf( a );
					if ( e.shiftKey && i <= 0 ) { f[ f.length - 1 ].focus(); e.preventDefault(); }
					else if ( ! e.shiftKey && i === f.length - 1 ) { f[ 0 ].focus(); e.preventDefault(); }
					else if ( i < 0 ) { f[ 0 ].focus(); e.preventDefault(); }
				}
			} );
			var sx = null;
			lb.addEventListener( 'touchstart', function ( e ) { sx = e.touches[ 0 ].clientX; }, { passive: true } );
			lb.addEventListener( 'touchend', function ( e ) {
				if ( null === sx ) { return; }
				var dx = e.changedTouches[ 0 ].clientX - sx; sx = null;
				if ( Math.abs( dx ) > 40 ) { go( dx < 0 ? 1 : -1 ); }
			} );
		}

		function show() {
			var it = list[ idx ], im = it.querySelector( 'img' ), c = it.querySelector( 'figcaption' );
			var big = lb.querySelector( 'img' );
			big.src = it.querySelector( '.wks-gf__open' ).dataset.full;
			big.alt = im.alt;
			lb.querySelector( '.wks-gf-lb__cap' ).textContent = c ? c.textContent : im.alt;
			lb.setAttribute( 'aria-label', im.alt || 'Image' );
			var multi = list.length > 1;
			lb.querySelector( '.wks-gf-lb__prev' ).hidden = ! multi;
			lb.querySelector( '.wks-gf-lb__next' ).hidden = ! multi;
		}
		function go( d ) { idx = ( idx + d + list.length ) % list.length; show(); }
		function openLb( item, btn ) {
			if ( ! lb ) { build(); }
			list = visibleItems();
			idx = Math.max( 0, list.indexOf( item ) );
			opener = btn;
			show();
			lb.hidden = false;
			document.documentElement.classList.add( 'wks-gf-lock' );
			lb.querySelector( '.wks-gf-lb__x' ).focus();
		}
		function closeLb() {
			if ( ! lb || lb.hidden ) { return; }
			lb.hidden = true;
			document.documentElement.classList.remove( 'wks-gf-lock' );
			if ( opener ) { opener.focus(); }
		}
		root.addEventListener( 'click', function ( e ) {
			var b = e.target.closest( '.wks-gf__open' );
			if ( b ) { openLb( b.closest( '.wks-gf__item' ), b ); }
		} );
	} );
}() );
