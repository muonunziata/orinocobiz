( function () {
	'use strict';
	WakooSuiteApi.define( 'chat', function ( root, cfg, S ) {
		var box = root.querySelector( '.wks-chat__box' ), log = root.querySelector( '.wks-chat__log' ), opts = root.querySelector( '.wks-chat__opts' );
		var launch = root.querySelector( '.wks-chat__launch' ), steps = cfg.steps || {}, started = false, token = 0, touched = false;
		var ctx = S.ctx( root ), mounted = Date.now(), delay = S.reduced() ? 0 : ( cfg.delay || 0 );
		var key = 'wks_chat_' + ctx.post + '_' + ctx.w + '_' + cfg.rev, TTL = 7 * 864e5;
		var st = { log: [], cur: '', data: {}, path: [], sent: false };

		/* ---------- persistence (never throws) ---------- */
		function save() {
			if ( ! cfg.keep ) { return; }
			st.log = st.log.slice( -120 );
			S.store.set( key, JSON.stringify( { t: Date.now(), s: st } ) );
		}
		function load() {
			if ( ! cfg.keep ) { return false; }
			try {
				var o = JSON.parse( S.store.get( key ) || 'null' );
				if ( o && o.s && Date.now() - o.t < TTL && o.s.log && o.s.log.length && steps[ o.s.cur ] ) { st = o.s; return true; }
			} catch ( e ) {}
			return false;
		}
		function wipe() { try { window.localStorage.removeItem( key ); } catch ( e ) {} }

		/* ---------- rendering ---------- */
		function hm() { var d = new Date(); return ( '0' + d.getHours() ).slice( -2 ) + ':' + ( '0' + d.getMinutes() ).slice( -2 ); }
		function link( label, url, cls ) {
			var a = S.el( 'a', { 'class': cls, href: url } );
			a.textContent = label;
			if ( /^https?:/i.test( url ) ) { a.target = '_blank'; a.rel = 'noopener noreferrer'; }
			return a;
		}
		function node( e ) {
			var b = S.el( 'div', { 'class': 'wks-chat__msg wks-chat__msg--' + ( 'me' === e.w ? 'me' : 'bot' ) } );
			if ( e.md ) {
				var m = e.md, el;
				if ( 'image' === m[ 0 ] ) { el = S.el( 'img', { src: m[ 1 ], alt: '', loading: 'lazy', 'class': 'wks-chat__media' } ); }
				else { el = S.el( m[ 0 ], { src: m[ 1 ], controls: '', preload: 'none', 'class': 'wks-chat__media' } ); }
				b.appendChild( el );
				b.classList.add( 'has-media' );
			} else if ( e.c ) {
				var c = e.c;
				b.classList.add( 'is-card' );
				if ( c.i ) { b.appendChild( S.el( 'img', { src: c.i, alt: '', loading: 'lazy', 'class': 'wks-chat__cardimg' } ) ); }
				var body = S.el( 'div', { 'class': 'wks-chat__cardbody' } );
				if ( c.t ) { body.appendChild( S.el( 'strong', { text: c.t } ) ); }
				if ( c.x ) { body.appendChild( S.el( 'p', { text: c.x } ) ); }
				if ( c.l && c.u ) { body.appendChild( link( c.l, c.u, 'wks-btn wks-chat__cardbtn' ) ); }
				b.appendChild( body );
			} else {
				b.appendChild( document.createTextNode( e.x || '' ) );
			}
			b.appendChild( S.el( 'time', { 'class': 'wks-chat__time', text: e.h || '' } ) );
			return b;
		}
		function add( e, silent ) {
			e.h = e.h || hm();
			var n = node( e );
			log.appendChild( n );
			if ( ! silent ) { st.log.push( e ); log.scrollTop = log.scrollHeight; }
			return n;
		}
		function typing() {
			var b = S.el( 'div', { 'class': 'wks-chat__msg wks-chat__msg--bot is-typing', role: 'status' } );
			b.appendChild( S.el( 'span', { 'class': 'wks-sr', text: cfg.typing || '…' } ) );
			b.appendChild( S.el( 'span', { 'class': 'wks-chat__dots', 'aria-hidden': 'true' }, [ S.el( 'i' ), S.el( 'i' ), S.el( 'i' ) ] ) );
			log.appendChild( b ); log.scrollTop = log.scrollHeight;
			return b;
		}
		function wait( ms, t ) { return new Promise( function ( ok ) { setTimeout( function () { ok( t === token ); }, ms ); } ); }
		function focusFirst( wrap ) {
			var f = wrap.querySelector( 'input, textarea, button, a' );
			if ( f && ( touched || cfg.float ) ) { f.focus( { preventScroll: true } ); }
		}

		/* ---------- actions area ---------- */
		function choices( id ) {
			var s = steps[ id ], wrap = S.el( 'div', { 'class': 'wks-chat__choices' } );
			s.o.forEach( function ( o ) {
				var b = S.el( 'button', { type: 'button', 'class': 'wks-chat__opt' } );
				b.textContent = o[ 0 ];
				b.addEventListener( 'click', function () { touched = true; add( { w: 'me', x: o[ 0 ] } ); st.path.push( o[ 0 ] ); play( o[ 1 ] ); } );
				wrap.appendChild( b );
			} );
			if ( s.au ) { wrap.appendChild( link( s.al || s.au, s.au, 'wks-btn wks-chat__act' ) ); }
			if ( ! s.o.length && ! s.q && cfg.cta && cfg.cta[ 1 ] ) { wrap.appendChild( link( cfg.cta[ 0 ] || cfg.cta[ 1 ], cfg.cta[ 1 ], 'wks-btn wks-chat__act' ) ); }
			return wrap;
		}
		function valid( f, v ) {
			if ( ! v ) { return false; }
			if ( 'email' === f ) { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test( v ); }
			if ( 'phone' === f ) { return /^[0-9+()\-\s.]{6,30}$/.test( v ); }
			return true;
		}
		function ask( id ) {
			var q = steps[ id ].q, f = q.f;
			var form = S.el( 'form', { 'class': 'wks-chat__ask', novalidate: '' } );
			var type = { email: 'email', phone: 'tel' }[ f ] || 'text';
			var inp = 'message' === f ? S.el( 'textarea', { rows: '2', maxlength: '1000' } ) : S.el( 'input', { type: type, maxlength: '120', autocomplete: { name: 'name', email: 'email', phone: 'tel' }[ f ] || 'off' } );
			inp.setAttribute( 'aria-label', q.p || f );
			if ( q.p ) { inp.setAttribute( 'placeholder', q.p ); }
			var hp = S.el( 'div', { 'class': 'wks-hp', 'aria-hidden': 'true' }, [ S.el( 'input', { type: 'text', name: 'website', tabindex: '-1', autocomplete: 'off' } ) ] );
			var btn = S.el( 'button', { type: 'submit', 'class': 'wks-btn' } ); btn.textContent = cfg.send || 'OK';
			var err = S.el( 'p', { 'class': 'wks-msg is-err', role: 'alert', hidden: '' } );
			form.appendChild( inp ); form.appendChild( hp ); form.appendChild( btn ); form.appendChild( err );
			form.addEventListener( 'submit', function ( e ) {
				e.preventDefault();
				var v = inp.value.trim();
				if ( ! valid( f, v ) ) { err.textContent = cfg.invalid || '!'; err.hidden = false; inp.focus(); return; }
				touched = true;
				st.data[ f ] = v; st.hp = hp.firstChild.value;
				add( { w: 'me', x: v } );
				if ( q.n ) { play( q.n ); } else { opts.textContent = ''; finish(); }
			} );
			return form;
		}
		function show( id ) {
			opts.textContent = '';
			var s = steps[ id ];
			if ( ! s ) { return; }
			var el = s.q ? ask( id ) : choices( id );
			opts.appendChild( el );
			focusFirst( el );
			save();
		}
		function finish() { save(); }

		function submitLead() {
			if ( ! cfg.lead || st.sent || ! Object.keys( st.data ).length ) { return; }
			st.sent = true; save();
			S.api( 'chat/lead', { data: { post: ctx.post, w: ctx.w, fields: st.data, path: st.path.join( ' > ' ), website: st.hp || '', t: Date.now() - mounted } } ).then( function ( d ) {
				add( { w: 'bot', x: d.ok ? cfg.sent : cfg.fail } );
				if ( ! d.ok ) { st.sent = false; }
				save();
			} );
		}

		async function play( id ) {
			var s = steps[ id ], t = ++token;
			if ( ! s ) { return; }
			st.cur = id; opts.textContent = '';
			var queue = s.m.map( function ( x ) { return { w: 'bot', x: x }; } );
			if ( s.md ) { queue.push( { w: 'bot', md: s.md } ); }
			if ( s.c ) { queue.push( { w: 'bot', c: s.c } ); }
			for ( var i = 0; i < queue.length; i++ ) {
				if ( delay ) {
					var ty = typing();
					var ok = await wait( delay, t );
					ty.remove();
					if ( ! ok ) { return; }
				}
				add( queue[ i ] );
			}
			if ( t !== token ) { return; }
			if ( s.s ) { submitLead(); }
			show( id );
		}

		/* ---------- start / restore ---------- */
		function begin( fresh ) {
			token++; log.textContent = ''; opts.textContent = ''; started = true;
			if ( fresh ) { wipe(); st = { log: [], cur: '', data: {}, path: [], sent: false }; }
			if ( ! fresh && load() ) {
				st.log.forEach( function ( e ) { add( e, true ); } );
				log.scrollTop = log.scrollHeight;
				show( st.cur );
				return;
			}
			st = { log: [], cur: '', data: {}, path: [], sent: false };
			play( cfg.start );
		}

		root.addEventListener( 'click', function ( e ) {
			var b = e.target.closest( 'button[data-a]' );
			if ( ! b ) { return; }
			if ( 'restart' === b.getAttribute( 'data-a' ) ) { begin( true ); }
			if ( 'close' === b.getAttribute( 'data-a' ) ) { toggle( false ); }
		} );
		function toggle( open ) {
			box.hidden = ! open;
			launch.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
			root.classList.toggle( 'is-open', open );
			if ( open && ! started ) { begin( false ); }
			if ( ! open ) { launch.focus(); }
		}
		if ( launch ) {
			launch.addEventListener( 'click', function () { toggle( box.hidden ); } );
			root.addEventListener( 'keydown', function ( e ) { if ( 'Escape' === e.key && ! box.hidden ) { toggle( false ); } } );
		} else { S.visible( root, function () { begin( false ); } ); }

		/* ---------- "online" status by schedule (site time zone) ---------- */
		( function () {
			var h = cfg.hours, label = root.querySelector( '.wks-chat__status' );
			if ( ! h || ! label ) { root.classList.add( 'is-online' ); return; }
			function on() {
				try {
					var p = new Intl.DateTimeFormat( 'en-GB', { timeZone: h.tz || undefined, weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false } ).formatToParts( new Date() ), o = {};
					p.forEach( function ( x ) { o[ x.type ] = x.value; } );
					var day = { Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6, Sun: 7 }[ o.weekday ] || 1;
					var now = parseInt( o.hour, 10 ) % 24 * 60 + parseInt( o.minute, 10 );
					function mins( s ) { var a = s.split( ':' ); return parseInt( a[ 0 ], 10 ) * 60 + parseInt( a[ 1 ], 10 ); }
					var a = mins( h.from ), b = mins( h.to );
					var inDay = h.days.indexOf( day ) > -1;
					return inDay && ( a <= b ? now >= a && now < b : now >= a || now < b );
				} catch ( e ) { return true; }
			}
			function paint() { var v = on(); root.classList.toggle( 'is-online', v ); root.classList.toggle( 'is-offline', ! v ); label.textContent = v ? cfg.status : h.off; }
			paint(); setInterval( paint, 60000 );
		}() );
	} );
} )();
