( function () {
	'use strict';
	WakooSuiteApi.define( 'journey', function ( root, cfg, S ) {
		var steps = [].slice.call( root.querySelectorAll( '.wks-journey__step' ) );
		var slides = [].slice.call( root.querySelectorAll( '.wks-journey__slide' ) );
		var count = root.querySelector( '.wks-journey__count' );
		var total = steps.length;
		function pad( n ) { return ( n < 10 ? '0' : '' ) + n; }
		function stopVideos( except ) {
			slides.forEach( function ( sl ) { var v = sl.querySelector( 'video' ); if ( v && sl !== except ) { v.pause(); } } );
		}
		function activate( i ) {
			steps.forEach( function ( s, k ) { s.classList.toggle( 'is-on', k === i ); if ( k === i ) { s.setAttribute( 'aria-current', 'step' ); } else { s.removeAttribute( 'aria-current' ); } } );
			slides.forEach( function ( s, k ) { s.classList.toggle( 'is-on', k === i ); } );
			if ( count ) { count.textContent = pad( i + 1 ) + ' / ' + pad( total ); }
			stopVideos( slides[ i ] );
		}
		if ( 'IntersectionObserver' in window ) {
			var io = new IntersectionObserver( function ( es ) {
				es.forEach( function ( e ) { if ( e.isIntersecting ) { activate( steps.indexOf( e.target ) ); } } );
			}, { rootMargin: '-40% 0px -40% 0px' } );
			steps.forEach( function ( s ) { io.observe( s ); } );
		}
		steps.forEach( function ( s, k ) { s.addEventListener( 'click', function () { activate( k ); } ); } );

		// El vídeo solo se descarga al pulsar la portada.
		root.addEventListener( 'click', function ( e ) {
			var b = e.target.closest( '.wks-journey__play' );
			if ( ! b ) { return; }
			var slide = b.closest( '.wks-journey__slide' );
			var src = slide.getAttribute( 'data-video' );
			if ( ! src || slide.querySelector( 'video' ) ) { return; }
			var v = document.createElement( 'video' );
			v.src = src; v.controls = true; v.playsInline = true; v.preload = 'auto';
			v.setAttribute( 'aria-label', b.getAttribute( 'aria-label' ) || '' );
			slide.appendChild( v );
			b.hidden = true;
			var p = v.play(); if ( p && p.catch ) { p.catch( function () {} ); }
			v.focus();
		} );
	} );
}() );
