( function () {
	'use strict';
	WakooSuiteApi.define( 'reviews', function ( root, cfg, S ) {
		var ctx = S.ctx( root ), list = root.querySelector( '.wks-rev__list' ), more = root.querySelector( '.wks-rev__more' ), none = root.querySelector( '.wks-rev__none' );
		var form = root.querySelector( '.wks-rev__form' ), page = 1, rating = 0, mounted = Date.now();

		function stars( n ) { return '★'.repeat( n ) + '☆'.repeat( 5 - n ); }
		function add( it ) {
			list.appendChild( S.el( 'article', { 'class': 'wks-rev__item wks-card' }, [
				S.el( 'div', { 'class': 'wks-rev__head' }, [ S.el( 'b', { text: it.name } ), S.el( 'span', { 'class': 'wks-stars', 'aria-label': it.rating + '/5', text: stars( it.rating ) } ), S.el( 'small', { text: it.date } ) ] ),
				S.el( 'p', { text: it.text, style: 'white-space:pre-wrap' } )
			] ) );
		}
		if ( more ) {
			more.addEventListener( 'click', function () {
				page++;
				S.api( 'reviews/list', { query: { post: ctx.post, w: ctx.w, page: page } } ).then( function ( d ) {
					if ( ! d.ok ) { return; }
					d.items.forEach( add );
					more.hidden = page >= d.pages;
				} );
			} );
		}
		if ( ! form ) { return; }
		var btns = form.querySelectorAll( '.wks-rev__star' ), msg = form.querySelector( '.wks-msg' );
		function paint( n ) { btns.forEach( function ( b, i ) { b.textContent = i < n ? '★' : '☆'; b.setAttribute( 'aria-checked', ( i + 1 ) === rating ? 'true' : 'false' ); } ); }
		btns.forEach( function ( b ) {
			b.addEventListener( 'click', function () { rating = parseInt( b.getAttribute( 'data-v' ), 10 ); paint( rating ); } );
			b.addEventListener( 'mouseenter', function () { paint( parseInt( b.getAttribute( 'data-v' ), 10 ) ); } );
			b.addEventListener( 'mouseleave', function () { paint( rating ); } );
			b.addEventListener( 'keydown', function ( e ) {
				if ( 'ArrowRight' === e.key || 'ArrowUp' === e.key ) { rating = Math.min( 5, ( rating || 0 ) + 1 ); paint( rating ); btns[ rating - 1 ].focus(); e.preventDefault(); }
				if ( 'ArrowLeft' === e.key || 'ArrowDown' === e.key ) { rating = Math.max( 1, ( rating || 2 ) - 1 ); paint( rating ); btns[ rating - 1 ].focus(); e.preventDefault(); }
			} );
		} );
		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			var btn = form.querySelector( '.wks-btn' ); btn.disabled = true;
			S.api( 'reviews/submit', { data: { post: ctx.post, w: ctx.w, rating: rating, name: form.name.value, email: form.email.value, text: form.text.value, website: form.website.value, t: Date.now() - mounted } } ).then( function ( d ) {
				btn.disabled = false;
				if ( d.ok ) {
					msg.textContent = d.published ? cfg.ok_pub : cfg.ok_pen; msg.className = 'wks-msg is-ok';
					if ( d.published ) { add( { name: form.name.value, text: form.text.value, rating: rating, date: '' } ); none.hidden = true; }
					form.reset(); rating = 0; paint( 0 );
				} else { msg.textContent = d.error || 'Error'; msg.className = 'wks-msg is-err'; }
			} );
		} );
	} );
}() );
