( function () {
	'use strict';
	WakooSuiteApi.define( 'checklist', function ( root, cfg, S ) {
		var boxes = Array.prototype.slice.call( root.querySelectorAll( 'input[type=checkbox]' ) ), ctx = S.ctx( root );
		var key = 'wks_cl_' + ctx.post + '_' + ctx.w, bar = root.querySelector( '.wks-bar' ), fill = bar.querySelector( 'i' );
		var count = root.querySelector( '.wks-cl__count' ), done = root.querySelector( '.wks-cl__done' );

		if ( cfg.persist ) {
			try {
				var saved = JSON.parse( S.store.get( key ) || '[]' );
				boxes.forEach( function ( b, i ) { b.checked = saved.indexOf( i ) > -1; } );
			} catch ( e ) {}
		}
		function update() {
			var n = boxes.filter( function ( b ) { return b.checked; } ).length, pct = boxes.length ? Math.round( n * 100 / boxes.length ) : 0;
			fill.style.width = pct + '%';
			bar.setAttribute( 'aria-valuenow', pct );
			count.textContent = n + ' ' + cfg.of + ' ' + boxes.length + ' (' + pct + '%)';
			done.hidden = ! ( cfg.done && n === boxes.length && n > 0 );
			boxes.forEach( function ( b ) { b.parentNode.classList.toggle( 'is-done', b.checked ); } );
			if ( cfg.persist ) {
				S.store.set( key, JSON.stringify( boxes.map( function ( b, i ) { return b.checked ? i : -1; } ).filter( function ( i ) { return i > -1; } ) ) );
			}
		}
		boxes.forEach( function ( b ) { b.addEventListener( 'change', update ); } );

		function summary() {
			var lines = [ cfg.title ].filter( Boolean );
			root.querySelectorAll( '.wks-cl__group' ).forEach( function ( g ) {
				lines.push( '', g.querySelector( 'legend' ).textContent );
				g.querySelectorAll( '.wks-cl__item' ).forEach( function ( it ) {
					lines.push( ( it.querySelector( 'input' ).checked ? '[x] ' : '[ ] ' ) + it.querySelector( 'label' ).textContent );
				} );
			} );
			return lines.join( '\n' );
		}
		root.addEventListener( 'click', function ( e ) {
			var btn = e.target.closest( 'button[data-a]' );
			if ( ! btn ) { return; }
			var a = btn.getAttribute( 'data-a' );
			if ( 'reset' === a ) { boxes.forEach( function ( b ) { b.checked = false; } ); update(); }
			if ( 'copy' === a ) {
				var text = summary(), orig = btn.textContent, ok = function () { btn.textContent = cfg.copied; setTimeout( function () { btn.textContent = orig; }, 1500 ); };
				if ( navigator.clipboard && navigator.clipboard.writeText ) { navigator.clipboard.writeText( text ).then( ok ); }
				else {
					var ta = S.el( 'textarea', { 'aria-hidden': 'true' } ); ta.value = text; ta.style.cssText = 'position:fixed;left:-9999px';
					document.body.appendChild( ta ); ta.select(); try { document.execCommand( 'copy' ); ok(); } catch ( x ) {} ta.remove();
				}
			}
			if ( 'print' === a ) {
				var f = S.el( 'iframe', { 'aria-hidden': 'true' } ); f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0';
				document.body.appendChild( f );
				var d = f.contentDocument, pre = d.createElement( 'pre' );
				pre.style.cssText = 'font:16px/1.6 sans-serif;white-space:pre-wrap';
				pre.textContent = summary();
				d.body.appendChild( pre );
				f.contentWindow.focus(); f.contentWindow.print();
				setTimeout( function () { f.remove(); }, 2000 );
			}
		} );
		update();
	} );
}() );
