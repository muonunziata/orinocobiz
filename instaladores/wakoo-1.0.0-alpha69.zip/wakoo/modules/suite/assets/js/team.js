( function () {
	'use strict';
	WakooSuiteApi.define( 'team', function ( root, cfg, S ) {
		var chips = [].slice.call( root.querySelectorAll( '.wks-chip' ) );
		var groups = [].slice.call( root.querySelectorAll( '.wks-team__group' ) );
		chips.forEach( function ( c ) {
			c.addEventListener( 'click', function () {
				chips.forEach( function ( x ) { var on = x === c; x.classList.toggle( 'is-active', on ); x.setAttribute( 'aria-pressed', on ? 'true' : 'false' ); } );
				groups.forEach( function ( g ) { g.hidden = !! c.dataset.g && g.dataset.g !== c.dataset.g; } );
			} );
		} );

		var modal = null, opener = null, box = null, x = null;
		function build() {
			modal = document.createElement( 'div' );
			modal.className = 'wks wks-team-modal';
			modal.hidden = true;
			box = document.createElement( 'div' );
			box.className = 'wks-team-modal__box';
			box.setAttribute( 'role', 'dialog' );
			box.setAttribute( 'aria-modal', 'true' );
			box.tabIndex = -1;
			x = document.createElement( 'button' );
			x.type = 'button'; x.className = 'wks-team-modal__x'; x.textContent = '×';
			x.setAttribute( 'aria-label', cfg.close || 'Close' );
			var body = document.createElement( 'div' ); body.className = 'wks-team-modal__body';
			box.appendChild( x ); box.appendChild( body ); modal.appendChild( box );
			document.body.appendChild( modal );
			x.addEventListener( 'click', closeM );
			modal.addEventListener( 'mousedown', function ( e ) { if ( e.target === modal ) { closeM(); } } );
			modal.addEventListener( 'keydown', function ( e ) {
				if ( 'Escape' === e.key ) { e.preventDefault(); closeM(); return; }
				if ( 'Tab' !== e.key ) { return; }
				var f = [].slice.call( box.querySelectorAll( 'a[href],button:not([disabled])' ) );
				if ( ! f.length ) { e.preventDefault(); return; }
				var first = f[ 0 ], last = f[ f.length - 1 ], a = document.activeElement;
				if ( e.shiftKey && ( a === first || a === box ) ) { last.focus(); e.preventDefault(); }
				else if ( ! e.shiftKey && a === last ) { first.focus(); e.preventDefault(); }
				else if ( ! box.contains( a ) ) { first.focus(); e.preventDefault(); }
			} );
		}
		function openM( btn ) {
			if ( ! modal ) { build(); }
			var tpl = btn.closest( '.wks-team__card' ).querySelector( 'template' );
			var body = box.querySelector( '.wks-team-modal__body' );
			body.textContent = '';
			body.appendChild( tpl.content.cloneNode( true ) );
			var h = body.querySelector( '.wks-team__mname' );
			if ( h ) { h.id = 'wks-tm-' + Math.random().toString( 36 ).slice( 2, 8 ); box.setAttribute( 'aria-labelledby', h.id ); }
			opener = btn;
			modal.hidden = false;
			document.documentElement.classList.add( 'wks-team-lock' );
			x.focus();
		}
		function closeM() {
			if ( ! modal || modal.hidden ) { return; }
			modal.hidden = true;
			document.documentElement.classList.remove( 'wks-team-lock' );
			if ( opener ) { opener.focus(); }
		}
		root.addEventListener( 'click', function ( e ) {
			var b = e.target.closest( '.wks-team__open' );
			if ( b ) { openM( b ); }
		} );
	} );
}() );
