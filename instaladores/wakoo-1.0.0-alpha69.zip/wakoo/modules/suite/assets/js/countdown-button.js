( function () {
	'use strict';
	WakooSuiteApi.define( 'countdown-button', function ( root, cfg, S ) {
		var q = function ( c ) { return root.querySelector( c ); };
		var btn = q( '.wks-cdb__btn' ), clock = q( '.wks-cdb__clock' ), content = q( '.wks-cdb__content' ), msg = q( '.wks-cdb__msg' ), reset = q( '.wks-cdb__reset' );
		var timer = null, KEY = cfg.key;

		function stored() { var v = parseInt( S.store.get( KEY ), 10 ); return v > 0 ? v : 0; }
		function pad( n ) { return ( n < 10 ? '0' : '' ) + n; }
		function fmt( ms ) {
			var t = Math.max( 0, Math.ceil( ms / 1000 ) ), h = Math.floor( t / 3600 ), m = Math.floor( ( t % 3600 ) / 60 );
			return ( h ? h + ':' + pad( m ) : pad( m ) ) + ':' + pad( t % 60 );
		}
		function show( node, on ) { node.hidden = ! on; }
		function view( state ) {
			show( btn, state === 'idle' );
			show( clock, state === 'run' );
			show( content, state === 'run' || ( state === 'end' && false ) );
			show( msg, state === 'end' && cfg.end === 'message' );
			if ( state === 'end' && cfg.end === 'relock' ) { show( btn, true ); }
			msg.textContent = cfg.endMsg; msg.className = 'wks-cdb__msg wks-msg is-err';
			show( reset, cfg.reset && state !== 'idle' );
			root.setAttribute( 'data-state', state );
		}
		function tick() {
			var left = stored() - Date.now();
			if ( left <= 0 ) { clearInterval( timer ); timer = null; S.store.set( KEY, '' ); view( 'end' ); return; }
			clock.textContent = cfg.running + ' ' + fmt( left );
		}
		function run() {
			view( 'run' ); tick();
			if ( ! timer ) { timer = setInterval( tick, 1000 ); }
		}
		btn.addEventListener( 'click', function () { S.store.set( KEY, String( Date.now() + cfg.min * 60000 ) ); run(); } );
		if ( cfg.reset ) {
			reset.textContent = cfg.resetT;
			reset.addEventListener( 'click', function () { clearInterval( timer ); timer = null; S.store.set( KEY, '' ); view( 'idle' ); } );
		}
		if ( stored() ) {
			if ( stored() > Date.now() ) { run(); } else { S.store.set( KEY, '' ); view( 'end' ); }
		} else { view( 'idle' ); }
	} );
}() );
