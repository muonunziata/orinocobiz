( function () {
	'use strict';
	var loadedJs = {};
	function loadScripts( urls, done ) {
		var i = 0;
		( function next() {
			if ( i >= urls.length ) { done(); return; }
			var u = urls[ i++ ];
			if ( loadedJs[ u ] || document.querySelector( 'script[src="' + u.replace( /"/g, '' ) + '"]' ) ) { next(); return; }
			loadedJs[ u ] = 1;
			var s = document.createElement( 'script' );
			s.src = u; s.onload = next; s.onerror = next;
			document.head.appendChild( s );
		}() );
	}
	function loadStyles( urls ) {
		urls.forEach( function ( u ) {
			if ( document.querySelector( 'link[href="' + u.replace( /"/g, '' ) + '"]' ) ) { return; }
			var l = document.createElement( 'link' );
			l.rel = 'stylesheet'; l.href = u;
			document.head.appendChild( l );
		} );
	}

	WakooSuiteApi.define( 'tabs', function ( root, cfg, S ) {
		var tabs = Array.prototype.slice.call( root.querySelectorAll( '.wks-tabs__tab' ) ), panels = root.querySelectorAll( '.wks-tabs__panel' ), ctx = S.ctx( root );

		function fill( panel, tab ) {
			if ( ! panel.getAttribute( 'data-lazy' ) ) { return; }
			panel.removeAttribute( 'data-lazy' );
			panel.setAttribute( 'aria-busy', 'true' );
			panel.textContent = cfg.loading;
			S.api( 'tabs/panel', { query: { post: ctx.post, w: ctx.w, i: tab.getAttribute( 'data-i' ) } } ).then( function ( r ) {
				panel.removeAttribute( 'aria-busy' );
				if ( ! r || ! r.ok ) { panel.textContent = cfg.error; panel.setAttribute( 'data-lazy', '1' ); return; }
				loadStyles( r.css || [] );
				panel.innerHTML = r.html; // server-rendered Elementor markup from a published template
				loadScripts( r.js || [], function () {
					var fe = window.elementorFrontend;
					if ( fe && fe.elementsHandler && fe.elementsHandler.runReadyTrigger && window.jQuery ) {
						panel.querySelectorAll( '[data-element_type]' ).forEach( function ( el ) { try { fe.elementsHandler.runReadyTrigger( window.jQuery( el ) ); } catch ( e ) {} } );
					}
				} );
			} );
		}
		function select( i, focus ) {
			tabs.forEach( function ( t, k ) {
				var on = k === i;
				t.classList.toggle( 'is-active', on );
				t.setAttribute( 'aria-selected', on ? 'true' : 'false' );
				t.tabIndex = on ? 0 : -1;
				panels[ k ].hidden = ! on;
			} );
			if ( focus ) { tabs[ i ].focus(); }
			fill( panels[ i ], tabs[ i ] );
		}
		tabs.forEach( function ( t, i ) {
			t.addEventListener( 'click', function () { select( i, false ); } );
			t.addEventListener( 'keydown', function ( e ) {
				var vertical = root.classList.contains( 'is-vertical' ), n = tabs.length, to = -1;
				if ( e.key === ( vertical ? 'ArrowDown' : 'ArrowRight' ) ) { to = ( i + 1 ) % n; }
				else if ( e.key === ( vertical ? 'ArrowUp' : 'ArrowLeft' ) ) { to = ( i - 1 + n ) % n; }
				else if ( e.key === 'Home' ) { to = 0; } else if ( e.key === 'End' ) { to = n - 1; }
				if ( to > -1 ) { e.preventDefault(); select( to, true ); }
			} );
		} );
	} );
}() );
