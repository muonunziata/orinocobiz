( function () {
	'use strict';
	WakooSuiteApi.define( 'dark-mode', function ( root, cfg ) {
		var T = window.WakooTheme;
		if ( ! T ) { return; }
		T.config( cfg );
		var btn = root.querySelector( '.wks-dm__btn' );
		if ( ! btn ) { return; }
		function sync( m ) {
			btn.setAttribute( 'aria-pressed', 'dark' === m ? 'true' : 'false' );
			root.classList.toggle( 'is-dark', 'dark' === m );
		}
		sync( T.get() );
		T.on( sync );
		btn.addEventListener( 'click', function () { T.toggle(); } );
	} );
}() );
