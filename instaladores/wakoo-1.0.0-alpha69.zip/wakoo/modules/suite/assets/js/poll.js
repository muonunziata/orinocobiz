( function () {
	'use strict';
	WakooSuiteApi.define( 'poll', function ( root, cfg, S ) {
		var ctx = S.ctx( root ), base = 'wks_poll_' + ctx.post + '_' + ctx.w + '_' + cfg.ver;
		var form = root.querySelector( '.wks-poll__form' ), res = root.querySelector( '.wks-poll__res' ), msg = root.querySelector( '.wks-msg' );
		var verdict = root.querySelector( '.wks-poll__verdict' ), rows = [].slice.call( root.querySelectorAll( '.wks-poll__row' ) ), wrap = root.querySelector( '.wks-poll__rows' );
		var count = parseInt( S.store.get( base ) || '0', 10 ) || 0, mounted = Date.now(), mine = [];
		try { mine = JSON.parse( S.store.get( base + '_mine' ) || '[]' ); } catch ( e ) {}
		var reduced = S.reduced();
		function closed() { return cfg.closes && Date.now() / 1000 >= cfg.closes; }

		function num( el, to, txt ) {
			if ( reduced || to < 1 ) { el.textContent = txt( to ); return; }
			var t0 = null;
			( function step( t ) {
				if ( null === t0 ) { t0 = t; }
				var k = Math.min( 1, ( t - t0 ) / 600 );
				el.textContent = txt( Math.round( to * ( 1 - Math.pow( 1 - k, 3 ) ) ) );
				if ( k < 1 ) { requestAnimationFrame( step ); }
			}( performance.now() ) );
		}
		function paint( d ) {
			var total = d.counts.reduce( function ( a, b ) { return a + b; }, 0 ), max = cfg.multi ? Math.max( d.voters, 1 ) : Math.max( total, 1 );
			var top = Math.max.apply( null, d.counts );
			rows.forEach( function ( row ) {
				var i = parseInt( row.getAttribute( 'data-i' ), 10 ), c = d.counts[ i ] || 0, p = Math.round( c * 100 / max );
				var bar = row.querySelector( '.wks-bar > i' ), pct = row.querySelector( '.wks-poll__pct' );
				row.classList.toggle( 'is-top', c > 0 && c === top );
				row.classList.toggle( 'is-mine', mine.indexOf( i ) > -1 );
				row.classList.toggle( 'is-right', !! ( d.correct && d.correct.indexOf( i ) > -1 ) );
				row.style.order = 'votes' === cfg.sort ? String( -c ) : '0';
				bar.style.width = '0';
				requestAnimationFrame( function () { requestAnimationFrame( function () { bar.style.width = p + '%'; } ); } );
				num( pct, p, function ( v ) { return v + '%'; } );
				row.querySelector( '.wks-poll__n' ).textContent = cfg.counts ? c + ' ' + cfg.votes : '';
				var tag = row.querySelector( '.wks-poll__tag' ), t = [];
				if ( mine.indexOf( i ) > -1 ) { t.push( cfg.mine ); }
				if ( d.correct && d.correct.indexOf( i ) > -1 ) { t.push( '✓' ); }
				tag.textContent = t.length ? ' · ' + t.join( ' · ' ) : ''; tag.hidden = ! t.length;
				var why = row.querySelector( '.wks-poll__why' ), w = d.why && d.why[ i ] && ( mine.indexOf( i ) > -1 || ( d.correct && d.correct.indexOf( i ) > -1 ) ) ? d.why[ i ] : '';
				why.textContent = w; why.hidden = ! w;
			} );
			root.querySelector( '.wks-poll__total' ).textContent = cfg.counts ? d.voters + ' ' + cfg.votes : '';
			if ( 'rating' === cfg.kind ) {
				var sum = 0; d.counts.forEach( function ( c, i ) { sum += c * ( i + 1 ); } );
				var avg = total ? sum / total : 0, box = root.querySelector( '.wks-poll__avg' );
				box.querySelector( 'b' ).textContent = cfg.avg + ': ' + avg.toFixed( 1 ) + ' / 5';
				box.querySelector( '.wks-stars' ).textContent = '★★★★★'.slice( 0, Math.round( avg ) ) + '☆☆☆☆☆'.slice( 0, 5 - Math.round( avg ) );
			}
			if ( cfg.quiz && d.correct && mine.length ) {
				var ok = d.correct.length === mine.length && mine.every( function ( i ) { return d.correct.indexOf( i ) > -1; } );
				verdict.textContent = ok ? cfg.right : cfg.wrong; verdict.className = 'wks-poll__verdict ' + ( ok ? 'is-ok' : 'is-bad' ); verdict.hidden = false;
			}
			res.hidden = false; form.hidden = count >= cfg.limit || closed();
			[].forEach.call( form.querySelectorAll( 'input[name=o]' ), function ( i ) { i.checked = false; i.disabled = false; } );
		}
		function load() { S.api( 'poll/results', { query: { post: ctx.post, w: ctx.w } } ).then( function ( d ) { if ( d.ok ) { paint( d ); } } ); }

		if ( closed() ) { msg.textContent = cfg.closed; msg.className = 'wks-msg'; form.hidden = true; load(); }
		else if ( count >= cfg.limit ) { msg.textContent = cfg.done; msg.className = 'wks-msg'; load(); }
		else if ( cfg.always ) { S.visible( root, load ); }

		/* max selection for multiple choice */
		form.addEventListener( 'change', function () {
			if ( ! cfg.multi || ! cfg.max ) { return; }
			var boxes = form.querySelectorAll( 'input[name=o]' ), n = form.querySelectorAll( 'input[name=o]:checked' ).length;
			[].forEach.call( boxes, function ( b ) { b.disabled = n >= cfg.max && ! b.checked; } );
		} );

		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			var o = [].map.call( form.querySelectorAll( 'input[name=o]:checked' ), function ( i ) { return parseInt( i.value, 10 ); } );
			if ( ! o.length ) { msg.textContent = cfg.pick; msg.className = 'wks-msg is-err'; return; }
			var btn = form.querySelector( 'button[type=submit]' ); btn.disabled = true;
			S.api( 'poll/vote', { data: { post: ctx.post, w: ctx.w, opts: o, website: form.website.value, t: Date.now() - mounted } } ).then( function ( d ) {
				btn.disabled = false;
				if ( d.ok ) {
					count++; S.store.set( base, String( count ) ); mine = o; S.store.set( base + '_mine', JSON.stringify( o ) );
					msg.textContent = cfg.thanks; msg.className = 'wks-msg is-ok';
										paint( d );
				} else if ( d.voted || d.closed ) {
					S.store.set( base, String( cfg.limit ) );
					msg.textContent = d.closed ? cfg.closed : cfg.done; msg.className = 'wks-msg';
					paint( d );
				} else { msg.textContent = d.error || 'Error'; msg.className = 'wks-msg is-err'; }
			} ).catch( function () { btn.disabled = false; msg.textContent = 'Error'; msg.className = 'wks-msg is-err'; } );
		} );

		var share = root.querySelector( '.wks-poll__share' );
		if ( share ) {
			share.addEventListener( 'click', function () {
				var url = location.href.split( '#' )[ 0 ] + '#' + form.id, label = share.textContent;
				function done() { share.textContent = cfg.copied; setTimeout( function () { share.textContent = label; }, 1800 ); }
				if ( navigator.clipboard && navigator.clipboard.writeText ) { navigator.clipboard.writeText( url ).then( done, function () { window.prompt( '', url ); } ); }
				else { window.prompt( '', url ); }
			} );
		}
	} );
}() );
