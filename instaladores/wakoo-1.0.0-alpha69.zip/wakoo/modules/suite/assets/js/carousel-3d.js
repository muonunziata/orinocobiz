/*! Wakoo Suite · Carrusel 3D de fotos y vídeos. Original code (GPL-2.0-or-later); behaviour inspired by a VeloxForge block. */
( function ( w, d ) {
	'use strict';
	if ( ! w.WakooSuiteApi ) { return; }
	var mql = w.matchMedia ? w.matchMedia( '(prefers-reduced-motion: reduce)' ) : { matches: false };

	w.WakooSuiteApi.define( 'carousel-3d', function ( root, cfg, S ) {
		var view = root.querySelector( '.wks-c3__view' ), ring = root.querySelector( '.wks-c3__ring' ), cards = [].slice.call( ring.querySelectorAll( '.wks-c3__card' ) );
		var cap = root.querySelector( '.wks-c3__cap' ), tog = root.querySelector( '[data-act="toggle"]' );
		var n = cards.length; if ( n < 2 ) { return; }
		var step = 360 / n, angle = 0, vel = 0, auto = !! cfg.auto && ! mql.matches, speed = ( cfg.speed || 12 ) / 1000;
		var dragging = false, moved = false, lastX = 0, startX = 0, hover = false, vis = false, running = false, last = 0, anim = null, front = -1, playing = null;

		function label() { if ( tog ) { tog.textContent = auto ? cfg.pause : cfg.play; tog.setAttribute( 'aria-pressed', String( ! auto ) ); } }
		function layout() {
			var wd = cards[ 0 ].offsetWidth, R = Math.round( ( wd / 2 ) / Math.tan( Math.PI / n ) + 24 );
			cards.forEach( function ( c, i ) { c.dataset.a = i * step; c.dataset.r = R; c.style.transform = 'rotateY(' + ( i * step ) + 'deg) translateZ(' + R + 'px)'; } );
		}
		function stopVideo() {
			if ( ! playing ) { return; }
			var v = playing.querySelector( 'video' ); if ( v ) { v.pause(); v.removeAttribute( 'src' ); v.load(); v.remove(); }
			playing.classList.remove( 'is-playing' ); playing = null;
		}
		function setFront() {
			var f = ( ( Math.round( -angle / step ) % n ) + n ) % n;
			if ( f === front ) { return; }
			front = f;
			cards.forEach( function ( c, i ) {
				var b = c.querySelector( '.wks-c3__play' ); if ( b ) { b.tabIndex = i === f ? 0 : -1; }
				c.classList.toggle( 'is-front', i === f );
			} );
			if ( playing && playing !== cards[ f ] ) { stopVideo(); }
			if ( cap ) { cap.textContent = cards[ f ].getAttribute( 'data-title' ) || ''; }
		}
		function render() {
			ring.style.transform = 'translateZ(' + ( -cards[ 0 ].dataset.r ) + 'px) rotateY(' + angle.toFixed( 2 ) + 'deg)';
			cards.forEach( function ( c ) {
				var a = ( +c.dataset.a + angle ) * Math.PI / 180;
				c.style.opacity = ( 0.35 + 0.65 * ( Math.cos( a ) + 1 ) / 2 ).toFixed( 2 );
			} );
			setFront();
		}
		function tick( t ) {
			if ( ! vis ) { running = false; return; }          // off-screen: stop the loop
			var dt = Math.min( 50, t - last ); last = t;
			var live = false;
			if ( anim ) {
				var k = Math.min( 1, ( t - anim.t0 ) / 600 ), e = 1 - Math.pow( 1 - k, 3 );
				angle = anim.from + ( anim.to - anim.from ) * e; if ( k >= 1 ) { anim = null; } else { live = true; }
			} else if ( ! dragging ) {
				if ( Math.abs( vel ) > 0.01 ) { angle += vel; vel *= 0.94; live = true; } else { vel = 0; }
				if ( auto && ! hover && ! playing ) { angle -= dt * speed; live = true; }
			} else { live = true; }
			render();
			if ( live && d.body.contains( root ) ) { w.requestAnimationFrame( tick ); } else { running = false; }
		}
		function kick() { if ( vis && ! running ) { running = true; last = performance.now(); w.requestAnimationFrame( tick ); } }
		function go( dir ) {
			stopVideo(); vel = 0; auto = false; label();
			var to = Math.round( angle / step ) * step + dir * step;
			if ( mql.matches ) { angle = to; render(); return; }          // no animation for reduced motion
			anim = { from: angle, to: to, t0: performance.now() }; kick();
		}
		function goTo( i ) {   // shortest path to card i
			var cur = ( ( Math.round( -angle / step ) % n ) + n ) % n, diff = i - cur;
			if ( diff > n / 2 ) { diff -= n; } if ( diff < -n / 2 ) { diff += n; }
			if ( ! diff ) { return; }
			stopVideo(); vel = 0; auto = false; label();
			var to = angle - diff * step;
			if ( mql.matches ) { angle = to; render(); return; }
			anim = { from: angle, to: to, t0: performance.now() }; kick();
		}

		layout(); render(); label();
		var rz; w.addEventListener( 'resize', function () { clearTimeout( rz ); rz = setTimeout( function () { layout(); render(); }, 120 ); } );
		if ( 'IntersectionObserver' in w ) {
			new IntersectionObserver( function ( es ) { vis = es.some( function ( e ) { return e.isIntersecting; } ); if ( vis ) { layout(); kick(); } else { stopVideo(); } }, { rootMargin: '60px' } ).observe( root );
		} else { vis = true; kick(); }
		if ( d.body.classList.contains( 'elementor-editor-active' ) ) { auto = false; return; }

		view.addEventListener( 'pointerdown', function ( e ) {
			if ( 0 !== e.button || ( e.target.closest && e.target.closest( 'video' ) ) ) { return; }
			dragging = true; moved = false; lastX = startX = e.clientX; vel = 0; anim = null; view.classList.add( 'drag' );
			try { view.setPointerCapture( e.pointerId ); } catch ( er ) {}
			kick();
		} );
		view.addEventListener( 'pointermove', function ( e ) {
			if ( ! dragging ) { return; }
			if ( ! moved && Math.abs( e.clientX - startX ) > 6 ) { moved = true; }
			var dx = e.clientX - lastX; lastX = e.clientX; angle += dx * 0.35; vel = mql.matches ? 0 : dx * 0.35;
		} );
		function end() { dragging = false; view.classList.remove( 'drag' ); kick(); }
		view.addEventListener( 'pointerup', end ); view.addEventListener( 'pointercancel', end );
		view.addEventListener( 'pointerenter', function () { hover = true; } ); view.addEventListener( 'pointerleave', function () { hover = false; kick(); } );

		/* clic: tarjeta lateral → centrar; botón de reproducir de la tarjeta frontal → cargar el vídeo (uno solo a la vez) */
		view.addEventListener( 'click', function ( e ) {
			if ( moved ) { moved = false; return; }
			var card = e.target.closest && e.target.closest( '.wks-c3__card' ); if ( ! card ) { return; }
			var i = cards.indexOf( card );
			if ( i !== front ) { goTo( i ); return; }
			var vurl = card.getAttribute( 'data-video' );
			if ( vurl && ! card.classList.contains( 'is-playing' ) && e.target.closest( '.wks-c3__play' ) ) {
				stopVideo(); auto = false; label();
				var v = d.createElement( 'video' ); v.controls = true; v.playsInline = true; v.autoplay = true; v.preload = 'auto';
				if ( card.getAttribute( 'data-poster' ) ) { v.poster = card.getAttribute( 'data-poster' ); }
				v.src = vurl; card.appendChild( v ); card.classList.add( 'is-playing' ); playing = card;
				var pr = v.play(); if ( pr && pr.catch ) { pr.catch( function () {} ); }
			}
		} );
		view.addEventListener( 'keydown', function ( e ) {
			if ( 'ArrowLeft' === e.key ) { e.preventDefault(); go( 1 ); } else if ( 'ArrowRight' === e.key ) { e.preventDefault(); go( -1 ); }
		} );
		var pv = root.querySelector( '[data-act="prev"]' ), nx = root.querySelector( '[data-act="next"]' );
		if ( pv ) { pv.addEventListener( 'click', function () { go( 1 ); } ); }
		if ( nx ) { nx.addEventListener( 'click', function () { go( -1 ); } ); }
		if ( tog ) { tog.addEventListener( 'click', function () { auto = ! auto; label(); kick(); } ); }
	} );
}( window, document ) );
