/*! Wakoo Suite · Pared de vídeos infinita. Original code (GPL-2.0-or-later); behaviour inspired by a VeloxForge block. */
( function ( w, d ) {
	'use strict';
	if ( ! w.WakooSuiteApi ) { return; }
	var fine = w.matchMedia && w.matchMedia( '(hover: hover) and (pointer: fine)' ).matches;
	var mql = w.matchMedia ? w.matchMedia( '(prefers-reduced-motion: reduce)' ) : { matches: false };
	function wrapP( v, P ) { return P ? v - P * Math.round( v / P ) : v; }

	w.WakooSuiteApi.define( 'video-wall', function ( root, cfg, S ) {
		var stage = root.querySelector( '.wks-vw__stage' ), tiles = [].slice.call( stage.querySelectorAll( '.wks-vw__tile' ) );
		var ROWS = cfg.rows || 5, COLS = cfg.cols || 9;
		var inEditor = d.body.classList.contains( 'elementor-editor-active' );
		var x = 0, y = 0, vx = 0, vy = 0, dvx = 0, dvy = 0, VW = 0, VH = 0, PITCH = 0, HS = 0, GAP = 16;
		var cx = [], cy = [], tw = [], th = [], rowW = [];
		var dragging = false, moved = false, sx = 0, sy = 0, lx = 0, ly = 0, lastAct = 0, hoverTile = false, modalOpen = false;
		var ang = Math.random() * 6.28, tNext = 0, last = 0, vis = false, running = false;

		function measure() {
			VW = root.clientWidth; VH = root.clientHeight;
			if ( ! VW || ! VH ) { return; }
			GAP = cfg.gap > 0 ? cfg.gap : ( parseFloat( getComputedStyle( stage ).rowGap ) || 16 );
			var rowH = 0, i, r, c;
			for ( i = 0; i < tiles.length; i++ ) { tw[ i ] = tiles[ i ].offsetWidth; th[ i ] = tiles[ i ].offsetHeight; if ( th[ i ] > rowH ) { rowH = th[ i ]; } }
			PITCH = rowH + GAP; HS = ROWS * PITCH;
			for ( r = 0; r < ROWS; r++ ) {
				var sum = 0; for ( c = 0; c < COLS; c++ ) { sum += tw[ r * COLS + c ] || 0; }
				rowW[ r ] = sum + GAP * COLS;
				var left = -( sum + GAP * ( COLS - 1 ) ) / 2;
				for ( c = 0; c < COLS; c++ ) { i = r * COLS + c; cx[ i ] = left + ( tw[ i ] || 0 ) / 2; left += ( tw[ i ] || 0 ) + GAP; cy[ i ] = ( r - ( ROWS - 1 ) / 2 ) * PITCH; }
			}
			apply();
		}
		function apply() {
			if ( ! VW ) { return; }
			for ( var i = 0; i < tiles.length; i++ ) {
				var px = wrapP( cx[ i ] + x, rowW[ Math.floor( i / COLS ) ] ), py = wrapP( cy[ i ] + y, HS );
				var k = Math.min( 1, Math.sqrt( ( px / VW ) * ( px / VW ) + ( py / VH ) * ( py / VH ) ) * 1.4 );
				tiles[ i ].style.transform = 'translate(' + ( VW / 2 + px - tw[ i ] / 2 ).toFixed( 1 ) + 'px,' + ( VH / 2 + py - th[ i ] / 2 ).toFixed( 1 ) + 'px) scale(' + ( 1 - 0.2 * k ).toFixed( 3 ) + ')';
				tiles[ i ].style.opacity = ( 1 - 0.5 * k ).toFixed( 3 );
			}
		}
		function loop( now ) {
			if ( ! vis ) { running = false; return; }   // off-screen: the loop stops and restarts when visible again
			var f = Math.min( 3, ( now - last ) / 16.67 ); last = now;
			var px = x, py = y;
			if ( dragging ) { lastAct = now; dvx = dvy = 0; } else {
				var idle = ! mql.matches && cfg.drift && ! modalOpen && ! hoverTile && ( now - lastAct > ( cfg.idle || 0 ) * 1000 ), wx = 0, wy = 0;
				if ( idle ) {
					if ( now > tNext ) { ang += ( Math.random() - 0.5 ) * 2.6; tNext = now + 3500 + Math.random() * 4500; }
					ang += ( Math.random() - 0.5 ) * 0.03 * f;
					var sp = ( cfg.driftSpeed || 36 ) / 60; wx = Math.cos( ang ) * sp; wy = Math.sin( ang ) * sp;
				}
				dvx += ( wx - dvx ) * 0.03 * f; dvy += ( wy - dvy ) * 0.03 * f;
				x += ( vx + dvx ) * f; y += ( vy + dvy ) * f;
				var dec = Math.pow( 0.93, f ); vx *= dec; vy *= dec;
				if ( Math.abs( vx ) < 0.01 ) { vx = 0; } if ( Math.abs( vy ) < 0.01 ) { vy = 0; }
			}
			if ( x !== px || y !== py ) { apply(); }
			if ( d.body.contains( root ) ) { w.requestAnimationFrame( loop ); } else { running = false; }
		}
		function kick() { if ( vis && ! running && ! inEditor ) { running = true; last = performance.now(); w.requestAnimationFrame( loop ); } }
		function touched() { lastAct = performance.now(); kick(); }

		root.classList.add( 'is-on' ); if ( fine ) { root.classList.add( 'fine' ); } if ( cfg.wheel ) { root.classList.add( 'is-trap' ); }
		measure();
		var rz; w.addEventListener( 'resize', function () { clearTimeout( rz ); rz = setTimeout( measure, 120 ); } );
		if ( 'IntersectionObserver' in w ) {
			new IntersectionObserver( function ( es ) {
				vis = es.some( function ( e ) { return e.isIntersecting; } );
				if ( vis ) { if ( ! VW ) { measure(); } lastAct = performance.now(); tNext = lastAct + 4000; kick(); } else { stopAllPv(); }
			}, { rootMargin: '80px' } ).observe( root );
		} else { vis = true; kick(); }
		if ( inEditor ) { root.classList.add( 'is-static' ); return; }

		/* --- cursor propio (solo ratón) --- */
		var cursor = null, ctext = null;
		var ARROWS = '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 4v16M4 12h16"/><path d="m9 7 3-3 3 3M9 17l3 3 3-3M7 9l-3 3 3 3M17 9l3 3-3 3"/></svg>';
		function setCur( st ) { if ( ! cursor ) { return; } cursor.dataset.s = st; if ( 'go' === st ) { ctext.textContent = cfg.go || ''; } else { ctext.innerHTML = ARROWS; } }
		function zone( e ) { return e.target && e.target.closest && e.target.closest( '.wks-vw__tile' ) ? 'go' : 'drag'; }
		if ( fine && cfg.cursor ) {
			cursor = S.el( 'div', { 'class': 'wks-vw-cur', 'aria-hidden': 'true' }, [ S.el( 'div', { 'class': 'c' } ) ] );
			ctext = cursor.firstChild; cursor.style.setProperty( '--vw-go', getComputedStyle( root ).getPropertyValue( '--vw-go' ) || '#FF5A5F' ); d.body.appendChild( cursor ); setCur( 'drag' );
		}

		/* --- vista previa muda (máx. cfg.maxPv a la vez; el vídeo no existe hasta entonces) --- */
		var pvs = [], intent = 0;
		function stopPv( rec ) {
			clearTimeout( rec.timer ); var i = pvs.indexOf( rec ); if ( i > -1 ) { pvs.splice( i, 1 ); }
			rec.tile.classList.remove( 'pv' );
			if ( rec.video ) { rec.video.pause(); rec.video.removeAttribute( 'src' ); rec.video.load(); rec.video.remove(); }
		}
		function stopAllPv() { pvs.slice().forEach( stopPv ); }
		function startPv( t ) {
			if ( ! cfg.preview || mql.matches ) { return; }
			var url = t.getAttribute( 'data-video' ); if ( ! url ) { return; }
			if ( pvs.some( function ( p ) { return p.tile === t; } ) ) { return; }
			while ( pvs.length >= ( cfg.maxPv || 1 ) ) { stopPv( pvs[ 0 ] ); }
			var v = d.createElement( 'video' ); v.muted = true; v.defaultMuted = true; v.playsInline = true; v.loop = true; v.preload = 'auto';
			if ( t.getAttribute( 'data-poster' ) ) { v.poster = t.getAttribute( 'data-poster' ); }
			v.src = url; v.setAttribute( 'aria-hidden', 'true' ); v.tabIndex = -1; t.appendChild( v ); t.classList.add( 'pv' );
			var pr = v.play(); if ( pr && pr.catch ) { pr.catch( function () {} ); }
			var rec = { tile: t, video: v, timer: 0 }; rec.timer = setTimeout( function () { stopPv( rec ); }, cfg.preview * 1000 ); pvs.push( rec );
		}

		/* --- ventana con sonido --- */
		var modal = null, opener = null;
		function focusables() { return [].slice.call( modal.querySelectorAll( 'button, video[controls], [tabindex="0"]' ) ); }
		function onKey( e ) {
			if ( ! modal ) { return; }
			if ( 'Escape' === e.key ) { e.preventDefault(); closeModal(); return; }
			if ( 'Tab' === e.key ) {
				var f = focusables(); if ( ! f.length ) { return; }
				var i = f.indexOf( d.activeElement );
				if ( e.shiftKey && i <= 0 ) { e.preventDefault(); f[ f.length - 1 ].focus(); } else if ( ! e.shiftKey && i === f.length - 1 ) { e.preventDefault(); f[ 0 ].focus(); }
			}
		}
		function closeModal() {
			if ( ! modal ) { return; }
			var v = modal.querySelector( 'video' ); if ( v ) { v.pause(); v.removeAttribute( 'src' ); v.load(); }
			modal.remove(); modal = null; modalOpen = false; stage.inert = false; d.removeEventListener( 'keydown', onKey, true );
			if ( opener ) { opener.focus( { preventScroll: true } ); } touched();
		}
		function openModal( t ) {
			stopAllPv(); opener = t; modalOpen = true; stage.inert = true; if ( cursor ) { cursor.classList.remove( 'on' ); }
			var url = t.getAttribute( 'data-video' ), poster = t.getAttribute( 'data-poster' ), cat = t.getAttribute( 'data-cat' ), title = t.getAttribute( 'data-title' ) || '';
			var kcls = ( t.className.match( /\bk\d\b/ ) || [ '' ] )[ 0 ], orient = t.classList.contains( 'is-P' ) ? 'P' : 'L';
			var media;
			if ( url ) {
				media = S.el( 'video', { controls: '', playsinline: '', autoplay: '', preload: 'auto', poster: poster || null, src: url } );
			} else {
				media = S.el( 'div', { 'class': 'wks-vw-mph' }, [ poster ? S.el( 'img', { src: poster, alt: '' } ) : null, S.el( 'small', { text: cfg.nofile || '' } ) ] );
			}
			var meta = S.el( 'div', { 'class': 'wks-vw-mmeta' }, [ S.el( 'span', { text: title } ) ] );
			if ( cat ) { var tag = S.el( 'span', { 'class': 't', text: cat } ); tag.style.background = t.getAttribute( 'data-cc' ) || ''; tag.style.color = t.getAttribute( 'data-cf' ) || ''; meta.appendChild( tag ); }
			var close = S.el( 'button', { type: 'button', 'class': 'wks-vw-mclose', 'aria-label': cfg.close || 'Close', text: '✕' } );
			modal = S.el( 'div', { 'class': 'wks-vw-modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': title || null }, [
				S.el( 'div', { 'class': 'wks-vw-mbox ' + orient }, [ close, S.el( 'div', { 'class': 'wks-vw-mmedia ' + ( url || poster ? '' : kcls ) }, [ media ] ), meta ] )
			] );
			modal.style.setProperty( '--vw-edge', getComputedStyle( root ).getPropertyValue( '--vw-edge' ) || '' );
			d.body.appendChild( modal ); d.addEventListener( 'keydown', onKey, true );
			modal.addEventListener( 'click', function ( e ) { if ( e.target === modal ) { closeModal(); } } );
			close.addEventListener( 'click', closeModal ); close.focus( { preventScroll: true } );
			if ( url ) { var pr = media.play(); if ( pr && pr.catch ) { pr.catch( function () {} ); } }
		}

		/* --- arrastre --- */
		stage.addEventListener( 'pointerdown', function ( e ) {
			if ( 0 !== e.button || modalOpen ) { return; }
			dragging = true; moved = false; sx = lx = e.clientX; sy = ly = e.clientY; vx = vy = 0; touched();
		} );
		w.addEventListener( 'pointermove', function ( e ) {
			if ( cursor && 'mouse' === e.pointerType && ! modalOpen ) {
				var inside = root.contains( e.target );
				cursor.classList.toggle( 'on', inside );
				if ( inside ) { cursor.style.transform = 'translate(' + e.clientX + 'px,' + e.clientY + 'px)'; if ( ! dragging || ! moved ) { var z = zone( e ); if ( cursor.dataset.s !== z ) { setCur( z ); } } }
			}
			if ( ! dragging ) { return; }
			if ( ! moved && Math.hypot( e.clientX - sx, e.clientY - sy ) > 6 ) { moved = true; stopAllPv(); setCur( 'grab' ); }
			if ( ! moved ) { return; }
			var dx = e.clientX - lx, dy = e.clientY - ly; lx = e.clientX; ly = e.clientY;
			x += dx; y += dy; vx = dx; vy = dy; apply();
		} );
		function release( e ) { dragging = false; touched(); if ( e && e.target && cursor ) { setCur( zone( e ) ); } }
		w.addEventListener( 'pointerup', function ( e ) { if ( dragging ) { release( e ); } } );
		w.addEventListener( 'pointercancel', function ( e ) { if ( dragging ) { release( e ); } } );
		stage.addEventListener( 'click', function ( e ) {
			var t = e.target.closest( '.wks-vw__tile' );
			if ( ! t || moved ) { moved = false; return; }
			if ( cfg.popup ) { openModal( t ); } else { startPv( t ); }
		}, true );
		tiles.forEach( function ( t ) {
			t.addEventListener( 'pointerenter', function ( e ) {
				hoverTile = true;
				if ( 'mouse' === e.pointerType && ! dragging && ! modalOpen ) { clearTimeout( intent ); intent = setTimeout( function () { startPv( t ); }, 280 ); }
			} );
			t.addEventListener( 'pointerleave', function () { hoverTile = false; clearTimeout( intent ); } );
		} );
		if ( cfg.wheel && fine ) {
			stage.addEventListener( 'wheel', function ( e ) { e.preventDefault(); touched(); var h = e.shiftKey && ! e.deltaX; x -= h ? e.deltaY : e.deltaX; y -= h ? 0 : e.deltaY; vx = vy = 0; apply(); }, { passive: false } );
		}
		stage.addEventListener( 'scroll', function () { stage.scrollTop = 0; stage.scrollLeft = 0; } );
		root.addEventListener( 'keydown', function ( e ) {
			if ( modalOpen ) { return; }
			var st = 15;
			if ( 'ArrowLeft' === e.key ) { vx = st; } else if ( 'ArrowRight' === e.key ) { vx = -st; } else if ( 'ArrowUp' === e.key ) { vy = st; } else if ( 'ArrowDown' === e.key ) { vy = -st; } else { return; }
			e.preventDefault(); touched();
		} );
	} );
}( window, document ) );
