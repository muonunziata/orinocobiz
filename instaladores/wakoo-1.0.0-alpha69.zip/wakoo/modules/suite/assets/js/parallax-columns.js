( function () {
	'use strict';
	var cols = [], queued = false, bound = false;
	function update() {
		var vh = window.innerHeight;
		cols.forEach( function ( c ) {
			if ( ! document.body.contains( c.el ) || ! c.on ) { return; }
			var b = c.el.parentNode.getBoundingClientRect();
			if ( b.bottom < -200 || b.top > vh + 200 ) { return; }
			// Se mide la sección (no la columna) para no realimentar el propio desplazamiento.
			var mid = b.top + b.height / 2 - vh / 2;
			c.el.style.translate = '0 ' + ( mid * c.k ).toFixed( 1 ) + 'px';
		} );
		queued = false;
	}
	function onScroll() { if ( ! queued ) { queued = true; requestAnimationFrame( update ); } }

	WakooSuiteApi.define( 'parallax-columns', function ( root, cfg, S ) {
		if ( ! cfg.par || S.reduced() || document.documentElement.classList.contains( 'elementor-editor-active' ) ) { return; }
		var mq = window.matchMedia ? window.matchMedia( '(prefers-reduced-motion: reduce)' ) : null;
		var mine = [];
		[].forEach.call( root.querySelectorAll( '[data-par]' ), function ( el ) {
			var o = { el: el, k: parseFloat( el.getAttribute( 'data-par' ) ) || 0, on: true };
			mine.push( o ); cols.push( o );
		} );
		if ( mq && mq.addEventListener ) {
			mq.addEventListener( 'change', function () {
				var off = mq.matches;
				mine.forEach( function ( o ) { o.on = ! off; if ( off ) { o.el.style.translate = ''; } } );
				if ( ! off ) { update(); }
			} );
		}
		if ( ! bound ) {
			bound = true;
			window.addEventListener( 'scroll', onScroll, { passive: true } );
			window.addEventListener( 'resize', onScroll, { passive: true } );
		}
		update();
	} );
}() );
