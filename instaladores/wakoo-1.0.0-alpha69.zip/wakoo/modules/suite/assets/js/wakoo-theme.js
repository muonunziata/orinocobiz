/* Wakoo theme (modo diurno/nocturno): tiny shared API used by the Dark mode widget and the Content switcher.
 * WakooTheme.get() -> 'dark'|'light'; set(mode) persists the visitor's choice; toggle(); on(fn); config(cfg). */
( function ( w, d ) {
	'use strict';
	if ( w.WakooTheme ) { return; }
	var KEY = 'wakoo-theme', root = d.documentElement, subs = [], cfg = w.WakooThemeCfg || null, mq = null;

	function read() { try { var v = w.localStorage.getItem( KEY ); return 'dark' === v || 'light' === v ? v : null; } catch ( e ) { return null; } }
	function write( v ) { try { if ( v ) { w.localStorage.setItem( KEY, v ); } else { w.localStorage.removeItem( KEY ); } } catch ( e ) {} }
	function dark() { return !! ( w.matchMedia && w.matchMedia( '(prefers-color-scheme: dark)' ).matches ); }
	function auto() {
		var c = cfg || {};
		if ( c.sched ) {
			var h = new Date().getHours(), f = +c.from, t = +c.to;
			return ( f <= t ? h >= f && h < t : h >= f || h < t ) ? 'dark' : 'light';
		}
		return dark() ? 'dark' : 'light';
	}
	function initial() {
		var def = cfg && cfg.def ? cfg.def : 'light';
		return 'auto' === def ? auto() : ( 'dark' === def ? 'dark' : 'light' );
	}
	function current() { return read() || initial(); }
	function animate() {
		if ( w.matchMedia && w.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) { return; }
		root.classList.add( 'wakoo-theme-anim' );
		setTimeout( function () { root.classList.remove( 'wakoo-theme-anim' ); }, 400 );
	}
	function apply( m, anim ) {
		if ( anim ) { animate(); }
		root.setAttribute( 'data-wakoo-dm', ( cfg && cfg.method ) || 'invert' );
		root.setAttribute( 'data-wakoo-theme', m );
		root.style.colorScheme = m;
		subs.forEach( function ( f ) { try { f( m ); } catch ( e ) {} } );
		try { w.dispatchEvent( new CustomEvent( 'wakoo:theme', { detail: { mode: m } } ) ); } catch ( e ) {}
	}

	var API = w.WakooTheme = {
		get: function () { return root.getAttribute( 'data-wakoo-theme' ) || current(); },
		set: function ( m ) { if ( 'dark' !== m && 'light' !== m ) { return; } write( m ); apply( m, true ); },
		toggle: function () { API.set( 'dark' === API.get() ? 'light' : 'dark' ); },
		reset: function () { write( null ); apply( current(), true ); },
		on: function ( f ) { subs.push( f ); },
		/** Called by the Dark mode widget when the head script was not printed (e.g. first view after saving). */
		config: function ( c ) {
			if ( ! cfg && c ) { cfg = c; w.WakooThemeCfg = c; apply( current(), false ); }
		}
	};

	apply( current(), false );
	try {
		mq = w.matchMedia( '(prefers-color-scheme: dark)' );
		var onmq = function () { if ( ! read() && cfg && 'auto' === cfg.def && ! cfg.sched ) { apply( auto(), true ); } };
		if ( mq.addEventListener ) { mq.addEventListener( 'change', onmq ); } else if ( mq.addListener ) { mq.addListener( onmq ); }
	} catch ( e ) {}
	w.addEventListener( 'storage', function ( e ) { if ( e.key === KEY ) { apply( current(), true ); } } );

	/* Content switcher bridge: .wk-content-switcher-wrapper[data-wk-theme-site] -> first state = day, second = night. */
	function csWrap( el ) { return el && el.closest ? el.closest( '.wk-content-switcher-wrapper' ) : null; }
	function csSync( m ) {
		d.querySelectorAll( '.wk-content-switcher-wrapper[data-wk-theme-site]' ).forEach( function ( wr ) {
			var inp = wr.querySelector( 'input.wk-cs-toggle-switch' );
			var night = 'dark' === m;
			if ( inp ) {
				if ( inp.checked !== night ) { inp.checked = night; csShow( wr, night ); }
				wr.classList.toggle( 'is-night', night );
			} else {
				var bs = wr.querySelectorAll( '.wk-cs-button' ), on = bs[ night ? 1 : 0 ];
				if ( on && ! on.classList.contains( 'active' ) ) { on.click(); }
			}
		} );
	}
	function csShow( wr, night ) {
		var p = wr.querySelectorAll( '.primary' ), s = wr.querySelectorAll( '.secondary' );
		p.forEach( function ( e ) { e.classList.toggle( 'active', ! night ); } );
		s.forEach( function ( e ) { e.classList.toggle( 'active', night ); } );
		csPause( wr );
	}
	/** Pauses audio/video inside the sections that are no longer visible. */
	function csPause( wr ) {
		wr.querySelectorAll( '.wk-cs-content-section:not(.active) audio, .wk-cs-content-section:not(.active) video' ).forEach( function ( m ) { try { m.pause(); } catch ( e ) {} } );
	}
	d.addEventListener( 'change', function ( e ) {
		var t = e.target;
		if ( ! t || ! t.classList || ! t.classList.contains( 'wk-cs-toggle-switch' ) ) { return; }
		var wr = csWrap( t );
		if ( ! wr ) { return; }
		wr.classList.toggle( 'is-night', t.checked );
		csPause( wr );
		if ( wr.hasAttribute( 'data-wk-theme-site' ) ) { API.set( t.checked ? 'dark' : 'light' ); }
	} );
	d.addEventListener( 'click', function ( e ) {
		var b = e.target && e.target.closest ? e.target.closest( '.wk-cs-button' ) : null, wr = csWrap( b );
		if ( ! wr ) { return; }
		setTimeout( function () { csPause( wr ); }, 0 );
		if ( wr.hasAttribute( 'data-wk-theme-site' ) ) {
			var i = Array.prototype.indexOf.call( wr.querySelectorAll( '.wk-cs-button' ), b );
			if ( 0 === i || 1 === i ) { API.set( 1 === i ? 'dark' : 'light' ); }
		}
	} );
	subs.push( csSync );
	function boot() { csSync( API.get() ); }
	if ( 'loading' === d.readyState ) { d.addEventListener( 'DOMContentLoaded', boot ); } else { boot(); }
	if ( w.jQuery ) { w.jQuery( w ).on( 'elementor/frontend/init', function () {
		if ( w.elementorFrontend && w.elementorFrontend.hooks ) { w.elementorFrontend.hooks.addAction( 'frontend/element_ready/wk-content-switcher.default', boot ); }
	} ); }
}( window, document ) );
