( function () {
	'use strict';
	var active = null; // only one player at a time
	var ctxAudio = null;

	function fmt( t ) { t = isFinite( t ) ? Math.floor( t ) : 0; return Math.floor( t / 60 ) + ':' + ( '0' + ( t % 60 ) ).slice( -2 ); }
	function sameOrigin( u ) { try { return new URL( u, location.href ).origin === location.origin; } catch ( e ) { return false; } }
	function fakePeaks( n, seed ) {
		var a = [], x = seed || 7;
		for ( var i = 0; i < n; i++ ) { x = ( x * 9301 + 49297 ) % 233280; a.push( .25 + .6 * Math.abs( Math.sin( i / 5 ) ) * ( .5 + x / 466560 ) ); }
		return a;
	}

	WakooSuiteApi.define( 'audio', function ( root, cfg, S ) {
		var tracks = [];
		try { tracks = JSON.parse( root.querySelector( '.wks-audio__data' ).textContent ); } catch ( e ) {}
		if ( ! tracks.length ) { return; }
		var audio = new Audio(); audio.preload = 'none';
		var wave = root.querySelector( '.wks-audio__wave' ), canvas = wave.querySelector( 'canvas' ), c = canvas.getContext( '2d' );
		var play = root.querySelector( '.wks-audio__play' ), time = root.querySelector( '.wks-audio__time' );
		var cur = 0, peaks = fakePeaks( cfg.bars || 96 ), seen = false, decodeToken = 0;

		function draw() {
			var w = canvas.clientWidth, h = canvas.clientHeight, dpr = window.devicePixelRatio || 1;
			if ( ! w ) { return; }
			if ( canvas.width !== w * dpr ) { canvas.width = w * dpr; canvas.height = h * dpr; }
			c.setTransform( dpr, 0, 0, dpr, 0, 0 ); c.clearRect( 0, 0, w, h );
			var st = getComputedStyle( root ), accent = st.getPropertyValue( '--wks-accent' ).trim() || '#6C5CE7';
			var n = peaks.length, bw = w / n, prog = audio.duration ? audio.currentTime / audio.duration : 0;
			for ( var i = 0; i < n; i++ ) {
				var bh = Math.max( 2, peaks[ i ] * h );
				c.fillStyle = ( i / n ) < prog ? accent : 'rgba(127,127,127,.4)';
				c.fillRect( i * bw + 1, ( h - bh ) / 2, Math.max( 1, bw - 2 ), bh );
			}
		}
		function ui() {
			time.textContent = fmt( audio.currentTime ) + ' / ' + fmt( audio.duration );
			wave.setAttribute( 'aria-valuenow', audio.duration ? Math.round( audio.currentTime / audio.duration * 100 ) : 0 );
			draw();
		}
		function setPlayIcon() {
			play.innerHTML = audio.paused ? '&#9654;' : '&#10074;&#10074;';
			play.setAttribute( 'aria-label', audio.paused ? 'Reproducir' : 'Pausar' );
		}
		function decode( src, token ) {
			if ( ! sameOrigin( src ) || ! ( window.AudioContext || window.webkitAudioContext ) ) { return; }
			fetch( src, { credentials: 'omit' } ).then( function ( r ) { return r.arrayBuffer(); } ).then( function ( buf ) {
				ctxAudio = ctxAudio || new ( window.AudioContext || window.webkitAudioContext )();
				return new Promise( function ( res, rej ) { ctxAudio.decodeAudioData( buf, res, rej ); } );
			} ).then( function ( ab ) {
				if ( token !== decodeToken ) { return; }
				var data = ab.getChannelData( 0 ), n = cfg.bars || 96, size = Math.floor( data.length / n ) || 1, out = [], max = 0.0001, i, j;
				for ( i = 0; i < n; i++ ) { var sum = 0, from = i * size, cnt = 0; for ( j = from; j < from + size && j < data.length; j += 16 ) { sum += Math.abs( data[ j ] ); cnt++; } out.push( cnt ? sum / cnt : 0 ); max = Math.max( max, out[ i ] ); }
				peaks = out.map( function ( v ) { return Math.max( .06, v / max ); } );
				draw();
			} ).catch( function () {} );
		}
		function load( i, autoplay ) {
			cur = ( i + tracks.length ) % tracks.length;
			var t = tracks[ cur ];
			audio.src = t.src; audio.load();
			root.querySelector( '.wks-audio__title' ).textContent = t.title;
			root.querySelector( '.wks-audio__artist' ).textContent = t.artist ? '— ' + t.artist : '';
			root.querySelectorAll( '.wks-audio__track' ).forEach( function ( b ) { b.classList.toggle( 'is-active', parseInt( b.getAttribute( 'data-i' ), 10 ) === cur ); } );
			peaks = fakePeaks( cfg.bars || 96, cur + 3 ); draw();
			decodeToken++;
			if ( seen ) { decode( t.src, decodeToken ); }
			if ( autoplay ) { toggle( true ); }
		}
		function toggle( force ) {
			var want = 'boolean' === typeof force ? force : audio.paused;
			if ( want ) {
				if ( active && active !== audio ) { active.pause(); }
				active = audio;
				var p = audio.play(); if ( p && p.catch ) { p.catch( function () {} ); }
			} else { audio.pause(); }
		}
		play.addEventListener( 'click', function () { toggle(); } );
		audio.addEventListener( 'play', function () { if ( active && active !== audio ) { active.pause(); } active = audio; setPlayIcon(); } );
		audio.addEventListener( 'pause', setPlayIcon );
		audio.addEventListener( 'timeupdate', ui );
		audio.addEventListener( 'loadedmetadata', ui );
		audio.addEventListener( 'ended', function () { setPlayIcon(); if ( cfg.autonext && tracks.length > 1 && cur < tracks.length - 1 ) { load( cur + 1, true ); } } );
		function seekFrom( e ) {
			var r = wave.getBoundingClientRect();
			if ( audio.duration ) { audio.currentTime = Math.min( 1, Math.max( 0, ( e.clientX - r.left ) / r.width ) ) * audio.duration; }
		}
		wave.addEventListener( 'click', seekFrom );
		wave.addEventListener( 'keydown', function ( e ) {
			var k = e.key;
			if ( ' ' === k || 'Enter' === k ) { toggle(); } else if ( 'ArrowRight' === k ) { audio.currentTime = Math.min( audio.duration || 0, audio.currentTime + 5 ); }
			else if ( 'ArrowLeft' === k ) { audio.currentTime = Math.max( 0, audio.currentTime - 5 ); }
			else if ( 'ArrowUp' === k ) { audio.volume = Math.min( 1, audio.volume + .1 ); syncVol(); }
			else if ( 'ArrowDown' === k ) { audio.volume = Math.max( 0, audio.volume - .1 ); syncVol(); }
			else { return; }
			e.preventDefault();
		} );
		var sp = root.querySelector( '.wks-audio__speed' ), vol = root.querySelector( '.wks-audio__vol' );
		function syncVol() { if ( vol ) { vol.value = audio.volume; } }
		if ( sp ) { sp.addEventListener( 'change', function () { audio.playbackRate = parseFloat( sp.value ) || 1; } ); }
		if ( vol ) { vol.addEventListener( 'input', function () { audio.volume = parseFloat( vol.value ); } ); }
		root.querySelectorAll( '.wks-audio__track' ).forEach( function ( b ) { b.addEventListener( 'click', function () { load( parseInt( b.getAttribute( 'data-i' ), 10 ), true ); } ); } );
		window.addEventListener( 'resize', draw );
		load( 0, false ); setPlayIcon();
		S.visible( root, function () { seen = true; decode( tracks[ cur ].src, decodeToken ); draw(); } );
	} );
}() );
