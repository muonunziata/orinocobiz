( function () {
	'use strict';
	WakooSuiteApi.define( 'faq', function ( root, cfg ) {
		var items = root.querySelectorAll( '.wks-faq__item' ), groups = root.querySelectorAll( '.wks-faq__group' ), none = root.querySelector( '.wks-faq__none' );
		var search = root.querySelector( '.wks-faq__search' ), group = '*';

		function toggle( item, open ) {
			var btn = item.querySelector( 'button' ), ans = item.querySelector( '.wks-faq__a' );
			btn.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
			ans.hidden = ! open;
			item.classList.toggle( 'is-open', open );
		}
		items.forEach( function ( item ) {
			item.querySelector( 'button' ).addEventListener( 'click', function () {
				var open = item.querySelector( 'button' ).getAttribute( 'aria-expanded' ) !== 'true';
				if ( open && ! cfg.multi ) { items.forEach( function ( o ) { if ( o !== item ) { toggle( o, false ); } } ); }
				toggle( item, open );
			} );
		} );

		function filter() {
			var q = search ? search.value.trim().toLowerCase() : '', shown = 0;
			groups.forEach( function ( g ) {
				var inGroup = '*' === group || g.getAttribute( 'data-g' ) === group, any = 0;
				g.querySelectorAll( '.wks-faq__item' ).forEach( function ( it ) {
					var hit = inGroup && ( ! q || it.textContent.toLowerCase().indexOf( q ) > -1 );
					it.hidden = ! hit;
					if ( hit ) { any++; if ( q ) { toggle( it, true ); } }
				} );
				g.hidden = ! any;
				shown += any;
			} );
			none.hidden = shown > 0;
		}
		if ( search ) { search.addEventListener( 'input', filter ); }
		root.querySelectorAll( '.wks-faq__tabs .wks-chip' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				root.querySelectorAll( '.wks-faq__tabs .wks-chip' ).forEach( function ( o ) { o.classList.toggle( 'is-active', o === b ); } );
				group = b.getAttribute( 'data-g' );
				filter();
			} );
		} );
	} );
}() );
