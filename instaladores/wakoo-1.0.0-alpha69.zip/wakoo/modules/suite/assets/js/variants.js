( function () {
	'use strict';
	WakooSuiteApi.define( 'variants', function ( root, cfg, S ) {
		var el = S.el, groupsBox = root.querySelector( '.wks-var__groups' ), priceBox = root.querySelector( '.wks-var__price' ),
			stockBox = root.querySelector( '.wks-var__stock' ), ctaBox = root.querySelector( '.wks-var__cta' );
		var sel = cfg.attrs.map( function () { return null; } ), btns = [];

		function money( n ) {
			var t = n.toLocaleString( undefined, { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 } );
			return cfg.after ? t + ' ' + cfg.cur : cfg.cur + t;
		}
		function match( v, skip ) {
			return v.o.every( function ( o, i ) { return i === skip || null === sel[ i ] || o === sel[ i ]; } );
		}
		function current() {
			if ( sel.indexOf( null ) > -1 ) { return null; }
			return cfg.vars.filter( function ( v ) { return match( v, -1 ); } )[ 0 ] || null;
		}
		cfg.attrs.forEach( function ( a, gi ) {
			var row = el( 'div', { class: 'wks-var__group', role: 'radiogroup', 'aria-label': a.name } );
			var list = el( 'div', { class: 'wks-var__opts' } );
			a.values.forEach( function ( val ) {
				var b = el( 'button', { type: 'button', class: 'wks-chip', role: 'radio', 'aria-checked': 'false', text: val } );
				b.addEventListener( 'click', function () {
					if ( b.disabled ) { return; }
					sel[ gi ] = sel[ gi ] === val ? null : val;
					update();
				} );
				btns.push( { b: b, gi: gi, val: val } );
				list.appendChild( b );
			} );
			row.appendChild( el( 'div', { class: 'wks-var__label', text: a.name } ) );
			row.appendChild( list );
			groupsBox.appendChild( row );
		} );

		function update() {
			btns.forEach( function ( o ) {
				var on = sel[ o.gi ] === o.val;
				// an option is available when some in-stock variant matches the other choices
				var ok = cfg.vars.some( function ( v ) { return v.s > 0 && v.o[ o.gi ] === o.val && match( v, o.gi ); } );
				o.b.disabled = ! ok && ! on;
				o.b.classList.toggle( 'is-active', on );
				o.b.setAttribute( 'aria-checked', on ? 'true' : 'false' );
			} );
			var v = current();
			ctaBox.textContent = '';
			if ( ! v ) {
				var prices = cfg.vars.map( function ( x ) { return x.p; } );
				priceBox.textContent = prices.length ? ( Math.min.apply( null, prices ) === Math.max.apply( null, prices ) ? money( prices[ 0 ] ) : money( Math.min.apply( null, prices ) ) + ' – ' + money( Math.max.apply( null, prices ) ) ) : '';
				stockBox.textContent = cfg.pick; stockBox.className = 'wks-var__stock';
				return;
			}
			priceBox.textContent = money( v.p );
			stockBox.className = 'wks-var__stock ' + ( v.s <= 0 ? 'is-out' : v.s <= cfg.low ? 'is-low' : 'is-in' );
			stockBox.textContent = v.s <= 0 ? cfg.out : v.s <= cfg.low ? cfg.lowtxt + ' (' + v.s + ')' : cfg.in;
			if ( v.s > 0 && cfg.url ) {
				var href = cfg.url;
				if ( cfg.append ) {
					var label = cfg.msg + ' ' + cfg.name + ' – ' + cfg.attrs.map( function ( a, i ) { return a.name + ': ' + sel[ i ]; } ).join( ', ' ) + ( v.k ? ' (' + v.k + ')' : '' ) + ' – ' + money( v.p );
					var hash = href.indexOf( '#' ); var tail = '';
					if ( hash > -1 ) { tail = href.slice( hash ); href = href.slice( 0, hash ); }
					href += ( href.indexOf( '?' ) < 0 ? '?' : '&' ) + encodeURIComponent( cfg.param ) + '=' + encodeURIComponent( label ) + tail;
				}
				var a = el( 'a', { class: 'wks-btn', href: href, text: cfg.cta } );
				if ( cfg.blank ) { a.target = '_blank'; a.rel = 'noopener noreferrer'; }
				ctaBox.appendChild( a );
			}
		}
		update();
	} );
}() );
