( function () {
	'use strict';
	WakooSuiteApi.define( 'rotator', function ( root, cfg, S ) {
		var track = root.querySelector( '.wks-rot__track' );
		var slides = root.querySelectorAll( '.wks-rot__slide' );
		var dots = root.querySelectorAll( '.wks-rot__dot' );
		var toggle = root.querySelector( '.wks-rot__toggle' );
		if ( ! track || slides.length < 2 ) { return; }
		var cur = 0, timer = null, paused = false, hold = false, seen = false;

		function go( i, user ) {
			cur = ( i + slides.length ) % slides.length;
			track.scrollTo( { left: slides[ cur ].offsetLeft - ( track.clientWidth - slides[ cur ].offsetWidth ) / 2, behavior: S.reduced() ? 'auto' : 'smooth' } );
			mark();
			if ( user ) { restart(); }
		}
		function mark() {
			slides.forEach( function ( s, k ) { s.classList.toggle( 'is-on', k === cur ); s.setAttribute( 'aria-hidden', k === cur ? 'false' : 'true' ); } );
			dots.forEach( function ( d, k ) { d.classList.toggle( 'is-on', k === cur ); d.setAttribute( 'aria-current', k === cur ? 'true' : 'false' ); } );
		}
		// Autoplay runs only while visible, not hovered/focused, not paused and without reduced motion.
		function refill() { dots.forEach( function ( d ) { var i = d.querySelector( 'i' ); i.style.animation = 'none'; void i.offsetWidth; i.style.animation = ''; } ); }
		function restart() {
			clearInterval( timer );
			var run = cfg.auto && ! paused && ! hold && seen && ! S.reduced();
			root.classList.toggle( 'is-run', !! run );
			if ( ! run ) { return; }
			root.style.setProperty( '--wks-rot-delay', cfg.delay + 's' );
			refill();
			timer = setInterval( function () { go( cur + 1 ); refill(); }, cfg.delay * 1000 );
		}

		// Swipe or trackpad scroll: follow the slide that ends up centred.
		var t;
		track.addEventListener( 'scroll', function () {
			clearTimeout( t );
			t = setTimeout( function () {
				var mid = track.scrollLeft + track.clientWidth / 2, best = 0, dist = 1e9;
				slides.forEach( function ( s, k ) { var c = s.offsetLeft + s.offsetWidth / 2, dd = Math.abs( c - mid ); if ( dd < dist ) { dist = dd; best = k; } } );
				if ( best !== cur ) { cur = best; mark(); restart(); }
			}, 120 );
		}, { passive: true } );

		var prev = root.querySelector( '.wks-rot__prev' ), next = root.querySelector( '.wks-rot__next' );
		if ( prev ) { prev.addEventListener( 'click', function () { go( cur - 1, true ); } ); }
		if ( next ) { next.addEventListener( 'click', function () { go( cur + 1, true ); } ); }
		dots.forEach( function ( d, k ) { d.addEventListener( 'click', function () { go( k, true ); } ); } );
		track.addEventListener( 'keydown', function ( e ) {
			if ( 'ArrowRight' === e.key ) { go( cur + 1, true ); e.preventDefault(); } else if ( 'ArrowLeft' === e.key ) { go( cur - 1, true ); e.preventDefault(); }
		} );
		if ( toggle ) {
			toggle.addEventListener( 'click', function () {
				paused = ! paused;
				toggle.setAttribute( 'aria-pressed', paused ? 'true' : 'false' );
				toggle.textContent = paused ? cfg.play : cfg.pause;
				restart();
			} );
		}
		root.addEventListener( 'mouseenter', function () { hold = true; restart(); } );
		root.addEventListener( 'mouseleave', function () { hold = false; restart(); } );
		root.addEventListener( 'focusin', function () { hold = true; restart(); } );
		root.addEventListener( 'focusout', function () { hold = false; restart(); } );
		document.addEventListener( 'visibilitychange', function () { hold = document.hidden; restart(); } );
		if ( 'IntersectionObserver' in window ) {
			new IntersectionObserver( function ( es ) { seen = es[ 0 ].isIntersecting; restart(); }, { threshold: .35 } ).observe( root );
		} else { seen = true; }
		mark();
		restart();
	} );
}() );
