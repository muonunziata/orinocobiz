( function () {
	'use strict';
	WakooSuiteApi.define( 'booking', function ( root, cfg, S ) {
		var app = root.querySelector( '.wks-book__app' ), ctx = S.ctx( root ), el = S.el, t0 = Date.now();
		var sel = el( 'select', { id: 'wkb-svc-' + ctx.w, 'aria-label': 'Servicio' } );
		var groups = {};
		cfg.services.forEach( function ( s ) {
			var g = s.group || '';
			if ( ! groups[ g ] ) { groups[ g ] = g ? el( 'optgroup', { label: g } ) : sel; if ( g ) { sel.appendChild( groups[ g ] ); } }
			groups[ g ].appendChild( el( 'option', { value: s.i, text: s.name + ' (' + s.min + ' min)' + ( s.price ? ' · ' + s.price : '' ) } ) );
		} );
		var date = el( 'input', { type: 'date', id: 'wkb-date-' + ctx.w, min: cfg.min, max: cfg.max, required: 'required' } );
		var slots = el( 'div', { class: 'wks-book__slots', role: 'group', 'aria-label': 'Horas libres' } );
		var chosen = '';
		var name = el( 'input', { type: 'text', required: 'required', maxlength: 100, autocomplete: 'name', id: 'wkb-n-' + ctx.w } );
		var email = el( 'input', { type: 'email', required: 'required', maxlength: 120, autocomplete: 'email', id: 'wkb-e-' + ctx.w } );
		var phone = el( 'input', { type: 'tel', maxlength: 30, autocomplete: 'tel', id: 'wkb-p-' + ctx.w } );
		var note = el( 'textarea', { rows: 3, maxlength: 500, id: 'wkb-o-' + ctx.w } );
		var hp = el( 'input', { type: 'text', name: 'website', tabindex: '-1', autocomplete: 'off', 'aria-hidden': 'true' } );
		var msg = el( 'div', { class: 'wks-msg', role: 'status', 'aria-live': 'polite' } );
		var btn = el( 'button', { type: 'submit', class: 'wks-btn', text: cfg.btn } );
		btn.disabled = true;
		function field( lab, input ) { return el( 'div', { class: 'wks-field' }, [ el( 'label', { 'for': input.id, text: lab } ), input ]); }
		var form = el( 'form', { novalidate: 'novalidate' }, [
			field( 'Servicio', sel ), field( 'Fecha', date ),
			el( 'div', { class: 'wks-field' }, [ el( 'label', { text: 'Hora' } ), slots ] ),
			field( 'Nombre', name ), field( 'Email', email ),
			cfg.phone ? field( 'Teléfono', phone ) : null, cfg.note ? field( 'Comentario', note ) : null,
			el( 'div', { class: 'wks-hp' }, [ hp ] ), btn, msg
		] );
		app.appendChild( form );

		function setMsg( text, ok ) { msg.textContent = text || ''; msg.className = 'wks-msg ' + ( text ? ( ok ? 'is-ok' : 'is-err' ) : '' ); }
		function load() {
			chosen = ''; btn.disabled = true; slots.textContent = '';
			if ( ! date.value ) { return; }
			slots.appendChild( el( 'span', { text: '…' } ) );
			S.api( 'booking/slots', { query: { post: ctx.post, w: ctx.w, service: sel.value, date: date.value } } ).then( function ( r ) {
				slots.textContent = '';
				if ( ! r.ok ) { setMsg( r.error, false ); return; }
				setMsg( '' );
				if ( ! r.slots.length ) { slots.appendChild( el( 'span', { text: 'No hay horas libres ese día.' } ) ); return; }
				r.slots.forEach( function ( h ) {
					var b = el( 'button', { type: 'button', class: 'wks-chip', text: h, 'aria-pressed': 'false' } );
					b.addEventListener( 'click', function () {
						chosen = h; btn.disabled = false;
						slots.querySelectorAll( 'button' ).forEach( function ( o ) { var on = o === b; o.classList.toggle( 'is-active', on ); o.setAttribute( 'aria-pressed', on ? 'true' : 'false' ); } );
					} );
					slots.appendChild( b );
				} );
			} );
		}
		date.addEventListener( 'change', load );
		sel.addEventListener( 'change', load );

		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			if ( ! chosen || ! name.value.trim() || ! email.checkValidity() || ! email.value ) { setMsg( 'Completa fecha, hora, nombre y un email válido.', false ); return; }
			btn.disabled = true;
			S.api( 'booking/create', { data: { post: ctx.post, w: ctx.w, service: parseInt( sel.value, 10 ), date: date.value, time: chosen, name: name.value, email: email.value, phone: phone.value, note: note.value, website: hp.value, t: Date.now() - t0 } } ).then( function ( r ) {
				if ( ! r.ok ) { setMsg( r.error, false ); btn.disabled = false; if ( /disponible/.test( r.error || '' ) ) { load(); } return; }
				done( r );
			} ).catch( function () { setMsg( 'Error de conexión.', false ); btn.disabled = false; } );
		} );

		function pad( n ) { return n < 10 ? '0' + n : '' + n; }
		function done( r ) {
			app.textContent = '';
			var ics = function () {
				var p = r.date.split( '-' ), h = r.time.split( ':' );
				var s = new Date( +p[ 0 ], p[ 1 ] - 1, +p[ 2 ], +h[ 0 ], +h[ 1 ] ), f = new Date( s.getTime() + r.minutes * 60000 );
				var fmt = function ( d ) { return d.getFullYear() + pad( d.getMonth() + 1 ) + pad( d.getDate() ) + 'T' + pad( d.getHours() ) + pad( d.getMinutes() ) + '00'; };
				var txt = [ 'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Wakoo//Booking//ES', 'BEGIN:VEVENT', 'UID:' + Date.now() + '@wakoo', 'DTSTAMP:' + fmt( new Date() ) , 'DTSTART:' + fmt( s ), 'DTEND:' + fmt( f ), 'SUMMARY:' + String( r.service ).replace( /[\r\n,;]/g, ' ' ), 'END:VEVENT', 'END:VCALENDAR' ].join( '\r\n' );
				var a = el( 'a', { href: URL.createObjectURL( new Blob( [ txt ], { type: 'text/calendar' } ) ), download: 'reserva.ics', class: 'wks-btn wks-btn--ghost', text: 'Añadir a mi calendario (.ics)' } );
				return a;
			};
			app.appendChild( el( 'div', { class: 'wks-card wks-book__done', role: 'status' }, [
				el( 'p', { text: cfg.ok } ), el( 'p', { text: r.service + ' · ' + r.date + ' ' + r.time } ), ics()
			] ) );
		}
	} );
}() );
