( function () {
	'use strict';
	WakooSuiteApi.define( 'compare', function ( root, cfg, S ) {
		var el = S.el, table = root.querySelector( '.wks-cmp__table' ), n = cfg.names.length;
		var shown = cfg.names.map( function () { return true; } ), onlyDiff = false;
		var bar = el( 'div', { class: 'wks-cmp__bar' } );

		function visCount() { return shown.filter( Boolean ).length; }
		function apply() {
			table.querySelectorAll( '[data-col]' ).forEach( function ( c ) { c.hidden = ! shown[ +c.getAttribute( 'data-col' ) ]; } );
			var groupRows = table.querySelectorAll( 'tr.wks-cmp__group' );
			table.querySelectorAll( 'tr.wks-cmp__row' ).forEach( function ( tr ) {
				var vs = [];
				tr.querySelectorAll( 'td' ).forEach( function ( td ) { if ( ! td.hidden ) { vs.push( td.textContent ); } } );
				var diff = vs.length > 1 && vs.some( function ( v ) { return v !== vs[ 0 ]; } );
				tr.classList.toggle( 'is-diff', cfg.highlight && diff );
				tr.hidden = onlyDiff && ! diff;
			} );
			groupRows.forEach( function ( g ) {
				var nx = g.nextElementSibling, any = false;
				while ( nx && ! nx.classList.contains( 'wks-cmp__group' ) ) { if ( ! nx.hidden ) { any = true; } nx = nx.nextElementSibling; }
				g.hidden = ! any;
			} );
			table.querySelectorAll( '.wks-cmp__group th' ).forEach( function ( th ) { th.colSpan = visCount() + 1; } );
		}
		if ( cfg.selector ) {
			cfg.names.forEach( function ( name, i ) {
				var b = el( 'button', { type: 'button', class: 'wks-chip is-active', 'aria-pressed': 'true', text: name } );
				b.addEventListener( 'click', function () {
					if ( shown[ i ] && visCount() <= cfg.min ) { return; }
					shown[ i ] = ! shown[ i ];
					b.classList.toggle( 'is-active', shown[ i ] );
					b.setAttribute( 'aria-pressed', shown[ i ] ? 'true' : 'false' );
					apply();
				} );
				bar.appendChild( b );
			} );
		}
		if ( cfg.highlight && n > 1 ) {
			var id = 'wks-d' + Math.random().toString( 36 ).slice( 2, 8 );
			var cb = el( 'input', { type: 'checkbox', id: id } );
			cb.addEventListener( 'change', function () { onlyDiff = cb.checked; apply(); } );
			bar.appendChild( el( 'label', { class: 'wks-cmp__diff', for: id }, [ cb, document.createTextNode( ' ' + cfg.diff ) ] ) );
		}
		if ( bar.childNodes.length ) { root.insertBefore( bar, root.firstChild ); }
		apply();
	} );
}() );
