( function () {
	'use strict';

	function fullscreen( el ) {
		if ( document.fullscreenElement ) { document.exitFullscreen(); } else if ( el.requestFullscreen ) { el.requestFullscreen(); }
	}

	/* ---- 360 ---- */
	function mount360( scene, urls, cfg, S ) {
		var stage = scene.querySelector( '.wks-v__stage' ), img = scene.querySelector( '.wks-v__img' ), n = urls.length, idx = 0, timer = null, loaded = false;
		var cache = [];
		function show( i ) { idx = ( i % n + n ) % n; img.src = urls[ idx ]; }
		function preload() {
			if ( loaded ) { return; }
			loaded = true;
			urls.forEach( function ( u ) { var im = new Image(); im.decoding = 'async'; im.src = u; cache.push( im ); } );
		}
		function stop() { if ( timer ) { clearInterval( timer ); timer = null; } }
		function start() { if ( S.reduced() || timer ) { return; } timer = setInterval( function () { show( idx + 1 ); }, cfg.speed || 120 ); }
		show( 0 );
		var down = false, startX = 0, startIdx = 0;
		stage.addEventListener( 'pointerdown', function ( e ) { down = true; startX = e.clientX; startIdx = idx; stop(); preload(); stage.setPointerCapture( e.pointerId ); stage.classList.add( 'is-grab' ); } );
		stage.addEventListener( 'pointermove', function ( e ) {
			if ( ! down ) { return; }
			var per = Math.max( 4, stage.clientWidth / n );
			show( startIdx - Math.round( ( e.clientX - startX ) / per ) );
		} );
		function up() { down = false; stage.classList.remove( 'is-grab' ); }
		stage.addEventListener( 'pointerup', up ); stage.addEventListener( 'pointercancel', up );
		stage.addEventListener( 'keydown', function ( e ) {
			if ( 'ArrowRight' === e.key ) { stop(); show( idx + 1 ); e.preventDefault(); } else if ( 'ArrowLeft' === e.key ) { stop(); show( idx - 1 ); e.preventDefault(); }
		} );
		scene.addEventListener( 'click', function ( ev ) {
			var b = ev.target.closest( '[data-act]' ); if ( ! b ) { return; }
			if ( 'toggle' === b.dataset.act ) { timer ? stop() : start(); } else if ( 'full' === b.dataset.act ) { fullscreen( scene ); }
		} );
		return {
			activate: function () { preload(); if ( cfg.autoplay ) { start(); } },
			deactivate: stop
		};
	}

	/* ---- zoom ---- */
	function mountZoom( scene, urls, cfg ) {
		var stage = scene.querySelector( '.wks-v__stage' ), img = scene.querySelector( '.wks-v__img' ), max = cfg.maxzoom || 5;
		var k = 1, tx = 0, ty = 0, pts = {}, pinch = 0, drag = null;
		img.src = urls[ 0 ];
		function clamp() {
			var w = stage.clientWidth, h = stage.clientHeight;
			var iw = img.clientWidth * k, ih = img.clientHeight * k;
			var mx = Math.max( 0, ( iw - w ) / 2 ), my = Math.max( 0, ( ih - h ) / 2 );
			tx = Math.min( mx, Math.max( -mx, tx ) ); ty = Math.min( my, Math.max( -my, ty ) );
		}
		function apply() { clamp(); img.style.transform = 'translate(' + tx + 'px,' + ty + 'px) scale(' + k + ')'; stage.classList.toggle( 'is-zoomed', k > 1.01 ); }
		function zoomAt( nk, cx, cy ) {
			nk = Math.min( max, Math.max( 1, nk ) );
			var r = stage.getBoundingClientRect(), px = cx - ( r.left + r.width / 2 ), py = cy - ( r.top + r.height / 2 );
			tx = px - ( px - tx ) * ( nk / k ); ty = py - ( py - ty ) * ( nk / k );
			k = nk; if ( 1 === k ) { tx = ty = 0; }
			apply();
		}
		function centre() { var r = stage.getBoundingClientRect(); return [ r.left + r.width / 2, r.top + r.height / 2 ]; }
		stage.addEventListener( 'wheel', function ( e ) { e.preventDefault(); zoomAt( k * ( e.deltaY < 0 ? 1.2 : 1 / 1.2 ), e.clientX, e.clientY ); }, { passive: false } );
		stage.addEventListener( 'dblclick', function ( e ) { zoomAt( k > 1.01 ? 1 : Math.min( max, 2.5 ), e.clientX, e.clientY ); } );
		stage.addEventListener( 'pointerdown', function ( e ) {
			pts[ e.pointerId ] = [ e.clientX, e.clientY ]; stage.setPointerCapture( e.pointerId );
			drag = { x: e.clientX, y: e.clientY, tx: tx, ty: ty };
			if ( 2 === Object.keys( pts ).length ) { var a = Object.keys( pts ).map( function ( i ) { return pts[ i ]; } ); pinch = Math.hypot( a[ 0 ][ 0 ] - a[ 1 ][ 0 ], a[ 0 ][ 1 ] - a[ 1 ][ 1 ] ); }
		} );
		stage.addEventListener( 'pointermove', function ( e ) {
			if ( ! pts[ e.pointerId ] ) { return; }
			pts[ e.pointerId ] = [ e.clientX, e.clientY ];
			var ids = Object.keys( pts );
			if ( 2 === ids.length ) {
				var a = pts[ ids[ 0 ] ], b = pts[ ids[ 1 ] ], d = Math.hypot( a[ 0 ] - b[ 0 ], a[ 1 ] - b[ 1 ] );
				if ( pinch ) { zoomAt( k * d / pinch, ( a[ 0 ] + b[ 0 ] ) / 2, ( a[ 1 ] + b[ 1 ] ) / 2 ); }
				pinch = d;
			} else if ( drag && k > 1.01 ) {
				tx = drag.tx + e.clientX - drag.x; ty = drag.ty + e.clientY - drag.y; apply();
			}
		} );
		function up( e ) { delete pts[ e.pointerId ]; pinch = 0; drag = null; }
		stage.addEventListener( 'pointerup', up ); stage.addEventListener( 'pointercancel', up );
		stage.addEventListener( 'keydown', function ( e ) {
			var step = 40, handled = true;
			if ( '+' === e.key || '=' === e.key ) { var c = centre(); zoomAt( k * 1.25, c[ 0 ], c[ 1 ] ); }
			else if ( '-' === e.key ) { var c2 = centre(); zoomAt( k / 1.25, c2[ 0 ], c2[ 1 ] ); }
			else if ( 'ArrowLeft' === e.key ) { tx += step; apply(); } else if ( 'ArrowRight' === e.key ) { tx -= step; apply(); }
			else if ( 'ArrowUp' === e.key ) { ty += step; apply(); } else if ( 'ArrowDown' === e.key ) { ty -= step; apply(); }
			else { handled = false; }
			if ( handled ) { e.preventDefault(); }
		} );
		scene.addEventListener( 'click', function ( ev ) {
			var b = ev.target.closest( '[data-act]' ); if ( ! b ) { return; }
			var c = centre();
			if ( 'in' === b.dataset.act ) { zoomAt( k * 1.4, c[ 0 ], c[ 1 ] ); } else if ( 'out' === b.dataset.act ) { zoomAt( k / 1.4, c[ 0 ], c[ 1 ] ); }
			else if ( 'reset' === b.dataset.act ) { k = 1; tx = ty = 0; apply(); } else if ( 'full' === b.dataset.act ) { fullscreen( scene ); setTimeout( apply, 200 ); }
		} );
		document.addEventListener( 'fullscreenchange', function () { setTimeout( apply, 100 ); } );
		return { activate: apply, deactivate: function () {} };
	}

	WakooSuiteApi.define( 'viewer360', function ( root, cfg, S ) {
		var scenes = Array.prototype.slice.call( root.querySelectorAll( '.wks-v__scene' ) ), tabs = root.querySelectorAll( '.wks-v__tabs .wks-chip' );
		var ctl = [], cur = 0;
		scenes.forEach( function ( sc ) {
			var urls = []; try { urls = JSON.parse( sc.getAttribute( 'data-urls' ) ); } catch ( e ) {}
			ctl.push( 'zoom' === sc.dataset.mode ? mountZoom( sc, urls, cfg ) : mount360( sc, urls, cfg, S ) );
		} );
		function go( i ) {
			ctl[ cur ].deactivate(); scenes[ cur ].hidden = true;
			cur = i; scenes[ cur ].hidden = false;
			tabs.forEach( function ( t, j ) { t.classList.toggle( 'is-active', j === i ); t.setAttribute( 'aria-selected', j === i ? 'true' : 'false' ); } );
			ctl[ cur ].activate();
		}
		tabs.forEach( function ( t, j ) { t.addEventListener( 'click', function () { go( j ); } ); } );
		S.visible( root, function () { ctl[ cur ].activate(); } );
		// Pause the spin while the tab is hidden.
		document.addEventListener( 'visibilitychange', function () { if ( document.hidden ) { ctl[ cur ].deactivate(); } else if ( root.isConnected ) { ctl[ cur ].activate(); } } );
	} );
}() );
