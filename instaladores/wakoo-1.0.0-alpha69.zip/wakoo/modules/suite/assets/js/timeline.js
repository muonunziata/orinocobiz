( function () {
	'use strict';
	WakooSuiteApi.define( 'timeline', function ( root, cfg, S ) {
		var items = root.querySelectorAll( '.wks-tl__item' );
		if ( cfg.animate && ! S.reduced() && 'IntersectionObserver' in window ) {
			root.classList.add( 'is-anim' );
			var io = new IntersectionObserver( function ( es ) {
				es.forEach( function ( e ) { if ( e.isIntersecting ) { e.target.classList.add( 'is-in' ); io.unobserve( e.target ); } } );
			}, { threshold: .15 } );
			items.forEach( function ( i ) { io.observe( i ); } );
		}
		if ( 'h' === cfg.dir ) {
			var track = root.querySelector( '.wks-tl__track' );
			var step = function ( d ) { track.scrollBy( { left: d * Math.max( 240, track.clientWidth * .7 ), behavior: S.reduced() ? 'auto' : 'smooth' } ); };
			root.querySelector( '.wks-tl__prev' ).addEventListener( 'click', function () { step( -1 ); } );
			root.querySelector( '.wks-tl__next' ).addEventListener( 'click', function () { step( 1 ); } );
			track.addEventListener( 'keydown', function ( e ) {
				if ( 'ArrowRight' === e.key ) { step( 1 ); e.preventDefault(); } else if ( 'ArrowLeft' === e.key ) { step( -1 ); e.preventDefault(); }
			} );
		}
	} );
}() );
