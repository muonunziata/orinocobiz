/**
 * WakooSheetEditor: spreadsheet / card editor in a large modal. Loaded ONLY inside the Elementor editor (never on the front end).
 * No libraries, no external requests.
 *
 * Widgets never call this directly. They declare a control in Base::sections():
 *     'edit' => [ 't' => 'editor_btn', 'l' => 'Abrir editor', 'target' => '<repeater id>', 'mode' => 'grid'|'cards' ]
 * and wakoo-editor-adapters.js wires the button to the right adapter (repeater, datatable, compare, Happy tables).
 *
 * Contract (for adapters):
 *   WakooSheetEditor.open( {
 *     title: 'Tabla',  hint: 'texto de ayuda',
 *     mode: 'grid' | 'cards',               // grid = hoja de cálculo, cards = una tarjeta por fila
 *     columns: [ { id, label, type, options, x } ],   // type: text textarea number select bool media url ; options = { value: label }
 *                                                     // x = opaque data that travels with the column (kept on move/insert)
 *     rows: [ { v: [ ...cell values ], x: [ ...opaque per cell ], data: opaque per row, fixed: bool } ],
 *     dynamicColumns: bool,                 // user may insert/delete/rename/move columns
 *     fixedLeft: 0,                         // first N columns can't be deleted/renamed/moved (compare: group + feature)
 *     minCols: 1, maxCols: 30, maxRows: 2000,
 *     headerEditable: bool,                 // column labels editable (default = dynamicColumns)
 *     newRow:  function( cols ) -> { v, x, data },   // optional factory for inserted rows
 *     newCol:  function( index ) -> { id, label, type, x },
 *     onSave:  function( { columns, rows } )         // rows keep v / x / data / fixed
 *   } )
 * Cell values: strings (text, textarea, number, select), 'yes' | '' (bool), { id, url } (media), { url, is_external } (url).
 */
( function ( w, d ) {
	'use strict';

	var T = {
		save: 'Guardar y cerrar', cancel: 'Cancelar', close: 'Cerrar', search: 'Buscar…', undo: 'Deshacer', redo: 'Rehacer',
		rowAbove: 'Fila arriba', rowBelow: 'Fila abajo', delRow: 'Borrar fila', dupRow: 'Duplicar fila', rowUp: 'Subir fila', rowDown: 'Bajar fila',
		colLeft: 'Columna izquierda', colRight: 'Columna derecha', delCol: 'Borrar columna', colL: 'Mover columna ←', colR: 'Mover columna →',
		grid: 'Hoja', cards: 'Tarjetas', rows: 'filas', cols: 'columnas', discard: '¿Descartar los cambios sin guardar?',
		hint: 'Flechas para moverte · Enter o doble clic para editar · Tab para avanzar · Ctrl+V pega desde Excel · Ctrl+Z deshace',
		pick: 'Elegir…', clear: 'Quitar', add: 'Añadir fila', limitRows: 'Máximo de filas alcanzado', limitCols: 'Máximo de columnas alcanzado',
		locked: 'Esta fila/columna es fija', colName: 'Nombre de columna', row: 'Fila', drag: 'Arrastrar para ordenar', yes: 'Sí'
	};
	var uid = 0;
	function el( tag, attrs, kids ) {
		var n = d.createElement( tag ), k;
		if ( attrs ) { for ( k in attrs ) { if ( 'text' === k ) { n.textContent = attrs[ k ]; } else if ( null !== attrs[ k ] && undefined !== attrs[ k ] ) { n.setAttribute( k, attrs[ k ] ); } } }
		( kids || [] ).forEach( function ( c ) { if ( c ) { n.appendChild( c ); } } );
		return n;
	}
	function clone( o ) { return JSON.parse( JSON.stringify( o ) ); }
	function emptyFor( t ) { return 'media' === t || 'url' === t ? '' : ''; }
	function show( v, t ) {
		if ( null === v || undefined === v ) { return ''; }
		if ( 'bool' === t ) { return v ? '✔' : ''; }
		if ( 'media' === t ) { return v && v.url ? String( v.url ).split( '/' ).pop() : ''; }
		if ( 'url' === t ) { return v && v.url ? v.url : ''; }
		return String( v );
	}

	function loadCss() {
		var u = w.WakooSheetCfg && w.WakooSheetCfg.css;
		if ( u && ! d.getElementById( 'wakoo-sheet-editor-css' ) ) { d.head.appendChild( el( 'link', { id: 'wakoo-sheet-editor-css', rel: 'stylesheet', href: u } ) ); }
	}

	function open( opt ) {
		loadCss();
		var cols = clone( opt.columns || [] ), rows = clone( opt.rows || [] );
		var dyn = !! opt.dynamicColumns, fixedLeft = opt.fixedLeft || 0, minCols = opt.minCols || 1, maxCols = opt.maxCols || 30, maxRows = opt.maxRows || 2000;
		var headEdit = undefined === opt.headerEditable ? dyn : !! opt.headerEditable;
		var mode = opt.mode === 'cards' ? 'cards' : 'grid';
		var sel = { r: 0, c: 0 }, undo = [], redo = [], dirty = false, editing = null, query = '', hits = [], hitI = -1, lastFocus = d.activeElement;
		var id = 'we' + ( ++uid );

		cols.forEach( function ( c, i ) { c.id = c.id || ( 'c' + i ); c.type = c.type || 'text'; } );
		rows.forEach( function ( r ) { norm( r ); } );
		function norm( r ) {
			r.v = r.v || []; r.x = r.x || [];
			while ( r.v.length < cols.length ) { r.v.push( emptyFor( cols[ r.v.length ].type ) ); }
			r.v.length = cols.length; r.x.length = cols.length;
		}
		function firstFree() { var i = 0; while ( rows[ i ] && rows[ i ].fixed ) { i++; } return i; }

		/* ---------------------------------------------------------------- DOM shell */
		var back = el( 'div', { class: 'we-back', role: 'presentation' } );
		var box = el( 'div', { class: 'we-box', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': id + '-t' } );
		var title = el( 'h2', { id: id + '-t', class: 'we-title', text: opt.title || 'Editor' } );
		var info = el( 'span', { class: 'we-info' } );
		var tools = el( 'div', { class: 'we-tools', role: 'toolbar', 'aria-label': 'Herramientas' } );
		var searchIn = el( 'input', { type: 'search', class: 'we-search', placeholder: T.search, 'aria-label': T.search } );
		var body = el( 'div', { class: 'we-body' } );
		var live = el( 'div', { class: 'we-live', 'aria-live': 'polite' } );
		var foot = el( 'div', { class: 'we-foot' } );
		var bSave = el( 'button', { type: 'button', class: 'we-btn we-primary', text: T.save } );
		var bCancel = el( 'button', { type: 'button', class: 'we-btn', text: T.cancel } );
		var bX = el( 'button', { type: 'button', class: 'we-x', 'aria-label': T.close, text: '×' } );
		var hintEl = el( 'p', { class: 'we-hint', text: opt.hint || T.hint } );
		foot.appendChild( hintEl ); foot.appendChild( bCancel ); foot.appendChild( bSave );
		box.appendChild( el( 'div', { class: 'we-head' }, [ title, info, bX ] ) );
		box.appendChild( tools ); box.appendChild( body ); box.appendChild( foot ); box.appendChild( live );
		back.appendChild( box ); d.body.appendChild( back );
		d.documentElement.classList.add( 'we-open' );

		function say( t ) { live.textContent = ''; setTimeout( function () { live.textContent = t; }, 30 ); }

		/* ---------------------------------------------------------------- state ops */
		function snap() { return JSON.stringify( { c: cols, r: rows } ); }
		function restore( s ) { var o = JSON.parse( s ); cols = o.c; rows = o.r; sel.r = Math.min( sel.r, rows.length - 1 ); sel.c = Math.min( sel.c, cols.length - 1 ); }
		function mutate( fn ) {
			finishEdit( true );
			undo.push( snap() ); if ( undo.length > 60 ) { undo.shift(); }
			redo = []; dirty = true;
			fn();
			render();
		}
		function doUndo() { if ( ! undo.length ) { return; } finishEdit( true ); redo.push( snap() ); restore( undo.pop() ); render(); say( T.undo ); }
		function doRedo() { if ( ! redo.length ) { return; } finishEdit( true ); undo.push( snap() ); restore( redo.pop() ); render(); say( T.redo ); }

		function blankRow() {
			var r = opt.newRow ? opt.newRow( cols ) : {};
			r.v = r.v || cols.map( function ( c ) { return emptyFor( c.type ); } );
			r.x = r.x || []; norm( r ); return r;
		}
		function insertRow( at ) {
			if ( rows.length >= maxRows ) { say( T.limitRows ); return; }
			at = Math.max( at, firstFree() );
			mutate( function () { rows.splice( at, 0, blankRow() ); sel.r = at; } );
		}
		function delRow( i ) {
			if ( ! rows[ i ] || rows[ i ].fixed ) { say( T.locked ); return; }
			mutate( function () { rows.splice( i, 1 ); sel.r = Math.max( 0, Math.min( i, rows.length - 1 ) ); } );
		}
		function dupRow( i ) {
			if ( rows.length >= maxRows ) { say( T.limitRows ); return; }
			if ( ! rows[ i ] || rows[ i ].fixed ) { say( T.locked ); return; }
			mutate( function () { var c = clone( rows[ i ] ); c.data = opt.dupData ? opt.dupData( c.data ) : undefined; rows.splice( i + 1, 0, c ); sel.r = i + 1; } );
		}
		function moveRow( i, dir ) {
			var j = i + dir;
			if ( ! rows[ i ] || rows[ i ].fixed || ! rows[ j ] || rows[ j ].fixed ) { return; }
			mutate( function () { var t = rows[ i ]; rows[ i ] = rows[ j ]; rows[ j ] = t; sel.r = j; } );
		}
		function insertCol( at ) {
			if ( ! dyn ) { return; }
			if ( cols.length >= maxCols ) { say( T.limitCols ); return; }
			at = Math.max( at, fixedLeft );
			mutate( function () {
				var nc = opt.newCol ? opt.newCol( at ) : { label: 'Columna ' + ( cols.length + 1 ), type: 'text' };
				nc.id = nc.id || ( 'n' + ( ++uid ) ); nc.type = nc.type || 'text';
				cols.splice( at, 0, nc );
				rows.forEach( function ( r ) { r.v.splice( at, 0, emptyFor( nc.type ) ); r.x.splice( at, 0, undefined ); } );
				sel.c = at;
			} );
		}
		function delCol( i ) {
			if ( ! dyn || i < fixedLeft ) { say( T.locked ); return; }
			if ( cols.length <= minCols ) { return; }
			mutate( function () { cols.splice( i, 1 ); rows.forEach( function ( r ) { r.v.splice( i, 1 ); r.x.splice( i, 1 ); } ); sel.c = Math.max( 0, Math.min( i, cols.length - 1 ) ); } );
		}
		function moveCol( i, dir ) {
			var j = i + dir;
			if ( ! dyn || i < fixedLeft || j < fixedLeft || j >= cols.length ) { return; }
			mutate( function () {
				var t = cols[ i ]; cols[ i ] = cols[ j ]; cols[ j ] = t;
				rows.forEach( function ( r ) { t = r.v[ i ]; r.v[ i ] = r.v[ j ]; r.v[ j ] = t; t = r.x[ i ]; r.x[ i ] = r.x[ j ]; r.x[ j ] = t; } );
				sel.c = j;
			} );
		}
		function setCell( r, c, v ) { if ( JSON.stringify( rows[ r ].v[ c ] ) === JSON.stringify( v ) ) { return; } mutate( function () { rows[ r ].v[ c ] = v; if ( rows[ r ].x[ c ] ) { rows[ r ].x[ c ] = undefined; } } ); }

		/* ---------------------------------------------------------------- toolbar */
		var btns = {};
		function tbtn( key, label, fn, glyph ) {
			var b = el( 'button', { type: 'button', class: 'we-tb', title: label, 'aria-label': label, text: glyph } );
			b.addEventListener( 'click', function () { fn(); focusGrid(); } );
			btns[ key ] = b; tools.appendChild( b ); return b;
		}
		function sep() { tools.appendChild( el( 'span', { class: 'we-sep', 'aria-hidden': 'true' } ) ); }
		tbtn( 'undo', T.undo, doUndo, '↶' ); tbtn( 'redo', T.redo, doRedo, '↷' ); sep();
		tbtn( 'ra', T.rowAbove, function () { insertRow( sel.r ); }, '⤒ +fila' );
		tbtn( 'rb', T.rowBelow, function () { insertRow( sel.r + 1 ); }, '⤓ +fila' );
		tbtn( 'rd', T.delRow, function () { delRow( sel.r ); }, '✕ fila' );
		tbtn( 'rc', T.dupRow, function () { dupRow( sel.r ); }, '⧉ fila' );
		tbtn( 'ru', T.rowUp, function () { moveRow( sel.r, -1 ); }, '↑' );
		tbtn( 'rn', T.rowDown, function () { moveRow( sel.r, 1 ); }, '↓' );
		if ( dyn ) {
			sep();
			tbtn( 'ca', T.colLeft, function () { insertCol( sel.c ); }, '⇤ +col' );
			tbtn( 'cb', T.colRight, function () { insertCol( sel.c + 1 ); }, '⇥ +col' );
			tbtn( 'cd', T.delCol, function () { delCol( sel.c ); }, '✕ col' );
			tbtn( 'cl', T.colL, function () { moveCol( sel.c, -1 ); }, '←' );
			tbtn( 'cr', T.colR, function () { moveCol( sel.c, 1 ); }, '→' );
		}
		sep();
		var bMode = el( 'button', { type: 'button', class: 'we-tb we-mode', 'aria-pressed': mode === 'cards' ? 'true' : 'false', text: mode === 'cards' ? T.grid : T.cards } );
		bMode.addEventListener( 'click', function () { finishEdit( true ); mode = 'cards' === mode ? 'grid' : 'cards'; bMode.textContent = 'cards' === mode ? T.grid : T.cards; bMode.setAttribute( 'aria-pressed', 'cards' === mode ? 'true' : 'false' ); render(); } );
		if ( opt.allowModes !== false ) { tools.appendChild( bMode ); }
		tools.appendChild( searchIn );
		searchIn.addEventListener( 'input', function () { query = searchIn.value.toLowerCase(); render(); } );
		searchIn.addEventListener( 'keydown', function ( e ) { if ( 'Enter' === e.key ) { e.preventDefault(); nextHit( e.shiftKey ? -1 : 1 ); } } );

		function nextHit( dir ) {
			if ( ! hits.length ) { return; }
			hitI = ( hitI + dir + hits.length ) % hits.length;
			sel.r = hits[ hitI ][ 0 ]; sel.c = hits[ hitI ][ 1 ]; markSel( true );
		}

		/* ---------------------------------------------------------------- grid */
		var table, tbody, cards;
		function cellEl( r, c ) { return tbody && tbody.rows[ r ] ? tbody.rows[ r ].cells[ c + 1 ] : null; }
		function focusGrid() { if ( 'grid' === mode && table ) { table.focus( { preventScroll: true } ); } }

		function render() {
			if ( ! rows.length && 'grid' === mode ) { rows.push( blankRow() ); }
			sel.r = Math.max( 0, Math.min( sel.r, rows.length - 1 ) ); sel.c = Math.max( 0, Math.min( sel.c, cols.length - 1 ) );
			body.textContent = ''; table = tbody = cards = null;
			hits = []; hitI = -1;
			if ( query ) { rows.forEach( function ( r, ri ) { r.v.forEach( function ( v, ci ) { if ( show( v, cols[ ci ].type ).toLowerCase().indexOf( query ) > -1 ) { hits.push( [ ri, ci ] ); } } ); } ); }
			'grid' === mode ? renderGrid() : renderCards();
			info.textContent = rows.length + ' ' + T.rows + ' × ' + cols.length + ' ' + T.cols + ( query ? ' · ' + hits.length + ' ✓' : '' );
			btns.undo.disabled = ! undo.length; btns.redo.disabled = ! redo.length;
		}

		function renderGrid() {
			table = el( 'table', { class: 'we-grid', tabindex: '0', role: 'grid', 'aria-label': opt.title || 'Hoja', 'aria-rowcount': rows.length + 1, 'aria-colcount': cols.length } );
			var tr = el( 'tr' );
			tr.appendChild( el( 'th', { class: 'we-corner', scope: 'col' } ) );
			cols.forEach( function ( c, ci ) {
				var th = el( 'th', { class: 'we-colh' + ( ci < fixedLeft && dyn ? ' is-fixed' : '' ), scope: 'col', 'data-c': ci }, [
					el( 'span', { class: 'we-let', text: letter( ci ) } ), el( 'span', { class: 'we-lab', text: c.label || '' } )
				] );
				th.addEventListener( 'click', function () { sel.c = ci; markSel(); focusGrid(); } );
				if ( headEdit && ci >= fixedLeft ) { th.addEventListener( 'dblclick', function () { editHeader( ci, th ); } ); th.title = T.colName; }
				tr.appendChild( th );
			} );
			table.appendChild( el( 'thead', null, [ tr ] ) );
			tbody = el( 'tbody' );
			rows.forEach( function ( r, ri ) {
				var row = el( 'tr', { 'aria-rowindex': ri + 2, class: r.fixed ? 'is-fixed' : '' } );
				var rh = el( 'th', { class: 'we-rowh', scope: 'row', text: String( ri + 1 ) } );
				rh.addEventListener( 'click', function () { sel.r = ri; markSel(); focusGrid(); } );
				row.appendChild( rh );
				cols.forEach( function ( c, ci ) { row.appendChild( buildCell( ri, ci ) ); } );
				tbody.appendChild( row );
			} );
			table.appendChild( tbody );
			body.appendChild( el( 'div', { class: 'we-scroll' }, [ table ] ) );
			table.addEventListener( 'keydown', gridKey );
			table.addEventListener( 'paste', onPaste );
			table.addEventListener( 'copy', onCopy );
			table.addEventListener( 'click', function ( e ) {
				var td = e.target.closest ? e.target.closest( 'td' ) : null; if ( ! td || editing ) { return; }
				sel.r = td.parentNode.rowIndex - 1; sel.c = td.cellIndex - 1; markSel();
			} );
			table.addEventListener( 'dblclick', function ( e ) { var td = e.target.closest ? e.target.closest( 'td' ) : null; if ( td ) { sel.r = td.parentNode.rowIndex - 1; sel.c = td.cellIndex - 1; startEdit(); } } );
			markSel();
			if ( ! opt._noFocus ) { focusGrid(); }
		}
		function letter( i ) { var s = ''; i++; while ( i > 0 ) { var m = ( i - 1 ) % 26; s = String.fromCharCode( 65 + m ) + s; i = Math.floor( ( i - 1 ) / 26 ); } return s; }
		function buildCell( ri, ci ) {
			var r = rows[ ri ], c = cols[ ci ], v = r.v[ ci ];
			var td = el( 'td', { role: 'gridcell', class: 'we-c we-t-' + c.type + ( r.x[ ci ] && r.x[ ci ].nonText ? ' is-nontext' : '' ) } );
			var txt = show( v, c.type );
			if ( r.x[ ci ] && r.x[ ci ].nonText && '' === txt ) { txt = r.x[ ci ].nonText; td.classList.add( 'is-ghost' ); }
			if ( 'media' === c.type && v && v.url && /\.(png|jpe?g|gif|webp|svg|avif)(\?|$)/i.test( v.url ) ) { td.appendChild( el( 'img', { src: v.url, alt: '', class: 'we-thumb' } ) ); }
			td.appendChild( el( 'span', { class: 'we-v', text: txt } ) );
			if ( query && txt.toLowerCase().indexOf( query ) > -1 ) { td.classList.add( 'is-hit' ); }
			return td;
		}
		function markSel( scroll ) {
			if ( ! tbody ) { return; }
			var o = table.querySelector( '.is-sel' ); if ( o ) { o.classList.remove( 'is-sel' ); }
			table.querySelectorAll( '.is-rsel,.is-csel' ).forEach( function ( n ) { n.classList.remove( 'is-rsel', 'is-csel' ); } );
			var td = cellEl( sel.r, sel.c );
			if ( td ) {
				td.classList.add( 'is-sel' ); tbody.rows[ sel.r ].cells[ 0 ].classList.add( 'is-rsel' );
				table.tHead.rows[ 0 ].cells[ sel.c + 1 ].classList.add( 'is-csel' );
				if ( scroll !== false ) { td.scrollIntoView( { block: 'nearest', inline: 'nearest' } ); }
				table.setAttribute( 'aria-activedescendant', '' );
			}
			var fixedRow = rows[ sel.r ] && rows[ sel.r ].fixed, fixedCol = sel.c < fixedLeft;
			[ 'rd', 'rc', 'ru', 'rn' ].forEach( function ( k ) { btns[ k ].disabled = !! fixedRow; } );
			[ 'cd', 'cl', 'cr' ].forEach( function ( k ) { if ( btns[ k ] ) { btns[ k ].disabled = !! fixedCol || cols.length <= minCols; } } );
			[ 'ra' ].forEach( function ( k ) { btns[ k ].disabled = !! fixedRow; } );
			if ( btns.ca ) { btns.ca.disabled = !! fixedCol; }
			if ( td ) { say( letter( sel.c ) + ( sel.r + 1 ) + ': ' + ( show( rows[ sel.r ].v[ sel.c ], cols[ sel.c ].type ) || '' ) ); }
		}
		function move( dr, dc ) { sel.r = Math.max( 0, Math.min( rows.length - 1, sel.r + dr ) ); sel.c = Math.max( 0, Math.min( cols.length - 1, sel.c + dc ) ); markSel(); }

		function gridKey( e ) {
			if ( editing || /^(INPUT|TEXTAREA|SELECT)$/.test( e.target.tagName ) ) { return; }
			var k = e.key, mod = e.ctrlKey || e.metaKey;
			if ( mod && ( 'z' === k || 'Z' === k ) ) { e.preventDefault(); e.shiftKey ? doRedo() : doUndo(); return; }
			if ( mod && ( 'y' === k || 'Y' === k ) ) { e.preventDefault(); doRedo(); return; }
			if ( mod && ( 's' === k || 'S' === k ) ) { e.preventDefault(); save(); return; }
			if ( mod && ( 'f' === k || 'F' === k ) ) { e.preventDefault(); searchIn.focus(); return; }
			if ( mod && 'Enter' === k ) { e.preventDefault(); insertRow( sel.r + 1 ); return; }
			if ( 'ArrowDown' === k ) { e.preventDefault(); move( 1, 0 ); } else if ( 'ArrowUp' === k ) { e.preventDefault(); move( -1, 0 ); }
			else if ( 'ArrowLeft' === k ) { e.preventDefault(); move( 0, -1 ); } else if ( 'ArrowRight' === k ) { e.preventDefault(); move( 0, 1 ); }
			else if ( 'Tab' === k ) { e.preventDefault(); if ( e.shiftKey ) { sel.c > 0 ? move( 0, -1 ) : ( sel.r > 0 && ( sel.c = cols.length - 1, move( -1, 0 ) ) ); } else if ( sel.c < cols.length - 1 ) { move( 0, 1 ); } else if ( sel.r < rows.length - 1 ) { sel.c = 0; move( 1, 0 ); } else { insertRow( rows.length ); sel.c = 0; markSel(); } }
			else if ( 'Home' === k ) { e.preventDefault(); sel.c = 0; mod ? sel.r = 0 : 0; markSel(); } else if ( 'End' === k ) { e.preventDefault(); sel.c = cols.length - 1; mod ? sel.r = rows.length - 1 : 0; markSel(); }
			else if ( 'PageDown' === k ) { e.preventDefault(); move( 10, 0 ); } else if ( 'PageUp' === k ) { e.preventDefault(); move( -10, 0 ); }
			else if ( 'Enter' === k || 'F2' === k ) { e.preventDefault(); startEdit(); }
			else if ( 'Delete' === k || 'Backspace' === k ) { e.preventDefault(); setCell( sel.r, sel.c, emptyFor( cols[ sel.c ].type ) ); }
			else if ( ' ' === k && 'bool' === cols[ sel.c ].type ) { e.preventDefault(); setCell( sel.r, sel.c, rows[ sel.r ].v[ sel.c ] ? '' : 'yes' ); }
			else if ( k.length === 1 && ! mod && ! e.altKey && 'media' !== cols[ sel.c ].type && 'bool' !== cols[ sel.c ].type ) { startEdit( k ); e.preventDefault(); }
		}

		function startEdit( first ) {
			var r = sel.r, c = sel.c, col = cols[ c ], td = cellEl( r, c ), v = rows[ r ].v[ c ];
			if ( ! td ) { return; }
			if ( 'media' === col.type ) { pickMedia( r, c ); return; }
			if ( 'bool' === col.type ) { setCell( r, c, v ? '' : 'yes' ); return; }
			var inp;
			if ( 'select' === col.type ) {
				inp = el( 'select', { class: 'we-in' }, Object.keys( col.options || {} ).map( function ( k ) { var o = el( 'option', { value: k, text: col.options[ k ] } ); if ( String( v ) === k ) { o.selected = true; } return o; } ) );
			} else if ( 'textarea' === col.type ) {
				inp = el( 'textarea', { class: 'we-in', rows: 4 } ); inp.value = undefined !== first ? first : show( v, col.type );
			} else {
				inp = el( 'input', { class: 'we-in', type: 'number' === col.type ? 'text' : 'text', inputmode: 'number' === col.type ? 'decimal' : null } );
				inp.value = undefined !== first ? first : show( v, col.type );
			}
			td.classList.add( 'is-editing' ); td.textContent = ''; td.appendChild( inp );
			editing = { r: r, c: c, inp: inp, td: td, orig: v };
			inp.focus();
			if ( undefined === first && inp.select && 'select' !== col.type ) { inp.select(); } else if ( inp.setSelectionRange && undefined !== first ) { inp.setSelectionRange( first.length, first.length ); }
			inp.addEventListener( 'keydown', function ( e ) {
				if ( 'Escape' === e.key ) { e.stopPropagation(); finishEdit( false ); focusGrid(); }
				else if ( 'Enter' === e.key && ! ( 'textarea' === col.type && e.shiftKey ) ) { e.preventDefault(); e.stopPropagation(); finishEdit( true ); move( 1, 0 ); focusGrid(); }
				else if ( 'Tab' === e.key ) { e.preventDefault(); e.stopPropagation(); finishEdit( true ); e.shiftKey ? move( 0, -1 ) : move( 0, 1 ); focusGrid(); }
			} );
			inp.addEventListener( 'blur', function () { setTimeout( function () { if ( editing && editing.inp === inp ) { finishEdit( true ); } }, 0 ); } );
		}
		function normalise( col, raw ) {
			if ( 'url' === col.type ) { return raw ? { url: raw } : ''; }
			return raw;
		}
		function finishEdit( commit ) {
			if ( ! editing ) { return; }
			var e = editing; editing = null;
			var col = cols[ e.c ], val = e.inp.value;
			if ( commit && rows[ e.r ] ) {
				var nv = normalise( col, val );
				if ( JSON.stringify( nv ) !== JSON.stringify( e.orig ) && ! ( ( '' === nv ) && ( '' === e.orig || undefined === e.orig ) ) ) {
					undo.push( snap() ); if ( undo.length > 60 ) { undo.shift(); } redo = []; dirty = true;
					rows[ e.r ].v[ e.c ] = nv; rows[ e.r ].x[ e.c ] = undefined;
				}
			}
			var nt = buildCell( e.r, e.c );
			if ( e.td.parentNode ) { e.td.parentNode.replaceChild( nt, e.td ); }
			btns.undo.disabled = ! undo.length; btns.redo.disabled = ! redo.length;
			markSel( false );
		}
		function editHeader( ci, th ) {
			var inp = el( 'input', { class: 'we-in', type: 'text', 'aria-label': T.colName } ); inp.value = cols[ ci ].label || '';
			th.textContent = ''; th.appendChild( inp ); inp.focus(); inp.select();
			function done( ok ) {
				if ( ok && inp.value !== cols[ ci ].label ) { mutate( function () { cols[ ci ].label = inp.value; } ); } else { render(); }
			}
			inp.addEventListener( 'keydown', function ( e ) { if ( 'Enter' === e.key ) { e.preventDefault(); done( true ); } else if ( 'Escape' === e.key ) { e.stopPropagation(); done( false ); } } );
			inp.addEventListener( 'blur', function () { setTimeout( function () { if ( inp.parentNode ) { done( true ); } }, 0 ); } );
		}
		function pickMedia( r, c ) {
			if ( ! w.wp || ! w.wp.media ) { return; }
			var f = w.wp.media( { multiple: false } );
			f.on( 'select', function () { var a = f.state().get( 'selection' ).first().toJSON(); setCell( r, c, { id: a.id, url: a.url } ); focusGrid(); } );
			f.open();
		}

		/* clipboard */
		function onCopy( e ) {
			if ( editing || /^(INPUT|TEXTAREA|SELECT)$/.test( e.target.tagName ) ) { return; }
			var v = show( rows[ sel.r ].v[ sel.c ], cols[ sel.c ].type );
			e.clipboardData.setData( 'text/plain', v ); e.preventDefault();
		}
		function parseTSV( t ) {
			t = t.replace( /\r\n?/g, '\n' ).replace( /\n$/, '' );
			var out = [], row = [], cell = '', q = false, i, ch;
			for ( i = 0; i < t.length; i++ ) {
				ch = t[ i ];
				if ( q ) { if ( '"' === ch && '"' === t[ i + 1 ] ) { cell += '"'; i++; } else if ( '"' === ch ) { q = false; } else { cell += ch; } }
				else if ( '"' === ch && '' === cell ) { q = true; }
				else if ( '\t' === ch ) { row.push( cell ); cell = ''; }
				else if ( '\n' === ch ) { row.push( cell ); out.push( row ); row = []; cell = ''; }
				else { cell += ch; }
			}
			row.push( cell ); out.push( row ); return out;
		}
		function onPaste( e ) {
			if ( editing || /^(INPUT|TEXTAREA|SELECT)$/.test( e.target.tagName ) ) { return; }
			var t = ( e.clipboardData || w.clipboardData ).getData( 'text' ); if ( null === t || '' === t ) { return; }
			e.preventDefault();
			var m = parseTSV( t );
			mutate( function () {
				m.forEach( function ( line, i ) {
					var ri = sel.r + i;
					while ( ri >= rows.length && rows.length < maxRows ) { rows.push( blankRow() ); }
					if ( ! rows[ ri ] ) { return; }
					line.forEach( function ( val, j ) {
						var ci = sel.c + j;
						while ( ci >= cols.length && dyn && cols.length < maxCols ) { var nc = opt.newCol ? opt.newCol( cols.length ) : { label: 'Columna ' + ( cols.length + 1 ), type: 'text' }; nc.id = nc.id || ( 'n' + ( ++uid ) ); nc.type = nc.type || 'text'; cols.push( nc ); rows.forEach( function ( r ) { r.v.push( '' ); r.x.push( undefined ); } ); }
						if ( ci >= cols.length || rows[ ri ].fixed && false ) { return; }
						var ty = cols[ ci ].type;
						if ( 'media' === ty ) { return; }
						rows[ ri ].v[ ci ] = 'bool' === ty ? ( /^(1|yes|s[ií]|true|✔)$/i.test( val ) ? 'yes' : '' ) : ( 'url' === ty ? ( val ? { url: val } : '' ) : val );
						rows[ ri ].x[ ci ] = undefined;
					} );
				} );
			} );
		}

		/* ---------------------------------------------------------------- cards */
		function renderCards() {
			cards = el( 'ol', { class: 'we-cards', 'aria-label': opt.title || 'Tarjetas' } );
			rows.forEach( function ( r, ri ) { cards.appendChild( buildCard( r, ri ) ); } );
			var add = el( 'button', { type: 'button', class: 'we-btn we-add', text: '+ ' + T.add } );
			add.addEventListener( 'click', function () { insertRow( rows.length ); } );
			body.appendChild( el( 'div', { class: 'we-scroll' }, [ cards, add ] ) );
		}
		function cardTitle( r ) { for ( var i = 0; i < cols.length; i++ ) { if ( ( 'text' === cols[ i ].type ) && 'string' === typeof r.v[ i ] && r.v[ i ] ) { return r.v[ i ].slice( 0, 40 ); } } return ''; }
		function buildCard( r, ri ) {
			var li = el( 'li', { class: 'we-card' + ( r.fixed ? ' is-fixed' : '' ), draggable: r.fixed ? 'false' : 'true', 'data-i': ri } );
			var head = el( 'div', { class: 'we-card-h' }, [ el( 'span', { class: 'we-grip', title: T.drag, 'aria-hidden': 'true', text: '⠿' } ), el( 'strong', { text: T.row + ' ' + ( ri + 1 ) + ( cardTitle( r ) ? ' · ' + cardTitle( r ) : '' ) } ) ] );
			if ( ! r.fixed ) {
				[ [ T.dupRow, '⧉', function () { dupRow( ri ); } ], [ T.rowUp, '↑', function () { moveRow( ri, -1 ); } ], [ T.rowDown, '↓', function () { moveRow( ri, 1 ); } ], [ T.delRow, '✕', function () { delRow( ri ); } ] ].forEach( function ( a ) {
					var b = el( 'button', { type: 'button', class: 'we-tb', title: a[ 0 ], 'aria-label': a[ 0 ], text: a[ 1 ] } ); b.addEventListener( 'click', a[ 2 ] ); head.appendChild( b );
				} );
			}
			li.appendChild( head );
			var grid = el( 'div', { class: 'we-fields' } );
			cols.forEach( function ( c, ci ) {
				var fid = id + '-' + ri + '-' + ci, v = r.v[ ci ], f, inp;
				if ( 'textarea' === c.type ) { inp = el( 'textarea', { id: fid, rows: 3 } ); inp.value = show( v, c.type ); }
				else if ( 'select' === c.type ) { inp = el( 'select', { id: fid }, Object.keys( c.options || {} ).map( function ( k ) { var o = el( 'option', { value: k, text: c.options[ k ] } ); if ( String( v ) === k ) { o.selected = true; } return o; } ) ); }
				else if ( 'bool' === c.type ) { inp = el( 'input', { id: fid, type: 'checkbox' } ); inp.checked = !! v; }
				else if ( 'media' === c.type ) {
					inp = el( 'button', { id: fid, type: 'button', class: 'we-btn', text: v && v.url ? show( v, 'media' ) : T.pick } );
					inp.addEventListener( 'click', function () { sel.r = ri; sel.c = ci; var fr = w.wp && w.wp.media ? w.wp.media( { multiple: false } ) : null; if ( fr ) { fr.on( 'select', function () { var a = fr.state().get( 'selection' ).first().toJSON(); setCell( ri, ci, { id: a.id, url: a.url } ); } ); fr.open(); } } );
				}
				else { inp = el( 'input', { id: fid, type: 'text' } ); inp.value = show( v, c.type ); }
				if ( 'media' !== c.type ) {
					inp.addEventListener( 'change', function () {
						var nv = 'bool' === c.type ? ( inp.checked ? 'yes' : '' ) : normalise( c, inp.value );
						undo.push( snap() ); redo = []; dirty = true; r.v[ ci ] = nv; r.x[ ci ] = undefined; btns.undo.disabled = false;
					} );
				}
				if ( 'bool' === c.type ) { f = el( 'label', { class: 'we-f we-f-bool', for: fid }, [ inp, el( 'span', { text: ' ' + c.label } ) ] ); }
				else { f = el( 'div', { class: 'we-f' }, [ el( 'label', { for: fid, text: c.label } ), inp ] ); }
				grid.appendChild( f );
			} );
			li.appendChild( grid );
			li.addEventListener( 'dragstart', function ( e ) { if ( r.fixed ) { e.preventDefault(); return; } e.dataTransfer.setData( 'text/plain', String( ri ) ); e.dataTransfer.effectAllowed = 'move'; li.classList.add( 'is-drag' ); } );
			li.addEventListener( 'dragend', function () { li.classList.remove( 'is-drag' ); } );
			li.addEventListener( 'dragover', function ( e ) { e.preventDefault(); li.classList.add( 'is-over' ); } );
			li.addEventListener( 'dragleave', function () { li.classList.remove( 'is-over' ); } );
			li.addEventListener( 'drop', function ( e ) {
				e.preventDefault(); li.classList.remove( 'is-over' );
				var from = parseInt( e.dataTransfer.getData( 'text/plain' ), 10 ); if ( isNaN( from ) || from === ri || rows[ ri ].fixed ) { return; }
				mutate( function () { var m = rows.splice( from, 1 )[ 0 ]; rows.splice( ri, 0, m ); sel.r = ri; } );
			} );
			return li;
		}

		/* ---------------------------------------------------------------- close / save */
		function close() {
			finishEdit( false );
			d.removeEventListener( 'keydown', onKey, true );
			if ( back.parentNode ) { back.parentNode.removeChild( back ); }
			d.documentElement.classList.remove( 'we-open' );
			if ( lastFocus && lastFocus.focus ) { try { lastFocus.focus(); } catch ( e ) {} }
		}
		function save() {
			finishEdit( true );
			var out = { columns: clone( cols ), rows: clone( rows ) };
			close();
			if ( opt.onSave ) { opt.onSave( out ); }
		}
		function attempt() { if ( ! dirty || w.confirm( T.discard ) ) { close(); } }
		bSave.addEventListener( 'click', save ); bCancel.addEventListener( 'click', attempt ); bX.addEventListener( 'click', attempt );
		back.addEventListener( 'mousedown', function ( e ) { if ( e.target === back ) { attempt(); } } );
		function onKey( e ) {
			if ( ! back.parentNode ) { return; }
			if ( 'Escape' === e.key && ! editing && ! ( w.wp && w.wp.media && d.querySelector( '.media-modal:not([style*="display: none"])' ) ) ) { e.stopPropagation(); e.preventDefault(); attempt(); return; }
			if ( 'Tab' === e.key && ! editing && ! d.querySelector( '.media-modal' ) ) {
				var f = box.querySelectorAll( 'button:not([disabled]),input,select,textarea,table[tabindex]' ), vis = [].filter.call( f, function ( n ) { return n.offsetParent; } );
				if ( ! vis.length ) { return; }
				var first = vis[ 0 ], last = vis[ vis.length - 1 ];
				if ( ! box.contains( d.activeElement ) ) { e.preventDefault(); first.focus(); }
				else if ( e.shiftKey && d.activeElement === first ) { e.preventDefault(); last.focus(); }
				else if ( ! e.shiftKey && d.activeElement === last ) { e.preventDefault(); first.focus(); }
			}
		}
		d.addEventListener( 'keydown', onKey, true );
		render();
		return { close: close, save: save, getState: function () { return { columns: clone( cols ), rows: clone( rows ) }; } };
	}

	w.WakooSheetEditor = { open: open, version: 1 };
}( window, document ) );
