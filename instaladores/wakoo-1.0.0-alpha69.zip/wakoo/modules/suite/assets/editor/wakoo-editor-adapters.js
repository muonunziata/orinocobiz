/**
 * Connects the Elementor editor to WakooSheetEditor (wakoo-editor.js). Runs only in the editor.
 *
 * Panel button (control type 'editor_btn' / Controls_Manager::BUTTON with event "wakoo:editor:open") carries:
 *   wakoo_adapter: 'repeater' | 'sheet' | 'matrix'
 *   repeater : wakoo_target = id of a REPEATER control (columns = its fields), wakoo_mode = grid|cards
 *   sheet    : wakoo_kind = 'datatable' | 'compare' (data stored as JSON in the widget's hidden "sheet" control)
 *   matrix   : Happy tables. wakoo_head / wakoo_rows = repeater ids, wakoo_head_text / wakoo_cell_text = text field ids
 * Widgets with an "Editar tabla" button in their preview open the same adapters (see PREVIEW below).
 */
( function ( w, $ ) {
	'use strict';
	if ( ! w.WakooSheetEditor ) { return; }
	var E = w.WakooSheetEditor, MAXC = 30;

	function clone( o ) { return JSON.parse( JSON.stringify( o ) ); }
	function widgetType( c ) { return c.model.get( 'widgetType' ); }
	function ctrlDefs( c ) { var wc = w.elementor.widgetsCache[ widgetType( c ) ]; return wc ? wc.controls : {}; }
	function ctrlDefault( c, id ) { var d = ctrlDefs( c )[ id ]; return d ? d[ 'default' ] : undefined; }
	function setting( c, id ) { return c.settings.get( id ); }
	function rid() { return Math.random().toString( 16 ).slice( 2, 9 ); }

	/** Plain items of a repeater (only values different from the defaults, plus _id). */
	function items( c, name ) {
		var col = setting( c, name ), out = [];
		if ( col && col.models ) { col.models.forEach( function ( m ) { var j; try { j = m.toJSON( { remove: [ 'default' ] } ); } catch ( e ) { j = m.toJSON(); } j._id = m.get( '_id' ); out.push( j ); } ); }
		else if ( Array.isArray( col ) ) { out = clone( col ); }
		return out;
	}
	/** Writes a whole repeater in one undoable step, keeping the _id of each item. */
	function writeRepeaters( c, map, title ) {
		var logId = w.$e.internal( 'document/history/start-log', { type: 'change', title: title || 'Wakoo', subTitle: '', elementType: widgetType( c ) } );
		try {
			Object.keys( map ).forEach( function ( name ) {
				map[ name ].forEach( function ( it ) { if ( ! it._id ) { it._id = rid(); } } );
				var o = {}; o[ name ] = clone( map[ name ] );
				w.$e.run( 'document/elements/settings', { container: c, settings: o } );
			} );
		} finally { w.$e.internal( 'document/history/end-log', { id: logId } ); }
		if ( c.view && c.view.renderOnChange ) { c.view.renderOnChange(); }
	}
	function writeSettings( c, o, title ) {
		var logId = w.$e.internal( 'document/history/start-log', { type: 'change', title: title || 'Wakoo', subTitle: '', elementType: widgetType( c ) } );
		try { w.$e.run( 'document/elements/settings', { container: c, settings: o } ); } finally { w.$e.internal( 'document/history/end-log', { id: logId } ); }
	}

	/* ---------------------------------------------------------------- repeater adapter */
	var TYPE = { text: 'text', textarea: 'textarea', wysiwyg: 'textarea', number: 'number', select: 'select', switcher: 'bool', media: 'media', url: 'url', color: 'text' };
	function openRepeater( c, name, mode, title ) {
		var defs = ctrlDefs( c )[ name ]; if ( ! defs || ! defs.fields ) { return; }
		var fields = [];
		Object.keys( defs.fields ).forEach( function ( fid ) {
			var f = defs.fields[ fid ], t = TYPE[ f.type ];
			if ( ! t || /^_/.test( fid ) ) { return; }
			var col = { id: fid, label: f.label || fid, type: t };
			if ( 'select' === t ) { col.options = f.options || {}; }
			fields.push( col );
		} );
		var data = items( c, name );
		var rows = data.map( function ( it ) {
			return { v: fields.map( function ( f ) { var v = it[ f.id ]; if ( undefined === v ) { v = ctrlDefault( c, name ) ? ( defs.fields[ f.id ][ 'default' ] ) : defs.fields[ f.id ][ 'default' ]; } if ( 'bool' === f.type ) { return v ? 'yes' : ''; } if ( 'media' === f.type ) { return v && v.url ? { id: v.id, url: v.url } : ''; } if ( 'url' === f.type ) { return v && v.url ? v : ''; } return null === v || undefined === v ? '' : v; } ), x: [], data: it };
		} );
		E.open( {
			title: title || ( defs.label || name ), mode: mode || 'grid', columns: fields, rows: rows, dynamicColumns: false, maxRows: 500,
			newRow: function () {
				var it = { _id: rid() };
				fields.forEach( function ( f ) { var df = defs.fields[ f.id ][ 'default' ]; if ( undefined !== df ) { it[ f.id ] = clone( df ); } } );
				return { v: fields.map( function ( f ) { var df = defs.fields[ f.id ][ 'default' ]; if ( 'bool' === f.type ) { return df ? 'yes' : ''; } if ( 'media' === f.type || 'url' === f.type ) { return ''; } return undefined === df ? '' : df; } ), x: [], data: it };
			},
			dupData: function ( d ) { var n = clone( d || {} ); n._id = rid(); return n; },
			onSave: function ( res ) {
				var out = res.rows.map( function ( r ) {
					var it = clone( r.data || {} ); it._id = it._id || rid();
					fields.forEach( function ( f, i ) {
						var v = r.v[ i ];
						if ( 'bool' === f.type ) { it[ f.id ] = v ? 'yes' : ''; }
						else if ( 'media' === f.type ) { it[ f.id ] = v ? { id: v.id, url: v.url, source: 'library' } : { id: '', url: '' }; }
						else if ( 'url' === f.type ) { it[ f.id ] = v && v.url ? { url: v.url, is_external: v.is_external || '', nofollow: '', custom_attributes: '' } : { url: '', is_external: '', nofollow: '', custom_attributes: '' }; }
						else { it[ f.id ] = v; }
					} );
					return it;
				} );
				var m = {}; m[ name ] = out; writeRepeaters( c, m, title || name );
			}
		} );
	}

	/* ---------------------------------------------------------------- csv */
	function parseCsv( text, delim ) {
		var out = [], row = [], cell = '', q = false, i, ch;
		text = String( text || '' ).replace( /^﻿/, '' ).replace( /\r\n?/g, '\n' );
		for ( i = 0; i < text.length; i++ ) {
			ch = text[ i ];
			if ( q ) { if ( '"' === ch && '"' === text[ i + 1 ] ) { cell += '"'; i++; } else if ( '"' === ch ) { q = false; } else { cell += ch; } }
			else if ( '"' === ch && '' === cell ) { q = true; }
			else if ( ch === delim ) { row.push( cell ); cell = ''; }
			else if ( '\n' === ch ) { row.push( cell ); out.push( row ); row = []; cell = ''; }
			else { cell += ch; }
		}
		if ( cell !== '' || row.length ) { row.push( cell ); out.push( row ); }
		return out.filter( function ( r ) { return r.join( '' ).trim() !== ''; } );
	}
	function delimOf( s ) { var d = s || ','; return 'tab' === d ? '\t' : ( [ ',', ';', '|' ].indexOf( d ) > -1 ? d : ',' ); }
	function rectangular( m ) { var n = 0; m.forEach( function ( r ) { n = Math.max( n, r.length ); } ); n = Math.min( n, MAXC ); m.forEach( function ( r ) { r.length = n; for ( var i = 0; i < n; i++ ) { if ( undefined === r[ i ] ) { r[ i ] = ''; } } } ); return n; }

	/* ---------------------------------------------------------------- Suite datatable (sheet) */
	function openDatatable( c ) {
		function go( matrix ) {
			var head = matrix.length ? matrix.shift() : [ 'Columna 1', 'Columna 2' ];
			var n = Math.max( head.length, 1 ); matrix.forEach( function ( r ) { n = Math.max( n, r.length ); } ); n = Math.min( n, MAXC );
			var cols = []; for ( var i = 0; i < n; i++ ) { cols.push( { id: 'c' + i, label: head[ i ] || ( 'Columna ' + ( i + 1 ) ), type: 'text' } ); }
			E.open( {
				title: 'Tabla de datos', dynamicColumns: true, minCols: 1, maxCols: MAXC, maxRows: 2000, allowModes: true,
				columns: cols, rows: matrix.map( function ( r ) { var v = []; for ( var j = 0; j < n; j++ ) { v.push( r[ j ] || '' ); } return { v: v, x: [] }; } ),
				newCol: function ( at ) { return { label: 'Columna ' + ( at + 1 ), type: 'text' }; },
				onSave: function ( res ) {
					var sheet = JSON.stringify( { head: res.columns.map( function ( k ) { return k.label || ''; } ), rows: res.rows.map( function ( r ) { return r.v.map( String ); } ) } );
					writeSettings( c, { sheet: sheet }, 'Tabla de datos' );
				}
			} );
		}
		var raw = setting( c, 'sheet' ), j = null;
		try { j = raw ? JSON.parse( raw ) : null; } catch ( e ) { j = null; }
		if ( j && Array.isArray( j.head ) ) { go( [ j.head ].concat( j.rows || [] ) ); return; }
		var hasHead = 'no' !== setting( c, 'header' ) && '' !== setting( c, 'header' ) ;
		if ( 'file' === setting( c, 'source' ) && setting( c, 'file' ) && setting( c, 'file' ).url ) {
			w.fetch( setting( c, 'file' ).url, { credentials: 'same-origin' } ).then( function ( r ) { return r.text(); } ).then( function ( t ) { go( withHead( parseCsv( t, delimOf( setting( c, 'delim' ) ) ), hasHead ) ); } ).catch( function () { go( [] ); } );
			return;
		}
		go( withHead( parseCsv( setting( c, 'csv' ) || ctrlDefault( c, 'csv' ), delimOf( setting( c, 'delim' ) ) ), hasHead ) );
	}
	function withHead( m, hasHead ) { if ( ! hasHead && m.length ) { var n = 0; m.forEach( function ( r ) { n = Math.max( n, r.length ); } ); var h = []; for ( var i = 0; i < n; i++ ) { h.push( 'Columna ' + ( i + 1 ) ); } m.unshift( h ); } return m; }

	/* ---------------------------------------------------------------- Suite compare (sheet) */
	var META = [ [ 'Precio', 'pr' ], [ 'Imagen (URL)', 'img' ], [ 'Enlace (URL)', 'url' ] ];
	function compareFromProducts( c ) {
		var ps = items( c, 'products' ), defs = ctrlDefs( c ).products, dflt = defs && defs[ 'default' ] ? defs[ 'default' ] : [];
		if ( ! setting( c, 'products' ) || ! ps.length ) { ps = clone( dflt ); }
		var prods = ps.map( function ( p ) { return { n: p.name || '', pr: p.price || '', img: p.image && p.image.url ? p.image.url : '', url: p.url && p.url.url ? p.url.url : '' }; } );
		var map = {}, order = [];
		ps.forEach( function ( p, i ) {
			String( p.specs || '' ).split( /\r\n|\r|\n/ ).forEach( function ( line ) {
				var a = line.split( '::' ).map( function ( s ) { return s.trim(); } ), g, f, v;
				if ( a.length >= 3 ) { g = a[ 0 ]; f = a[ 1 ]; v = a.slice( 2 ).join( '::' ); } else if ( 2 === a.length && a[ 0 ] ) { g = ''; f = a[ 0 ]; v = a[ 1 ]; } else { return; }
				if ( ! f ) { return; }
				var k = g + '\u0001' + f; if ( ! map[ k ] ) { map[ k ] = { g: g, f: f, v: [] }; order.push( k ); }
				map[ k ].v[ i ] = v;
			} );
		} );
		return { p: prods, r: order.map( function ( k ) { var o = map[ k ]; var row = [ o.g, o.f ]; for ( var i = 0; i < prods.length; i++ ) { row.push( o.v[ i ] || '' ); } return row; } ) };
	}
	function openCompare( c ) {
		var raw = setting( c, 'sheet' ), s = null;
		try { s = raw ? JSON.parse( raw ) : null; } catch ( e ) { s = null; }
		if ( ! s || ! Array.isArray( s.p ) ) { s = compareFromProducts( c ); }
		var cols = [ { id: 'g', label: 'Grupo', type: 'text' }, { id: 'f', label: 'Característica', type: 'text' } ];
		s.p.forEach( function ( p, i ) { cols.push( { id: 'p' + i, label: p.n || ( 'Producto ' + ( i + 1 ) ), type: 'text' } ); } );
		var rows = META.map( function ( m ) { return { fixed: true, v: [ '', m[ 0 ] ].concat( s.p.map( function ( p ) { return p[ m[ 1 ] ] || ''; } ) ), x: [] }; } );
		( s.r || [] ).forEach( function ( r ) { var v = r.slice( 0, 2 + s.p.length ); while ( v.length < 2 + s.p.length ) { v.push( '' ); } rows.push( { v: v, x: [] } ); } );
		E.open( {
			title: 'Comparador de productos', dynamicColumns: true, fixedLeft: 2, minCols: 3, maxCols: 8, maxRows: 300,
			hint: 'Cada columna es un producto (doble clic en el nombre para renombrarla). Las 3 primeras filas son precio, imagen y enlace. Escribe el grupo y la característica en las filas siguientes.',
			columns: cols, rows: rows,
			newCol: function ( at ) { return { label: 'Producto ' + ( at - 1 ), type: 'text' }; },
			onSave: function ( res ) {
				var np = res.columns.length - 2, prods = [];
				for ( var i = 0; i < np; i++ ) { prods.push( { n: res.columns[ i + 2 ].label || '', pr: res.rows[ 0 ].v[ i + 2 ] || '', img: res.rows[ 1 ].v[ i + 2 ] || '', url: res.rows[ 2 ].v[ i + 2 ] || '' } ); }
				var body = res.rows.slice( 3 ).map( function ( r ) { return r.v.map( String ); } ).filter( function ( r ) { return r[ 1 ].trim() !== ''; } );
				writeSettings( c, { sheet: JSON.stringify( { p: prods, r: body } ) }, 'Comparador' );
			}
		} );
	}

	/* ---------------------------------------------------------------- Happy tables (matrix) */
	/** Row/cell marker; 'row' is the control default, so toJSON({remove:default}) drops it. */
	function rtype( it ) { return undefined === it.row_column_type ? 'row' : it.row_column_type; }
	function openMatrix( c, cfg ) {
		var heads = items( c, cfg.head ), flat = items( c, cfg.rows ), tcell = cfg.cellText, thead = cfg.headText;
		var rowsOut = [], cur = null;
		flat.forEach( function ( it ) {
			if ( rtype( it ) === 'row' ) { cur = { v: [], x: [], data: it }; rowsOut.push( cur ); return; }
			if ( ! cur ) { cur = { v: [], x: [], data: { row_column_type: 'row', _id: rid() } }; rowsOut.push( cur ); }
			var nonText = '';
			if ( it.column_content_type && 'text' !== it.column_content_type && 'blank' !== it.column_content_type ) { nonText = 'icon' === it.column_content_type ? '◆ icono' : '🖼 imagen'; }
			else if ( it.row_icons && it.row_icons.value || it.row_image && it.row_image.url ) { nonText = it.row_image && it.row_image.url ? '🖼 imagen' : '◆ icono'; }
			cur.v.push( it[ tcell ] || '' ); cur.x.push( { item: it, orig: it[ tcell ] || '', nonText: nonText && ! ( it[ tcell ] ) ? nonText : '' } );
		} );
		var cols = heads.map( function ( h ) { return { id: h._id, label: h[ thead ] || '', type: 'text', x: h }; } );
		function newHead( at ) {
			var h = {}; var defs = ctrlDefs( c )[ cfg.head ].fields;
			Object.keys( defs ).forEach( function ( k ) { if ( ! /^_/.test( k ) && undefined !== defs[ k ][ 'default' ] && /column_name|column_media|title_tag|column_span/.test( k ) ) { h[ k ] = clone( defs[ k ][ 'default' ] ); } } );
			h._id = rid(); h[ thead ] = 'Columna ' + ( at + 1 ); return h;
		}
		E.open( {
			title: cfg.title, dynamicColumns: true, minCols: 1, maxCols: 12, maxRows: 300, allowModes: false,
			columns: cols, rows: rowsOut,
			newCol: function ( at ) { var h = newHead( at ); return { id: h._id, label: h[ thead ], type: 'text', x: h }; },
			newRow: function ( cs ) { return { v: cs.map( function () { return ''; } ), x: [], data: { row_column_type: 'row', _id: rid() } }; },
			dupData: function ( d ) { var n = clone( d || { row_column_type: 'row' } ); n._id = rid(); return n; },
			onSave: function ( res ) {
				var hs = res.columns.map( function ( k, i ) { var h = k.x ? clone( k.x ) : newHead( i ); h[ thead ] = k.label; h._id = h._id || rid(); return h; } );
				var fl = [];
				res.rows.forEach( function ( r ) {
					var marker = clone( r.data || { row_column_type: 'row' } ); marker.row_column_type = 'row'; marker._id = marker._id || rid(); fl.push( marker );
					r.v.forEach( function ( v, i ) {
						var x = r.x[ i ], it;
						if ( x && x.item ) { it = clone( x.item ); } else { it = { row_column_type: 'column', _id: rid() }; }
						it.row_column_type = 'column'; it._id = it._id || rid();
						if ( ! x || ! x.item || v !== x.orig ) { it[ tcell ] = v; if ( cfg.setType && '' !== v ) { it.column_content_type = 'text'; } }
						fl.push( it );
					} );
				} );
				var m = {}; m[ cfg.head ] = hs; m[ cfg.rows ] = fl; writeRepeaters( c, m, cfg.title );
			}
		} );
	}

	/* ---------------------------------------------------------------- wiring */
	var MATRIX = {
		'wk-comparison-table': { head: 'columns_data', rows: 'rows_data', headText: 'column_name', cellText: 'column_text', setType: true, title: 'Tabla comparativa' },
		'wk-data-table': { head: 'columns_data', rows: 'rows_data', headText: 'column_name', cellText: 'cell_name', setType: false, title: 'Tabla de datos' }
	};
	function openFor( c, ctl ) {
		var t = widgetType( c );
		if ( 'wakoo-datatable' === t ) { return openDatatable( c ); }
		if ( 'wakoo-compare' === t ) { return openCompare( c ); }
		if ( MATRIX[ t ] ) { return openMatrix( c, MATRIX[ t ] ); }
		if ( ctl && ctl.wakoo_target ) { return openRepeater( c, ctl.wakoo_target, ctl.wakoo_mode, ctl.wakoo_title ); }
	}
	E.openFor = openFor;
	E.openRepeater = openRepeater;

	$( w ).on( 'elementor:init', function () {
		w.elementor.channels.editor.on( 'wakoo:editor:open', function ( view ) {
			var c = view.container || ( view.options && view.options.container ), ctl = view.model ? view.model.attributes : {};
			if ( c ) { openFor( c, ctl ); }
		} );
		w.elementor.on( 'preview:loaded', function () {
			// PREVIEW: "Editar tabla" buttons rendered by the widgets inside the preview iframe.
			w.elementor.$previewContents.on( 'click', '.wks-ed-open, .wk-ed-open', function ( ev ) {
				ev.preventDefault(); ev.stopPropagation();
				var id = $( ev.currentTarget ).closest( '.elementor-element[data-id]' ).attr( 'data-id' );
				var c = id && w.elementor.getContainer( id ); if ( c ) { openFor( c ); }
			} );
		} );
	} );
}( window, window.jQuery ) );
