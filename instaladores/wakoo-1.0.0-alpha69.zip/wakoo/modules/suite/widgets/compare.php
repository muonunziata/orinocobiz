<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;

defined( 'ABSPATH' ) || die();

/** Comparador de productos: columnas por producto, filas de características agrupadas. */
class Compare extends Base {

	const MAX_PRODUCTS = 6;

	public function slug() { return 'compare'; }
	public function label() { return __( 'Comparador de productos', 'wakoo' ); }
	public function cat() { return 'commerce'; }
	public function icon() { return 'eicon-price-table'; }
	public function words() { return [ 'comparar', 'comparador', 'productos', 'características', 'tabla' ]; }

	protected function sections() {
		return [
			[ 'id' => 'sec_products', 'label' => __( 'Productos', 'wakoo' ), 'controls' => [
				'edit'     => [ 't' => 'editor_btn', 'l' => __( 'Editar como hoja (productos en columnas)', 'wakoo' ) ],
				'sheet'    => [ 't' => 'hidden', 'd' => '' ],
				'products' => [ 't' => 'repeater', 'title' => '{{{ name }}}', 'fields' => [
					'name'  => [ 't' => 'text', 'l' => __( 'Nombre', 'wakoo' ), 'd' => __( 'Producto', 'wakoo' ) ],
					'image' => [ 't' => 'media', 'l' => __( 'Imagen', 'wakoo' ) ],
					'price' => [ 't' => 'text', 'l' => __( 'Precio', 'wakoo' ), 'd' => '' ],
					'url'   => [ 't' => 'url', 'l' => __( 'Enlace', 'wakoo' ), 'd' => [ 'url' => '' ] ],
					'specs' => [ 't' => 'textarea', 'l' => __( 'Características (Grupo::Característica::Valor, una por línea)', 'wakoo' ), 'd' => '', 'rows' => 8 ],
				], 'd' => [
					[ 'name' => 'Básico', 'price' => '9 €', 'specs' => "General::Usuarios::1\nGeneral::Almacenamiento::10 GB\nSoporte::Respuesta::48 h\nSoporte::Chat::No" ],
					[ 'name' => 'Pro', 'price' => '29 €', 'specs' => "General::Usuarios::5\nGeneral::Almacenamiento::100 GB\nSoporte::Respuesta::24 h\nSoporte::Chat::Sí" ],
					[ 'name' => 'Empresa', 'price' => '79 €', 'specs' => "General::Usuarios::Ilimitados\nGeneral::Almacenamiento::1 TB\nSoporte::Respuesta::1 h\nSoporte::Chat::Sí" ],
				] ],
			] ],
			[ 'id' => 'sec_opts', 'label' => __( 'Opciones', 'wakoo' ), 'controls' => [
				'highlight' => [ 't' => 'switch', 'l' => __( 'Resaltar diferencias', 'wakoo' ), 'd' => 'yes' ],
				'selector'  => [ 't' => 'switch', 'l' => __( 'Selector de productos a mostrar', 'wakoo' ), 'd' => 'yes' ],
				'min_show'  => [ 't' => 'number', 'l' => __( 'Mínimo de productos visibles', 'wakoo' ), 'd' => 2, 'min' => 1, 'max' => 6, 'c' => [ 'selector' => 'yes' ] ],
				'btn'       => [ 't' => 'text', 'l' => __( 'Texto del botón de enlace', 'wakoo' ), 'd' => __( 'Ver producto', 'wakoo' ) ],
				'diff_lbl'  => [ 't' => 'text', 'l' => __( 'Etiqueta "solo diferencias"', 'wakoo' ), 'd' => __( 'Solo diferencias', 'wakoo' ), 'c' => [ 'highlight' => 'yes' ] ],
			] ],
		];
	}

	/** Products and spec rows from the spreadsheet editor, in the same shape as the repeater; null if none. */
	private function from_sheet( array $s ) {
		$j = self::json_in( $s['sheet'] ?? '' );
		if ( ! $j || empty( $j['p'] ) || ! is_array( $j['p'] ) ) { return null; }
		$url = static function ( $u ) { $u = esc_url_raw( trim( (string) $u ), [ 'http', 'https' ] ); return $u; };
		$prods = [];
		foreach ( array_slice( array_values( $j['p'] ), 0, self::MAX_PRODUCTS ) as $p ) {
			$p = (array) $p;
			$prods[] = [ 'name' => self::cell( $p['n'] ?? '', 120 ), 'price' => self::cell( $p['pr'] ?? '', 60 ), 'image' => [ 'url' => $url( $p['img'] ?? '' ) ], 'url' => [ 'url' => $url( $p['url'] ?? '' ) ] ];
		}
		$n      = count( $prods );
		$groups = [];
		foreach ( array_slice( (array) ( $j['r'] ?? [] ), 0, 300 ) as $r ) {
			if ( ! is_array( $r ) || count( $r ) < 2 ) { continue; }
			$g = self::cell( $r[0], 120 ); $f = self::cell( $r[1], 120 );
			if ( '' === $f ) { continue; }
			for ( $i = 0; $i < $n; $i++ ) { $groups[ $g ][ $f ][ $i ] = self::cell( $r[ $i + 2 ] ?? '', 300 ); }
		}
		return [ $prods, $groups ];
	}

	protected function draw( array $s ) {
		$sheet  = $this->from_sheet( $s );
		$prods  = $sheet ? $sheet[0] : array_slice( array_values( (array) $s['products'] ), 0, 3 );
		if ( ! $prods ) { return; }
		$groups = $sheet ? $sheet[1] : []; // group => [ spec => [ idx => value ] ]
		foreach ( $sheet ? [] : $prods as $i => $p ) {
			foreach ( preg_split( '/\r\n|\r|\n/', (string) ( $p['specs'] ?? '' ) ) as $line ) {
				$parts = array_map( 'trim', explode( '::', $line, 3 ) );
				if ( 3 === count( $parts ) && '' !== $parts[1] ) { $groups[ $parts[0] ][ $parts[1] ][ $i ] = $parts[2]; }
				elseif ( 2 === count( $parts ) && '' !== $parts[0] && '' !== $parts[1] ) { $groups[''][ $parts[0] ][ $i ] = $parts[1]; }
			}
		}
		$this->edit_btn( __( 'Editar tabla', 'wakoo' ) );
		$this->open( [ 'highlight' => 'yes' === $s['highlight'], 'selector' => 'yes' === $s['selector'] && count( $prods ) > 1, 'min' => max( 1, min( count( $prods ), (int) $s['min_show'] ) ), 'diff' => (string) $s['diff_lbl'], 'names' => array_map( function ( $p ) { return (string) ( $p['name'] ?? '' ); }, $prods ) ] );
		echo '<div class="wks-cmp__wrap"><table class="wks-cmp__table"><thead><tr><th scope="col"><span class="wks-sr">' . esc_html__( 'Característica', 'wakoo' ) . '</span></th>';
		foreach ( $prods as $i => $p ) {
			echo '<th scope="col" class="wks-cmp__prod" data-col="' . (int) $i . '">';
			$img = $this->img( $p['image'] ?? null );
			if ( $img ) { echo '<img src="' . $img . '" alt="" loading="lazy">'; }
			echo '<div class="wks-cmp__name">' . esc_html( $p['name'] ?? '' ) . '</div>';
			if ( ! empty( $p['price'] ) ) { echo '<div class="wks-cmp__price">' . esc_html( $p['price'] ) . '</div>'; }
			if ( ! empty( $p['url']['url'] ) ) { echo '<a class="wks-btn"' . $this->link_attrs( $p['url'] ) . '>' . esc_html( $s['btn'] ) . '</a>'; }
			echo '</th>';
		}
		echo '</tr></thead><tbody>';
		$cols = count( $prods ) + 1;
		foreach ( $groups as $g => $specs ) {
			if ( '' !== $g ) { echo '<tr class="wks-cmp__group"><th colspan="' . (int) $cols . '" scope="colgroup">' . esc_html( $g ) . '</th></tr>'; }
			foreach ( $specs as $name => $vals ) {
				echo '<tr class="wks-cmp__row"><th scope="row">' . esc_html( $name ) . '</th>';
				foreach ( $prods as $i => $p ) { echo '<td data-col="' . (int) $i . '">' . ( isset( $vals[ $i ] ) ? esc_html( $vals[ $i ] ) : '—' ) . '</td>'; }
				echo '</tr>';
			}
		}
		echo '</tbody></table></div>';
		$this->close();
	}
}
