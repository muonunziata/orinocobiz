<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;
use Wakoo\Modules\Suite\Module;

defined( 'ABSPATH' ) || die();

/**
 * Modo nocturno automático. Guardado en una plantilla (cabecera, pie, Theme Builder, [wakoo_template]) se aplica a todo el sitio:
 * al guardar el documento se memoriza su configuración (opción `wakoo_dark_mode`) y un único script mínimo en <head> evita el parpadeo.
 * La elección del visitante se guarda en localStorage (`wakoo-theme`) y la comparte el conmutador de contenido.
 */
class DarkMode extends Base {

	const OPTION = 'wakoo_dark_mode';

	public function slug() { return 'dark-mode'; }
	public function label() { return __( 'Modo nocturno', 'wakoo' ); }
	public function icon() { return 'eicon-adjust'; }
	public function words() { return [ 'dark', 'oscuro', 'noche', 'nocturno', 'tema', 'interruptor' ]; }

	public function get_script_depends() { self::dm_register(); return [ 'wakoo-theme', 'wakoo-suite-dark-mode' ]; }
	public function get_style_depends() { self::dm_register(); return [ 'wakoo-theme', 'wakoo-suite-dark-mode' ]; }

	protected function sections() {
		return [
			[ 'id' => 'sec_mode', 'label' => __( 'Comportamiento', 'wakoo' ), 'controls' => [
				'note'     => [ 't' => 'note', 'l' => __( 'Colócalo en una plantilla global (cabecera o pie): todas las páginas que la usen compartirán este modo. La elección del visitante se recuerda en su navegador.', 'wakoo' ) ],
				'def'      => [ 't' => 'select', 'l' => __( 'Modo inicial', 'wakoo' ), 'd' => 'auto', 'o' => [
					'auto'  => __( 'Automático (sistema u horario)', 'wakoo' ),
					'light' => __( 'Diurno', 'wakoo' ),
					'dark'  => __( 'Nocturno', 'wakoo' ),
				] ],
				'sched'    => [ 't' => 'switch', 'l' => __( 'Noche automática por horas', 'wakoo' ), 'c' => [ 'def' => 'auto' ] ],
				'from'     => [ 't' => 'number', 'l' => __( 'Empieza la noche a las (0-23)', 'wakoo' ), 'd' => 20, 'min' => 0, 'max' => 23, 'c' => [ 'def' => 'auto', 'sched' => 'yes' ] ],
				'to'       => [ 't' => 'number', 'l' => __( 'Termina la noche a las (0-23)', 'wakoo' ), 'd' => 7, 'min' => 0, 'max' => 23, 'c' => [ 'def' => 'auto', 'sched' => 'yes' ] ],
			] ],
			[ 'id' => 'sec_look', 'label' => __( 'Aspecto nocturno', 'wakoo' ), 'controls' => [
				'method'   => [ 't' => 'select', 'l' => __( 'Método', 'wakoo' ), 'd' => 'invert', 'o' => [
					'invert' => __( 'Inversión inteligente (cualquier diseño; no invierte imágenes ni vídeos)', 'wakoo' ),
					'colors' => __( 'Colores propios (fondo, texto y acento)', 'wakoo' ),
				] ],
				'bg'       => [ 't' => 'color', 'l' => __( 'Fondo', 'wakoo' ), 'd' => '#0f1115', 'c' => [ 'method' => 'colors' ] ],
				'text'     => [ 't' => 'color', 'l' => __( 'Texto', 'wakoo' ), 'd' => '#e8e8ee', 'c' => [ 'method' => 'colors' ] ],
				'accent'   => [ 't' => 'color', 'l' => __( 'Acento (enlaces)', 'wakoo' ), 'd' => '#8b7bff', 'c' => [ 'method' => 'colors' ] ],
				'css'      => [ 't' => 'code', 'l' => __( 'CSS extra del modo nocturno (solo usuarios con HTML sin filtrar)', 'wakoo' ), 'desc' => __( 'Se aplica bajo html[data-wakoo-theme="dark"].', 'wakoo' ) ],
			] ],
			[ 'id' => 'sec_btn', 'label' => __( 'Interruptor visible', 'wakoo' ), 'controls' => [
				'show'     => [ 't' => 'switch', 'l' => __( 'Mostrar interruptor', 'wakoo' ), 'd' => 'yes' ],
				'pos'      => [ 't' => 'select', 'l' => __( 'Posición', 'wakoo' ), 'd' => 'inline', 'o' => [
					'inline' => __( 'En línea (donde está el widget)', 'wakoo' ),
					'br'     => __( 'Flotante abajo a la derecha', 'wakoo' ),
					'bl'     => __( 'Flotante abajo a la izquierda', 'wakoo' ),
					'tr'     => __( 'Flotante arriba a la derecha', 'wakoo' ),
					'tl'     => __( 'Flotante arriba a la izquierda', 'wakoo' ),
				], 'c' => [ 'show' => 'yes' ] ],
				'label'    => [ 't' => 'text', 'l' => __( 'Texto del botón (vacío = solo icono)', 'wakoo' ), 'd' => '', 'c' => [ 'show' => 'yes' ] ],
				'aria'     => [ 't' => 'text', 'l' => __( 'Etiqueta accesible', 'wakoo' ), 'd' => __( 'Modo nocturno', 'wakoo' ), 'c' => [ 'show' => 'yes' ] ],
			] ],
		];
	}

	protected function draw( array $s ) {
		$edit = \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode();
		$this->open( self::public_cfg( $s ) , 'wks-dm--' . ( 'yes' === $s['show'] ? sanitize_html_class( $s['pos'] ) : 'hidden' ) );
		if ( 'yes' === $s['show'] ) {
			$sun  = '<svg class="wks-dm__sun" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="4.2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9L17 7M7 17l-2.1 2.1" stroke="currentColor" stroke-width="2" stroke-linecap="round" fill="none"/></svg>';
			$moon = '<svg class="wks-dm__moon" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M20.5 14.5A8.5 8.5 0 0 1 9.5 3.5a8.5 8.5 0 1 0 11 11z"/></svg>';
			echo '<button type="button" class="wks-dm__btn" aria-pressed="false" aria-label="' . esc_attr( $s['aria'] ) . '">' . $sun . $moon; // phpcs:ignore
			if ( '' !== trim( (string) $s['label'] ) ) { echo '<span class="wks-dm__lbl">' . esc_html( $s['label'] ) . '</span>'; }
			echo '</button>';
		} elseif ( $edit ) {
			echo '<p class="wks-dm__note">' . esc_html__( 'Modo nocturno activo (sin interruptor visible).', 'wakoo' ) . '</p>';
		}
		$this->close();
	}

	/* ------------------------------------------------------------ config */

	private static function color( $v, $fallback ) {
		return preg_match( '/^#[0-9a-fA-F]{3,8}$/', (string) $v ) ? $v : $fallback;
	}

	/** Display-level settings, sanitised. Used both for data-wks and the head script. */
	public static function public_cfg( array $s ) {
		$s = $s + self::declared_defaults();
		$h = static function ( $v, $d ) { $v = (int) $v; return ( $v >= 0 && $v <= 23 ) ? $v : $d; };
		return [
			'def'    => in_array( $s['def'], [ 'auto', 'light', 'dark' ], true ) ? $s['def'] : 'auto',
			'sched'  => ( 'yes' === ( $s['sched'] ?? '' ) && 'auto' === ( $s['def'] ?? 'auto' ) ),
			'from'   => $h( $s['from'], 20 ),
			'to'     => $h( $s['to'], 7 ),
			'method' => 'colors' === $s['method'] ? 'colors' : 'invert',
		];
	}

	/* ------------------------------------------------------------ site wide */

	public static function boot() {
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'dm_register' ], 1 );
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'dm_register' ] );
		add_action( 'elementor/frontend/after_register_styles', [ __CLASS__, 'dm_register' ] );
		add_action( 'elementor/editor/after_enqueue_styles', [ __CLASS__, 'dm_register' ] );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'dm_site' ], 5 );
		add_action( 'wp_head', [ __CLASS__, 'dm_head' ], 1 );
		add_action( 'elementor/document/after_save', [ __CLASS__, 'dm_save' ], 10, 2 );
		add_action( 'before_delete_post', [ __CLASS__, 'dm_delete' ] );
		add_action( 'wp_trash_post', [ __CLASS__, 'dm_delete' ] );
	}

	public static function dm_register() {
		$u = WAKOO_MODULES_URL . 'suite/assets/';
		if ( ! wp_script_is( 'wakoo-theme', 'registered' ) ) {
			wp_register_script( 'wakoo-theme', $u . 'js/wakoo-theme.js', [], WAKOO_VERSION, true );
		}
		if ( ! wp_style_is( 'wakoo-theme', 'registered' ) ) {
			wp_register_style( 'wakoo-theme', $u . 'css/wakoo-theme.css', [], WAKOO_VERSION );
		}
	}

	public static function dm_site() {
		if ( get_option( self::OPTION ) ) {
			self::dm_register();
			wp_enqueue_script( 'wakoo-theme' );
			wp_enqueue_style( 'wakoo-theme' );
		}
	}

	/** Walks the saved element tree and returns the settings of the first dark-mode widget found. */
	private static function dm_find( array $els ) {
		foreach ( $els as $el ) {
			if ( ( $el['widgetType'] ?? '' ) === 'wakoo-dark-mode' ) { return (array) ( $el['settings'] ?? [] ); }
			if ( ! empty( $el['elements'] ) ) {
				$f = self::dm_find( (array) $el['elements'] );
				if ( null !== $f ) { return $f; }
			}
		}
		return null;
	}

	public static function dm_save( $document, $data ) {
		$pid = (int) $document->get_main_id();
		$cur = get_option( self::OPTION );
		$s   = self::dm_find( (array) ( $data['elements'] ?? [] ) );
		if ( null === $s ) {
			if ( is_array( $cur ) && (int) ( $cur['post'] ?? 0 ) === $pid ) { delete_option( self::OPTION ); }
			return;
		}
		$s   = $s + self::declared_defaults();
		$css = '';
		if ( current_user_can( 'unfiltered_html' ) ) {
			$css = substr( wp_strip_all_tags( str_replace( '</', '', (string) ( $s['css'] ?? '' ) ) ), 0, 4000 );
		} elseif ( is_array( $cur ) && (int) ( $cur['post'] ?? 0 ) === $pid ) {
			$css = (string) ( $cur['css'] ?? '' );
		}
		update_option( self::OPTION, [
			'post'   => $pid,
			'cfg'    => self::public_cfg( $s ),
			'bg'     => self::color( $s['bg'], '#0f1115' ),
			'text'   => self::color( $s['text'], '#e8e8ee' ),
			'accent' => self::color( $s['accent'], '#8b7bff' ),
			'css'    => $css,
		], true );
	}

	public static function dm_delete( $post_id ) {
		$cur = get_option( self::OPTION );
		if ( is_array( $cur ) && (int) ( $cur['post'] ?? 0 ) === (int) $post_id ) { delete_option( self::OPTION ); }
	}

	/** One small inline script: sets the config and applies the stored or automatic mode before first paint. */
	public static function dm_head() {
		$o = get_option( self::OPTION );
		if ( ! is_array( $o ) || empty( $o['cfg'] ) ) { return; }
		$cfg = wp_json_encode( $o['cfg'], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );
		$js  = '(function(){try{var c=' . $cfg . ',d=document.documentElement,m=null;window.WakooThemeCfg=c;try{m=localStorage.getItem("wakoo-theme")}catch(e){}'
			. 'if(m!=="dark"&&m!=="light"){m=c.def;if(m==="auto"){var h=new Date().getHours(),f=c.from,t=c.to;'
			. 'if(c.sched){m=(f<=t?h>=f&&h<t:h>=f||h<t)?"dark":"light"}else{m=window.matchMedia&&matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}}}'
			. 'd.setAttribute("data-wakoo-dm",c.method);d.setAttribute("data-wakoo-theme",m);d.style.colorScheme=m}catch(e){}})();';
		$css = 'html[data-wakoo-theme="dark"]{--wk-dm-bg:' . $o['bg'] . ';--wk-dm-text:' . $o['text'] . ';--wk-dm-accent:' . $o['accent'] . '}';
		if ( ! empty( $o['css'] ) ) { $css .= 'html[data-wakoo-theme="dark"]{}' . $o['css']; }
		echo "<script id=\"wakoo-theme-boot\">" . $js . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- json encoded with HEX flags, rest are constants.
		echo '<style id="wakoo-theme-vars">' . str_replace( '<', '', $css ) . "</style>\n"; // phpcs:ignore
	}
}
