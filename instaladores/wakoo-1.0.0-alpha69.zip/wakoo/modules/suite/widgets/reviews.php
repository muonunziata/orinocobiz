<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;
use Wakoo\Modules\Suite\Data;
use Wakoo\Modules\Suite\Sec;

defined( 'ABSPATH' ) || die();

/** 3. Reseñas con estrellas: media, formulario de opinión y moderación desde el panel. */
class Reviews extends Base {

	const CPT = 'wakoo_review';

	public function slug() { return 'reviews'; }
	public function label() { return __( 'Reseñas con estrellas', 'wakoo' ); }
	public function cat() { return 'interact'; }
	public function icon() { return 'eicon-star'; }
	public function words() { return [ 'reseñas', 'opiniones', 'estrellas', 'reviews', 'rating' ]; }

	protected function sections() {
		return [
			[ 'id' => 'sec_rev', 'label' => __( 'Reseñas', 'wakoo' ), 'controls' => [
				'title'    => [ 't' => 'text', 'l' => __( 'Título', 'wakoo' ), 'd' => __( 'Opiniones de clientes', 'wakoo' ) ],
				'gkey'     => [ 't' => 'text', 'l' => __( 'Clave de grupo (opcional)', 'wakoo' ), 'desc' => __( 'Usa la misma clave en varios widgets para compartir reseñas. Vacío = solo este widget.', 'wakoo' ) ],
				'item'     => [ 't' => 'text', 'l' => __( 'Nombre del producto/servicio (datos para Google)', 'wakoo' ), 'd' => '' ],
				'schema'   => [ 't' => 'switch', 'l' => __( 'Datos estructurados AggregateRating', 'wakoo' ), 'c' => [ 'item!' => '' ] ],
				'per'      => [ 't' => 'number', 'l' => __( 'Reseñas por página', 'wakoo' ), 'd' => 5, 'min' => 1, 'max' => 30 ],
			] ],
			[ 'id' => 'sec_form', 'label' => __( 'Formulario y moderación', 'wakoo' ), 'controls' => [
				'form'   => [ 't' => 'switch', 'l' => __( 'Mostrar formulario', 'wakoo' ), 'd' => 'yes' ],
				'auto'   => [ 't' => 'switch', 'l' => __( 'Publicar sin moderar', 'wakoo' ), 'desc' => __( 'Apagado: las reseñas quedan pendientes y las apruebas en Reseñas Wakoo.', 'wakoo' ) ],
				'l_name' => [ 't' => 'text', 'l' => __( 'Etiqueta nombre', 'wakoo' ), 'd' => __( 'Nombre', 'wakoo' ) ],
				'l_mail' => [ 't' => 'text', 'l' => __( 'Etiqueta email (no se muestra)', 'wakoo' ), 'd' => __( 'Email (opcional, no se publica)', 'wakoo' ) ],
				'l_text' => [ 't' => 'text', 'l' => __( 'Etiqueta opinión', 'wakoo' ), 'd' => __( 'Tu opinión', 'wakoo' ) ],
				'l_rate' => [ 't' => 'text', 'l' => __( 'Etiqueta puntuación', 'wakoo' ), 'd' => __( 'Puntuación', 'wakoo' ) ],
				'btn'    => [ 't' => 'text', 'l' => __( 'Botón', 'wakoo' ), 'd' => __( 'Enviar reseña', 'wakoo' ) ],
				'ok_pub' => [ 't' => 'text', 'l' => __( 'Mensaje (publicada)', 'wakoo' ), 'd' => __( '¡Gracias! Tu reseña ya está publicada.', 'wakoo' ) ],
				'ok_pen' => [ 't' => 'text', 'l' => __( 'Mensaje (pendiente)', 'wakoo' ), 'd' => __( '¡Gracias! Tu reseña se publicará tras revisarla.', 'wakoo' ) ],
				'more'   => [ 't' => 'text', 'l' => __( 'Botón "ver más"', 'wakoo' ), 'd' => __( 'Ver más reseñas', 'wakoo' ) ],
				'none'   => [ 't' => 'text', 'l' => __( 'Sin reseñas', 'wakoo' ), 'd' => __( 'Aún no hay reseñas. ¡Sé el primero!', 'wakoo' ) ],
			] ],
		];
	}

	private static function stars( $n ) { return str_repeat( '★', (int) $n ) . str_repeat( '☆', 5 - (int) $n ); }

	private static function key_for( $s, $post, $w ) {
		$g = trim( (string) ( $s['gkey'] ?? '' ) );
		return '' !== $g ? 'k:' . mb_substr( $g, 0, 60 ) : 'w:' . (int) $post . ':' . $w;
	}

	private static function summary( $key ) {
		$tk = 'wks_rev_sum_' . md5( $key );
		$c  = get_transient( $tk );
		if ( is_array( $c ) ) { return $c; }
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT m.meta_value AS r, COUNT(*) AS n FROM {$wpdb->postmeta} m
			 JOIN {$wpdb->posts} p ON p.ID = m.post_id AND p.post_type = %s AND p.post_status = 'publish'
			 JOIN {$wpdb->postmeta} k ON k.post_id = p.ID AND k.meta_key = '_wks_key' AND k.meta_value = %s
			 WHERE m.meta_key = '_wks_rating' GROUP BY m.meta_value",
			self::CPT, $key
		) );
		$dist = [ 1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0 ];
		foreach ( (array) $rows as $r ) { if ( isset( $dist[ (int) $r->r ] ) ) { $dist[ (int) $r->r ] += (int) $r->n; } }
		$total = array_sum( $dist );
		$sum   = 0;
		foreach ( $dist as $k => $n ) { $sum += $k * $n; }
		$c = [ 'dist' => $dist, 'total' => $total, 'avg' => $total ? round( $sum / $total, 2 ) : 0 ];
		set_transient( $tk, $c, DAY_IN_SECONDS );
		return $c;
	}

	private static function page( $key, $page, $per ) {
		$q = new \WP_Query( [
			'post_type' => self::CPT, 'post_status' => 'publish', 'posts_per_page' => $per, 'paged' => max( 1, $page ),
			'meta_key' => '_wks_key', 'meta_value' => $key, 'no_found_rows' => false, 'orderby' => 'date', 'order' => 'DESC',
			'update_post_term_cache' => false,
		] );
		$out = [];
		foreach ( $q->posts as $p ) {
			$out[] = [ 'name' => (string) $p->post_title, 'text' => (string) $p->post_content, 'rating' => (int) get_post_meta( $p->ID, '_wks_rating', true ), 'date' => get_the_date( '', $p ) ];
		}
		return [ 'items' => $out, 'pages' => (int) $q->max_num_pages ];
	}

	protected function draw( array $s ) {
		$ctx = $this->ctx();
		$key = self::key_for( $s, $ctx['post'], $ctx['w'] );
		$sum = self::summary( $key );
		$per = max( 1, min( 30, (int) $s['per'] ) );
		$pg  = self::page( $key, 1, $per );
		$this->open( [ 'per' => $per, 'pages' => $pg['pages'], 'ok_pub' => (string) $s['ok_pub'], 'ok_pen' => (string) $s['ok_pen'], 'none' => (string) $s['none'] ] );
		if ( $s['title'] ) { echo '<h3 class="wks-group-title" style="margin-top:0">' . esc_html( $s['title'] ) . '</h3>'; }
		echo '<div class="wks-rev__sum wks-card"><div class="wks-rev__avg"><b>' . esc_html( number_format_i18n( $sum['avg'], 1 ) ) . '</b><span class="wks-stars" aria-label="' . esc_attr( sprintf( '%s / 5', $sum['avg'] ) ) . '">' . esc_html( self::stars( round( $sum['avg'] ) ) ) . '</span><small>' . esc_html( sprintf( _n( '%d reseña', '%d reseñas', $sum['total'], 'wakoo' ), $sum['total'] ) ) . '</small></div><div class="wks-rev__dist">';
		for ( $i = 5; $i >= 1; $i-- ) {
			$pc = $sum['total'] ? round( $sum['dist'][ $i ] * 100 / $sum['total'] ) : 0;
			echo '<div class="wks-rev__drow"><span>' . $i . '★</span><div class="wks-bar"><i style="width:' . (int) $pc . '%"></i></div><small>' . (int) $sum['dist'][ $i ] . '</small></div>';
		}
		echo '</div></div><div class="wks-rev__list">';
		foreach ( $pg['items'] as $it ) { $this->item_html( $it ); }
		echo '</div><p class="wks-rev__none"' . ( $pg['items'] ? ' hidden' : '' ) . '>' . esc_html( $s['none'] ) . '</p>';
		echo '<button type="button" class="wks-btn wks-btn--ghost wks-rev__more"' . ( $pg['pages'] > 1 ? '' : ' hidden' ) . '>' . esc_html( $s['more'] ) . '</button>';
		if ( 'yes' === $s['form'] ) {
			$id = 'wks-rv-' . esc_attr( $this->get_id() );
			echo '<form class="wks-rev__form wks-card" novalidate><div class="wks-field"><label>' . esc_html( $s['l_rate'] ) . '</label><div class="wks-rev__rate" role="radiogroup" aria-label="' . esc_attr( $s['l_rate'] ) . '">';
			for ( $i = 1; $i <= 5; $i++ ) { echo '<button type="button" class="wks-rev__star" role="radio" aria-checked="false" aria-label="' . $i . '" data-v="' . $i . '">☆</button>'; }
			echo '</div></div>';
			echo '<div class="wks-field"><label for="' . $id . '-n">' . esc_html( $s['l_name'] ) . '</label><input id="' . $id . '-n" name="name" type="text" maxlength="80" required></div>';
			echo '<div class="wks-field"><label for="' . $id . '-e">' . esc_html( $s['l_mail'] ) . '</label><input id="' . $id . '-e" name="email" type="email" maxlength="120"></div>';
			echo '<div class="wks-field"><label for="' . $id . '-t">' . esc_html( $s['l_text'] ) . '</label><textarea id="' . $id . '-t" name="text" rows="4" maxlength="1500" required></textarea></div>';
			echo '<div class="wks-hp" aria-hidden="true"><input type="text" name="website" tabindex="-1" autocomplete="off"></div>';
			echo '<button type="submit" class="wks-btn">' . esc_html( $s['btn'] ) . '</button><p class="wks-msg" role="status"></p></form>';
		}
		$this->close();
		if ( 'yes' === ( $s['schema'] ?? '' ) && $s['item'] && $sum['total'] ) {
			echo '<script type="application/ld+json">' . wp_json_encode( [ '@context' => 'https://schema.org', '@type' => 'Product', 'name' => wp_strip_all_tags( $s['item'] ), 'aggregateRating' => [ '@type' => 'AggregateRating', 'ratingValue' => $sum['avg'], 'reviewCount' => $sum['total'], 'bestRating' => 5, 'worstRating' => 1 ] ], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) . '</script>';
		}
	}

	private function item_html( $it ) {
		echo '<article class="wks-rev__item wks-card"><div class="wks-rev__head"><b>' . esc_html( $it['name'] ) . '</b><span class="wks-stars" aria-label="' . (int) $it['rating'] . '/5">' . esc_html( self::stars( $it['rating'] ) ) . '</span><small>' . esc_html( $it['date'] ) . '</small></div><p>' . nl2br( esc_html( $it['text'] ) ) . '</p></article>';
	}

	/* ------------------------------------------------------------ server */

	private static function conf( $post, $w ) {
		$s = Data::widget( $post, $w, 'wakoo-reviews' );
		if ( null === $s ) { return null; }
		$wt = \Elementor\Plugin::$instance->widgets_manager->get_widget_types( 'wakoo-reviews' );
		if ( $wt ) { foreach ( $wt->get_controls() as $id => $c ) { if ( ! isset( $s[ $id ] ) && isset( $c['default'] ) ) { $s[ $id ] = $c['default']; } } }
		return $s;
	}

	public static function boot() {
		register_post_type( self::CPT, [
			'labels' => [ 'name' => __( 'Reseñas Wakoo', 'wakoo' ), 'singular_name' => __( 'Reseña', 'wakoo' ), 'edit_item' => __( 'Editar reseña', 'wakoo' ), 'all_items' => __( 'Reseñas', 'wakoo' ) ],
			'public' => false, 'show_ui' => true, 'show_in_menu' => true, 'menu_icon' => 'dashicons-star-filled', 'menu_position' => 58,
			'supports' => [ 'title', 'editor' ], 'capability_type' => 'post', 'capabilities' => [ 'create_posts' => 'do_not_allow' ], 'map_meta_cap' => true,
			'show_in_rest' => false, 'has_archive' => false, 'rewrite' => false,
		] );
		add_filter( 'manage_' . self::CPT . '_posts_columns', static function ( $c ) {
			return [ 'cb' => $c['cb'], 'title' => __( 'Nombre', 'wakoo' ), 'wks_rating' => __( 'Puntuación', 'wakoo' ), 'wks_key' => __( 'Grupo', 'wakoo' ), 'wks_email' => __( 'Email', 'wakoo' ), 'date' => $c['date'] ];
		} );
		add_action( 'manage_' . self::CPT . '_posts_custom_column', static function ( $col, $id ) {
			if ( 'wks_rating' === $col ) { echo esc_html( self::stars( (int) get_post_meta( $id, '_wks_rating', true ) ) ); }
			if ( 'wks_key' === $col ) { echo esc_html( (string) get_post_meta( $id, '_wks_key', true ) ); }
			if ( 'wks_email' === $col ) { echo esc_html( (string) get_post_meta( $id, '_wks_email', true ) ); }
		}, 10, 2 );
		// Invalidate the cached summary when a review changes status or is edited/trashed.
		$flush = static function ( $id ) {
			$p = get_post( $id );
			if ( $p && self::CPT === $p->post_type ) { delete_transient( 'wks_rev_sum_' . md5( (string) get_post_meta( $id, '_wks_key', true ) ) ); }
		};
		add_action( 'save_post_' . self::CPT, $flush );
		add_action( 'trashed_post', $flush );
		add_action( 'deleted_post', $flush );
		add_action( 'transition_post_status', static function ( $n, $o, $p ) use ( $flush ) { $flush( $p->ID ); }, 10, 3 );
	}

	public static function routes() {
		Sec::route( 'reviews/list', 'GET', static function ( \WP_REST_Request $r ) {
			$post = Sec::int( $r->get_param( 'post' ), 0 );
			$w    = Sec::text( $r->get_param( 'w' ), 32 );
			$s    = self::conf( $post, $w );
			if ( ! $s ) { return Sec::err( 'No encontrado', 404 ); }
			if ( ! Sec::rate( 'rev-list', 120, 600 ) ) { return Sec::err( 'Demasiadas peticiones', 429 ); }
			$per = max( 1, min( 30, (int) $s['per'] ) );
			$pg  = self::page( self::key_for( $s, $post, $w ), Sec::int( $r->get_param( 'page' ), 1, 500 ), $per );
			$items = array_map( static function ( $i ) { return [ 'name' => $i['name'], 'text' => $i['text'], 'rating' => $i['rating'], 'date' => $i['date'] ]; }, $pg['items'] );
			return Sec::ok( [ 'items' => $items, 'pages' => $pg['pages'] ] );
		} );
		Sec::route( 'reviews/submit', 'POST', static function ( \WP_REST_Request $r ) {
			if ( ! Sec::human( $r, 2500 ) ) { return Sec::err( 'Inténtalo de nuevo en unos segundos', 400 ); }
			if ( ! Sec::rate( 'rev-submit', 5, HOUR_IN_SECONDS ) ) { return Sec::err( 'Has enviado demasiadas reseñas. Prueba más tarde.', 429 ); }
			$post = Sec::int( $r->get_param( 'post' ), 0 );
			$w    = Sec::text( $r->get_param( 'w' ), 32 );
			$s    = self::conf( $post, $w );
			if ( ! $s || 'yes' !== $s['form'] ) { return Sec::err( 'No encontrado', 404 ); }
			$name   = Sec::text( $r->get_param( 'name' ), 80 );
			$email  = sanitize_email( Sec::text( $r->get_param( 'email' ), 120 ) );
			$text   = Sec::area( $r->get_param( 'text' ), 1500 );
			$rating = Sec::int( $r->get_param( 'rating' ), 0, 5 );
			if ( '' === $name || mb_strlen( $text ) < 3 || $rating < 1 ) { return Sec::err( 'Completa nombre, puntuación y opinión.', 400 ); }
			$dup = 'wks_rev_dup_' . md5( Sec::visitor() . $text );
			if ( get_transient( $dup ) ) { return Sec::err( 'Esta reseña ya se envió.', 409 ); }
			set_transient( $dup, 1, DAY_IN_SECONDS );
			$auto = 'yes' === $s['auto'];
			$id = wp_insert_post( [
				'post_type' => self::CPT, 'post_status' => $auto ? 'publish' : 'pending', 'post_title' => $name, 'post_content' => $text, 'post_author' => 0,
			], true );
			if ( is_wp_error( $id ) ) { return Sec::err( 'No se pudo guardar', 500 ); }
			update_post_meta( $id, '_wks_rating', $rating );
			update_post_meta( $id, '_wks_key', self::key_for( $s, $post, $w ) );
			if ( $email ) { update_post_meta( $id, '_wks_email', $email ); }
			delete_transient( 'wks_rev_sum_' . md5( self::key_for( $s, $post, $w ) ) );
			return Sec::ok( [ 'published' => $auto ] );
		} );
	}
}
