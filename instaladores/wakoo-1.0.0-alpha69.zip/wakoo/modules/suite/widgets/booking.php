<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;
use Wakoo\Modules\Suite\Sec;
use Wakoo\Modules\Suite\Data;

defined( 'ABSPATH' ) || die();

/** 1. Reservas y citas: servicio, fecha, hora libre y confirmación por email. */
class Booking extends Base {

	const CPT = 'wakoo_booking';

	public function slug() { return 'booking'; }
	public function label() { return __( 'Reservas y citas', 'wakoo' ); }
	public function cat() { return 'commerce'; }
	public function icon() { return 'eicon-calendar'; }
	public function words() { return [ 'reservas', 'citas', 'booking', 'appointment', 'agenda' ]; }

	protected function sections() {
		$days = [ '1' => __( 'Lunes', 'wakoo' ), '2' => __( 'Martes', 'wakoo' ), '3' => __( 'Miércoles', 'wakoo' ), '4' => __( 'Jueves', 'wakoo' ), '5' => __( 'Viernes', 'wakoo' ), '6' => __( 'Sábado', 'wakoo' ), '0' => __( 'Domingo', 'wakoo' ) ];
		$hrs  = [];
		foreach ( [ '1', '2', '3', '4', '5' ] as $d ) { $hrs[] = [ 'day' => $d, 'from' => '09:00', 'to' => '17:00' ]; }
		return [
			[ 'id' => 'sec_services', 'label' => __( 'Servicios', 'wakoo' ), 'controls' => [
				'services' => [ 't' => 'repeater', 'title' => '{{{ name }}} · {{{ minutes }}} min', 'fields' => [
					'group'   => [ 't' => 'text', 'l' => __( 'Categoría', 'wakoo' ), 'd' => __( 'General', 'wakoo' ) ],
					'name'    => [ 't' => 'text', 'l' => __( 'Servicio', 'wakoo' ), 'd' => __( 'Consulta', 'wakoo' ) ],
					'minutes' => [ 't' => 'number', 'l' => __( 'Duración (min)', 'wakoo' ), 'd' => 30, 'min' => 5, 'max' => 480 ],
					'price'   => [ 't' => 'text', 'l' => __( 'Precio (texto)', 'wakoo' ), 'd' => '' ],
				], 'd' => [
					[ 'group' => __( 'General', 'wakoo' ), 'name' => __( 'Consulta inicial', 'wakoo' ), 'minutes' => 30, 'price' => '' ],
					[ 'group' => __( 'General', 'wakoo' ), 'name' => __( 'Sesión completa', 'wakoo' ), 'minutes' => 60, 'price' => '' ],
					[ 'group' => __( 'Especiales', 'wakoo' ), 'name' => __( 'Sesión doble', 'wakoo' ), 'minutes' => 90, 'price' => '' ],
				] ],
			] ],
			[ 'id' => 'sec_hours', 'label' => __( 'Horario y reglas', 'wakoo' ), 'controls' => [
				'hours'    => [ 't' => 'repeater', 'title' => '{{{ from }}} - {{{ to }}}', 'fields' => [
					'day'  => [ 't' => 'select', 'l' => __( 'Día', 'wakoo' ), 'o' => $days, 'd' => '1' ],
					'from' => [ 't' => 'text', 'l' => __( 'Desde (HH:MM)', 'wakoo' ), 'd' => '09:00' ],
					'to'   => [ 't' => 'text', 'l' => __( 'Hasta (HH:MM)', 'wakoo' ), 'd' => '17:00' ],
				], 'd' => $hrs, 'desc' => __( 'Añade varias franjas por día si hay pausa para comer.', 'wakoo' ) ],
				'step'     => [ 't' => 'number', 'l' => __( 'Intervalo entre horas (min)', 'wakoo' ), 'd' => 30, 'min' => 5, 'max' => 240 ],
				'buffer'   => [ 't' => 'number', 'l' => __( 'Descanso entre citas (min)', 'wakoo' ), 'd' => 0, 'min' => 0, 'max' => 120 ],
				'capacity' => [ 't' => 'number', 'l' => __( 'Plazas por hora', 'wakoo' ), 'd' => 1, 'min' => 1, 'max' => 50 ],
				'max_days' => [ 't' => 'number', 'l' => __( 'Días hacia adelante', 'wakoo' ), 'd' => 60, 'min' => 1, 'max' => 365 ],
				'notice'   => [ 't' => 'number', 'l' => __( 'Antelación mínima (horas)', 'wakoo' ), 'd' => 2, 'min' => 0, 'max' => 720 ],
			] ],
			[ 'id' => 'sec_notify', 'label' => __( 'Avisos y textos', 'wakoo' ), 'controls' => [
				'email'   => [ 't' => 'text', 'l' => __( 'Email que recibe las reservas', 'wakoo' ), 'd' => '', 'desc' => __( 'Queda guardado en el servidor y nunca se muestra a los visitantes. Vacío = email del administrador.', 'wakoo' ) ],
				'title'   => [ 't' => 'text', 'l' => __( 'Título', 'wakoo' ), 'd' => __( 'Reserva tu cita', 'wakoo' ) ],
				'btn'     => [ 't' => 'text', 'l' => __( 'Texto del botón', 'wakoo' ), 'd' => __( 'Confirmar reserva', 'wakoo' ) ],
				'ok'      => [ 't' => 'text', 'l' => __( 'Mensaje de confirmación', 'wakoo' ), 'd' => __( '¡Reserva confirmada! Te hemos enviado un email.', 'wakoo' ) ],
				'phone'   => [ 't' => 'switch', 'l' => __( 'Pedir teléfono', 'wakoo' ), 'd' => 'yes' ],
				'note'    => [ 't' => 'switch', 'l' => __( 'Pedir comentario', 'wakoo' ), 'd' => 'yes' ],
			] ],
		];
	}

	protected function draw( array $s ) {
		$services = [];
		foreach ( array_values( (array) $s['services'] ) as $i => $r ) {
			$services[] = [ 'i' => $i, 'name' => (string) ( $r['name'] ?? '' ), 'min' => max( 5, (int) ( $r['minutes'] ?? 30 ) ), 'price' => (string) ( $r['price'] ?? '' ), 'group' => (string) ( $r['group'] ?? '' ) ];
		}
		$open = [];
		foreach ( (array) $s['hours'] as $h ) { $open[ (int) ( $h['day'] ?? 0 ) ] = 1; }
		$tz = wp_timezone();
		$now = new \DateTimeImmutable( 'now', $tz );
		$this->open( [
			'services' => $services,
			'open'     => array_keys( $open ),
			'min'      => $now->format( 'Y-m-d' ),
			'max'      => $now->modify( '+' . max( 1, (int) $s['max_days'] ) . ' days' )->format( 'Y-m-d' ),
			'phone'    => 'yes' === $s['phone'],
			'note'     => 'yes' === $s['note'],
			'btn'      => (string) $s['btn'],
			'ok'       => (string) $s['ok'],
			'tz'       => $tz->getName(),
		] );
		echo '<h3 class="wks-book__title">' . esc_html( $s['title'] ) . '</h3>';
		echo '<div class="wks-book__app"></div>';
		$this->close();
	}

	/* ------------------------------------------------------------ server side */

	public static function boot() {
		register_post_type( self::CPT, [
			'labels'          => [ 'name' => __( 'Reservas Wakoo', 'wakoo' ), 'singular_name' => __( 'Reserva', 'wakoo' ), 'menu_name' => __( 'Reservas', 'wakoo' ) ],
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => true,
			'menu_icon'       => 'dashicons-calendar-alt',
			'supports'        => [ 'title' ],
			'capability_type' => 'post',
			'capabilities'    => [ 'create_posts' => 'do_not_allow' ],
			'map_meta_cap'    => true,
		] );
		if ( ! is_admin() ) { return; }
		add_filter( 'manage_' . self::CPT . '_posts_columns', static function ( $c ) {
			return [ 'cb' => $c['cb'], 'title' => __( 'Cliente', 'wakoo' ), 'wk_svc' => __( 'Servicio', 'wakoo' ), 'wk_when' => __( 'Fecha y hora', 'wakoo' ), 'wk_contact' => __( 'Contacto', 'wakoo' ), 'wk_status' => __( 'Estado', 'wakoo' ) ];
		} );
		add_action( 'manage_' . self::CPT . '_posts_custom_column', static function ( $col, $id ) {
			switch ( $col ) {
				case 'wk_svc': echo esc_html( get_post_meta( $id, '_wk_service', true ) ); break;
				case 'wk_when': echo esc_html( get_post_meta( $id, '_wk_date', true ) . ' ' . get_post_meta( $id, '_wk_time', true ) ); break;
				case 'wk_contact': echo esc_html( get_post_meta( $id, '_wk_email', true ) . ' ' . get_post_meta( $id, '_wk_phone', true ) ); break;
				case 'wk_status': echo esc_html( 'cancelled' === get_post_meta( $id, '_wk_status', true ) ? __( 'Cancelada', 'wakoo' ) : __( 'Confirmada', 'wakoo' ) ); break;
			}
		}, 10, 2 );
		add_action( 'add_meta_boxes_' . self::CPT, static function () {
			add_meta_box( 'wk_book_status', __( 'Estado de la reserva', 'wakoo' ), static function ( $post ) {
				wp_nonce_field( 'wk_book_status', 'wk_book_nonce' );
				$st = get_post_meta( $post->ID, '_wk_status', true ) ?: 'confirmed';
				echo '<select name="wk_book_status"><option value="confirmed"' . selected( $st, 'confirmed', false ) . '>' . esc_html__( 'Confirmada', 'wakoo' ) . '</option><option value="cancelled"' . selected( $st, 'cancelled', false ) . '>' . esc_html__( 'Cancelada (libera la hora)', 'wakoo' ) . '</option></select>';
				echo '<p>' . esc_html( get_post_meta( $post->ID, '_wk_note', true ) ) . '</p>';
			}, self::CPT, 'side' );
		} );
		add_action( 'save_post_' . self::CPT, static function ( $id ) {
			if ( ! isset( $_POST['wk_book_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wk_book_nonce'] ) ), 'wk_book_status' ) ) { return; }
			if ( ! current_user_can( 'edit_post', $id ) || wp_is_post_autosave( $id ) ) { return; }
			$st = isset( $_POST['wk_book_status'] ) && 'cancelled' === $_POST['wk_book_status'] ? 'cancelled' : 'confirmed';
			update_post_meta( $id, '_wk_status', $st );
		} );
	}

	public static function routes() {
		Sec::route( 'booking/slots', 'GET', [ __CLASS__, 'rest_slots' ] );
		Sec::route( 'booking/create', 'POST', [ __CLASS__, 'rest_create' ] );
	}

	/** Saved Elementor data omits untouched controls, so fill them with the control defaults. */
	private static function with_defaults( array $set ) {
		static $defs = null;
		if ( null === $defs ) {
			$defs = [];
			$inst = new self( [], [] );
			foreach ( $inst->get_controls() as $id => $c ) {
				if ( array_key_exists( 'default', $c ) ) { $defs[ $id ] = $c['default']; }
			}
		}
		return $set + $defs;
	}

	private static function mins( $t ) {
		return preg_match( '/^([01]?\d|2[0-3]):([0-5]\d)$/', trim( (string) $t ), $m ) ? (int) $m[1] * 60 + (int) $m[2] : null;
	}

	private static function fmt( $m ) { return sprintf( '%02d:%02d', intdiv( $m, 60 ), $m % 60 ); }

	/** Free start times (minutes since midnight) for a service on a date, or WP_Error-like string on invalid input. */
	private static function free( array $set, $svc_i, $date, $key ) {
		$tz = wp_timezone();
		$d  = \DateTimeImmutable::createFromFormat( '!Y-m-d', $date, $tz );
		if ( ! $d || $d->format( 'Y-m-d' ) !== $date ) { return null; }
		$now = new \DateTimeImmutable( 'now', $tz );
		if ( $d < $now->setTime( 0, 0 ) || $d > $now->modify( '+' . self::cap( $set['max_days'] ?? 60, 1, 365 ) . ' days' ) ) { return null; }
		$svcs = array_values( (array) ( $set['services'] ?? [] ) );
		if ( ! isset( $svcs[ $svc_i ] ) ) { return null; }
		$len  = self::cap( $svcs[ $svc_i ]['minutes'] ?? 30, 5, 480 );
		$step = self::cap( $set['step'] ?? 30, 5, 240 );
		$buf  = self::cap( $set['buffer'] ?? 0, 0, 120 );
		$capy = self::cap( $set['capacity'] ?? 1, 1, 50 );
		$notice = self::cap( $set['notice'] ?? 0, 0, 720 ) * 3600;
		$dow  = (int) $d->format( 'w' );

		$booked = [];
		$ids = get_posts( [ 'post_type' => self::CPT, 'fields' => 'ids', 'posts_per_page' => 300, 'no_found_rows' => true, 'meta_key' => '_wk_key', 'meta_value' => $key . ':' . $date ] ); // phpcs:ignore
		foreach ( $ids as $id ) {
			if ( 'cancelled' === get_post_meta( $id, '_wk_status', true ) ) { continue; }
			$booked[] = [ (int) get_post_meta( $id, '_wk_start', true ), (int) get_post_meta( $id, '_wk_end', true ) ];
		}
		$out = [];
		foreach ( (array) ( $set['hours'] ?? [] ) as $h ) {
			if ( (int) ( $h['day'] ?? -1 ) !== $dow ) { continue; }
			$from = self::mins( $h['from'] ?? '' );
			$to   = self::mins( $h['to'] ?? '' );
			if ( null === $from || null === $to ) { continue; }
			for ( $t = $from; $t + $len <= $to; $t += $step ) {
				$ts = $d->setTime( intdiv( $t, 60 ), $t % 60 )->getTimestamp();
				if ( $ts < time() + $notice ) { continue; }
				$n = 0;
				foreach ( $booked as $b ) { if ( $t < $b[1] + $buf && $t + $len + $buf > $b[0] ) { $n++; } }
				if ( $n < $capy ) { $out[ $t ] = $len; }
			}
		}
		ksort( $out );
		return $out;
	}

	private static function cap( $v, $min, $max ) { return max( $min, min( $max, (int) $v ) ); }

	public static function rest_slots( \WP_REST_Request $r ) {
		if ( ! Sec::rate( 'book_slots', 90, 600 ) ) { return Sec::err( __( 'Demasiadas consultas.', 'wakoo' ), 429 ); }
		$post = Sec::int( $r->get_param( 'post' ), 0 );
		$w    = Sec::text( $r->get_param( 'w' ), 40 );
		$set  = Data::widget( $post, $w, 'wakoo-booking' );
		if ( null === $set ) { return Sec::err( __( 'Widget no válido.', 'wakoo' ), 404 ); }
		$set  = self::with_defaults( $set );
		$free = self::free( $set, Sec::int( $r->get_param( 'service' ), 0, 200 ), Sec::text( $r->get_param( 'date' ), 10 ), $post . ':' . preg_replace( '/[^a-z0-9]/i', '', $w ) );
		if ( null === $free ) { return Sec::err( __( 'Fecha no disponible.', 'wakoo' ) ); }
		return Sec::ok( [ 'slots' => array_map( [ __CLASS__, 'fmt' ], array_keys( $free ) ) ] );
	}

	public static function rest_create( \WP_REST_Request $r ) {
		if ( ! Sec::human( $r ) ) { return Sec::err( __( 'Inténtalo de nuevo en unos segundos.', 'wakoo' ), 429 ); }
		if ( ! Sec::rate( 'book_create', 5, 900 ) ) { return Sec::err( __( 'Demasiadas reservas desde tu conexión.', 'wakoo' ), 429 ); }
		$post = Sec::int( $r->get_param( 'post' ), 0 );
		$w    = preg_replace( '/[^a-z0-9]/i', '', Sec::text( $r->get_param( 'w' ), 40 ) );
		$set  = Data::widget( $post, $w, 'wakoo-booking' );
		if ( null === $set ) { return Sec::err( __( 'Widget no válido.', 'wakoo' ), 404 ); }
		$set  = self::with_defaults( $set );

		$name  = Sec::text( $r->get_param( 'name' ), 100 );
		$email = sanitize_email( Sec::text( $r->get_param( 'email' ), 120 ) );
		$phone = preg_replace( '/[^0-9+()\-\s.]/', '', Sec::text( $r->get_param( 'phone' ), 30 ) );
		$note  = Sec::area( $r->get_param( 'note' ), 500 );
		$date  = Sec::text( $r->get_param( 'date' ), 10 );
		$time  = self::mins( Sec::text( $r->get_param( 'time' ), 5 ) );
		$svc_i = Sec::int( $r->get_param( 'service' ), 0, 200 );
		if ( '' === $name || ! is_email( $email ) || null === $time ) { return Sec::err( __( 'Revisa tu nombre, email y hora.', 'wakoo' ) ); }

		$key  = $post . ':' . $w;
		$lock = Sec::lock( 'booking_' . $key . $date );
		if ( ! $lock ) { return Sec::err( __( 'Servidor ocupado, inténtalo otra vez.', 'wakoo' ), 503 ); }
		$free = self::free( $set, $svc_i, $date, $key );
		if ( null === $free || ! isset( $free[ $time ] ) ) {
			Sec::unlock( $lock );
			return Sec::err( __( 'Esa hora ya no está disponible. Elige otra.', 'wakoo' ), 409 );
		}
		$svc  = array_values( (array) $set['services'] )[ $svc_i ];
		$len  = $free[ $time ];
		$sname = sanitize_text_field( (string) ( $svc['name'] ?? '' ) );
		$id = wp_insert_post( [ 'post_type' => self::CPT, 'post_status' => 'publish', 'post_title' => $name . ' · ' . $date . ' ' . self::fmt( $time ) ], true );
		if ( is_wp_error( $id ) ) { Sec::unlock( $lock ); return Sec::err( __( 'No se pudo guardar la reserva.', 'wakoo' ), 500 ); }
		$meta = [ '_wk_key' => $key . ':' . $date, '_wk_date' => $date, '_wk_time' => self::fmt( $time ), '_wk_start' => $time, '_wk_end' => $time + $len, '_wk_service' => $sname, '_wk_email' => $email, '_wk_phone' => $phone, '_wk_note' => $note, '_wk_status' => 'confirmed' ];
		foreach ( $meta as $k => $v ) { update_post_meta( $id, $k, $v ); }
		Sec::unlock( $lock );

		$to   = sanitize_email( (string) ( $set['email'] ?? '' ) );
		$to   = is_email( $to ) ? $to : get_option( 'admin_email' );
		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$what = "$sname\n$date " . self::fmt( $time ) . " ($len min)";
		wp_mail( $to, sprintf( '[%s] %s', $site, __( 'Nueva reserva', 'wakoo' ) ), "$what\n\n$name\n$email\n$phone\n\n$note", [ 'Reply-To: ' . $email ] );
		wp_mail( $email, sprintf( '[%s] %s', $site, __( 'Reserva confirmada', 'wakoo' ) ), sprintf( __( "Hola %s,\n\nTu reserva está confirmada:\n%s\n\nGracias.", 'wakoo' ), $name, $what ) );

		return Sec::ok( [ 'service' => $sname, 'date' => $date, 'time' => self::fmt( $time ), 'minutes' => $len, 'site' => $site ], 201 );
	}
}
