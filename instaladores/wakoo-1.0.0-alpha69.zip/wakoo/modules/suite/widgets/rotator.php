<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;

defined( 'ABSPATH' ) || die();

/** Rotating calls to action: slides with their own colour, text and button; swipe/scroll, arrows, dots and autoplay. */
class Rotator extends Base {

	public function slug() { return 'rotator'; }
	public function label() { return __( 'Rotador de llamadas', 'wakoo' ); }
	public function cat() { return 'media'; }
	public function icon() { return 'eicon-slider-push'; }
	public function words() { return [ 'cta', 'call to action', 'slider', 'carrusel', 'banner', 'rotador', 'mensajes' ]; }

	protected function sections() {
		return [
			[ 'id' => 'sec_slides', 'label' => __( 'Mensajes', 'wakoo' ), 'controls' => [
				'slides' => [ 't' => 'repeater', 'title' => '{{{ title }}}', 'fields' => [
					'icon'    => [ 't' => 'text', 'l' => __( 'Emoji o símbolo (opcional)', 'wakoo' ), 'd' => '' ],
					'eyebrow' => [ 't' => 'text', 'l' => __( 'Antetítulo', 'wakoo' ), 'd' => '' ],
					'title'   => [ 't' => 'text', 'l' => __( 'Título', 'wakoo' ), 'd' => __( 'Tu mensaje', 'wakoo' ) ],
					'text'    => [ 't' => 'textarea', 'l' => __( 'Texto', 'wakoo' ), 'd' => '' ],
					'button'  => [ 't' => 'text', 'l' => __( 'Texto del botón', 'wakoo' ), 'd' => __( 'Saber más', 'wakoo' ) ],
					'link'    => [ 't' => 'url', 'l' => __( 'Enlace del botón', 'wakoo' ) ],
					'from'    => [ 't' => 'color', 'l' => __( 'Color de fondo 1', 'wakoo' ), 'd' => '#1F7A63' ],
					'to'      => [ 't' => 'color', 'l' => __( 'Color de fondo 2', 'wakoo' ), 'd' => '#2A9D8F' ],
					'ink'     => [ 't' => 'select', 'l' => __( 'Texto', 'wakoo' ), 'd' => 'light', 'o' => [ 'light' => __( 'Claro', 'wakoo' ), 'dark' => __( 'Oscuro', 'wakoo' ) ] ],
					'image'   => [ 't' => 'media', 'l' => __( 'Imagen (opcional)', 'wakoo' ) ],
				], 'd' => [
					[ 'icon' => '★', 'eyebrow' => __( 'Novedad', 'wakoo' ), 'title' => __( 'Únete a la comunidad', 'wakoo' ), 'text' => __( 'Un mensaje breve que invita a actuar.', 'wakoo' ), 'button' => __( 'Únete', 'wakoo' ), 'from' => '#1F7A63', 'to' => '#2A9D8F', 'ink' => 'light' ],
					[ 'icon' => '☀', 'eyebrow' => __( 'Inspiración', 'wakoo' ), 'title' => __( 'Cuenta tu historia', 'wakoo' ), 'text' => __( 'Cada mensaje tiene su color y su botón.', 'wakoo' ), 'button' => __( 'Empezar', 'wakoo' ), 'from' => '#F4A261', 'to' => '#E76F51', 'ink' => 'light' ],
				] ],
			] ],
			[ 'id' => 'sec_play', 'label' => __( 'Movimiento', 'wakoo' ), 'controls' => [
				'autoplay' => [ 't' => 'switch', 'l' => __( 'Pasar solo', 'wakoo' ), 'd' => 'yes' ],
				'delay'    => [ 't' => 'number', 'l' => __( 'Segundos por mensaje', 'wakoo' ), 'd' => 7, 'min' => 3, 'max' => 30, 'c' => [ 'autoplay' => 'yes' ] ],
				'peek'     => [ 't' => 'switch', 'l' => __( 'Asomar el siguiente mensaje', 'wakoo' ), 'd' => 'yes' ],
				'arrows'   => [ 't' => 'switch', 'l' => __( 'Flechas', 'wakoo' ), 'd' => 'yes' ],
				'dots'     => [ 't' => 'switch', 'l' => __( 'Puntos', 'wakoo' ), 'd' => 'yes' ],
				'prev'     => [ 't' => 'text', 'l' => __( 'Texto: anterior', 'wakoo' ), 'd' => __( 'Anterior', 'wakoo' ) ],
				'next'     => [ 't' => 'text', 'l' => __( 'Texto: siguiente', 'wakoo' ), 'd' => __( 'Siguiente', 'wakoo' ) ],
				'pause'    => [ 't' => 'text', 'l' => __( 'Texto: pausar', 'wakoo' ), 'd' => __( 'Pausar', 'wakoo' ) ],
				'play'     => [ 't' => 'text', 'l' => __( 'Texto: reanudar', 'wakoo' ), 'd' => __( 'Reanudar', 'wakoo' ) ],
				'height'   => [ 't' => 'number', 'l' => __( 'Altura mínima (px)', 'wakoo' ), 'd' => 300, 'min' => 160, 'max' => 900, 'sel' => [ '{{WRAPPER}} .wks-rot__slide' => 'min-height: {{VALUE}}px;' ] ],
			] ],
		];
	}

	protected function draw( array $s ) {
		$slides = array_values( (array) ( $s['slides'] ?? [] ) );
		if ( ! $slides ) { return; }
		$auto = 'yes' === $s['autoplay'];
		$this->open( [ 'auto' => $auto, 'delay' => max( 3, (int) $s['delay'] ), 'pause' => $s['pause'], 'play' => $s['play'] ], 'yes' === $s['peek'] ? 'wks-rot--peek' : '' );
		echo '<div class="wks-rot__track" tabindex="0" role="region" aria-roledescription="carousel">';
		foreach ( $slides as $i => $r ) {
			$from  = sanitize_hex_color( $r['from'] ?? '' ) ?: '#1F7A63';
			$to    = sanitize_hex_color( $r['to'] ?? '' ) ?: $from;
			$img   = $this->img( $r['image'] ?? [] );
			$style = '--from:' . $from . ';--to:' . $to . ';';
			printf( '<article class="wks-rot__slide wks-rot--%1$s%2$s" style="%3$s" aria-roledescription="slide" aria-label="%4$d / %5$d">',
				'dark' === ( $r['ink'] ?? '' ) ? 'dark' : 'light', $img ? ' has-img' : '', esc_attr( $style ), $i + 1, count( $slides ) );
			echo '<div class="wks-rot__body">';
			if ( ! empty( $r['icon'] ) ) { echo '<span class="wks-rot__icon" aria-hidden="true">' . esc_html( $r['icon'] ) . '</span>'; }
			if ( ! empty( $r['eyebrow'] ) ) { echo '<p class="wks-rot__eyebrow">' . esc_html( $r['eyebrow'] ) . '</p>'; }
			if ( ! empty( $r['title'] ) ) { echo '<h3 class="wks-rot__title">' . esc_html( $r['title'] ) . '</h3>'; }
			if ( ! empty( $r['text'] ) ) { echo '<p class="wks-rot__text">' . esc_html( $r['text'] ) . '</p>'; }
			$a = $this->link_attrs( $r['link'] ?? [] );
			if ( $a && ! empty( $r['button'] ) ) { echo '<a class="wks-rot__btn"' . $a . '>' . esc_html( $r['button'] ) . ' <span aria-hidden="true">&rarr;</span></a>'; } // phpcs:ignore WordPress.Security.EscapeOutput
			echo '</div>';
			if ( $img ) { echo '<img class="wks-rot__img" src="' . $img . '" alt="" loading="lazy" decoding="async">'; } // phpcs:ignore WordPress.Security.EscapeOutput
			echo '</article>';
		}
		echo '</div>';
		if ( count( $slides ) > 1 ) {
			echo '<div class="wks-rot__bar">';
			if ( 'yes' === $s['dots'] ) {
				echo '<div class="wks-rot__dots">';
				foreach ( $slides as $i => $r ) { echo '<button type="button" class="wks-rot__dot" aria-label="' . esc_attr( ( $i + 1 ) . ' · ' . ( $r['title'] ?? '' ) ) . '"><i></i></button>'; }
				echo '</div>';
			}
			if ( $auto ) { echo '<button type="button" class="wks-rot__toggle" aria-pressed="false">' . esc_html( $s['pause'] ) . '</button>'; }
			if ( 'yes' === $s['arrows'] ) {
				echo '<button type="button" class="wks-rot__arrow wks-rot__prev" aria-label="' . esc_attr( $s['prev'] ) . '">&larr;</button>'
					. '<button type="button" class="wks-rot__arrow wks-rot__next" aria-label="' . esc_attr( $s['next'] ) . '">&rarr;</button>';
			}
			echo '</div>';
		}
		$this->close();
	}
}
