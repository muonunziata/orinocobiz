<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;
use Wakoo\Modules\Suite\Data;
use Wakoo\Modules\Suite\Sec;

defined( 'ABSPATH' ) || die();

/** 2. Votaciones y encuestas propias: resultados en barras, sin cuentas de terceros. */
class Poll extends Base {

	public function slug() { return 'poll'; }
	public function label() { return __( 'Encuesta / votación', 'wakoo' ); }
	public function cat() { return 'interact'; }
	public function icon() { return 'eicon-skill-bar'; }
	public function words() { return [ 'encuesta', 'votacion', 'poll', 'survey' ]; }

	protected function sections() {
		return [
			[ 'id' => 'sec_q', 'label' => __( 'Pregunta', 'wakoo' ), 'controls' => [
				'question' => [ 't' => 'text', 'l' => __( 'Pregunta', 'wakoo' ), 'd' => __( '¿Cuál es tu favorito?', 'wakoo' ) ],
				'type'     => [ 't' => 'select', 'l' => __( 'Tipo de respuesta', 'wakoo' ), 'd' => 'single', 'o' => [
					'single' => __( 'Una opción', 'wakoo' ), 'multiple' => __( 'Varias opciones', 'wakoo' ), 'image' => __( 'Una opción con imagen', 'wakoo' ),
					'yesno' => __( 'Sí / No', 'wakoo' ), 'rating' => __( 'Valoración de 1 a 5 estrellas', 'wakoo' ),
				] ],
				'max_sel'  => [ 't' => 'number', 'l' => __( 'Máximo de opciones a elegir (0 = sin límite)', 'wakoo' ), 'd' => 0, 'min' => 0, 'max' => 20, 'c' => [ 'type' => 'multiple' ] ],
				'edit_opts' => [ 't' => 'editor_btn', 'target' => 'options', 'mode' => 'cards', 'l' => __( 'Abrir editor de opciones', 'wakoo' ) ],
				'options'  => [ 't' => 'repeater', 'title' => '{{{ label }}}', 'fields' => [
					'label'   => [ 't' => 'text', 'l' => __( 'Opción', 'wakoo' ), 'd' => __( 'Opción', 'wakoo' ) ],
					'image'   => [ 't' => 'media', 'l' => __( 'Imagen (tipo «con imagen»)', 'wakoo' ) ],
					'correct' => [ 't' => 'switch', 'l' => __( 'Es respuesta correcta (modo quiz)', 'wakoo' ), 'd' => '' ],
					'explain' => [ 't' => 'text', 'l' => __( 'Explicación al responder (modo quiz)', 'wakoo' ), 'd' => '' ],
				], 'd' => [ [ 'label' => __( 'Opción A', 'wakoo' ) ], [ 'label' => __( 'Opción B', 'wakoo' ) ], [ 'label' => __( 'Opción C', 'wakoo' ) ] ] ],
				'quiz'     => [ 't' => 'switch', 'l' => __( 'Modo quiz (con respuesta correcta y explicación)', 'wakoo' ), 'd' => '' ],
			] ],
			[ 'id' => 'sec_res', 'label' => __( 'Resultados', 'wakoo' ), 'controls' => [
				'show'    => [ 't' => 'select', 'l' => __( 'Mostrar resultados', 'wakoo' ), 'd' => 'after', 'o' => [ 'after' => __( 'Solo después de votar', 'wakoo' ), 'always' => __( 'Siempre', 'wakoo' ) ] ],
				'sort'    => [ 't' => 'select', 'l' => __( 'Orden de los resultados', 'wakoo' ), 'd' => 'order', 'o' => [ 'order' => __( 'El de las opciones', 'wakoo' ), 'votes' => __( 'Más votadas primero', 'wakoo' ) ] ],
				'counts'  => [ 't' => 'switch', 'l' => __( 'Mostrar número de votos', 'wakoo' ), 'd' => 'yes' ],
				'share'   => [ 't' => 'switch', 'l' => __( 'Botón para compartir (copia el enlace)', 'wakoo' ), 'd' => '' ],
				'version' => [ 't' => 'number', 'l' => __( 'Versión (súbela para reiniciar los votos)', 'wakoo' ), 'd' => 1, 'min' => 1 ],
			] ],
			[ 'id' => 'sec_rules', 'label' => __( 'Reglas', 'wakoo' ), 'controls' => [
				'limit'  => [ 't' => 'number', 'l' => __( 'Votos permitidos por visitante', 'wakoo' ), 'd' => 1, 'min' => 1, 'max' => 20, 'desc' => __( 'Se controla con una huella anónima (IP + navegador); no es infalible.', 'wakoo' ) ],
				'closes' => [ 't' => 'datetime', 'l' => __( 'Cierre de la votación (hora del sitio, vacío = sin cierre)', 'wakoo' ), 'd' => '' ],
			] ],
			[ 'id' => 'sec_txt', 'label' => __( 'Textos', 'wakoo' ), 'controls' => [
				'btn'    => [ 't' => 'text', 'l' => __( 'Botón votar', 'wakoo' ), 'd' => __( 'Votar', 'wakoo' ) ],
				'thanks' => [ 't' => 'text', 'l' => __( 'Mensaje de gracias', 'wakoo' ), 'd' => __( '¡Gracias por votar!', 'wakoo' ) ],
				'done'   => [ 't' => 'text', 'l' => __( 'Mensaje si ya votó', 'wakoo' ), 'd' => __( 'Ya has votado.', 'wakoo' ) ],
				'votes'  => [ 't' => 'text', 'l' => __( 'Etiqueta "votos"', 'wakoo' ), 'd' => __( 'votos', 'wakoo' ) ],
				'l_yes'  => [ 't' => 'text', 'l' => __( 'Texto «Sí»', 'wakoo' ), 'd' => __( 'Sí', 'wakoo' ) ],
				'l_no'   => [ 't' => 'text', 'l' => __( 'Texto «No»', 'wakoo' ), 'd' => __( 'No', 'wakoo' ) ],
				'l_closed' => [ 't' => 'text', 'l' => __( 'Mensaje de votación cerrada', 'wakoo' ), 'd' => __( 'La votación ha terminado.', 'wakoo' ) ],
				'l_mine'   => [ 't' => 'text', 'l' => __( 'Marca «tu voto»', 'wakoo' ), 'd' => __( 'Tu voto', 'wakoo' ) ],
				'l_right'  => [ 't' => 'text', 'l' => __( 'Quiz: acierto', 'wakoo' ), 'd' => __( '¡Correcto!', 'wakoo' ) ],
				'l_wrong'  => [ 't' => 'text', 'l' => __( 'Quiz: fallo', 'wakoo' ), 'd' => __( 'No es la respuesta correcta.', 'wakoo' ) ],
				'l_share'  => [ 't' => 'text', 'l' => __( 'Botón compartir', 'wakoo' ), 'd' => __( 'Compartir', 'wakoo' ) ],
				'l_copied' => [ 't' => 'text', 'l' => __( 'Enlace copiado', 'wakoo' ), 'd' => __( 'Enlace copiado', 'wakoo' ) ],
				'l_avg'    => [ 't' => 'text', 'l' => __( 'Etiqueta «media» (valoración)', 'wakoo' ), 'd' => __( 'Media', 'wakoo' ) ],
				'l_pick'   => [ 't' => 'text', 'l' => __( 'Aviso si no elige nada', 'wakoo' ), 'd' => __( 'Elige una opción.', 'wakoo' ) ],
			] ],
		];
	}

	/** Normalised list of answers for the poll: [ [ label, img, correct, explain ] ]. */
	private static function answers( array $s ) {
		$t = (string) ( $s['type'] ?? 'single' );
		if ( 'yesno' === $t ) { return [ [ (string) $s['l_yes'], '', false, '' ], [ (string) $s['l_no'], '', false, '' ] ]; }
		if ( 'rating' === $t ) {
			$o = [];
			for ( $i = 1; $i <= 5; $i++ ) { $o[] = [ (string) $i, '', false, '' ]; }
			return $o;
		}
		$out = [];
		foreach ( array_slice( array_values( (array) ( $s['options'] ?? [] ) ), 0, 30 ) as $o ) {
			$img = ( is_array( $o['image'] ?? null ) && ! empty( $o['image']['url'] ) ) ? esc_url_raw( $o['image']['url'], [ 'http', 'https' ] ) : '';
			$out[] = [ (string) ( $o['label'] ?? '' ), $img, 'yes' === ( $o['correct'] ?? '' ), (string) ( $o['explain'] ?? '' ) ];
		}
		return $out;
	}

	/** Closing time as a UTC epoch (0 = never). */
	private static function closes_at( array $s ) {
		$c = trim( (string) ( $s['closes'] ?? '' ) );
		if ( '' === $c ) { return 0; }
		try { return ( new \DateTime( $c, wp_timezone() ) )->getTimestamp(); } catch ( \Exception $e ) { return 0; }
	}

	protected function draw( array $s ) {
		$ans    = self::answers( $s );
		$type   = (string) $s['type'];
		$multi  = 'multiple' === $type;
		$quiz   = 'yes' === ( $s['quiz'] ?? '' ) && in_array( $type, [ 'single', 'multiple', 'image', 'yesno' ], true );
		$closes = self::closes_at( $s );
		$this->open( [
			'ver'    => max( 1, (int) $s['version'] ),
			'always' => 'always' === $s['show'],
			'counts' => 'yes' === $s['counts'],
			'multi'  => $multi,
			'kind'   => $type,
			'max'    => $multi ? max( 0, (int) $s['max_sel'] ) : 1,
			'quiz'   => $quiz,
			'sort'   => 'votes' === $s['sort'] ? 'votes' : 'order',
			'limit'  => max( 1, min( 20, (int) $s['limit'] ) ),
			'closes' => $closes,
			'share'  => 'yes' === $s['share'],
			'thanks' => (string) $s['thanks'], 'done' => (string) $s['done'], 'votes' => (string) $s['votes'],
			'closed' => (string) $s['l_closed'], 'mine' => (string) $s['l_mine'], 'right' => (string) $s['l_right'], 'wrong' => (string) $s['l_wrong'],
			'lshare' => (string) $s['l_share'], 'copied' => (string) $s['l_copied'], 'avg' => (string) $s['l_avg'], 'pick' => (string) $s['l_pick'],
		], 'is-' . $type );
		$q   = esc_html( $s['question'] );
		$wid = 'wks-poll-' . esc_attr( $this->get_id() );
		echo '<form class="wks-poll__form wks-card" id="' . $wid . '" novalidate><fieldset class="wks-poll__set"><legend class="wks-group-title">' . $q . '</legend>';
		if ( 'rating' === $type ) {
			echo '<div class="wks-poll__stars" role="radiogroup" aria-label="' . esc_attr( $s['question'] ) . '">';
			foreach ( array_reverse( $ans, true ) as $i => $a ) { // DOM 5→1 + row-reverse = 1→5 on screen, so ~ highlights lower stars.
				$id = $wid . '-' . $i;
				echo '<input class="wks-sr" id="' . $id . '" type="radio" name="o" value="' . (int) $i . '"><label for="' . $id . '" title="' . esc_attr( $a[0] ) . '" class="wks-poll__star"><span aria-hidden="true">★</span><span class="wks-sr">' . esc_html( $a[0] ) . '</span></label>';
			}
			echo '</div>';
		} else {
			echo '<div class="wks-poll__opts' . ( 'image' === $type ? ' wks-poll__opts--img' : '' ) . '">';
			foreach ( $ans as $i => $a ) {
				$id = $wid . '-' . $i;
				echo '<div class="wks-poll__opt"><input id="' . $id . '" type="' . ( $multi ? 'checkbox' : 'radio' ) . '" name="o" value="' . (int) $i . '"><label for="' . $id . '">';
				if ( 'image' === $type && $a[1] ) { echo '<img src="' . esc_url( $a[1] ) . '" alt="" loading="lazy">'; }
				echo '<span>' . esc_html( $a[0] ) . '</span></label></div>';
			}
			echo '</div>';
		}
		echo '</fieldset><div class="wks-hp" aria-hidden="true"><input type="text" name="website" tabindex="-1" autocomplete="off"></div>';
		echo '<button type="submit" class="wks-btn">' . esc_html( $s['btn'] ) . '</button></form>';
		echo '<div class="wks-poll__res wks-card" hidden aria-live="polite"><div class="wks-group-title">' . $q . '</div><div class="wks-poll__verdict" hidden></div>';
		if ( 'rating' === $type ) { echo '<div class="wks-poll__avg"><b></b><span class="wks-stars" aria-hidden="true"></span></div>'; }
		echo '<div class="wks-poll__rows">';
		foreach ( $ans as $i => $a ) {
			echo '<div class="wks-poll__row" data-i="' . (int) $i . '">';
			if ( $a[1] ) { echo '<img class="wks-poll__thumb" src="' . esc_url( $a[1] ) . '" alt="" loading="lazy">'; }
			echo '<div class="wks-poll__main"><div class="wks-poll__lab"><span>' . ( 'rating' === $type ? esc_html( $a[0] ) . ' ★' : esc_html( $a[0] ) ) . '<em class="wks-poll__tag" hidden></em></span><b class="wks-poll__pct">0%</b></div><div class="wks-bar"><i></i></div><small class="wks-poll__n"></small><small class="wks-poll__why" hidden></small></div></div>';
		}
		echo '</div><p class="wks-poll__total"></p>';
		if ( 'yes' === $s['share'] ) { echo '<button type="button" class="wks-btn wks-btn--ghost wks-poll__share">' . esc_html( $s['l_share'] ) . '</button>'; }
		echo '</div><p class="wks-msg" role="status"></p>';
		$this->close();
	}

	/* ------------------------------------------------------------ server */

	private static function conf( $post, $w ) {
		return Data::widget( $post, $w, 'wakoo-poll' );
	}

	private static function okey( $post, $w ) { return 'wks_poll_' . md5( (int) $post . '|' . $w ); }

	private static function results( $s, $post, $w, $reveal = false ) {
		$ver  = max( 1, (int) $s['version'] );
		$ans  = self::answers( $s );
		$data = get_option( self::okey( $post, $w ), [] );
		$ok   = is_array( $data ) && ( $data['v'] ?? 0 ) === $ver;
		$c    = $ok ? (array) $data['c'] : [];
		$out  = [];
		foreach ( $ans as $i => $a ) { $out[] = (int) ( $c[ $i ] ?? 0 ); }
		$res  = [ 'counts' => $out, 'voters' => $ok ? (int) ( $data['n'] ?? 0 ) : 0, 'closed' => self::is_closed( $s ) ];
		if ( $reveal && 'yes' === ( $s['quiz'] ?? '' ) ) {
			$res['correct'] = [];
			$res['why']     = [];
			foreach ( $ans as $i => $a ) {
				if ( $a[2] ) { $res['correct'][] = $i; }
				if ( '' !== $a[3] ) { $res['why'][ $i ] = wp_strip_all_tags( $a[3] ); }
			}
		}
		return $res;
	}

	private static function is_closed( $s ) {
		$t = self::closes_at( $s );
		return $t > 0 && time() >= $t;
	}

	private static function votes_used( $post, $w, $s ) {
		$ver = max( 1, (int) $s['version'] );
		return (int) get_transient( 'wks_pv_' . md5( $post . '|' . $w . '|' . $ver . '|' . Sec::visitor() ) );
	}

	public static function routes() {
		Sec::route( 'poll/results', 'GET', static function ( \WP_REST_Request $r ) {
			$post = Sec::int( $r->get_param( 'post' ), 0 );
			$w    = Sec::text( $r->get_param( 'w' ), 32 );
			$s    = self::conf( $post, $w );
			if ( ! $s ) { return Sec::err( 'No encontrado', 404 ); }
			if ( ! Sec::rate( 'poll-res', 120, 600 ) ) { return Sec::err( 'Demasiadas peticiones', 429 ); }
			// Correct answers are only revealed to visitors who already voted, or once the poll is closed.
			$reveal = self::votes_used( $post, $w, $s ) > 0 || self::is_closed( $s );
			return Sec::ok( self::results( $s, $post, $w, $reveal ) );
		} );
		Sec::route( 'poll/vote', 'POST', static function ( \WP_REST_Request $r ) {
			if ( ! Sec::human( $r, 500 ) ) { return Sec::err( 'Inténtalo de nuevo', 400 ); }
			if ( ! Sec::rate( 'poll-vote', 30, 600 ) ) { return Sec::err( 'Demasiadas peticiones', 429 ); }
			$post = Sec::int( $r->get_param( 'post' ), 0 );
			$w    = Sec::text( $r->get_param( 'w' ), 32 );
			$s    = self::conf( $post, $w );
			if ( ! $s ) { return Sec::err( 'No encontrado', 404 ); }
			if ( self::is_closed( $s ) ) {
				return new \WP_REST_Response( [ 'ok' => false, 'closed' => true, 'error' => (string) $s['l_closed'] ] + self::results( $s, $post, $w, true ), 403 );
			}
			$n    = count( self::answers( $s ) );
			$type = (string) $s['type'];
			$sel  = array_values( array_unique( array_map( 'intval', (array) $r->get_param( 'opts' ) ) ) );
			$sel  = array_values( array_filter( $sel, static function ( $i ) use ( $n ) { return $i >= 0 && $i < $n; } ) );
			$max  = 'multiple' === $type ? (int) $s['max_sel'] : 1;
			if ( ! $sel || ( $max > 0 && count( $sel ) > $max ) ) { return Sec::err( (string) $s['l_pick'], 400 ); }
			$ver   = max( 1, (int) $s['version'] );
			$vkey  = 'wks_pv_' . md5( $post . '|' . $w . '|' . $ver . '|' . Sec::visitor() );
			$limit = max( 1, min( 20, (int) $s['limit'] ) );
			$used  = (int) get_transient( $vkey );
			if ( $used >= $limit ) {
				return new \WP_REST_Response( [ 'ok' => false, 'voted' => true, 'error' => (string) $s['done'] ] + self::results( $s, $post, $w, true ), 409 );
			}
			$lock = Sec::lock( 'poll' . $post . $w );
			if ( ! $lock ) { return Sec::err( 'Ocupado, reinténtalo', 503 ); }
			$ok   = self::okey( $post, $w );
			$data = get_option( $ok, [] );
			if ( ! is_array( $data ) || ( $data['v'] ?? 0 ) !== $ver ) { $data = [ 'v' => $ver, 'c' => [], 'n' => 0 ]; }
			foreach ( $sel as $i ) { $data['c'][ $i ] = (int) ( $data['c'][ $i ] ?? 0 ) + 1; }
			$data['n'] = (int) $data['n'] + 1;
			update_option( $ok, $data, false );
			Sec::unlock( $lock );
			set_transient( $vkey, $used + 1, 30 * DAY_IN_SECONDS );
			return Sec::ok( self::results( $s, $post, $w, true ) + [ 'left' => $limit - $used - 1 ] );
		} );
	}
}
