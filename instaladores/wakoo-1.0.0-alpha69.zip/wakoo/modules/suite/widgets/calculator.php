<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;

defined( 'ABSPATH' ) || die();

/** Calculadora de presupuesto: campos agrupados, total en vivo y resumen enviable. */
class Calculator extends Base {

	public function slug() { return 'calculator'; }
	public function label() { return __( 'Calculadora de presupuesto', 'wakoo' ); }
	public function cat() { return 'commerce'; }
	public function icon() { return 'eicon-calculator'; }
	public function words() { return [ 'calculadora', 'presupuesto', 'precio', 'cotizador', 'total' ]; }

	protected function sections() {
		$f = [
			[ 'group' => __( 'Proyecto', 'wakoo' ), 'label' => __( 'Páginas', 'wakoo' ), 'type' => 'slider', 'price' => 50, 'min' => 1, 'max' => 20, 'step' => 1, 'def' => 5, 'opts' => '' ],
			[ 'group' => __( 'Proyecto', 'wakoo' ), 'label' => __( 'Tipo de diseño', 'wakoo' ), 'type' => 'select', 'price' => 0, 'min' => 0, 'max' => 0, 'step' => 1, 'def' => 0, 'opts' => "Básico=0\nPersonalizado=300\nPremium=800" ],
			[ 'group' => __( 'Extras', 'wakoo' ), 'label' => __( 'Tienda online', 'wakoo' ), 'type' => 'toggle', 'price' => 400, 'min' => 0, 'max' => 0, 'step' => 1, 'def' => 0, 'opts' => '' ],
			[ 'group' => __( 'Extras', 'wakoo' ), 'label' => __( 'Idiomas adicionales', 'wakoo' ), 'type' => 'number', 'price' => 120, 'min' => 0, 'max' => 10, 'step' => 1, 'def' => 0, 'opts' => '' ],
		];
		return [
			[ 'id' => 'sec_fields', 'label' => __( 'Campos', 'wakoo' ), 'controls' => [
				'base'   => [ 't' => 'number', 'l' => __( 'Precio base', 'wakoo' ), 'd' => 200, 'min' => 0, 'step' => 0.01 ],
				'fields' => [ 't' => 'repeater', 'title' => '{{{ group }}} · {{{ label }}}', 'fields' => [
					'group' => [ 't' => 'text', 'l' => __( 'Grupo', 'wakoo' ), 'd' => __( 'General', 'wakoo' ) ],
					'label' => [ 't' => 'text', 'l' => __( 'Etiqueta', 'wakoo' ), 'd' => __( 'Campo', 'wakoo' ) ],
					'type'  => [ 't' => 'select', 'l' => __( 'Tipo', 'wakoo' ), 'd' => 'number', 'o' => [ 'slider' => __( 'Deslizador', 'wakoo' ), 'number' => __( 'Número', 'wakoo' ), 'toggle' => __( 'Interruptor', 'wakoo' ), 'select' => __( 'Lista', 'wakoo' ) ] ],
					'price' => [ 't' => 'number', 'l' => __( 'Precio por unidad / si activo', 'wakoo' ), 'd' => 0, 'step' => 0.01 ],
					'min'   => [ 't' => 'number', 'l' => __( 'Mínimo', 'wakoo' ), 'd' => 0 ],
					'max'   => [ 't' => 'number', 'l' => __( 'Máximo', 'wakoo' ), 'd' => 10 ],
					'step'  => [ 't' => 'number', 'l' => __( 'Paso', 'wakoo' ), 'd' => 1, 'min' => 0.01, 'step' => 0.01 ],
					'def'   => [ 't' => 'number', 'l' => __( 'Valor inicial (en lista: nº de opción desde 0)', 'wakoo' ), 'd' => 0 ],
					'opts'  => [ 't' => 'textarea', 'l' => __( 'Opciones de la lista (una por línea: Etiqueta=precio)', 'wakoo' ), 'd' => '', 'rows' => 4, 'c' => [ 'type' => 'select' ] ],
					'unit'  => [ 't' => 'text', 'l' => __( 'Unidad', 'wakoo' ), 'd' => '' ],
				], 'd' => $f ],
			] ],
			[ 'id' => 'sec_format', 'label' => __( 'Formato y resumen', 'wakoo' ), 'controls' => [
				'title'     => [ 't' => 'text', 'l' => __( 'Título', 'wakoo' ), 'd' => __( 'Calcula tu presupuesto', 'wakoo' ) ],
				'currency'  => [ 't' => 'text', 'l' => __( 'Símbolo de moneda', 'wakoo' ), 'd' => '€' ],
				'cur_after' => [ 't' => 'switch', 'l' => __( 'Símbolo después', 'wakoo' ), 'd' => 'yes' ],
				'decimals'  => [ 't' => 'number', 'l' => __( 'Decimales', 'wakoo' ), 'd' => 0, 'min' => 0, 'max' => 4 ],
				'total_txt' => [ 't' => 'text', 'l' => __( 'Texto del total', 'wakoo' ), 'd' => __( 'Total estimado', 'wakoo' ) ],
				'summary'   => [ 't' => 'switch', 'l' => __( 'Mostrar resumen', 'wakoo' ), 'd' => 'yes' ],
				'cta_text'  => [ 't' => 'text', 'l' => __( 'Texto del botón', 'wakoo' ), 'd' => __( 'Solicitar presupuesto', 'wakoo' ) ],
				'cta_url'   => [ 't' => 'url', 'l' => __( 'Enlace del botón', 'wakoo' ), 'd' => [ 'url' => '' ], 'desc' => __( 'mailto:, WhatsApp (https://wa.me/número) o una página. El resumen se añade al enlace.', 'wakoo' ) ],
				'param'     => [ 't' => 'text', 'l' => __( 'Parámetro del resumen (si no es mailto)', 'wakoo' ), 'd' => 'summary' ],
			] ],
		];
	}

	protected function draw( array $s ) {
		$fields = [];
		foreach ( (array) $s['fields'] as $f ) {
			$type = in_array( $f['type'] ?? '', [ 'slider', 'number', 'toggle', 'select' ], true ) ? $f['type'] : 'number';
			$o = [ 'g' => (string) ( $f['group'] ?? '' ), 'l' => (string) ( $f['label'] ?? '' ), 't' => $type, 'p' => (float) ( $f['price'] ?? 0 ),
				'min' => (float) ( $f['min'] ?? 0 ), 'max' => (float) ( $f['max'] ?? 10 ), 'st' => max( 0.01, (float) ( $f['step'] ?? 1 ) ), 'd' => (float) ( $f['def'] ?? 0 ), 'u' => (string) ( $f['unit'] ?? '' ) ];
			if ( 'select' === $type ) {
				$o['o'] = [];
				foreach ( preg_split( '/\r\n|\r|\n/', (string) ( $f['opts'] ?? '' ) ) as $line ) {
					$line = trim( $line );
					if ( '' === $line ) { continue; }
					$pos = strrpos( $line, '=' );
					$o['o'][] = false === $pos ? [ $line, 0 ] : [ trim( substr( $line, 0, $pos ) ), (float) substr( $line, $pos + 1 ) ];
				}
				if ( ! $o['o'] ) { continue; }
			}
			$fields[] = $o;
		}
		$url = ! empty( $s['cta_url']['url'] ) ? esc_url_raw( $s['cta_url']['url'], [ 'http', 'https', 'mailto', 'tel' ] ) : '';
		$this->open( [
			'title' => (string) $s['title'], 'base' => (float) $s['base'], 'fields' => $fields, 'cur' => (string) $s['currency'],
			'after' => 'yes' === $s['cur_after'], 'dec' => max( 0, min( 4, (int) $s['decimals'] ) ), 'totalTxt' => (string) $s['total_txt'],
			'summary' => 'yes' === $s['summary'], 'cta' => (string) $s['cta_text'], 'url' => $url, 'blank' => ! empty( $s['cta_url']['is_external'] ),
			'param' => preg_replace( '/[^a-z0-9_\-]/i', '', (string) $s['param'] ) ?: 'summary',
		] );
		if ( $s['title'] ) { echo '<h3 class="wks-calc__title">' . esc_html( $s['title'] ) . '</h3>'; }
		echo '<div class="wks-calc__fields"></div><div class="wks-calc__total" aria-live="polite"></div><ul class="wks-calc__sum"></ul><div class="wks-calc__cta"></div>';
		$this->close();
	}
}
