<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;
use Wakoo\Modules\Suite\Data;
use Wakoo\Modules\Suite\Sec;

defined( 'ABSPATH' ) || die();

/** 10. Pestañas con contenido dinámico: cada pestaña puede cargar una plantilla de Wakoo/Elementor. */
class Tabs extends Base {

	public function slug() { return 'tabs'; }
	public function label() { return __( 'Pestañas dinámicas', 'wakoo' ); }
	public function icon() { return 'eicon-tabs'; }
	public function words() { return [ 'pestañas', 'tabs', 'plantilla', 'template' ]; }

	/** Published library templates [ id => title ] (cached briefly). */
	private static function templates() {
		$list = get_transient( 'wks_tabs_tpls' );
		if ( ! is_array( $list ) ) {
			$list = [];
			$ids = get_posts( [ 'post_type' => 'elementor_library', 'post_status' => 'publish', 'numberposts' => 200, 'fields' => 'ids', 'orderby' => 'title', 'order' => 'ASC', 'no_found_rows' => true ] );
			foreach ( $ids as $id ) { $list[ $id ] = get_the_title( $id ) ?: ( '#' . $id ); }
			set_transient( 'wks_tabs_tpls', $list, 60 );
		}
		return [ '' => __( '— Elige una plantilla —', 'wakoo' ) ] + $list;
	}

	protected function sections() {
		return [
			[ 'id' => 'sec_tabs', 'label' => __( 'Pestañas', 'wakoo' ), 'controls' => [
				'items' => [ 't' => 'repeater', 'title' => '{{{ title }}}', 'fields' => [
					'group'  => [ 't' => 'text', 'l' => __( 'Grupo (opcional)', 'wakoo' ), 'd' => '' ],
					'title'  => [ 't' => 'text', 'l' => __( 'Título', 'wakoo' ), 'd' => __( 'Pestaña', 'wakoo' ) ],
					'icon'   => [ 't' => 'text', 'l' => __( 'Icono (emoji o texto corto)', 'wakoo' ), 'd' => '' ],
					'source' => [ 't' => 'select', 'l' => __( 'Contenido', 'wakoo' ), 'd' => 'inline', 'o' => [ 'inline' => __( 'Texto', 'wakoo' ), 'template' => __( 'Plantilla guardada', 'wakoo' ) ] ],
					'tpl'    => [ 't' => 'select', 'l' => __( 'Plantilla', 'wakoo' ), 'o' => self::templates(), 'd' => '', 'c' => [ 'source' => 'template' ] ],
					'body'   => [ 't' => 'wysiwyg', 'l' => __( 'Texto', 'wakoo' ), 'd' => __( 'Contenido de la pestaña.', 'wakoo' ), 'c' => [ 'source' => 'inline' ] ],
				], 'd' => [
					[ 'title' => __( 'Descripción', 'wakoo' ), 'icon' => '📝', 'source' => 'inline', 'body' => __( 'Contenido de la primera pestaña.', 'wakoo' ) ],
					[ 'title' => __( 'Detalles', 'wakoo' ), 'icon' => '📋', 'source' => 'inline', 'body' => __( 'Contenido de la segunda pestaña.', 'wakoo' ) ],
					[ 'title' => __( 'Opiniones', 'wakoo' ), 'icon' => '⭐', 'source' => 'inline', 'body' => __( 'Contenido de la tercera pestaña.', 'wakoo' ) ],
				] ],
			] ],
			[ 'id' => 'sec_opts', 'label' => __( 'Opciones', 'wakoo' ), 'controls' => [
				'layout'  => [ 't' => 'select', 'l' => __( 'Disposición', 'wakoo' ), 'd' => 'horizontal', 'o' => [ 'horizontal' => __( 'Horizontal', 'wakoo' ), 'vertical' => __( 'Vertical', 'wakoo' ) ] ],
				'loading' => [ 't' => 'text', 'l' => __( 'Texto de carga', 'wakoo' ), 'd' => __( 'Cargando…', 'wakoo' ) ],
				'error'   => [ 't' => 'text', 'l' => __( 'Texto de error', 'wakoo' ), 'd' => __( 'No se pudo cargar el contenido.', 'wakoo' ) ],
			] ],
		];
	}

	/** Valid, public template id from an item (0 if not allowed). */
	private static function template_id( array $item ) {
		if ( 'template' !== ( $item['source'] ?? '' ) ) { return 0; }
		$id = (int) ( $item['tpl'] ?? 0 );
		if ( ! $id || 'elementor_library' !== get_post_type( $id ) || 'publish' !== get_post_status( $id ) ) { return 0; }
		return $id;
	}

	/** Renders a template to HTML, cached until the template changes. */
	private static function render_template( $id ) {
		$key = 'wks_tab_' . $id . '_' . strtotime( get_post_field( 'post_modified_gmt', $id ) );
		$html = get_transient( $key );
		if ( false === $html ) {
			$html = \Elementor\Plugin::$instance->frontend->get_builder_content_for_display( $id, true );
			set_transient( $key, $html, DAY_IN_SECONDS );
		}
		return $html;
	}

	public static function routes() {
		Sec::route( 'tabs/panel', 'GET', [ __CLASS__, 'panel' ] );
	}

	public static function panel( \WP_REST_Request $r ) {
		if ( ! Sec::rate( 'tabs', 120, 600 ) ) { return Sec::err( 'rate', 429 ); }
		$set = Data::widget( (int) $r->get_param( 'post' ), (string) $r->get_param( 'w' ), 'wakoo-tabs' );
		if ( null === $set ) { return Sec::err( 'not found', 404 ); }
		$uid = preg_replace( '/[^a-z0-9]/i', '', (string) $r->get_param( 'i' ) );
		foreach ( (array) ( $set['items'] ?? [] ) as $item ) {
			if ( ( $item['_id'] ?? '' ) !== $uid ) { continue; }
			$tid = self::template_id( $item );
			if ( ! $tid ) { return Sec::err( 'not found', 404 ); }
			// Make the template's widget assets known and capture what they enqueue.
			$fe = \Elementor\Plugin::$instance->frontend;
			$fe->register_scripts();
			$fe->register_styles();
			$before_js  = wp_scripts()->queue;
			$before_css = wp_styles()->queue;
			$html = self::render_template( $tid );
			$js  = self::urls( wp_scripts(), array_diff( wp_scripts()->queue, $before_js ) );
			$css = self::urls( wp_styles(), array_diff( wp_styles()->queue, $before_css ) );
			return Sec::ok( [ 'html' => $html, 'js' => $js, 'css' => $css ] );
		}
		return Sec::err( 'not found', 404 );
	}

	/** Same-site asset URLs for the given handles (dependencies included). */
	private static function urls( $deps, $handles ) {
		$out  = [];
		$seen = [];
		$walk = function ( $h ) use ( &$walk, &$out, &$seen, $deps ) {
			if ( isset( $seen[ $h ] ) || empty( $deps->registered[ $h ] ) ) { return; }
			$seen[ $h ] = 1;
			foreach ( (array) $deps->registered[ $h ]->deps as $d ) { $walk( $d ); }
			$src = $deps->registered[ $h ]->src;
			if ( is_string( $src ) && $src ) {
				if ( 0 === strpos( $src, '/' ) && 0 !== strpos( $src, '//' ) ) { $src = site_url( $src ); }
				$home = wp_parse_url( home_url(), PHP_URL_HOST );
				if ( wp_parse_url( $src, PHP_URL_HOST ) === $home && ! preg_match( '#/(jquery(-migrate)?|jquery\.min)\.#', $src ) ) {
					$out[ $h ] = esc_url_raw( $src );
				}
			}
		};
		foreach ( $handles as $h ) { $walk( $h ); }
		return array_values( $out );
	}

	protected function draw( array $s ) {
		$items = array_values( (array) ( $s['items'] ?? [] ) );
		if ( ! $items ) { return; }
		$this->open( [ 'loading' => (string) $s['loading'], 'error' => (string) $s['error'] ], 'is-' . ( 'vertical' === $s['layout'] ? 'vertical' : 'horizontal' ) );
		$uid = esc_attr( $this->get_id() );
		echo '<div class="wks-tabs__nav" role="tablist" aria-orientation="' . ( 'vertical' === $s['layout'] ? 'vertical' : 'horizontal' ) . '">';
		$lastg = null;
		foreach ( $items as $i => $it ) {
			$g = trim( (string) ( $it['group'] ?? '' ) );
			if ( $g !== '' && $g !== $lastg ) { echo '<span class="wks-tabs__grp" role="presentation">' . esc_html( $g ) . '</span>'; }
			$lastg = $g;
			$tid = self::template_id( $it );
			echo '<button type="button" role="tab" class="wks-tabs__tab' . ( 0 === $i ? ' is-active' : '' ) . '" id="wks-t-' . $uid . '-' . $i . '" aria-controls="wks-p-' . $uid . '-' . $i . '" aria-selected="' . ( 0 === $i ? 'true' : 'false' ) . '" tabindex="' . ( 0 === $i ? '0' : '-1' ) . '"' . ( $tid ? ' data-i="' . esc_attr( $it['_id'] ?? '' ) . '"' : '' ) . '>';
			if ( ! empty( $it['icon'] ) ) { echo '<span class="wks-tabs__ico" aria-hidden="true">' . esc_html( $it['icon'] ) . '</span>'; }
			echo '<span>' . esc_html( $it['title'] ?? '' ) . '</span></button>';
		}
		echo '</div><div class="wks-tabs__panels">';
		foreach ( $items as $i => $it ) {
			$tid = self::template_id( $it );
			echo '<div class="wks-tabs__panel" role="tabpanel" id="wks-p-' . $uid . '-' . $i . '" aria-labelledby="wks-t-' . $uid . '-' . $i . '" tabindex="0"' . ( 0 === $i ? '' : ' hidden' ) . ( $tid && 0 !== $i ? ' data-lazy="1"' : '' ) . '>';
			if ( $tid ) {
				if ( 0 === $i ) { echo self::render_template( $tid ); } // phpcs:ignore
			} else {
				echo wp_kses_post( $it['body'] ?? '' );
			}
			echo '</div>';
		}
		echo '</div>';
		$this->close();
	}
}
