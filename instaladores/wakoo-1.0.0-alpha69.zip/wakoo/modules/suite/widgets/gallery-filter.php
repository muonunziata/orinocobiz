<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;

defined( 'ABSPATH' ) || die();

/** Galería con filtros por etiqueta, transiciones FLIP y lightbox propio. */
class GalleryFilter extends Base {

	public function slug() { return 'gallery-filter'; }
	public function label() { return __( 'Galería filtrable', 'wakoo' ); }
	public function cat() { return 'media'; }
	public function icon() { return 'eicon-gallery-grid'; }
	public function words() { return [ 'galeria', 'gallery', 'filtro', 'lightbox', 'portfolio' ]; }

	private static function demo( $f ) { return [ 'url' => WAKOO_MODULES_URL . 'suite/assets/demo/' . $f, 'id' => 0 ]; }

	protected function sections() {
		$d = [
			[ 'photo-1.svg', __( 'Amanecer', 'wakoo' ), 'naturaleza, paisaje' ],
			[ 'photo-2.svg', __( 'Ciudad', 'wakoo' ), 'urbano' ],
			[ 'photo-3.svg', __( 'Bosque', 'wakoo' ), 'naturaleza' ],
			[ 'photo-4.svg', __( 'Puente', 'wakoo' ), 'urbano, paisaje' ],
			[ 'photo-5.svg', __( 'Costa', 'wakoo' ), 'paisaje' ],
			[ 'photo-6.svg', __( 'Mercado', 'wakoo' ), 'urbano' ],
		];
		$rows = [];
		foreach ( $d as $x ) { $rows[] = [ 'image' => self::demo( $x[0] ), 'title' => $x[1], 'tags' => $x[2], 'group' => '' ]; }
		return [
			[ 'id' => 'sec_items', 'label' => __( 'Imágenes', 'wakoo' ), 'controls' => [
				'images' => [ 't' => 'repeater', 'title' => '{{{ title }}}', 'fields' => [
					'image' => [ 't' => 'media', 'l' => __( 'Imagen', 'wakoo' ) ],
					'title' => [ 't' => 'text', 'l' => __( 'Título', 'wakoo' ), 'd' => '' ],
					'tags'  => [ 't' => 'text', 'l' => __( 'Etiquetas (separadas por coma)', 'wakoo' ), 'd' => '' ],
					'group' => [ 't' => 'text', 'l' => __( 'Grupo (opcional)', 'wakoo' ), 'd' => '' ],
				], 'd' => $rows ],
			] ],
			[ 'id' => 'sec_layout', 'label' => __( 'Diseño', 'wakoo' ), 'controls' => [
				'all'     => [ 't' => 'text', 'l' => __( 'Texto del filtro «todas»', 'wakoo' ), 'd' => __( 'Todas', 'wakoo' ) ],
				'cols'    => [ 't' => 'number', 'l' => __( 'Columnas (escritorio)', 'wakoo' ), 'd' => 3, 'min' => 1, 'max' => 6, 'sel' => [ '{{WRAPPER}} .wks-gf__grid' => '--wks-cols: {{VALUE}};' ] ],
				'aspect'  => [ 't' => 'select', 'l' => __( 'Proporción', 'wakoo' ), 'd' => '4 / 3', 'o' => [ '1 / 1' => '1:1', '4 / 3' => '4:3', '3 / 2' => '3:2', '16 / 9' => '16:9', '3 / 4' => '3:4' ], 'sel' => [ '{{WRAPPER}} .wks-gf__item' => 'aspect-ratio: {{VALUE}};' ] ],
				'caption' => [ 't' => 'switch', 'l' => __( 'Mostrar títulos', 'wakoo' ), 'd' => 'yes' ],
				'close'   => [ 't' => 'text', 'l' => __( 'Texto cerrar', 'wakoo' ), 'd' => __( 'Cerrar', 'wakoo' ) ],
				'prev'    => [ 't' => 'text', 'l' => __( 'Texto anterior', 'wakoo' ), 'd' => __( 'Anterior', 'wakoo' ) ],
				'next'    => [ 't' => 'text', 'l' => __( 'Texto siguiente', 'wakoo' ), 'd' => __( 'Siguiente', 'wakoo' ) ],
			] ],
		];
	}

	protected function draw( array $s ) {
		$items = [];
		$tags  = [];
		foreach ( (array) ( $s['images'] ?? [] ) as $r ) {
			$src = $this->img( $r['image'] ?? [] );
			if ( ! $src ) { continue; }
			$t = [];
			foreach ( explode( ',', (string) ( $r['tags'] ?? '' ) ) as $x ) {
				$x = trim( sanitize_text_field( $x ) );
				if ( '' !== $x ) { $t[ strtolower( $x ) ] = $x; }
			}
			foreach ( $t as $k => $v ) { $tags[ $k ] = $v; }
			$items[] = [ 'src' => $src, 'title' => (string) ( $r['title'] ?? '' ), 'tags' => array_keys( $t ), 'group' => trim( (string) ( $r['group'] ?? '' ) ) ];
		}
		$this->open( [ 'close' => $s['close'], 'prev' => $s['prev'], 'next' => $s['next'] ] );
		if ( $tags ) {
			echo '<div class="wks-gf__chips" role="group" aria-label="' . esc_attr( $s['all'] ) . '"><button type="button" class="wks-chip is-active" data-tag="" aria-pressed="true">' . esc_html( $s['all'] ) . '</button>';
			foreach ( $tags as $k => $label ) {
				echo '<button type="button" class="wks-chip" data-tag="' . esc_attr( $k ) . '" aria-pressed="false">' . esc_html( $label ) . '</button>';
			}
			echo '</div>';
		}
		$groups = [];
		foreach ( $items as $i ) { $groups[ $i['group'] ][] = $i; }
		foreach ( $groups as $name => $rows ) {
			if ( '' !== $name ) { echo '<h3 class="wks-group-title">' . esc_html( $name ) . '</h3>'; }
			echo '<div class="wks-gf__grid">';
			foreach ( $rows as $i ) {
				echo '<figure class="wks-gf__item" data-tags="' . esc_attr( implode( ',', $i['tags'] ) ) . '">';
				echo '<button type="button" class="wks-gf__open" data-full="' . esc_url( $i['src'] ) . '" aria-label="' . esc_attr( $i['title'] ?: __( 'Ampliar imagen', 'wakoo' ) ) . '">';
				echo '<img src="' . esc_url( $i['src'] ) . '" alt="' . esc_attr( $i['title'] ) . '" loading="lazy" decoding="async"></button>';
				if ( 'yes' === $s['caption'] && '' !== $i['title'] ) { echo '<figcaption>' . esc_html( $i['title'] ) . '</figcaption>'; }
				echo '</figure>';
			}
			echo '</div>';
		}
		echo '<p class="wks-gf__empty" hidden></p>';
		$this->close();
	}
}
