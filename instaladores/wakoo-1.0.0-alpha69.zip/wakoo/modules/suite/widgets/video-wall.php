<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;

defined( 'ABSPATH' ) || die();

/** Pared de vídeos infinita: se arrastra en cualquier dirección, vista previa muda al pasar y ventana con sonido al hacer clic. Solo se carga la portada de cada vídeo. */
class VideoWall extends Base {

	const MAX_TILES = 66;

	public function slug() { return 'video-wall'; }
	public function label() { return __( 'Pared de vídeos infinita', 'wakoo' ); }
	public function cat() { return 'media'; }
	public function icon() { return 'eicon-video-playlist'; }
	public function words() { return [ 'video', 'vídeo', 'pared', 'wall', 'galeria', 'infinita', 'arrastrar' ]; }

	private static function demo( $f ) { return [ 'url' => WAKOO_MODULES_URL . 'suite/assets/demo/' . $f, 'id' => 0 ]; }

	protected function sections() {
		$items = [];
		for ( $i = 1; $i <= 6; $i++ ) {
			$items[] = [
				'title'    => sprintf( __( 'Vídeo de ejemplo %d', 'wakoo' ), $i ),
				'poster'   => self::demo( 'photo-' . $i . '.svg' ),
				'category' => [ 'Negocios', 'Empleo', 'Eventos' ][ $i % 3 ],
				'orient'   => 'auto',
			];
		}
		return [
			[ 'id' => 'sec_items', 'label' => __( 'Vídeos', 'wakoo' ), 'controls' => [
				'note_items' => [ 't' => 'note', 'l' => __( 'Cada recuadro carga solo su imagen de portada. El vídeo se descarga únicamente al pasar el ratón (vista previa) o al hacer clic. Sin portada se muestra un recuadro de color.', 'wakoo' ) ],
				'items' => [ 't' => 'repeater', 'title' => '{{{ title }}}', 'fields' => [
					'title'    => [ 't' => 'text', 'l' => __( 'Título', 'wakoo' ), 'd' => '' ],
					'video'    => [ 't' => 'media', 'mt' => [ 'video' ], 'l' => __( 'Vídeo (biblioteca)', 'wakoo' ), 'd' => [ 'url' => '' ] ],
					'video_url' => [ 't' => 'url', 'l' => __( 'o enlace a un .mp4 / .webm propio', 'wakoo' ) ],
					'poster'   => [ 't' => 'media', 'l' => __( 'Imagen de portada (recomendada)', 'wakoo' ), 'd' => [ 'url' => '' ] ],
					'category' => [ 't' => 'text', 'l' => __( 'Categoría (de la lista de categorías)', 'wakoo' ), 'd' => '' ],
					'orient'   => [ 't' => 'select', 'l' => __( 'Orientación', 'wakoo' ), 'd' => 'auto', 'o' => [ 'auto' => __( 'Automática (alterna)', 'wakoo' ), 'P' => __( 'Vertical', 'wakoo' ), 'L' => __( 'Horizontal', 'wakoo' ) ] ],
				], 'd' => $items ],
				'cats' => [ 't' => 'textarea', 'l' => __( 'Categorías y colores (una por línea: Nombre|#fondo|#texto)', 'wakoo' ), 'rows' => 6, 'd' => "Negocios|#E3A92B|#1B1608\nEmpleo|#2B8ED0|#FFFFFF\nEventos|#CC7A3A|#FFFFFF" ],
			] ],
			[ 'id' => 'sec_wall', 'label' => __( 'Pared', 'wakoo' ), 'controls' => [
				'rows'     => [ 't' => 'number', 'l' => __( 'Filas', 'wakoo' ), 'd' => 5, 'min' => 2, 'max' => 10 ],
				'cols'     => [ 't' => 'number', 'l' => __( 'Columnas (en simétrica se ajusta a impar)', 'wakoo' ), 'd' => 9, 'min' => 3, 'max' => 21 ],
				'max_tiles' => [ 't' => 'number', 'l' => __( 'Máximo de recuadros (tope duro 66)', 'wakoo' ), 'd' => 45, 'min' => 9, 'max' => self::MAX_TILES, 'desc' => __( 'Si filas × columnas supera el máximo, se reducen las columnas.', 'wakoo' ) ],
				'symmetry' => [ 't' => 'select', 'l' => __( 'Distribución', 'wakoo' ), 'd' => 'sym', 'o' => [ 'sym' => __( 'Simétrica (cada fila es un espejo)', 'wakoo' ), 'asym' => __( 'Asimétrica (libre)', 'wakoo' ) ] ],
				'gap'      => [ 't' => 'number', 'l' => __( 'Separación (px, 0 = automática)', 'wakoo' ), 'd' => 0, 'min' => 0, 'max' => 80 ],
				'height'   => [ 't' => 'number', 'l' => __( 'Altura de la pared (vh)', 'wakoo' ), 'd' => 90, 'min' => 40, 'max' => 200, 'sel' => [ '{{WRAPPER}} .wks-vw' => '--vw-h: {{VALUE}}vh;' ] ],
				'tile_h'   => [ 't' => 'number', 'l' => __( 'Tamaño de los recuadros (% de la altura de pantalla)', 'wakoo' ), 'd' => 36, 'min' => 15, 'max' => 70, 'sel' => [ '{{WRAPPER}} .wks-vw' => '--vw-th: {{VALUE}};' ] ],
				'frame'    => [ 't' => 'switch', 'l' => __( 'Marco alrededor', 'wakoo' ), 'd' => 'yes' ],
			] ],
			[ 'id' => 'sec_motion', 'label' => __( 'Movimiento y reproducción', 'wakoo' ), 'controls' => [
				'drift'    => [ 't' => 'switch', 'l' => __( 'Movimiento suave cuando nadie la toca', 'wakoo' ), 'd' => 'yes', 'desc' => __( 'Se desactiva solo si el visitante pide «reducir movimiento».', 'wakoo' ) ],
				'drift_speed' => [ 't' => 'number', 'l' => __( 'Velocidad del movimiento', 'wakoo' ), 'd' => 36, 'min' => 5, 'max' => 200, 'c' => [ 'drift' => 'yes' ] ],
				'idle'     => [ 't' => 'number', 'l' => __( 'Segundos de reposo antes de moverse', 'wakoo' ), 'd' => 2, 'min' => 0, 'max' => 30, 'c' => [ 'drift' => 'yes' ] ],
				'wheel'    => [ 't' => 'switch', 'l' => __( 'La rueda del ratón mueve la pared', 'wakoo' ), 'd' => '' ],
				'preview'  => [ 't' => 'number', 'l' => __( 'Segundos de vista previa al pasar el ratón (0 = sin vista previa)', 'wakoo' ), 'd' => 8, 'min' => 0, 'max' => 60 ],
				'max_pv'   => [ 't' => 'number', 'l' => __( 'Vistas previas a la vez (máximo)', 'wakoo' ), 'd' => 2, 'min' => 1, 'max' => 3 ],
				'popup'    => [ 't' => 'switch', 'l' => __( 'Abrir ventana con sonido al hacer clic', 'wakoo' ), 'd' => 'yes' ],
				'cursor'   => [ 't' => 'switch', 'l' => __( 'Cursor propio (solo con ratón)', 'wakoo' ), 'd' => 'yes' ],
			] ],
			[ 'id' => 'sec_text', 'label' => __( 'Textos', 'wakoo' ), 'controls' => [
				'cur_go'   => [ 't' => 'text', 'l' => __( 'Texto del cursor sobre un vídeo', 'wakoo' ), 'd' => __( '¡VER!', 'wakoo' ), 'c' => [ 'cursor' => 'yes' ] ],
				'aria'     => [ 't' => 'text', 'l' => __( 'Descripción accesible de la pared', 'wakoo' ), 'd' => __( 'Pared de vídeos. Arrastra para explorar.', 'wakoo' ) ],
				'bar_l'    => [ 't' => 'text', 'l' => __( 'Texto inferior izquierdo', 'wakoo' ), 'd' => __( 'Arrastra en cualquier dirección · pasa el ratón para una vista previa · haz clic para abrir', 'wakoo' ) ],
				'bar_r'    => [ 't' => 'text', 'l' => __( 'Texto inferior derecho', 'wakoo' ), 'd' => '' ],
				'lbl_nofile' => [ 't' => 'text', 'l' => __( 'Texto del reproductor sin archivo', 'wakoo' ), 'd' => __( 'Aquí se reproduce el vídeo, con sonido', 'wakoo' ) ],
				'lbl_close' => [ 't' => 'text', 'l' => __( 'Etiqueta «Cerrar»', 'wakoo' ), 'd' => __( 'Cerrar', 'wakoo' ) ],
				'lbl_untitled' => [ 't' => 'text', 'l' => __( 'Nombre de un vídeo sin título (usa %d para el número)', 'wakoo' ), 'd' => __( 'Vídeo %d', 'wakoo' ) ],
			] ],
			[ 'id' => 'sec_look', 'label' => __( 'Colores de la pared', 'wakoo' ), 'style' => true, 'controls' => [
				'c_wall'   => [ 't' => 'color', 'l' => __( 'Fondo de la pared', 'wakoo' ), 'sel' => [ '{{WRAPPER}} .wks-vw' => '--vw-bg: {{VALUE}};' ] ],
				'c_edge'   => [ 't' => 'color', 'l' => __( 'Color del marco y bordes', 'wakoo' ), 'sel' => [ '{{WRAPPER}} .wks-vw' => '--vw-edge: {{VALUE}};' ] ],
				'c_go'     => [ 't' => 'color', 'l' => __( 'Color del cursor', 'wakoo' ), 'sel' => [ '{{WRAPPER}} .wks-vw' => '--vw-go: {{VALUE}};' ] ],
			] ],
		];
	}

	private static function hex( $c, $fallback ) {
		$c = trim( (string) $c );
		return preg_match( '/^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i', $c ) ? $c : $fallback;
	}

	private static function contrast( $bg ) {
		$h = ltrim( $bg, '#' );
		if ( 3 === strlen( $h ) ) { $h = $h[0] . $h[0] . $h[1] . $h[1] . $h[2] . $h[2]; }
		$l = ( hexdec( substr( $h, 0, 2 ) ) * 299 + hexdec( substr( $h, 2, 2 ) ) * 587 + hexdec( substr( $h, 4, 2 ) ) * 114 ) / 1000;
		return $l > 150 ? '#14181A' : '#FFFFFF';
	}

	protected function draw( array $s ) {
		$rows = max( 2, min( 10, (int) $s['rows'] ) );
		$cols = max( 3, min( 21, (int) $s['cols'] ) );
		$cap  = max( 9, min( self::MAX_TILES, (int) $s['max_tiles'] ) );
		$sym  = 'asym' !== $s['symmetry'];
		while ( $rows * $cols > $cap && $cols > 3 ) { $cols -= 1; }
		if ( $rows * $cols > $cap ) { $rows = max( 2, (int) floor( $cap / $cols ) ); }
		if ( $sym && 0 === $cols % 2 ) { $cols = $cols > 3 ? $cols - 1 : $cols + 1; }

		$cats = [];
		foreach ( preg_split( '/\R/', (string) $s['cats'] ) as $line ) {
			$p = array_map( 'trim', explode( '|', $line ) );
			if ( '' === $p[0] ) { continue; }
			$bg = self::hex( $p[1] ?? '', '#E3A92B' );
			$fg = self::hex( $p[2] ?? '', self::contrast( $bg ) );
			$cats[ strtolower( $p[0] ) ] = [ sanitize_text_field( $p[0] ), $bg, $fg ];
		}
		$items = array_values( array_filter( (array) $s['items'], 'is_array' ) );

		$this->open( [
			'rows' => $rows, 'cols' => $cols, 'sym' => $sym ? 1 : 0, 'gap' => (int) $s['gap'],
			'drift' => 'yes' === $s['drift'] ? 1 : 0, 'driftSpeed' => (float) $s['drift_speed'], 'idle' => (float) $s['idle'],
			'wheel' => 'yes' === $s['wheel'] ? 1 : 0, 'preview' => (float) $s['preview'], 'maxPv' => max( 1, min( 3, (int) $s['max_pv'] ) ),
			'popup' => 'yes' === $s['popup'] ? 1 : 0, 'cursor' => 'yes' === $s['cursor'] ? 1 : 0,
			'go' => wp_strip_all_tags( $s['cur_go'] ), 'nofile' => wp_strip_all_tags( $s['lbl_nofile'] ), 'close' => wp_strip_all_tags( $s['lbl_close'] ),
		], 'wks-vw' . ( 'yes' === $s['frame'] ? ' has-frame' : '' ) );
		echo '<div class="wks-vw__box" role="region" aria-label="' . esc_attr( $s['aria'] ) . '"><div class="wks-vw__stage">';
		for ( $r = 0; $r < $rows; $r++ ) {
			for ( $c = 0; $c < $cols; $c++ ) {
				$n  = $r * $cols + $c;
				$it = $items ? $items[ $n % count( $items ) ] : [];
				$o  = $it['orient'] ?? 'auto';
				$k  = ( 'P' === $o || 'L' === $o ) ? $o : ( $sym ? ( ( $r + $c ) % 2 === 1 ? 'P' : 'L' ) : ( ( ( $n * 7 + $r * 3 + (int) floor( $n / 3 ) ) % 5 ) < 2 ? 'P' : 'L' ) );
				$ct = strtolower( trim( (string) ( $it['category'] ?? '' ) ) );
				if ( ! isset( $cats[ $ct ] ) && $cats ) { $keys = array_keys( $cats ); $ct = $keys[ $n % count( $keys ) ]; }
				$cat    = $cats[ $ct ] ?? null;
				$praw   = ! empty( $it['poster']['url'] ) ? esc_url_raw( $it['poster']['url'], [ 'http', 'https' ] ) : '';
				$poster = $praw ? esc_url( $praw ) : '';
				$vurl   = ! empty( $it['video']['url'] ) ? $it['video']['url'] : ( $it['video_url']['url'] ?? '' );
				$video  = $vurl ? esc_url_raw( $vurl, [ 'http', 'https' ] ) : '';
				$num    = str_pad( (string) ( $n + 1 ), 2, '0', STR_PAD_LEFT );
				$title  = ! empty( $it['title'] ) ? $it['title'] : sprintf( $s['lbl_untitled'], $n + 1 );
				echo '<button type="button" class="wks-vw__tile is-' . esc_attr( $k ) . ' k' . (int) ( ( ( $r + $c ) % 6 ) + 1 ) . '" data-n="' . (int) $n . '" data-video="' . esc_attr( $video ) . '" data-poster="' . esc_attr( $praw ) . '" data-title="' . esc_attr( $title ) . '"'
					. ( $cat ? ' data-cat="' . esc_attr( $cat[0] ) . '" data-cc="' . esc_attr( $cat[1] ) . '" data-cf="' . esc_attr( $cat[2] ) . '"' : '' ) . ' aria-label="' . esc_attr( $title ) . '">';
				if ( $poster ) { echo '<img src="' . $poster . '" alt="" loading="lazy" decoding="async" draggable="false">'; } else { echo '<span class="wks-vw__no">' . esc_html( $num ) . '</span>'; }
				if ( $cat ) { echo '<span class="wks-vw__tag" style="background:' . esc_attr( $cat[1] ) . ';color:' . esc_attr( $cat[2] ) . '">' . esc_html( $cat[0] ) . '</span>'; }
				echo '</button>';
			}
		}
		echo '</div>';
		if ( '' !== $s['bar_l'] || '' !== $s['bar_r'] ) { echo '<div class="wks-vw__bar"><span>' . esc_html( $s['bar_l'] ) . '</span><span>' . esc_html( $s['bar_r'] ) . '</span></div>'; }
		echo '</div>';
		$this->close();
	}
}
