<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;

defined( 'ABSPATH' ) || die();

/** Botón con cuenta atrás por visitante: al pulsar arranca el reloj y se revela el contenido. */
class CountdownButton extends Base {

	public function slug() { return 'countdown-button'; }
	public function label() { return __( 'Botón con cuenta atrás', 'wakoo' ); }
	public function cat() { return 'commerce'; }
	public function icon() { return 'eicon-countdown'; }
	public function words() { return [ 'cuenta atrás', 'cupón', 'oferta', 'temporizador', 'botón' ]; }

	protected function sections() {
		return [
			[ 'id' => 'sec_btn', 'label' => __( 'Botón y reloj', 'wakoo' ), 'controls' => [
				'text'    => [ 't' => 'text', 'l' => __( 'Texto del botón', 'wakoo' ), 'd' => __( 'Activar mi oferta', 'wakoo' ) ],
				'minutes' => [ 't' => 'number', 'l' => __( 'Duración (minutos)', 'wakoo' ), 'd' => 15, 'min' => 1, 'max' => 10080 ],
				'running' => [ 't' => 'text', 'l' => __( 'Texto durante la cuenta', 'wakoo' ), 'd' => __( 'Tu oferta termina en', 'wakoo' ) ],
			] ],
			[ 'id' => 'sec_reveal', 'label' => __( 'Contenido revelado', 'wakoo' ), 'controls' => [
				'content' => [ 't' => 'wysiwyg', 'l' => __( 'Contenido', 'wakoo' ), 'd' => '<p>' . __( 'Tu código: <strong>WAKOO15</strong>', 'wakoo' ) . '</p>', 'desc' => __( 'Se revela en el navegador; no es un secreto de servidor.', 'wakoo' ) ],
			] ],
			[ 'id' => 'sec_end', 'label' => __( 'Al terminar', 'wakoo' ), 'controls' => [
				'end'     => [ 't' => 'select', 'l' => __( 'Acción', 'wakoo' ), 'd' => 'message', 'o' => [ 'hide' => __( 'Ocultar el contenido', 'wakoo' ), 'message' => __( 'Mostrar un mensaje', 'wakoo' ), 'relock' => __( 'Volver a mostrar el botón', 'wakoo' ) ] ],
				'end_msg' => [ 't' => 'text', 'l' => __( 'Mensaje', 'wakoo' ), 'd' => __( 'La oferta ha terminado.', 'wakoo' ), 'c' => [ 'end' => 'message' ] ],
				'reset'   => [ 't' => 'switch', 'l' => __( 'Mostrar enlace para reiniciar', 'wakoo' ), 'd' => '' ],
				'reset_t' => [ 't' => 'text', 'l' => __( 'Texto de reinicio', 'wakoo' ), 'd' => __( 'Reiniciar', 'wakoo' ), 'c' => [ 'reset' => 'yes' ] ],
			] ],
		];
	}

	protected function draw( array $s ) {
		$ctx = $this->ctx();
		$this->open( [
			'min' => max( 1, min( 10080, (int) $s['minutes'] ) ), 'running' => (string) $s['running'], 'end' => in_array( $s['end'], [ 'hide', 'message', 'relock' ], true ) ? $s['end'] : 'message',
			'endMsg' => (string) $s['end_msg'], 'reset' => 'yes' === $s['reset'], 'resetT' => (string) $s['reset_t'],
			'key' => 'wks_cdb_' . (int) $ctx['post'] . '_' . preg_replace( '/[^a-z0-9]/i', '', (string) $ctx['w'] ),
		] );
		echo '<button type="button" class="wks-btn wks-cdb__btn">' . esc_html( $s['text'] ) . '</button>';
		echo '<div class="wks-cdb__clock" aria-live="off" hidden></div>';
		echo '<div class="wks-cdb__content" hidden>' . wp_kses_post( $s['content'] ) . '</div>';
		echo '<div class="wks-cdb__msg wks-msg" role="status" hidden></div><button type="button" class="wks-cdb__reset" hidden></button>';
		$this->close();
	}
}
