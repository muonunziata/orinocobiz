<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;
use Wakoo\Modules\Suite\Data;
use Wakoo\Modules\Suite\Sec;

defined( 'ABSPATH' ) || die();

/** 8. Contadores animados con cifras manuales o reales del propio sitio (visitas, entradas), más contador de visitas sin cookies. */
class Stats extends Base {

	const OPT = 'wakoo_stats_track';

	public function slug() { return 'stats'; }
	public function label() { return __( 'Estadísticas animadas', 'wakoo' ); }
	public function cat() { return 'data'; }
	public function icon() { return 'eicon-counter'; }
	public function words() { return [ 'contador', 'estadisticas', 'numeros', 'counter', 'visitas' ]; }

	protected function sections() {
		$src = [
			'manual' => __( 'Número manual', 'wakoo' ),
			'total'  => __( 'Visitas totales del sitio', 'wakoo' ),
			'today'  => __( 'Visitas de hoy', 'wakoo' ),
			'page'   => __( 'Visitas de esta página', 'wakoo' ),
			'posts'  => __( 'Entradas publicadas', 'wakoo' ),
		];
		return [
			[ 'id' => 'sec_items', 'label' => __( 'Contadores', 'wakoo' ), 'controls' => [
				'items' => [ 't' => 'repeater', 'title' => '{{{ label }}}', 'fields' => [
					'group'  => [ 't' => 'text', 'l' => __( 'Grupo (opcional)', 'wakoo' ), 'd' => '' ],
					'label'  => [ 't' => 'text', 'l' => __( 'Etiqueta', 'wakoo' ), 'd' => __( 'Clientes', 'wakoo' ) ],
					'source' => [ 't' => 'select', 'l' => __( 'Origen del número', 'wakoo' ), 'd' => 'manual', 'o' => $src ],
					'number' => [ 't' => 'number', 'l' => __( 'Número', 'wakoo' ), 'd' => 100, 'c' => [ 'source' => 'manual' ] ],
					'dec'    => [ 't' => 'number', 'l' => __( 'Decimales', 'wakoo' ), 'd' => 0, 'min' => 0, 'max' => 3 ],
					'prefix' => [ 't' => 'text', 'l' => __( 'Prefijo', 'wakoo' ), 'd' => '' ],
					'suffix' => [ 't' => 'text', 'l' => __( 'Sufijo', 'wakoo' ), 'd' => '' ],
				], 'd' => [
					[ 'group' => '', 'label' => __( 'Clientes felices', 'wakoo' ), 'source' => 'manual', 'number' => 1200, 'dec' => 0, 'prefix' => '', 'suffix' => '+' ],
					[ 'group' => '', 'label' => __( 'Proyectos', 'wakoo' ), 'source' => 'manual', 'number' => 350, 'dec' => 0, 'prefix' => '', 'suffix' => '' ],
					[ 'group' => '', 'label' => __( 'Satisfacción', 'wakoo' ), 'source' => 'manual', 'number' => 98, 'dec' => 0, 'prefix' => '', 'suffix' => '%' ],
					[ 'group' => '', 'label' => __( 'Entradas publicadas', 'wakoo' ), 'source' => 'posts', 'number' => 0, 'dec' => 0, 'prefix' => '', 'suffix' => '' ],
				] ],
			] ],
			[ 'id' => 'sec_opts', 'label' => __( 'Opciones', 'wakoo' ), 'controls' => [
				'cols'  => [ 't' => 'select', 'l' => __( 'Columnas', 'wakoo' ), 'd' => '4', 'o' => [ '1' => '1', '2' => '2', '3' => '3', '4' => '4', '5' => '5' ] ],
				'dur'   => [ 't' => 'number', 'l' => __( 'Duración de la animación (ms)', 'wakoo' ), 'd' => 1600, 'min' => 200, 'max' => 8000 ],
				'note'  => [ 't' => 'note', 'l' => __( 'Los orígenes de visitas usan el contador propio de Wakoo (sin cookies, respeta "No rastrear"). Mientras esta página tenga el widget se cuentan sus visitas; para contar todo el sitio activa "Estadísticas Wakoo" en el menú del administrador.', 'wakoo' ) ],
			] ],
		];
	}

	protected function draw( array $s ) {
		$rows = array_values( (array) $s['items'] );
		$ctx  = $this->ctx();
		$vals = self::values( $rows, (int) $ctx['post'] );
		$live = false;
		foreach ( $rows as $r ) { if ( 'manual' !== ( $r['source'] ?? 'manual' ) ) { $live = true; } }
		$this->open( [ 'dur' => Sec::int( $s['dur'], 200, 8000 ), 'live' => $live, 'hit' => true ], 'wks-stats--c' . Sec::int( $s['cols'], 1, 5 ) );
		$groups = [];
		foreach ( $rows as $i => $r ) {
			$g = trim( (string) ( $r['group'] ?? '' ) );
			$groups[ $g ][] = $i;
		}
		foreach ( $groups as $g => $idx ) {
			echo '<section class="wks-stats__group">';
			if ( '' !== $g ) { echo '<h3 class="wks-group-title">' . esc_html( $g ) . '</h3>'; }
			echo '<ul class="wks-stats__list">';
			foreach ( $idx as $i ) {
				$r   = $rows[ $i ];
				$dec = Sec::int( $r['dec'] ?? 0, 0, 3 );
				$v   = (float) $vals[ $i ];
				echo '<li class="wks-stats__item wks-card" data-i="' . (int) $i . '" data-to="' . esc_attr( $v ) . '" data-dec="' . $dec . '">';
				echo '<span class="wks-stats__num"><span class="wks-stats__pre">' . esc_html( $r['prefix'] ?? '' ) . '</span><b class="wks-stats__n">' . esc_html( number_format_i18n( $v, $dec ) ) . '</b><span class="wks-stats__suf">' . esc_html( $r['suffix'] ?? '' ) . '</span></span>';
				echo '<span class="wks-stats__label">' . esc_html( $r['label'] ?? '' ) . '</span></li>';
			}
			echo '</ul></section>';
		}
		$this->close();
	}

	/* ------------------------------------------------------------ data */

	private static function conf( $post, $w ) {
		$s = Data::widget( $post, $w, 'wakoo-stats' );
		if ( null === $s ) { return null; }
		$wt = \Elementor\Plugin::$instance->widgets_manager->get_widget_types( 'wakoo-stats' );
		if ( $wt ) {
			foreach ( $wt->get_controls() as $id => $c ) {
				if ( ! isset( $s[ $id ] ) && isset( $c['default'] ) ) { $s[ $id ] = $c['default']; }
			}
		}
		return $s;
	}

	/** Path ("/slug/") used to aggregate hits of a post. */
	private static function path_of( $post ) {
		$u = $post ? get_permalink( $post ) : '';
		$p = $u ? (string) wp_parse_url( $u, PHP_URL_PATH ) : '/';
		$h = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		if ( '' !== $h && '/' !== $h && 0 === strpos( $p, rtrim( $h, '/' ) . '/' ) ) { $p = '/' . ltrim( substr( $p, strlen( rtrim( $h, '/' ) ) ), '/' ); }
		return self::norm( $p );
	}

	private static function norm( $p ) {
		$p = '/' . ltrim( (string) $p, '/' );
		$p = preg_replace( '#/+#', '/', $p );
		$p = preg_replace( '#[^A-Za-z0-9/_\-.~%]#', '', $p );
		return substr( $p, 0, 190 );
	}

	/** Numbers for each row. Cached 60 s so a busy page does not run the aggregates on every view. */
	public static function values( array $rows, $post ) {
		global $wpdb;
		$t   = $wpdb->prefix . 'wakoo_hits';
		$key = 'wks_stv_' . (int) $post . '_' . gmdate( 'YmdHi' );
		$c   = get_transient( $key );
		if ( ! is_array( $c ) ) {
			$c = [];
			// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$c['total'] = (int) $wpdb->get_var( "SELECT COALESCE(SUM(views),0) FROM {$t}" );
			$c['today'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(views),0) FROM {$t} WHERE day=%s", Data::today() ) );
			$c['page']  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(views),0) FROM {$t} WHERE path=%s", self::path_of( $post ) ) );
			// phpcs:enable
			$cnt        = wp_count_posts( 'post' );
			$c['posts'] = (int) ( $cnt->publish ?? 0 );
			set_transient( $key, $c, 60 );
		}
		$out = [];
		foreach ( $rows as $i => $r ) {
			$src = $r['source'] ?? 'manual';
			$out[ $i ] = isset( $c[ $src ] ) ? $c[ $src ] : (float) ( $r['number'] ?? 0 );
		}
		return $out;
	}

	/* ------------------------------------------------------------ hooks */

	public static function boot() {
		add_action( 'wp_footer', [ __CLASS__, 'footer_beacon' ], 99 );
		add_action( 'admin_menu', [ __CLASS__, 'menu' ], 25 );
	}

	/** Site-wide beacon when the option is on (the widget's own JS sends it on pages that have the widget). */
	public static function footer_beacon() {
		if ( ! get_option( self::OPT ) || is_admin() || is_preview() || is_customize_preview() ) { return; }
		if ( is_user_logged_in() && current_user_can( 'edit_posts' ) ) { return; }
		$url = esc_url_raw( rest_url( 'wakoo/v1/s/stats/hit' ) );
		echo '<script id="wakoo-hit">(function(){try{if(window.__wksHit||navigator.doNotTrack==="1"||window.doNotTrack==="1"||navigator.webdriver||/bot|crawl|spider|slurp|headless/i.test(navigator.userAgent))return;window.__wksHit=1;var b=JSON.stringify({p:location.pathname});if(navigator.sendBeacon){navigator.sendBeacon(' . wp_json_encode( $url ) . ',new Blob([b],{type:"application/json"}));}else{fetch(' . wp_json_encode( $url ) . ',{method:"POST",body:b,headers:{"Content-Type":"application/json"},credentials:"omit",keepalive:true});}}catch(e){}})();</script>' . "\n"; // phpcs:ignore
	}

	public static function menu() {
		add_submenu_page( 'wakoo-seo', __( 'Estadísticas Wakoo', 'wakoo' ), __( 'Estadísticas Wakoo', 'wakoo' ), 'manage_options', 'wakoo-stats', [ __CLASS__, 'page' ] );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) { return; }
		global $wpdb;
		$t = $wpdb->prefix . 'wakoo_hits';
		if ( isset( $_POST['wks_stats_save'] ) ) {
			check_admin_referer( 'wks_stats_save' );
			update_option( self::OPT, ! empty( $_POST['track'] ) ? 1 : 0, false );
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Guardado.', 'wakoo' ) . '</p></div>';
		}
		$from = gmdate( 'Y-m-d', strtotime( '-29 days', current_time( 'timestamp', true ) ) );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$days = $wpdb->get_results( $wpdb->prepare( "SELECT day, SUM(views) v FROM {$t} WHERE day>=%s GROUP BY day ORDER BY day DESC", $from ) );
		$top  = $wpdb->get_results( $wpdb->prepare( "SELECT path, SUM(views) v FROM {$t} WHERE day>=%s GROUP BY path ORDER BY v DESC LIMIT 20", $from ) );
		// phpcs:enable
		$sum  = 0; foreach ( $days as $d ) { $sum += (int) $d->v; }
		echo '<div class="wrap"><h1>' . esc_html__( 'Estadísticas Wakoo', 'wakoo' ) . '</h1>';
		echo '<form method="post">'; wp_nonce_field( 'wks_stats_save' );
		echo '<p><label><input type="checkbox" name="track" value="1" ' . checked( (bool) get_option( self::OPT ), true, false ) . '> ' . esc_html__( 'Contar las visitas de todo el sitio (sin cookies, respeta "No rastrear", ignora bots y administradores)', 'wakoo' ) . '</label></p>';
		echo '<p><button class="button button-primary" name="wks_stats_save" value="1">' . esc_html__( 'Guardar', 'wakoo' ) . '</button></p></form>';
		echo '<h2>' . esc_html__( 'Últimos 30 días', 'wakoo' ) . ' — ' . (int) $sum . '</h2>';
		echo '<table class="widefat striped" style="max-width:520px"><thead><tr><th>' . esc_html__( 'Día', 'wakoo' ) . '</th><th>' . esc_html__( 'Visitas', 'wakoo' ) . '</th></tr></thead><tbody>';
		if ( ! $days ) { echo '<tr><td colspan="2">' . esc_html__( 'Aún no hay datos.', 'wakoo' ) . '</td></tr>'; }
		foreach ( $days as $d ) { echo '<tr><td>' . esc_html( $d->day ) . '</td><td>' . (int) $d->v . '</td></tr>'; }
		echo '</tbody></table>';
		echo '<h2>' . esc_html__( 'Páginas más vistas', 'wakoo' ) . '</h2>';
		echo '<table class="widefat striped" style="max-width:720px"><thead><tr><th>' . esc_html__( 'Página', 'wakoo' ) . '</th><th>' . esc_html__( 'Visitas', 'wakoo' ) . '</th></tr></thead><tbody>';
		if ( ! $top ) { echo '<tr><td colspan="2">' . esc_html__( 'Aún no hay datos.', 'wakoo' ) . '</td></tr>'; }
		foreach ( $top as $r ) { echo '<tr><td>' . esc_html( $r->path ) . '</td><td>' . (int) $r->v . '</td></tr>'; }
		echo '</tbody></table></div>';
	}

	public static function routes() {
		// Values of the live counters (public, validated against the saved widget).
		Sec::route( 'stats/values', 'GET', static function ( \WP_REST_Request $r ) {
			$post = Sec::int( $r->get_param( 'post' ), 0 );
			$w    = Sec::text( $r->get_param( 'w' ), 32 );
			$s    = self::conf( $post, $w );
			if ( ! $s ) { return Sec::err( 'No encontrado', 404 ); }
			if ( ! Sec::rate( 'stats-val', 60, 600 ) ) { return Sec::err( 'Demasiadas peticiones', 429 ); }
			return Sec::ok( [ 'values' => array_map( 'floatval', self::values( array_values( (array) $s['items'] ), $post ) ) ] );
		} );

		// Page-view beacon: no cookies, no IP stored, aggregated per day + path.
		Sec::route( 'stats/hit', 'POST', static function ( \WP_REST_Request $r ) {
			global $wpdb;
			$dnt = isset( $_SERVER['HTTP_DNT'] ) && '1' === $_SERVER['HTTP_DNT']; // phpcs:ignore
			$ua  = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : ''; // phpcs:ignore
			if ( $dnt || '' === $ua || preg_match( '/bot|crawl|spider|slurp|headless|curl|wget|python|java\b|monitor|preview/i', $ua ) ) {
				return new \WP_REST_Response( null, 204 );
			}
			if ( is_user_logged_in() && current_user_can( 'edit_posts' ) ) { return new \WP_REST_Response( null, 204 ); }
			if ( ! Sec::rate( 'stats-hit', 60, 600 ) ) { return new \WP_REST_Response( null, 204 ); }
			$p = self::norm( wp_parse_url( '/' . ltrim( (string) $r->get_param( 'p' ), '/' ), PHP_URL_PATH ) );
			if ( '' === $p ) { $p = '/'; }
			$t   = $wpdb->prefix . 'wakoo_hits';
			$day = Data::today();
			// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			// Limit distinct paths per day so a flood of made-up URLs cannot bloat the table.
			$known = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE day=%s AND path=%s", $day, $p ) );
			if ( ! $known ) {
				$n = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE day=%s", $day ) );
				if ( $n >= 1500 ) { $p = '/(otros)'; }
			}
			$wpdb->query( $wpdb->prepare( "INSERT INTO {$t} (day,path,views) VALUES (%s,%s,1) ON DUPLICATE KEY UPDATE views=views+1", $day, $p ) );
			// phpcs:enable
			return new \WP_REST_Response( null, 204 );
		} );
	}
}
