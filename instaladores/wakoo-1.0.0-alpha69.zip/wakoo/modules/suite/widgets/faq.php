<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;

defined( 'ABSPATH' ) || die();

/** 9. Acordeón de preguntas con búsqueda, agrupado por categorías. */
class Faq extends Base {

	public function slug() { return 'faq'; }
	public function label() { return __( 'Preguntas frecuentes', 'wakoo' ); }
	public function icon() { return 'eicon-accordion'; }
	public function words() { return [ 'faq', 'acordeon', 'preguntas', 'accordion' ]; }

	protected function sections() {
		return [
			[ 'id' => 'sec_items', 'label' => __( 'Preguntas', 'wakoo' ), 'controls' => [
				'items' => [ 't' => 'repeater', 'title' => '{{{ q }}}', 'fields' => [
					'group' => [ 't' => 'text', 'l' => __( 'Categoría', 'wakoo' ), 'd' => __( 'General', 'wakoo' ) ],
					'q'     => [ 't' => 'text', 'l' => __( 'Pregunta', 'wakoo' ), 'd' => __( '¿Pregunta?', 'wakoo' ) ],
					'a'     => [ 't' => 'wysiwyg', 'l' => __( 'Respuesta', 'wakoo' ), 'd' => __( 'Respuesta.', 'wakoo' ) ],
				], 'd' => [
					[ 'group' => __( 'General', 'wakoo' ), 'q' => __( '¿Cómo funciona?', 'wakoo' ), 'a' => __( 'Explícalo aquí.', 'wakoo' ) ],
					[ 'group' => __( 'Pagos', 'wakoo' ), 'q' => __( '¿Qué métodos de pago aceptan?', 'wakoo' ), 'a' => __( 'Detalla los métodos.', 'wakoo' ) ],
				] ],
			] ],
			[ 'id' => 'sec_opts', 'label' => __( 'Opciones', 'wakoo' ), 'controls' => [
				'search'    => [ 't' => 'switch', 'l' => __( 'Mostrar buscador', 'wakoo' ), 'd' => 'yes' ],
				'ph'        => [ 't' => 'text', 'l' => __( 'Texto del buscador', 'wakoo' ), 'd' => __( 'Buscar una pregunta…', 'wakoo' ), 'c' => [ 'search' => 'yes' ] ],
				'tabs'      => [ 't' => 'switch', 'l' => __( 'Botones de categoría', 'wakoo' ), 'd' => 'yes' ],
				'all'       => [ 't' => 'text', 'l' => __( 'Texto de "Todas"', 'wakoo' ), 'd' => __( 'Todas', 'wakoo' ), 'c' => [ 'tabs' => 'yes' ] ],
				'multi'     => [ 't' => 'switch', 'l' => __( 'Permitir varias abiertas', 'wakoo' ) ],
				'empty'     => [ 't' => 'text', 'l' => __( 'Mensaje sin resultados', 'wakoo' ), 'd' => __( 'No hay resultados.', 'wakoo' ) ],
				'schema'    => [ 't' => 'switch', 'l' => __( 'Datos estructurados para Google (FAQPage)', 'wakoo' ), 'd' => 'yes' ],
			] ],
		];
	}

	protected function draw( array $s ) {
		$items  = (array) ( $s['items'] ?? [] );
		$groups = $this->group_rows( $items, 'group', __( 'General', 'wakoo' ) );
		$this->open( [ 'multi' => 'yes' === $s['multi'], 'empty' => (string) $s['empty'] ] );

		if ( 'yes' === $s['search'] ) {
			echo '<div class="wks-field"><input type="search" class="wks-faq__search" placeholder="' . esc_attr( $s['ph'] ) . '" aria-label="' . esc_attr( $s['ph'] ) . '"></div>';
		}
		if ( 'yes' === $s['tabs'] && count( $groups ) > 1 ) {
			echo '<div class="wks-faq__tabs" role="group">';
			echo '<button type="button" class="wks-chip is-active" data-g="*">' . esc_html( $s['all'] ) . '</button>';
			foreach ( array_keys( $groups ) as $i => $g ) {
				echo '<button type="button" class="wks-chip" data-g="' . esc_attr( 'g' . $i ) . '">' . esc_html( $g ) . '</button>';
			}
			echo '</div>';
		}
		$n = 0;
		$schema = [];
		foreach ( array_values( $groups ) as $gi => $rows ) {
			$title = array_keys( $groups )[ $gi ];
			echo '<section class="wks-faq__group" data-g="g' . (int) $gi . '"><h3 class="wks-group-title">' . esc_html( $title ) . '</h3>';
			foreach ( $rows as $r ) {
				$id  = 'wks-faq-' . esc_attr( $this->get_id() ) . '-' . ( ++$n );
				$ans = wp_kses_post( $r['a'] ?? '' );
				$schema[] = [ '@type' => 'Question', 'name' => wp_strip_all_tags( $r['q'] ?? '' ), 'acceptedAnswer' => [ '@type' => 'Answer', 'text' => wp_strip_all_tags( $ans ) ] ];
				echo '<div class="wks-faq__item wks-card">';
				echo '<h4 class="wks-faq__q"><button type="button" aria-expanded="false" aria-controls="' . $id . '">' . esc_html( $r['q'] ?? '' ) . '<span class="wks-faq__ico" aria-hidden="true"></span></button></h4>';
				echo '<div class="wks-faq__a" id="' . $id . '" hidden>' . $ans . '</div>'; // phpcs:ignore
				echo '</div>';
			}
			echo '</section>';
		}
		echo '<p class="wks-faq__none" hidden>' . esc_html( $s['empty'] ) . '</p>';
		$this->close();

		if ( 'yes' === $s['schema'] && $schema ) {
			echo '<script type="application/ld+json">' . wp_json_encode( [ '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $schema ], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) . '</script>';
		}
	}
}
