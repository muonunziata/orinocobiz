<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;

defined( 'ABSPATH' ) || die();

/** 7. Visor 360° y zoom de imagen, con escenas agrupadas. */
class Viewer360 extends Base {

	public function slug() { return 'viewer360'; }
	public function label() { return __( 'Visor 360° y zoom', 'wakoo' ); }
	public function cat() { return 'media'; }
	public function icon() { return 'eicon-3d-cube'; }
	public function words() { return [ '360', 'zoom', 'visor', 'producto', 'inmueble', 'rotar' ]; }

	private static function demo( $f ) { return [ 'url' => WAKOO_MODULES_URL . 'suite/assets/demo/' . $f, 'id' => 0 ]; }

	protected function sections() {
		$frames = [];
		for ( $i = 1; $i <= 12; $i++ ) { $frames[] = self::demo( sprintf( 'spin-%02d.svg', $i ) ); }
		return [
			[ 'id' => 'sec_scenes', 'label' => __( 'Escenas', 'wakoo' ), 'controls' => [
				'scenes' => [ 't' => 'repeater', 'title' => '{{{ title }}} ({{{ mode }}})', 'fields' => [
					'group'  => [ 't' => 'text', 'l' => __( 'Grupo (p. ej. habitación, producto)', 'wakoo' ), 'd' => '' ],
					'title'  => [ 't' => 'text', 'l' => __( 'Título', 'wakoo' ), 'd' => __( 'Escena', 'wakoo' ) ],
					'mode'   => [ 't' => 'select', 'l' => __( 'Modo', 'wakoo' ), 'd' => '360', 'o' => [ '360' => __( '360° (secuencia de fotos)', 'wakoo' ), 'zoom' => __( 'Zoom de una imagen', 'wakoo' ) ] ],
					'frames' => [ 't' => 'gallery', 'l' => __( 'Fotos de la secuencia (en orden)', 'wakoo' ), 'c' => [ 'mode' => '360' ] ],
					'image'  => [ 't' => 'media', 'l' => __( 'Imagen de alta resolución', 'wakoo' ), 'c' => [ 'mode' => 'zoom' ] ],
				], 'd' => [
					[ 'group' => __( 'Producto', 'wakoo' ), 'title' => __( 'Vista 360°', 'wakoo' ), 'mode' => '360', 'frames' => $frames ],
					[ 'group' => __( 'Producto', 'wakoo' ), 'title' => __( 'Detalle con zoom', 'wakoo' ), 'mode' => 'zoom', 'image' => self::demo( 'zoom.svg' ) ],
				] ],
			] ],
			[ 'id' => 'sec_opts', 'label' => __( 'Opciones', 'wakoo' ), 'controls' => [
				'autoplay' => [ 't' => 'switch', 'l' => __( 'Giro automático (360°)', 'wakoo' ), 'd' => 'yes' ],
				'speed'    => [ 't' => 'number', 'l' => __( 'Milisegundos por foto', 'wakoo' ), 'd' => 120, 'min' => 40, 'max' => 1000, 'c' => [ 'autoplay' => 'yes' ] ],
				'maxzoom'  => [ 't' => 'number', 'l' => __( 'Zoom máximo (×)', 'wakoo' ), 'd' => 5, 'min' => 2, 'max' => 12 ],
				'height'   => [ 't' => 'number', 'l' => __( 'Alto del visor (px)', 'wakoo' ), 'd' => 420, 'min' => 200, 'max' => 900, 'sel' => [ '{{WRAPPER}} .wks-v__stage' => 'height: {{VALUE}}px;' ] ],
				'hint360'  => [ 't' => 'text', 'l' => __( 'Ayuda 360°', 'wakoo' ), 'd' => __( 'Arrastra para girar', 'wakoo' ) ],
				'hintzoom' => [ 't' => 'text', 'l' => __( 'Ayuda zoom', 'wakoo' ), 'd' => __( 'Rueda o pellizca para ampliar; doble clic para acercar', 'wakoo' ) ],
			] ],
		];
	}

	protected function draw( array $s ) {
		$scenes = [];
		foreach ( (array) ( $s['scenes'] ?? [] ) as $sc ) {
			$mode = 'zoom' === ( $sc['mode'] ?? '' ) ? 'zoom' : '360';
			if ( 'zoom' === $mode ) {
				$u = $this->img( $sc['image'] ?? [] );
				if ( ! $u ) { continue; }
				$sc['urls'] = [ $u ];
			} else {
				$urls = [];
				foreach ( (array) ( $sc['frames'] ?? [] ) as $f ) { $u = $this->img( $f ); if ( $u ) { $urls[] = $u; } }
				if ( count( $urls ) < 2 ) { continue; }
				$sc['urls'] = $urls;
			}
			$sc['mode'] = $mode;
			$scenes[]   = $sc;
		}
		if ( ! $scenes ) { echo '<p>' . esc_html__( 'Añade al menos una escena.', 'wakoo' ) . '</p>'; return; }
		$this->open( [
			'autoplay' => 'yes' === $s['autoplay'], 'speed' => (int) $s['speed'], 'maxzoom' => (int) $s['maxzoom'],
		] );
		if ( count( $scenes ) > 1 ) {
			echo '<div class="wks-v__tabs" role="tablist">';
			$last = null;
			foreach ( $scenes as $i => $sc ) {
				$g = trim( (string) ( $sc['group'] ?? '' ) );
				if ( '' !== $g && $g !== $last ) { echo '<span class="wks-v__grp">' . esc_html( $g ) . '</span>'; }
				$last = $g;
				echo '<button type="button" role="tab" class="wks-chip' . ( 0 === $i ? ' is-active' : '' ) . '" data-i="' . (int) $i . '" aria-selected="' . ( 0 === $i ? 'true' : 'false' ) . '">' . esc_html( $sc['title'] ?? '' ) . '</button>';
			}
			echo '</div>';
		}
		foreach ( $scenes as $i => $sc ) {
			$hint = 'zoom' === $sc['mode'] ? $s['hintzoom'] : $s['hint360'];
			echo '<div class="wks-v__scene" role="tabpanel" data-mode="' . esc_attr( $sc['mode'] ) . '" data-urls="' . esc_attr( wp_json_encode( $sc['urls'] ) ) . '"' . ( 0 === $i ? '' : ' hidden' ) . '>';
			echo '<div class="wks-v__stage" tabindex="0" aria-label="' . esc_attr( $sc['title'] ?? '' ) . '"><img class="wks-v__img" alt="' . esc_attr( $sc['title'] ?? '' ) . '" draggable="false"></div>';
			echo '<div class="wks-v__bar"><span class="wks-v__hint">' . esc_html( $hint ) . '</span><span class="wks-v__tools">';
			if ( 'zoom' === $sc['mode'] ) {
				echo '<button type="button" class="wks-chip" data-act="out" aria-label="' . esc_attr__( 'Alejar', 'wakoo' ) . '">&minus;</button><button type="button" class="wks-chip" data-act="in" aria-label="' . esc_attr__( 'Acercar', 'wakoo' ) . '">+</button><button type="button" class="wks-chip" data-act="reset">' . esc_html__( 'Restablecer', 'wakoo' ) . '</button>';
			} else {
				echo '<button type="button" class="wks-chip" data-act="toggle">' . esc_html__( 'Girar / pausar', 'wakoo' ) . '</button>';
			}
			echo '<button type="button" class="wks-chip" data-act="full">' . esc_html__( 'Pantalla completa', 'wakoo' ) . '</button></span></div>';
			echo '</div>';
		}
		$this->close();
	}
}
