<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;
use Wakoo\Modules\Suite\Data;
use Wakoo\Modules\Suite\Sec;

defined( 'ABSPATH' ) || die();

/**
 * Directorio profesional: buscador instantáneo con resaltado, filtros facetados (categoría, etiquetas, zona, «abierto ahora»
 * con zona horaria configurable), orden, vista cuadrícula/lista, paginación o «cargar más», estado en la URL opcional y ficha
 * emergente accesible (galería con miniaturas, contacto, horario). Datos estructurados LocalBusiness opcionales.
 *
 * Origen de datos: repetidor (hasta 300 negocios, van en la página) o archivo CSV de la biblioteca (hasta 3000 filas,
 * se sirven por REST paginado con filtros en el servidor y caché).
 */
class Directory extends Base {

	const MAX     = 300;
	const CSV_MAX = 3000;
	const CSV_BYTES = 1048576;

	public function slug() { return 'directory'; }
	public function label() { return __( 'Directorio con buscador y ficha', 'wakoo' ); }
	public function cat() { return 'data'; }
	public function icon() { return 'eicon-search-results'; }
	public function words() { return [ 'directorio', 'negocios', 'buscador', 'ficha', 'localbusiness', 'guia', 'listado' ]; }

	private static function demo( $f ) { return [ 'url' => WAKOO_MODULES_URL . 'suite/assets/demo/' . $f, 'id' => 0 ]; }

	protected function sections() {
		$ex = function ( $n, $cat, $type, $photo ) {
			return [
				'name' => sprintf( __( 'Negocio de ejemplo %d', 'wakoo' ), $n ), 'category' => $cat, 'type' => $type, 'area' => __( 'Tu ciudad', 'wakoo' ),
				'desc' => __( 'Descripción de ejemplo. Cuenta qué ofrece el negocio, desde cuándo atiende y por qué lo eligen los vecinos.', 'wakoo' ),
				'address' => __( 'Calle Ejemplo 1', 'wakoo' ), 'phone' => '+34 600 000 00' . $n, 'hours' => "Lun – Vie|8:00 – 17:00\nSáb|9:00 – 13:00",
				'tags' => $type, 'logo' => self::demo( 'avatar-' . ( ( $n % 3 ) + 1 ) . '.svg' ), 'rating' => 4.5, 'reviews' => 10 + $n,
			];
		};
		$cats = [
			[ 'name' => __( 'Restauración', 'wakoo' ), 'color' => '#CC7A3A' ],
			[ 'name' => __( 'Servicios', 'wakoo' ), 'color' => '#2B5BA8' ],
			[ 'name' => __( 'Comercio', 'wakoo' ), 'color' => '#7A4A9A' ],
			[ 'name' => __( 'Salud', 'wakoo' ), 'color' => '#2E7D55' ],
		];
		return [
			[ 'id' => 'sec_text', 'label' => __( 'Textos', 'wakoo' ), 'controls' => [
				'label'       => [ 't' => 'text', 'l' => __( 'Rótulo', 'wakoo' ), 'd' => __( 'Guía local', 'wakoo' ) ],
				'title'       => [ 't' => 'text', 'l' => __( 'Título', 'wakoo' ), 'd' => __( 'Encuentra un negocio', 'wakoo' ) ],
				'placeholder' => [ 't' => 'text', 'l' => __( 'Texto del buscador', 'wakoo' ), 'd' => __( 'Busca un negocio o categoría: fontanero, restaurante, dentista…', 'wakoo' ) ],
				'all_label'   => [ 't' => 'text', 'l' => __( 'Filtro «todas las categorías»', 'wakoo' ), 'd' => __( 'Todas', 'wakoo' ) ],
				'show_all'    => [ 't' => 'switch', 'l' => __( 'Mostrar todos los negocios antes de buscar', 'wakoo' ), 'd' => 'yes' ],
			] ],
			[ 'id' => 'sec_view', 'label' => __( 'Filtros, orden y vista', 'wakoo' ), 'controls' => [
				'show_tags'  => [ 't' => 'switch', 'l' => __( 'Filtro por etiquetas', 'wakoo' ), 'd' => 'yes' ],
				'show_areas' => [ 't' => 'switch', 'l' => __( 'Filtro por zona', 'wakoo' ), 'd' => 'yes' ],
				'show_open'  => [ 't' => 'switch', 'l' => __( 'Filtro «abierto ahora» (solo si hay horarios)', 'wakoo' ), 'd' => 'yes' ],
				'tz'         => [ 't' => 'text', 'l' => __( 'Zona horaria (p. ej. Europe/Madrid; vacío = la del sitio)', 'wakoo' ), 'd' => '', 'c' => [ 'show_open' => 'yes' ] ],
				'show_sort'  => [ 't' => 'switch', 'l' => __( 'Selector de orden', 'wakoo' ), 'd' => 'yes' ],
				'sort'       => [ 't' => 'select', 'l' => __( 'Orden inicial', 'wakoo' ), 'd' => 'original', 'o' => [
					'original' => __( 'Como los escribes', 'wakoo' ), 'az' => __( 'Nombre A–Z', 'wakoo' ), 'za' => __( 'Nombre Z–A', 'wakoo' ),
					'rating' => __( 'Mejor puntuación', 'wakoo' ), 'reviews' => __( 'Más opiniones', 'wakoo' ), 'featured' => __( 'Destacados primero', 'wakoo' ),
				] ],
				'show_view'  => [ 't' => 'switch', 'l' => __( 'Botones cuadrícula / lista', 'wakoo' ), 'd' => 'yes' ],
				'view'       => [ 't' => 'select', 'l' => __( 'Vista inicial', 'wakoo' ), 'd' => 'grid', 'o' => [ 'grid' => __( 'Cuadrícula', 'wakoo' ), 'list' => __( 'Lista', 'wakoo' ) ] ],
				'per_page'   => [ 't' => 'number', 'l' => __( 'Negocios por página', 'wakoo' ), 'd' => 12, 'min' => 4, 'max' => 48 ],
				'pager'      => [ 't' => 'select', 'l' => __( 'Paginación', 'wakoo' ), 'd' => 'more', 'o' => [ 'more' => __( 'Botón «Cargar más»', 'wakoo' ), 'pages' => __( 'Páginas numeradas', 'wakoo' ) ] ],
				'url_state'  => [ 't' => 'switch', 'l' => __( 'Guardar búsqueda y filtros en la URL (para compartir; un solo directorio por página)', 'wakoo' ), 'd' => '' ],
				'map_btn'    => [ 't' => 'switch', 'l' => __( 'Botón «ver en el mapa» (solo enlace, sin API)', 'wakoo' ), 'd' => '' ],
			] ],
			[ 'id' => 'sec_source', 'label' => __( 'Origen de los datos', 'wakoo' ), 'controls' => [
				'source'   => [ 't' => 'select', 'l' => __( 'Origen', 'wakoo' ), 'd' => 'repeater', 'o' => [ 'repeater' => __( 'Lista editable (hasta 300)', 'wakoo' ), 'csv' => __( 'Archivo CSV de la biblioteca (hasta 3000)', 'wakoo' ) ] ],
				'csv_file' => [ 't' => 'media', 'l' => __( 'Archivo CSV', 'wakoo' ), 'c' => [ 'source' => 'csv' ], 'desc' => __( 'Sube un .csv (máx. 1 MB, solo administradores). Primera fila = encabezados: nombre, categoria, tipo, zona, logo, fotos, descripcion, direccion, mapa, telefono, correo, web, horario, etiquetas, puntuacion, opiniones, destacado, redes. En «fotos» separa las URL con «;», en «horario» cada tramo con «;» (Lun – Vie|8:00 – 17:00) y en «redes» usa etiqueta|url separadas por «;». Las categorías nuevas se crean solas.', 'wakoo' ) ],
			] ],
			[ 'id' => 'sec_cats', 'label' => __( 'Categorías', 'wakoo' ), 'controls' => [
				'edit_cats' => [ 't' => 'editor_btn', 'target' => 'cats', 'mode' => 'cards', 'l' => __( 'Abrir editor de categorías', 'wakoo' ) ],
				'cats' => [ 't' => 'repeater', 'title' => '{{{ name }}}', 'fields' => [
					'name'  => [ 't' => 'text', 'l' => __( 'Nombre', 'wakoo' ), 'd' => '' ],
					'color' => [ 't' => 'color', 'l' => __( 'Color', 'wakoo' ) ],
				], 'd' => $cats ],
			] ],
			[ 'id' => 'sec_list', 'label' => __( 'Negocios (lista editable, máx. 300)', 'wakoo' ), 'controls' => [
				'edit_list' => [ 't' => 'editor_btn', 'target' => 'listings', 'mode' => 'grid', 'l' => __( 'Abrir editor de negocios (hoja)', 'wakoo' ) ],
				'listings' => [ 't' => 'repeater', 'title' => '{{{ name }}}', 'fields' => [
					'name'     => [ 't' => 'text', 'l' => __( 'Nombre', 'wakoo' ), 'd' => '' ],
					'category' => [ 't' => 'text', 'l' => __( 'Categoría (igual que arriba)', 'wakoo' ), 'd' => '' ],
					'type'     => [ 't' => 'text', 'l' => __( 'Tipo (p. ej. fontanero)', 'wakoo' ), 'd' => '' ],
					'area'     => [ 't' => 'text', 'l' => __( 'Zona', 'wakoo' ), 'd' => '' ],
					'logo'     => [ 't' => 'media', 'l' => __( 'Logo', 'wakoo' ) ],
					'photos'   => [ 't' => 'gallery', 'l' => __( 'Galería de fotos', 'wakoo' ) ],
					'desc'     => [ 't' => 'textarea', 'l' => __( 'Descripción', 'wakoo' ), 'd' => '' ],
					'address'  => [ 't' => 'text', 'l' => __( 'Dirección', 'wakoo' ), 'd' => '' ],
					'maps_url' => [ 't' => 'url', 'l' => __( 'Enlace de mapa propio (opcional)', 'wakoo' ) ],
					'phone'    => [ 't' => 'text', 'l' => __( 'Teléfono', 'wakoo' ), 'd' => '' ],
					'email'    => [ 't' => 'text', 'l' => __( 'Correo', 'wakoo' ), 'd' => '' ],
					'web'      => [ 't' => 'url', 'l' => __( 'Sitio web', 'wakoo' ) ],
					'hours'    => [ 't' => 'textarea', 'l' => __( 'Horario (una línea por tramo: Lun – Vie|8:00 – 17:00)', 'wakoo' ), 'd' => '' ],
					'tags'     => [ 't' => 'text', 'l' => __( 'Etiquetas (separadas por coma)', 'wakoo' ), 'd' => '' ],
					'rating'   => [ 't' => 'number', 'l' => __( 'Puntuación (0–5)', 'wakoo' ), 'min' => 0, 'max' => 5, 'step' => 0.1 ],
					'reviews'  => [ 't' => 'number', 'l' => __( 'Número de opiniones', 'wakoo' ), 'min' => 0, 'max' => 1000000 ],
					'featured' => [ 't' => 'switch', 'l' => __( 'Destacado (insignia)', 'wakoo' ), 'd' => '' ],
					'social'   => [ 't' => 'textarea', 'l' => __( 'Redes (una por línea: etiqueta|url)', 'wakoo' ), 'd' => '' ],
				], 'd' => [
					$ex( 1, __( 'Restauración', 'wakoo' ), __( 'Restaurante', 'wakoo' ), 1 ),
					$ex( 2, __( 'Servicios', 'wakoo' ), __( 'Fontanero', 'wakoo' ), 2 ),
					$ex( 3, __( 'Comercio', 'wakoo' ), __( 'Librería', 'wakoo' ), 3 ),
					$ex( 4, __( 'Salud', 'wakoo' ), __( 'Dentista', 'wakoo' ), 4 ),
					$ex( 5, __( 'Servicios', 'wakoo' ), __( 'Electricista', 'wakoo' ), 5 ),
					$ex( 6, __( 'Restauración', 'wakoo' ), __( 'Cafetería', 'wakoo' ), 6 ),
				] ],
				'sample_note' => [ 't' => 'textarea', 'l' => __( 'Aviso en la ficha (vacío = ocultar)', 'wakoo' ), 'd' => '' ],
			] ],
			[ 'id' => 'sec_labels', 'label' => __( 'Textos de la ficha y mensajes', 'wakoo' ), 'controls' => [
				'lbl_none_t' => [ 't' => 'text', 'l' => __( 'Sin resultados: título', 'wakoo' ), 'd' => __( 'No se encontró ningún negocio', 'wakoo' ) ],
				'lbl_none_d' => [ 't' => 'text', 'l' => __( 'Sin resultados: ayuda', 'wakoo' ), 'd' => __( 'Prueba con una palabra más general o elige «Todas».', 'wakoo' ) ],
				'lbl_count'  => [ 't' => 'text', 'l' => __( 'Contador (usa {n} para el número)', 'wakoo' ), 'd' => __( 'Resultados: {n}', 'wakoo' ) ],
				'lbl_clear'  => [ 't' => 'text', 'l' => __( 'Borrar búsqueda', 'wakoo' ), 'd' => __( 'Borrar búsqueda', 'wakoo' ) ],
				'lbl_open'   => [ 't' => 'text', 'l' => __( 'Ver ficha (lectores de pantalla)', 'wakoo' ), 'd' => __( 'Ver ficha', 'wakoo' ) ],
				'lbl_maps'   => [ 't' => 'text', 'l' => __( 'Botón «Ver en el mapa»', 'wakoo' ), 'd' => __( 'Ver en el mapa', 'wakoo' ) ],
				'lbl_dir'    => [ 't' => 'text', 'l' => __( 'Botón «Cómo llegar»', 'wakoo' ), 'd' => __( 'Cómo llegar', 'wakoo' ) ],
				'lbl_call'   => [ 't' => 'text', 'l' => __( 'Botón «Llamar»', 'wakoo' ), 'd' => __( 'Llamar', 'wakoo' ) ],
				'lbl_web'    => [ 't' => 'text', 'l' => __( 'Botón «Sitio web»', 'wakoo' ), 'd' => __( 'Sitio web', 'wakoo' ) ],
				'lbl_address' => [ 't' => 'text', 'l' => __( 'Rótulo «Dirección»', 'wakoo' ), 'd' => __( 'Dirección', 'wakoo' ) ],
				'lbl_phone'  => [ 't' => 'text', 'l' => __( 'Rótulo «Teléfono»', 'wakoo' ), 'd' => __( 'Teléfono', 'wakoo' ) ],
				'lbl_email'  => [ 't' => 'text', 'l' => __( 'Rótulo «Correo»', 'wakoo' ), 'd' => __( 'Correo', 'wakoo' ) ],
				'lbl_hours'  => [ 't' => 'text', 'l' => __( 'Rótulo «Horario»', 'wakoo' ), 'd' => __( 'Horario', 'wakoo' ) ],
				'lbl_found'  => [ 't' => 'text', 'l' => __( 'Insignia de destacado', 'wakoo' ), 'd' => __( 'Destacado', 'wakoo' ) ],
				'lbl_photo'  => [ 't' => 'text', 'l' => __( 'Palabra «Foto»', 'wakoo' ), 'd' => __( 'Foto', 'wakoo' ) ],
				'lbl_prev'   => [ 't' => 'text', 'l' => __( 'Foto anterior', 'wakoo' ), 'd' => __( 'Foto anterior', 'wakoo' ) ],
				'lbl_next'   => [ 't' => 'text', 'l' => __( 'Foto siguiente', 'wakoo' ), 'd' => __( 'Foto siguiente', 'wakoo' ) ],
				'lbl_close'  => [ 't' => 'text', 'l' => __( 'Cerrar', 'wakoo' ), 'd' => __( 'Cerrar', 'wakoo' ) ],
				'lbl_open_now' => [ 't' => 'text', 'l' => __( 'Filtro «abierto ahora»', 'wakoo' ), 'd' => __( 'Abierto ahora', 'wakoo' ) ],
				'lbl_is_open'  => [ 't' => 'text', 'l' => __( 'Insignia «abierto»', 'wakoo' ), 'd' => __( 'Abierto', 'wakoo' ) ],
				'lbl_is_closed' => [ 't' => 'text', 'l' => __( 'Insignia «cerrado»', 'wakoo' ), 'd' => __( 'Cerrado', 'wakoo' ) ],
				'lbl_area'     => [ 't' => 'text', 'l' => __( 'Selector de zona', 'wakoo' ), 'd' => __( 'Zona', 'wakoo' ) ],
				'lbl_all_areas' => [ 't' => 'text', 'l' => __( 'Zona: «todas»', 'wakoo' ), 'd' => __( 'Todas las zonas', 'wakoo' ) ],
				'lbl_tags'     => [ 't' => 'text', 'l' => __( 'Rótulo de etiquetas', 'wakoo' ), 'd' => __( 'Etiquetas', 'wakoo' ) ],
				'lbl_sort'     => [ 't' => 'text', 'l' => __( 'Rótulo de orden', 'wakoo' ), 'd' => __( 'Ordenar por', 'wakoo' ) ],
				'lbl_view_grid' => [ 't' => 'text', 'l' => __( 'Vista cuadrícula', 'wakoo' ), 'd' => __( 'Cuadrícula', 'wakoo' ) ],
				'lbl_view_list' => [ 't' => 'text', 'l' => __( 'Vista lista', 'wakoo' ), 'd' => __( 'Lista', 'wakoo' ) ],
				'lbl_more'     => [ 't' => 'text', 'l' => __( 'Cargar más', 'wakoo' ), 'd' => __( 'Cargar más', 'wakoo' ) ],
				'lbl_page'     => [ 't' => 'text', 'l' => __( 'Página (usa {n})', 'wakoo' ), 'd' => __( 'Página {n}', 'wakoo' ) ],
				'lbl_reset'    => [ 't' => 'text', 'l' => __( 'Quitar filtros', 'wakoo' ), 'd' => __( 'Quitar filtros', 'wakoo' ) ],
				'lbl_map_btn'  => [ 't' => 'text', 'l' => __( 'Botón del mapa', 'wakoo' ), 'd' => __( 'Ver resultados en el mapa', 'wakoo' ) ],
				'lbl_loading'  => [ 't' => 'text', 'l' => __( 'Cargando', 'wakoo' ), 'd' => __( 'Cargando…', 'wakoo' ) ],
				'lbl_error'    => [ 't' => 'text', 'l' => __( 'Error de carga', 'wakoo' ), 'd' => __( 'No se pudo cargar. Inténtalo de nuevo.', 'wakoo' ) ],
				'lbl_featured_only' => [ 't' => 'text', 'l' => __( 'Opción de orden «destacados»', 'wakoo' ), 'd' => __( 'Destacados primero', 'wakoo' ) ],
				'lbl_s_original' => [ 't' => 'text', 'l' => __( 'Orden: relevancia / original', 'wakoo' ), 'd' => __( 'Relevancia', 'wakoo' ) ],
				'lbl_s_az'     => [ 't' => 'text', 'l' => __( 'Orden: A–Z', 'wakoo' ), 'd' => __( 'Nombre A–Z', 'wakoo' ) ],
				'lbl_s_za'     => [ 't' => 'text', 'l' => __( 'Orden: Z–A', 'wakoo' ), 'd' => __( 'Nombre Z–A', 'wakoo' ) ],
				'lbl_s_rating' => [ 't' => 'text', 'l' => __( 'Orden: puntuación', 'wakoo' ), 'd' => __( 'Mejor puntuación', 'wakoo' ) ],
				'lbl_s_reviews' => [ 't' => 'text', 'l' => __( 'Orden: opiniones', 'wakoo' ), 'd' => __( 'Más opiniones', 'wakoo' ) ],
			] ],
			[ 'id' => 'sec_seo', 'label' => __( 'SEO y ubicación', 'wakoo' ), 'controls' => [
				'schema'   => [ 't' => 'switch', 'l' => __( 'Añadir datos estructurados LocalBusiness', 'wakoo' ), 'd' => 'yes' ],
				'locality' => [ 't' => 'text', 'l' => __( 'Localidad (opcional)', 'wakoo' ), 'd' => '', 'c' => [ 'schema' => 'yes' ] ],
				'region'   => [ 't' => 'text', 'l' => __( 'Provincia / estado (opcional)', 'wakoo' ), 'd' => '', 'c' => [ 'schema' => 'yes' ] ],
				'country'  => [ 't' => 'text', 'l' => __( 'País, código de 2 letras (opcional, p. ej. ES)', 'wakoo' ), 'd' => '', 'c' => [ 'schema' => 'yes' ] ],
				'maps_links' => [ 't' => 'switch', 'l' => __( 'Mostrar enlaces «mapa» y «cómo llegar» (solo enlaces, sin API)', 'wakoo' ), 'd' => 'yes' ],
			] ],
		];
	}

	/* ---------------------------------------------------------------- helpers */

	private static function url( $m ) {
		$u = is_array( $m ) ? ( $m['url'] ?? '' ) : (string) $m;
		return '' === $u ? '' : esc_url_raw( trim( $u ), [ 'http', 'https' ] );
	}

	private static function color( $c ) {
		$c = sanitize_hex_color( (string) $c );
		return $c ? $c : '#2E7D55';
	}

	private static function lines( $raw ) {
		$out = [];
		foreach ( preg_split( '/[\r\n;]+/', (string) $raw ) as $line ) {
			$p = array_map( 'trim', explode( '|', $line, 2 ) );
			if ( '' !== $p[0] ) { $out[] = [ sanitize_text_field( $p[0] ), sanitize_text_field( $p[1] ?? '' ) ]; }
		}
		return $out;
	}

	private static function tel( $p ) { return preg_replace( '/[^+\d]/', '', (string) $p ); }

	/** Categorías del widget (nombre y color). */
	private static function cats( array $s ) {
		$cats = [];
		foreach ( (array) ( $s['cats'] ?? [] ) as $c ) {
			if ( is_array( $c ) && ! empty( $c['name'] ) ) { $cats[] = [ 'n' => sanitize_text_field( $c['name'] ), 'c' => self::color( $c['color'] ?? '' ) ]; }
		}
		if ( ! $cats ) { $cats[] = [ 'n' => __( 'General', 'wakoo' ), 'c' => '#2E7D55' ]; }
		return array_slice( $cats, 0, 30 );
	}

	private static function cat_index( array &$cats, $name, $grow ) {
		$name = trim( (string) $name );
		foreach ( $cats as $i => $c ) {
			if ( 0 === strcasecmp( $c['n'], $name ) ) { return $i; }
		}
		if ( $grow && '' !== $name && count( $cats ) < 30 ) {
			static $pal = [ '#CC7A3A', '#2B5BA8', '#7A4A9A', '#2E7D55', '#B8454F', '#0F8B8D', '#8A6D1E', '#4F5D75' ];
			$cats[] = [ 'n' => sanitize_text_field( $name ), 'c' => $pal[ count( $cats ) % count( $pal ) ] ];
			return count( $cats ) - 1;
		}
		return 0;
	}

	/* ------- horario: texto -> tramos [máscara de días (lun=bit0), inicio, fin] en minutos ------- */

	private static function days_mask( $label ) {
		$t = strtolower( remove_accents( (string) $label ) );
		if ( preg_match( '/todos los dias|diario|every ?day|daily|7 ?dias|24\s*\/\s*7/', $t ) ) { return 127; }
		static $map = [ 'lun' => 0, 'mon' => 0, 'mar' => 1, 'tue' => 1, 'mie' => 2, 'wed' => 2, 'jue' => 3, 'thu' => 3, 'vie' => 4, 'fri' => 4, 'sab' => 5, 'sat' => 5, 'dom' => 6, 'sun' => 6 ];
		if ( ! preg_match_all( '/\b(lun|mon|mar|tue|mie|wed|jue|thu|vie|fri|sab|sat|dom|sun)[a-z]*\.?/', $t, $m, PREG_OFFSET_CAPTURE ) ) { return 0; }
		$mask = 0;
		$prev = null;
		foreach ( $m[0] as $k => $hit ) {
			$d = $map[ $m[1][ $k ][0] ];
			if ( null !== $prev ) {
				$between = substr( $t, $prev[1], $hit[1] - $prev[1] );
				if ( preg_match( '/^\s*(-|–|—|a|al|to|hasta|thru)\s*$/u', $between ) ) {
					for ( $x = $prev[0]; ; $x = ( $x + 1 ) % 7 ) { $mask |= 1 << $x; if ( $x === $d ) { break; } }
					$prev = null;
					continue;
				}
			}
			$mask |= 1 << $d;
			$prev = [ $d, $hit[1] + strlen( $hit[0] ) ];
		}
		return $mask;
	}

	private static function minutes( $h, $m, $ap ) {
		$h = (int) $h; $m = (int) $m; $ap = strtolower( (string) $ap );
		if ( 'pm' === $ap && $h < 12 ) { $h += 12; }
		if ( 'am' === $ap && 12 === $h ) { $h = 0; }
		return max( 0, min( 1440, $h * 60 + $m ) );
	}

	private static function open_segments( array $hours ) {
		$out = [];
		foreach ( $hours as $h ) {
			$mask = self::days_mask( $h[0] );
			if ( ! $mask ) { continue; }
			$t = strtolower( remove_accents( $h[1] ) );
			if ( preg_match( '/cerrad|closed/', $t ) ) { continue; }
			if ( preg_match( '/24\s*h|24\s*\/\s*7|todo el dia|all day|24 horas/', $t ) ) { $out[] = [ $mask, 0, 1440 ]; continue; }
			if ( preg_match_all( '/(\d{1,2})(?:[:.h](\d{2}))?\s*(am|pm)?\s*(?:-|–|—|a|to|hasta)\s*(\d{1,2})(?:[:.h](\d{2}))?\s*(am|pm)?/u', $t, $mm, PREG_SET_ORDER ) ) {
				foreach ( array_slice( $mm, 0, 4 ) as $x ) {
					$out[] = [ $mask, self::minutes( $x[1], $x[2] ?? 0, $x[3] ?? '' ), self::minutes( $x[4], $x[5] ?? 0, $x[6] ?? '' ) ];
				}
			}
		}
		return array_slice( $out, 0, 24 );
	}

	/** ¿Abierto ahora? $now = [ día 0-6 (lun=0), minutos ]. Los tramos que cruzan la medianoche se tratan también. */
	private static function is_open( array $segs, array $now ) {
		list( $d, $m ) = $now;
		foreach ( $segs as $g ) {
			list( $mask, $a, $b ) = $g;
			if ( $b > $a ) {
				if ( ( $mask >> $d & 1 ) && $m >= $a && $m < $b ) { return true; }
			} else {
				if ( ( $mask >> $d & 1 ) && $m >= $a ) { return true; }
				if ( ( $mask >> ( ( $d + 6 ) % 7 ) & 1 ) && $m < $b ) { return true; }
			}
		}
		return false;
	}

	private static function timezone( array $s ) {
		$tz = trim( (string) ( $s['tz'] ?? '' ) );
		if ( $tz && in_array( $tz, timezone_identifiers_list(), true ) ) { return $tz; }
		$site = wp_timezone_string();
		return in_array( $site, timezone_identifiers_list(), true ) ? $site : '';
	}

	private static function now( $tz ) {
		try { $dt = new \DateTime( 'now', $tz ? new \DateTimeZone( $tz ) : wp_timezone() ); } catch ( \Exception $e ) { $dt = new \DateTime( 'now', wp_timezone() ); }
		return [ (int) $dt->format( 'N' ) - 1, (int) $dt->format( 'G' ) * 60 + (int) $dt->format( 'i' ) ];
	}

	/* ------- normalización ------- */

	/** Normaliza un negocio (de repetidor o CSV); devuelve null si no tiene nombre. */
	private function norm( array $r, array &$cats, $grow = false ) {
		$name = sanitize_text_field( $r['name'] ?? '' );
		if ( '' === $name ) { return null; }
		$photos = [];
		$ph = $r['photos'] ?? [];
		if ( is_string( $ph ) ) { $ph = preg_split( '/[;\s]+/', $ph ); }
		foreach ( (array) $ph as $x ) {
			$u = self::url( $x );
			if ( $u ) { $photos[] = $u; }
			if ( count( $photos ) >= 8 ) { break; }
		}
		$social = [];
		foreach ( self::lines( $r['social'] ?? '' ) as $x ) {
			$u = esc_url_raw( $x[1], [ 'http', 'https' ] );
			if ( $u ) { $social[] = [ $x[0], $u ]; }
		}
		$email = sanitize_email( $r['email'] ?? '' );
		$logo  = $r['logo'] ?? '';
		$hours = self::lines( $r['hours'] ?? '' );
		$tags  = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', preg_split( '/[,;]/', (string) ( $r['tags'] ?? '' ) ) ) ) ) ) );
		$ft    = $r['featured'] ?? '';
		return [
			'n' => $name, 'k' => self::cat_index( $cats, $r['category'] ?? '', $grow ), 'ty' => sanitize_text_field( $r['type'] ?? '' ), 'ar' => sanitize_text_field( $r['area'] ?? '' ),
			'lg' => is_array( $logo ) ? self::url( $logo ) : self::url( $logo ), 'ph' => $photos, 'de' => sanitize_textarea_field( $r['desc'] ?? '' ),
			'ad' => sanitize_text_field( $r['address'] ?? '' ), 'mp' => self::url( $r['maps_url'] ?? '' ),
			'tl' => sanitize_text_field( $r['phone'] ?? '' ), 'em' => is_email( $email ) ? $email : '', 'wb' => self::url( $r['web'] ?? '' ),
			'hr' => $hours, 'oh' => self::open_segments( $hours ), 'tg' => array_slice( $tags, 0, 12 ),
			'ra' => round( max( 0, min( 5, (float) ( $r['rating'] ?? 0 ) ) ), 1 ), 'rv' => max( 0, (int) ( $r['reviews'] ?? 0 ) ),
			'ft' => ( true === $ft || 'yes' === $ft || 1 === $ft || '1' === $ft || in_array( strtolower( (string) $ft ), [ 'si', 'sí', 'true' ], true ) ) ? 1 : 0,
			'so' => array_slice( $social, 0, 8 ),
		];
	}

	/** Lee y normaliza todos los negocios del widget. Devuelve [ items, cats ]. */
	private function load( array $s ) {
		$cats = self::cats( $s );
		if ( 'csv' === ( $s['source'] ?? 'repeater' ) ) {
			$id   = (int) ( $s['csv_file']['id'] ?? 0 );
			$path = $id ? get_attached_file( $id ) : '';
			if ( ! $path || ! is_readable( $path ) || ! preg_match( '/\.(csv|txt)$/i', $path ) ) { return [ [], $cats ]; }
			$key = 'wks_dir_' . $id . '_' . md5( $path . '|' . filemtime( $path ) . '|' . wp_json_encode( $cats ) );
			$hit = get_transient( $key );
			if ( is_array( $hit ) ) { return $hit; }
			if ( filesize( $path ) > self::CSV_BYTES ) { return [ [], $cats ]; }
			$items = self::parse_csv( $path, $cats, $this );
			$res   = [ $items, $cats ];
			set_transient( $key, $res, DAY_IN_SECONDS );
			return $res;
		}
		$items = [];
		foreach ( (array) ( $s['listings'] ?? [] ) as $r ) {
			if ( ! is_array( $r ) ) { continue; }
			$b = $this->norm( $r, $cats );
			if ( $b ) { $b['i'] = count( $items ); $items[] = $b; }
			if ( count( $items ) >= self::MAX ) { break; }
		}
		return [ $items, $cats ];
	}

	private static function parse_csv( $path, array &$cats, self $w ) {
		$raw = (string) file_get_contents( $path ); // phpcs:ignore
		$raw = str_replace( [ "\r\n", "\r" ], "\n", $raw );
		if ( 0 === strpos( $raw, "\xEF\xBB\xBF" ) ) { $raw = substr( $raw, 3 ); }
		$first = strtok( $raw, "\n" );
		$d = ',';
		foreach ( [ ';', "\t", '|' ] as $c ) { if ( substr_count( (string) $first, $c ) > substr_count( (string) $first, $d ) ) { $d = $c; } }
		$fh = fopen( 'php://temp', 'r+' ); // phpcs:ignore
		fwrite( $fh, $raw ); // phpcs:ignore
		rewind( $fh );
		$head = fgetcsv( $fh, 0, $d, '"', '\\' );
		if ( ! $head ) { fclose( $fh ); return []; } // phpcs:ignore
		static $alias = [
			'nombre' => 'name', 'name' => 'name', 'categoria' => 'category', 'category' => 'category', 'tipo' => 'type', 'type' => 'type', 'zona' => 'area', 'area' => 'area',
			'logo' => 'logo', 'fotos' => 'photos', 'photos' => 'photos', 'descripcion' => 'desc', 'description' => 'desc', 'direccion' => 'address', 'address' => 'address',
			'mapa' => 'maps_url', 'map' => 'maps_url', 'telefono' => 'phone', 'phone' => 'phone', 'correo' => 'email', 'email' => 'email', 'web' => 'web', 'sitio' => 'web',
			'horario' => 'hours', 'hours' => 'hours', 'etiquetas' => 'tags', 'tags' => 'tags', 'puntuacion' => 'rating', 'rating' => 'rating', 'opiniones' => 'reviews',
			'reviews' => 'reviews', 'destacado' => 'featured', 'featured' => 'featured', 'redes' => 'social', 'social' => 'social',
		];
		$cols = [];
		foreach ( $head as $i => $h ) {
			$k = strtolower( trim( remove_accents( (string) $h ) ) );
			if ( isset( $alias[ $k ] ) ) { $cols[ $i ] = $alias[ $k ]; }
		}
		$items = [];
		$n = 0;
		while ( false !== ( $row = fgetcsv( $fh, 0, $d, '"', '\\' ) ) && $n < self::CSV_MAX * 2 ) {
			$n++;
			$r = [];
			foreach ( $cols as $i => $k ) { $r[ $k ] = isset( $row[ $i ] ) ? mb_substr( (string) $row[ $i ], 0, 1500 ) : ''; }
			$b = $w->norm( $r, $cats, true );
			if ( $b ) { $b['i'] = count( $items ); $items[] = $b; }
			if ( count( $items ) >= self::CSV_MAX ) { break; }
		}
		fclose( $fh ); // phpcs:ignore
		return $items;
	}

	/* ------- consulta (la misma lógica que el JS del modo en página) ------- */

	private static function hay( array $b, array $cats ) {
		return mb_strtolower( $b['n'] . ' ' . $b['ty'] . ' ' . $b['ar'] . ' ' . ( $cats[ $b['k'] ]['n'] ?? '' ) . ' ' . implode( ' ', $b['tg'] ) . ' ' . $b['ad'] );
	}

	/** $skip: faceta que se ignora (para contar sin su propio filtro). */
	private static function match( array $b, array $f, array $cats, array $now, $skip = '' ) {
		if ( 'cat' !== $skip && '' !== $f['cat'] && (int) $f['cat'] !== $b['k'] ) { return false; }
		if ( 'area' !== $skip && '' !== $f['area'] && 0 !== strcasecmp( $f['area'], $b['ar'] ) ) { return false; }
		if ( 'tag' !== $skip && $f['tags'] ) {
			$mine = array_map( 'mb_strtolower', $b['tg'] );
			foreach ( $f['tags'] as $t ) { if ( ! in_array( mb_strtolower( $t ), $mine, true ) ) { return false; } }
		}
		if ( 'open' !== $skip && $f['open'] && ! self::is_open( $b['oh'], $now ) ) { return false; }
		if ( $f['toks'] ) {
			$h = self::hay( $b, $cats );
			foreach ( $f['toks'] as $t ) { if ( false === mb_strpos( $h, $t ) ) { return false; } }
		}
		return true;
	}

	private static function score( array $b, array $f ) {
		$n = mb_strtolower( $b['n'] );
		$sc = 0;
		foreach ( $f['toks'] as $t ) {
			if ( 0 === mb_strpos( $n, $t ) ) { $sc += 3; } elseif ( false !== mb_strpos( $n, $t ) ) { $sc += 2; } elseif ( false !== mb_strpos( mb_strtolower( $b['ty'] ), $t ) ) { $sc += 1; }
		}
		return $sc;
	}

	private static function sort_items( array &$list, $sort, array $f ) {
		$cmp = [
			'az'       => function ( $a, $b ) { return strcasecmp( remove_accents( $a['n'] ), remove_accents( $b['n'] ) ); },
			'za'       => function ( $a, $b ) { return strcasecmp( remove_accents( $b['n'] ), remove_accents( $a['n'] ) ); },
			'rating'   => function ( $a, $b ) { return $b['ra'] <=> $a['ra'] ?: $b['rv'] <=> $a['rv']; },
			'reviews'  => function ( $a, $b ) { return $b['rv'] <=> $a['rv']; },
			'featured' => function ( $a, $b ) { return $b['ft'] <=> $a['ft']; },
		];
		if ( 'original' === $sort && $f['toks'] ) {
			usort( $list, function ( $a, $b ) use ( $f ) { return self::score( $b, $f ) <=> self::score( $a, $f ) ?: $a['i'] <=> $b['i']; } );
			return;
		}
		$c = $cmp[ $sort ] ?? null;
		usort( $list, function ( $a, $b ) use ( $c ) { $r = $c ? $c( $a, $b ) : 0; return $r ?: $a['i'] <=> $b['i']; } );
	}

	/** Consulta completa: filtros + facetas con recuentos + orden + página. */
	private static function query( array $items, array $cats, array $f, array $now, $sort, $page, $per ) {
		$res = [];
		foreach ( $items as $b ) { if ( self::match( $b, $f, $cats, $now ) ) { $res[] = $b; } }
		$fc = [ 'cats' => [], 'tags' => [], 'areas' => [], 'open' => 0 ];
		foreach ( $items as $b ) {
			if ( self::match( $b, $f, $cats, $now, 'cat' ) ) { $fc['cats'][ $b['k'] ] = ( $fc['cats'][ $b['k'] ] ?? 0 ) + 1; }
			if ( '' !== $b['ar'] && self::match( $b, $f, $cats, $now, 'area' ) ) { $fc['areas'][ $b['ar'] ] = ( $fc['areas'][ $b['ar'] ] ?? 0 ) + 1; }
			if ( $b['tg'] && self::match( $b, $f, $cats, $now, 'tag' ) ) { foreach ( $b['tg'] as $t ) { $fc['tags'][ $t ] = ( $fc['tags'][ $t ] ?? 0 ) + 1; } }
			if ( $b['oh'] && self::match( $b, $f, $cats, $now, 'open' ) && self::is_open( $b['oh'], $now ) ) { $fc['open']++; }
		}
		arsort( $fc['tags'] ); arsort( $fc['areas'] );
		$fc['tags']  = array_slice( $fc['tags'], 0, 24, true );
		$fc['areas'] = array_slice( $fc['areas'], 0, 60, true );
		$fc['tags']  = array_map( null, array_keys( $fc['tags'] ), array_values( $fc['tags'] ) );
		$fc['areas'] = array_map( null, array_keys( $fc['areas'] ), array_values( $fc['areas'] ) );
		self::sort_items( $res, $sort, $f );
		$total = count( $res );
		$pages = max( 1, (int) ceil( $total / $per ) );
		$page  = max( 1, min( $page, $pages ) );
		return [ 'total' => $total, 'page' => $page, 'pages' => $pages, 'items' => array_slice( $res, ( $page - 1 ) * $per, $per ), 'facets' => $fc ];
	}

	private static function filters( $q, $cat, $tags, $area, $open ) {
		$q = mb_strtolower( sanitize_text_field( mb_substr( (string) $q, 0, 100 ) ) );
		$ts = [];
		foreach ( array_slice( (array) $tags, 0, 6 ) as $t ) { $t = sanitize_text_field( mb_substr( (string) $t, 0, 60 ) ); if ( '' !== $t ) { $ts[] = $t; } }
		return [
			'toks' => array_slice( array_values( array_filter( preg_split( '/\s+/u', $q ) ) ), 0, 8 ), 'cat' => ( '' === (string) $cat || ! is_numeric( $cat ) ) ? '' : (string) (int) $cat,
			'tags' => $ts, 'area' => sanitize_text_field( mb_substr( (string) $area, 0, 80 ) ), 'open' => ! empty( $open ) && '0' !== (string) $open,
		];
	}

	/* ------- REST ------- */

	public static function routes() {
		Sec::route( 'directory/list', 'GET', [ __CLASS__, 'rest_list' ] );
	}

	public static function rest_list( \WP_REST_Request $r ) {
		if ( ! Sec::rate( 'dir', 240, 600 ) ) { return Sec::err( 'rate', 429 ); }
		$s = Data::widget( (int) $r->get_param( 'post' ), (string) $r->get_param( 'w' ), 'wakoo-directory' );
		if ( null === $s ) { return Sec::err( 'not found', 404 ); }
		$self = ( new \ReflectionClass( __CLASS__ ) )->newInstanceWithoutConstructor();
		list( $items, $cats ) = $self->load( $s );
		$sort = (string) $r->get_param( 'sort' );
		if ( ! in_array( $sort, [ 'original', 'az', 'za', 'rating', 'reviews', 'featured' ], true ) ) { $sort = 'original'; }
		$tags = $r->get_param( 'tag' );
		$f    = self::filters( $r->get_param( 'q' ), $r->get_param( 'cat' ), is_array( $tags ) ? $tags : ( '' === (string) $tags ? [] : explode( '|', (string) $tags ) ), $r->get_param( 'area' ), $r->get_param( 'open' ) );
		$per  = Sec::int( $r->get_param( 'per' ), 4, 48 );
		$out  = self::query( $items, $cats, $f, self::now( self::timezone( $s ) ), $sort, Sec::int( $r->get_param( 'page' ), 1, 1000 ), $per );
		return Sec::ok( $out );
	}

	/* ---------------------------------------------------------------- render */

	/** LocalBusiness JSON-LD sin región/país fijos: solo lo que el usuario configure. */
	private function jsonld( array $items, array $s ) {
		$graph = [];
		foreach ( array_slice( $items, 0, 50 ) as $b ) {
			if ( '' === $b['ad'] && '' === $b['tl'] ) { continue; }
			$d = [ '@type' => 'LocalBusiness', 'name' => $b['n'] ];
			if ( $b['de'] ) { $d['description'] = $b['de']; }
			if ( $b['lg'] ) { $d['image'] = $b['lg']; }
			if ( $b['wb'] ) { $d['url'] = $b['wb']; }
			if ( $b['tl'] ) { $d['telephone'] = $b['tl']; }
			if ( $b['em'] ) { $d['email'] = $b['em']; }
			if ( $b['ad'] ) {
				$a = [ '@type' => 'PostalAddress', 'streetAddress' => $b['ad'] ];
				$loc = sanitize_text_field( $s['locality'] ?? '' ) ?: $b['ar'];
				if ( $loc ) { $a['addressLocality'] = $loc; }
				$reg = sanitize_text_field( $s['region'] ?? '' );
				if ( $reg ) { $a['addressRegion'] = $reg; }
				$cty = strtoupper( preg_replace( '/[^A-Za-z]/', '', (string) ( $s['country'] ?? '' ) ) );
				if ( 2 === strlen( $cty ) ) { $a['addressCountry'] = $cty; }
				$d['address'] = $a;
			}
			if ( $b['ra'] > 0 && $b['rv'] > 0 ) { $d['aggregateRating'] = [ '@type' => 'AggregateRating', 'ratingValue' => $b['ra'], 'reviewCount' => $b['rv'] ]; }
			if ( $b['so'] ) { $d['sameAs'] = array_column( $b['so'], 1 ); }
			$graph[] = $d;
		}
		if ( ! $graph ) { return; }
		echo '<script type="application/ld+json">' . wp_json_encode( [ '@context' => 'https://schema.org', '@graph' => $graph ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . '</script>';
	}

	private static function flag( $s, $k, $def = true ) { return isset( $s[ $k ] ) ? 'yes' === $s[ $k ] : $def; }

	protected function draw( array $s ) {
		list( $items, $cats ) = $this->load( $s );
		$maps  = self::flag( $s, 'maps_links' );
		$csv   = 'csv' === ( $s['source'] ?? 'repeater' );
		$tz    = self::timezone( $s );
		$per   = Sec::int( $s['per_page'] ?? 12, 4, 48 );
		$sort  = in_array( $s['sort'] ?? '', [ 'original', 'az', 'za', 'rating', 'reviews', 'featured' ], true ) ? $s['sort'] : 'original';
		$has_open = false;
		foreach ( $items as $b ) { if ( $b['oh'] ) { $has_open = true; break; } }

		// Etiquetas con los textos que ve el visitante (se envían como datos; el JS nunca interpreta HTML).
		$t = [];
		foreach ( [ 'count', 'close', 'photo', 'prev', 'next', 'lbl_open', 'lbl_maps', 'lbl_dir', 'lbl_call', 'lbl_web', 'lbl_address', 'lbl_phone', 'lbl_email', 'lbl_hours', 'lbl_found',
			'lbl_open_now', 'lbl_is_open', 'lbl_is_closed', 'lbl_area', 'lbl_all_areas', 'lbl_tags', 'lbl_sort', 'lbl_view_grid', 'lbl_view_list', 'lbl_more', 'lbl_page', 'lbl_reset',
			'lbl_map_btn', 'lbl_loading', 'lbl_error', 'lbl_s_original', 'lbl_s_az', 'lbl_s_za', 'lbl_s_rating', 'lbl_s_reviews', 'lbl_featured_only', 'all_label', 'lbl_none_t', 'lbl_none_d', 'sample_note' ] as $k ) {
			$src = [ 'count' => 'lbl_count', 'close' => 'lbl_close', 'photo' => 'lbl_photo', 'prev' => 'lbl_prev', 'next' => 'lbl_next' ][ $k ] ?? $k;
			$t[ $k ] = isset( $s[ $src ] ) ? (string) $s[ $src ] : '';
		}
		$cfgc = [];
		foreach ( $cats as $c ) { $cfgc[] = [ 'n' => $c['n'], 'c' => $c['c'] ]; }
		$init = null;
		$f0   = self::filters( '', '', [], '', 0 );
		if ( $csv ) { $init = self::query( $items, $cats, $f0, self::now( $tz ), $sort, 1, $per ); }
		$cfg = [
			't' => $t, 'cats' => $cfgc, 'mode' => $csv ? 'rest' : 'page', 'per' => $per, 'pager' => 'pages' === ( $s['pager'] ?? '' ) ? 'pages' : 'more',
			'sort' => $sort, 'view' => 'list' === ( $s['view'] ?? '' ) ? 'list' : 'grid', 'tz' => $tz, 'showAll' => self::flag( $s, 'show_all' ) ? 1 : 0,
			'tags' => self::flag( $s, 'show_tags' ) ? 1 : 0, 'areas' => self::flag( $s, 'show_areas' ) ? 1 : 0, 'open' => ( self::flag( $s, 'show_open' ) && $has_open ) ? 1 : 0,
			'sortUi' => self::flag( $s, 'show_sort' ) ? 1 : 0, 'viewUi' => self::flag( $s, 'show_view' ) ? 1 : 0, 'url' => self::flag( $s, 'url_state', false ) ? 1 : 0,
			'mapBtn' => self::flag( $s, 'map_btn', false ) ? 1 : 0, 'maps' => $maps ? 1 : 0, 'locality' => sanitize_text_field( $s['locality'] ?? '' ),
		];
		$uid = 'wksd' . substr( md5( $this->get_id() ), 0, 6 );

		$this->open( $cfg, 'wks-dir' );
		if ( ! empty( $s['label'] ) ) { echo '<p class="wks-dir__label">' . esc_html( $s['label'] ) . '</p>'; }
		if ( ! empty( $s['title'] ) ) { echo '<h2 class="wks-dir__title">' . esc_html( $s['title'] ) . '</h2>'; }
		echo '<form class="wks-dir__search" role="search" onsubmit="return false"><label for="' . esc_attr( $uid ) . '" class="wks-sr">' . esc_html( $s['placeholder'] ) . '</label><input id="' . esc_attr( $uid ) . '" type="search" autocomplete="off" placeholder="' . esc_attr( $s['placeholder'] ) . '"><button type="button" class="wks-dir__clear" aria-label="' . esc_attr( $s['lbl_clear'] ) . '" hidden>&#10005;</button></form>';
		echo '<div class="wks-dir__facets"></div>';
		echo '<div class="wks-dir__status-row"><p class="wks-dir__status" role="status" aria-live="polite"></p><button type="button" class="wks-dir__reset" hidden>' . esc_html( $s['lbl_reset'] ?? '' ) . '</button></div>';
		echo '<div class="wks-dir__list" aria-live="off"></div><div class="wks-dir__pager"></div>';
		echo '<div class="wks-dir__none" hidden><b>' . esc_html( $s['lbl_none_t'] ) . '</b><span>' . esc_html( $s['lbl_none_d'] ) . '</span></div>';
		// Datos: JSON dentro de un <script> inerte (escapado con JSON_HEX_*) + lista simple para quien no tenga JS.
		$payload = $csv ? $init : [ 'items' => $items ];
		echo '<script type="application/json" class="wks-dir__data">' . wp_json_encode( $payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . '</script>';
		echo '<noscript><ul class="wks-dir__plain">';
		foreach ( array_slice( $items, 0, 50 ) as $b ) {
			echo '<li><strong>' . esc_html( $b['n'] ) . '</strong>' . ( $b['ty'] ? ' · ' . esc_html( $b['ty'] ) : '' ) . ( $b['ad'] ? ' · ' . esc_html( $b['ad'] ) : '' ) . ( $b['tl'] ? ' · <a href="tel:' . esc_attr( self::tel( $b['tl'] ) ) . '">' . esc_html( $b['tl'] ) . '</a>' : '' ) . '</li>';
		}
		echo '</ul></noscript>';
		if ( self::flag( $s, 'schema' ) ) { $this->jsonld( $items, $s ); }
		$this->close();
	}
}
