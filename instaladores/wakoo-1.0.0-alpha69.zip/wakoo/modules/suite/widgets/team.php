<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;

defined( 'ABSPATH' ) || die();

/** Equipo por departamentos con filtro y ficha en ventana modal accesible. */
class Team extends Base {

	public function slug() { return 'team'; }
	public function label() { return __( 'Equipo', 'wakoo' ); }
	public function cat() { return 'interact'; }
	public function icon() { return 'eicon-person'; }
	public function words() { return [ 'equipo', 'team', 'personas', 'staff', 'miembros' ]; }

	private static function demo( $f ) { return [ 'url' => WAKOO_MODULES_URL . 'suite/assets/demo/' . $f, 'id' => 0 ]; }

	protected function sections() {
		return [
			[ 'id' => 'sec_items', 'label' => __( 'Miembros', 'wakoo' ), 'controls' => [
				'members' => [ 't' => 'repeater', 'title' => '{{{ name }}}', 'fields' => [
					'photo'  => [ 't' => 'media', 'l' => __( 'Foto', 'wakoo' ) ],
					'name'   => [ 't' => 'text', 'l' => __( 'Nombre', 'wakoo' ), 'd' => __( 'Nombre', 'wakoo' ) ],
					'role'   => [ 't' => 'text', 'l' => __( 'Cargo', 'wakoo' ), 'd' => '' ],
					'group'  => [ 't' => 'text', 'l' => __( 'Departamento', 'wakoo' ), 'd' => '' ],
					'short'  => [ 't' => 'textarea', 'l' => __( 'Bio corta', 'wakoo' ), 'd' => '' ],
					'full'   => [ 't' => 'textarea', 'l' => __( 'Bio completa', 'wakoo' ), 'd' => '' ],
					'social' => [ 't' => 'textarea', 'l' => __( 'Redes (una por línea: etiqueta|url)', 'wakoo' ), 'd' => '' ],
				], 'd' => [
					[ 'photo' => self::demo( 'avatar-1.svg' ), 'name' => 'Lucía Márquez', 'role' => __( 'Directora', 'wakoo' ), 'group' => __( 'Dirección', 'wakoo' ), 'short' => __( 'Lidera la estrategia del equipo.', 'wakoo' ), 'full' => __( 'Lucía lleva más de diez años liderando proyectos digitales. Cree en los equipos pequeños y en las decisiones basadas en datos.', 'wakoo' ), 'social' => "LinkedIn|https://example.com/lucia\nWeb|https://example.com" ],
					[ 'photo' => self::demo( 'avatar-2.svg' ), 'name' => 'Marcos Ortega', 'role' => __( 'Desarrollador', 'wakoo' ), 'group' => __( 'Tecnología', 'wakoo' ), 'short' => __( 'Construye y mantiene la plataforma.', 'wakoo' ), 'full' => __( 'Marcos diseña la arquitectura y cuida de que todo cargue rápido y sea seguro.', 'wakoo' ), 'social' => 'GitHub|https://example.com/marcos' ],
					[ 'photo' => self::demo( 'avatar-3.svg' ), 'name' => 'Irene Solís', 'role' => __( 'Diseñadora', 'wakoo' ), 'group' => __( 'Tecnología', 'wakoo' ), 'short' => __( 'Da forma a la experiencia de uso.', 'wakoo' ), 'full' => __( 'Irene une investigación y diseño visual para que los productos sean claros y accesibles.', 'wakoo' ), 'social' => '' ],
				] ],
			] ],
			[ 'id' => 'sec_layout', 'label' => __( 'Diseño', 'wakoo' ), 'controls' => [
				'all'   => [ 't' => 'text', 'l' => __( 'Texto del filtro «todos»', 'wakoo' ), 'd' => __( 'Todos', 'wakoo' ) ],
				'cols'  => [ 't' => 'number', 'l' => __( 'Columnas (escritorio)', 'wakoo' ), 'd' => 3, 'min' => 1, 'max' => 6, 'sel' => [ '{{WRAPPER}} .wks-team__grid' => '--wks-cols: {{VALUE}};' ] ],
				'more'  => [ 't' => 'text', 'l' => __( 'Texto «ver ficha»', 'wakoo' ), 'd' => __( 'Ver perfil', 'wakoo' ) ],
				'close' => [ 't' => 'text', 'l' => __( 'Texto cerrar', 'wakoo' ), 'd' => __( 'Cerrar', 'wakoo' ) ],
			] ],
		];
	}

	/** "etiqueta|url" por línea → [[label,url]] solo http/https. */
	private static function social( $raw ) {
		$out = [];
		foreach ( preg_split( '/\R/', (string) $raw ) as $line ) {
			$p = explode( '|', $line, 2 );
			if ( 2 !== count( $p ) ) { continue; }
			$label = sanitize_text_field( $p[0] );
			$url   = esc_url_raw( trim( $p[1] ), [ 'http', 'https' ] );
			if ( '' !== $label && '' !== $url ) { $out[] = [ $label, $url ]; }
		}
		return $out;
	}

	protected function draw( array $s ) {
		$rows = array_filter( (array) ( $s['members'] ?? [] ), function ( $r ) { return ! empty( $r['name'] ); } );
		$groups = $this->group_rows( $rows, 'group', '' );
		$this->open( [ 'close' => $s['close'] ] );
		if ( count( $groups ) > 1 ) {
			echo '<div class="wks-team__chips" role="group" aria-label="' . esc_attr( $s['all'] ) . '"><button type="button" class="wks-chip is-active" data-g="" aria-pressed="true">' . esc_html( $s['all'] ) . '</button>';
			$n = 0;
			foreach ( array_keys( $groups ) as $g ) {
				if ( '' === $g ) { $n++; continue; }
				echo '<button type="button" class="wks-chip" data-g="' . esc_attr( 'g' . $n ) . '" aria-pressed="false">' . esc_html( $g ) . '</button>';
				$n++;
			}
			echo '</div>';
		}
		$n = 0;
		foreach ( $groups as $name => $members ) {
			echo '<section class="wks-team__group" data-g="g' . (int) $n . '">';
			if ( '' !== $name ) { echo '<h3 class="wks-group-title">' . esc_html( $name ) . '</h3>'; }
			echo '<div class="wks-team__grid">';
			foreach ( $members as $m ) {
				$photo = $this->img( $m['photo'] ?? [] );
				echo '<article class="wks-team__card wks-card">';
				if ( $photo ) { echo '<img class="wks-team__photo" src="' . $photo . '" alt="" loading="lazy" decoding="async">'; }
				echo '<h4 class="wks-team__name">' . esc_html( $m['name'] ) . '</h4>';
				if ( ! empty( $m['role'] ) ) { echo '<p class="wks-team__role">' . esc_html( $m['role'] ) . '</p>'; }
				if ( ! empty( $m['short'] ) ) { echo '<p class="wks-team__short">' . esc_html( $m['short'] ) . '</p>'; }
				echo '<button type="button" class="wks-btn wks-team__open" aria-haspopup="dialog">' . esc_html( $s['more'] ) . '<span class="wks-sr"> — ' . esc_html( $m['name'] ) . '</span></button>';
				// Ficha oculta, clonada a la modal al abrir (todo ya escapado aquí).
				echo '<template class="wks-team__tpl">';
				if ( $photo ) { echo '<img class="wks-team__bigphoto" src="' . $photo . '" alt="">'; }
				echo '<h3 class="wks-team__mname">' . esc_html( $m['name'] ) . '</h3>';
				if ( ! empty( $m['role'] ) ) { echo '<p class="wks-team__role">' . esc_html( $m['role'] ) . '</p>'; }
				$full = '' !== trim( (string) ( $m['full'] ?? '' ) ) ? $m['full'] : ( $m['short'] ?? '' );
				if ( '' !== trim( (string) $full ) ) { echo '<div class="wks-team__full">' . wp_kses_post( wpautop( esc_html( $full ) ) ) . '</div>'; }
				$soc = self::social( $m['social'] ?? '' );
				if ( $soc ) {
					echo '<ul class="wks-team__social">';
					foreach ( $soc as $x ) { echo '<li><a href="' . esc_url( $x[1], [ 'http', 'https' ] ) . '" target="_blank" rel="noopener noreferrer nofollow">' . esc_html( $x[0] ) . '</a></li>'; }
					echo '</ul>';
				}
				echo '</template></article>';
			}
			echo '</div></section>';
			$n++;
		}
		$this->close();
	}
}
