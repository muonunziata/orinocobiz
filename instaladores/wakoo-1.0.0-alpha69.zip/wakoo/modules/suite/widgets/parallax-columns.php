<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;

defined( 'ABSPATH' ) || die();

/** Dos columnas de fotos con parallax suave a los lados de un texto central con botón; modo espejo opcional. */
class ParallaxColumns extends Base {

	public function slug() { return 'parallax-columns'; }
	public function label() { return __( 'Columnas de fotos con parallax', 'wakoo' ); }
	public function cat() { return 'media'; }
	public function icon() { return 'eicon-parallax'; }
	public function words() { return [ 'parallax', 'columnas', 'fotos', 'simetrico', 'espejo', 'galeria' ]; }

	private static function demo( $f ) { return [ 'url' => WAKOO_MODULES_URL . 'suite/assets/demo/' . $f, 'id' => 0 ]; }

	private static function ratios() {
		return [ '4/3' => '4:3', '3/4' => '3:4', '1/1' => '1:1', '16/9' => '16:9', '4/5' => '4:5' ];
	}

	private function photo_fields() {
		return [
			'image' => [ 't' => 'media', 'l' => __( 'Foto', 'wakoo' ) ],
			'alt'   => [ 't' => 'text', 'l' => __( 'Texto alternativo (vacío = decorativa)', 'wakoo' ), 'd' => '' ],
			'ratio' => [ 't' => 'select', 'l' => __( 'Proporción', 'wakoo' ), 'o' => self::ratios(), 'd' => '4/3' ],
		];
	}

	protected function sections() {
		$ph = [
			[ 'image' => self::demo( 'photo-1.svg' ), 'ratio' => '4/3' ],
			[ 'image' => self::demo( 'photo-2.svg' ), 'ratio' => '3/4' ],
			[ 'image' => self::demo( 'photo-3.svg' ), 'ratio' => '4/3' ],
			[ 'image' => self::demo( 'photo-4.svg' ), 'ratio' => '1/1' ],
		];
		$ph2 = [
			[ 'image' => self::demo( 'photo-5.svg' ), 'ratio' => '4/3' ],
			[ 'image' => self::demo( 'photo-6.svg' ), 'ratio' => '3/4' ],
			[ 'image' => self::demo( 'photo-2.svg' ), 'ratio' => '4/3' ],
			[ 'image' => self::demo( 'photo-1.svg' ), 'ratio' => '1/1' ],
		];
		return [
			[ 'id' => 'sec_text', 'label' => __( 'Texto central', 'wakoo' ), 'controls' => [
				'label'    => [ 't' => 'text', 'l' => __( 'Rótulo', 'wakoo' ), 'd' => __( 'Negocios fundadores', 'wakoo' ) ],
				'title'    => [ 't' => 'textarea', 'l' => __( 'Título', 'wakoo' ), 'd' => __( '¿Tienes un negocio aquí?', 'wakoo' ), 'dyn' => true ],
				'lead'     => [ 't' => 'textarea', 'l' => __( 'Texto', 'wakoo' ), 'd' => __( 'Los primeros negocios en unirse forman la base del directorio y mantienen sus ventajas desde el primer día.', 'wakoo' ) ],
				'btn_text' => [ 't' => 'text', 'l' => __( 'Texto del botón (vacío = sin botón)', 'wakoo' ), 'd' => __( 'Unirme como negocio fundador', 'wakoo' ) ],
				'btn_url'  => [ 't' => 'url', 'l' => __( 'Enlace del botón', 'wakoo' ) ],
			] ],
			[ 'id' => 'sec_left', 'label' => __( 'Fotos · columna izquierda', 'wakoo' ), 'controls' => [
				'left' => [ 't' => 'repeater', 'title' => '{{{ ratio }}}', 'fields' => $this->photo_fields(), 'd' => $ph ],
			] ],
			[ 'id' => 'sec_right', 'label' => __( 'Fotos · columna derecha', 'wakoo' ), 'controls' => [
				'right' => [ 't' => 'repeater', 'title' => '{{{ ratio }}}', 'fields' => $this->photo_fields(), 'd' => $ph2 ],
				'mirror' => [ 't' => 'switch', 'l' => __( 'Simetría: la derecha copia las proporciones de la izquierda', 'wakoo' ), 'd' => 'yes' ],
			] ],
			[ 'id' => 'sec_motion', 'label' => __( 'Movimiento', 'wakoo' ), 'controls' => [
				'parallax' => [ 't' => 'switch', 'l' => __( 'Movimiento suave al hacer scroll', 'wakoo' ), 'd' => 'yes' ],
				'depth'    => [ 't' => 'number', 'l' => __( 'Intensidad (1–15)', 'wakoo' ), 'd' => 5, 'min' => 1, 'max' => 15, 'c' => [ 'parallax' => 'yes' ], 'desc' => __( 'Se desactiva solo si el visitante pide «reducir movimiento».', 'wakoo' ) ],
				'opposite' => [ 't' => 'switch', 'l' => __( 'Columnas en sentido contrario', 'wakoo' ), 'd' => '', 'c' => [ 'parallax' => 'yes' ] ],
			] ],
			[ 'id' => 'sec_look', 'label' => __( 'Colores', 'wakoo' ), 'style' => true, 'controls' => [
				'c_bg'  => [ 't' => 'color', 'l' => __( 'Fondo de la sección', 'wakoo' ), 'sel' => [ '{{WRAPPER}} .wks-pcols' => '--wks-p-bg: {{VALUE}};' ] ],
				'c_ink' => [ 't' => 'color', 'l' => __( 'Texto de la sección', 'wakoo' ), 'sel' => [ '{{WRAPPER}} .wks-pcols' => '--wks-p-ink: {{VALUE}};' ] ],
			] ],
		];
	}

	private static function ratio( $r ) {
		return isset( self::ratios()[ $r ] ) ? str_replace( '/', ' / ', $r ) : '4 / 3';
	}

	private function column( array $rows, array $ratios_from, $eager ) {
		foreach ( array_values( $rows ) as $i => $it ) {
			$url = $this->img( $it['image'] ?? [] );
			if ( ! $url ) { continue; }
			$ra  = $ratios_from ? ( $ratios_from[ $i ]['ratio'] ?? '4/3' ) : ( $it['ratio'] ?? '4/3' );
			echo '<figure class="wks-pcols__ph" style="aspect-ratio:' . esc_attr( self::ratio( $ra ) ) . '"><img src="' . $url . '" alt="' . esc_attr( $it['alt'] ?? '' ) . '" loading="' . ( $eager && 0 === $i ? 'eager' : 'lazy' ) . '" decoding="async"></figure>';
		}
	}

	protected function draw( array $s ) {
		$l = array_values( (array) ( $s['left'] ?? [] ) );
		$r = array_values( (array) ( $s['right'] ?? [] ) );
		$mirror = ! empty( $s['mirror'] ) && 'yes' === $s['mirror'];
		$par    = ! empty( $s['parallax'] ) && 'yes' === $s['parallax'];
		$depth  = max( 1, min( 15, (int) ( $s['depth'] ?? 5 ) ) ) / 100;
		$opp    = $par && ! empty( $s['opposite'] ) && 'yes' === $s['opposite'];
		$this->open( [ 'par' => $par ? 1 : 0 ] );
		echo '<section class="wks-pcols"><div class="wks-pcols__grid"><div class="wks-pcols__col"' . ( $par ? ' data-par="' . esc_attr( $depth ) . '"' : '' ) . '>';
		$this->column( $l, [], true );
		echo '</div><div class="wks-pcols__copy">';
		if ( ! empty( $s['label'] ) ) { echo '<p class="wks-pcols__label">' . esc_html( $s['label'] ) . '</p>'; }
		if ( ! empty( $s['title'] ) ) { echo '<h2 class="wks-pcols__title">' . esc_html( $s['title'] ) . '</h2>'; }
		if ( ! empty( $s['lead'] ) ) { echo '<p class="wks-pcols__lead">' . esc_html( $s['lead'] ) . '</p>'; }
		if ( ! empty( $s['btn_text'] ) ) { echo '<a class="wks-btn wks-pcols__btn"' . $this->link_attrs( $s['btn_url'] ?? [] ) . '>' . esc_html( $s['btn_text'] ) . '</a>'; }
		echo '</div><div class="wks-pcols__col"' . ( $par ? ' data-par="' . esc_attr( $opp ? -$depth : $depth ) . '"' : '' ) . '>';
		$this->column( $r ? $r : $l, $mirror ? $l : [], true );
		echo '</div></div></section>';
		$this->close();
	}
}
