<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;

defined( 'ABSPATH' ) || die();

/** 15. Checklist interactivo agrupado, con progreso guardado en el navegador. */
class Checklist extends Base {

	public function slug() { return 'checklist'; }
	public function label() { return __( 'Checklist interactivo', 'wakoo' ); }
	public function icon() { return 'eicon-check-circle'; }
	public function words() { return [ 'checklist', 'lista', 'tareas', 'onboarding', 'guia' ]; }

	protected function sections() {
		return [
			[ 'id' => 'sec_items', 'label' => __( 'Tareas', 'wakoo' ), 'controls' => [
				'title' => [ 't' => 'text', 'l' => __( 'Título', 'wakoo' ), 'd' => __( 'Lista de comprobación', 'wakoo' ) ],
				'items' => [ 't' => 'repeater', 'title' => '{{{ text }}}', 'fields' => [
					'group' => [ 't' => 'text', 'l' => __( 'Grupo', 'wakoo' ), 'd' => __( 'Primeros pasos', 'wakoo' ) ],
					'text'  => [ 't' => 'text', 'l' => __( 'Tarea', 'wakoo' ), 'd' => __( 'Tarea', 'wakoo' ) ],
					'hint'  => [ 't' => 'text', 'l' => __( 'Ayuda (opcional)', 'wakoo' ), 'd' => '' ],
					'link'  => [ 't' => 'url', 'l' => __( 'Enlace (opcional)', 'wakoo' ) ],
				], 'd' => [
					[ 'group' => __( 'Primeros pasos', 'wakoo' ), 'text' => __( 'Crea tu cuenta', 'wakoo' ), 'hint' => __( 'Solo toma un minuto.', 'wakoo' ) ],
					[ 'group' => __( 'Primeros pasos', 'wakoo' ), 'text' => __( 'Completa tu perfil', 'wakoo' ), 'hint' => '' ],
					[ 'group' => __( 'Configuración', 'wakoo' ), 'text' => __( 'Elige tu plan', 'wakoo' ), 'hint' => '' ],
					[ 'group' => __( 'Configuración', 'wakoo' ), 'text' => __( 'Invita a tu equipo', 'wakoo' ), 'hint' => '' ],
				] ],
			] ],
			[ 'id' => 'sec_opts', 'label' => __( 'Opciones', 'wakoo' ), 'controls' => [
				'persist'  => [ 't' => 'switch', 'l' => __( 'Recordar el progreso en este navegador', 'wakoo' ), 'd' => 'yes' ],
				'reset'    => [ 't' => 'switch', 'l' => __( 'Botón reiniciar', 'wakoo' ), 'd' => 'yes' ],
				'copy'     => [ 't' => 'switch', 'l' => __( 'Botón copiar resumen', 'wakoo' ), 'd' => 'yes' ],
				'print'    => [ 't' => 'switch', 'l' => __( 'Botón imprimir', 'wakoo' ) ],
				'done_msg' => [ 't' => 'text', 'l' => __( 'Mensaje al completar todo (vacío = ninguno)', 'wakoo' ), 'd' => __( '¡Todo listo! 🎉', 'wakoo' ) ],
				'l_reset'  => [ 't' => 'text', 'l' => __( 'Texto reiniciar', 'wakoo' ), 'd' => __( 'Reiniciar', 'wakoo' ) ],
				'l_copy'   => [ 't' => 'text', 'l' => __( 'Texto copiar', 'wakoo' ), 'd' => __( 'Copiar resumen', 'wakoo' ) ],
				'l_copied' => [ 't' => 'text', 'l' => __( 'Texto copiado', 'wakoo' ), 'd' => __( 'Copiado', 'wakoo' ) ],
				'l_print'  => [ 't' => 'text', 'l' => __( 'Texto imprimir', 'wakoo' ), 'd' => __( 'Imprimir', 'wakoo' ) ],
				'l_of'     => [ 't' => 'text', 'l' => __( 'Texto "de" del contador', 'wakoo' ), 'd' => __( 'de', 'wakoo' ) ],
			] ],
		];
	}

	protected function draw( array $s ) {
		$items = array_values( (array) ( $s['items'] ?? [] ) );
		if ( ! $items ) { return; }
		$groups = $this->group_rows( $items, 'group', __( 'General', 'wakoo' ) );
		$this->open( [
			'persist' => 'yes' === $s['persist'],
			'done'    => (string) $s['done_msg'],
			'copied'  => (string) $s['l_copied'],
			'of'      => (string) $s['l_of'],
			'title'   => (string) $s['title'],
		] );
		if ( $s['title'] ) { echo '<h3 class="wks-cl__title">' . esc_html( $s['title'] ) . '</h3>'; }
		echo '<div class="wks-cl__progress"><div class="wks-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><i></i></div><span class="wks-cl__count" aria-live="polite"></span></div>';
		$n = 0;
		foreach ( $groups as $g => $rows ) {
			echo '<fieldset class="wks-cl__group"><legend class="wks-group-title">' . esc_html( $g ) . '</legend>';
			foreach ( $rows as $r ) {
				$id = 'wks-cl-' . esc_attr( $this->get_id() ) . '-' . $n;
				echo '<div class="wks-cl__item"><input type="checkbox" id="' . $id . '" data-n="' . (int) $n . '"><label for="' . $id . '">' . esc_html( $r['text'] ?? '' ) . '</label>';
				if ( ! empty( $r['hint'] ) ) { echo '<small class="wks-cl__hint">' . esc_html( $r['hint'] ) . '</small>'; }
				$a = $this->link_attrs( $r['link'] ?? null );
				if ( $a ) { echo '<a class="wks-cl__link"' . $a . ' aria-label="' . esc_attr( ( $r['text'] ?? '' ) . ' →' ) . '">→</a>'; } // phpcs:ignore
				echo '</div>';
				$n++;
			}
			echo '</fieldset>';
		}
		echo '<p class="wks-cl__done" role="status" hidden>' . esc_html( $s['done_msg'] ) . '</p><div class="wks-cl__tools">';
		if ( 'yes' === $s['copy'] ) { echo '<button type="button" class="wks-btn wks-btn--ghost" data-a="copy">' . esc_html( $s['l_copy'] ) . '</button>'; }
		if ( 'yes' === $s['print'] ) { echo '<button type="button" class="wks-btn wks-btn--ghost" data-a="print">' . esc_html( $s['l_print'] ) . '</button>'; }
		if ( 'yes' === $s['reset'] ) { echo '<button type="button" class="wks-btn wks-btn--ghost" data-a="reset">' . esc_html( $s['l_reset'] ) . '</button>'; }
		echo '</div>';
		$this->close();
	}
}
