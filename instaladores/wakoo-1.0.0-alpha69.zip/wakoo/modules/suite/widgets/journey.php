<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;

defined( 'ABSPATH' ) || die();

/** Recorrido por etapas: una tarjeta fija cambia de foto (o vídeo con portada) según la etapa activa al hacer scroll. */
class Journey extends Base {

	public function slug() { return 'journey'; }
	public function label() { return __( 'Recorrido con tarjeta fija', 'wakoo' ); }
	public function cat() { return 'media'; }
	public function icon() { return 'eicon-time-line'; }
	public function words() { return [ 'recorrido', 'pasos', 'scroll', 'sticky', 'storytelling', 'journey', 'etapas' ]; }

	private static function demo( $f ) { return [ 'url' => WAKOO_MODULES_URL . 'suite/assets/demo/' . $f, 'id' => 0 ]; }

	protected function sections() {
		return [
			[ 'id' => 'sec_head', 'label' => __( 'Cabecera', 'wakoo' ), 'controls' => [
				'title'    => [ 't' => 'text', 'l' => __( 'Título', 'wakoo' ), 'd' => __( 'Del primer contacto', 'wakoo' ), 'dyn' => true ],
				'accent'   => [ 't' => 'text', 'l' => __( 'Final del título (en color)', 'wakoo' ), 'd' => __( 'a la decisión', 'wakoo' ) ],
				'lead'     => [ 't' => 'textarea', 'l' => __( 'Texto de apoyo', 'wakoo' ), 'd' => __( 'Cada etapa es útil por sí sola, antes de cualquier oferta.', 'wakoo' ) ],
				'card_tag' => [ 't' => 'text', 'l' => __( 'Rótulo de la tarjeta', 'wakoo' ), 'd' => __( 'GUÍA', 'wakoo' ) ],
			] ],
			[ 'id' => 'sec_steps', 'label' => __( 'Etapas', 'wakoo' ), 'controls' => [
				'steps' => [ 't' => 'repeater', 'title' => '{{{ title }}}', 'fields' => [
					'title' => [ 't' => 'text', 'l' => __( 'Título', 'wakoo' ), 'd' => '' ],
					'text'  => [ 't' => 'textarea', 'l' => __( 'Texto', 'wakoo' ), 'd' => '' ],
					'image' => [ 't' => 'media', 'l' => __( 'Foto de la tarjeta (o portada del vídeo)', 'wakoo' ) ],
					'video' => [ 't' => 'media', 'l' => __( 'Vídeo propio (opcional: solo se carga al pulsar)', 'wakoo' ) ],
				], 'd' => [
					[ 'title' => __( 'Descubre', 'wakoo' ), 'text' => __( 'Turismo, eventos y negocios locales muestran cómo es el lugar.', 'wakoo' ), 'image' => self::demo( 'photo-1.svg' ) ],
					[ 'title' => __( 'Confía', 'wakoo' ), 'text' => __( 'Contenido local verificable y un directorio hecho por los propios negocios.', 'wakoo' ), 'image' => self::demo( 'photo-2.svg' ) ],
					[ 'title' => __( 'Participa', 'wakoo' ), 'text' => __( 'Membresías, mercado y empleo para negocios y vecinos.', 'wakoo' ), 'image' => self::demo( 'photo-3.svg' ) ],
					[ 'title' => __( 'Decide', 'wakoo' ), 'text' => __( 'Quien quiera vivir aquí puede ver los proyectos disponibles, siempre marcados como publicidad.', 'wakoo' ), 'image' => self::demo( 'photo-4.svg' ) ],
				] ],
			] ],
			[ 'id' => 'sec_btn', 'label' => __( 'Botón y textos', 'wakoo' ), 'controls' => [
				'btn_text' => [ 't' => 'text', 'l' => __( 'Texto del botón (vacío = sin botón)', 'wakoo' ), 'd' => __( 'Conoce la guía', 'wakoo' ) ],
				'btn_url'  => [ 't' => 'url', 'l' => __( 'Enlace del botón', 'wakoo' ) ],
				'lbl_play' => [ 't' => 'text', 'l' => __( 'Texto accesible «Reproducir vídeo»', 'wakoo' ), 'd' => __( 'Reproducir vídeo', 'wakoo' ) ],
				'lbl_step' => [ 't' => 'text', 'l' => __( 'Palabra «Etapa» (lectores de pantalla)', 'wakoo' ), 'd' => __( 'Etapa', 'wakoo' ) ],
			] ],
			[ 'id' => 'sec_look', 'label' => __( 'Colores de la tarjeta', 'wakoo' ), 'style' => true, 'controls' => [
				'c_card' => [ 't' => 'color', 'l' => __( 'Fondo de la tarjeta fija', 'wakoo' ), 'sel' => [ '{{WRAPPER}} .wks-journey' => '--wks-j-card: {{VALUE}};' ] ],
				'c_cardink' => [ 't' => 'color', 'l' => __( 'Texto de la tarjeta', 'wakoo' ), 'sel' => [ '{{WRAPPER}} .wks-journey' => '--wks-j-ink: {{VALUE}};' ] ],
			] ],
		];
	}

	private static function video_url( $m ) {
		$u = is_array( $m ) && ! empty( $m['url'] ) ? esc_url_raw( $m['url'], [ 'http', 'https' ] ) : '';
		return $u;
	}

	protected function draw( array $s ) {
		$steps = array_values( array_filter( (array) ( $s['steps'] ?? [] ), function ( $r ) { return is_array( $r ) && ( ! empty( $r['title'] ) || ! empty( $r['text'] ) ); } ) );
		$total = count( $steps );
		$pad   = function ( $n ) { return str_pad( (string) $n, 2, '0', STR_PAD_LEFT ); };
		$this->open( [ 'play' => $s['lbl_play'] ] );
		echo '<div class="wks-journey__head">';
		if ( ! empty( $s['title'] ) || ! empty( $s['accent'] ) ) {
			echo '<h2 class="wks-journey__title">' . esc_html( $s['title'] ?? '' ) . ' <span class="wks-journey__accent">' . esc_html( $s['accent'] ?? '' ) . '</span></h2>';
		}
		if ( ! empty( $s['lead'] ) ) { echo '<p class="wks-journey__lead">' . esc_html( $s['lead'] ) . '</p>'; }
		echo '</div><div class="wks-journey__grid"><div class="wks-journey__card" aria-hidden="false"><div class="wks-journey__cnt"><span class="wks-journey__count" aria-hidden="true">' . esc_html( $pad( 1 ) . ' / ' . $pad( $total ) ) . '</span><span>' . esc_html( $s['card_tag'] ?? '' ) . '</span></div><div class="wks-journey__stack">';
		foreach ( $steps as $i => $st ) {
			$img   = $this->img( $st['image'] ?? [] );
			$video = self::video_url( $st['video'] ?? [] );
			echo '<div class="wks-journey__slide' . ( 0 === $i ? ' is-on' : '' ) . '" data-i="' . (int) $i . '"' . ( $video ? ' data-video="' . esc_url( $video ) . '"' : '' ) . '>';
			if ( $img ) { echo '<img src="' . $img . '" alt="" loading="' . ( 0 === $i ? 'eager' : 'lazy' ) . '" decoding="async">'; }
			if ( $video ) {
				echo '<button type="button" class="wks-journey__play" aria-label="' . esc_attr( $s['lbl_play'] . ': ' . ( $st['title'] ?? '' ) ) . '"><svg viewBox="0 0 24 24" width="28" height="28" aria-hidden="true"><path d="M8 5v14l11-7z" fill="currentColor"/></svg></button>';
			}
			echo '</div>';
		}
		echo '</div></div><ol class="wks-journey__list">';
		foreach ( $steps as $i => $st ) {
			echo '<li class="wks-journey__step' . ( 0 === $i ? ' is-on' : '' ) . '" data-i="' . (int) $i . '"><span class="wks-journey__n" aria-hidden="true">' . esc_html( $pad( $i + 1 ) ) . '</span><h3><span class="wks-sr">' . esc_html( $s['lbl_step'] . ' ' . ( $i + 1 ) . ': ' ) . '</span>' . esc_html( $st['title'] ?? '' ) . '</h3>';
			if ( ! empty( $st['text'] ) ) { echo '<p>' . esc_html( $st['text'] ) . '</p>'; }
			echo '</li>';
		}
		echo '</ol>';
		if ( ! empty( $s['btn_text'] ) ) {
			echo '<a class="wks-btn wks-journey__btn"' . $this->link_attrs( $s['btn_url'] ?? [] ) . '>' . esc_html( $s['btn_text'] ) . ' →</a>';
		}
		echo '</div>';
		$this->close();
	}
}
