<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;

defined( 'ABSPATH' ) || die();

/** 5. Reproductor de audio con forma de onda, lista por álbum/grupo. */
class Audio extends Base {

	public function slug() { return 'audio'; }
	public function label() { return __( 'Reproductor de audio', 'wakoo' ); }
	public function cat() { return 'media'; }
	public function icon() { return 'eicon-play'; }
	public function words() { return [ 'audio', 'podcast', 'musica', 'onda', 'waveform', 'nota de voz' ]; }

	protected function sections() {
		return [
			[ 'id' => 'sec_tracks', 'label' => __( 'Pistas', 'wakoo' ), 'controls' => [
				'tracks' => [ 't' => 'repeater', 'title' => '{{{ title }}}', 'fields' => [
					'group'  => [ 't' => 'text', 'l' => __( 'Álbum / grupo', 'wakoo' ), 'd' => '' ],
					'title'  => [ 't' => 'text', 'l' => __( 'Título', 'wakoo' ), 'd' => __( 'Pista', 'wakoo' ) ],
					'artist' => [ 't' => 'text', 'l' => __( 'Autor', 'wakoo' ), 'd' => '' ],
					'file'   => [ 't' => 'media', 'l' => __( 'Archivo de audio (biblioteca)', 'wakoo' ), 'd' => [ 'url' => '' ] ],
					'url'    => [ 't' => 'url', 'l' => __( 'o enlace al audio', 'wakoo' ), 'desc' => __( 'Si hay archivo, se usa el archivo. La onda real solo se calcula con archivos de tu propio sitio.', 'wakoo' ) ],
				], 'd' => [
					[ 'group' => __( 'Demo', 'wakoo' ), 'title' => __( 'Melodía de prueba', 'wakoo' ), 'artist' => 'Wakoo', 'file' => [ 'url' => WAKOO_MODULES_URL . 'suite/assets/demo/tone.wav', 'id' => 0 ] ],
				] ],
			] ],
			[ 'id' => 'sec_opts', 'label' => __( 'Opciones', 'wakoo' ), 'controls' => [
				'autonext' => [ 't' => 'switch', 'l' => __( 'Pasar a la siguiente pista', 'wakoo' ), 'd' => 'yes' ],
				'speed'    => [ 't' => 'switch', 'l' => __( 'Control de velocidad', 'wakoo' ), 'd' => 'yes' ],
				'volume'   => [ 't' => 'switch', 'l' => __( 'Control de volumen', 'wakoo' ), 'd' => 'yes' ],
				'bars'     => [ 't' => 'number', 'l' => __( 'Barras de la onda', 'wakoo' ), 'd' => 96, 'min' => 24, 'max' => 240 ],
				'wave_h'   => [ 't' => 'number', 'l' => __( 'Alto de la onda (px)', 'wakoo' ), 'd' => 80, 'min' => 40, 'max' => 240, 'sel' => [ '{{WRAPPER}} .wks-audio__wave' => 'height: {{VALUE}}px;' ] ],
			] ],
		];
	}

	protected function draw( array $s ) {
		$tracks = [];
		foreach ( (array) ( $s['tracks'] ?? [] ) as $t ) {
			$src = $this->img( $t['file'] ?? [] );
			if ( ! $src && ! empty( $t['url']['url'] ) ) { $src = esc_url( $t['url']['url'], [ 'http', 'https' ] ); }
			if ( $src ) { $tracks[] = [ 'src' => $src ] + $t; }
		}
		if ( ! $tracks ) { echo '<p class="wks-msg">' . esc_html__( 'Añade una pista de audio.', 'wakoo' ) . '</p>'; return; }
		$this->open( [ 'autonext' => 'yes' === $s['autonext'], 'bars' => (int) $s['bars'] ] );
		echo '<div class="wks-audio__now"><strong class="wks-audio__title"></strong> <span class="wks-audio__artist"></span></div>';
		echo '<div class="wks-audio__main">';
		echo '<button type="button" class="wks-btn wks-audio__play" aria-label="' . esc_attr__( 'Reproducir', 'wakoo' ) . '">&#9654;</button>';
		echo '<div class="wks-audio__wave" role="slider" tabindex="0" aria-label="' . esc_attr__( 'Posición', 'wakoo' ) . '" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><canvas></canvas></div>';
		echo '<span class="wks-audio__time">0:00 / 0:00</span>';
		echo '</div><div class="wks-audio__tools">';
		if ( 'yes' === $s['speed'] ) {
			echo '<label class="wks-audio__tool">' . esc_html__( 'Velocidad', 'wakoo' ) . ' <select class="wks-audio__speed">';
			foreach ( [ '0.75', '1', '1.25', '1.5', '2' ] as $v ) { echo '<option value="' . esc_attr( $v ) . '"' . selected( '1', $v, false ) . '>' . esc_html( $v ) . '×</option>'; }
			echo '</select></label>';
		}
		if ( 'yes' === $s['volume'] ) {
			echo '<label class="wks-audio__tool">' . esc_html__( 'Volumen', 'wakoo' ) . ' <input type="range" class="wks-audio__vol" min="0" max="1" step="0.05" value="1"></label>';
		}
		echo '</div>';
		if ( count( $tracks ) > 1 ) {
			echo '<div class="wks-audio__list">';
			$i = 0;
			foreach ( $this->group_rows( $tracks, 'group', '' ) as $g => $rows ) {
				if ( '' !== $g ) { echo '<div class="wks-group-title">' . esc_html( $g ) . '</div>'; }
				echo '<ul>';
				foreach ( $rows as $r ) {
					echo '<li><button type="button" class="wks-audio__track" data-i="' . (int) $i . '">' . esc_html( $r['title'] ?? '' ) . ( ! empty( $r['artist'] ) ? ' <small>— ' . esc_html( $r['artist'] ) . '</small>' : '' ) . '</button></li>';
					$i++;
				}
				echo '</ul>';
			}
			echo '</div>';
		}
		// Track data lives in a JSON script so it needs no extra escaping in attributes.
		$data = [];
		foreach ( $this->flat_order( $tracks ) as $t ) { $data[] = [ 'src' => $t['src'], 'title' => (string) ( $t['title'] ?? '' ), 'artist' => (string) ( $t['artist'] ?? '' ) ]; }
		echo '<script type="application/json" class="wks-audio__data">' . wp_json_encode( $data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES ) . '</script>';
		$this->close();
	}

	/** Same order the list is printed in (grouped). */
	private function flat_order( array $tracks ) {
		$out = [];
		foreach ( $this->group_rows( $tracks, 'group', '' ) as $rows ) { foreach ( $rows as $r ) { $out[] = $r; } }
		return $out;
	}
}
