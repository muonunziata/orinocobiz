<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;

defined( 'ABSPATH' ) || die();

/** 12. Selector de tallas y variantes: precio y stock cambian al elegir. */
class Variants extends Base {

	public function slug() { return 'variants'; }
	public function label() { return __( 'Selector de variantes', 'wakoo' ); }
	public function cat() { return 'commerce'; }
	public function icon() { return 'eicon-product-variations'; }
	public function words() { return [ 'tallas', 'variantes', 'talla', 'color', 'stock', 'precio' ]; }

	protected function sections() {
		$vr = [];
		foreach ( [ 'S', 'M', 'L' ] as $i => $sz ) {
			foreach ( [ 'Rojo', 'Azul' ] as $j => $col ) {
				$vr[] = [ 'opts' => "$sz, $col", 'price' => (string) ( 19 + $i * 2 ), 'stock' => ( 'L' === $sz && 'Azul' === $col ) ? 0 : 5 - $i, 'sku' => "CAM-$sz-" . strtoupper( substr( $col, 0, 3 ) ) ];
			}
		}
		return [
			[ 'id' => 'sec_product', 'label' => __( 'Producto', 'wakoo' ), 'controls' => [
				'name'  => [ 't' => 'text', 'l' => __( 'Nombre', 'wakoo' ), 'd' => __( 'Camiseta básica', 'wakoo' ) ],
				'image' => [ 't' => 'media', 'l' => __( 'Imagen', 'wakoo' ) ],
				'attrs' => [ 't' => 'repeater', 'title' => '{{{ name }}}', 'fields' => [
					'name'   => [ 't' => 'text', 'l' => __( 'Grupo de opciones', 'wakoo' ), 'd' => __( 'Talla', 'wakoo' ) ],
					'values' => [ 't' => 'text', 'l' => __( 'Valores (separados por comas)', 'wakoo' ), 'd' => 'S, M, L' ],
				], 'd' => [ [ 'name' => __( 'Talla', 'wakoo' ), 'values' => 'S, M, L' ], [ 'name' => __( 'Color', 'wakoo' ), 'values' => 'Rojo, Azul' ] ],
				  'desc' => __( 'El orden de los grupos debe coincidir con el de las variantes.', 'wakoo' ) ],
			] ],
			[ 'id' => 'sec_matrix', 'label' => __( 'Variantes (precio y stock)', 'wakoo' ), 'controls' => [
				'variants' => [ 't' => 'repeater', 'title' => '{{{ opts }}} · {{{ price }}}', 'fields' => [
					'opts'  => [ 't' => 'text', 'l' => __( 'Opciones (mismo orden que los grupos)', 'wakoo' ), 'd' => 'M, Rojo' ],
					'price' => [ 't' => 'number', 'l' => __( 'Precio', 'wakoo' ), 'd' => 19, 'step' => 0.01, 'min' => 0 ],
					'stock' => [ 't' => 'number', 'l' => __( 'Stock', 'wakoo' ), 'd' => 5, 'min' => 0 ],
					'sku'   => [ 't' => 'text', 'l' => 'SKU', 'd' => '' ],
				], 'd' => $vr ],
				'currency' => [ 't' => 'text', 'l' => __( 'Símbolo de moneda', 'wakoo' ), 'd' => '€' ],
				'cur_after' => [ 't' => 'switch', 'l' => __( 'Símbolo después del precio', 'wakoo' ), 'd' => 'yes' ],
				'low'      => [ 't' => 'number', 'l' => __( 'Avisar "pocas unidades" desde', 'wakoo' ), 'd' => 3, 'min' => 0 ],
			] ],
			[ 'id' => 'sec_cta', 'label' => __( 'Botón de compra', 'wakoo' ), 'controls' => [
				'cta_text' => [ 't' => 'text', 'l' => __( 'Texto del botón', 'wakoo' ), 'd' => __( 'Lo quiero', 'wakoo' ) ],
				'cta_url'  => [ 't' => 'url', 'l' => __( 'Enlace', 'wakoo' ), 'd' => [ 'url' => '' ], 'desc' => __( 'Puede ser una página, un WhatsApp (https://wa.me/número) o mailto:.', 'wakoo' ) ],
				'append'   => [ 't' => 'switch', 'l' => __( 'Añadir la variante elegida al enlace', 'wakoo' ), 'd' => 'yes' ],
				'param'    => [ 't' => 'text', 'l' => __( 'Nombre del parámetro', 'wakoo' ), 'd' => 'text', 'c' => [ 'append' => 'yes' ] ],
				'msg'      => [ 't' => 'text', 'l' => __( 'Texto inicial del mensaje', 'wakoo' ), 'd' => __( 'Hola, quiero:', 'wakoo' ), 'c' => [ 'append' => 'yes' ] ],
				'out'      => [ 't' => 'text', 'l' => __( 'Texto "agotado"', 'wakoo' ), 'd' => __( 'Agotado', 'wakoo' ) ],
				'instock'  => [ 't' => 'text', 'l' => __( 'Texto "en stock"', 'wakoo' ), 'd' => __( 'En stock', 'wakoo' ) ],
				'lowtxt'   => [ 't' => 'text', 'l' => __( 'Texto "pocas unidades"', 'wakoo' ), 'd' => __( '¡Quedan pocas!', 'wakoo' ) ],
				'pick'     => [ 't' => 'text', 'l' => __( 'Texto sin elegir', 'wakoo' ), 'd' => __( 'Elige una opción de cada grupo', 'wakoo' ) ],
			] ],
		];
	}

	protected function draw( array $s ) {
		$attrs = [];
		foreach ( (array) $s['attrs'] as $a ) {
			$vals = array_values( array_filter( array_map( 'trim', explode( ',', (string) ( $a['values'] ?? '' ) ) ), 'strlen' ) );
			if ( $vals ) { $attrs[] = [ 'name' => (string) ( $a['name'] ?? '' ), 'values' => $vals ]; }
		}
		$vars = [];
		foreach ( (array) $s['variants'] as $v ) {
			$opts = array_map( 'trim', explode( ',', (string) ( $v['opts'] ?? '' ) ) );
			$vars[] = [ 'o' => $opts, 'p' => (float) ( $v['price'] ?? 0 ), 's' => max( 0, (int) ( $v['stock'] ?? 0 ) ), 'k' => (string) ( $v['sku'] ?? '' ) ];
		}
		$url = ! empty( $s['cta_url']['url'] ) ? esc_url_raw( $s['cta_url']['url'] ) : '';
		$this->open( [
			'name' => (string) $s['name'], 'attrs' => $attrs, 'vars' => $vars,
			'cur' => (string) $s['currency'], 'after' => 'yes' === $s['cur_after'], 'low' => (int) $s['low'],
			'cta' => (string) $s['cta_text'], 'url' => $url, 'blank' => ! empty( $s['cta_url']['is_external'] ),
			'append' => 'yes' === $s['append'], 'param' => preg_replace( '/[^a-z0-9_\-]/i', '', (string) $s['param'] ) ?: 'text', 'msg' => (string) $s['msg'],
			'out' => (string) $s['out'], 'in' => (string) $s['instock'], 'lowtxt' => (string) $s['lowtxt'], 'pick' => (string) $s['pick'],
		] );
		$img = $this->img( $s['image'] );
		echo '<div class="wks-var__wrap">';
		if ( $img ) { echo '<img class="wks-var__img" src="' . $img . '" alt="' . esc_attr( $s['name'] ) . '" loading="lazy">'; }
		echo '<div class="wks-var__body"><h3 class="wks-var__name">' . esc_html( $s['name'] ) . '</h3><div class="wks-var__groups"></div>';
		echo '<div class="wks-var__price" aria-live="polite"></div><div class="wks-var__stock" aria-live="polite"></div><div class="wks-var__cta"></div></div></div>';
		$this->close();
	}
}
