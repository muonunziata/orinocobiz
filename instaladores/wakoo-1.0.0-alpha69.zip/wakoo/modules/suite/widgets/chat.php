<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;
use Wakoo\Modules\Suite\Data;
use Wakoo\Modules\Suite\Sec;

defined( 'ABSPATH' ) || die();

/** 17. Chat guiado estilo WhatsApp (guion de pasos, sin servicios externos). */
class Chat extends Base {

	const MAX_STEPS = 60;
	const MAX_MSGS  = 8;
	const MAX_OPTS  = 8;

	public function slug() { return 'chat'; }
	public function label() { return __( 'Chat guiado', 'wakoo' ); }
	public function icon() { return 'eicon-comments'; }
	public function words() { return [ 'chat', 'whatsapp', 'bot', 'asistente', 'conversacion' ]; }

	protected function sections() {
		return [
			[ 'id' => 'sec_bot', 'label' => __( 'Asistente', 'wakoo' ), 'controls' => [
				'name'   => [ 't' => 'text', 'l' => __( 'Nombre', 'wakoo' ), 'd' => __( 'Asistente', 'wakoo' ) ],
				'status' => [ 't' => 'text', 'l' => __( 'Estado', 'wakoo' ), 'd' => __( 'En línea', 'wakoo' ) ],
				'avatar' => [ 't' => 'media', 'l' => __( 'Avatar', 'wakoo' ) ],
				'mode'   => [ 't' => 'select', 'l' => __( 'Modo', 'wakoo' ), 'o' => [ 'inline' => __( 'En la página', 'wakoo' ), 'float' => __( 'Flotante con botón', 'wakoo' ) ], 'd' => 'inline' ],
				'side'   => [ 't' => 'select', 'l' => __( 'Lado del botón flotante', 'wakoo' ), 'o' => [ 'right' => __( 'Derecha', 'wakoo' ), 'left' => __( 'Izquierda', 'wakoo' ) ], 'd' => 'right' ],
				'launch' => [ 't' => 'text', 'l' => __( 'Texto del botón flotante', 'wakoo' ), 'd' => __( 'Chatea con nosotros', 'wakoo' ) ],
				'delay'  => [ 't' => 'number', 'l' => __( 'Retraso al escribir (ms)', 'wakoo' ), 'd' => 700, 'min' => 0, 'max' => 3000 ],
				'start'  => [ 't' => 'text', 'l' => __( 'ID del paso inicial', 'wakoo' ), 'd' => 'inicio' ],
				'remember' => [ 't' => 'switch', 'l' => __( 'Recordar la conversación del visitante (7 días)', 'wakoo' ), 'd' => 'yes' ],
			] ],
			[ 'id' => 'sec_hours', 'label' => __( 'Horario «en línea»', 'wakoo' ), 'controls' => [
				'hours_on'   => [ 't' => 'switch', 'l' => __( 'Mostrar «en línea» solo en horario', 'wakoo' ), 'd' => '' ],
				'hours_from' => [ 't' => 'text', 'l' => __( 'Desde (HH:MM)', 'wakoo' ), 'd' => '09:00', 'c' => [ 'hours_on' => 'yes' ] ],
				'hours_to'   => [ 't' => 'text', 'l' => __( 'Hasta (HH:MM)', 'wakoo' ), 'd' => '18:00', 'c' => [ 'hours_on' => 'yes' ] ],
				'hours_days' => [ 't' => 'text', 'l' => __( 'Días (1 = lunes … 7 = domingo, separados por coma)', 'wakoo' ), 'd' => '1,2,3,4,5', 'c' => [ 'hours_on' => 'yes' ] ],
				'l_offline'  => [ 't' => 'text', 'l' => __( 'Texto fuera de horario', 'wakoo' ), 'd' => __( 'Fuera de horario', 'wakoo' ), 'c' => [ 'hours_on' => 'yes' ] ],
			] ],
			[ 'id' => 'sec_steps', 'label' => __( 'Pasos', 'wakoo' ), 'controls' => [
				'edit_steps' => [ 't' => 'editor_btn', 'target' => 'steps', 'mode' => 'cards', 'l' => __( 'Abrir editor de pasos', 'wakoo' ) ],
				'steps' => [ 't' => 'repeater', 'title' => '{{{ sid }}}', 'fields' => [
					'sid'      => [ 't' => 'text', 'l' => __( 'ID del paso (sin espacios)', 'wakoo' ), 'd' => 'inicio' ],
					'msg'      => [ 't' => 'textarea', 'l' => __( 'Mensajes del asistente (una línea = un mensaje)', 'wakoo' ), 'd' => '' ],
					'opts'     => [ 't' => 'textarea', 'l' => __( 'Opciones: una por línea, formato Etiqueta>idPaso', 'wakoo' ), 'd' => '' ],
					'act_lbl'  => [ 't' => 'text', 'l' => __( 'Botón de acción (texto, opcional)', 'wakoo' ), 'd' => '' ],
					'act_url'  => [ 't' => 'url', 'l' => __( 'Botón de acción (enlace, opcional)', 'wakoo' ) ],
					'h_media'  => [ 't' => 'heading', 'l' => __( 'Medio y tarjeta (opcional)', 'wakoo' ) ],
					'media'    => [ 't' => 'media', 'l' => __( 'Imagen, vídeo o audio de la biblioteca', 'wakoo' ), 'mt' => [ 'image', 'video', 'audio' ] ],
					'card_img' => [ 't' => 'media', 'l' => __( 'Tarjeta: imagen', 'wakoo' ) ],
					'card_title' => [ 't' => 'text', 'l' => __( 'Tarjeta: título', 'wakoo' ), 'd' => '' ],
					'card_text'  => [ 't' => 'textarea', 'l' => __( 'Tarjeta: texto', 'wakoo' ), 'd' => '', 'rows' => 3 ],
					'card_lbl'   => [ 't' => 'text', 'l' => __( 'Tarjeta: texto del botón', 'wakoo' ), 'd' => '' ],
					'card_url'   => [ 't' => 'url', 'l' => __( 'Tarjeta: enlace del botón', 'wakoo' ) ],
					'h_ask'    => [ 't' => 'heading', 'l' => __( 'Pregunta guiada (recoger un dato)', 'wakoo' ) ],
					'ask'      => [ 't' => 'select', 'l' => __( 'Pedir al visitante', 'wakoo' ), 'd' => '', 'o' => [ '' => __( 'Nada (usar opciones)', 'wakoo' ), 'name' => __( 'Nombre', 'wakoo' ), 'email' => __( 'Email', 'wakoo' ), 'phone' => __( 'Teléfono', 'wakoo' ), 'message' => __( 'Mensaje libre', 'wakoo' ) ] ],
					'ask_ph'   => [ 't' => 'text', 'l' => __( 'Texto de ayuda del campo', 'wakoo' ), 'd' => '', 'c' => [ 'ask!' => '' ] ],
					'ask_next' => [ 't' => 'text', 'l' => __( 'ID del paso siguiente tras responder', 'wakoo' ), 'd' => '', 'c' => [ 'ask!' => '' ] ],
					'send'     => [ 't' => 'switch', 'l' => __( 'Enviar los datos recogidos al llegar a este paso', 'wakoo' ), 'd' => '' ],
				], 'd' => [
					[ 'sid' => 'inicio', 'msg' => "¡Hola! 👋\n¿En qué puedo ayudarte?", 'opts' => "Quiero precios>precios\nNecesito soporte>soporte" ],
					[ 'sid' => 'precios', 'msg' => 'Tenemos planes para cada necesidad.', 'opts' => "Volver>inicio" ],
					[ 'sid' => 'soporte', 'msg' => 'Cuéntanos tu caso y te responderemos pronto.', 'opts' => "Volver>inicio" ],
				] ],
			] ],
			[ 'id' => 'sec_cta', 'label' => __( 'Cierre y textos', 'wakoo' ), 'controls' => [
				'cta_lbl'   => [ 't' => 'text', 'l' => __( 'Texto del botón final (opcional)', 'wakoo' ), 'd' => '' ],
				'cta_url'   => [ 't' => 'url', 'l' => __( 'Enlace final (formulario / WhatsApp)', 'wakoo' ) ],
				'lead_on'   => [ 't' => 'switch', 'l' => __( 'Guardar los datos recogidos en «Mensajes Wakoo» y avisar por email al administrador', 'wakoo' ), 'd' => 'yes' ],
				'l_restart' => [ 't' => 'text', 'l' => __( 'Texto reiniciar', 'wakoo' ), 'd' => __( 'Reiniciar chat', 'wakoo' ) ],
				'l_close'   => [ 't' => 'text', 'l' => __( 'Texto cerrar', 'wakoo' ), 'd' => __( 'Cerrar', 'wakoo' ) ],
				'l_typing'  => [ 't' => 'text', 'l' => __( 'Texto "escribiendo"', 'wakoo' ), 'd' => __( 'Escribiendo…', 'wakoo' ) ],
				'l_send'    => [ 't' => 'text', 'l' => __( 'Texto del botón enviar', 'wakoo' ), 'd' => __( 'Enviar', 'wakoo' ) ],
				'l_sent'    => [ 't' => 'text', 'l' => __( 'Mensaje al enviar los datos', 'wakoo' ), 'd' => __( '¡Gracias! Hemos recibido tus datos.', 'wakoo' ) ],
				'l_fail'    => [ 't' => 'text', 'l' => __( 'Mensaje si falla el envío', 'wakoo' ), 'd' => __( 'No se pudo enviar. Inténtalo más tarde.', 'wakoo' ) ],
				'l_invalid' => [ 't' => 'text', 'l' => __( 'Mensaje de dato no válido', 'wakoo' ), 'd' => __( 'Revisa el dato e inténtalo de nuevo.', 'wakoo' ) ],
			] ],
		];
	}

	private static function sid( $v ) {
		return substr( preg_replace( '/[^a-z0-9_-]/', '', strtolower( remove_accents( (string) $v ) ) ), 0, 40 );
	}

	private static function safe_url( $u ) {
		$u = is_array( $u ) ? (string) ( $u['url'] ?? '' ) : '';
		return '' === $u ? '' : esc_url_raw( $u, [ 'http', 'https', 'mailto', 'tel' ] );
	}

	/** Own media only: a library attachment (by id) or a URL under the uploads folder. Returns [ kind, url ] or null. */
	private static function own_media( $m, array $kinds ) {
		if ( ! is_array( $m ) ) { return null; }
		$id = (int) ( $m['id'] ?? 0 );
		if ( $id ) {
			$mime = (string) get_post_mime_type( $id );
			$url  = wp_get_attachment_url( $id );
		} else {
			$url  = (string) ( $m['url'] ?? '' );
			$up   = wp_get_upload_dir();
			if ( '' === $url || 0 !== strpos( $url, trailingslashit( $up['baseurl'] ) ) ) { return null; }
			$mime = (string) wp_check_filetype( $url )['type'];
		}
		$k = strstr( $mime, '/', true );
		if ( ! $url || ! in_array( $k, $kinds, true ) ) { return null; }
		return [ $k, esc_url_raw( $url, [ 'http', 'https' ] ) ];
	}

	/** Valida y normaliza el guion: ids únicos, opciones con destino válido, límites de tamaño. */
	private function script( array $rows, $start ) {
		$steps = [];
		foreach ( array_slice( $rows, 0, self::MAX_STEPS ) as $r ) {
			$id = self::sid( $r['sid'] ?? '' );
			if ( '' === $id || isset( $steps[ $id ] ) ) { continue; }
			$msgs = [];
			foreach ( preg_split( '/\r\n|\r|\n/', (string) ( $r['msg'] ?? '' ) ) as $l ) {
				$l = trim( wp_strip_all_tags( $l ) );
				if ( '' !== $l ) { $msgs[] = mb_substr( $l, 0, 500 ); }
			}
			$st = [
				'm' => array_slice( $msgs, 0, self::MAX_MSGS ),
				'o' => [],
				'raw' => (string) ( $r['opts'] ?? '' ),
				'al' => mb_substr( sanitize_text_field( $r['act_lbl'] ?? '' ), 0, 60 ),
				'au' => self::safe_url( $r['act_url'] ?? null ),
			];
			$md = self::own_media( $r['media'] ?? null, [ 'image', 'video', 'audio' ] );
			if ( $md ) { $st['md'] = $md; }
			$ct = mb_substr( sanitize_text_field( $r['card_title'] ?? '' ), 0, 80 );
			$cx = mb_substr( sanitize_textarea_field( $r['card_text'] ?? '' ), 0, 300 );
			$ci = self::own_media( $r['card_img'] ?? null, [ 'image' ] );
			if ( '' !== $ct || '' !== $cx || $ci ) {
				$st['c'] = [ 'i' => $ci ? $ci[1] : '', 't' => $ct, 'x' => $cx, 'l' => mb_substr( sanitize_text_field( $r['card_lbl'] ?? '' ), 0, 40 ), 'u' => self::safe_url( $r['card_url'] ?? null ) ];
			}
			$ask = (string) ( $r['ask'] ?? '' );
			if ( in_array( $ask, [ 'name', 'email', 'phone', 'message' ], true ) ) {
				$st['q'] = [ 'f' => $ask, 'p' => mb_substr( sanitize_text_field( $r['ask_ph'] ?? '' ), 0, 80 ), 'n' => self::sid( $r['ask_next'] ?? '' ) ];
			}
			if ( 'yes' === ( $r['send'] ?? '' ) ) { $st['s'] = 1; }
			$steps[ $id ] = $st;
		}
		foreach ( $steps as $id => &$st ) {
			foreach ( preg_split( '/\r\n|\r|\n/', $st['raw'] ) as $l ) {
				$p = strrpos( $l, '>' );
				if ( false === $p ) { continue; }
				$label = mb_substr( sanitize_text_field( substr( $l, 0, $p ) ), 0, 80 );
				$to    = self::sid( substr( $l, $p + 1 ) );
				if ( '' === $label || ! isset( $steps[ $to ] ) ) { continue; } // destino desconocido: se descarta
				$st['o'][] = [ $label, $to ];
				if ( count( $st['o'] ) >= self::MAX_OPTS ) { break; }
			}
			unset( $st['raw'] );
			if ( isset( $st['q'] ) && ! isset( $steps[ $st['q']['n'] ] ) ) { $st['q']['n'] = ''; }
		}
		unset( $st );
		$start = self::sid( $start );
		if ( ! isset( $steps[ $start ] ) ) { $start = $steps ? (string) array_key_first( $steps ) : ''; }
		return [ $steps, $start ];
	}

	private static function hhmm( $v, $def ) {
		return preg_match( '/^([01]?\d|2[0-3]):([0-5]\d)$/', trim( (string) $v ) ) ? trim( (string) $v ) : $def;
	}

	protected function draw( array $s ) {
		list( $steps, $start ) = $this->script( array_values( (array) ( $s['steps'] ?? [] ) ), $s['start'] ?? '' );
		if ( ! $steps ) { return; }
		$float = 'float' === $s['mode'];
		$av    = $this->img( $s['avatar'] ?? null );
		$lead  = false;
		foreach ( $steps as $st ) { if ( ! empty( $st['s'] ) ) { $lead = true; } }
		$hours = null;
		if ( 'yes' === ( $s['hours_on'] ?? '' ) ) {
			$days  = array_values( array_filter( array_map( 'intval', explode( ',', (string) $s['hours_days'] ) ), static function ( $d ) { return $d >= 1 && $d <= 7; } ) );
			$hours = [ 'from' => self::hhmm( $s['hours_from'], '09:00' ), 'to' => self::hhmm( $s['hours_to'], '18:00' ), 'days' => $days ?: [ 1, 2, 3, 4, 5, 6, 7 ], 'tz' => wp_timezone_string(), 'off' => (string) $s['l_offline'] ];
		}
		$cfg   = [
			'steps'   => $steps,
			'start'   => $start,
			'float'   => $float,
			'delay'   => max( 0, min( 3000, (int) $s['delay'] ) ),
			'cta'     => [ mb_substr( sanitize_text_field( $s['cta_lbl'] ), 0, 60 ), self::safe_url( $s['cta_url'] ?? null ) ],
			'restart' => (string) $s['l_restart'],
			'typing'  => (string) $s['l_typing'],
			'send'    => (string) $s['l_send'],
			'sent'    => (string) $s['l_sent'],
			'fail'    => (string) $s['l_fail'],
			'invalid' => (string) $s['l_invalid'],
			'lead'    => $lead && 'yes' === ( $s['lead_on'] ?? 'yes' ),
			'keep'    => 'yes' === ( $s['remember'] ?? 'yes' ),
			'rev'     => substr( md5( wp_json_encode( $steps ) . $start ), 0, 8 ),
			'status'  => (string) $s['status'],
			'hours'   => $hours,
		];
		$this->open( $cfg, ( $float ? 'is-float wks-chat--' . ( 'left' === $s['side'] ? 'left' : 'right' ) : '' ) );
		$uid = 'wks-chat-' . esc_attr( $this->get_id() );
		if ( $float ) {
			echo '<button type="button" class="wks-chat__launch wks-btn" aria-expanded="false" aria-controls="' . $uid . '">' . esc_html( $s['launch'] ) . '</button>';
		}
		echo '<div class="wks-chat__box" id="' . $uid . '" role="' . ( $float ? 'dialog' : 'region' ) . '" aria-label="' . esc_attr( $s['name'] ) . '"' . ( $float ? ' hidden' : '' ) . '>';
		echo '<div class="wks-chat__head">';
		if ( $av ) { echo '<span class="wks-chat__ava"><img class="wks-chat__avatar" src="' . $av . '" alt="" width="40" height="40" loading="lazy"><i class="wks-chat__dot" aria-hidden="true"></i></span>'; }
		echo '<div class="wks-chat__who"><strong>' . esc_html( $s['name'] ) . '</strong><small class="wks-chat__status">' . esc_html( $s['status'] ) . '</small></div>';
		echo '<button type="button" class="wks-chat__restart" data-a="restart" aria-label="' . esc_attr( $s['l_restart'] ) . '" title="' . esc_attr( $s['l_restart'] ) . '">↺</button>';
		if ( $float ) { echo '<button type="button" class="wks-chat__x" data-a="close" aria-label="' . esc_attr( $s['l_close'] ) . '">×</button>'; }
		echo '</div><div class="wks-chat__log" role="log" aria-live="polite" aria-relevant="additions"></div><div class="wks-chat__opts"></div></div>';
		$this->close();
	}

	/* ------------------------------------------------------------ server */

	public static function routes() {
		Sec::route( 'chat/lead', 'POST', static function ( \WP_REST_Request $r ) {
			if ( ! Sec::human( $r, 1500 ) ) { return Sec::err( 'Inténtalo de nuevo', 400 ); }
			if ( ! Sec::rate( 'chat-lead', 5, 900 ) ) { return Sec::err( 'Demasiadas peticiones', 429 ); }
			$post = Sec::int( $r->get_param( 'post' ), 0 );
			$w    = Sec::text( $r->get_param( 'w' ), 32 );
			$s    = Data::widget( $post, $w, 'wakoo-chat' );
			if ( null === $s || 'yes' !== ( $s['lead_on'] ?? 'yes' ) ) { return Sec::err( 'No encontrado', 404 ); }
			$f     = (array) $r->get_param( 'fields' );
			$vals  = [];
			$name  = Sec::text( $f['name'] ?? '', 80 );
			$email = sanitize_email( Sec::text( $f['email'] ?? '', 120 ) );
			$phone = preg_replace( '/[^0-9+()\-\s.]/', '', Sec::text( $f['phone'] ?? '', 30 ) );
			$msg   = Sec::area( $f['message'] ?? '', 1000 );
			if ( '' !== $email && ! is_email( $email ) ) { return Sec::err( 'Email no válido', 400 ); }
			if ( '' === $name . $email . $phone . $msg ) { return Sec::err( 'Sin datos', 400 ); }
			$path = Sec::text( $r->get_param( 'path' ), 600 );
			foreach ( [ 'Nombre' => $name, 'Email' => $email, 'Teléfono' => $phone, 'Mensaje' => $msg, 'Recorrido del chat' => $path ] as $k => $v ) {
				if ( '' !== $v ) { $vals[ $k ] = $v; }
			}
			if ( post_type_exists( 'wakoo_submission' ) ) {
				$pid = wp_insert_post( [ 'post_type' => 'wakoo_submission', 'post_status' => 'publish', 'post_title' => sprintf( '%s — %s', __( 'Chat guiado', 'wakoo' ), current_time( 'Y-m-d H:i' ) ) ] );
				if ( $pid && ! is_wp_error( $pid ) ) {
					update_post_meta( $pid, '_wakoo_fields', $vals );
					update_post_meta( $pid, '_wakoo_files', [] );
					update_post_meta( $pid, '_wakoo_meta', [ 'ip' => '', 'page' => esc_url_raw( (string) get_permalink( $post ) ), 'time' => current_time( 'mysql' ), 'form' => __( 'Chat guiado', 'wakoo' ) ] );
				}
			}
			$lines = [];
			foreach ( $vals as $k => $v ) { $lines[] = $k . ': ' . $v; }
			$hdr = $email ? [ 'Reply-To: ' . $email ] : [];
			wp_mail( get_option( 'admin_email' ), __( 'Nuevo contacto desde el chat', 'wakoo' ), implode( "\n", $lines ) . "\n\n" . get_permalink( $post ), $hdr );
			return Sec::ok();
		} );
	}
}
