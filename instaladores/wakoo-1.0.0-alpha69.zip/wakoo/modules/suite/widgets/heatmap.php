<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;
use Wakoo\Modules\Suite\Data;
use Wakoo\Modules\Suite\Sec;

defined( 'ABSPATH' ) || die();

/** 14. Mapa de calor de clics propio: invisible para el visitante, visible como capa solo para administradores. */
class Heatmap extends Base {

	const CRON = 'wakoo_heatmap_prune';
	const DAYS = 'wakoo_heatmap_days';

	public function slug() { return 'heatmap'; }
	public function label() { return __( 'Mapa de calor de clics', 'wakoo' ); }
	public function cat() { return 'data'; }
	public function icon() { return 'eicon-flash'; }
	public function words() { return [ 'heatmap', 'mapa de calor', 'clics', 'clicks' ]; }

	protected function sections() {
		return [
			[ 'id' => 'sec_rec', 'label' => __( 'Registro de clics', 'wakoo' ), 'controls' => [
				'note'   => [ 't' => 'note', 'l' => __( 'Al poner este widget, la página registra los clics de los visitantes (solo posición, sin datos personales, sin cookies). El visitante no ve nada; tú, con sesión de administrador, verás el botón "Ver mapa de calor".', 'wakoo' ) ],
				'sample' => [ 't' => 'number', 'l' => __( 'Visitantes registrados (%)', 'wakoo' ), 'd' => 100, 'min' => 1, 'max' => 100, 'desc' => __( 'Muestreo: 100 registra a todos; 20 registra a 1 de cada 5.', 'wakoo' ) ],
				'max'    => [ 't' => 'number', 'l' => __( 'Máx. clics por visitante y página', 'wakoo' ), 'd' => 20, 'min' => 1, 'max' => 100 ],
				'days'   => [ 't' => 'number', 'l' => __( 'Guardar los clics (días)', 'wakoo' ), 'd' => 30, 'min' => 1, 'max' => 365 ],
			] ],
			[ 'id' => 'sec_adm', 'label' => __( 'Vista de administrador', 'wakoo' ), 'controls' => [
				'btn'     => [ 't' => 'text', 'l' => __( 'Texto del botón', 'wakoo' ), 'd' => __( 'Ver mapa de calor', 'wakoo' ) ],
				'btn_off' => [ 't' => 'text', 'l' => __( 'Texto para ocultar', 'wakoo' ), 'd' => __( 'Ocultar mapa de calor', 'wakoo' ) ],
				'radius'  => [ 't' => 'number', 'l' => __( 'Radio de cada clic (px)', 'wakoo' ), 'd' => 38, 'min' => 10, 'max' => 120 ],
			] ],
		];
	}

	protected function draw( array $s ) {
		$edit = \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode();
		$this->open( [
			'sample' => Sec::int( $s['sample'], 1, 100 ),
			'max'    => Sec::int( $s['max'], 1, 100 ),
			'btn'    => (string) $s['btn'], 'btn_off' => (string) $s['btn_off'],
			'radius' => Sec::int( $s['radius'], 10, 120 ),
			'edit'   => (bool) $edit,
			'l'      => [ 'mobile' => __( 'Móvil', 'wakoo' ), 'tablet' => __( 'Tableta', 'wakoo' ), 'desktop' => __( 'Escritorio', 'wakoo' ), 'clicks' => __( 'clics', 'wakoo' ), 'none' => __( 'Sin datos todavía', 'wakoo' ) ],
		], $edit ? 'is-edit' : '' );
		if ( $edit ) {
			echo '<div class="wks-card"><b>' . esc_html__( 'Mapa de calor activo en esta página', 'wakoo' ) . '</b><p>' . esc_html__( 'Los visitantes no ven este bloque. Con sesión de administrador, en la página publicada aparece el botón para ver el mapa.', 'wakoo' ) . '</p></div>';
		}
		$this->close();
	}

	/* ------------------------------------------------------------ server */

	private static function conf( $post, $w ) {
		$s = Data::widget( $post, $w, 'wakoo-heatmap' );
		if ( null === $s ) { return null; }
		$wt = \Elementor\Plugin::$instance->widgets_manager->get_widget_types( 'wakoo-heatmap' );
		if ( $wt ) {
			foreach ( $wt->get_controls() as $id => $c ) {
				if ( ! isset( $s[ $id ] ) && isset( $c['default'] ) ) { $s[ $id ] = $c['default']; }
			}
		}
		return $s;
	}

	private static function bucket( $b ) { return in_array( $b, [ 'mobile', 'tablet', 'desktop' ], true ) ? $b : 'desktop'; }

	public static function boot() {
		add_action( self::CRON, [ __CLASS__, 'prune' ] );
		if ( ! wp_next_scheduled( self::CRON ) ) { wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON ); }
	}

	/** Daily: deletes clicks older than the retention set in the widget (last value saved while recording). */
	public static function prune() {
		global $wpdb;
		$days = Sec::int( get_option( self::DAYS, 30 ), 1, 365 );
		$t    = $wpdb->prefix . 'wakoo_clicks';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$t} WHERE created < %s", gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ) );
	}

	public static function routes() {
		// Click recording (public). Points are [x in hundredths of % of the page width, y in px from the top of the page].
		Sec::route( 'heatmap/click', 'POST', static function ( \WP_REST_Request $r ) {
			global $wpdb;
			if ( ! Sec::rate( 'hm-click', 40, 600 ) ) { return new \WP_REST_Response( null, 204 ); }
			$post = Sec::int( $r->get_param( 'post' ), 0 );
			$w    = Sec::text( $r->get_param( 'w' ), 32 );
			$s    = self::conf( $post, $w );
			if ( ! $s ) { return Sec::err( 'No encontrado', 404 ); }
			$b    = self::bucket( Sec::text( $r->get_param( 'b' ), 8 ) );
			$max  = Sec::int( $s['max'], 1, 100 );
			$qkey = 'wks_hmq_' . md5( $post . '|' . $b . '|' . Sec::visitor() );
			$used = (int) get_transient( $qkey );
			$room = max( 0, $max - $used );
			$pts  = array_slice( (array) $r->get_param( 'pts' ), 0, min( 10, $room ) );
			$rows = [];
			foreach ( $pts as $p ) {
				if ( ! is_array( $p ) || count( $p ) < 2 ) { continue; }
				$x = (int) $p[0]; $y = (int) $p[1];
				if ( $x < 0 || $x > 10000 || $y < 0 || $y > 200000 ) { continue; }
				$rows[] = $wpdb->prepare( '(%d,%s,%d,%d,%s)', $post, $b, $x, $y, current_time( 'mysql', true ) );
			}
			if ( ! $rows ) { return new \WP_REST_Response( null, 204 ); }
			$t = $wpdb->prefix . 'wakoo_clicks';
			// Hard cap per page so the table cannot grow without bound.
			$ck = 'wks_hmc_' . $post;
			$n  = get_transient( $ck );
			if ( false === $n ) { $n = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE post_id=%d", $post ) ); set_transient( $ck, $n, 300 ); } // phpcs:ignore
			if ( $n >= 60000 ) { return new \WP_REST_Response( null, 204 ); }
			$wpdb->query( "INSERT INTO {$t} (post_id,bucket,x,y,created) VALUES " . implode( ',', $rows ) ); // phpcs:ignore
			set_transient( $qkey, $used + count( $rows ), DAY_IN_SECONDS );
			set_transient( $ck, $n + count( $rows ), 300 );
			update_option( self::DAYS, Sec::int( $s['days'], 1, 365 ), false );
			return new \WP_REST_Response( null, 204 );
		} );

		// Aggregated points for the overlay (administrators only; cookie nonce enforced by core).
		Sec::route_admin( 'heatmap/data', 'GET', static function ( \WP_REST_Request $r ) {
			global $wpdb;
			$post = Sec::int( $r->get_param( 'post' ), 0 );
			$b    = self::bucket( Sec::text( $r->get_param( 'b' ), 8 ) );
			$t    = $wpdb->prefix . 'wakoo_clicks';
			// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$pts   = $wpdb->get_results( $wpdb->prepare( "SELECT ROUND(x/40)*40 AS x, ROUND(y/8)*8 AS y, COUNT(*) AS c FROM {$t} WHERE post_id=%d AND bucket=%s GROUP BY 1,2 ORDER BY c DESC LIMIT 5000", $post, $b ), ARRAY_N );
			$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE post_id=%d AND bucket=%s", $post, $b ) );
			// phpcs:enable
			return Sec::ok( [ 'total' => $total, 'pts' => array_map( static function ( $p ) { return [ (int) $p[0], (int) $p[1], (int) $p[2] ]; }, (array) $pts ) ] );
		} );
	}
}
