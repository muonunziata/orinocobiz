<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;

defined( 'ABSPATH' ) || die();

/** 6. Tabla de datos con orden, búsqueda, filtros, grupos, paginación y exportación. */
class Datatable extends Base {

	const MAX_ROWS = 2000;
	const MAX_COLS = 30;
	const MAX_CELL = 300;

	public function slug() { return 'datatable'; }
	public function label() { return __( 'Tabla de datos', 'wakoo' ); }
	public function cat() { return 'data'; }
	public function icon() { return 'eicon-table'; }
	public function words() { return [ 'tabla', 'csv', 'datos', 'table', 'filtros' ]; }

	protected function sections() {
		$sample = "Producto,Categoría,Precio,Fecha\nCamiseta,Ropa,19.90,2026-01-12\nGorra,Ropa,12.50,2026-02-03\nTaza,Hogar,8.00,2026-01-30\nLámpara,Hogar,34.00,2026-03-15\nMochila,Accesorios,42.90,2026-02-20\nCartera,Accesorios,25.00,2026-03-01";
		return [
			[ 'id' => 'sec_data', 'label' => __( 'Datos', 'wakoo' ), 'controls' => [
				'edit'   => [ 't' => 'editor_btn', 'l' => __( 'Editar como hoja (insertar filas y columnas)', 'wakoo' ) ],
				'sheet'  => [ 't' => 'hidden', 'd' => '' ],
				'source' => [ 't' => 'select', 'l' => __( 'Origen', 'wakoo' ), 'd' => 'text', 'o' => [ 'text' => __( 'Pegar CSV', 'wakoo' ), 'file' => __( 'Archivo CSV de la biblioteca', 'wakoo' ) ] ],
				'csv'    => [ 't' => 'textarea', 'l' => __( 'Datos CSV', 'wakoo' ), 'd' => $sample, 'rows' => 10, 'c' => [ 'source' => 'text' ] ],
				'file'   => [ 't' => 'media', 'l' => __( 'Archivo CSV', 'wakoo' ), 'c' => [ 'source' => 'file' ], 'desc' => __( 'Sube un .csv a la biblioteca (máx. 1 MB).', 'wakoo' ) ],
				'delim'  => [ 't' => 'select', 'l' => __( 'Separador', 'wakoo' ), 'd' => ',', 'o' => [ ',' => __( 'Coma (,)', 'wakoo' ), ';' => __( 'Punto y coma (;)', 'wakoo' ), 'tab' => __( 'Tabulador', 'wakoo' ), '|' => __( 'Barra (|)', 'wakoo' ) ] ],
				'header' => [ 't' => 'switch', 'l' => __( 'La primera fila es el encabezado', 'wakoo' ), 'd' => 'yes' ],
			] ],
			[ 'id' => 'sec_opts', 'label' => __( 'Herramientas', 'wakoo' ), 'controls' => [
				'search'    => [ 't' => 'switch', 'l' => __( 'Buscador', 'wakoo' ), 'd' => 'yes' ],
				'ph'        => [ 't' => 'text', 'l' => __( 'Texto del buscador', 'wakoo' ), 'd' => __( 'Buscar…', 'wakoo' ), 'c' => [ 'search' => 'yes' ] ],
				'filters'   => [ 't' => 'text', 'l' => __( 'Columnas con filtro (números separados por coma)', 'wakoo' ), 'd' => '2', 'desc' => __( 'Ej.: 2,4 muestra un desplegable en esas columnas.', 'wakoo' ) ],
				'group_col' => [ 't' => 'number', 'l' => __( 'Agrupar por columna (0 = sin grupos)', 'wakoo' ), 'd' => 0, 'min' => 0, 'max' => 30 ],
				'page_size' => [ 't' => 'number', 'l' => __( 'Filas por página (0 = todas)', 'wakoo' ), 'd' => 5, 'min' => 0, 'max' => 200 ],
				'export'    => [ 't' => 'switch', 'l' => __( 'Botón exportar CSV', 'wakoo' ), 'd' => 'yes' ],
				'striped'   => [ 't' => 'switch', 'l' => __( 'Filas alternas', 'wakoo' ), 'd' => 'yes' ],
				'l_all'     => [ 't' => 'text', 'l' => __( 'Texto "Todos" de los filtros', 'wakoo' ), 'd' => __( 'Todos', 'wakoo' ) ],
				'l_export'  => [ 't' => 'text', 'l' => __( 'Texto exportar', 'wakoo' ), 'd' => __( 'Exportar CSV', 'wakoo' ) ],
				'l_empty'   => [ 't' => 'text', 'l' => __( 'Sin resultados', 'wakoo' ), 'd' => __( 'No hay resultados.', 'wakoo' ) ],
				'l_prev'    => [ 't' => 'text', 'l' => __( 'Anterior', 'wakoo' ), 'd' => __( 'Anterior', 'wakoo' ) ],
				'l_next'    => [ 't' => 'text', 'l' => __( 'Siguiente', 'wakoo' ), 'd' => __( 'Siguiente', 'wakoo' ) ],
			] ],
		];
	}

	/** Reads and parses the CSV into [ rows ] with caps; returns [] if unreadable. */
	private function parse( array $s ) {
		$raw = '';
		if ( 'file' === ( $s['source'] ?? 'text' ) ) {
			$id = (int) ( $s['file']['id'] ?? 0 );
			$path = $id ? get_attached_file( $id ) : '';
			if ( $path && is_readable( $path ) && filesize( $path ) <= 1048576 && preg_match( '/\.(csv|txt)$/i', $path ) ) {
				$raw = (string) file_get_contents( $path ); // phpcs:ignore
			}
		} else {
			$raw = (string) ( $s['csv'] ?? '' );
		}
		$raw = mb_substr( str_replace( [ "\r\n", "\r" ], "\n", $raw ), 0, 1048576 );
		if ( 0 === strpos( $raw, "\xEF\xBB\xBF" ) ) { $raw = substr( $raw, 3 ); }
		$d = $s['delim'] ?? ',';
		$d = 'tab' === $d ? "\t" : ( in_array( $d, [ ',', ';', '|' ], true ) ? $d : ',' );
		$rows = [];
		foreach ( explode( "\n", $raw ) as $line ) {
			if ( '' === trim( $line ) ) { continue; }
			$cells = array_slice( str_getcsv( $line, $d, '"', '\\' ), 0, self::MAX_COLS );
			$rows[] = array_map( static function ( $c ) { return mb_substr( trim( wp_strip_all_tags( (string) $c ) ), 0, Datatable::MAX_CELL ); }, $cells );
			if ( count( $rows ) > self::MAX_ROWS ) { break; }
		}
		return $rows;
	}

	/** Rows saved by the spreadsheet editor: [ head, row, row… ] or null when the sheet is empty/invalid. */
	private function sheet( array $s ) {
		$j = self::json_in( $s['sheet'] ?? '' );
		if ( ! $j || ! isset( $j['head'] ) || ! is_array( $j['head'] ) ) { return null; }
		$cols = min( self::MAX_COLS, max( 1, count( $j['head'] ) ) );
		$rows = [ array_slice( array_map( [ __CLASS__, 'cell' ], $j['head'] ), 0, $cols ) ];
		foreach ( array_slice( (array) ( $j['rows'] ?? [] ), 0, self::MAX_ROWS ) as $r ) {
			if ( ! is_array( $r ) ) { continue; }
			$rows[] = array_slice( array_map( [ __CLASS__, 'cell' ], array_values( $r ) ), 0, $cols );
		}
		return $rows;
	}

	protected function draw( array $s ) {
		$rows = $this->sheet( $s );
		$from_sheet = null !== $rows;
		if ( ! $from_sheet ) { $rows = $this->parse( $s ); }
		if ( ! $rows ) {
			echo '<p>' . esc_html__( 'Sin datos. Pega un CSV en el widget.', 'wakoo' ) . '</p>';
			return;
		}
		$cols   = max( array_map( 'count', $rows ) );
		$header = ( $from_sheet || 'yes' === $s['header'] ) ? array_shift( $rows ) : [];
		$filters = array_values( array_filter( array_map( 'intval', explode( ',', (string) $s['filters'] ) ), static function ( $n ) use ( $cols ) { return $n >= 1 && $n <= $cols; } ) );
		$group = max( 0, min( $cols, (int) $s['group_col'] ) );
		$this->open( [
			'filters' => $filters,
			'group'   => $group,
			'page'    => max( 0, min( 200, (int) $s['page_size'] ) ),
			'all'     => (string) $s['l_all'],
			'empty'   => (string) $s['l_empty'],
			'prev'    => (string) $s['l_prev'],
			'next'    => (string) $s['l_next'],
		], 'yes' === $s['striped'] ? 'is-striped' : '' );

		$this->edit_btn( __( 'Editar tabla', 'wakoo' ) );
		echo '<div class="wks-dt__bar">';
		if ( 'yes' === $s['search'] ) {
			echo '<input type="search" class="wks-dt__search" placeholder="' . esc_attr( $s['ph'] ) . '" aria-label="' . esc_attr( $s['ph'] ) . '">';
		}
		echo '<span class="wks-dt__filters"></span>';
		if ( 'yes' === $s['export'] ) {
			echo '<button type="button" class="wks-btn wks-dt__export">' . esc_html( $s['l_export'] ) . '</button>';
		}
		echo '</div><div class="wks-dt__wrap"><table class="wks-dt__table">';
		if ( $header ) {
			echo '<thead><tr>';
			for ( $i = 0; $i < $cols; $i++ ) {
				echo '<th scope="col" aria-sort="none"><button type="button" class="wks-dt__sort">' . esc_html( $header[ $i ] ?? '' ) . '<span aria-hidden="true"></span></button></th>';
			}
			echo '</tr></thead>';
		}
		echo '<tbody>';
		foreach ( $rows as $r ) {
			echo '<tr>';
			for ( $i = 0; $i < $cols; $i++ ) { echo '<td>' . esc_html( $r[ $i ] ?? '' ) . '</td>'; }
			echo '</tr>';
		}
		echo '</tbody></table></div><p class="wks-dt__none" hidden>' . esc_html( $s['l_empty'] ) . '</p><nav class="wks-dt__pager" aria-label="' . esc_attr__( 'Paginación', 'wakoo' ) . '"></nav>';
		$this->close();
	}
}
