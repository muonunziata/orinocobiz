<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;

defined( 'ABSPATH' ) || die();

/** Anillo 3D de fotos y vídeos: gira solo, se arrastra con inercia y reproduce el vídeo de la tarjeta frontal. Solo se descarga la portada hasta pulsar «reproducir». */
class Carousel3d extends Base {

	const MAX_CARDS = 24;

	public function slug() { return 'carousel-3d'; }
	public function label() { return __( 'Carrusel 3D de fotos y vídeos', 'wakoo' ); }
	public function cat() { return 'media'; }
	public function icon() { return 'eicon-slider-3d'; }
	public function words() { return [ 'carrusel', '3d', 'anillo', 'ring', 'fotos', 'video', 'visor', 'cover flow' ]; }

	private static function demo( $f ) { return [ 'url' => WAKOO_MODULES_URL . 'suite/assets/demo/' . $f, 'id' => 0 ]; }

	protected function sections() {
		$items = [];
		for ( $i = 1; $i <= 6; $i++ ) {
			$items[] = [ 'kind' => ( 2 === $i || 5 === $i ) ? 'video' : 'image', 'image' => self::demo( 'photo-' . $i . '.svg' ), 'title' => sprintf( __( 'Diapositiva %d', 'wakoo' ), $i ) ];
		}
		return [
			[ 'id' => 'sec_items', 'label' => __( 'Diapositivas', 'wakoo' ), 'controls' => [
				'note_items' => [ 't' => 'note', 'l' => __( 'En una diapositiva de vídeo solo se descarga la imagen (portada). El vídeo se carga al pulsar «reproducir» en la tarjeta frontal. Las diapositivas de vídeo de ejemplo no tienen archivo: sube el tuyo.', 'wakoo' ) ],
				'items' => [ 't' => 'repeater', 'title' => '{{{ title }}}', 'fields' => [
					'kind'   => [ 't' => 'select', 'l' => __( 'Tipo', 'wakoo' ), 'd' => 'image', 'o' => [ 'image' => __( 'Foto', 'wakoo' ), 'video' => __( 'Vídeo', 'wakoo' ) ] ],
					'image'  => [ 't' => 'media', 'l' => __( 'Foto o portada del vídeo', 'wakoo' ), 'd' => [ 'url' => '' ] ],
					'video'  => [ 't' => 'media', 'mt' => [ 'video' ], 'l' => __( 'Vídeo (biblioteca)', 'wakoo' ), 'd' => [ 'url' => '' ], 'c' => [ 'kind' => 'video' ] ],
					'video_url' => [ 't' => 'url', 'l' => __( 'o enlace a un .mp4 / .webm propio', 'wakoo' ), 'c' => [ 'kind' => 'video' ] ],
					'title'  => [ 't' => 'text', 'l' => __( 'Título / texto alternativo', 'wakoo' ), 'd' => '' ],
				], 'd' => $items ],
			] ],
			[ 'id' => 'sec_layout', 'label' => __( 'Diseño', 'wakoo' ), 'controls' => [
				'ratio' => [ 't' => 'select', 'l' => __( 'Proporción', 'wakoo' ), 'd' => '4 / 3', 'o' => [ '4 / 3' => '4:3', '16 / 9' => '16:9', '1 / 1' => '1:1', '3 / 4' => '3:4', '9 / 16' => '9:16' ], 'sel' => [ '{{WRAPPER}} .wks-c3' => '--c3-ratio: {{VALUE}};' ] ],
				'full'  => [ 't' => 'switch', 'l' => __( 'Ocupar todo el ancho de la pantalla', 'wakoo' ), 'd' => 'yes' ],
				'card_w' => [ 't' => 'number', 'l' => __( 'Ancho de cada tarjeta (% de la pantalla)', 'wakoo' ), 'd' => 36, 'min' => 12, 'max' => 70, 'sel' => [ '{{WRAPPER}} .wks-c3' => '--c3-w: {{VALUE}}vw;' ] ],
				'persp' => [ 't' => 'number', 'l' => __( 'Profundidad 3D (px)', 'wakoo' ), 'd' => 2200, 'min' => 600, 'max' => 5000, 'sel' => [ '{{WRAPPER}} .wks-c3' => '--c3-persp: {{VALUE}}px;' ] ],
				'captions' => [ 't' => 'switch', 'l' => __( 'Mostrar el título de la tarjeta frontal', 'wakoo' ), 'd' => 'yes' ],
			] ],
			[ 'id' => 'sec_motion', 'label' => __( 'Movimiento y controles', 'wakoo' ), 'controls' => [
				'auto'  => [ 't' => 'switch', 'l' => __( 'Girar solo', 'wakoo' ), 'd' => 'yes', 'desc' => __( 'No gira solo si el visitante pide «reducir movimiento».', 'wakoo' ) ],
				'speed' => [ 't' => 'number', 'l' => __( 'Velocidad (grados por segundo)', 'wakoo' ), 'd' => 12, 'min' => 1, 'max' => 60, 'c' => [ 'auto' => 'yes' ] ],
				'controls' => [ 't' => 'switch', 'l' => __( 'Mostrar flechas y botón de pausa', 'wakoo' ), 'd' => 'yes' ],
			] ],
			[ 'id' => 'sec_text', 'label' => __( 'Textos', 'wakoo' ), 'controls' => [
				'label'    => [ 't' => 'text', 'l' => __( 'Descripción accesible del carrusel', 'wakoo' ), 'd' => __( 'Carrusel 3D de fotos y vídeos', 'wakoo' ) ],
				'lbl_prev' => [ 't' => 'text', 'l' => __( 'Etiqueta «anterior»', 'wakoo' ), 'd' => __( 'Anterior', 'wakoo' ) ],
				'lbl_next' => [ 't' => 'text', 'l' => __( 'Etiqueta «siguiente»', 'wakoo' ), 'd' => __( 'Siguiente', 'wakoo' ) ],
				'lbl_pause' => [ 't' => 'text', 'l' => __( 'Texto «pausar»', 'wakoo' ), 'd' => __( 'Pausar', 'wakoo' ) ],
				'lbl_play' => [ 't' => 'text', 'l' => __( 'Texto «girar»', 'wakoo' ), 'd' => __( 'Girar', 'wakoo' ) ],
				'lbl_video' => [ 't' => 'text', 'l' => __( 'Etiqueta «reproducir vídeo»', 'wakoo' ), 'd' => __( 'Reproducir vídeo', 'wakoo' ) ],
				'lbl_slide' => [ 't' => 'text', 'l' => __( 'Etiqueta de diapositiva (usa %1$d y %2$d)', 'wakoo' ), 'd' => __( 'Diapositiva %1$d de %2$d', 'wakoo' ) ],
			] ],
		];
	}

	protected function draw( array $s ) {
		$items = array_values( array_filter( (array) $s['items'], 'is_array' ) );
		$items = array_slice( $items, 0, self::MAX_CARDS );
		$n     = max( 3, count( $items ) );
		$this->open( [
			'auto' => 'yes' === $s['auto'] ? 1 : 0, 'speed' => (float) $s['speed'],
			'pause' => wp_strip_all_tags( $s['lbl_pause'] ), 'play' => wp_strip_all_tags( $s['lbl_play'] ),
		], 'wks-c3' . ( 'yes' === $s['full'] ? ' is-full' : '' ) );
		echo '<div class="wks-c3__view" tabindex="0" role="group" aria-roledescription="carousel" aria-label="' . esc_attr( $s['label'] ) . '"><div class="wks-c3__ring">';
		for ( $i = 0; $i < $n; $i++ ) {
			$it    = $items ? $items[ $i % count( $items ) ] : [];
			$img   = $this->img( $it['image'] ?? [] );
			$kind  = 'video' === ( $it['kind'] ?? '' ) ? 'video' : 'image';
			$vurl  = ! empty( $it['video']['url'] ) ? $it['video']['url'] : ( $it['video_url']['url'] ?? '' );
			$vurl  = ( 'video' === $kind && $vurl ) ? esc_url_raw( $vurl, [ 'http', 'https' ] ) : '';
			$title = (string) ( $it['title'] ?? '' );
			echo '<div class="wks-c3__card k' . (int) ( ( $i % 6 ) + 1 ) . '" role="group" aria-roledescription="' . esc_attr__( 'diapositiva', 'wakoo' ) . '" aria-label="' . esc_attr( sprintf( $s['lbl_slide'], $i + 1, $n ) ) . '" data-title="' . esc_attr( $title ) . '"' . ( $vurl ? ' data-video="' . esc_attr( $vurl ) . '"' : '' ) . ( $img ? ' data-poster="' . esc_attr( esc_url_raw( $it['image']['url'], [ 'http', 'https' ] ) ) . '"' : '' ) . '>';
			if ( $img ) { echo '<img src="' . $img . '" alt="' . esc_attr( $title ) . '" loading="lazy" decoding="async" draggable="false">'; } else { echo '<span class="wks-c3__no">' . esc_html( str_pad( (string) ( $i + 1 ), 2, '0', STR_PAD_LEFT ) ) . '</span>'; }
			if ( $vurl ) { echo '<button type="button" class="wks-c3__play" tabindex="-1" aria-label="' . esc_attr( $s['lbl_video'] . ( $title ? ': ' . $title : '' ) ) . '"><svg viewBox="0 0 24 24" width="28" height="28" aria-hidden="true"><path d="M8 5v14l11-7z" fill="currentColor"/></svg></button>'; }
			echo '</div>';
		}
		echo '</div></div>';
		if ( 'yes' === $s['captions'] ) { echo '<p class="wks-c3__cap" aria-live="polite"></p>'; }
		if ( 'yes' === $s['controls'] ) {
			echo '<div class="wks-c3__ctl"><button type="button" class="wks-btn wks-btn--ghost" data-act="prev" aria-label="' . esc_attr( $s['lbl_prev'] ) . '">&larr;</button><button type="button" class="wks-btn wks-btn--ghost" data-act="next" aria-label="' . esc_attr( $s['lbl_next'] ) . '">&rarr;</button><button type="button" class="wks-btn wks-btn--ghost" data-act="toggle" aria-pressed="false">' . esc_html( $s['lbl_pause'] ) . '</button></div>';
		}
		$this->close();
	}
}
