<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;

defined( 'ABSPATH' ) || die();

/** 4. Línea de tiempo vertical u horizontal con animación al aparecer, agrupada por épocas. */
class Timeline extends Base {

	public function slug() { return 'timeline'; }
	public function label() { return __( 'Línea de tiempo', 'wakoo' ); }
	public function cat() { return 'media'; }
	public function icon() { return 'eicon-time-line'; }
	public function words() { return [ 'timeline', 'historia', 'cronologia', 'hitos' ]; }

	private static function demo( $f ) { return [ 'url' => WAKOO_MODULES_URL . 'suite/assets/demo/' . $f, 'id' => 0 ]; }

	protected function sections() {
		return [
			[ 'id' => 'sec_items', 'label' => __( 'Hitos', 'wakoo' ), 'controls' => [
				'items' => [ 't' => 'repeater', 'title' => '{{{ date }}} · {{{ title }}}', 'fields' => [
					'group' => [ 't' => 'text', 'l' => __( 'Época / grupo', 'wakoo' ), 'd' => '' ],
					'date'  => [ 't' => 'text', 'l' => __( 'Fecha', 'wakoo' ), 'd' => '2024' ],
					'title' => [ 't' => 'text', 'l' => __( 'Título', 'wakoo' ), 'd' => __( 'Hito', 'wakoo' ) ],
					'text'  => [ 't' => 'textarea', 'l' => __( 'Texto', 'wakoo' ), 'd' => '' ],
					'image' => [ 't' => 'media', 'l' => __( 'Imagen', 'wakoo' ) ],
				], 'd' => [
					[ 'group' => __( 'Inicios', 'wakoo' ), 'date' => '2019', 'title' => __( 'Nace la idea', 'wakoo' ), 'text' => __( 'Un primer boceto sobre una mesa.', 'wakoo' ), 'image' => self::demo( 'photo-1.svg' ) ],
					[ 'group' => __( 'Inicios', 'wakoo' ), 'date' => '2020', 'title' => __( 'Primer prototipo', 'wakoo' ), 'text' => __( 'Probamos con los primeros usuarios.', 'wakoo' ), 'image' => self::demo( 'photo-2.svg' ) ],
					[ 'group' => __( 'Crecimiento', 'wakoo' ), 'date' => '2022', 'title' => __( 'Lanzamiento', 'wakoo' ), 'text' => __( 'Abrimos al público.', 'wakoo' ), 'image' => self::demo( 'photo-3.svg' ) ],
					[ 'group' => __( 'Crecimiento', 'wakoo' ), 'date' => '2024', 'title' => __( 'Mil clientes', 'wakoo' ), 'text' => __( 'Superamos el primer millar.', 'wakoo' ), 'image' => self::demo( 'photo-4.svg' ) ],
				] ],
			] ],
			[ 'id' => 'sec_layout', 'label' => __( 'Diseño', 'wakoo' ), 'controls' => [
				'dir'     => [ 't' => 'select', 'l' => __( 'Orientación', 'wakoo' ), 'd' => 'v', 'o' => [ 'v' => __( 'Vertical', 'wakoo' ), 'h' => __( 'Horizontal (con flechas)', 'wakoo' ) ] ],
				'alt'     => [ 't' => 'switch', 'l' => __( 'Alternar lados (vertical)', 'wakoo' ), 'd' => 'yes', 'c' => [ 'dir' => 'v' ] ],
				'animate' => [ 't' => 'switch', 'l' => __( 'Animar al aparecer', 'wakoo' ), 'd' => 'yes' ],
				'prev'    => [ 't' => 'text', 'l' => __( 'Texto flecha anterior', 'wakoo' ), 'd' => __( 'Anterior', 'wakoo' ), 'c' => [ 'dir' => 'h' ] ],
				'next'    => [ 't' => 'text', 'l' => __( 'Texto flecha siguiente', 'wakoo' ), 'd' => __( 'Siguiente', 'wakoo' ), 'c' => [ 'dir' => 'h' ] ],
			] ],
		];
	}

	protected function draw( array $s ) {
		$dir    = 'h' === $s['dir'] ? 'h' : 'v';
		$groups = $this->group_rows( (array) ( $s['items'] ?? [] ), 'group', '' );
		$this->open( [ 'dir' => $dir, 'animate' => 'yes' === $s['animate'] ], 'wks-tl--' . $dir . ( 'yes' === $s['alt'] ? ' wks-tl--alt' : '' ) );
		if ( 'h' === $dir ) {
			echo '<div class="wks-tl__nav"><button type="button" class="wks-btn wks-btn--ghost wks-tl__prev">&larr; ' . esc_html( $s['prev'] ) . '</button><button type="button" class="wks-btn wks-btn--ghost wks-tl__next">' . esc_html( $s['next'] ) . ' &rarr;</button></div>';
		}
		echo '<div class="wks-tl__track" tabindex="0" role="list">';
		foreach ( $groups as $name => $rows ) {
			echo '<section class="wks-tl__group">';
			if ( '' !== $name ) { echo '<h3 class="wks-group-title wks-tl__era">' . esc_html( $name ) . '</h3>'; }
			foreach ( $rows as $r ) {
				$img = $this->img( $r['image'] ?? [] );
				echo '<article class="wks-tl__item" role="listitem"><span class="wks-tl__dot" aria-hidden="true"></span><div class="wks-tl__card wks-card">';
				if ( ! empty( $r['date'] ) ) { echo '<time class="wks-tl__date">' . esc_html( $r['date'] ) . '</time>'; }
				if ( $img ) { echo '<img src="' . $img . '" alt="" loading="lazy" decoding="async">'; }
				if ( ! empty( $r['title'] ) ) { echo '<h4 class="wks-tl__title">' . esc_html( $r['title'] ) . '</h4>'; }
				if ( ! empty( $r['text'] ) ) { echo '<p class="wks-tl__text">' . esc_html( $r['text'] ) . '</p>'; }
				echo '</div></article>';
			}
			echo '</section>';
		}
		echo '</div>';
		$this->close();
	}
}
