<?php
/**
 * Data helpers: widget settings lookup (so recipients/prices never travel to the browser) and custom tables.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Suite;

defined( 'ABSPATH' ) || die();

class Data {

	const DB_VERSION = '1';

	public static function maybe_install() {
		if ( get_option( 'wakoo_suite_db' ) === self::DB_VERSION ) { return; }
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		// Daily page views (aggregated, no personal data).
		dbDelta( "CREATE TABLE {$wpdb->prefix}wakoo_hits (
			day date NOT NULL,
			path varchar(190) NOT NULL,
			views bigint(20) unsigned NOT NULL DEFAULT 0,
			PRIMARY KEY  (day,path)
		) $c;" );
		// Sampled clicks for the heat map (percent coordinates only).
		dbDelta( "CREATE TABLE {$wpdb->prefix}wakoo_clicks (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			post_id bigint(20) unsigned NOT NULL,
			bucket varchar(8) NOT NULL,
			x smallint(5) unsigned NOT NULL,
			y int(10) unsigned NOT NULL,
			created datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY post_bucket (post_id,bucket)
		) $c;" );
		update_option( 'wakoo_suite_db', self::DB_VERSION, false );
	}

	/**
	 * Settings of one widget instance, read server-side from the saved Elementor data.
	 * Returns null unless the post is public (or the viewer can edit it) and the widget exists with the given type.
	 */
	public static function widget( $post_id, $widget_id, $type ) {
		$post_id   = (int) $post_id;
		$widget_id = preg_replace( '/[^a-z0-9]/i', '', (string) $widget_id );
		if ( ! $post_id || '' === $widget_id ) { return null; }
		$post = get_post( $post_id );
		if ( ! $post ) { return null; }
		if ( 'publish' !== $post->post_status && ! current_user_can( 'edit_post', $post_id ) ) {
			// Templates (headers, popups) are private/published library items; allow them when published only.
			return null;
		}
		if ( ! empty( $post->post_password ) ) { return null; }
		$cache = 'wks_w_' . $post_id . '_' . $widget_id . '_' . strtotime( $post->post_modified_gmt );
		$hit   = wp_cache_get( $cache, 'wakoo_suite' );
		if ( false === $hit ) {
			$raw  = get_post_meta( $post_id, '_elementor_data', true );
			$data = is_string( $raw ) ? json_decode( $raw, true ) : $raw;
			$hit  = is_array( $data ) ? self::find( $data, $widget_id ) : null;
			wp_cache_set( $cache, $hit ?: 0, 'wakoo_suite', 300 );
		}
		if ( ! is_array( $hit ) ) { return null; }
		if ( ( $hit['widgetType'] ?? '' ) !== $type ) { return null; }
		return self::with_defaults( $type, (array) ( $hit['settings'] ?? [] ) );
	}

	/** Elementor stores only changed settings: fill the rest from the widget's declared defaults. */
	private static function with_defaults( $type, array $saved ) {
		$slug = preg_replace( '/^wakoo-/', '', $type );
		$cls  = Module::class_for( $slug );
		if ( class_exists( $cls ) && method_exists( $cls, 'declared_defaults' ) ) {
			return array_replace( $cls::declared_defaults(), array_filter( $saved, static function ( $v ) { return null !== $v; } ) );
		}
		return $saved;
	}

	private static function find( array $els, $id ) {
		foreach ( $els as $el ) {
			if ( ( $el['id'] ?? '' ) === $id ) { return $el; }
			if ( ! empty( $el['elements'] ) ) {
				$f = self::find( $el['elements'], $id );
				if ( $f ) { return $f; }
			}
		}
		return null;
	}

	/** Month key helper. */
	public static function today() { return gmdate( 'Y-m-d', current_time( 'timestamp', true ) ); }
}
