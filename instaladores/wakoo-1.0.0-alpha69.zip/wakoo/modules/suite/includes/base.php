<?php
/**
 * Base class for the Suite widgets. Widgets only describe their controls as plain arrays (see sections()) and print
 * HTML in draw(); this class builds the Elementor controls, the common style section, the root element and the
 * asset dependencies.
 *
 * Control definition keys (all optional except 't'):
 *   t   type: text textarea wysiwyg number select switch color url media repeater slider choose heading note code datetime hidden editor_btn
 *       (editor_btn = button that opens the spreadsheet/card editor on a repeater: 'target' => repeater id, 'mode' => grid|cards)
 *   l   label        d default       o options (value => label)       c condition (array)
 *   min max step     desc description   rows  textarea rows   dyn dynamic tags on (bool)
 *   fields  sub-controls (same shape) for repeaters      title  repeater title_field      sel  selectors (css => value)
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Suite;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

defined( 'ABSPATH' ) || die();

abstract class Base extends Widget_Base {

	/** Slug used for the widget name, assets and CSS classes, e.g. 'faq'. */
	abstract public function slug();
	/** Spanish title, without "(Wakoo)". */
	abstract public function label();
	/** Controls: [ [ 'id' => 'sec_x', 'label' => 'Grupo', 'controls' => [ 'key' => [ 't' => 'text', ... ] ] ], ... ] */
	abstract protected function sections();
	/** Prints the widget markup. Use $this->open( $cfg ) ... $this->close(). */
	abstract protected function draw( array $s );

	/** Panel category: interact | data | commerce | media */
	public function cat() { return 'interact'; }
	public function icon() { return 'eicon-apps'; }
	public function words() { return []; }

	public function get_name() { return 'wakoo-' . $this->slug(); }
	public function get_title() { return $this->label() . ' (Wakoo)'; }
	public function get_icon() { return $this->icon(); }
	public function get_categories() { return [ 'wakoo-' . $this->cat() ]; }
	public function get_keywords() { return array_merge( [ 'wakoo', $this->slug() ], $this->words() ); }

	public function get_script_depends() {
		return file_exists( Module::DIR . '/assets/js/' . $this->slug() . '.js' ) ? [ 'wakoo-suite-' . $this->slug() ] : [ 'wakoo-suite-core' ];
	}

	public function get_style_depends() {
		return file_exists( Module::DIR . '/assets/css/' . $this->slug() . '.css' ) ? [ 'wakoo-suite-' . $this->slug() ] : [ 'wakoo-suite' ];
	}

	/** Defaults declared in sections(), for server-side reads of saved settings. */
	public static function declared_defaults() {
		static $cache = [];
		$cls = static::class;
		if ( ! isset( $cache[ $cls ] ) ) {
			$out = [];
			$obj = ( new \ReflectionClass( $cls ) )->newInstanceWithoutConstructor();
			$m   = new \ReflectionMethod( $obj, 'sections' );
			$m->setAccessible( true );
			foreach ( $m->invoke( $obj ) as $sec ) {
				foreach ( $sec['controls'] as $id => $def ) {
					if ( array_key_exists( 'd', $def ) ) { $out[ $id ] = $def['d']; }
				}
			}
			$cache[ $cls ] = $out;
		}
		return $cache[ $cls ];
	}

	/* ---------------------------------------------------------------- controls */

	protected function register_controls() {
		foreach ( $this->sections() as $sec ) {
			$this->start_controls_section( $sec['id'], [
				'label' => $sec['label'],
				'tab'   => ! empty( $sec['style'] ) ? Controls_Manager::TAB_STYLE : Controls_Manager::TAB_CONTENT,
			] );
			foreach ( $sec['controls'] as $id => $def ) {
				$this->add_control( $id, $this->control_args( $def ) );
			}
			$this->end_controls_section();
		}
		$this->style_section();
	}

	/** Common look shared by every widget (CSS variables read by suite.css). */
	protected function style_section() {
		$this->start_controls_section( 'wks_style', [ 'label' => __( 'Estilo general', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$w = '{{WRAPPER}} .wks';
		$this->add_control( 'wks_accent', [ 'label' => __( 'Color de acento', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#6C5CE7', 'selectors' => [ $w => '--wks-accent: {{VALUE}};' ] ] );
		$this->add_control( 'wks_text', [ 'label' => __( 'Color del texto', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ $w => '--wks-text: {{VALUE}};' ] ] );
		$this->add_control( 'wks_bg', [ 'label' => __( 'Color de fondo', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ $w => '--wks-bg: {{VALUE}};' ] ] );
		$this->add_control( 'wks_radius', [ 'label' => __( 'Redondez (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 60, 'selectors' => [ $w => '--wks-radius: {{VALUE}}px;' ] ] );
		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [ 'name' => 'wks_typo', 'selector' => $w ] );
		$this->end_controls_section();
	}

	private function control_args( array $d ) {
		$map = [
			'text' => Controls_Manager::TEXT, 'textarea' => Controls_Manager::TEXTAREA, 'wysiwyg' => Controls_Manager::WYSIWYG,
			'number' => Controls_Manager::NUMBER, 'select' => Controls_Manager::SELECT, 'switch' => Controls_Manager::SWITCHER,
			'color' => Controls_Manager::COLOR, 'url' => Controls_Manager::URL, 'media' => Controls_Manager::MEDIA,
			'repeater' => Controls_Manager::REPEATER, 'slider' => Controls_Manager::SLIDER, 'choose' => Controls_Manager::CHOOSE,
			'heading' => Controls_Manager::HEADING, 'note' => Controls_Manager::RAW_HTML, 'code' => Controls_Manager::CODE,
			'datetime' => Controls_Manager::DATE_TIME, 'hidden' => Controls_Manager::HIDDEN, 'gallery' => Controls_Manager::GALLERY,
			'editor_btn' => Controls_Manager::BUTTON,
		];
		$t    = $d['t'] ?? 'text';
		$args = [ 'type' => $map[ $t ] ?? Controls_Manager::TEXT ];
		if ( isset( $d['l'] ) ) { $args['label'] = $d['l']; }
		if ( array_key_exists( 'd', $d ) ) { $args['default'] = $d['d']; }
		if ( isset( $d['o'] ) ) { $args['options'] = $d['o']; }
		if ( isset( $d['c'] ) ) { $args['condition'] = $d['c']; }
		if ( isset( $d['desc'] ) ) { $args['description'] = $d['desc']; }
		foreach ( [ 'min', 'max', 'step', 'rows' ] as $k ) { if ( isset( $d[ $k ] ) ) { $args[ $k ] = $d[ $k ]; } }
		if ( isset( $d['sel'] ) ) { $args['selectors'] = $d['sel']; }
		if ( isset( $d['mt'] ) ) { $args['media_types'] = $d['mt']; }
		if ( 'switch' === $t ) { $args['return_value'] = 'yes'; $args['default'] = $args['default'] ?? ''; }
		if ( 'note' === $t ) { $args['raw'] = $d['l'] ?? ''; unset( $args['label'] ); $args['content_classes'] = 'elementor-descriptor'; }
		if ( 'editor_btn' === $t ) {
			// Opens WakooEditor (assets/editor). target = repeater id; mode = grid|cards. See wakoo-editor.js.
			$args['text']           = $d['l'] ?? __( 'Abrir editor', 'wakoo' );
			$args['label_block']    = true;
			$args['button_type']    = 'success';
			$args['event']          = 'wakoo:editor:open';
			$args['wakoo_target']   = $d['target'] ?? '';
			$args['wakoo_mode']     = $d['mode'] ?? 'grid';
			$args['wakoo_title']    = $d['title'] ?? '';
			unset( $args['label'] );
		}
		if ( 'url' === $t ) { $args['label_block'] = true; }
		if ( in_array( $t, [ 'text', 'textarea' ], true ) ) { $args['label_block'] = true; if ( ! empty( $d['dyn'] ) ) { $args['dynamic'] = [ 'active' => true ]; } }
		if ( 'repeater' === $t ) {
			$rep = new Repeater();
			foreach ( $d['fields'] as $fid => $fd ) { $rep->add_control( $fid, $this->control_args( $fd ) ); }
			$args['fields']  = $rep->get_controls();
			$args['default'] = $d['d'] ?? [];
			if ( isset( $d['title'] ) ) { $args['title_field'] = $d['title']; }
		}
		return $args;
	}

	/* ------------------------------------------------------------------ render */

	protected function render() {
		$this->draw( $this->get_settings_for_display() );
	}

	/** Document the widget lives in (page or library template) and its element id, for REST calls. */
	protected function ctx() {
		$doc = \Elementor\Plugin::$instance->documents->get_current();
		$pid = $doc ? (int) $doc->get_main_id() : (int) get_the_ID();
		return [ 'post' => $pid ?: (int) get_the_ID(), 'w' => $this->get_id() ];
	}

	/** Opens the root element. $cfg is JSON-encoded into data-wks (only non-secret, display-level values!). */
	protected function open( array $cfg = [], $class = '' ) {
		$ctx = $this->ctx();
		printf(
			'<div class="wks wks-%1$s %2$s" data-wks="%3$s" data-post="%4$d" data-w="%5$s">',
			esc_attr( $this->slug() ),
			esc_attr( $class ),
			esc_attr( wp_json_encode( $cfg ) ),
			(int) $ctx['post'],
			esc_attr( $ctx['w'] )
		);
	}

	protected function close() { echo '</div>'; }

	/** "Editar tabla" button shown only inside the Elementor preview; assets/editor/wakoo-editor-adapters.js handles the click. */
	protected function edit_btn( $label ) {
		if ( class_exists( '\\Elementor\\Plugin' ) && \Elementor\Plugin::$instance->editor && \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			echo '<button type="button" class="wks-ed-open">' . esc_html( $label ) . '</button>';
		}
	}

	/** Decodes a JSON sheet saved by the editor: [ 'ok' => bool, ... ] with caps; $max_cols/$max_rows keep it bounded. */
	protected static function json_in( $raw ) {
		$raw = is_string( $raw ) ? $raw : '';
		if ( '' === $raw || strlen( $raw ) > 1048576 ) { return null; }
		$j = json_decode( $raw, true );
		return is_array( $j ) ? $j : null;
	}

	/** Plain, short, tag-free cell text. */
	protected static function cell( $v, $max = 300 ) {
		return mb_substr( trim( wp_strip_all_tags( is_scalar( $v ) ? (string) $v : '' ) ), 0, $max );
	}

	/** Groups repeater rows by a field, keeping the order of first appearance. Returns [ group => [ rows ] ]. */
	protected function group_rows( array $rows, $field = 'group', $fallback = '' ) {
		$out = [];
		foreach ( $rows as $r ) {
			$g = trim( (string) ( $r[ $field ] ?? '' ) );
			$g = '' === $g ? $fallback : $g;
			$out[ $g ][] = $r;
		}
		return $out;
	}

	/** Image URL from a MEDIA control value. */
	protected function img( $m ) { return is_array( $m ) && ! empty( $m['url'] ) ? esc_url( $m['url'] ) : ''; }

	/** Safe link attributes from a URL control value. */
	protected function link_attrs( $u ) {
		if ( ! is_array( $u ) || empty( $u['url'] ) ) { return ''; }
		$a = ' href="' . esc_url( $u['url'] ) . '"';
		if ( ! empty( $u['is_external'] ) ) { $a .= ' target="_blank" rel="noopener noreferrer"'; }
		return $a;
	}
}
