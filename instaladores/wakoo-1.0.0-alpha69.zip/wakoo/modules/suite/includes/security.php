<?php
/**
 * Shared input/abuse protection for the Suite's public endpoints.
 *
 * Public endpoints cannot rely on nonces (pages are cached), so every one of them: validates that the
 * post/widget pair really exists and is of the expected type (Data::widget), caps and sanitizes every field,
 * applies a per-visitor rate limit, and uses a honeypot + minimum-time trap on form-like posts.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Suite;

defined( 'ABSPATH' ) || die();

class Sec {

	const NS = 'wakoo/v1/s';

	/** Anonymous hash of the visitor (IP + UA + salt); the raw IP is never stored. */
	public static function visitor() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? preg_replace( '/[^0-9a-f:.]/i', '', (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : ''; // phpcs:ignore
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ), 0, 120 ) : ''; // phpcs:ignore
		return substr( hash_hmac( 'sha256', $ip . '|' . $ua, wp_salt( 'auth' ) ), 0, 24 );
	}

	/** Allows $max calls per $window seconds per visitor and bucket. Returns false when exceeded. */
	public static function rate( $bucket, $max = 10, $window = 600 ) {
		$key = 'wks_rl_' . md5( $bucket . '|' . self::visitor() );
		$n   = (int) get_transient( $key );
		if ( $n >= $max ) { return false; }
		set_transient( $key, $n + 1, $window );
		return true;
	}

	/** Very small mutex around read-modify-write sections. */
	public static function lock( $name, $ttl = 5 ) {
		$key = 'wks_lock_' . md5( $name );
		for ( $i = 0; $i < 20; $i++ ) {
			if ( false === get_transient( $key ) ) {
				set_transient( $key, 1, $ttl );
				return $key;
			}
			usleep( 100000 );
		}
		return false;
	}

	public static function unlock( $key ) { if ( $key ) { delete_transient( $key ); } }

	public static function text( $v, $max = 200 ) {
		$v = is_scalar( $v ) ? (string) $v : '';
		return mb_substr( sanitize_text_field( wp_unslash( $v ) ), 0, $max );
	}

	public static function area( $v, $max = 2000 ) {
		$v = is_scalar( $v ) ? (string) $v : '';
		return mb_substr( sanitize_textarea_field( wp_unslash( $v ) ), 0, $max );
	}

	public static function int( $v, $min = 0, $max = PHP_INT_MAX ) {
		return max( $min, min( $max, (int) $v ) );
	}

	/** Honeypot ("website" must be empty) and minimum fill time ("t" in ms). */
	public static function human( \WP_REST_Request $r, $min_ms = 1500 ) {
		if ( '' !== (string) $r->get_param( 'website' ) ) { return false; }
		return (int) $r->get_param( 't' ) >= $min_ms;
	}

	public static function ok( $data = [], $code = 200 ) {
		return new \WP_REST_Response( [ 'ok' => true ] + (array) $data, $code );
	}

	public static function err( $msg, $code = 400 ) {
		return new \WP_REST_Response( [ 'ok' => false, 'error' => $msg ], $code );
	}

	/** Public route (anonymous allowed; see class docblock for the protections). */
	public static function route( $path, $methods, $cb, $args = [] ) {
		register_rest_route( self::NS, $path, [
			'methods'             => $methods,
			'callback'            => $cb,
			'permission_callback' => '__return_true',
			'args'                => $args,
		] );
	}

	/** Admin-only route; the REST cookie nonce (X-WP-Nonce) is enforced by core. */
	public static function route_admin( $path, $methods, $cb, $args = [] ) {
		register_rest_route( self::NS, $path, [
			'methods'             => $methods,
			'callback'            => $cb,
			'permission_callback' => static function () { return current_user_can( 'manage_options' ); },
			'args'                => $args,
		] );
	}
}
