<?php
/**
 * Wakoo Suite: 20 native widgets (reservas, encuestas, reseñas, línea de tiempo, audio, tablas, visor 360,
 * estadísticas, FAQ, pestañas dinámicas, comparador, variantes, cuenta atrás por botón, mapa de calor,
 * checklist, galería filtrable, equipo, calculadora, chat guionizado, cookies).
 *
 * Everything is native: no external APIs, CDNs or services. Each widget loads its own JS/CSS only when it is on the page.
 * Widget files live in widgets/<slug>.php and define Wakoo\Modules\Suite\Widgets\<Studly>; an optional static
 * boot() hook registers its REST routes. Assets: assets/js/<slug>.js and assets/css/<slug>.css (both optional).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Suite;

defined( 'ABSPATH' ) || die();

require_once __DIR__ . '/includes/security.php';
require_once __DIR__ . '/includes/data.php';

class Module {

	const DIR = __DIR__;

	/** Slugs of the widget files found in widgets/. */
	public static function slugs() {
		static $slugs = null;
		if ( null === $slugs ) {
			$slugs = [];
			foreach ( glob( self::DIR . '/widgets/*.php' ) as $f ) {
				$slugs[] = basename( $f, '.php' );
			}
		}
		return $slugs;
	}

	public static function class_for( $slug ) {
		return __NAMESPACE__ . '\\Widgets\\' . str_replace( ' ', '', ucwords( str_replace( '-', ' ', $slug ) ) );
	}

	public static function init() {
		add_action( 'init', [ Data::class, 'maybe_install' ] );
		add_action( 'elementor/elements/categories_registered', [ __CLASS__, 'categories' ] );
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widgets' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'scripts' ] );
		add_action( 'elementor/frontend/after_register_styles', [ __CLASS__, 'styles' ] );
		add_action( 'elementor/editor/after_enqueue_styles', [ __CLASS__, 'styles' ] );
		add_action( 'elementor/editor/before_enqueue_scripts', [ __CLASS__, 'editor_scripts' ] );
		add_action( 'rest_api_init', [ __CLASS__, 'boot_widgets' ] );
		add_action( 'init', [ __CLASS__, 'boot_init' ], 20 );
	}

	/** Load each widget file once (they only declare classes). */
	public static function load_widgets() {
		static $done = false;
		if ( $done || ! class_exists( '\\Elementor\\Widget_Base' ) ) { return; }
		$done = true;
		require_once self::DIR . '/includes/base.php';
		foreach ( self::slugs() as $slug ) {
			require_once self::DIR . '/widgets/' . $slug . '.php';
		}
	}

	public static function boot_widgets() {
		self::load_widgets();
		foreach ( self::slugs() as $slug ) {
			$cls = self::class_for( $slug );
			if ( class_exists( $cls ) && method_exists( $cls, 'routes' ) ) { $cls::routes(); }
		}
	}

	/** Non-REST hooks (admin menus, CPTs, front-end hooks) a widget needs at init time. */
	public static function boot_init() {
		self::load_widgets();
		foreach ( self::slugs() as $slug ) {
			$cls = self::class_for( $slug );
			if ( class_exists( $cls ) && method_exists( $cls, 'boot' ) ) { $cls::boot(); }
		}
	}

	public static function categories( $mgr ) {
		$cats = [
			'wakoo-interact' => __( 'Wakoo · Interacción', 'wakoo' ),
			'wakoo-data'     => __( 'Wakoo · Datos y estadísticas', 'wakoo' ),
			'wakoo-commerce' => __( 'Wakoo · Reservas y comercio', 'wakoo' ),
			'wakoo-media'    => __( 'Wakoo · Multimedia', 'wakoo' ),
		];
		foreach ( $cats as $k => $t ) {
			$mgr->add_category( $k, [ 'title' => $t, 'icon' => 'eicon-apps' ] );
		}
	}

	public static function register_widgets( $wm ) {
		self::load_widgets();
		foreach ( self::slugs() as $slug ) {
			$cls = self::class_for( $slug );
			if ( class_exists( $cls ) ) { $wm->register( new $cls() ); }
		}
	}

	public static function scripts() {
		$url = WAKOO_MODULES_URL . 'suite/assets/js/';
		wp_register_script( 'wakoo-suite-core', $url . 'core.js', [], WAKOO_VERSION, true );
		wp_localize_script( 'wakoo-suite-core', 'WakooSuite', [
			'rest'  => esc_url_raw( rest_url( 'wakoo/v1/s/' ) ),
			'nonce' => wp_create_nonce( 'wp_rest' ),
		] );
		foreach ( self::slugs() as $slug ) {
			if ( file_exists( self::DIR . '/assets/js/' . $slug . '.js' ) ) {
				wp_register_script( 'wakoo-suite-' . $slug, $url . $slug . '.js', [ 'wakoo-suite-core' ], WAKOO_VERSION, true );
			}
		}
	}

	/** Spreadsheet/card editor: only inside the Elementor editor, never on the front end. */
	public static function editor_scripts() {
		$u = WAKOO_MODULES_URL . 'suite/assets/editor/';
		wp_enqueue_script( 'wakoo-sheet-editor', $u . 'wakoo-editor.js', [], WAKOO_VERSION, true );
		wp_enqueue_script( 'wakoo-sheet-adapters', $u . 'wakoo-editor-adapters.js', [ 'jquery', 'wakoo-sheet-editor' ], WAKOO_VERSION, true );
		wp_localize_script( 'wakoo-sheet-adapters', 'WakooSheetCfg', [ 'css' => $u . 'wakoo-editor.css?ver=' . WAKOO_VERSION ] );
	}

	public static function styles() {
		$url = WAKOO_MODULES_URL . 'suite/assets/css/';
		wp_register_style( 'wakoo-suite', $url . 'suite.css', [], WAKOO_VERSION );
		foreach ( self::slugs() as $slug ) {
			if ( file_exists( self::DIR . '/assets/css/' . $slug . '.css' ) ) {
				wp_register_style( 'wakoo-suite-' . $slug, $url . $slug . '.css', [ 'wakoo-suite' ], WAKOO_VERSION );
			}
		}
	}
}

Module::init();
