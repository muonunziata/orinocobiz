/* Wakoo Orbit: circles turning around a centre image; each one opens a panel with tabs, a full-screen layer or a link. */
( function () {
	'use strict';

	var all = [];

	function shown( el ) {
		// Lets widgets inside (sliders, games…) measure themselves once they are visible.
		try { el.dispatchEvent( new CustomEvent( 'wakoo:shown', { bubbles: false } ) ); } catch ( e ) {}
		Array.prototype.forEach.call( el.querySelectorAll( '[data-wakoo-shown]' ), function ( x ) {
			try { x.dispatchEvent( new CustomEvent( 'wakoo:shown' ) ); } catch ( e ) {}
		} );
		window.dispatchEvent( new Event( 'resize' ) );
	}

	function Orbit( root ) {
		var cfg = {};
		try { cfg = JSON.parse( root.getAttribute( 'data-wakoo-orbit' ) || '{}' ); } catch ( e ) {}
		var S = { ang: 0, open: null, tab: 0, pause: false, raf: 0, t0: 0, target: null, geo: null, tgt: null };
		var owner = root.getAttribute( 'data-owner' );
		var edit = document.body.classList.contains( 'elementor-editor-active' ) || /elementor-preview/.test( location.search );
		var reduce = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
		var still = edit || ! cfg.turn || reduce;
		var fx = ! edit && ! reduce && 0 !== cfg.fx && !! Element.prototype.animate;
		var EASE = 'cubic-bezier(.2,.8,.2,1)';
		var items = Array.prototype.slice.call( root.querySelectorAll( '.wakoo-orbit__it' ) );
		var panel = root.querySelector( '.wakoo-orbit__panel' );
		var hero = root.querySelector( '.wakoo-orbit__hero' );
		var logo = root.querySelector( '.wakoo-orbit__logo' );
		var ring = root.querySelector( '.wakoo-orbit__ring' );
		var bodyEl = root.querySelector( '.wakoo-orbit__body' );
		var veil = root.querySelector( '.wakoo-orbit__veil' );
		var foot = root.querySelector( '.wakoo-orbit__foot' );
		var layers = {};
		var lastFocus = null;
		var pending = [];

		if ( fx ) {
			root.classList.add( 'wko-fx' );
			Array.prototype.forEach.call( root.querySelectorAll( '.wakoo-orbit__tabs' ), function ( tl ) {
				var k = document.createElement( 'span' );
				k.className = 'wakoo-orbit__ink';
				k.setAttribute( 'aria-hidden', 'true' );
				tl.appendChild( k );
			} );
		}

		// Centre of `from`, measured inside `box`.
		function origin( from, box ) {
			var a = from.getBoundingClientRect(), b = box.getBoundingClientRect();
			return { x: a.left + a.width / 2 - b.left, y: a.top + a.height / 2 - b.top, w: b.width, h: b.height, r: a.width / 2 };
		}

		// The box grows (or shrinks back) as a circle centred on `from`: the panel is born from the circle that was tapped.
		function bloom( box, from, back, done ) {
			if ( box._wko ) { box._wko.onfinish = null; box._wko.cancel(); box._wko = null; }
			if ( ! fx || ! from ) { if ( done ) { done(); } return; }
			var o = origin( from, box );
			var far = Math.ceil( Math.max( Math.hypot( o.x, o.y ), Math.hypot( o.w - o.x, o.y ), Math.hypot( o.x, o.h - o.y ), Math.hypot( o.w - o.x, o.h - o.y ) ) ) + 4;
			var c0 = 'circle(' + Math.max( 1, o.r ).toFixed( 1 ) + 'px at ' + o.x.toFixed( 1 ) + 'px ' + o.y.toFixed( 1 ) + 'px)';
			var c1 = 'circle(' + far + 'px at ' + o.x.toFixed( 1 ) + 'px ' + o.y.toFixed( 1 ) + 'px)';
			var a = box.animate( { clipPath: back ? [ c1, c0 ] : [ c0, c1 ], opacity: back ? [ 1, 0.4 ] : [ 0.5, 1 ] },
				{ duration: back ? 460 : 780, easing: back ? 'cubic-bezier(.55,0,.75,.35)' : EASE } );
			box._wko = a;
			a.onfinish = function () { box._wko = null; if ( done ) { done(); } };
		}

		function rise( el, delay, dx, dy ) {
			el.animate( [ { opacity: 0, transform: 'translate(' + dx + 'px,' + dy + 'px)' }, { opacity: 1, transform: 'none' } ],
				{ duration: 640, delay: delay, easing: EASE, fill: 'backwards' } );
		}

		// Blocks further down appear as they scroll into the panel.
		var io = fx && window.IntersectionObserver ? new IntersectionObserver( function ( ents ) {
			ents.forEach( function ( en ) {
				if ( ! en.isIntersecting ) { return; }
				io.unobserve( en.target );
				en.target.style.opacity = '';
				rise( en.target, 0, 0, 26 );
			} );
		}, { root: bodyEl, rootMargin: '0px 0px -6% 0px' } ) : null;

		// The content of a tab comes in one block after another (a grid card counts as one block).
		function cascade( pane, dir ) {
			if ( ! fx || ! pane ) { return; }
			pending.forEach( function ( el ) { if ( io ) { io.unobserve( el ); } el.style.opacity = ''; } );
			pending = [];
			var list = [];
			Array.prototype.forEach.call( pane.querySelectorAll( '.e-grid > .elementor-element, .elementor-widget' ), function ( el ) {
				for ( var k = 0; k < list.length; k++ ) { if ( list[ k ].contains( el ) ) { return; } }
				list.push( el );
			} );
			var fold = bodyEl.getBoundingClientRect().bottom + 40, n = 0;
			list.forEach( function ( el ) {
				if ( el.getBoundingClientRect().top > fold ) {
					if ( io ) { el.style.opacity = '0'; io.observe( el ); pending.push( el ); }
					return;
				}
				rise( el, 90 + Math.min( n++, 14 ) * 60, dir * 30, dir ? 0 : 24 );
			} );
		}

		function ink( tl ) {
			var k = tl && tl.querySelector( '.wakoo-orbit__ink' ), b = tl && tl.querySelector( '.wakoo-orbit__tab[aria-selected="true"]' );
			if ( ! k || ! b ) { return; }
			k.style.width = b.offsetWidth + 'px';
			k.style.transform = 'translateX(' + b.offsetLeft + 'px)';
		}

		// Full-screen layers live in <body>, so no parent transform or overflow can cut them.
		Array.prototype.forEach.call( root.querySelectorAll( '.wakoo-orbit__layer' ), function ( l ) {
			layers[ l.getAttribute( 'data-i' ) ] = l;
			if ( ! edit ) { document.body.appendChild( l ); }
		} );
		if ( edit ) {
			// In the editor the layers stay hidden: their template is edited on its own.
			Object.keys( layers ).forEach( function ( k ) { layers[ k ].hidden = true; } );
		}

		var anchors = {};
		items.forEach( function ( it, i ) {
			( it.getAttribute( 'data-anchors' ) || '' ).split( ',' ).forEach( function ( a, t ) {
				if ( a ) { anchors[ a ] = [ i, t ]; }
			} );
		} );

		function mobile() { return root.clientWidth < ( cfg.bp || 900 ); }

		function layout() {
			var W = root.clientWidth, H = root.clientHeight, mob = mobile(), ab = S.open !== null;
			root.classList.toggle( 'is-mobile', mob );
			root.classList.toggle( 'is-open', ab );
			if ( mob ) {
				hero.style.cssText = ''; logo.style.cssText = ''; ring.style.cssText = '';
				items.forEach( function ( it ) { it.style.transform = ''; } );
				root.classList.add( 'is-placed' );
				return;
			}
			var aw = ab ? W * 0.46 : W, cx = aw / 2, cy = ab ? H * 0.47 : H * 0.555;
			var R = Math.min( aw * 0.38, H * ( ab ? 0.305 : 0.325 ) );
			var Sz = Math.max( 72, Math.min( 112, R * 0.36 ) );
			// The footer (bottom left; it fades out while a panel is open) must never cover a circle or its name.
			// The circles turn, so what matters is the nearest point of each footer block to the centre of the orbit.
			if ( foot && ! ab && foot.offsetHeight ) {
				var rb = root.getBoundingClientRect(), near = Infinity;
				Array.prototype.forEach.call( foot.querySelectorAll( '.elementor-widget' ), function ( w ) {
					var q = ( w.firstElementChild || w ).getBoundingClientRect();
					var dx = Math.max( q.left - rb.left - cx, 0, cx - ( q.right - rb.left ) );
					var dy = Math.max( q.top - rb.top - cy, 0, cy - ( q.bottom - rb.top ) );
					near = Math.min( near, Math.hypot( dx, dy ) );
				} );
				var over = R + Sz * 0.5 + 34 - near; // 34: the name under each circle
				if ( over > 0 ) {
					R = Math.max( R * 0.72, R - over );
					Sz = Math.max( 72, Math.min( 112, R * 0.36 ) );
				}
			}
			var logoD = Math.max( 130, ( R - Sz * 0.75 ) * 2 );
			hero.style.cssText = 'left:0;right:auto;width:' + aw + 'px;top:14px;';
			S.tgt = { cx: cx, cy: cy, R: R, S: Sz, logoD: logoD };
			if ( ! S.geo ) { S.geo = JSON.parse( JSON.stringify( S.tgt ) ); }
			apply();
			root.classList.add( 'is-placed' );
		}

		function approach() {
			var g = S.geo, t = S.tgt, moved = false;
			if ( ! g || ! t || mobile() ) { return false; }
			[ 'cx', 'cy', 'R', 'S', 'logoD' ].forEach( function ( k ) {
				var d = t[ k ] - g[ k ];
				if ( Math.abs( d ) > 0.4 ) { g[ k ] += d * 0.16; moved = true; } else { g[ k ] = t[ k ]; }
			} );
			return moved;
		}

		function apply() {
			var g = S.geo;
			if ( ! g || mobile() ) { return; }
			logo.style.width = logo.style.height = g.logoD.toFixed( 1 ) + 'px';
			logo.style.left = ( g.cx - g.logoD / 2 ).toFixed( 1 ) + 'px';
			logo.style.top = ( g.cy - g.logoD / 2 ).toFixed( 1 ) + 'px';
			ring.style.width = ring.style.height = ( g.R * 2 ).toFixed( 1 ) + 'px';
			ring.style.left = ( g.cx - g.R ).toFixed( 1 ) + 'px';
			ring.style.top = ( g.cy - g.R ).toFixed( 1 ) + 'px';
			root.style.setProperty( '--S', g.S.toFixed( 1 ) + 'px' );
			var n = items.length;
			for ( var i = 0; i < n; i++ ) {
				var th = ( S.ang + i * 360 / n - 90 ) * Math.PI / 180;
				var x = g.cx + g.R * Math.cos( th ), y = g.cy + g.R * Math.sin( th );
				items[ i ].style.transform = 'translate(' + ( x - g.S / 2 ).toFixed( 1 ) + 'px,' + ( y - g.S / 2 ).toFixed( 1 ) + 'px)';
				items[ i ].classList.toggle( 'is-sel', S.open === i );
			}
		}

		function tick( ts ) {
			if ( ! root.isConnected ) { S.raf = 0; return; }
			if ( mobile() ) { S.t0 = ts; S.raf = requestAnimationFrame( tick ); return; }
			var dt = S.t0 ? Math.min( 60, ts - S.t0 ) : 16, moved = approach();
			S.t0 = ts;
			if ( S.target !== null ) {
				var d = ( ( S.target - S.ang ) % 360 + 540 ) % 360 - 180;
				S.ang += d * 0.14;
				if ( Math.abs( d ) < 0.25 ) { S.ang = S.target; S.target = null; }
				moved = true;
			} else if ( ! still && ! S.pause && S.open === null && ! document.hidden ) {
				S.ang = ( S.ang + dt * 360 / ( cfg.turn * 1000 ) ) % 360;
				moved = true;
			}
			if ( moved ) { apply(); }
			S.raf = requestAnimationFrame( tick );
		}

		function showTab( i, t, dir ) {
			var tabs = root.querySelectorAll( '.wakoo-orbit__tabs' ), panes = root.querySelectorAll( '.wakoo-orbit__pane' ), pane = null, list = null;
			Array.prototype.forEach.call( tabs, function ( tl ) {
				var on = +tl.getAttribute( 'data-i' ) === i;
				tl.hidden = ! on;
				if ( on ) { list = tl; }
				Array.prototype.forEach.call( tl.querySelectorAll( '.wakoo-orbit__tab' ), function ( b ) {
					var sel = on && +b.getAttribute( 'data-t' ) === t;
					b.setAttribute( 'aria-selected', sel ? 'true' : 'false' );
					b.tabIndex = sel ? 0 : -1;
				} );
			} );
			Array.prototype.forEach.call( panes, function ( p ) {
				var on = +p.getAttribute( 'data-i' ) === i && +p.getAttribute( 'data-t' ) === t;
				p.hidden = ! on;
				if ( on ) { pane = p; }
			} );
			if ( ! pane && t ) { return showTab( i, 0, dir ); }
			S.tab = t;
			bodyEl.scrollTop = 0;
			panel.classList.remove( 'is-scrolled' );
			ink( list );
			if ( pane ) { shown( pane ); cascade( pane, dir || 0 ); }
		}

		function open( i, t ) {
			var it = items[ i ];
			if ( ! it ) { return; }
			var act = it.getAttribute( 'data-act' );
			if ( 'link' === act ) { return; }
			lastFocus = document.activeElement;
			if ( 'layer' === act ) { openLayer( i ); return; }
			var fresh = S.open === null;
			S.open = i;
			panel.classList.add( 'is-on' );
			panel.setAttribute( 'aria-hidden', 'false' );
			showTab( i, t || 0, 0 );
			if ( fresh && ! mobile() ) { bloom( panel, it, false ); }
			layout();
			if ( mobile() ) { document.body.classList.add( 'wakoo-orbit-lock' ); }
			else { S.target = ( ( -i * 360 / items.length ) % 360 + 360 ) % 360; } // the chosen circle goes to the top
			var x = panel.querySelector( '.wakoo-orbit__x' );
			if ( x && mobile() ) { x.focus( { preventScroll: true } ); }
		}

		function close() {
			if ( S.open === null ) { return; }
			var from = items[ S.open ];
			S.open = null;
			panel.setAttribute( 'aria-hidden', 'true' );
			document.body.classList.remove( 'wakoo-orbit-lock' );
			if ( fx && ! mobile() ) {
				bloom( panel, from, true, function () { if ( S.open === null ) { panel.classList.remove( 'is-on' ); } } );
			} else {
				panel.classList.remove( 'is-on' );
			}
			layout();
			if ( lastFocus && lastFocus.focus ) { lastFocus.focus( { preventScroll: true } ); }
		}

		function openLayer( i ) {
			var l = layers[ i ];
			if ( ! l || edit ) { return; }
			l.hidden = false;
			l.scrollTop = 0;
			document.body.classList.add( 'wakoo-orbit-lock' );
			bloom( l, items[ i ], false );
			var x = l.querySelector( '.wakoo-orbit__x' );
			if ( x ) { x.focus( { preventScroll: true } ); }
			shown( l );
		}

		function closeLayer( l ) {
			if ( S.open === null || ! mobile() ) { document.body.classList.remove( 'wakoo-orbit-lock' ); }
			try { l.dispatchEvent( new CustomEvent( 'wakoo:hidden' ) ); } catch ( e ) {}
			if ( lastFocus && lastFocus.focus ) { lastFocus.focus( { preventScroll: true } ); }
			l.setAttribute( 'data-closing', '1' );
			bloom( l, items[ +l.getAttribute( 'data-i' ) ], true, function () { l.hidden = true; l.removeAttribute( 'data-closing' ); } );
		}

		function openLayerOpen() {
			for ( var k in layers ) { if ( ! layers[ k ].hidden && ! layers[ k ].hasAttribute( 'data-closing' ) ) { return layers[ k ]; } }
			return null;
		}

		items.forEach( function ( it, i ) {
			it.addEventListener( 'click', function ( e ) {
				if ( 'link' === it.getAttribute( 'data-act' ) ) { return; }
				e.preventDefault();
				if ( S.open === i ) { close(); } else { open( i, 0 ); }
			} );
		} );
		root.addEventListener( 'click', function ( e ) {
			var tab = e.target.closest( '.wakoo-orbit__tab' );
			if ( tab && root.contains( tab ) ) {
				var nt = +tab.getAttribute( 'data-t' );
				if ( nt !== S.tab ) { showTab( S.open, nt, nt > S.tab ? 1 : -1 ); }
				return;
			}
			if ( veil && e.target === veil ) { close(); return; }
			var x = e.target.closest( '.wakoo-orbit__panel .wakoo-orbit__x' );
			if ( x ) { close(); }
		} );
		root.addEventListener( 'keydown', function ( e ) {
			var tab = e.target.closest && e.target.closest( '.wakoo-orbit__tab' );
			if ( ! tab || ( 'ArrowRight' !== e.key && 'ArrowLeft' !== e.key ) ) { return; }
			var list = tab.parentNode.querySelectorAll( '.wakoo-orbit__tab' ), t = +tab.getAttribute( 'data-t' ) + ( 'ArrowRight' === e.key ? 1 : -1 );
			t = ( t + list.length ) % list.length;
			showTab( S.open, t, 'ArrowRight' === e.key ? 1 : -1 );
			list[ t ].focus();
			e.preventDefault();
		} );
		Object.keys( layers ).forEach( function ( k ) {
			layers[ k ].addEventListener( 'click', function ( e ) {
				if ( e.target.closest( '.wakoo-orbit__x--layer' ) ) { closeLayer( layers[ k ] ); }
			} );
		} );
		var box = root.querySelector( '.wakoo-orbit__items' );
		[ [ 'mouseenter', true ], [ 'mouseleave', false ], [ 'focusin', true ], [ 'focusout', false ] ].forEach( function ( p ) {
			box.addEventListener( p[ 0 ], function () { S.pause = p[ 1 ]; } );
		} );

		this.anchor = function ( name ) {
			var a = anchors[ name ];
			if ( ! a ) { return false; }
			var l = openLayerOpen();
			if ( l ) { closeLayer( l ); }
			open( a[ 0 ], a[ 1 ] );
			return true;
		};
		this.escape = function () {
			var l = openLayerOpen();
			if ( l ) { closeLayer( l ); return true; }
			if ( S.open !== null ) { close(); return true; }
			return false;
		};
		this.owner = owner;

		bodyEl.addEventListener( 'scroll', function () { panel.classList.toggle( 'is-scrolled', bodyEl.scrollTop > 4 ); }, { passive: true } );
		window.addEventListener( 'resize', layout );
		if ( fx ) {
			window.addEventListener( 'resize', function () { Array.prototype.forEach.call( root.querySelectorAll( '.wakoo-orbit__tabs:not([hidden])' ), ink ); } );
		}
		layout();
		if ( ! S.raf ) { S.raf = requestAnimationFrame( tick ); }
	}

	function init( root ) {
		if ( root.dataset.wakooInit ) { return; }
		root.dataset.wakooInit = '1';
		all.push( new Orbit( root ) );
	}

	function byAnchor( name ) {
		name = decodeURIComponent( ( name || '' ).replace( /^#/, '' ) );
		if ( ! name ) { return false; }
		for ( var i = 0; i < all.length; i++ ) { if ( all[ i ].anchor( name ) ) { return true; } }
		return false;
	}

	// Any link to #anchor (or to this same page with #anchor) opens its circle.
	document.addEventListener( 'click', function ( e ) {
		var a = e.target.closest && e.target.closest( 'a[href*="#"]' );
		if ( ! a || ! all.length ) { return; }
		var u;
		try { u = new URL( a.href, location.href ); } catch ( err ) { return; }
		if ( u.origin + u.pathname !== location.origin + location.pathname || ! u.hash ) { return; }
		if ( byAnchor( u.hash ) ) { e.preventDefault(); }
	} );
	document.addEventListener( 'keydown', function ( e ) {
		if ( 'Escape' !== e.key ) { return; }
		for ( var i = 0; i < all.length; i++ ) { if ( all[ i ].escape() ) { return; } }
	} );
	window.addEventListener( 'hashchange', function () { byAnchor( location.hash ); } );

	function boot() {
		Array.prototype.forEach.call( document.querySelectorAll( '.wakoo-orbit' ), init );
		if ( location.hash ) { byAnchor( location.hash ); }
	}
	if ( 'loading' === document.readyState ) { document.addEventListener( 'DOMContentLoaded', boot ); } else { boot(); }
	if ( window.jQuery ) {
		window.jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend && elementorFrontend.hooks ) {
				elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-orbit.default', function ( $el ) {
					var r = $el[ 0 ].querySelector( '.wakoo-orbit' );
					if ( r ) { init( r ); }
				} );
			}
		} );
	}
	window.WakooOrbit = { open: byAnchor };
} )();
