<?php
/**
 * Wakoo Orbit widget.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Orbit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Widget extends Widget_Base {

	public function get_name() { return 'wakoo-orbit'; }
	public function get_title() { return __( 'Órbita (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-spinner'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'orbita', 'orbit', 'circulos', 'giratorio', 'rueda', 'menu', 'portada', 'panel', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-orbit' ]; }
	public function get_style_depends() { return [ 'wakoo-orbit' ]; }

	private static function templates() {
		return class_exists( '\Wakoo\Modules\Templates\Module' ) ? [ '' => __( '— Ninguna —', 'wakoo' ) ] + \Wakoo\Modules\Templates\Module::template_options() : [ '' => __( '— Ninguna —', 'wakoo' ) ];
	}

	protected function register_controls() {
		$tpls = self::templates();

		$this->start_controls_section( 'sec_center', [ 'label' => __( 'Centro', 'wakoo' ) ] );
		$this->add_control( 'logo', [ 'label' => __( 'Imagen del centro', 'wakoo' ), 'type' => Controls_Manager::MEDIA, 'default' => [ 'url' => Utils::get_placeholder_image_src() ] ] );
		$this->add_control( 'logo_alt', [ 'label' => __( 'Texto alternativo', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '' ] );
		$this->add_control( 'eyebrow', [ 'label' => __( 'Antetítulo', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Bienvenida', 'wakoo' ), 'separator' => 'before' ] );
		$this->add_control( 'title', [ 'label' => __( 'Título', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 2, 'default' => __( 'Un título que invita', 'wakoo' ) ] );
		$this->add_control( 'title_em', [ 'label' => __( 'Final del título destacado', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'a descubrir', 'wakoo' ) ] );
		$this->add_control( 'title_tag', [ 'label' => __( 'Etiqueta del título', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'h1', 'options' => [ 'h1' => 'H1', 'h2' => 'H2', 'p' => 'p' ] ] );
		$this->add_control( 'cta_text', [ 'label' => __( 'Botón (solo en el móvil)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '' ] );
		$this->add_control( 'cta_link', [ 'label' => __( 'Enlace del botón', 'wakoo' ), 'type' => Controls_Manager::URL, 'default' => [ 'url' => '' ] ] );
		$this->add_control( 'hint', [ 'label' => __( 'Indicación', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Toca un círculo para conocernos', 'wakoo' ) ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_items', [ 'label' => __( 'Círculos', 'wakoo' ) ] );
		$r = new Repeater();
		$r->add_control( 'label', [ 'label' => __( 'Nombre', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Círculo', 'wakoo' ), 'label_block' => true ] );
		$r->add_control( 'image', [ 'label' => __( 'Imagen', 'wakoo' ), 'type' => Controls_Manager::MEDIA, 'default' => [ 'url' => Utils::get_placeholder_image_src() ] ] );
		$r->add_control( 'action', [
			'label'   => __( 'Al tocarlo', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'panel',
			'options' => [
				'panel' => __( 'Abrir el panel con pestañas', 'wakoo' ),
				'layer' => __( 'Abrir a pantalla completa', 'wakoo' ),
				'link'  => __( 'Ir a un enlace', 'wakoo' ),
			],
		] );
		$r->add_control( 'tab_label', [ 'label' => __( 'Pestaña 1', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '', 'description' => __( 'Vacío = el nombre del círculo.', 'wakoo' ), 'condition' => [ 'action' => 'panel' ] ] );
		$r->add_control( 'template_id', [ 'label' => __( 'Plantilla', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'options' => $tpls, 'default' => '', 'label_block' => true, 'description' => __( 'Una plantilla guardada (Plantillas > Plantillas guardadas). Se edita con Elementor como cualquier página.', 'wakoo' ), 'condition' => [ 'action!' => 'link' ] ] );
		$r->add_control( 'tab_label_2', [ 'label' => __( 'Pestaña 2 (opcional)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '', 'condition' => [ 'action' => 'panel' ] ] );
		$r->add_control( 'template_id_2', [ 'label' => __( 'Plantilla de la pestaña 2', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'options' => $tpls, 'default' => '', 'label_block' => true, 'condition' => [ 'action' => 'panel' ] ] );
		$r->add_control( 'link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL, 'default' => [ 'url' => '' ], 'condition' => [ 'action' => 'link' ] ] );
		$r->add_control( 'anchors', [ 'label' => __( 'Anclas', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '', 'description' => __( 'Nombres separados por comas (p. ej. «que-es, valores»): la primera abre la pestaña 1 y la segunda la pestaña 2. Un enlace a #que-es en cualquier parte de la página abre este círculo.', 'wakoo' ) ] );
		$this->add_control( 'items', [
			'label'       => __( 'Círculos', 'wakoo' ),
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'title_field' => '{{{ label }}}',
			'default'     => [
				[ 'label' => __( 'Quiénes somos', 'wakoo' ) ],
				[ 'label' => __( 'Qué hacemos', 'wakoo' ) ],
				[ 'label' => __( 'Comunidad', 'wakoo' ) ],
				[ 'label' => __( 'Contacto', 'wakoo' ) ],
				[ 'label' => __( 'Blog', 'wakoo' ) ],
				[ 'label' => __( 'Empieza', 'wakoo' ) ],
			],
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_foot', [ 'label' => __( 'Pie y comportamiento', 'wakoo' ) ] );
		$this->add_control( 'foot_template_id', [ 'label' => __( 'Plantilla del pie (abajo a la izquierda)', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'options' => $tpls, 'default' => '', 'label_block' => true, 'description' => __( 'Por ejemplo: selector de idioma, botón de entrar y aviso legal.', 'wakoo' ) ] );
		$this->add_control( 'turn', [ 'label' => __( 'Segundos por vuelta (0 = quieto)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 600, 'default' => 55 ] );
		$this->add_control( 'breakpoint', [ 'label' => __( 'Columna en pantallas de menos de (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 320, 'max' => 1600, 'default' => 900 ] );
		$this->add_control( 'fx', [
			'label'       => __( 'Animaciones', 'wakoo' ),
			'type'        => Controls_Manager::SELECT,
			'default'     => 'rich',
			'options'     => [
				'rich' => __( 'Completas (el panel nace del círculo, contenido en cascada)', 'wakoo' ),
				'soft' => __( 'Sencillas (solo deslizar)', 'wakoo' ),
			],
			'description' => __( 'Si el visitante pide «reducir movimiento» en su sistema, no se anima nada.', 'wakoo' ),
		] );
		$this->add_control( 'close_label', [ 'label' => __( 'Texto del botón cerrar (accesible)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Cerrar', 'wakoo' ) ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Colores', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$vars = [
			'c_bg'     => [ __( 'Fondo', 'wakoo' ), '#FAF5EA', '--wko-bg' ],
			'c_disc1'  => [ __( 'Círculo de fondo (centro)', 'wakoo' ), '#F8EBDD', '--wko-disc1' ],
			'c_disc2'  => [ __( 'Círculo de fondo (borde)', 'wakoo' ), '#EFD8BF', '--wko-disc2' ],
			'c_ring'   => [ __( 'Anillo de puntos', 'wakoo' ), '#C9A57A', '--wko-ring' ],
			'c_text'   => [ __( 'Texto', 'wakoo' ), '#1F3A5F', '--wko-text' ],
			'c_eb'     => [ __( 'Antetítulo', 'wakoo' ), '#8A4B3C', '--wko-eb' ],
			'c_em'     => [ __( 'Título destacado', 'wakoo' ), '#C4596C', '--wko-em' ],
			'c_hover'  => [ __( 'Borde al pasar', 'wakoo' ), '#E0B05C', '--wko-hover' ],
			'c_sel'    => [ __( 'Borde del elegido y pestaña activa', 'wakoo' ), '#DE8A99', '--wko-sel' ],
			'c_panel'  => [ __( 'Fondo del panel', 'wakoo' ), '#FFFDF8', '--wko-panel' ],
			'c_tab'    => [ __( 'Pestañas', 'wakoo' ), '#3C5676', '--wko-tab' ],
			'c_tab_on' => [ __( 'Pestaña activa (texto)', 'wakoo' ), '#8A4B3C', '--wko-tab-on' ],
		];
		foreach ( $vars as $k => $v ) {
			$this->add_control( $k, [ 'label' => $v[0], 'type' => Controls_Manager::COLOR, 'default' => $v[1], 'selectors' => [ '{{WRAPPER}} .wakoo-orbit, .wakoo-orbit__layer[data-owner="{{ID}}"]' => $v[2] . ': {{VALUE}};' ] ] );
		}
		$this->end_controls_section();

		$this->start_controls_section( 'sec_type', [ 'label' => __( 'Tipografía', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'ty_eb', 'label' => __( 'Antetítulo', 'wakoo' ), 'selector' => '{{WRAPPER}} .wakoo-orbit__eb' ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'ty_title', 'label' => __( 'Título', 'wakoo' ), 'selector' => '{{WRAPPER}} .wakoo-orbit__title' ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'ty_hint', 'label' => __( 'Indicación', 'wakoo' ), 'selector' => '{{WRAPPER}} .wakoo-orbit__hint' ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'ty_label', 'label' => __( 'Nombres de los círculos', 'wakoo' ), 'selector' => '{{WRAPPER}} .wakoo-orbit__lb' ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'ty_tab', 'label' => __( 'Pestañas', 'wakoo' ), 'selector' => '{{WRAPPER}} .wakoo-orbit__tab' ] );
		$this->end_controls_section();
	}

	private static function tpl( $id ) {
		if ( ! $id || ! class_exists( '\Wakoo\Modules\Templates\Module' ) ) { return ''; }
		return \Wakoo\Modules\Templates\Module::render_template( $id );
	}

	private static function link_attrs( $l ) {
		$url = is_array( $l ) ? ( $l['url'] ?? '' ) : '';
		$out = ' href="' . esc_url( $url ? $url : '#' ) . '"';
		if ( ! empty( $l['is_external'] ) ) { $out .= ' target="_blank"'; }
		if ( ! empty( $l['nofollow'] ) || ! empty( $l['is_external'] ) ) { $out .= ' rel="' . ( ! empty( $l['nofollow'] ) ? 'nofollow ' : '' ) . 'noopener"'; }
		return $out;
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$items = array_values( (array) ( $s['items'] ?? [] ) );
		$id    = $this->get_id();
		$close = $s['close_label'] ?: __( 'Cerrar', 'wakoo' );
		$cfg   = [ 'turn' => max( 0, (int) ( $s['turn'] ?? 55 ) ), 'bp' => max( 320, (int) ( $s['breakpoint'] ?? 900 ) ), 'fx' => 'soft' === ( $s['fx'] ?? 'rich' ) ? 0 : 1 ];
		$tag   = in_array( $s['title_tag'] ?? 'h1', [ 'h1', 'h2', 'p' ], true ) ? $s['title_tag'] : 'h1';

		echo '<div class="wakoo-orbit' . ( count( $items ) > 7 ? ' n8' : '' ) . '" data-wakoo-orbit="' . esc_attr( wp_json_encode( $cfg ) ) . '" data-owner="' . esc_attr( $id ) . '">';
		echo '<div class="wakoo-orbit__bg" aria-hidden="true"></div>';

		echo '<div class="wakoo-orbit__hero">';
		if ( '' !== (string) $s['eyebrow'] ) { echo '<span class="wakoo-orbit__eb">' . esc_html( $s['eyebrow'] ) . '</span>'; }
		if ( '' !== (string) $s['title'] || '' !== (string) $s['title_em'] ) {
			echo '<' . $tag . ' class="wakoo-orbit__title">' . wp_kses_post( $s['title'] ) . ( '' !== (string) $s['title_em'] ? ' <em>' . wp_kses_post( $s['title_em'] ) . '</em>' : '' ) . '</' . $tag . '>'; // phpcs:ignore
		}
		if ( '' !== (string) $s['cta_text'] ) { echo '<a class="wakoo-orbit__cta"' . self::link_attrs( $s['cta_link'] ) . '>' . esc_html( $s['cta_text'] ) . '</a>'; } // phpcs:ignore
		if ( '' !== (string) $s['hint'] ) { echo '<span class="wakoo-orbit__hint">' . esc_html( $s['hint'] ) . '</span>'; }
		echo '</div>';

		$logo = $s['logo']['url'] ?? '';
		echo '<div class="wakoo-orbit__logo">' . ( $logo ? '<img src="' . esc_url( $logo ) . '" alt="' . esc_attr( $s['logo_alt'] ) . '" fetchpriority="high">' : '' ) . '</div>';
		echo '<svg class="wakoo-orbit__ring" aria-hidden="true" focusable="false"><circle cx="50%" cy="50%" r="49%" fill="none" stroke-width="2" stroke-dasharray="3 14" stroke-linecap="round"/></svg>';

		echo '<div class="wakoo-orbit__veil" aria-hidden="true"></div>';
		echo '<div class="wakoo-orbit__items" role="group" aria-label="' . esc_attr( $s['hint'] ) . '">';
		foreach ( $items as $i => $it ) {
			$act  = in_array( $it['action'] ?? 'panel', [ 'panel', 'layer', 'link' ], true ) ? $it['action'] : 'panel';
			$img  = $it['image']['url'] ?? '';
			$anch = implode( ',', array_filter( array_map( 'sanitize_title', explode( ',', (string) ( $it['anchors'] ?? '' ) ) ) ) );
			$body = $img ? '<img src="' . esc_url( $img ) . '" alt="" draggable="false" loading="lazy">' : '';
			$body .= '<span class="wakoo-orbit__lb">' . esc_html( $it['label'] ) . '</span>';
			if ( 'link' === $act ) {
				echo '<a class="wakoo-orbit__it" style="--i:' . (int) $i . '" data-i="' . (int) $i . '" data-act="link"' . self::link_attrs( $it['link'] ?? [] ) . ( $anch ? ' data-anchors="' . esc_attr( $anch ) . '"' : '' ) . '>' . $body . '</a>'; // phpcs:ignore
			} else {
				echo '<button type="button" class="wakoo-orbit__it" style="--i:' . (int) $i . '" data-i="' . (int) $i . '" data-act="' . esc_attr( $act ) . '"' . ( $anch ? ' data-anchors="' . esc_attr( $anch ) . '"' : '' ) . ' aria-label="' . esc_attr( $it['label'] ) . '">' . $body . '</button>'; // phpcs:ignore
			}
		}
		echo '</div>';

		echo '<aside class="wakoo-orbit__panel" aria-hidden="true"><div class="wakoo-orbit__ph">';
		foreach ( $items as $i => $it ) {
			if ( 'panel' !== ( $it['action'] ?? 'panel' ) ) { continue; }
			$tabs = [ [ $it['tab_label'] ?: $it['label'], $it['template_id'] ?? '' ] ];
			if ( ! empty( $it['template_id_2'] ) ) { $tabs[] = [ $it['tab_label_2'] ?: $it['label'], $it['template_id_2'] ]; }
			echo '<div class="wakoo-orbit__tabs" role="tablist" data-i="' . (int) $i . '" hidden>';
			foreach ( $tabs as $t => $tab ) {
				echo '<button type="button" role="tab" class="wakoo-orbit__tab" id="wko-' . esc_attr( $id ) . '-t' . (int) $i . '-' . (int) $t . '" aria-controls="wko-' . esc_attr( $id ) . '-p' . (int) $i . '-' . (int) $t . '" data-t="' . (int) $t . '" aria-selected="false">' . esc_html( $tab[0] ) . '</button>';
			}
			echo '</div>';
		}
		echo '<button type="button" class="wakoo-orbit__x" aria-label="' . esc_attr( $close ) . '">✕</button></div><div class="wakoo-orbit__body" data-lenis-prevent>';
		foreach ( $items as $i => $it ) {
			if ( 'panel' !== ( $it['action'] ?? 'panel' ) ) { continue; }
			$tabs = [ $it['template_id'] ?? '' ];
			if ( ! empty( $it['template_id_2'] ) ) { $tabs[] = $it['template_id_2']; }
			foreach ( $tabs as $t => $tpl ) {
				echo '<div class="wakoo-orbit__pane" role="tabpanel" id="wko-' . esc_attr( $id ) . '-p' . (int) $i . '-' . (int) $t . '" aria-labelledby="wko-' . esc_attr( $id ) . '-t' . (int) $i . '-' . (int) $t . '" data-i="' . (int) $i . '" data-t="' . (int) $t . '" hidden>' . self::tpl( $tpl ) . '</div>'; // phpcs:ignore
			}
		}
		echo '</div></aside>';

		$foot = self::tpl( $s['foot_template_id'] ?? '' );
		if ( $foot ) { echo '<div class="wakoo-orbit__foot">' . $foot . '</div>'; } // phpcs:ignore

		foreach ( $items as $i => $it ) {
			if ( 'layer' !== ( $it['action'] ?? '' ) ) { continue; }
			echo '<div class="wakoo-orbit__layer" data-lenis-prevent data-owner="' . esc_attr( $id ) . '" data-i="' . (int) $i . '" role="dialog" aria-modal="true" aria-label="' . esc_attr( $it['label'] ) . '" hidden>';
			echo '<button type="button" class="wakoo-orbit__x wakoo-orbit__x--layer" aria-label="' . esc_attr( $close ) . '">✕</button>';
			echo self::tpl( $it['template_id'] ?? '' ); // phpcs:ignore
			echo '</div>';
		}
		echo '</div>';
	}
}
