<?php
/**
 * Wakoo Orbit: a big image in the centre and circles that turn slowly around it.
 * Each circle opens a side panel with up to two tabs (each tab is a saved Elementor
 * template), a full-screen layer (another saved template) or a link. On phones it
 * becomes a normal column: image, texts, a grid of circles and a full-screen sheet.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Orbit;

defined( 'ABSPATH' ) || die();

class Module {

	public static function init() {
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_action( 'elementor/frontend/after_register_scripts', function () {
			wp_register_script( 'wakoo-orbit', WAKOO_MODULES_URL . 'orbit/assets/orbit.js', [], WAKOO_VERSION, true );
		} );
		add_action( 'elementor/frontend/after_register_styles', function () {
			wp_register_style( 'wakoo-orbit', WAKOO_MODULES_URL . 'orbit/assets/orbit.css', [], WAKOO_VERSION );
		} );
	}

	public static function register_widget( $wm ) {
		require_once __DIR__ . '/widget.php';
		$wm->register( new Widget() );
	}
}

Module::init();
