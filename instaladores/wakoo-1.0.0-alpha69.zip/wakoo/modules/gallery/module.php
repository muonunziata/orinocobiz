<?php
/**
 * Wakoo: floating gallery + advanced lightbox.
 *
 * A gallery widget with grid / masonry / floating layouts whose images (and
 * videos) open in an advanced lightbox (zoom, keyboard, swipe, captions,
 * next/prev) powered by GLightbox (MIT, bundled in vendor/ with CREDITS.txt).
 * Each item can be an upload from the computer or an external URL. No GSAP.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Gallery;

defined( 'ABSPATH' ) || die();

class Module {

	public static function init() {
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'assets' ] );
		add_action( 'elementor/frontend/after_register_styles', [ __CLASS__, 'styles' ] );
	}

	public static function register_widget( $wm ) {
		require_once __DIR__ . '/widget.php';
		$wm->register( new Widget() );
	}

	public static function assets() {
		wp_register_script( 'wakoo-glightbox', WAKOO_MODULES_URL . 'gallery/vendor/glightbox.min.js', [], '3.3.1', true );
		wp_register_script( 'wakoo-gallery', WAKOO_MODULES_URL . 'gallery/assets/gallery.js', [ 'wakoo-glightbox' ], WAKOO_VERSION, true );
	}

	public static function styles() {
		wp_register_style( 'wakoo-glightbox', WAKOO_MODULES_URL . 'gallery/vendor/glightbox.min.css', [], '3.3.1' );
		wp_register_style( 'wakoo-gallery', WAKOO_MODULES_URL . 'gallery/assets/gallery.css', [ 'wakoo-glightbox' ], WAKOO_VERSION );
	}
}

Module::init();
