( function () {
	'use strict';

	var instance = null;

	function build() {
		if ( ! window.GLightbox ) { return; }
		var any = document.querySelector( '.wakoo-gallery[data-lightbox="yes"] .wakoo-glightbox' );
		if ( ! any ) { return; }
		// Re-create a single lightbox over all Wakoo galleries; GLightbox groups
		// items by their data-gallery attribute, so each widget stays separate.
		if ( instance && instance.destroy ) { instance.destroy(); }
		instance = window.GLightbox( {
			selector: '.wakoo-glightbox',
			loop: true,
			touchNavigation: true,
			zoomable: true,
			openEffect: 'zoom',
			closeEffect: 'fade',
		} );
	}

	function boot() { build(); }

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}
	if ( window.jQuery ) {
		jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend && elementorFrontend.hooks ) {
				elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-gallery.default', function () { build(); } );
			}
		} );
	}
}() );
