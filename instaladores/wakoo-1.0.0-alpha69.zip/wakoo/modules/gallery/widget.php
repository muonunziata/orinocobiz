<?php
/**
 * Wakoo floating gallery widget.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Gallery;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

defined( 'ABSPATH' ) || die();

class Widget extends Widget_Base {

	public function get_name() { return 'wakoo-gallery'; }
	public function get_title() { return __( 'Galería flotante (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-gallery-grid'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'gallery', 'galeria', 'lightbox', 'masonry', 'imagenes', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-gallery' ]; }
	public function get_style_depends() { return [ 'wakoo-gallery' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_items', [ 'label' => __( 'Imágenes', 'wakoo' ) ] );

		$rep = new Repeater();
		$rep->add_control( 'source', [
			'label'   => __( 'Origen', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'file',
			'options' => [ 'file' => __( 'Subir del ordenador', 'wakoo' ), 'url' => __( 'Enlace (URL)', 'wakoo' ) ],
		] );
		$rep->add_control( 'image', [
			'label'     => __( 'Imagen', 'wakoo' ),
			'type'      => Controls_Manager::MEDIA,
			'default'   => [ 'url' => \Elementor\Utils::get_placeholder_image_src() ],
			'condition' => [ 'source' => 'file' ],
		] );
		$rep->add_control( 'image_url', [
			'label'       => __( 'URL de la imagen', 'wakoo' ),
			'type'        => Controls_Manager::TEXT,
			'placeholder' => 'https://.../foto.jpg',
			'label_block' => true,
			'condition'   => [ 'source' => 'url' ],
		] );
		$rep->add_control( 'kind', [
			'label'   => __( 'Tipo', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'image',
			'options' => [ 'image' => __( 'Imagen', 'wakoo' ), 'video' => __( 'Vídeo (YouTube/Vimeo/MP4)', 'wakoo' ) ],
		] );
		$rep->add_control( 'video_url', [
			'label'       => __( 'URL del vídeo', 'wakoo' ),
			'type'        => Controls_Manager::TEXT,
			'placeholder' => 'https://youtu.be/...',
			'label_block' => true,
			'condition'   => [ 'kind' => 'video' ],
		] );
		$rep->add_control( 'caption', [
			'label'       => __( 'Pie de foto', 'wakoo' ),
			'type'        => Controls_Manager::TEXT,
			'label_block' => true,
		] );

		$this->add_control( 'items', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $rep->get_controls(),
			'title_field' => '{{{ caption || "Imagen" }}}',
			'default'     => [
				[ 'source' => 'file', 'caption' => '' ],
				[ 'source' => 'file', 'caption' => '' ],
				[ 'source' => 'file', 'caption' => '' ],
			],
		] );

		$this->end_controls_section();

		$this->start_controls_section( 'sec_layout', [ 'label' => __( 'Disposición', 'wakoo' ) ] );

		$this->add_control( 'layout', [
			'label'   => __( 'Estilo', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'grid',
			'options' => [
				'grid'     => __( 'Rejilla', 'wakoo' ),
				'masonry'  => __( 'Mosaico (masonry)', 'wakoo' ),
				'floating' => __( 'Flotante', 'wakoo' ),
			],
		] );
		$this->add_responsive_control( 'columns', [
			'label'          => __( 'Columnas', 'wakoo' ),
			'type'           => Controls_Manager::SELECT,
			'default'        => '3',
			'tablet_default' => '2',
			'mobile_default' => '1',
			'options'        => [ '1' => '1', '2' => '2', '3' => '3', '4' => '4', '5' => '5' ],
			'selectors'      => [ '{{WRAPPER}} .wakoo-gallery' => '--wk-cols: {{VALUE}};' ],
		] );
		$this->add_responsive_control( 'gap', [
			'label'     => __( 'Separación', 'wakoo' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => [ 'px' => [ 'min' => 0, 'max' => 60 ] ],
			'default'   => [ 'size' => 14, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .wakoo-gallery' => '--wk-gap: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'radius', [
			'label'     => __( 'Redondeo', 'wakoo' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => [ 'px' => [ 'min' => 0, 'max' => 40 ] ],
			'default'   => [ 'size' => 12, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .wakoo-gallery' => '--wk-radius: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'hover', [
			'label'   => __( 'Efecto al pasar el ratón', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'zoom',
			'options' => [
				'zoom' => __( 'Acercar', 'wakoo' ),
				'lift' => __( 'Elevar', 'wakoo' ),
				'none' => __( 'Ninguno', 'wakoo' ),
			],
		] );
		$this->add_control( 'lightbox', [
			'label'        => __( 'Lightbox al hacer clic', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => 'yes',
		] );

		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$items = $s['items'] ?? [];
		if ( empty( $items ) ) {
			return;
		}
		$layout = in_array( $s['layout'] ?? 'grid', [ 'grid', 'masonry', 'floating' ], true ) ? $s['layout'] : 'grid';
		$hover = in_array( $s['hover'] ?? 'zoom', [ 'zoom', 'lift', 'none' ], true ) ? $s['hover'] : 'zoom';
		$lightbox = ( 'yes' === ( $s['lightbox'] ?? 'yes' ) );
		$gid = 'wk-gal-' . $this->get_id();

		$classes = sprintf( 'wakoo-gallery wakoo-gallery--%s wakoo-gallery--hover-%s', $layout, $hover );
		printf( '<div class="%s" data-lightbox="%s">', esc_attr( $classes ), $lightbox ? 'yes' : 'no' );

		foreach ( $items as $item ) {
			$is_video = ( 'video' === ( $item['kind'] ?? 'image' ) );
			if ( $is_video ) {
				$href  = trim( $item['video_url'] ?? '' );
				$thumb = ( 'url' === ( $item['source'] ?? 'file' ) )
					? trim( $item['image_url'] ?? '' )
					: ( $item['image']['url'] ?? '' );
			} elseif ( 'url' === ( $item['source'] ?? 'file' ) ) {
				$href  = trim( $item['image_url'] ?? '' );
				$thumb = $href;
			} else {
				$href  = $item['image']['url'] ?? '';
				$thumb = $href;
			}
			if ( ! $href && ! $thumb ) {
				continue;
			}
			$cap = $item['caption'] ?? '';

			$attrs = [
				'href'         => esc_url( $href ),
				'class'        => 'wakoo-gallery__item' . ( $lightbox ? ' wakoo-glightbox' : '' ),
				'data-gallery' => esc_attr( $gid ),
			];
			// Force the media type so GLightbox never guesses wrong from a URL
			// that lacks a file extension.
			$attrs['data-type'] = $is_video ? 'video' : 'image';
			if ( $cap ) {
				$attrs['data-description'] = esc_attr( $cap );
				$attrs['data-title']       = esc_attr( $cap );
			}
			$attr_str = '';
			foreach ( $attrs as $k => $v ) {
				$attr_str .= sprintf( ' %s="%s"', $k, $v );
			}

			echo '<a' . $attr_str . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			printf(
				'<img src="%s" alt="%s" loading="lazy">',
				esc_url( $thumb ), esc_attr( $cap )
			);
			if ( $is_video ) {
				echo '<span class="wakoo-gallery__play" aria-hidden="true"></span>';
			}
			if ( $cap ) {
				printf( '<figcaption class="wakoo-gallery__cap">%s</figcaption>', esc_html( $cap ) );
			}
			echo '</a>';
		}

		echo '</div>';
	}
}
