<?php
/**
 * Wakoo code-highlight widget.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Code;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Widget extends Widget_Base {

	public function get_name() { return 'wakoo-code'; }
	public function get_title() { return __( 'Bloque de código (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-code'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'code', 'codigo', 'prism', 'highlight', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-code' ]; }
	public function get_style_depends() { return [ 'wakoo-code' ]; }

	private function languages() {
		return [
			'markup'     => 'HTML / XML',
			'css'        => 'CSS',
			'javascript' => 'JavaScript',
			'php'        => 'PHP',
			'python'     => 'Python',
			'bash'       => 'Bash / Shell',
			'json'       => 'JSON',
			'sql'        => 'SQL',
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec', [ 'label' => __( 'Código', 'wakoo' ) ] );

		$this->add_control( 'language', [
			'label'   => __( 'Lenguaje', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'php',
			'options' => $this->languages(),
		] );
		$this->add_control( 'code', [
			'label'       => __( 'Código', 'wakoo' ),
			'type'        => Controls_Manager::CODE,
			'language'    => 'php',
			'rows'        => 14,
			'default'     => "<?php\necho 'Hola, Wakoo';",
		] );
		$this->add_control( 'line_numbers', [
			'label'        => __( 'Números de línea', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => 'yes',
		] );
		$this->add_control( 'copy', [
			'label'        => __( 'Botón de copiar', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => 'yes',
		] );

		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$langs = $this->languages();
		$lang = isset( $langs[ $s['language'] ?? 'php' ] ) ? $s['language'] : 'markup';
		$code = (string) ( $s['code'] ?? '' );
		$ln = ( 'yes' === ( $s['line_numbers'] ?? 'yes' ) );
		$copy = ( 'yes' === ( $s['copy'] ?? 'yes' ) );

		$pre_class = 'wakoo-code__pre language-' . $lang . ( $ln ? ' line-numbers' : '' );

		echo '<div class="wakoo-code">';
		if ( $copy ) {
			printf(
				'<button type="button" class="wakoo-code__copy" aria-label="%s">%s</button>',
				esc_attr__( 'Copiar código', 'wakoo' ),
				esc_html__( 'Copiar', 'wakoo' )
			);
		}
		printf(
			'<pre class="%s"><code class="language-%s">%s</code></pre>',
			esc_attr( $pre_class ),
			esc_attr( $lang ),
			esc_html( $code )
		);
		echo '</div>';
	}
}
