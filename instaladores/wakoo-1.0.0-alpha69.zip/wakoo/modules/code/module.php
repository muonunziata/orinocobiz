<?php
/**
 * Wakoo: code block with syntax highlighting.
 *
 * A widget that shows a block of source code with coloured syntax highlighting,
 * optional line numbers and a copy button. Powered by Prism (MIT, bundled in
 * vendor/ with CREDITS.txt) with a curated set of languages (markup, css,
 * javascript, php, python, bash, json, sql) plus the line-numbers plugin.
 * No GSAP.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Code;

defined( 'ABSPATH' ) || die();

class Module {

	public static function init() {
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'assets' ] );
		add_action( 'elementor/frontend/after_register_styles', [ __CLASS__, 'styles' ] );
	}

	public static function register_widget( $wm ) {
		require_once __DIR__ . '/widget.php';
		$wm->register( new Widget() );
	}

	public static function assets() {
		wp_register_script( 'wakoo-prism', WAKOO_MODULES_URL . 'code/vendor/prism.bundle.min.js', [], '1.29.0', true );
		wp_register_script( 'wakoo-code', WAKOO_MODULES_URL . 'code/assets/code.js', [ 'wakoo-prism' ], WAKOO_VERSION, true );
	}

	public static function styles() {
		wp_register_style( 'wakoo-prism', WAKOO_MODULES_URL . 'code/vendor/prism-theme.min.css', [], '1.29.0' );
		wp_register_style( 'wakoo-code', WAKOO_MODULES_URL . 'code/assets/code.css', [ 'wakoo-prism' ], WAKOO_VERSION );
	}
}

Module::init();
