( function () {
	'use strict';

	function highlight( scope ) {
		if ( window.Prism && window.Prism.highlightAllUnder ) {
			window.Prism.highlightAllUnder( scope || document );
		}
	}

	function wireCopy( root ) {
		( root || document ).querySelectorAll( '.wakoo-code__copy' ).forEach( function ( btn ) {
			if ( btn.dataset.wakooCopyInit ) { return; }
			btn.dataset.wakooCopyInit = '1';
			btn.addEventListener( 'click', function () {
				var block = btn.parentNode.querySelector( 'code' );
				if ( ! block ) { return; }
				var text = block.textContent;
				var done = function () {
					var old = btn.textContent;
					btn.textContent = '✓';
					btn.classList.add( 'is-copied' );
					window.setTimeout( function () { btn.textContent = old; btn.classList.remove( 'is-copied' ); }, 1400 );
				};
				if ( navigator.clipboard && navigator.clipboard.writeText ) {
					navigator.clipboard.writeText( text ).then( done, function () {} );
				} else {
					var ta = document.createElement( 'textarea' );
					ta.value = text; document.body.appendChild( ta ); ta.select();
					try { document.execCommand( 'copy' ); done(); } catch ( e ) {}
					document.body.removeChild( ta );
				}
			} );
		} );
	}

	function boot( scope ) {
		highlight( scope );
		wireCopy( scope );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', function () { boot(); } );
	} else {
		boot();
	}
	if ( window.jQuery ) {
		jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend && elementorFrontend.hooks ) {
				elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-code.default', function ( $s ) { boot( $s[ 0 ] ); } );
			}
		} );
	}
}() );
