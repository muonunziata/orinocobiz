<?php
/**
 * Wakoo social providers. Each provider connects to a network's OWN official
 * API (no third-party plugin or aggregator service) and normalises posts to a
 * common shape:
 *   id, network, type(image|video), media, thumb, permalink, caption,
 *   author, avatar, date(unix ts)
 *
 * fetch() returns an array of such posts or a WP_Error. The caller caches the
 * result and falls back to demo posts when a network is not connected.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Social;

defined( 'ABSPATH' ) || die();

class Providers {

	/** @return array<string,array> slug => [label, color, fields, fetch] */
	public static function all() {
		$list = [
			'instagram' => [
				'label'    => 'Instagram',
				'color'    => '#E1306C',
				'help'     => __( 'Cuenta Profesional (Business o Creator) de Instagram. Con una app de Meta propia puedes conectar con un botón; si ya tienes un token de larga duración, pégalo.', 'wakoo' ),
				'required' => [ 'token' ],
				'fields'   => [
					'token'      => [ 'label' => __( 'Token de acceso (larga duración)', 'wakoo' ), 'secret' => true ],
					'handle'     => [ 'label' => __( 'Usuario (para la cabecera y el botón Seguir)', 'wakoo' ), 'optional' => true ],
					'app_id'     => [ 'label' => __( 'ID de la app de Instagram', 'wakoo' ), 'optional' => true ],
					'app_secret' => [ 'label' => __( 'Clave secreta de la app', 'wakoo' ), 'secret' => true, 'optional' => true ],
				],
				'oauth'    => true,
				'steps'    => [
					__( 'Convierte tu Instagram en cuenta Profesional (Ajustes → Tipo de cuenta). Las cuentas personales no tienen API.', 'wakoo' ),
					__( 'Entra en developers.facebook.com/apps, crea una app de tipo «Empresa» y añade el producto «Instagram» → «API con inicio de sesión de Instagram».', 'wakoo' ),
					__( 'En «Configuración de la API con inicio de sesión de Instagram» pega la URI de redireccionamiento que ves abajo, y copia el ID y la clave secreta de la app de Instagram.', 'wakoo' ),
					__( 'Añade tu cuenta como probador de Instagram (Roles → Roles de la app) y acepta la invitación desde Instagram (Ajustes → Sitios web → Invitaciones de probador).', 'wakoo' ),
					__( 'Pega aquí el ID y la clave y pulsa «Conectar con Instagram». Wakoo guardará el token de 60 días y lo renovará solo.', 'wakoo' ),
				],
				'docs'     => 'https://developers.facebook.com/docs/instagram-platform/instagram-api-with-instagram-login',
				'fetch'    => [ __CLASS__, 'fetch_instagram' ],
			],
			'facebook'  => [
				'label'    => 'Facebook',
				'color'    => '#1877F2',
				'help'     => __( 'Página de Facebook (no perfiles personales). Con una app de Meta propia conectas con un botón y eliges la página.', 'wakoo' ),
				'required' => [ 'page_id', 'token' ],
				'fields'   => [
					'page_id'    => [ 'label' => __( 'ID de la página', 'wakoo' ) ],
					'token'      => [ 'label' => __( 'Token de la página', 'wakoo' ), 'secret' => true ],
					'handle'     => [ 'label' => __( 'Nombre de usuario de la página (para Seguir)', 'wakoo' ), 'optional' => true ],
					'app_id'     => [ 'label' => __( 'ID de la app de Meta', 'wakoo' ), 'optional' => true ],
					'app_secret' => [ 'label' => __( 'Clave secreta de la app', 'wakoo' ), 'secret' => true, 'optional' => true ],
				],
				'oauth'    => true,
				'steps'    => [
					__( 'Entra en developers.facebook.com/apps y crea una app de tipo «Empresa» (con tu cuenta, que debe administrar la página).', 'wakoo' ),
					__( 'Añade el producto «Inicio de sesión con Facebook para empresas» y, en su configuración, pega la URI de redireccionamiento que ves abajo.', 'wakoo' ),
					__( 'En Configuración → Básica copia el ID de la app y la clave secreta y pégalos aquí.', 'wakoo' ),
					__( 'Pulsa «Conectar con Facebook», acepta los permisos y elige la página. Los tokens de página no caducan.', 'wakoo' ),
					__( 'Mientras la app esté en modo desarrollo funciona con tus propias páginas sin revisión de Meta; para páginas de terceros Meta exige revisión de la app.', 'wakoo' ),
				],
				'docs'     => 'https://developers.facebook.com/docs/pages-api/getting-started',
				'fetch'    => [ __CLASS__, 'fetch_facebook' ],
			],
			'youtube'   => [
				'label'    => 'YouTube',
				'color'    => '#FF0000',
				'help'     => __( 'No necesita iniciar sesión: solo una clave de API gratuita y tu canal.', 'wakoo' ),
				'required' => [ 'api_key', 'channel_id' ],
				'fields'   => [
					'api_key'    => [ 'label' => __( 'Clave de API', 'wakoo' ), 'secret' => true ],
					'channel_id' => [ 'label' => __( 'Canal: ID (UC…) o @usuario', 'wakoo' ) ],
				],
				'steps'    => [
					__( 'Entra en console.cloud.google.com, crea un proyecto y activa «YouTube Data API v3» (Biblioteca de APIs).', 'wakoo' ),
					__( 'En Credenciales → Crear credenciales → Clave de API. Restríngela a «YouTube Data API v3» y, si quieres, a tu dominio.', 'wakoo' ),
					__( 'Pega la clave aquí y escribe tu canal: el @usuario (por ejemplo @miCanal) o el ID que empieza por UC.', 'wakoo' ),
				],
				'docs'     => 'https://developers.google.com/youtube/v3/getting-started',
				'fetch'    => [ __CLASS__, 'fetch_youtube' ],
			],
			'tiktok'    => [
				'label'    => 'TikTok',
				'color'    => '#000000',
				'help'     => __( 'Exige una app de TikTok for Developers con la Display API aprobada. Es el trámite más largo.', 'wakoo' ),
				'required' => [ 'token' ],
				'fields'   => [
					'token'         => [ 'label' => __( 'Token de acceso', 'wakoo' ), 'secret' => true ],
					'handle'        => [ 'label' => __( 'Usuario (sin @, para Seguir)', 'wakoo' ), 'optional' => true ],
					'client_key'    => [ 'label' => __( 'Client key de la app', 'wakoo' ), 'optional' => true ],
					'client_secret' => [ 'label' => __( 'Client secret de la app', 'wakoo' ), 'secret' => true, 'optional' => true ],
				],
				'oauth'    => true,
				'steps'    => [
					__( 'Crea una app en developers.tiktok.com y añade los productos «Login Kit» y «Display API» con los permisos user.info.basic y video.list.', 'wakoo' ),
					__( 'En Login Kit pega la URI de redireccionamiento que ves abajo. TikTok revisa la app antes de dejarla pública; mientras está en «sandbox» solo funcionan las cuentas que añadas como usuarios de prueba.', 'wakoo' ),
					__( 'Pega aquí Client key y Client secret y pulsa «Conectar con TikTok». El token dura 24 horas y Wakoo lo renueva solo mientras no pasen 365 días.', 'wakoo' ),
					__( 'Las imágenes de portada de TikTok caducan en horas, así que el feed se actualiza cada hora como máximo.', 'wakoo' ),
				],
				'docs'     => 'https://developers.tiktok.com/doc/display-api-overview',
				'fetch'    => [ __CLASS__, 'fetch_tiktok' ],
			],
			'x'         => [
				'label'    => 'X',
				'color'    => '#111111',
				'help'     => __( 'La API de X para leer publicaciones es de pago (consulta su plan vigente). Sin plan, usa el modo demostración.', 'wakoo' ),
				'required' => [ 'bearer', 'user_id' ],
				'fields'   => [
					'bearer'  => [ 'label' => __( 'Bearer token', 'wakoo' ), 'secret' => true ],
					'user_id' => [ 'label' => __( 'Usuario: ID numérico o @usuario', 'wakoo' ) ],
				],
				'steps'    => [
					__( 'Entra en developer.x.com, crea un proyecto y una app con un plan que permita leer publicaciones.', 'wakoo' ),
					__( 'En «Keys and tokens» genera el Bearer token y pégalo aquí.', 'wakoo' ),
					__( 'Escribe tu @usuario; Wakoo averigua el ID por ti.', 'wakoo' ),
				],
				'docs'     => 'https://developer.x.com/en/docs/x-api',
				'fetch'    => [ __CLASS__, 'fetch_x' ],
			],
		];
		/** Allow extensions to register more native providers. */
		return apply_filters( 'wakoo/social/providers', $list );
	}

	/* ---------- small HTTP helper ---------- */
	private static function get( $url, $args = [] ) {
		$res = wp_remote_get( $url, array_merge( [ 'timeout' => 12 ], $args ) );
		if ( is_wp_error( $res ) ) { return $res; }
		$code = wp_remote_retrieve_response_code( $res );
		$body = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( $code < 200 || $code >= 300 ) {
			$msg = is_array( $body ) && isset( $body['error']['message'] ) ? $body['error']['message'] : ( 'HTTP ' . $code );
			return new \WP_Error( 'http', $msg );
		}
		return is_array( $body ) ? $body : new \WP_Error( 'parse', __( 'Respuesta no válida.', 'wakoo' ) );
	}

	/* ---------- Instagram ---------- */
	public static function fetch_instagram( $c, $limit ) {
		$url = add_query_arg( [
			'fields'       => 'id,caption,media_type,media_url,permalink,thumbnail_url,timestamp,username',
			'limit'        => $limit,
			'access_token' => $c['token'] ?? '',
		], 'https://graph.instagram.com/me/media' );
		$d = self::get( $url );
		if ( is_wp_error( $d ) ) { return $d; }
		$out = [];
		foreach ( (array) ( $d['data'] ?? [] ) as $m ) {
			$video = ( 'VIDEO' === ( $m['media_type'] ?? '' ) );
			$out[] = self::post( [
				'id'        => $m['id'] ?? '',
				'network'   => 'instagram',
				'type'      => $video ? 'video' : 'image',
				'media'     => $m['media_url'] ?? '',
				'thumb'     => $video ? ( $m['thumbnail_url'] ?? ( $m['media_url'] ?? '' ) ) : ( $m['media_url'] ?? '' ),
				'permalink' => $m['permalink'] ?? '',
				'caption'   => $m['caption'] ?? '',
				'author'    => $m['username'] ?? '',
				'date'      => isset( $m['timestamp'] ) ? strtotime( $m['timestamp'] ) : 0,
			] );
		}
		return $out;
	}

	/* ---------- Facebook ---------- */
	public static function fetch_facebook( $c, $limit ) {
		$url = add_query_arg( [
			'fields'       => 'message,full_picture,permalink_url,created_time,from',
			'limit'        => $limit,
			'access_token' => $c['token'] ?? '',
		], 'https://graph.facebook.com/v19.0/' . rawurlencode( $c['page_id'] ?? '' ) . '/posts' );
		$d = self::get( $url );
		if ( is_wp_error( $d ) ) { return $d; }
		$out = [];
		foreach ( (array) ( $d['data'] ?? [] ) as $m ) {
			$out[] = self::post( [
				'id'        => $m['id'] ?? '',
				'network'   => 'facebook',
				'type'      => 'image',
				'media'     => $m['full_picture'] ?? '',
				'thumb'     => $m['full_picture'] ?? '',
				'permalink' => $m['permalink_url'] ?? '',
				'caption'   => $m['message'] ?? '',
				'author'    => $m['from']['name'] ?? '',
				'date'      => isset( $m['created_time'] ) ? strtotime( $m['created_time'] ) : 0,
			] );
		}
		return $out;
	}

	/* ---------- YouTube ---------- */
	public static function fetch_youtube( $c, $limit ) {
		$key = $c['api_key'] ?? '';
		$ch  = $c['channel_id'] ?? '';
		// Resolve the channel's uploads playlist (the channel can be given as @handle or UC id).
		$q    = ( 0 === strpos( $ch, '@' ) ) ? [ 'forHandle' => $ch ] : [ 'id' => $ch ];
		$chan = self::get( add_query_arg( array_merge( [ 'part' => 'contentDetails', 'key' => $key ], $q ), 'https://www.googleapis.com/youtube/v3/channels' ) );
		if ( is_wp_error( $chan ) ) { return $chan; }
		$pl = $chan['items'][0]['contentDetails']['relatedPlaylists']['uploads'] ?? '';
		if ( ! $pl ) { return new \WP_Error( 'noch', __( 'Canal no encontrado.', 'wakoo' ) ); }
		$d = self::get( add_query_arg( [ 'part' => 'snippet', 'playlistId' => $pl, 'maxResults' => $limit, 'key' => $key ], 'https://www.googleapis.com/youtube/v3/playlistItems' ) );
		if ( is_wp_error( $d ) ) { return $d; }
		$out = [];
		foreach ( (array) ( $d['items'] ?? [] ) as $m ) {
			$sn  = $m['snippet'] ?? [];
			$vid = $sn['resourceId']['videoId'] ?? '';
			$th  = $sn['thumbnails']['high']['url'] ?? ( $sn['thumbnails']['default']['url'] ?? '' );
			$out[] = self::post( [
				'id'        => $vid,
				'network'   => 'youtube',
				'type'      => 'video',
				'media'     => $vid ? 'https://www.youtube.com/watch?v=' . $vid : '',
				'thumb'     => $th,
				'permalink' => $vid ? 'https://www.youtube.com/watch?v=' . $vid : '',
				'caption'   => $sn['title'] ?? '',
				'author'    => $sn['channelTitle'] ?? '',
				'date'      => isset( $sn['publishedAt'] ) ? strtotime( $sn['publishedAt'] ) : 0,
			] );
		}
		return $out;
	}

	/* ---------- TikTok ---------- */
	public static function fetch_tiktok( $c, $limit ) {
		$res = wp_remote_post( 'https://open.tiktokapis.com/v2/video/list/?fields=' . rawurlencode( 'id,title,cover_image_url,share_url,create_time' ), [
			'timeout' => 12,
			'headers' => [ 'Authorization' => 'Bearer ' . ( $c['token'] ?? '' ), 'Content-Type' => 'application/json' ],
			'body'    => wp_json_encode( [ 'max_count' => (int) $limit ] ),
		] );
		if ( is_wp_error( $res ) ) { return $res; }
		$body = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( ! empty( $body['error']['code'] ) && 'ok' !== $body['error']['code'] ) {
			return new \WP_Error( 'tiktok', $body['error']['message'] ?? 'TikTok error' );
		}
		$out = [];
		foreach ( (array) ( $body['data']['videos'] ?? [] ) as $m ) {
			$out[] = self::post( [
				'id'        => $m['id'] ?? '',
				'network'   => 'tiktok',
				'type'      => 'video',
				'media'     => $m['share_url'] ?? '',
				'thumb'     => $m['cover_image_url'] ?? '',
				'permalink' => $m['share_url'] ?? '',
				'caption'   => $m['title'] ?? '',
				'date'      => isset( $m['create_time'] ) ? (int) $m['create_time'] : 0,
			] );
		}
		return $out;
	}

	/* ---------- X ---------- */
	public static function fetch_x( $c, $limit ) {
		$uid = ltrim( (string) ( $c['user_id'] ?? '' ), ' ' );
		if ( '' !== $uid && ! ctype_digit( $uid ) ) {
			$u = self::get( 'https://api.twitter.com/2/users/by/username/' . rawurlencode( ltrim( $uid, '@' ) ), [ 'headers' => [ 'Authorization' => 'Bearer ' . ( $c['bearer'] ?? '' ) ] ] );
			if ( is_wp_error( $u ) ) { return $u; }
			$c['user_id'] = $u['data']['id'] ?? '';
		}
		$url = add_query_arg( [
			'max_results'    => max( 5, min( 100, (int) $limit ) ),
			'tweet.fields'   => 'created_at',
			'expansions'     => 'attachments.media_keys',
			'media.fields'   => 'url,preview_image_url,type',
		], 'https://api.twitter.com/2/users/' . rawurlencode( $c['user_id'] ?? '' ) . '/tweets' );
		$d = self::get( $url, [ 'headers' => [ 'Authorization' => 'Bearer ' . ( $c['bearer'] ?? '' ) ] ] );
		if ( is_wp_error( $d ) ) { return $d; }
		$media = [];
		foreach ( (array) ( $d['includes']['media'] ?? [] ) as $m ) {
			$media[ $m['media_key'] ] = $m;
		}
		$out = [];
		foreach ( (array) ( $d['data'] ?? [] ) as $t ) {
			$mk    = $t['attachments']['media_keys'][0] ?? '';
			$mm    = $mk && isset( $media[ $mk ] ) ? $media[ $mk ] : [];
			$thumb = $mm['url'] ?? ( $mm['preview_image_url'] ?? '' );
			$out[] = self::post( [
				'id'        => $t['id'] ?? '',
				'network'   => 'x',
				'type'      => ( isset( $mm['type'] ) && 'photo' !== $mm['type'] ) ? 'video' : 'image',
				'media'     => $thumb,
				'thumb'     => $thumb,
				'permalink' => 'https://x.com/i/web/status/' . ( $t['id'] ?? '' ),
				'caption'   => $t['text'] ?? '',
				'date'      => isset( $t['created_at'] ) ? strtotime( $t['created_at'] ) : 0,
			] );
		}
		return $out;
	}

	/* ---------- demo posts (shown until a network is connected) ---------- */
	public static function demo( $network, $limit ) {
		$prov = self::all();
		$label = $prov[ $network ]['label'] ?? ucfirst( $network );
		$dir   = WAKOO_MODULES_URL . 'social/assets/samples/';
		$caps  = [
			__( 'Novedades de esta semana ✨', 'wakoo' ),
			__( 'Entre bastidores del equipo', 'wakoo' ),
			__( 'Gracias por acompañarnos 🙌', 'wakoo' ),
			__( 'Nuevo lanzamiento disponible', 'wakoo' ),
			__( 'Un día en la oficina', 'wakoo' ),
			__( 'Pregúntanos lo que quieras', 'wakoo' ),
		];
		$out = [];
		for ( $i = 0; $i < $limit; $i++ ) {
			$n = ( $i % 6 ) + 1;
			$out[] = self::post( [
				'id'        => 'demo-' . $network . '-' . $i,
				'network'   => $network,
				'type'      => ( 0 === $i % 3 && in_array( $network, [ 'youtube', 'tiktok' ], true ) ) ? 'video' : 'image',
				'media'     => $dir . 'sample' . $n . '.jpg',
				'thumb'     => $dir . 'sample' . $n . '.jpg',
				'permalink' => '#',
				'caption'   => $caps[ $i % count( $caps ) ],
				'author'    => $label,
				'date'      => time() - $i * 86400,
				'demo'      => true,
			] );
		}
		return $out;
	}

	/** Public profile (name, link, initial) of a network for the feed header and the follow button. */
	public static function profile( $network, $posts = [] ) {
		$c      = Module::creds( $network );
		$handle = ltrim( (string) ( $c['handle'] ?? '' ), '@ ' );
		$name   = $handle;
		if ( '' === $name && ! empty( $posts[0]['author'] ) && empty( $posts[0]['demo'] ) ) { $name = $posts[0]['author']; }
		if ( '' === $handle && 'youtube' !== $network && 'x' !== $network ) { $handle = $name; }
		$url = '';
		switch ( $network ) {
			case 'instagram': $url = $handle ? 'https://www.instagram.com/' . rawurlencode( $handle ) . '/' : ''; break;
			case 'facebook':  $url = ( $handle || ! empty( $c['page_id'] ) ) ? 'https://www.facebook.com/' . rawurlencode( $handle ? $handle : $c['page_id'] ) : ''; break;
			case 'youtube':
				$ch  = (string) ( $c['channel_id'] ?? '' );
				$url = $ch ? ( 0 === strpos( $ch, '@' ) ? 'https://www.youtube.com/' . rawurlencode( $ch ) : 'https://www.youtube.com/channel/' . rawurlencode( $ch ) ) : '';
				if ( '' === $name ) { $name = 0 === strpos( $ch, '@' ) ? substr( $ch, 1 ) : ''; }
				break;
			case 'tiktok':    $url = $handle ? 'https://www.tiktok.com/@' . rawurlencode( $handle ) : ''; break;
			case 'x':
				$u   = ltrim( (string) ( $c['user_id'] ?? '' ), '@' );
				$url = ( $u && ! ctype_digit( $u ) ) ? 'https://x.com/' . rawurlencode( $u ) : '';
				if ( '' === $name && $u && ! ctype_digit( $u ) ) { $name = $u; }
				break;
		}
		return [ 'name' => $name, 'url' => $url, 'label' => self::all()[ $network ]['label'] ?? $network ];
	}

	private static function post( $a ) {
		return array_merge( [
			'id' => '', 'network' => '', 'type' => 'image', 'media' => '', 'thumb' => '',
			'permalink' => '', 'caption' => '', 'author' => '', 'avatar' => '', 'date' => 0, 'demo' => false,
		], $a );
	}
}
