/* Wakoo Social feeds: carousel, load more, lightbox. No dependencies. */
(function () {
	'use strict';
	function init(root) {
		if (root.__wkSocial) { return; }
		root.__wkSocial = true;
		var layout = root.getAttribute('data-layout');
		var list = root.querySelector('.wakoo-social');

		var more = root.querySelector('.wakoo-social__morebtn');
		if (more && list) {
			var step = parseInt(root.getAttribute('data-step'), 10) || 6;
			more.addEventListener('click', function () {
				var hid = list.querySelectorAll('.is-extra[hidden]');
				for (var i = 0; i < step && i < hid.length; i++) { hid[i].removeAttribute('hidden'); }
				if (list.querySelectorAll('.is-extra[hidden]').length === 0) { more.parentNode.style.display = 'none'; }
			});
		}

		if (layout === 'carousel' && list) {
			var prev = root.querySelector('.wakoo-social__nav--prev'), next = root.querySelector('.wakoo-social__nav--next');
			var move = function (dir) {
				var item = list.querySelector('.wakoo-social__item');
				var w = item ? item.getBoundingClientRect().width + 14 : list.clientWidth;
				if (dir > 0 && list.scrollLeft + list.clientWidth >= list.scrollWidth - 4) { list.scrollTo({ left: 0 }); } else { list.scrollBy({ left: dir * w }); }
			};
			if (prev) { prev.addEventListener('click', function () { move(-1); }); }
			if (next) { next.addEventListener('click', function () { move(1); }); }
			if (root.hasAttribute('data-autoplay') && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
				var t = setInterval(function () { if (document.contains(root)) { move(1); } else { clearInterval(t); } }, 4000);
				root.addEventListener('mouseenter', function () { clearInterval(t); });
			}
		}

		if (root.hasAttribute('data-lightbox')) {
			root.addEventListener('click', function (e) {
				var a = e.target.closest && e.target.closest('a[data-wk-full]');
				if (!a || e.metaKey || e.ctrlKey) { return; }
				e.preventDefault();
				open(a);
			});
		}
	}

	function open(a) {
		var prevFocus = document.activeElement;
		var lb = document.createElement('div');
		lb.className = 'wakoo-social-lb';
		lb.setAttribute('role', 'dialog');
		lb.setAttribute('aria-modal', 'true');
		var img = document.createElement('img');
		img.src = a.getAttribute('data-wk-full');
		img.alt = a.getAttribute('data-wk-caption') || '';
		var cap = document.createElement('p');
		cap.textContent = a.getAttribute('data-wk-caption') || '';
		var link = document.createElement('a');
		link.href = a.href; link.target = '_blank'; link.rel = 'noopener'; link.textContent = 'Ver publicación';
		cap.appendChild(document.createTextNode(' ')); cap.appendChild(link);
		var x = document.createElement('button');
		x.type = 'button'; x.setAttribute('aria-label', 'Cerrar'); x.innerHTML = '&times;';
		lb.appendChild(x); lb.appendChild(img); lb.appendChild(cap);
		document.body.appendChild(lb);
		x.focus();
		function close() { document.removeEventListener('keydown', key); lb.remove(); if (prevFocus && prevFocus.focus) { prevFocus.focus(); } }
		function key(e) { if (e.key === 'Escape') { close(); } }
		document.addEventListener('keydown', key);
		x.addEventListener('click', close);
		lb.addEventListener('click', function (e) { if (e.target === lb) { close(); } });
	}

	function scan(ctx) { (ctx || document).querySelectorAll('[data-wk-social]').forEach(init); }
	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', function () { scan(); }); } else { scan(); }
	if (window.jQuery) { jQuery(window).on('elementor/frontend/init', function () { if (window.elementorFrontend && elementorFrontend.hooks) { elementorFrontend.hooks.addAction('frontend/element_ready/wakoo-social-feed.default', function ($el) { scan($el[0]); }); } }); }
})();
