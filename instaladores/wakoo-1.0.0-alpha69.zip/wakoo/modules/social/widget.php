<?php
/**
 * Wakoo Social Feed widget: shows posts from a connected network and lets you
 * curate what appears (count, hide posts, override captions). No third-party
 * service. Falls back to demo posts when the network is not connected.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Social;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

defined( 'ABSPATH' ) || die();

class Widget extends Widget_Base {

	public function get_name() { return 'wakoo-social-feed'; }
	public function get_title() { return __( 'Feed de redes (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-social-icons'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'social', 'redes', 'instagram', 'facebook', 'youtube', 'tiktok', 'feed', 'wakoo' ]; }
	public function get_style_depends() { return [ 'wakoo-social' ]; }
	public function get_script_depends() { return [ 'wakoo-social' ]; }

	protected function register_controls() {

		$this->start_controls_section( 'sec_src', [ 'label' => __( 'Origen', 'wakoo' ) ] );

		$opts = [];
		foreach ( Providers::all() as $slug => $p ) {
			$opts[ $slug ] = $p['label'] . ( Module::is_connected( $slug ) ? '' : ' (' . __( 'demo', 'wakoo' ) . ')' );
		}
		$this->add_control( 'network', [
			'label'   => __( 'Red social', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'instagram',
			'options' => $opts,
		] );
		$this->add_control( 'count', [ 'label' => __( 'Nº de publicaciones', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 30, 'default' => 6 ] );
		$this->add_control( 'notice', [
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => __( 'Conecta tus cuentas en <b>Redes Wakoo</b> (menú del panel). Sin conectar, se muestran ejemplos.', 'wakoo' ),
			'content_classes' => 'elementor-descriptor',
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_layout', [ 'label' => __( 'Diseño', 'wakoo' ) ] );
		$this->add_control( 'layout', [
			'label'   => __( 'Disposición', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'grid',
			'options' => [ 'grid' => __( 'Cuadrícula', 'wakoo' ), 'masonry' => __( 'Mosaico (Masonry)', 'wakoo' ), 'carousel' => __( 'Carrusel', 'wakoo' ), 'highlight' => __( 'Destacada + cuadrícula', 'wakoo' ), 'list' => __( 'Lista', 'wakoo' ) ],
		] );
		$this->add_control( 'autoplay', [ 'label' => __( 'Pasar solo', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'condition' => [ 'layout' => 'carousel' ] ] );
		$this->add_responsive_control( 'columns', [
			'label'          => __( 'Columnas', 'wakoo' ),
			'type'           => Controls_Manager::NUMBER,
			'min'            => 1,
			'max'            => 6,
			'default'        => 3,
			'tablet_default' => 2,
			'mobile_default' => 1,
			'condition'      => [ 'layout!' => 'list' ],
			'selectors'      => [ '{{WRAPPER}} .wakoo-social-wrap' => '--wk-cols: {{VALUE}};' ],
		] );
		$this->add_responsive_control( 'gap', [
			'label'      => __( 'Separación (px)', 'wakoo' ),
			'type'       => Controls_Manager::NUMBER,
			'default'    => 14,
			'selectors'  => [ '{{WRAPPER}} .wakoo-social-wrap' => '--wk-gap: {{VALUE}}px;' ],
		] );
		$this->add_control( 'show_caption', [ 'label' => __( 'Mostrar texto', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'caption_words', [ 'label' => __( 'Palabras del texto', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 18, 'condition' => [ 'show_caption' => 'yes' ] ] );
		$this->add_control( 'show_meta', [ 'label' => __( 'Mostrar autor y fecha', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'show_badge', [ 'label' => __( 'Mostrar icono de la red', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'hover_overlay', [ 'label' => __( 'Texto al pasar el ratón (en vez de debajo)', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ] );
		$this->add_control( 'lightbox', [ 'label' => __( 'Abrir las fotos ampliadas (ventana)', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_header', [ 'label' => __( 'Cabecera y botones', 'wakoo' ) ] );
		$this->add_control( 'show_header', [ 'label' => __( 'Mostrar cabecera', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ] );
		$this->add_control( 'header_title', [ 'label' => __( 'Nombre (vacío = el de la cuenta)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'condition' => [ 'show_header' => 'yes' ] ] );
		$this->add_control( 'show_follow', [ 'label' => __( 'Botón «Seguir»', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ] );
		$this->add_control( 'follow_text', [ 'label' => __( 'Texto del botón', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'placeholder' => __( 'Seguir en…', 'wakoo' ), 'condition' => [ 'show_follow' => 'yes' ] ] );
		$this->add_control( 'follow_url', [ 'label' => __( 'Enlace (vacío = el perfil)', 'wakoo' ), 'type' => Controls_Manager::URL, 'condition' => [ 'show_follow' => 'yes' ] ] );
		$this->add_control( 'load_more', [ 'label' => __( 'Botón «Cargar más»', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'condition' => [ 'layout!' => 'carousel' ] ] );
		$this->add_control( 'load_more_text', [ 'label' => __( 'Texto del botón', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'placeholder' => __( 'Cargar más', 'wakoo' ), 'condition' => [ 'load_more' => 'yes', 'layout!' => 'carousel' ] ] );
		$this->add_control( 'load_count', [ 'label' => __( 'Publicaciones por clic', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 12, 'default' => 6, 'condition' => [ 'load_more' => 'yes', 'layout!' => 'carousel' ] ] );
		$this->end_controls_section();

		/* Curation: hide + caption overrides. */
		$this->start_controls_section( 'sec_curate', [ 'label' => __( 'Curar / editar', 'wakoo' ) ] );
		$this->add_control( 'hide_ids', [
			'label'       => __( 'Ocultar publicaciones (IDs separados por coma)', 'wakoo' ),
			'type'        => Controls_Manager::TEXT,
			'label_block' => true,
			'description' => __( 'Copia el ID que aparece al pasar el ratón por una publicación en el editor.', 'wakoo' ),
		] );
		$ov = new Repeater();
		$ov->add_control( 'ov_id', [ 'label' => __( 'ID de la publicación', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$ov->add_control( 'ov_text', [ 'label' => __( 'Texto a mostrar', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA ] );
		$this->add_control( 'overrides', [
			'label'       => __( 'Reescribir textos', 'wakoo' ),
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $ov->get_controls(),
			'title_field' => '{{{ ov_id }}}',
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'radius', [
			'label'     => __( 'Redondez (px)', 'wakoo' ),
			'type'      => Controls_Manager::NUMBER,
			'default'   => 12,
			'selectors' => [ '{{WRAPPER}} .wakoo-social__item' => 'border-radius: {{VALUE}}px;' ],
		] );
		$this->add_control( 'c_card', [ 'label' => __( 'Fondo de la tarjeta', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-social__item' => 'background: {{VALUE}};' ] ] );
		$this->add_control( 'c_text', [ 'label' => __( 'Color del texto', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-social__caption' => 'color: {{VALUE}};' ] ] );
		$this->add_control( 'c_meta', [ 'label' => __( 'Color de autor y fecha', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-social__meta' => 'color: {{VALUE}};' ] ] );
		$this->add_control( 'c_accent', [ 'label' => __( 'Color de acento (icono, botones)', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-social-wrap' => '--wk-social: {{VALUE}};' ] ] );
		$this->add_control( 'c_overlay', [ 'label' => __( 'Fondo del texto al pasar el ratón', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-social__overlay' => 'background: {{VALUE}};' ] ] );
		$this->add_control( 'c_hbg', [ 'label' => __( 'Fondo de la cabecera', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-social__header' => 'background: {{VALUE}};' ] ] );
		$this->add_control( 'c_htext', [ 'label' => __( 'Texto de la cabecera', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-social__header' => 'color: {{VALUE}};' ] ] );
		$this->add_control( 'c_btn', [ 'label' => __( 'Fondo de los botones', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-social__follow, {{WRAPPER}} .wakoo-social__morebtn' => 'background: {{VALUE}};' ] ] );
		$this->add_control( 'c_btntext', [ 'label' => __( 'Texto de los botones', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wakoo-social__follow, {{WRAPPER}} .wakoo-social__morebtn' => 'color: {{VALUE}};' ] ] );
		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), [ 'name' => 't_caption', 'label' => __( 'Tipografía del texto', 'wakoo' ), 'selector' => '{{WRAPPER}} .wakoo-social__caption' ] );
		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$o = [
			'network' => $s['network'] ?? 'instagram', 'count' => $s['count'] ?? 6, 'layout' => $s['layout'] ?? 'grid',
			'show_header' => $s['show_header'] ?? '', 'show_follow' => $s['show_follow'] ?? '', 'follow_text' => $s['follow_text'] ?? '', 'follow_url' => is_array( $s['follow_url'] ?? null ) ? ( $s['follow_url']['url'] ?? '' ) : '', 'header_title' => $s['header_title'] ?? '',
			'show_caption' => $s['show_caption'] ?? '', 'caption_words' => $s['caption_words'] ?? 18, 'show_meta' => $s['show_meta'] ?? '', 'show_badge' => $s['show_badge'] ?? '',
			'load_more' => $s['load_more'] ?? '', 'load_more_text' => $s['load_more_text'] ?? '', 'load_count' => $s['load_count'] ?? 6,
			'lightbox' => $s['lightbox'] ?? '', 'hover_overlay' => $s['hover_overlay'] ?? '', 'autoplay' => $s['autoplay'] ?? '',
			'hide_ids' => $s['hide_ids'] ?? '', 'overrides' => $s['overrides'] ?? [],
			'edit' => \Elementor\Plugin::instance()->editor->is_edit_mode(),
		];
		echo Feed::render( $o ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
