<?php
/**
 * Wakoo Social: sign-in with each network using the site owner's OWN developer app
 * (no relay server of ours), token exchange and automatic renewal.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Social;

defined( 'ABSPATH' ) || die();

class Auth {

	const CRON = 'wakoo_social_cron';

	public static function init() {
		add_action( 'admin_post_wakoo_social_connect', [ __CLASS__, 'connect' ] );
		add_action( 'admin_post_wakoo_social_oauth', [ __CLASS__, 'callback' ] );
		add_action( 'admin_post_wakoo_social_relay', [ __CLASS__, 'relay_return' ] );
		add_action( 'admin_post_wakoo_social_disconnect', [ __CLASS__, 'disconnect' ] );
		add_action( 'admin_post_wakoo_social_pick_page', [ __CLASS__, 'pick_page' ] );
		add_action( 'admin_post_wakoo_social_refresh', [ __CLASS__, 'refresh_now' ] );
		add_action( self::CRON, [ __CLASS__, 'cron' ] );
		add_action( 'init', function () {
			if ( ! wp_next_scheduled( self::CRON ) ) { wp_schedule_event( time() + 300, 'hourly', self::CRON ); }
		} );
	}

	public static function redirect_uri() {
		return admin_url( 'admin-post.php?action=wakoo_social_oauth' );
	}

	private static function back( $args = [] ) {
		wp_safe_redirect( add_query_arg( array_merge( [ 'page' => 'wakoo-social' ], $args ), admin_url( 'admin.php' ) ) );
		exit;
	}

	private static function guard( $nonce ) {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'No autorizado.', 'wakoo' ) ); }
		check_admin_referer( $nonce );
	}

	/* ---------- start the sign-in ---------- */

	public static function auth_url( $network, $c ) {
		$state = wp_generate_password( 24, false );
		set_transient( 'wakoo_social_state_' . $state, [ 'network' => $network, 'user' => get_current_user_id() ], 15 * MINUTE_IN_SECONDS );
		$ru = self::redirect_uri();
		switch ( $network ) {
			case 'instagram':
				return add_query_arg( [ 'client_id' => $c['app_id'] ?? '', 'redirect_uri' => $ru, 'response_type' => 'code', 'scope' => 'instagram_business_basic', 'state' => $state ], 'https://www.instagram.com/oauth/authorize' );
			case 'facebook':
				return add_query_arg( [ 'client_id' => $c['app_id'] ?? '', 'redirect_uri' => $ru, 'state' => $state, 'scope' => 'pages_show_list,pages_read_engagement,pages_read_user_content' ], 'https://www.facebook.com/v19.0/dialog/oauth' );
			case 'tiktok':
				return add_query_arg( [ 'client_key' => $c['client_key'] ?? '', 'redirect_uri' => $ru, 'response_type' => 'code', 'scope' => 'user.info.basic,video.list', 'state' => $state ], 'https://www.tiktok.com/v2/auth/authorize/' );
		}
		return '';
	}

	public static function connect() {
		self::guard( 'wakoo_social_connect' );
		$net  = sanitize_key( $_GET['network'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification
		$c    = Module::creds( $net );
		if ( self::relay_url() ) {
			$nonce = wp_generate_password( 24, false );
			set_transient( 'wakoo_social_rstate_' . $nonce, [ 'network' => $net, 'user' => get_current_user_id() ], 15 * MINUTE_IN_SECONDS );
			wp_redirect( add_query_arg( [ 'r' => 'connect', 'network' => $net, 'return' => admin_url( 'admin-post.php?action=wakoo_social_relay' ), 'nonce' => $nonce ], self::relay_url() ) ); // phpcs:ignore WordPress.Security.SafeRedirect -- the relay URL is set by the site admin.
			exit;
		}
		$need = 'tiktok' === $net ? [ 'client_key', 'client_secret' ] : [ 'app_id', 'app_secret' ];
		foreach ( $need as $f ) {
			if ( empty( $c[ $f ] ) ) { self::back( [ 'wk_err' => rawurlencode( __( 'Guarda primero el ID y la clave secreta de tu app.', 'wakoo' ) ), 'wk_net' => $net ] ); }
		}
		$url = self::auth_url( $net, $c );
		if ( ! $url ) { self::back( [ 'wk_err' => rawurlencode( __( 'Esta red no usa inicio de sesión.', 'wakoo' ) ) ] ); }
		wp_redirect( $url ); // phpcs:ignore WordPress.Security.SafeRedirect -- external OAuth endpoint chosen from a fixed list.
		exit;
	}

	/* ---------- the network sends the visitor back ---------- */

	public static function callback() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'No autorizado.', 'wakoo' ) ); }
		$state = sanitize_text_field( wp_unslash( $_GET['state'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$st    = $state ? get_transient( 'wakoo_social_state_' . $state ) : false;
		if ( ! $st || (int) $st['user'] !== get_current_user_id() ) { self::back( [ 'wk_err' => rawurlencode( __( 'La sesión de conexión caducó. Vuelve a intentarlo.', 'wakoo' ) ) ] ); }
		delete_transient( 'wakoo_social_state_' . $state );
		$net = $st['network'];
		if ( ! empty( $_GET['error'] ) || empty( $_GET['code'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			self::back( [ 'wk_err' => rawurlencode( sanitize_text_field( wp_unslash( $_GET['error_description'] ?? $_GET['error'] ?? __( 'Se canceló la autorización.', 'wakoo' ) ) ) ), 'wk_net' => $net ] ); // phpcs:ignore WordPress.Security.NonceVerification
		}
		$code = sanitize_text_field( wp_unslash( $_GET['code'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$code = preg_replace( '/#_$/', '', $code );
		$r    = self::exchange( $net, $code );
		if ( is_wp_error( $r ) ) { self::back( [ 'wk_err' => rawurlencode( $r->get_error_message() ), 'wk_net' => $net ] ); }
		Module::flush_cache();
		self::back( [ 'wk_ok' => $net ] );
	}

	/** Code → long-lived credentials, stored in the network's settings. */
	public static function exchange( $net, $code ) {
		$c  = Module::creds( $net );
		$ru = self::redirect_uri();
		if ( 'instagram' === $net ) {
			$s = self::post( 'https://api.instagram.com/oauth/access_token', [ 'client_id' => $c['app_id'] ?? '', 'client_secret' => $c['app_secret'] ?? '', 'grant_type' => 'authorization_code', 'redirect_uri' => $ru, 'code' => $code ] );
			if ( is_wp_error( $s ) ) { return $s; }
			$l = self::get( add_query_arg( [ 'grant_type' => 'ig_exchange_token', 'client_secret' => $c['app_secret'] ?? '', 'access_token' => $s['access_token'] ?? '' ], 'https://graph.instagram.com/access_token' ) );
			if ( is_wp_error( $l ) ) { return $l; }
			Module::save_network( $net, [ 'token' => $l['access_token'], 'token_expires' => time() + (int) ( $l['expires_in'] ?? 5184000 ) ] );
			return true;
		}
		if ( 'facebook' === $net ) {
			$base = 'https://graph.facebook.com/v19.0/oauth/access_token';
			$s    = self::get( add_query_arg( [ 'client_id' => $c['app_id'] ?? '', 'client_secret' => $c['app_secret'] ?? '', 'redirect_uri' => $ru, 'code' => $code ], $base ) );
			if ( is_wp_error( $s ) ) { return $s; }
			$l = self::get( add_query_arg( [ 'grant_type' => 'fb_exchange_token', 'client_id' => $c['app_id'] ?? '', 'client_secret' => $c['app_secret'] ?? '', 'fb_exchange_token' => $s['access_token'] ?? '' ], $base ) );
			if ( is_wp_error( $l ) ) { return $l; }
			$p = self::get( add_query_arg( [ 'access_token' => $l['access_token'] ?? '', 'fields' => 'id,name,access_token,username' ], 'https://graph.facebook.com/v19.0/me/accounts' ) );
			if ( is_wp_error( $p ) ) { return $p; }
			$pages = array_values( array_filter( (array) ( $p['data'] ?? [] ), function ( $x ) { return ! empty( $x['id'] ) && ! empty( $x['access_token'] ); } ) );
			if ( ! $pages ) { return new \WP_Error( 'nopages', __( 'La cuenta no administra ninguna página de Facebook o falta el permiso pages_show_list.', 'wakoo' ) ); }
			if ( 1 === count( $pages ) ) {
				Module::save_network( $net, [ 'page_id' => $pages[0]['id'], 'token' => $pages[0]['access_token'], 'handle' => $pages[0]['username'] ?? '' ] );
			} else {
				set_transient( 'wakoo_social_pages_' . get_current_user_id(), $pages, HOUR_IN_SECONDS );
			}
			return true;
		}
		if ( 'tiktok' === $net ) {
			$s = self::post( 'https://open.tiktokapis.com/v2/oauth/token/', [ 'client_key' => $c['client_key'] ?? '', 'client_secret' => $c['client_secret'] ?? '', 'code' => $code, 'grant_type' => 'authorization_code', 'redirect_uri' => $ru ] );
			if ( is_wp_error( $s ) ) { return $s; }
			Module::save_network( $net, [ 'token' => $s['access_token'], 'refresh_token' => $s['refresh_token'] ?? '', 'token_expires' => time() + (int) ( $s['expires_in'] ?? 86400 ) ] );
			return true;
		}
		return new \WP_Error( 'net', __( 'Red desconocida.', 'wakoo' ) );
	}

	public static function pick_page() {
		self::guard( 'wakoo_social_pick_page' );
		$id    = sanitize_text_field( wp_unslash( $_POST['page'] ?? '' ) );
		$pages = (array) get_transient( 'wakoo_social_pages_' . get_current_user_id() );
		foreach ( $pages as $p ) {
			if ( (string) $p['id'] === $id ) {
				Module::save_network( 'facebook', [ 'page_id' => $p['id'], 'token' => $p['access_token'], 'handle' => $p['username'] ?? '' ] );
				delete_transient( 'wakoo_social_pages_' . get_current_user_id() );
				Module::flush_cache();
				self::back( [ 'wk_ok' => 'facebook' ] );
			}
		}
		self::back( [ 'wk_err' => rawurlencode( __( 'Elige una página de la lista.', 'wakoo' ) ), 'wk_net' => 'facebook' ] );
	}

	public static function disconnect() {
		self::guard( 'wakoo_social_disconnect' );
		$net = sanitize_key( $_GET['network'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification
		$all = Module::creds();
		unset( $all[ $net ] );
		update_option( Module::OPTION, $all, false );
		delete_option( 'wakoo_social_last_' . $net );
		Module::flush_cache();
		self::back( [ 'wk_off' => $net ] );
	}

	/* ---------- relay («Conectar con un clic») ---------- */

	public static function relay_url() {
		$u = (string) ( Module::creds( '_relay' )['url'] ?? '' );
		return ( $u && preg_match( '#^https?://#i', $u ) ) ? esc_url_raw( $u ) : '';
	}

	/** The relay sends the visitor back with a one-time ticket; it is exchanged for the tokens server to server. */
	public static function relay_return() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'No autorizado.', 'wakoo' ) ); }
		$nonce = sanitize_text_field( wp_unslash( $_GET['state'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$st    = $nonce ? get_transient( 'wakoo_social_rstate_' . $nonce ) : false;
		if ( ! $st || (int) $st['user'] !== get_current_user_id() || ! self::relay_url() ) { self::back( [ 'wk_err' => rawurlencode( __( 'La sesión de conexión caducó. Vuelve a intentarlo.', 'wakoo' ) ) ] ); }
		delete_transient( 'wakoo_social_rstate_' . $nonce );
		$net = $st['network'];
		if ( ! empty( $_GET['wk_relay_err'] ) ) { self::back( [ 'wk_err' => rawurlencode( sanitize_text_field( wp_unslash( $_GET['wk_relay_err'] ) ) ), 'wk_net' => $net ] ); } // phpcs:ignore WordPress.Security.NonceVerification
		$ticket = sanitize_text_field( wp_unslash( $_GET['wk_relay_ticket'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$r      = self::post( add_query_arg( 'r', 'claim', self::relay_url() ), [ 'ticket' => $ticket, 'state' => $nonce ] );
		if ( is_wp_error( $r ) ) { self::back( [ 'wk_err' => rawurlencode( $r->get_error_message() ), 'wk_net' => $net ] ); }
		$e = self::apply_payload( $net, $r );
		if ( is_wp_error( $e ) ) { self::back( [ 'wk_err' => rawurlencode( $e->get_error_message() ), 'wk_net' => $net ] ); }
		Module::flush_cache();
		self::back( [ 'wk_ok' => $net ] );
	}

	/** Stores what the relay returned for a network. */
	public static function apply_payload( $net, array $r ) {
		if ( ! empty( $r['pages'] ) ) {
			$pages = array_values( array_filter( (array) $r['pages'], function ( $x ) { return ! empty( $x['id'] ) && ! empty( $x['access_token'] ); } ) );
			if ( ! $pages ) { return new \WP_Error( 'nopages', __( 'La cuenta no administra ninguna página.', 'wakoo' ) ); }
			if ( 1 === count( $pages ) ) {
				Module::save_network( $net, [ 'page_id' => $pages[0]['id'], 'token' => $pages[0]['access_token'], 'handle' => $pages[0]['username'] ?? '' ] );
			} else {
				set_transient( 'wakoo_social_pages_' . get_current_user_id(), $pages, HOUR_IN_SECONDS );
			}
			return true;
		}
		if ( empty( $r['token'] ) ) { return new \WP_Error( 'notoken', __( 'El relay no devolvió ningún token.', 'wakoo' ) ); }
		$vals = [ 'token' => $r['token'], 'token_expires' => time() + (int) ( $r['expires_in'] ?? 0 ) ];
		if ( ! empty( $r['refresh_token'] ) ) { $vals['refresh_token'] = $r['refresh_token']; }
		Module::save_network( $net, $vals );
		return true;
	}

	/* ---------- renewal ---------- */

	/** Renews the token of a network when it expires within $days. Returns true, false (not needed) or WP_Error. */
	public static function renew( $net, $days = 20, $force = false ) {
		$c = Module::creds( $net );
		if ( empty( $c['token'] ) ) { return false; }
		$exp = (int) ( $c['token_expires'] ?? 0 );
		if ( ! $force && ( ! $exp || $exp - time() > $days * DAY_IN_SECONDS ) ) { return false; }
		if ( 'instagram' === $net ) {
			$r = self::get( add_query_arg( [ 'grant_type' => 'ig_refresh_token', 'access_token' => $c['token'] ], 'https://graph.instagram.com/refresh_access_token' ) );
			if ( is_wp_error( $r ) ) { return $r; }
			Module::save_network( $net, [ 'token' => $r['access_token'], 'token_expires' => time() + (int) ( $r['expires_in'] ?? 5184000 ) ] );
			return true;
		}
		if ( 'tiktok' === $net && ! empty( $c['refresh_token'] ) && empty( $c['client_secret'] ) && self::relay_url() ) {
			$r = self::post( add_query_arg( 'r', 'refresh', self::relay_url() ), [ 'network' => 'tiktok', 'refresh_token' => $c['refresh_token'] ] );
			if ( is_wp_error( $r ) ) { return $r; }
			return self::apply_payload( $net, $r );
		}
		if ( 'tiktok' === $net && ! empty( $c['refresh_token'] ) && ! empty( $c['client_key'] ) ) {
			$r = self::post( 'https://open.tiktokapis.com/v2/oauth/token/', [ 'client_key' => $c['client_key'], 'client_secret' => $c['client_secret'] ?? '', 'grant_type' => 'refresh_token', 'refresh_token' => $c['refresh_token'] ] );
			if ( is_wp_error( $r ) ) { return $r; }
			Module::save_network( $net, [ 'token' => $r['access_token'], 'refresh_token' => $r['refresh_token'] ?? $c['refresh_token'], 'token_expires' => time() + (int) ( $r['expires_in'] ?? 86400 ) ] );
			return true;
		}
		return false;
	}

	/** Hourly: renew tokens that are about to expire (TikTok every day, Instagram 20 days before) and refresh the cached feeds. */
	public static function cron() {
		foreach ( [ 'instagram' => 20, 'tiktok' => 1 ] as $net => $days ) {
			$r = self::renew( $net, $days );
			if ( is_wp_error( $r ) ) { Module::status( $net, false, $r->get_error_message() ); }
		}
		foreach ( array_keys( Providers::all() ) as $net ) {
			if ( Module::is_connected( $net ) ) { Module::get_posts( $net, Module::POOL, true ); }
		}
	}

	public static function refresh_now() {
		self::guard( 'wakoo_social_refresh' );
		$net = sanitize_key( $_GET['network'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification
		$r   = self::renew( $net, 0, true );
		Module::flush_cache();
		$p = Module::get_posts( $net, Module::POOL, true );
		if ( is_wp_error( $r ) ) { self::back( [ 'wk_err' => rawurlencode( $r->get_error_message() ), 'wk_net' => $net ] ); }
		if ( is_wp_error( $p ) ) { self::back( [ 'wk_err' => rawurlencode( $p->get_error_message() ), 'wk_net' => $net ] ); }
		self::back( [ 'wk_ok' => $net ] );
	}

	/* ---------- http ---------- */

	private static function get( $url ) {
		return self::parse( wp_remote_get( $url, [ 'timeout' => 15 ] ) );
	}

	private static function post( $url, $body ) {
		return self::parse( wp_remote_post( $url, [ 'timeout' => 15, 'body' => $body ] ) );
	}

	private static function parse( $res ) {
		if ( is_wp_error( $res ) ) { return $res; }
		$code = wp_remote_retrieve_response_code( $res );
		$b    = json_decode( wp_remote_retrieve_body( $res ), true );
		$b    = is_array( $b ) ? $b : [];
		$msg  = $b['error_message'] ?? $b['error']['message'] ?? ( is_string( $b['error'] ?? null ) ? ( $b['error_description'] ?? $b['error'] ) : '' );
		if ( $code < 200 || $code >= 300 || ( $msg && empty( $b['access_token'] ) ) ) {
			return new \WP_Error( 'http', $msg ? (string) $msg : 'HTTP ' . $code );
		}
		return $b;
	}
}

Auth::init();
