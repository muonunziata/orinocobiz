<?php
/**
 * Wakoo Social: a native social-feed connector. Connects to each network's OWN
 * official API (no Smash Balloon, no aggregator service), caches the posts, and
 * shows them with a feed widget you can curate. Until a network is connected
 * the widget shows demo posts so you can design with it.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Social;

defined( 'ABSPATH' ) || die();

class Module {

	const OPTION = 'wakoo_social';
	const NONCE  = 'wakoo_social';
	const POOL   = 30;

	public static function init() {
		require_once __DIR__ . '/providers.php';
		require_once __DIR__ . '/auth.php';
		require_once __DIR__ . '/feed.php';
		add_shortcode( 'wakoo_feed', [ Feed::class, 'shortcode' ] );
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_action( 'elementor/frontend/after_register_styles', [ __CLASS__, 'styles' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'scripts' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'admin_styles' ] );
		add_action( 'admin_menu', [ __CLASS__, 'menu' ] );
		add_action( 'admin_post_wakoo_social_save', [ __CLASS__, 'save' ] );
		add_action( 'wp_ajax_wakoo_social_test', [ __CLASS__, 'ajax_test' ] );
	}

	public static function register_widget( $wm ) {
		require_once __DIR__ . '/widget.php';
		$wm->register( new Widget() );
	}

	public static function styles() {
		wp_register_style( 'wakoo-social', WAKOO_MODULES_URL . 'social/assets/social.css', [], WAKOO_VERSION );
	}

	public static function scripts() {
		wp_register_script( 'wakoo-social', WAKOO_MODULES_URL . 'social/assets/social.js', [], WAKOO_VERSION, true );
	}

	public static function admin_styles( $hook ) {
		if ( false !== strpos( (string) $hook, 'wakoo-social' ) ) {
			wp_enqueue_style( 'wakoo-social-admin', WAKOO_MODULES_URL . 'social/assets/admin.css', [], WAKOO_VERSION );
		}
	}

	/* ---------- credentials ---------- */
	public static function creds( $network = null ) {
		$all = (array) get_option( self::OPTION, [] );
		if ( null === $network ) { return $all; }
		return (array) ( $all[ $network ] ?? [] );
	}

	/** Merges values into a network's settings (used by the sign-in and the renewal). */
	public static function save_network( $network, array $vals ) {
		$all = self::creds();
		$all[ $network ] = array_merge( (array) ( $all[ $network ] ?? [] ), $vals );
		update_option( self::OPTION, $all, false );
	}

	public static function is_connected( $network ) {
		$prov = Providers::all();
		if ( empty( $prov[ $network ] ) ) { return false; }
		$c = self::creds( $network );
		foreach ( (array) ( $prov[ $network ]['required'] ?? array_keys( $prov[ $network ]['fields'] ) ) as $f ) {
			if ( empty( $c[ $f ] ) ) { return false; }
		}
		return true;
	}

	public static function cache_minutes() {
		$all = self::creds();
		return max( 1, (int) ( $all['_cache'] ?? 20 ) );
	}

	/** Last result of a network: [ ok, msg, time ]. */
	public static function status( $network, $ok = null, $msg = '' ) {
		$all = (array) get_option( 'wakoo_social_status', [] );
		if ( null === $ok ) { return $all[ $network ] ?? null; }
		$all[ $network ] = [ 'ok' => (bool) $ok, 'msg' => (string) $msg, 'time' => time() ];
		update_option( 'wakoo_social_status', $all, false );
		return $all[ $network ];
	}

	/**
	 * Normalised posts for a network (cached). A failing API keeps showing the last good
	 * posts; demo posts appear only when the network is not connected or never worked.
	 */
	public static function get_posts( $network, $limit, $bypass_cache = false ) {
		$limit = max( 1, min( 50, (int) $limit ) );
		$prov  = Providers::all();
		if ( empty( $prov[ $network ] ) || ! self::is_connected( $network ) ) {
			return Providers::demo( $network, $limit );
		}
		$key = 'wakoo_social_' . $network;
		$ttl = 'tiktok' === $network ? min( 60, self::cache_minutes() ) : self::cache_minutes();
		if ( ! $bypass_cache ) {
			$cached = get_transient( $key );
			if ( is_array( $cached ) ) { return array_slice( $cached, 0, $limit ); }
		}
		$posts = call_user_func( $prov[ $network ]['fetch'], self::creds( $network ), self::POOL );
		if ( is_wp_error( $posts ) || ! is_array( $posts ) || ! $posts ) {
			$msg = is_wp_error( $posts ) ? $posts->get_error_message() : __( 'La red no devolvió publicaciones.', 'wakoo' );
			self::status( $network, false, $msg );
			$last = get_option( 'wakoo_social_last_' . $network );
			$good = is_array( $last ) && ! empty( $last['posts'] ) ? $last['posts'] : null;
			if ( ! $bypass_cache ) { set_transient( $key, $good ? $good : Providers::demo( $network, self::POOL ), 5 * MINUTE_IN_SECONDS ); }
			if ( $bypass_cache && is_wp_error( $posts ) ) { return $posts; }
			return array_slice( $good ? $good : Providers::demo( $network, $limit ), 0, $limit );
		}
		self::status( $network, true, sprintf( _n( '%d publicación recibida', '%d publicaciones recibidas', count( $posts ), 'wakoo' ), count( $posts ) ) );
		update_option( 'wakoo_social_last_' . $network, [ 'time' => time(), 'posts' => $posts ], false );
		set_transient( $key, $posts, $ttl * MINUTE_IN_SECONDS );
		return array_slice( $posts, 0, $limit );
	}

	public static function flush_cache() {
		global $wpdb;
		foreach ( array_keys( Providers::all() ) as $net ) { delete_transient( 'wakoo_social_' . $net ); }
		$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_wakoo\_social\_%' OR option_name LIKE '\_transient\_timeout\_wakoo\_social\_%'" ); // phpcs:ignore
	}

	/* ---------- admin page ---------- */
	public static function menu() {
		add_menu_page( __( 'Redes Wakoo', 'wakoo' ), __( 'Redes Wakoo', 'wakoo' ), 'manage_options', 'wakoo-social', [ __CLASS__, 'page' ], 'dashicons-share', 58 );
	}

	private static function relay_box() {
		$rel = Auth::relay_url();
		echo '<div class="wk-net" style="--wk-net:#6C5CE7"><h2>' . esc_html__( 'Conectar con un clic (relay propio)', 'wakoo' ) . '</h2><p class="description">' . esc_html__( 'Opcional. Sube la carpeta «relay» (la descargas en el zip del relay) a tu hosting con tus apps de Meta y TikTok, pega aquí su URL y los botones «Conectar» pedirán permiso con un clic, sin copiar tokens. Sin relay puedes conectar con tu propia app o pegando un token.', 'wakoo' ) . '</p>';
		echo '<table class="form-table"><tbody><tr><th><label>' . esc_html__( 'URL del relay', 'wakoo' ) . '</label></th><td><input type="url" class="regular-text" placeholder="https://relay.tu-dominio.com/index.php" name="wk[_relay][url]" value="' . esc_attr( $rel ) . '" autocomplete="off"></td></tr></tbody></table>';
		echo '<p><button type="button" class="button wk-test" data-net="_relay">' . esc_html__( 'Probar relay', 'wakoo' ) . '</button> <span class="wk-test-out" data-net="_relay"></span></p></div>';

	}

	/** Smash Balloon (or other feed plugins) can stay active: Wakoo uses its own prefixes everywhere. */
	private static function coexist_notice() {
		$sb = [ 'instagram-feed/instagram-feed.php', 'instagram-feed-pro/instagram-feed.php', 'custom-facebook-feed/custom-facebook-feed.php', 'custom-facebook-feed-pro/custom-facebook-feed.php', 'feeds-for-youtube/youtube-feed.php', 'youtube-feed-pro/youtube-feed.php', 'custom-twitter-feeds/custom-twitter-feed.php', 'feeds-for-tiktok/tiktok-feed.php' ];
		$on = [];
		foreach ( $sb as $f ) { if ( is_plugin_active( $f ) ) { $on[] = $f; } }
		if ( $on ) { echo '<div class="notice notice-info inline"><p>' . esc_html__( 'Smash Balloon está activo en este sitio. Pueden convivir: Wakoo usa sus propias clases (wakoo-social), scripts, opciones y shortcode ([wakoo_feed]), así que no se pisan. Cada plugin guarda su propio token.', 'wakoo' ) . '</p></div>'; }
	}

	private static function action_url( $action, $net ) {
		return wp_nonce_url( admin_url( 'admin-post.php?action=' . $action . '&network=' . $net ), $action );
	}

	public static function page() {
		$prov = Providers::all();
		$all  = self::creds();
		echo '<div class="wrap wakoo-social-admin"><h1>' . esc_html__( 'Redes sociales de Wakoo', 'wakoo' ) . '</h1>';
		echo '<p>' . esc_html__( 'Conecta cada red con tu propia cuenta de desarrollador: Wakoo no usa servidores de terceros: los permisos y los datos son tuyos (opcionalmente con un relay que alojas tú). Mientras no conectes una red, el widget muestra publicaciones de ejemplo (modo demostración).', 'wakoo' ) . '</p>';
		if ( isset( $_GET['saved'] ) ) { echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Guardado.', 'wakoo' ) . '</p></div>'; } // phpcs:ignore WordPress.Security.NonceVerification
		if ( isset( $_GET['wk_ok'] ) ) { echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sprintf( __( '%s conectado y actualizado.', 'wakoo' ), $prov[ sanitize_key( $_GET['wk_ok'] ) ]['label'] ?? '' ) ) . '</p></div>'; } // phpcs:ignore WordPress.Security.NonceVerification
		if ( isset( $_GET['wk_off'] ) ) { echo '<div class="notice notice-info is-dismissible"><p>' . esc_html__( 'Red desconectada. Se borraron sus datos de acceso.', 'wakoo' ) . '</p></div>'; } // phpcs:ignore WordPress.Security.NonceVerification
		if ( isset( $_GET['wk_err'] ) ) { echo '<div class="notice notice-error"><p>' . esc_html( sanitize_text_field( rawurldecode( wp_unslash( $_GET['wk_err'] ) ) ) ) . '</p></div>'; } // phpcs:ignore WordPress.Security.NonceVerification

		echo '<p><strong>' . esc_html__( 'URI de redireccionamiento para tus apps:', 'wakoo' ) . '</strong> <code id="wk-ru">' . esc_html( Auth::redirect_uri() ) . '</code> <button type="button" class="button button-small" onclick="navigator.clipboard&&navigator.clipboard.writeText(document.getElementById(\'wk-ru\').textContent)">' . esc_html__( 'Copiar', 'wakoo' ) . '</button></p>';
		if ( 0 !== strpos( home_url(), 'https://' ) ) { echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Meta, TikTok y Google exigen que la URI de redireccionamiento sea https. Activa el certificado SSL del sitio antes de conectar.', 'wakoo' ) . '</p></div>'; }

		self::coexist_notice();
		$pages = get_transient( 'wakoo_social_pages_' . get_current_user_id() );
		if ( is_array( $pages ) && $pages ) {
			echo '<div class="notice notice-info inline"><p><strong>' . esc_html__( 'Elige la página de Facebook', 'wakoo' ) . '</strong></p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="wakoo_social_pick_page">';
			wp_nonce_field( 'wakoo_social_pick_page' );
			echo '<select name="page">';
			foreach ( $pages as $p ) { echo '<option value="' . esc_attr( $p['id'] ) . '">' . esc_html( $p['name'] ?? $p['id'] ) . '</option>'; }
			echo '</select> '; submit_button( __( 'Usar esta página', 'wakoo' ), 'primary', 'submit', false );
			echo '</form></div>';
		}

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( self::NONCE );
		echo '<input type="hidden" name="action" value="wakoo_social_save">';
		self::relay_box();

		foreach ( $prov as $slug => $p ) {
			$c         = (array) ( $all[ $slug ] ?? [] );
			$connected = self::is_connected( $slug );
			$st        = self::status( $slug );
			echo '<div class="wk-net" style="--wk-net:' . esc_attr( $p['color'] ) . '">';
			echo '<h2>' . esc_html( $p['label'] ) . ' ' . ( $connected ? '<span class="wk-badge wk-on">' . esc_html__( 'conectado', 'wakoo' ) . '</span>' : '<span class="wk-badge wk-off">' . esc_html__( 'demostración', 'wakoo' ) . '</span>' ) . '</h2>';
			echo '<p class="description">' . esc_html( $p['help'] ) . '</p>';
			if ( $connected ) {
				$line = [];
				if ( ! empty( $c['token_expires'] ) ) { $line[] = sprintf( __( 'El token vence el %s y se renueva solo.', 'wakoo' ), date_i18n( get_option( 'date_format' ), (int) $c['token_expires'] ) ); }
				if ( $st ) { $line[] = ( $st['ok'] ? '✓ ' : '✕ ' ) . $st['msg'] . ' · ' . human_time_diff( $st['time'] ) . ' ' . __( 'atrás', 'wakoo' ); }
				if ( $line ) { echo '<p class="' . ( $st && ! $st['ok'] ? 'wk-bad' : 'wk-good' ) . '">' . esc_html( implode( ' ', $line ) ) . '</p>'; }
			}
			if ( ! empty( $p['steps'] ) ) {
				echo '<details' . ( $connected ? '' : ' open' ) . '><summary>' . esc_html__( 'Paso a paso', 'wakoo' ) . '</summary><ol>';
				foreach ( $p['steps'] as $step ) { echo '<li>' . esc_html( $step ) . '</li>'; }
				echo '</ol>' . ( ! empty( $p['docs'] ) ? '<p><a href="' . esc_url( $p['docs'] ) . '" target="_blank" rel="noopener">' . esc_html__( 'Documentación oficial', 'wakoo' ) . ' ↗</a></p>' : '' ) . '</details>';
			}
			echo '<table class="form-table"><tbody>';
			foreach ( $p['fields'] as $fkey => $f ) {
				$val = $c[ $fkey ] ?? '';
				$sec = ! empty( $f['secret'] );
				echo '<tr><th><label>' . esc_html( $f['label'] ) . ( ! empty( $f['optional'] ) ? ' <span class="description">(' . esc_html__( 'opcional', 'wakoo' ) . ')</span>' : '' ) . '</label></th><td>';
				echo '<input type="' . ( $sec ? 'password' : 'text' ) . '" class="regular-text" name="wk[' . esc_attr( $slug ) . '][' . esc_attr( $fkey ) . ']" value="' . esc_attr( $sec && $val ? '••••••••' : $val ) . '" autocomplete="off">';
				echo '</td></tr>';
			}
			echo '</tbody></table>';
			echo '<p>';
			if ( ! empty( $p['oauth'] ) ) {
				echo '<a class="button button-primary" href="' . esc_url( self::action_url( 'wakoo_social_connect', $slug ) ) . '">' . esc_html( sprintf( __( 'Conectar con %s', 'wakoo' ), $p['label'] ) ) . '</a> ';
			}
			echo '<button type="button" class="button wk-test" data-net="' . esc_attr( $slug ) . '">' . esc_html__( 'Probar conexión', 'wakoo' ) . '</button> ';
			if ( $connected ) {
				echo '<a class="button" href="' . esc_url( self::action_url( 'wakoo_social_refresh', $slug ) ) . '">' . esc_html__( 'Actualizar ahora', 'wakoo' ) . '</a> ';
				echo '<a class="button-link-delete" href="' . esc_url( self::action_url( 'wakoo_social_disconnect', $slug ) ) . '" onclick="return confirm(' . esc_attr( wp_json_encode( __( '¿Desconectar y borrar los datos de acceso?', 'wakoo' ) ) ) . ')">' . esc_html__( 'Desconectar', 'wakoo' ) . '</a> ';
			}
			echo '<span class="wk-test-out" data-net="' . esc_attr( $slug ) . '"></span></p><div class="wk-test-prev" data-net="' . esc_attr( $slug ) . '"></div>';
			echo '</div>';
		}

		echo '<table class="form-table"><tbody><tr><th>' . esc_html__( 'Caché (minutos)', 'wakoo' ) . '</th><td><input type="number" min="1" max="1440" name="wk[_cache]" value="' . esc_attr( $all['_cache'] ?? 20 ) . '" class="small-text"> <span class="description">' . esc_html__( 'Cada cuánto se vuelven a pedir las publicaciones. Si la red falla, se siguen mostrando las últimas que llegaron bien.', 'wakoo' ) . '</span></td></tr></tbody></table>';
		submit_button( __( 'Guardar', 'wakoo' ) );
		echo '</form>';
		echo '<h2>' . esc_html__( 'Cómo se usa', 'wakoo' ) . '</h2><p>' . esc_html__( 'En Elementor añade el widget «Feed de redes (Wakoo)»: allí eliges la red, cuántas publicaciones, la disposición (cuadrícula, mosaico, carrusel, lista o destacada), la cabecera, el botón Seguir, «Cargar más», la ventana ampliada y los colores, con vista previa en vivo.', 'wakoo' ) . '</p>';

		$nonce = wp_create_nonce( self::NONCE );
		echo '<script>(function(){var a="' . esc_js( admin_url( 'admin-ajax.php' ) ) . '",n="' . esc_js( $nonce ) . '";';
		echo 'document.querySelectorAll(".wk-test").forEach(function(b){b.addEventListener("click",function(){var net=b.getAttribute("data-net");var out=document.querySelector(\'.wk-test-out[data-net="\'+net+\'"]\');var pv=document.querySelector(\'.wk-test-prev[data-net="\'+net+\'"]\');out.textContent="…";pv.innerHTML="";var fd=new FormData();fd.append("action","wakoo_social_test");fd.append("nonce",n);fd.append("network",net);';
		echo 'document.querySelectorAll("input").forEach(function(i){var m=i.name.match(/^wk\\[(.+?)\\]\\[(.+?)\\]$/);if(m&&m[1]===net){fd.append("c["+m[2]+"]",i.value);}});';
		echo 'fetch(a,{method:"POST",body:fd,credentials:"same-origin"}).then(function(r){return r.json();}).then(function(j){out.textContent=j.success?("✓ "+j.data.message):("✕ "+(j.data&&j.data.message||"error"));out.style.color=j.success?"#1e824c":"#c0392b";if(j.success&&j.data.thumbs){pv.innerHTML=j.data.thumbs.map(function(u){return \'<img src="\'+u.replace(/"/g,"")+\'" alt="">\';}).join("");}}).catch(function(){out.textContent="✕";});});});})();</script>';
		echo '</div>';
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( self::NONCE ) ) {
			wp_die( esc_html__( 'No autorizado.', 'wakoo' ) );
		}
		$in   = isset( $_POST['wk'] ) ? wp_unslash( $_POST['wk'] ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$prov = Providers::all();
		$old  = self::creds();
		$out  = $old;
		foreach ( $prov as $slug => $p ) {
			foreach ( array_keys( $p['fields'] ) as $fkey ) {
				if ( ! isset( $in[ $slug ][ $fkey ] ) ) { continue; }
				$v = sanitize_text_field( $in[ $slug ][ $fkey ] );
				if ( '••••••••' === $v ) { continue; } // untouched secret
				if ( '' === $v ) { unset( $out[ $slug ][ $fkey ] ); } else { $out[ $slug ][ $fkey ] = $v; }
				if ( 'token' === $fkey && ( $old[ $slug ]['token'] ?? '' ) !== $v ) { unset( $out[ $slug ]['token_expires'] ); }
			}
		}
		$ru = isset( $in['_relay']['url'] ) ? esc_url_raw( trim( (string) $in['_relay']['url'] ) ) : '';
		if ( $ru ) { $out['_relay']['url'] = $ru; } else { unset( $out['_relay'] ); }
		$out['_cache'] = isset( $in['_cache'] ) ? max( 1, min( 1440, (int) $in['_cache'] ) ) : 20;
		update_option( self::OPTION, $out, false );
		self::flush_cache();
		wp_safe_redirect( add_query_arg( [ 'page' => 'wakoo-social', 'saved' => 1 ], admin_url( 'admin.php' ) ) );
		exit;
	}

	public static function ajax_test() {
		if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( self::NONCE, 'nonce', false ) ) {
			wp_send_json_error( [ 'message' => __( 'No autorizado.', 'wakoo' ) ] );
		}
		$network = isset( $_POST['network'] ) ? sanitize_key( $_POST['network'] ) : '';
		if ( '_relay' === $network ) {
			$u = esc_url_raw( trim( (string) wp_unslash( $_POST['c']['url'] ?? '' ) ) );
			if ( ! $u ) { wp_send_json_error( [ 'message' => __( 'Escribe la URL del relay.', 'wakoo' ) ] ); }
			$r = wp_remote_get( add_query_arg( 'r', 'ping', $u ), [ 'timeout' => 12 ] );
			if ( is_wp_error( $r ) ) { wp_send_json_error( [ 'message' => $r->get_error_message() ] ); }
			$j = json_decode( wp_remote_retrieve_body( $r ), true );
			if ( empty( $j['ok'] ) || 'wakoo' !== ( $j['relay'] ?? '' ) ) { wp_send_json_error( [ 'message' => __( 'Esa URL no responde como un relay de Wakoo. Revisa que apunte a index.php y que config.php exista.', 'wakoo' ) ] ); }
			wp_send_json_success( [ 'message' => sprintf( __( 'Relay v%1$s activo. Redes configuradas: %2$s. URI de redireccionamiento para tus apps: %3$s', 'wakoo' ), $j['version'] ?? '?', $j['networks'] ? implode( ', ', $j['networks'] ) : __( 'ninguna', 'wakoo' ), $j['redirect_uri'] ?? '' ) ] );
		}
		$prov    = Providers::all();
		if ( empty( $prov[ $network ] ) ) { wp_send_json_error( [ 'message' => __( 'Red desconocida.', 'wakoo' ) ] ); }
		$c = self::creds( $network );
		if ( isset( $_POST['c'] ) && is_array( $_POST['c'] ) ) {
			foreach ( wp_unslash( $_POST['c'] ) as $k => $v ) {
				$v = sanitize_text_field( $v );
				if ( '' !== $v && '••••••••' !== $v ) { $c[ sanitize_key( $k ) ] = $v; }
			}
		}
		foreach ( (array) ( $prov[ $network ]['required'] ?? array_keys( $prov[ $network ]['fields'] ) ) as $f ) {
			if ( empty( $c[ $f ] ) ) { wp_send_json_error( [ 'message' => __( 'Faltan datos de acceso (revisa los campos obligatorios).', 'wakoo' ) ] ); }
		}
		$posts = call_user_func( $prov[ $network ]['fetch'], $c, 6 );
		if ( is_wp_error( $posts ) ) { wp_send_json_error( [ 'message' => $posts->get_error_message() ] ); }
		$posts = (array) $posts;
		wp_send_json_success( [
			'message' => sprintf( __( '%d publicaciones recibidas', 'wakoo' ), count( $posts ) ),
			'thumbs'  => array_values( array_filter( array_map( function ( $p ) { return esc_url_raw( $p['thumb'] ?? '' ); }, array_slice( $posts, 0, 4 ) ) ) ),
		] );
	}
}

Module::init();
