<?php
/**
 * Wakoo Social: markup of a feed, shared by the Elementor widget and the [wakoo_feed] shortcode.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Social;

defined( 'ABSPATH' ) || die();

class Feed {

	const LAYOUTS = [ 'grid', 'masonry', 'carousel', 'list', 'highlight' ];

	public static function defaults() {
		return [
			'network' => 'instagram', 'count' => 6, 'layout' => 'grid',
			'show_header' => '', 'show_follow' => '', 'follow_text' => '', 'follow_url' => '', 'header_title' => '',
			'show_caption' => 'yes', 'caption_words' => 18, 'show_meta' => 'yes', 'show_badge' => 'yes',
			'load_more' => '', 'load_more_text' => '', 'load_count' => 6,
			'lightbox' => '', 'hover_overlay' => '', 'autoplay' => '', 'hide_ids' => '', 'overrides' => [],
			'edit' => false,
		];
	}

	public static function enqueue() {
		wp_enqueue_style( 'wakoo-social' );
		wp_enqueue_script( 'wakoo-social' );
	}

	public static function render( array $o ) {
		$o       = array_merge( self::defaults(), $o );
		$prov    = Providers::all();
		$network = isset( $prov[ $o['network'] ] ) ? $o['network'] : 'instagram';
		$count   = max( 1, min( 30, (int) $o['count'] ) );
		$layout  = in_array( $o['layout'], self::LAYOUTS, true ) ? $o['layout'] : 'grid';
		$more    = 'yes' === $o['load_more'] && 'carousel' !== $layout;
		$step    = max( 1, (int) $o['load_count'] );

		$hide = array_filter( array_map( 'trim', explode( ',', (string) $o['hide_ids'] ) ) );
		$ovr  = [];
		foreach ( (array) $o['overrides'] as $x ) {
			if ( ! empty( $x['ov_id'] ) ) { $ovr[ trim( $x['ov_id'] ) ] = $x['ov_text'] ?? ''; }
		}

		$all   = Module::get_posts( $network, Module::POOL + count( $hide ) );
		$all   = array_values( array_filter( $all, function ( $p ) use ( $hide ) { return ! in_array( (string) $p['id'], $hide, true ); } ) );
		$total = $more ? min( count( $all ), $count + $step * 3 ) : $count;
		$posts = array_slice( $all, 0, $total );
		if ( ! $posts ) { return ''; }

		$label = $prov[ $network ]['label'] ?? $network;
		$color = $prov[ $network ]['color'] ?? '#6C5CE7';
		$demo  = ! empty( $posts[0]['demo'] );
		$prof  = Providers::profile( $network, $posts );
		$cap   = 'yes' === $o['show_caption'];
		$meta  = 'yes' === $o['show_meta'];

		$h  = '<div class="wakoo-social-wrap wakoo-social-wrap--' . esc_attr( $layout ) . ( 'yes' === $o['hover_overlay'] ? ' has-overlay' : '' ) . '" data-wk-social data-layout="' . esc_attr( $layout ) . '"';
		$h .= ' data-step="' . esc_attr( $step ) . '"' . ( 'yes' === $o['lightbox'] ? ' data-lightbox="1"' : '' ) . ( 'yes' === $o['autoplay'] ? ' data-autoplay="1"' : '' ) . ' style="--wk-social:' . esc_attr( $color ) . '">';

		if ( 'yes' === $o['show_header'] || 'yes' === $o['show_follow'] ) {
			$name = '' !== $o['header_title'] ? $o['header_title'] : ( $prof['name'] ? ( 'x' === $network || 'tiktok' === $network || 'instagram' === $network ? '@' . ltrim( $prof['name'], '@' ) : $prof['name'] ) : $label );
			$h   .= '<div class="wakoo-social__header">';
			if ( 'yes' === $o['show_header'] ) {
				$init = function_exists( 'mb_substr' ) ? mb_strtoupper( mb_substr( ltrim( $name, '@' ), 0, 1 ) ) : strtoupper( substr( ltrim( $name, '@' ), 0, 1 ) );
				$h   .= '<span class="wakoo-social__avatar" aria-hidden="true">' . esc_html( $init ) . '</span><div class="wakoo-social__who"><strong class="wakoo-social__name">' . esc_html( $name ) . '</strong><span class="wakoo-social__net">' . esc_html( $label ) . '</span></div>';
			}
			$follow = '' !== $o['follow_url'] ? $o['follow_url'] : $prof['url'];
			if ( 'yes' === $o['show_follow'] && $follow ) {
				$h .= '<a class="wakoo-social__follow" href="' . esc_url( $follow ) . '" target="_blank" rel="noopener">' . esc_html( '' !== $o['follow_text'] ? $o['follow_text'] : sprintf( __( 'Seguir en %s', 'wakoo' ), $label ) ) . '</a>';
			}
			$h .= '</div>';
		}

		$h .= '<div class="wakoo-social wakoo-social--' . esc_attr( $layout ) . '">';
		foreach ( $posts as $i => $p ) {
			$caption = isset( $ovr[ (string) $p['id'] ] ) ? $ovr[ (string) $p['id'] ] : $p['caption'];
			$short   = ( $cap && $caption ) ? wp_trim_words( $caption, max( 3, (int) $o['caption_words'] ) ) : '';
			$href    = $p['permalink'] ? $p['permalink'] : '#';
			$blank   = ( '#' === $href ) ? '' : ' target="_blank" rel="noopener"';
			$extra   = $more && $i >= $count;
			$lb      = 'yes' === $o['lightbox'] && 'image' === $p['type'] && $p['media'];

			$h .= '<article class="wakoo-social__item wakoo-social__item--' . esc_attr( $p['type'] ) . ( $extra ? ' is-extra' : '' ) . '"' . ( $extra ? ' hidden' : '' ) . ( $o['edit'] ? ' title="ID: ' . esc_attr( $p['id'] ) . '"' : '' ) . '>';
			$h .= '<a class="wakoo-social__media" href="' . esc_url( $href ) . '"' . $blank . ( $lb ? ' data-wk-full="' . esc_url( $p['media'] ) . '" data-wk-caption="' . esc_attr( wp_strip_all_tags( (string) $caption ) ) . '"' : '' ) . '>';
			if ( $p['thumb'] ) { $h .= '<img src="' . esc_url( $p['thumb'] ) . '" loading="lazy" decoding="async" alt="' . esc_attr( wp_trim_words( (string) $p['caption'], 8 ) ) . '">'; }
			if ( 'video' === $p['type'] ) { $h .= '<span class="wakoo-social__play" aria-hidden="true">▶</span>'; }
			if ( 'yes' === $o['show_badge'] ) { $h .= '<span class="wakoo-social__badge">' . esc_html( $label ) . '</span>'; }
			if ( 'yes' === $o['hover_overlay'] && $short ) { $h .= '<span class="wakoo-social__overlay">' . esc_html( $short ) . '</span>'; }
			$h .= '</a>';

			if ( ( $short && 'yes' !== $o['hover_overlay'] ) || $meta ) {
				$h .= '<div class="wakoo-social__body">';
				if ( $short && 'yes' !== $o['hover_overlay'] ) { $h .= '<p class="wakoo-social__caption">' . esc_html( $short ) . '</p>'; }
				if ( $meta ) {
					$m = [];
					if ( $p['author'] ) { $m[] = esc_html( $p['author'] ); }
					if ( $p['date'] ) { $m[] = esc_html( date_i18n( get_option( 'date_format' ), (int) $p['date'] ) ); }
					if ( $m ) { $h .= '<p class="wakoo-social__meta">' . implode( ' · ', $m ) . '</p>'; }
				}
				$h .= '</div>';
			}
			$h .= '</article>';
		}
		$h .= '</div>';

		if ( 'carousel' === $layout ) {
			$h .= '<button type="button" class="wakoo-social__nav wakoo-social__nav--prev" aria-label="' . esc_attr__( 'Anterior', 'wakoo' ) . '">‹</button><button type="button" class="wakoo-social__nav wakoo-social__nav--next" aria-label="' . esc_attr__( 'Siguiente', 'wakoo' ) . '">›</button>';
		}
		if ( $more && count( $posts ) > $count ) {
			$h .= '<div class="wakoo-social__more"><button type="button" class="wakoo-social__morebtn">' . esc_html( '' !== $o['load_more_text'] ? $o['load_more_text'] : __( 'Cargar más', 'wakoo' ) ) . '</button></div>';
		}
		if ( $demo && $o['edit'] ) {
			$h .= '<p class="wakoo-social__demo-note">' . esc_html__( 'Modo demostración: publicaciones de ejemplo. Conecta esta red en «Redes Wakoo» para ver las tuyas.', 'wakoo' ) . '</p>';
		}
		return $h . '</div>';
	}

	/** [wakoo_feed network="instagram" count="6" layout="grid" columns="3" header="yes" follow="yes" load_more="yes" lightbox="yes"] */
	public static function shortcode( $atts ) {
		$a = shortcode_atts( [ 'network' => 'instagram', 'count' => 6, 'layout' => 'grid', 'columns' => 3, 'gap' => 14, 'header' => '', 'follow' => '', 'caption' => 'yes', 'meta' => 'yes', 'badge' => 'yes', 'load_more' => '', 'lightbox' => '', 'overlay' => '', 'hide' => '' ], $atts, 'wakoo_feed' );
		self::enqueue();
		$cols = max( 1, min( 6, (int) $a['columns'] ) );
		$html = self::render( [
			'network' => sanitize_key( $a['network'] ), 'count' => (int) $a['count'], 'layout' => sanitize_key( $a['layout'] ),
			'show_header' => $a['header'], 'show_follow' => $a['follow'], 'show_caption' => $a['caption'], 'show_meta' => $a['meta'], 'show_badge' => $a['badge'],
			'load_more' => $a['load_more'], 'lightbox' => $a['lightbox'], 'hover_overlay' => $a['overlay'], 'hide_ids' => $a['hide'],
		] );
		return $html ? '<div style="--wk-cols:' . $cols . ';--wk-gap:' . (int) $a['gap'] . 'px">' . $html . '</div>' : '';
	}
}
