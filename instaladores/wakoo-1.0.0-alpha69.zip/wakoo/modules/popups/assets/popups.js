( function () {
	'use strict';

	function store() {
		try { return window.localStorage; } catch ( e ) { return null; }
	}

	function seenKey( id ) { return 'wakoo_popup_' + id; }

	function canShow( id, cfg ) {
		if ( 'always' === cfg.frequency ) { return true; }
		var ls = store();
		if ( 'session' === cfg.frequency ) {
			try { return ! window.sessionStorage.getItem( seenKey( id ) ); } catch ( e ) { return true; }
		}
		if ( 'days' === cfg.frequency && ls ) {
			var until = parseInt( ls.getItem( seenKey( id ) ) || '0', 10 );
			return ! until || Date.now() > until;
		}
		return true;
	}

	function markSeen( id, cfg ) {
		if ( 'session' === cfg.frequency ) {
			try { window.sessionStorage.setItem( seenKey( id ), '1' ); } catch ( e ) {}
		} else if ( 'days' === cfg.frequency ) {
			var ls = store();
			if ( ls ) { ls.setItem( seenKey( id ), String( Date.now() + cfg.days * 864e5 ) ); }
		}
	}

	function open( el ) {
		if ( el.classList.contains( 'is-open' ) ) { return; }
		el.classList.add( 'is-open' );
		el.setAttribute( 'aria-hidden', 'false' );
		document.documentElement.classList.add( 'wakoo-popup-lock' );
		var cfg = read( el );
		markSeen( el.getAttribute( 'id' ).replace( 'wakoo-popup-', '' ), cfg );
	}

	function close( el ) {
		el.classList.remove( 'is-open' );
		el.setAttribute( 'aria-hidden', 'true' );
		if ( ! document.querySelector( '.wakoo-popup.is-open' ) ) {
			document.documentElement.classList.remove( 'wakoo-popup-lock' );
		}
	}

	function read( el ) {
		try { return JSON.parse( el.getAttribute( 'data-wakoo' ) || '{}' ); } catch ( e ) { return {}; }
	}

	function arm( el ) {
		var id  = el.getAttribute( 'id' ).replace( 'wakoo-popup-', '' );
		var cfg = read( el );

		// Close interactions.
		var closeBtn = el.querySelector( '.wakoo-popup__close' );
		if ( closeBtn ) { closeBtn.addEventListener( 'click', function () { close( el ); } ); }
		var overlay = el.querySelector( '.wakoo-popup__overlay' );
		if ( overlay && cfg.overlayClose ) { overlay.addEventListener( 'click', function () { close( el ); } ); }

		// Manual (click) popups only open from a trigger element.
		if ( 'click' === cfg.trigger ) { return; }

		if ( ! canShow( id, cfg ) ) { return; }

		if ( 'load' === cfg.trigger ) {
			open( el );
		} else if ( 'delay' === cfg.trigger ) {
			setTimeout( function () { if ( canShow( id, cfg ) ) { open( el ); } }, ( cfg.delay || 0 ) * 1000 );
		} else if ( 'scroll' === cfg.trigger ) {
			var onScroll = function () {
				var h = document.documentElement;
				var pct = ( h.scrollTop || document.body.scrollTop ) / ( ( h.scrollHeight - h.clientHeight ) || 1 ) * 100;
				if ( pct >= ( cfg.scroll || 0 ) ) {
					window.removeEventListener( 'scroll', onScroll );
					if ( canShow( id, cfg ) ) { open( el ); }
				}
			};
			window.addEventListener( 'scroll', onScroll, { passive: true } );
		} else if ( 'exit' === cfg.trigger ) {
			var onLeave = function ( e ) {
				if ( e.clientY <= 0 ) {
					document.removeEventListener( 'mouseout', onLeave );
					if ( canShow( id, cfg ) ) { open( el ); }
				}
			};
			document.addEventListener( 'mouseout', onLeave );
		}
	}

	function initTriggers() {
		document.addEventListener( 'click', function ( e ) {
			if ( ! e.target.closest ) { return; }
			// Close from inside the popup content: any element with the
			// wakoo-popup-close class (e.g. an age-gate "I'm over 18" button).
			var c = e.target.closest( '.wakoo-popup-close' );
			if ( c ) {
				var pop = c.closest( '.wakoo-popup' );
				if ( pop ) { e.preventDefault(); close( pop ); return; }
			}
			var t = e.target.closest( '.wakoo-open-popup' );
			if ( ! t ) { return; }
			var pid = t.getAttribute( 'data-wakoo-popup' );
			var el  = document.getElementById( 'wakoo-popup-' + pid );
			if ( el ) { e.preventDefault(); open( el ); }
		} );
		document.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key ) {
				var openEl = document.querySelector( '.wakoo-popup.is-open' );
				if ( openEl ) { close( openEl ); }
			}
		} );
	}

	function boot() {
		var list = document.querySelectorAll( '.wakoo-popup' );
		for ( var i = 0; i < list.length; i++ ) { arm( list[ i ] ); }
		initTriggers();
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}
}() );
