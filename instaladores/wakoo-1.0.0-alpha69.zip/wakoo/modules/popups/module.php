<?php
/**
 * Wakoo Popups: a popup builder on top of Elementor/Wakoo.
 *
 * - Registers a `wakoo_popup` post type that is edited with the Wakoo (Elementor)
 *   canvas, so a popup is designed with the full drag-and-drop ecosystem.
 * - Each popup stores its trigger, frequency, display conditions and look in post
 *   meta (a simple meta box).
 * - On the frontend, popups whose conditions match are printed hidden in the
 *   footer and shown by a tiny vanilla-JS engine (load, delay, scroll %, exit
 *   intent, or a click on any `.wakoo-open-popup[data-wakoo-popup="ID"]`).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Popups;

defined( 'ABSPATH' ) || die();

class Module {

	const CPT       = 'wakoo_popup';
	const META      = '_wakoo_popup';
	const NONCE     = 'wakoo_popup_meta';

	public static function init() {
		add_action( 'init', [ __CLASS__, 'register_cpt' ] );
		// Let the popup CPT be edited with Elementor/Wakoo.
		add_filter( 'elementor/utils/is_post_type_support', [ __CLASS__, 'enable_elementor' ], 10, 3 );
		add_filter( 'elementor/utils/is_post_support', [ __CLASS__, 'enable_elementor' ], 10, 3 );
		// Meta box with the popup behaviour.
		add_action( 'add_meta_boxes', [ __CLASS__, 'add_meta_box' ] );
		add_action( 'save_post_' . self::CPT, [ __CLASS__, 'save_meta' ] );
		// Frontend output + assets.
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue' ] );
		add_action( 'wp_footer', [ __CLASS__, 'render_popups' ], 100 );
	}

	public static function register_cpt() {
		register_post_type( self::CPT, [
			'labels' => [
				'name'          => __( 'Popups Wakoo', 'wakoo' ),
				'singular_name' => __( 'Popup', 'wakoo' ),
				'add_new'       => __( 'Añadir popup', 'wakoo' ),
				'add_new_item'  => __( 'Añadir popup', 'wakoo' ),
				'edit_item'     => __( 'Editar popup', 'wakoo' ),
				'menu_name'     => __( 'Popups Wakoo', 'wakoo' ),
			],
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'menu_icon'           => 'dashicons-align-center',
			'menu_position'       => 58,
			'exclude_from_search' => true,
			'publicly_queryable'  => false,
			'rewrite'             => false,
			'supports'            => [ 'title', 'editor', 'elementor', 'author' ],
		] );
	}

	public static function enable_elementor( $supported, $post_id = 0, $post_type = '' ) {
		if ( self::CPT === $post_type || ( $post_id && self::CPT === get_post_type( $post_id ) ) ) {
			return true;
		}
		return $supported;
	}

	/** Behaviour defaults. */
	public static function defaults() {
		return [
			'trigger'      => 'load',   // load | delay | scroll | exit | click
			'delay'        => 3,        // seconds (trigger=delay)
			'scroll'       => 40,       // percent (trigger=scroll)
			'frequency'    => 'always', // always | session | days
			'days'         => 7,
			'position'     => 'center', // center | top | bottom | top-left | top-right | bottom-left | bottom-right
			'width'        => 600,      // px
			'overlay'      => 'yes',
			'overlay_close'=> 'yes',
			'close_button' => 'yes',
			'animation'    => 'fade',   // fade | zoom | slide-up | slide-down
			'conditions'   => 'all',    // all | front | posts | pages | ids
			'ids'          => '',       // comma list (conditions=ids)
		];
	}

	public static function get_settings( $post_id ) {
		$saved = get_post_meta( $post_id, self::META, true );
		if ( ! is_array( $saved ) ) {
			$saved = [];
		}
		return array_merge( self::defaults(), $saved );
	}

	public static function add_meta_box() {
		add_meta_box( 'wakoo_popup_box', __( 'Comportamiento del popup', 'wakoo' ), [ __CLASS__, 'meta_box_html' ], self::CPT, 'side', 'high' );
	}

	public static function meta_box_html( $post ) {
		$s = self::get_settings( $post->ID );
		wp_nonce_field( self::NONCE, self::NONCE );
		$sel = function ( $a, $b ) { return selected( $a, $b, false ); };
		?>
		<p><label><strong><?php esc_html_e( 'Disparador', 'wakoo' ); ?></strong></label><br>
		<select name="wk[trigger]" style="width:100%">
			<option value="load" <?php echo $sel( $s['trigger'], 'load' ); ?>><?php esc_html_e( 'Al cargar', 'wakoo' ); ?></option>
			<option value="delay" <?php echo $sel( $s['trigger'], 'delay' ); ?>><?php esc_html_e( 'Tras una espera', 'wakoo' ); ?></option>
			<option value="scroll" <?php echo $sel( $s['trigger'], 'scroll' ); ?>><?php esc_html_e( 'Al hacer scroll', 'wakoo' ); ?></option>
			<option value="exit" <?php echo $sel( $s['trigger'], 'exit' ); ?>><?php esc_html_e( 'Intención de salida', 'wakoo' ); ?></option>
			<option value="click" <?php echo $sel( $s['trigger'], 'click' ); ?>><?php esc_html_e( 'Al hacer clic (manual)', 'wakoo' ); ?></option>
		</select></p>
		<p><label><?php esc_html_e( 'Espera (seg)', 'wakoo' ); ?> <input type="number" min="0" name="wk[delay]" value="<?php echo esc_attr( $s['delay'] ); ?>" style="width:70px"></label>
		&nbsp;<label><?php esc_html_e( 'Scroll %', 'wakoo' ); ?> <input type="number" min="0" max="100" name="wk[scroll]" value="<?php echo esc_attr( $s['scroll'] ); ?>" style="width:70px"></label></p>
		<p><label><strong><?php esc_html_e( 'Frecuencia', 'wakoo' ); ?></strong></label><br>
		<select name="wk[frequency]" style="width:100%">
			<option value="always" <?php echo $sel( $s['frequency'], 'always' ); ?>><?php esc_html_e( 'Siempre', 'wakoo' ); ?></option>
			<option value="session" <?php echo $sel( $s['frequency'], 'session' ); ?>><?php esc_html_e( 'Una vez por sesión', 'wakoo' ); ?></option>
			<option value="days" <?php echo $sel( $s['frequency'], 'days' ); ?>><?php esc_html_e( 'Una vez cada N días', 'wakoo' ); ?></option>
		</select>
		<label><?php esc_html_e( 'Días', 'wakoo' ); ?> <input type="number" min="1" name="wk[days]" value="<?php echo esc_attr( $s['days'] ); ?>" style="width:70px"></label></p>
		<p><label><strong><?php esc_html_e( 'Posición', 'wakoo' ); ?></strong></label><br>
		<select name="wk[position]" style="width:100%">
			<?php foreach ( [ 'center'=>'Centro','top'=>'Arriba','bottom'=>'Abajo','top-left'=>'Arriba izq.','top-right'=>'Arriba der.','bottom-left'=>'Abajo izq.','bottom-right'=>'Abajo der.' ] as $k=>$v ) : ?>
			<option value="<?php echo esc_attr( $k ); ?>" <?php echo $sel( $s['position'], $k ); ?>><?php echo esc_html( $v ); ?></option>
			<?php endforeach; ?>
		</select></p>
		<p><label><?php esc_html_e( 'Ancho (px)', 'wakoo' ); ?> <input type="number" min="200" name="wk[width]" value="<?php echo esc_attr( $s['width'] ); ?>" style="width:90px"></label></p>
		<p><label><strong><?php esc_html_e( 'Animación', 'wakoo' ); ?></strong></label><br>
		<select name="wk[animation]" style="width:100%">
			<?php foreach ( [ 'fade'=>'Desvanecer','zoom'=>'Zoom','slide-up'=>'Deslizar arriba','slide-down'=>'Deslizar abajo' ] as $k=>$v ) : ?>
			<option value="<?php echo esc_attr( $k ); ?>" <?php echo $sel( $s['animation'], $k ); ?>><?php echo esc_html( $v ); ?></option>
			<?php endforeach; ?>
		</select></p>
		<p>
			<label><input type="checkbox" name="wk[overlay]" value="yes" <?php checked( $s['overlay'], 'yes' ); ?>> <?php esc_html_e( 'Fondo oscuro', 'wakoo' ); ?></label><br>
			<label><input type="checkbox" name="wk[overlay_close]" value="yes" <?php checked( $s['overlay_close'], 'yes' ); ?>> <?php esc_html_e( 'Cerrar al pulsar fuera', 'wakoo' ); ?></label><br>
			<label><input type="checkbox" name="wk[close_button]" value="yes" <?php checked( $s['close_button'], 'yes' ); ?>> <?php esc_html_e( 'Botón de cerrar', 'wakoo' ); ?></label>
		</p>
		<p><label><strong><?php esc_html_e( 'Mostrar en', 'wakoo' ); ?></strong></label><br>
		<select name="wk[conditions]" style="width:100%">
			<option value="all" <?php echo $sel( $s['conditions'], 'all' ); ?>><?php esc_html_e( 'Todo el sitio', 'wakoo' ); ?></option>
			<option value="front" <?php echo $sel( $s['conditions'], 'front' ); ?>><?php esc_html_e( 'Portada', 'wakoo' ); ?></option>
			<option value="posts" <?php echo $sel( $s['conditions'], 'posts' ); ?>><?php esc_html_e( 'Entradas', 'wakoo' ); ?></option>
			<option value="pages" <?php echo $sel( $s['conditions'], 'pages' ); ?>><?php esc_html_e( 'Páginas', 'wakoo' ); ?></option>
			<option value="ids" <?php echo $sel( $s['conditions'], 'ids' ); ?>><?php esc_html_e( 'IDs concretos', 'wakoo' ); ?></option>
		</select>
		<input type="text" name="wk[ids]" value="<?php echo esc_attr( $s['ids'] ); ?>" placeholder="12, 34, 56" style="width:100%;margin-top:4px"></p>
		<p style="color:#787c82"><?php esc_html_e( 'Para abrir manualmente: añade la clase wakoo-open-popup y data-wakoo-popup con el ID a cualquier botón.', 'wakoo' ); ?></p>
		<?php
	}

	public static function save_meta( $post_id ) {
		if ( ! isset( $_POST[ self::NONCE ] ) || ! wp_verify_nonce( sanitize_key( $_POST[ self::NONCE ] ), self::NONCE ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$in = isset( $_POST['wk'] ) && is_array( $_POST['wk'] ) ? wp_unslash( $_POST['wk'] ) : [];
		$d  = self::defaults();
		$out = [
			'trigger'      => in_array( $in['trigger'] ?? '', [ 'load','delay','scroll','exit','click' ], true ) ? $in['trigger'] : $d['trigger'],
			'delay'        => max( 0, (int) ( $in['delay'] ?? $d['delay'] ) ),
			'scroll'       => min( 100, max( 0, (int) ( $in['scroll'] ?? $d['scroll'] ) ) ),
			'frequency'    => in_array( $in['frequency'] ?? '', [ 'always','session','days' ], true ) ? $in['frequency'] : $d['frequency'],
			'days'         => max( 1, (int) ( $in['days'] ?? $d['days'] ) ),
			'position'     => in_array( $in['position'] ?? '', [ 'center','top','bottom','top-left','top-right','bottom-left','bottom-right' ], true ) ? $in['position'] : $d['position'],
			'width'        => max( 200, (int) ( $in['width'] ?? $d['width'] ) ),
			'overlay'      => isset( $in['overlay'] ) ? 'yes' : 'no',
			'overlay_close'=> isset( $in['overlay_close'] ) ? 'yes' : 'no',
			'close_button' => isset( $in['close_button'] ) ? 'yes' : 'no',
			'animation'    => in_array( $in['animation'] ?? '', [ 'fade','zoom','slide-up','slide-down' ], true ) ? $in['animation'] : $d['animation'],
			'conditions'   => in_array( $in['conditions'] ?? '', [ 'all','front','posts','pages','ids' ], true ) ? $in['conditions'] : $d['conditions'],
			'ids'          => preg_replace( '/[^0-9,\s]/', '', (string) ( $in['ids'] ?? '' ) ),
		];
		update_post_meta( $post_id, self::META, $out );
	}

	/** Which published popups should load on the current request. */
	private static function matching_popups() {
		$q = get_posts( [
			'post_type'      => self::CPT,
			'post_status'    => 'publish',
			'posts_per_page' => 50,
			'no_found_rows'  => true,
		] );
		$matched = [];
		foreach ( $q as $p ) {
			$s = self::get_settings( $p->ID );
			if ( self::condition_matches( $s ) ) {
				$matched[] = [ 'id' => $p->ID, 's' => $s ];
			}
		}
		return $matched;
	}

	private static function condition_matches( $s ) {
		// A click popup is always printed (it is opened manually), subject only to
		// its own condition rule.
		switch ( $s['conditions'] ) {
			case 'front':
				return is_front_page();
			case 'posts':
				return is_single();
			case 'pages':
				return is_page();
			case 'ids':
				$ids = array_filter( array_map( 'intval', preg_split( '/[,\s]+/', $s['ids'] ) ) );
				return in_array( (int) get_queried_object_id(), $ids, true );
			case 'all':
			default:
				return true;
		}
	}

	/**
	 * True inside the Elementor editor or its preview iframe. Popups must never
	 * render there, or a load-triggered popup (e.g. an age gate) would cover the
	 * canvas and block editing.
	 */
	private static function is_builder_context() {
		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return false;
		}
		$p = \Elementor\Plugin::instance();
		if ( isset( $p->editor ) && $p->editor->is_edit_mode() ) {
			return true;
		}
		if ( isset( $p->preview ) && $p->preview->is_preview_mode() ) {
			return true;
		}
		// Preview iframe query flag, and Elementor's own template preview.
		return isset( $_GET['elementor-preview'] ) || isset( $_GET['preview_id'] ) || isset( $_GET['elementor_library'] ); // phpcs:ignore WordPress.Security.NonceVerification
	}

	public static function enqueue() {
		if ( is_admin() || self::is_builder_context() ) {
			return;
		}
		wp_enqueue_style( 'wakoo-popups', WAKOO_MODULES_URL . 'popups/assets/popups.css', [], WAKOO_VERSION );
		wp_enqueue_script( 'wakoo-popups', WAKOO_MODULES_URL . 'popups/assets/popups.js', [], WAKOO_VERSION, true );
	}

	public static function render_popups() {
		if ( is_admin() || self::is_builder_context() ) {
			return;
		}
		$popups = self::matching_popups();
		if ( ! $popups ) {
			return;
		}
		$frontend = \Elementor\Plugin::instance()->frontend;
		foreach ( $popups as $pp ) {
			$s       = $pp['s'];
			$content = $frontend->get_builder_content_for_display( $pp['id'] );
			$data    = [
				'trigger'   => $s['trigger'],
				'delay'     => (int) $s['delay'],
				'scroll'    => (int) $s['scroll'],
				'frequency' => $s['frequency'],
				'days'      => (int) $s['days'],
				'overlayClose' => 'yes' === $s['overlay_close'],
			];
			printf(
				'<div class="wakoo-popup wakoo-popup--pos-%1$s wakoo-popup--anim-%2$s" id="wakoo-popup-%3$d" data-wakoo="%4$s" aria-hidden="true" role="dialog">',
				esc_attr( $s['position'] ),
				esc_attr( $s['animation'] ),
				(int) $pp['id'],
				esc_attr( wp_json_encode( $data ) )
			);
			if ( 'yes' === $s['overlay'] ) {
				echo '<div class="wakoo-popup__overlay"></div>';
			}
			printf( '<div class="wakoo-popup__box" style="max-width:%dpx">', (int) $s['width'] );
			if ( 'yes' === $s['close_button'] ) {
				echo '<button class="wakoo-popup__close" aria-label="Cerrar">&times;</button>';
			}
			echo '<div class="wakoo-popup__content">' . $content . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Elementor-rendered content.
			echo '</div></div>';
		}
	}
}

Module::init();
