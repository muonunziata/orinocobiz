/* Wakoo Slides: the child containers of a container become full-screen slides (progress bar = timer). */
( function () {
	'use strict';

	function kids( root ) {
		var box = root.querySelector( ':scope > .e-con-inner' ) || root;
		return Array.prototype.filter.call( box.children, function ( c ) { return c.classList.contains( 'e-con' ) || c.classList.contains( 'elementor-element' ); } );
	}

	function init( root ) {
		if ( root.dataset.wakooInit ) { return; }
		if ( document.body.classList.contains( 'elementor-editor-active' ) || /elementor-preview/.test( location.search ) ) { return; } // stacked in the editor
		var cfg = {};
		try { cfg = JSON.parse( root.getAttribute( 'data-wakoo-slides' ) || '{}' ); } catch ( e ) {}
		var box = root.querySelector( ':scope > .e-con-inner' );
		if ( box ) { root.classList.add( 'has-inner' ); }
		var slides = kids( root );
		if ( slides.length < 2 ) { return; }
		root.dataset.wakooInit = '1';
		if ( box ) { box.classList.add( 'wakoo-slides', 'is-ready' ); }
		var host = box || root;
		host.classList.add( 'is-ready' );
		if ( cfg.anim ) { host.classList.add( 'is-anim' ); }
		var reduced = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
		var manual = reduced || ! cfg.time, out = false, over = false, focus = false, hiddenTab = document.hidden, idx = -1;
		root.style.setProperty( '--wks-dur', ( cfg.time || 9 ) + 's' );

		slides.forEach( function ( s, n ) {
			s.classList.add( 'wakoo-slide' );
			s.setAttribute( 'role', 'group' );
			s.setAttribute( 'aria-roledescription', 'slide' );
			s.setAttribute( 'aria-label', ( n + 1 ) + ' / ' + slides.length );
			if ( cfg.anim ) {
				Array.prototype.forEach.call( s.querySelectorAll( '.elementor-widget' ), function ( w, i ) {
					w.classList.add( 'wks-a' );
					w.style.setProperty( '--i', Math.min( i, 8 ) );
				} );
			}
		} );

		function esc( t ) { var d = document.createElement( 'div' ); d.textContent = t || ''; return d.innerHTML; }
		var ui = document.createElement( 'div' );
		ui.className = 'wakoo-slides__ui';
		var segs = '';
		slides.forEach( function ( s, n ) { segs += '<button type="button" class="wakoo-slides__seg" data-go="' + n + '" aria-label="' + ( n + 1 ) + ' / ' + slides.length + '"><i></i></button>'; } );
		ui.innerHTML = '<div class="wakoo-slides__top"><div class="wakoo-slides__prog">' + segs + '</div></div>'
			+ '<div class="wakoo-slides__ctl"><button type="button" class="wakoo-slides__btn" data-act="prev" aria-label="' + esc( cfg.prev ) + '">‹</button>'
			+ '<span class="wakoo-slides__count" aria-hidden="true"></span>'
			+ ( cfg.time ? '<button type="button" class="wakoo-slides__btn" data-act="play" aria-label="' + esc( cfg.pause ) + '">❚❚</button>' : '' )
			+ '<button type="button" class="wakoo-slides__btn" data-act="next" aria-label="' + esc( cfg.next ) + '">›</button>'
			+ ( cfg.btn && cfg.url ? '<a class="wakoo-slides__extra" href="' + esc( cfg.url ) + '"' + ( cfg.dl ? ' download' : '' ) + ' target="_blank" rel="noopener">' + esc( cfg.btn ) + '</a>' : '' )
			+ '</div>';
		root.appendChild( ui );
		if ( cfg.petals && ! reduced ) {
			var bg = document.createElement( 'div' ), cs = [ '#F1B6C0', '#F0CC8A', '#7CCBC4' ], h = '';
			bg.className = 'wakoo-slides__bg';
			bg.setAttribute( 'aria-hidden', 'true' );
			for ( var p = 0; p < cfg.petals; p++ ) {
				h += '<i class="wakoo-slides__petal" style="left:' + ( Math.random() * 100 ).toFixed( 1 ) + '%;--s:' + ( 9 + Math.random() * 13 ).toFixed( 0 ) + 'px;--d:' + ( 14 + Math.random() * 12 ).toFixed( 1 ) + 's;--w:-' + ( Math.random() * 20 ).toFixed( 1 ) + 's;--x:' + ( Math.random() * 160 - 80 ).toFixed( 0 ) + 'px;--c:' + cs[ p % 3 ] + '"></i>';
			}
			bg.innerHTML = h;
			root.insertBefore( bg, root.firstChild );
		}
		var segEls = Array.prototype.slice.call( ui.querySelectorAll( '.wakoo-slides__seg' ) );
		var count = ui.querySelector( '.wakoo-slides__count' ), play = ui.querySelector( '[data-act="play"]' );

		function playing() { return ! manual && ! out && ! over && ! focus && ! hiddenTab; }
		function paint() {
			root.classList.toggle( 'is-playing', playing() );
			root.classList.toggle( 'is-manual', manual );
			if ( play ) { play.textContent = manual ? '▶' : '❚❚'; play.setAttribute( 'aria-label', manual ? cfg.play : cfg.pause ); }
		}
		function go( n, force ) {
			n = ( n + slides.length ) % slides.length;
			if ( n === idx && ! force ) { return; }
			idx = n;
			slides.forEach( function ( s, i ) { s.classList.toggle( 'is-on', i === n ); s.setAttribute( 'aria-hidden', i === n ? 'false' : 'true' ); } );
			segEls.forEach( function ( g, i ) { g.classList.toggle( 'is-done', i < n ); g.classList.remove( 'is-cur' ); } );
			void segEls[ n ].offsetWidth; // restart the fill animation
			segEls[ n ].classList.add( 'is-cur' );
			root.classList.toggle( 'is-dark', '1' === slides[ n ].getAttribute( 'data-wakoo-dark' ) );
			count.textContent = ( n + 1 < 10 ? '0' : '' ) + ( n + 1 ) + ' / ' + slides.length;
			paint();
		}
		function back() { if ( window.innerWidth <= 860 ) { var r = root.getBoundingClientRect(); if ( r.top < -8 ) { root.scrollIntoView( { behavior: reduced ? 'auto' : 'smooth', block: 'start' } ); } } }

		root.addEventListener( 'animationend', function ( e ) { if ( 'wksFill' === e.animationName && playing() ) { go( idx + 1 ); } } );
		ui.addEventListener( 'click', function ( e ) {
			var b = e.target.closest( '[data-go],[data-act]' );
			if ( ! b ) { return; }
			if ( b.hasAttribute( 'data-go' ) ) { go( +b.getAttribute( 'data-go' ) ); back(); return; }
			var a = b.getAttribute( 'data-act' );
			if ( 'next' === a ) { go( idx + 1 ); back(); } else if ( 'prev' === a ) { go( idx - 1 ); back(); } else if ( 'play' === a ) { manual = ! manual; paint(); }
		} );
		host.addEventListener( 'pointerenter', function ( e ) { if ( 'mouse' === e.pointerType ) { over = true; paint(); } } );
		host.addEventListener( 'pointerleave', function ( e ) { if ( 'mouse' === e.pointerType ) { over = false; paint(); } } );
		root.addEventListener( 'focusin', function ( e ) { if ( e.target !== root ) { focus = true; paint(); } } );
		root.addEventListener( 'focusout', function () { focus = false; paint(); } );
		var x0 = null, y0 = 0, t0 = 0;
		host.addEventListener( 'pointerdown', function ( e ) { x0 = e.clientX; y0 = e.clientY; t0 = Date.now(); } );
		host.addEventListener( 'pointerup', function ( e ) {
			if ( null === x0 ) { return; }
			var dx = e.clientX - x0, dy = e.clientY - y0;
			x0 = null;
			if ( Math.abs( dx ) > 50 && Math.abs( dx ) > Math.abs( dy ) * 1.4 && Date.now() - t0 < 900 ) { go( dx < 0 ? idx + 1 : idx - 1 ); back(); }
		} );
		host.addEventListener( 'pointercancel', function () { x0 = null; } );
		root.addEventListener( 'keydown', function ( e ) {
			if ( e.target.closest && e.target.closest( 'input,textarea,select' ) ) { return; }
			if ( 'ArrowRight' === e.key ) { go( idx + 1 ); e.preventDefault(); }
			else if ( 'ArrowLeft' === e.key ) { go( idx - 1 ); e.preventDefault(); }
			else if ( 'Home' === e.key ) { go( 0 ); e.preventDefault(); }
			else if ( 'End' === e.key ) { go( slides.length - 1 ); e.preventDefault(); }
		} );
		if ( 'IntersectionObserver' in window ) {
			new IntersectionObserver( function ( es ) { out = ! es[ 0 ].isIntersecting; paint(); }, { threshold: 0.35 } ).observe( root );
		}
		document.addEventListener( 'visibilitychange', function () { hiddenTab = document.hidden; paint(); } );
		// Shown inside a full-screen layer (Wakoo Orbit): start again from the first slide and take the keyboard.
		root.addEventListener( 'wakoo:shown', function () { go( 0, true ); try { root.focus( { preventScroll: true } ); } catch ( e ) {} } );
		go( 0 );
	}

	function boot() { Array.prototype.forEach.call( document.querySelectorAll( '.wakoo-slides' ), init ); }
	if ( 'loading' === document.readyState ) { document.addEventListener( 'DOMContentLoaded', boot ); } else { boot(); }
	window.WakooSlides = { init: init };
} )();
