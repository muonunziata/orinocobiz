<?php
/**
 * Wakoo Slides: turns any container into a full-screen slider. Each direct child
 * container is one slide, built and edited with normal Elementor widgets. Progress
 * bar that is also the timer, previous / pause / next, counter, an optional extra
 * button (for example a PDF), swipe, keyboard, and staggered entrance of the widgets
 * of each slide. In the editor the slides stay one under the other.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Slides;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Module {

	public static function init() {
		add_action( 'elementor/element/container/section_layout/after_section_end', [ __CLASS__, 'controls' ], 20, 2 );
		add_action( 'elementor/frontend/container/before_render', [ __CLASS__, 'before_render' ] );
		add_action( 'elementor/frontend/after_register_scripts', function () {
			wp_register_script( 'wakoo-slides', WAKOO_MODULES_URL . 'slides/assets/slides.js', [], WAKOO_VERSION, true );
		} );
		add_action( 'elementor/frontend/after_register_styles', function () {
			wp_register_style( 'wakoo-slides', WAKOO_MODULES_URL . 'slides/assets/slides.css', [], WAKOO_VERSION );
		} );
	}

	public static function controls( $el, $args ) {
		$el->start_controls_section( 'wakoo_slides_section', [
			'label' => __( 'Diapositivas (Wakoo)', 'wakoo' ),
			'tab'   => Controls_Manager::TAB_ADVANCED,
		] );
		$el->add_control( 'wakoo_slides', [
			'label'        => __( 'Convertir en diapositivas', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => '',
			'description'  => __( 'Cada contenedor de dentro es una diapositiva. En el editor se ven una debajo de otra.', 'wakoo' ),
		] );
		$on = [ 'wakoo_slides' => 'yes' ];
		$el->add_control( 'wakoo_slides_time', [ 'label' => __( 'Segundos por diapositiva (0 = manual)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 120, 'default' => 9, 'condition' => $on ] );
		$el->add_control( 'wakoo_slides_full', [ 'label' => __( 'Alto de pantalla completa', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'condition' => $on ] );
		$el->add_control( 'wakoo_slides_anim', [ 'label' => __( 'Animar los elementos al entrar', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'description' => __( 'Entran uno tras otro. Clases opcionales en cada widget: wk-a-l (desde la izquierda), wk-a-r (desde la derecha), wk-a-z (acercar).', 'wakoo' ), 'condition' => $on ] );
		$el->add_control( 'wakoo_slides_petals', [ 'label' => __( 'Pétalos flotando (0 = ninguno)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 40, 'default' => 0, 'condition' => $on ] );
		$el->add_control( 'wakoo_slides_prev', [ 'label' => __( 'Texto «Anterior»', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Anterior', 'wakoo' ), 'separator' => 'before', 'condition' => $on ] );
		$el->add_control( 'wakoo_slides_next', [ 'label' => __( 'Texto «Siguiente»', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Siguiente', 'wakoo' ), 'condition' => $on ] );
		$el->add_control( 'wakoo_slides_pause', [ 'label' => __( 'Texto «Pausar»', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Pausar', 'wakoo' ), 'condition' => $on ] );
		$el->add_control( 'wakoo_slides_play', [ 'label' => __( 'Texto «Reproducir»', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Reproducir', 'wakoo' ), 'condition' => $on ] );
		$el->add_control( 'wakoo_slides_label', [ 'label' => __( 'Nombre del carrusel (accesible)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Presentación', 'wakoo' ), 'condition' => $on ] );
		$el->add_control( 'wakoo_slides_btn', [ 'label' => __( 'Botón extra junto a los controles', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '', 'description' => __( 'Por ejemplo «Descargar PDF». Vacío = sin botón.', 'wakoo' ), 'separator' => 'before', 'condition' => $on ] );
		$el->add_control( 'wakoo_slides_btn_link', [ 'label' => __( 'Enlace del botón extra', 'wakoo' ), 'type' => Controls_Manager::URL, 'default' => [ 'url' => '' ], 'condition' => $on ] );
		$el->add_control( 'wakoo_slides_btn_dl', [ 'label' => __( 'Descargar el archivo', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'condition' => $on ] );
		$el->add_control( 'wakoo_slide_dark', [
			'label'        => __( 'Esta diapositiva es oscura', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => '',
			'description'  => __( 'Para un contenedor que es una diapositiva: los controles se ven claros sobre ella.', 'wakoo' ),
			'separator'    => 'before',
			'condition'    => [ 'wakoo_slides!' => 'yes' ],
		] );
		$el->end_controls_section();
	}

	public static function before_render( $el ) {
		$s = $el->get_settings_for_display();
		if ( 'yes' === ( $s['wakoo_slide_dark'] ?? '' ) ) {
			$el->add_render_attribute( '_wrapper', 'data-wakoo-dark', '1' );
		}
		if ( 'yes' !== ( $s['wakoo_slides'] ?? '' ) ) { return; }
		$link = $s['wakoo_slides_btn_link'] ?? [];
		$cfg  = [
			'time'   => max( 0, (float) ( $s['wakoo_slides_time'] ?? 9 ) ),
			'anim'   => 'yes' === ( $s['wakoo_slides_anim'] ?? '' ),
			'petals' => min( 40, max( 0, (int) ( $s['wakoo_slides_petals'] ?? 0 ) ) ),
			'prev'   => (string) ( $s['wakoo_slides_prev'] ?? '' ),
			'next'   => (string) ( $s['wakoo_slides_next'] ?? '' ),
			'pause'  => (string) ( $s['wakoo_slides_pause'] ?? '' ),
			'play'   => (string) ( $s['wakoo_slides_play'] ?? '' ),
			'btn'    => (string) ( $s['wakoo_slides_btn'] ?? '' ),
			'url'    => esc_url( $link['url'] ?? '' ),
			'dl'     => 'yes' === ( $s['wakoo_slides_btn_dl'] ?? '' ),
		];
		$el->add_render_attribute( '_wrapper', [
			'class'                => 'wakoo-slides' . ( 'yes' === ( $s['wakoo_slides_full'] ?? '' ) ? ' wakoo-slides--full' : '' ),
			'data-wakoo-slides'    => wp_json_encode( $cfg ),
			'data-wakoo-shown'     => '1',
			'role'                 => 'region',
			'aria-roledescription' => 'carousel',
			'aria-label'           => (string) ( $s['wakoo_slides_label'] ?? '' ),
			'tabindex'             => '0',
		] );
		wp_enqueue_script( 'wakoo-slides' );
		wp_enqueue_style( 'wakoo-slides' );
	}
}

Module::init();
