<?php
/**
 * Wakoo Accesibilidad: runtime fixes + a site audit, built into the optimizer.
 *
 * Front end (on by default, switchable): skip-to-content link, visible focus
 * ring, missing image alt / link and button names filled in, and an optional
 * automatic text-contrast fix (WCAG AA). Admin: Wakoo → Accesibilidad scans the
 * Elementor content of every published page for low contrast, images without
 * alt text, empty buttons and heading-level problems.
 *
 * Fully native: no external service or library.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\A11y;

defined( 'ABSPATH' ) || die();

class Module {

	const OPT_ON       = 'wakoo_a11y_on';
	const OPT_CONTRAST = 'wakoo_a11y_contrast';

	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ], 25 );
		add_action( 'admin_init', [ __CLASS__, 'settings' ] );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue' ], 20 );
	}

	public static function enabled() {
		return (bool) apply_filters( 'wakoo_a11y_enabled', '0' !== get_option( self::OPT_ON, '1' ) );
	}

	public static function contrast_fix() {
		return '1' === get_option( self::OPT_CONTRAST, '0' );
	}

	private static function in_builder() {
		if ( isset( $_GET['elementor-preview'] ) || isset( $_GET['preview_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return true;
		}
		if ( class_exists( '\Elementor\Plugin' ) ) {
			$pl = \Elementor\Plugin::instance();
			if ( ( $pl->editor && $pl->editor->is_edit_mode() ) || ( $pl->preview && $pl->preview->is_preview_mode() ) ) {
				return true;
			}
		}
		return false;
	}

	public static function enqueue() {
		if ( ! self::enabled() || is_admin() || self::in_builder() ) {
			return;
		}
		wp_enqueue_style( 'wakoo-a11y', WAKOO_MODULES_URL . 'a11y/assets/a11y.css', [], WAKOO_VERSION );
		wp_enqueue_script( 'wakoo-a11y', WAKOO_MODULES_URL . 'a11y/assets/a11y.js', [], WAKOO_VERSION, true );
		wp_localize_script( 'wakoo-a11y', 'WakooA11y', [
			'contrast' => self::contrast_fix(),
			'skip'     => __( 'Saltar al contenido', 'wakoo' ),
		] );
	}

	/* ---------- settings + page ---------- */

	public static function menu() {
		add_submenu_page( 'wakoo-seo', __( 'Accesibilidad', 'wakoo' ), __( 'Accesibilidad', 'wakoo' ), 'manage_options', 'wakoo-a11y', [ __CLASS__, 'page' ] );
	}

	public static function settings() {
		$san = function ( $v ) { return $v ? '1' : '0'; };
		register_setting( 'wakoo_a11y_group', self::OPT_ON, [ 'type' => 'string', 'sanitize_callback' => $san, 'default' => '1' ] );
		register_setting( 'wakoo_a11y_group', self::OPT_CONTRAST, [ 'type' => 'string', 'sanitize_callback' => $san, 'default' => '0' ] );
	}

	public static function page() {
		$issues = self::audit();
		$labels = [
			'contrast' => __( 'Contraste bajo', 'wakoo' ),
			'alt'      => __( 'Imagen sin texto alternativo', 'wakoo' ),
			'button'   => __( 'Botón o enlace sin texto', 'wakoo' ),
			'heading'  => __( 'Títulos', 'wakoo' ),
		];
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Accesibilidad de Wakoo', 'wakoo' ); ?></h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'wakoo_a11y_group' ); ?>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><?php esc_html_e( 'Mejoras automáticas', 'wakoo' ); ?></th><td>
						<label><input type="checkbox" name="<?php echo esc_attr( self::OPT_ON ); ?>" value="1" <?php checked( self::enabled() ); ?>>
						<?php esc_html_e( 'Enlace “Saltar al contenido”, foco visible con teclado y rellenar nombres que faltan en imágenes, botones y enlaces', 'wakoo' ); ?></label>
					</td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Corregir contraste', 'wakoo' ); ?></th><td>
						<label><input type="checkbox" name="<?php echo esc_attr( self::OPT_CONTRAST ); ?>" value="1" <?php checked( self::contrast_fix() ); ?>>
						<?php esc_html_e( 'Si un texto no llega al contraste AA (4,5:1), cambiarlo a negro o blanco en la web', 'wakoo' ); ?></label>
						<p class="description"><?php esc_html_e( 'Desactivado por defecto porque puede cambiar un color de tu diseño. Es mejor arreglar los avisos de abajo en el editor.', 'wakoo' ); ?></p>
					</td></tr>
				</table>
				<?php submit_button(); ?>
			</form>

			<h2><?php esc_html_e( 'Auditoría de tus páginas', 'wakoo' ); ?></h2>
			<?php if ( ! $issues ) : ?>
				<p style="color:#1e824c;font-weight:600">✓ <?php esc_html_e( 'No se han encontrado problemas en las páginas hechas con Elementor.', 'wakoo' ); ?></p>
			<?php else : ?>
				<p><?php echo esc_html( sprintf( _n( '%d problema encontrado.', '%d problemas encontrados.', count( $issues ), 'wakoo' ), count( $issues ) ) ); ?></p>
				<table class="widefat striped" style="max-width:980px">
					<thead><tr><th><?php esc_html_e( 'Página', 'wakoo' ); ?></th><th><?php esc_html_e( 'Tipo', 'wakoo' ); ?></th><th><?php esc_html_e( 'Detalle', 'wakoo' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $issues as $i ) : ?>
						<tr>
							<td><a href="<?php echo esc_url( add_query_arg( [ 'post' => $i['post'], 'action' => 'elementor' ], admin_url( 'post.php' ) ) ); ?>"><?php echo esc_html( get_the_title( $i['post'] ) ); ?></a></td>
							<td><?php echo esc_html( $labels[ $i['type'] ] ?? $i['type'] ); ?></td>
							<td><?php echo esc_html( $i['msg'] ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
		<?php
	}

	/* ---------- audit ---------- */

	/** @return array<int,array{post:int,type:string,msg:string}> */
	public static function audit( $limit_posts = 200 ) {
		$ids = get_posts( [
			'post_type'      => [ 'page', 'post' ],
			'post_status'    => 'publish',
			'posts_per_page' => $limit_posts,
			'fields'         => 'ids',
			'meta_key'       => '_elementor_data', // phpcs:ignore WordPress.DB.SlowDBQuery
		] );
		$out = [];
		foreach ( $ids as $id ) {
			$raw = get_post_meta( $id, '_elementor_data', true );
			$data = is_string( $raw ) ? json_decode( $raw, true ) : $raw;
			if ( ! is_array( $data ) ) { continue; }
			$ctx = [ 'post' => $id, 'issues' => [], 'h1' => 0, 'last' => 0 ];
			self::walk( $data, '#FFFFFF', $ctx );
			if ( $ctx['h1'] > 1 ) {
				$ctx['issues'][] = [ 'post' => $id, 'type' => 'heading', 'msg' => sprintf( __( 'Hay %d títulos H1; debería haber solo uno.', 'wakoo' ), $ctx['h1'] ) ];
			}
			$out = array_merge( $out, $ctx['issues'] );
		}
		return $out;
	}

	private static function walk( array $els, $bg, array &$ctx ) {
		foreach ( $els as $el ) {
			$s = isset( $el['settings'] ) && is_array( $el['settings'] ) ? $el['settings'] : [];
			$mybg = $bg;
			if ( 'container' === ( $el['elType'] ?? '' ) || 'section' === ( $el['elType'] ?? '' ) || 'column' === ( $el['elType'] ?? '' ) ) {
				if ( ( $s['background_background'] ?? '' ) === 'classic' && ! empty( $s['background_color'] ) ) {
					$mybg = $s['background_color'];
				} elseif ( ( $s['background_background'] ?? '' ) === 'classic' && ! empty( $s['background_image']['url'] ) ) {
					$mybg = ''; // unknown (image): skip contrast checks inside.
				}
			}
			if ( 'widget' === ( $el['elType'] ?? '' ) ) {
				self::check_widget( $el['widgetType'] ?? '', $s, $mybg, $ctx );
			}
			if ( ! empty( $el['elements'] ) ) {
				self::walk( $el['elements'], $mybg, $ctx );
			}
		}
	}

	private static function check_widget( $type, array $s, $bg, array &$ctx ) {
		$post = $ctx['post'];
		$add  = function ( $t, $m ) use ( &$ctx, $post ) { $ctx['issues'][] = [ 'post' => $post, 'type' => $t, 'msg' => $m ]; };

		if ( 'heading' === $type ) {
			$tag = $s['header_size'] ?? 'h2';
			if ( 'h1' === $tag ) { $ctx['h1']++; }
			$lvl = (int) substr( $tag, 1 );
			if ( $lvl >= 1 && $lvl <= 6 ) {
				if ( $ctx['last'] && $lvl > $ctx['last'] + 1 ) {
					$add( 'heading', sprintf( __( 'Salto de nivel de título: de H%1$d a H%2$d (“%3$s”).', 'wakoo' ), $ctx['last'], $lvl, wp_trim_words( wp_strip_all_tags( $s['title'] ?? '' ), 5 ) ) );
				}
				$ctx['last'] = $lvl;
			}
		}

		if ( $bg ) {
			$fg = '';
			$what = '';
			if ( 'heading' === $type && ! empty( $s['title_color'] ) ) { $fg = $s['title_color']; $what = wp_trim_words( wp_strip_all_tags( $s['title'] ?? '' ), 5 ); }
			elseif ( 'text-editor' === $type && ! empty( $s['text_color'] ) ) { $fg = $s['text_color']; $what = wp_trim_words( wp_strip_all_tags( $s['editor'] ?? '' ), 5 ); }
			elseif ( 'button' === $type && ! empty( $s['button_text_color'] ) && ! empty( $s['background_color'] ) ) { $fg = $s['button_text_color']; $bg = $s['background_color']; $what = $s['text'] ?? ''; }
			if ( $fg ) {
				$r = self::ratio( $fg, $bg );
				if ( null !== $r && $r < 4.5 ) {
					$add( 'contrast', sprintf( __( '“%1$s”: contraste %2$s:1 (texto %3$s sobre %4$s), mínimo 4,5:1.', 'wakoo' ), $what, number_format_i18n( $r, 1 ), $fg, $bg ) );
				}
			}
		}

		if ( 'image' === $type ) {
			$aid = (int) ( $s['image']['id'] ?? 0 );
			$alt = $aid ? get_post_meta( $aid, '_wp_attachment_image_alt', true ) : '';
			$has_link = ! empty( $s['link']['url'] ) && 'custom' === ( $s['link_to'] ?? '' );
			if ( '' === trim( (string) $alt ) && '' === trim( (string) ( $s['image']['alt'] ?? '' ) ) && '' === trim( (string) ( $s['caption'] ?? '' ) ) ) {
				$add( 'alt', $has_link ? __( 'Imagen con enlace y sin texto alternativo.', 'wakoo' ) : __( 'Imagen sin texto alternativo.', 'wakoo' ) );
			}
		}

		if ( 'button' === $type && '' === trim( (string) ( $s['text'] ?? '' ) ) ) {
			$add( 'button', ! empty( $s['selected_icon']['value'] ) ? __( 'Botón solo con icono y sin texto.', 'wakoo' ) : __( 'Botón sin texto.', 'wakoo' ) );
		}
	}

	/* ---------- WCAG contrast ---------- */

	private static function rgb( $c ) {
		$c = trim( (string) $c );
		if ( preg_match( '/^#?([0-9a-f]{3})$/i', $c, $m ) ) {
			$h = $m[1]; return [ hexdec( $h[0] . $h[0] ), hexdec( $h[1] . $h[1] ), hexdec( $h[2] . $h[2] ) ];
		}
		if ( preg_match( '/^#?([0-9a-f]{6})([0-9a-f]{2})?$/i', $c, $m ) ) {
			$h = $m[1]; return [ hexdec( substr( $h, 0, 2 ) ), hexdec( substr( $h, 2, 2 ) ), hexdec( substr( $h, 4, 2 ) ) ];
		}
		if ( preg_match( '/rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)/i', $c, $m ) ) {
			return [ (int) $m[1], (int) $m[2], (int) $m[3] ];
		}
		return null;
	}

	private static function lum( array $rgb ) {
		$f = function ( $v ) { $v /= 255; return $v <= 0.03928 ? $v / 12.92 : pow( ( $v + 0.055 ) / 1.055, 2.4 ); };
		return 0.2126 * $f( $rgb[0] ) + 0.7152 * $f( $rgb[1] ) + 0.0722 * $f( $rgb[2] );
	}

	/** Contrast ratio between two CSS colours, or null if either is not a plain colour. */
	public static function ratio( $a, $b ) {
		$x = self::rgb( $a );
		$y = self::rgb( $b );
		if ( ! $x || ! $y ) { return null; }
		$l1 = self::lum( $x ); $l2 = self::lum( $y );
		if ( $l1 < $l2 ) { $t = $l1; $l1 = $l2; $l2 = $t; }
		return ( $l1 + 0.05 ) / ( $l2 + 0.05 );
	}
}

Module::init();
