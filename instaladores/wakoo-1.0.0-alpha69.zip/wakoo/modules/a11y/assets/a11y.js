/**
 * Wakoo Accesibilidad (front end). Native, no libraries.
 * - skip-to-content link
 * - alt="" for images without an alt attribute (decorative fallback)
 * - accessible names for links/buttons that have none
 * - optional WCAG AA text-contrast fix
 */
( function () {
	'use strict';
	var C = window.WakooA11y || {};

	function skipLink() {
		if ( document.querySelector( '.wakoo-skip' ) ) { return; }
		var target = document.querySelector( 'main, #content, [role="main"], .elementor' );
		if ( ! target ) { return; }
		if ( ! target.id ) { target.id = 'wakoo-main'; }
		if ( ! target.hasAttribute( 'tabindex' ) ) { target.setAttribute( 'tabindex', '-1' ); }
		var a = document.createElement( 'a' );
		a.className = 'wakoo-skip';
		a.href = '#' + target.id;
		a.textContent = C.skip || 'Saltar al contenido';
		document.body.insertBefore( a, document.body.firstChild );
	}

	function fixAlt() {
		var imgs = document.querySelectorAll( 'img:not([alt])' );
		for ( var i = 0; i < imgs.length; i++ ) { imgs[ i ].setAttribute( 'alt', imgs[ i ].getAttribute( 'title' ) || '' ); }
	}

	function fixNames() {
		var els = document.querySelectorAll( 'a[href], button, [role="button"]' );
		for ( var i = 0; i < els.length; i++ ) {
			var el = els[ i ];
			if ( el.hasAttribute( 'aria-label' ) || el.hasAttribute( 'aria-labelledby' ) ) { continue; }
			if ( ( el.textContent || '' ).trim() ) { continue; }
			var img = el.querySelector( 'img[alt]' );
			if ( img && img.getAttribute( 'alt' ).trim() ) { continue; }
			var label = el.getAttribute( 'title' );
			if ( ! label && 'A' === el.tagName ) {
				try { label = new URL( el.href, location.href ).hostname.replace( /^www\./, '' ); } catch ( e ) {}
			}
			if ( label ) { el.setAttribute( 'aria-label', label ); }
		}
	}

	/* ---- contrast ---- */
	function parse( c ) {
		var m = c.match( /rgba?\(\s*([\d.]+)[ ,]+([\d.]+)[ ,]+([\d.]+)(?:[ ,/]+([\d.]+))?/ );
		return m ? [ +m[ 1 ], +m[ 2 ], +m[ 3 ], m[ 4 ] === undefined ? 1 : +m[ 4 ] ] : null;
	}
	function lum( r ) {
		var f = function ( v ) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow( ( v + 0.055 ) / 1.055, 2.4 ); };
		return 0.2126 * f( r[ 0 ] ) + 0.7152 * f( r[ 1 ] ) + 0.0722 * f( r[ 2 ] );
	}
	function ratio( a, b ) {
		var l1 = lum( a ), l2 = lum( b );
		if ( l1 < l2 ) { var t = l1; l1 = l2; l2 = t; }
		return ( l1 + 0.05 ) / ( l2 + 0.05 );
	}
	function bgOf( el ) {
		var layers = [];
		for ( var n = el; n && n.nodeType === 1; n = n.parentElement ) {
			var cs = getComputedStyle( n );
			if ( cs.backgroundImage && 'none' !== cs.backgroundImage ) { return null; } // unknown
			var c = parse( cs.backgroundColor );
			if ( c && c[ 3 ] > 0 ) { layers.push( c ); if ( c[ 3 ] >= 1 ) { break; } }
		}
		var base = [ 255, 255, 255 ];
		for ( var i = layers.length - 1; i >= 0; i-- ) {
			var a = layers[ i ][ 3 ];
			base = [ layers[ i ][ 0 ] * a + base[ 0 ] * ( 1 - a ), layers[ i ][ 1 ] * a + base[ 1 ] * ( 1 - a ), layers[ i ][ 2 ] * a + base[ 2 ] * ( 1 - a ) ];
		}
		return base;
	}
	function fixContrast() {
		var els = document.querySelectorAll( '.elementor h1,.elementor h2,.elementor h3,.elementor h4,.elementor h5,.elementor h6,.elementor p,.elementor li,.elementor a,.elementor span,.elementor .elementor-button-text' );
		var max = Math.min( els.length, 1500 );
		for ( var i = 0; i < max; i++ ) {
			var el = els[ i ];
			if ( ! ( el.textContent || '' ).trim() || el.children.length && ! el.matches( 'a,span,p,li' ) ) { continue; }
			var cs = getComputedStyle( el );
			var fg = parse( cs.color );
			var bg = bgOf( el );
			if ( ! fg || ! bg || fg[ 3 ] < 1 ) { continue; }
			var size = parseFloat( cs.fontSize ), bold = parseInt( cs.fontWeight, 10 ) >= 700;
			var need = ( size >= 24 || ( size >= 18.66 && bold ) ) ? 3 : 4.5;
			if ( ratio( fg, bg ) >= need ) { continue; }
			var dark = [ 17, 17, 17 ], light = [ 255, 255, 255 ];
			el.style.setProperty( 'color', ratio( dark, bg ) >= ratio( light, bg ) ? '#111' : '#fff', 'important' );
		}
	}

	function run() {
		skipLink();
		fixAlt();
		fixNames();
		if ( C.contrast ) { fixContrast(); }
	}
	if ( 'loading' === document.readyState ) { document.addEventListener( 'DOMContentLoaded', run ); } else { run(); }
	window.addEventListener( 'load', function () { fixNames(); if ( C.contrast ) { fixContrast(); } } );
}() );
