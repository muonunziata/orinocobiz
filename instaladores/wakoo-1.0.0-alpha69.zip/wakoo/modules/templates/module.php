<?php
/**
 * Saved templates everywhere: [wakoo_template id="123"] shortcode, a "Template" widget
 * and a shortcode column in the Elementor templates list. Edit the template once and
 * every place that shows it updates.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Templates;

use Elementor\Plugin;

defined( 'ABSPATH' ) || die();

class Module {

	const SHORTCODE = 'wakoo_template';

	/** Template IDs being rendered, to stop a template from including itself. */
	private static $rendering = [];

	public static function init() {
		add_shortcode( self::SHORTCODE, [ __CLASS__, 'shortcode' ] );
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_filter( 'manage_elementor_library_posts_columns', [ __CLASS__, 'add_column' ] );
		add_action( 'manage_elementor_library_posts_custom_column', [ __CLASS__, 'render_column' ], 10, 2 );
		add_filter( 'manage_wk_library_posts_columns', [ __CLASS__, 'add_column' ] );
		add_action( 'manage_wk_library_posts_custom_column', [ __CLASS__, 'render_column' ], 10, 2 );
	}

	/** Every saved template, for selects. */
	public static function template_options() {
		$posts = get_posts( [
			'post_type'      => [ 'elementor_library', 'wk_library' ],
			'post_status'    => 'publish',
			'posts_per_page' => 200,
			'orderby'        => 'title',
			'order'          => 'ASC',
		] );
		$options = [];
		foreach ( $posts as $p ) {
			$type = get_post_meta( $p->ID, '_elementor_template_type', true );
			$options[ $p->ID ] = $p->post_title . ( $type ? ' (' . $type . ')' : '' );
		}
		return $options;
	}

	public static function render_template( $id ) {
		$id = absint( $id );
		if ( ! $id || isset( self::$rendering[ $id ] ) ) {
			return '';
		}
		$post = get_post( $id );
		if ( ! $post || ! in_array( $post->post_type, [ 'elementor_library', 'wk_library' ], true ) ) {
			return '';
		}
		if ( 'publish' !== $post->post_status && ! current_user_can( 'edit_post', $id ) ) {
			return '';
		}
		self::$rendering[ $id ] = true;
		$html = Plugin::instance()->frontend->get_builder_content_for_display( $id, true );
		unset( self::$rendering[ $id ] );
		return $html;
	}

	public static function shortcode( $atts ) {
		$atts = shortcode_atts( [ 'id' => 0 ], $atts, self::SHORTCODE );
		return self::render_template( $atts['id'] );
	}

	public static function add_column( $columns ) {
		$columns['wakoo_shortcode'] = __( 'Shortcode', 'wakoo' );
		return $columns;
	}

	public static function render_column( $column, $post_id ) {
		if ( 'wakoo_shortcode' !== $column ) {
			return;
		}
		$code = sprintf( '[%s id="%d"]', self::SHORTCODE, $post_id );
		printf(
			'<input type="text" class="wakoo-shortcode-input" readonly value="%1$s" onfocus="this.select()" style="width:100%%;max-width:230px" aria-label="%2$s">',
			esc_attr( $code ),
			esc_attr__( 'Template shortcode', 'wakoo' )
		);
	}

	public static function register_widget( $widgets_manager ) {
		// Loaded here because Elementor's Widget_Base is only available once widgets register.
		require_once __DIR__ . '/template-widget.php';
		$widgets_manager->register( new Template_Widget() );
	}
}

Module::init();
