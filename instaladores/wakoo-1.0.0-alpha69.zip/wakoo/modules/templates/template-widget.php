<?php
/**
 * The "Saved Template" widget. Loaded only when Elementor registers widgets, so
 * Widget_Base is available.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Templates;

use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widget_Base;

defined( 'ABSPATH' ) || die();

class Template_Widget extends Widget_Base {

	public function get_name() {
		return 'wk-template';
	}

	public function get_title() {
		return __( 'Saved Template', 'wakoo' );
	}

	public function get_icon() {
		return 'eicon-document-file';
	}

	public function get_categories() {
		return [ 'wakoo_category' ];
	}

	public function get_keywords() {
		return [ 'template', 'library', 'block', 'global', 'shortcode', 'wakoo' ];
	}

	protected function is_dynamic_content(): bool {
		return true;
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_template', [ 'label' => __( 'Template', 'wakoo' ) ] );
		$this->add_control( 'template_id', [
			'label'       => __( 'Choose Template', 'wakoo' ),
			'type'        => Controls_Manager::SELECT2,
			'options'     => Module::template_options(),
			'label_block' => true,
		] );
		$this->add_control( 'note', [
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => __( 'Changes made to the template show up everywhere it is used. You can also insert it anywhere with the shortcode shown in Templates > Saved Templates.', 'wakoo' ),
			'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
		] );
		$this->end_controls_section();
	}

	protected function render() {
		$id = $this->get_settings_for_display( 'template_id' );
		if ( ! $id ) {
			if ( Plugin::instance()->editor->is_edit_mode() ) {
				echo '<div class="wk-woo-placeholder" style="padding:24px;border:1px dashed #c3c4c7;text-align:center">' . esc_html__( 'Choose a saved template.', 'wakoo' ) . '</div>';
			}
			return;
		}
		echo Module::render_template( $id ); // phpcs:ignore WordPress.Security.EscapeOutput -- Elementor-rendered content.
	}
}
