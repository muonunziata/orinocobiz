<?php
/**
 * Wakoo: new Elementor/Wakoo pages start on a blank canvas (no theme header or
 * footer), like Elementor's "Canvas" page layout.
 *
 * Implemented the native Elementor way: the active Kit's "default page layout"
 * is set to Canvas once, and only if the user has not already chosen a layout.
 * After that we never touch it again, so the user keeps full control from
 * Site Settings → Layout.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Canvas_Default;

defined( 'ABSPATH' ) || die();

class Module {

	const FLAG = 'wakoo_canvas_default_applied';

	public static function init() {
		add_action( 'elementor/init', [ __CLASS__, 'maybe_apply' ], 30 );
	}

	public static function maybe_apply() {
		if ( get_option( self::FLAG ) ) {
			return;
		}

		$kits_manager = \Elementor\Plugin::instance()->kits_manager;
		if ( ! $kits_manager ) {
			return;
		}

		$current = $kits_manager->get_current_settings( 'default_page_template' );

		// Only switch to Canvas while the site is still on the theme default,
		// so an explicit user choice is never overwritten.
		if ( empty( $current ) || 'default' === $current ) {
			$kits_manager->update_kit_settings_based_on_option( 'default_page_template', 'canvas' );
		}

		update_option( self::FLAG, 1 );
	}
}

Module::init();
