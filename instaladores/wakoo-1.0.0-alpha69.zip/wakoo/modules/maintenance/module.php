<?php
/**
 * Wakoo Mantenimiento y 404: a maintenance mode and a custom 404 page, either
 * built with the editor (pick any page) or a simple built-in design.
 *
 * Maintenance answers 503 + Retry-After (search engines keep your ranking) and
 * lets logged-in editors through. Fully native.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Maintenance;

defined( 'ABSPATH' ) || die();

class Module {

	const OPT = 'wakoo_maint';

	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ], 26 );
		add_action( 'admin_init', [ __CLASS__, 'settings' ] );
		add_action( 'template_redirect', [ __CLASS__, 'maybe_serve' ], 1 );
		add_action( 'admin_bar_menu', [ __CLASS__, 'bar_notice' ], 300 );
	}

	public static function opts() {
		return wp_parse_args( (array) get_option( self::OPT, [] ), [
			'mode'      => 'off',
			'page'      => 0,
			'use_404'   => 'off',
			'page_404'  => 0,
			'title'     => __( 'Volvemos enseguida', 'wakoo' ),
			'message'   => __( 'Estamos haciendo mejoras en la web. Vuelve en unos minutos.', 'wakoo' ),
			'title_404' => __( 'Esta página no existe', 'wakoo' ),
			'msg_404'   => __( 'Puede que el enlace esté roto o que la página se haya movido.', 'wakoo' ),
		] );
	}

	/* ---------- serving ---------- */

	/** Whether visitors should currently see the maintenance page. */
	public static function should_block() {
		$o = self::opts();
		if ( 'on' !== $o['mode'] ) { return false; }
		if ( is_user_logged_in() && current_user_can( 'edit_posts' ) ) { return false; }
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return false; }
		return true;
	}

	private static function in_builder() {
		return isset( $_GET['elementor-preview'] ) || isset( $_GET['preview'] ); // phpcs:ignore WordPress.Security.NonceVerification
	}

	public static function maybe_serve() {
		if ( self::in_builder() ) { return; }
		$o = self::opts();
		if ( self::should_block() ) {
			self::output( (int) $o['page'], 503, $o['title'], $o['message'] );
		}
		if ( is_404() && 'on' === $o['use_404'] ) {
			self::output( (int) $o['page_404'], 404, $o['title_404'], $o['msg_404'] );
		}
	}

	/** Print a full page (editor-built if a page is chosen, else built-in) and stop. */
	private static function output( $page_id, $status, $title, $message ) {
		status_header( $status );
		nocache_headers();
		if ( 503 === $status ) { header( 'Retry-After: 3600' ); }
		add_filter( 'wp_robots', function ( $r ) { $r['noindex'] = true; return $r; } );

		$content = '';
		$p = $page_id ? get_post( $page_id ) : null;
		if ( $p && 'publish' === $p->post_status && class_exists( '\Elementor\Plugin' ) ) {
			// Build before wp_head so the page's CSS gets enqueued.
			$content = \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $p->ID, true );
		}
		?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo esc_html( $title . ' — ' . get_bloginfo( 'name' ) ); ?></title>
<?php wp_head(); ?>
</head>
<body <?php body_class( 'wakoo-maint' ); ?>>
<?php
if ( $content ) {
	echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
} else {
	$logo = defined( 'WAKOO_MODULES_URL' ) ? WAKOO_MODULES_URL . 'branding/assets/wakoo-mark.png' : '';
	echo '<style>body.wakoo-maint{margin:0;background:#f4f5fb;font-family:system-ui,sans-serif;color:#1a1a2e}.wkm{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;text-align:center}.wkm div{max-width:460px;background:#fff;border-radius:16px;padding:40px 32px;box-shadow:0 10px 40px rgba(26,26,46,.08)}.wkm img{width:72px;height:72px;margin-bottom:16px}.wkm h1{margin:0 0 10px;font-size:28px}.wkm p{margin:0;color:#666;line-height:1.5}.wkm a{display:inline-block;margin-top:20px;color:#6C5CE7;font-weight:600}</style>';
	echo '<main class="wkm"><div>';
	if ( $logo ) { echo '<img src="' . esc_url( $logo ) . '" alt="">'; }
	echo '<h1>' . esc_html( $title ) . '</h1><p>' . esc_html( $message ) . '</p>';
	if ( 404 === $status ) { echo '<a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Volver al inicio', 'wakoo' ) . '</a>'; }
	echo '</div></main>';
}
wp_footer();
echo '</body></html>';
		exit;
	}

	/* ---------- admin ---------- */

	public static function bar_notice( $bar ) {
		if ( 'on' === self::opts()['mode'] && current_user_can( 'manage_options' ) ) {
			$bar->add_node( [
				'id'    => 'wakoo_maint',
				'title' => '<span style="background:#d63638;color:#fff;padding:2px 8px;border-radius:4px;font-weight:600">' . esc_html__( 'Modo mantenimiento activo', 'wakoo' ) . '</span>',
				'href'  => admin_url( 'admin.php?page=wakoo-maintenance' ),
			] );
		}
	}

	public static function menu() {
		add_submenu_page( 'wakoo-seo', __( 'Mantenimiento y 404', 'wakoo' ), __( 'Mantenimiento y 404', 'wakoo' ), 'manage_options', 'wakoo-maintenance', [ __CLASS__, 'page' ] );
	}

	public static function settings() {
		register_setting( 'wakoo_maint_group', self::OPT, [ 'type' => 'array', 'sanitize_callback' => [ __CLASS__, 'sanitize' ] ] );
	}

	public static function sanitize( $in ) {
		$in = (array) $in;
		return [
			'mode'      => ( 'on' === ( $in['mode'] ?? '' ) ) ? 'on' : 'off',
			'page'      => absint( $in['page'] ?? 0 ),
			'use_404'   => ( 'on' === ( $in['use_404'] ?? '' ) ) ? 'on' : 'off',
			'page_404'  => absint( $in['page_404'] ?? 0 ),
			'title'     => sanitize_text_field( $in['title'] ?? '' ),
			'message'   => sanitize_textarea_field( $in['message'] ?? '' ),
			'title_404' => sanitize_text_field( $in['title_404'] ?? '' ),
			'msg_404'   => sanitize_textarea_field( $in['msg_404'] ?? '' ),
		];
	}

	private static function page_select( $name, $val ) {
		$pages = get_posts( [ 'post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => 200, 'orderby' => 'title', 'order' => 'ASC' ] );
		echo '<select name="' . esc_attr( self::OPT . '[' . $name . ']' ) . '"><option value="0">' . esc_html__( 'Diseño sencillo de Wakoo', 'wakoo' ) . '</option>';
		foreach ( $pages as $p ) {
			echo '<option value="' . (int) $p->ID . '"' . selected( (int) $val, $p->ID, false ) . '>' . esc_html( $p->post_title ?: '#' . $p->ID ) . '</option>';
		}
		echo '</select>';
	}

	public static function page() {
		$o = self::opts();
		$n = self::OPT;
		echo '<div class="wrap"><h1>' . esc_html__( 'Mantenimiento y página 404', 'wakoo' ) . '</h1><form method="post" action="options.php">';
		settings_fields( 'wakoo_maint_group' );
		echo '<h2>' . esc_html__( 'Modo mantenimiento', 'wakoo' ) . '</h2><table class="form-table"><tbody>';
		echo '<tr><th>' . esc_html__( 'Estado', 'wakoo' ) . '</th><td><label><input type="checkbox" name="' . esc_attr( $n ) . '[mode]" value="on" ' . checked( 'on', $o['mode'], false ) . '> ' . esc_html__( 'Activar (los visitantes ven la página de mantenimiento; tú y tu equipo seguís viendo la web)', 'wakoo' ) . '</label></td></tr>';
		echo '<tr><th>' . esc_html__( 'Página a mostrar', 'wakoo' ) . '</th><td>'; self::page_select( 'page', $o['page'] ); echo '<p class="description">' . esc_html__( 'Elige una página diseñada con el editor, o usa el diseño sencillo.', 'wakoo' ) . '</p></td></tr>';
		echo '<tr><th>' . esc_html__( 'Título (diseño sencillo)', 'wakoo' ) . '</th><td><input type="text" class="regular-text" name="' . esc_attr( $n ) . '[title]" value="' . esc_attr( $o['title'] ) . '"></td></tr>';
		echo '<tr><th>' . esc_html__( 'Mensaje', 'wakoo' ) . '</th><td><textarea class="large-text" rows="3" name="' . esc_attr( $n ) . '[message]">' . esc_textarea( $o['message'] ) . '</textarea></td></tr>';
		echo '</tbody></table><h2>' . esc_html__( 'Página 404 (no encontrada)', 'wakoo' ) . '</h2><table class="form-table"><tbody>';
		echo '<tr><th>' . esc_html__( 'Estado', 'wakoo' ) . '</th><td><label><input type="checkbox" name="' . esc_attr( $n ) . '[use_404]" value="on" ' . checked( 'on', $o['use_404'], false ) . '> ' . esc_html__( 'Usar la página 404 de Wakoo', 'wakoo' ) . '</label></td></tr>';
		echo '<tr><th>' . esc_html__( 'Página a mostrar', 'wakoo' ) . '</th><td>'; self::page_select( 'page_404', $o['page_404'] ); echo '</td></tr>';
		echo '<tr><th>' . esc_html__( 'Título (diseño sencillo)', 'wakoo' ) . '</th><td><input type="text" class="regular-text" name="' . esc_attr( $n ) . '[title_404]" value="' . esc_attr( $o['title_404'] ) . '"></td></tr>';
		echo '<tr><th>' . esc_html__( 'Mensaje', 'wakoo' ) . '</th><td><textarea class="large-text" rows="3" name="' . esc_attr( $n ) . '[msg_404]">' . esc_textarea( $o['msg_404'] ) . '</textarea></td></tr>';
		echo '</tbody></table>';
		submit_button();
		echo '</form></div>';
	}
}

Module::init();
