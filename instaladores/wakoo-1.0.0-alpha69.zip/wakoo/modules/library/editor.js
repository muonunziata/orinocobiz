( function ( $ ) {
	'use strict';

	var L = window.WakooLibrary || {};
	var i18n = L.i18n || {};
	var items = null; // cached index
	var $overlay = null;

	// --- native tabs (work on sites that can reach Elementor's library) -------
	function addNativeTabs() {
		try {
			var library = $e.components.get( 'library' );
			if ( ! library || 'function' !== typeof library.addTab || ( library.hasTab && library.hasTab( 'templates/wakoo-blocks' ) ) ) {
				return;
			}
			library.addTab( 'templates/wakoo-blocks', { title: 'Wakoo ' + ( i18n.blocks || 'Blocks' ), filter: { source: 'wakoo', type: 'block' } }, 0 );
			library.addTab( 'templates/wakoo-pages', { title: 'Wakoo ' + ( i18n.pages || 'Pages' ), filter: { source: 'wakoo', type: 'page' } }, 1 );
		} catch ( e ) {}
	}

	// --- self-contained Wakoo library panel ----------------------------------
	function request( action, data ) {
		return $.ajax( {
			url: L.ajaxUrl,
			method: 'POST',
			dataType: 'json',
			data: $.extend( { action: action, nonce: L.nonce }, data || {} ),
		} );
	}

	function insert( templateId, title ) {
		request( 'wakoo_library_content', { template_id: templateId } ).done( function ( res ) {
			if ( ! res || ! res.success ) {
				return;
			}
			var content = res.data.content || [];
			content = Array.isArray( content ) ? content : [ content ];
			var root = elementor.getPreviewContainer();
			var at = ( root.view && root.view.collection ) ? root.view.collection.length : ( root.children ? root.children.length : 0 );
			// import iterates data.content and creates each element (with its full
			// nested tree) under the preview container. It needs a model carrying a
			// title for the history entry, or it throws in getHistory().
			$e.run( 'document/elements/import', {
				model: new Backbone.Model( { title: title || 'Wakoo', elType: 'container' } ),
				data: { content: content },
				options: { at: at },
			} );
			close();
			if ( elementor.notifications ) {
				elementor.notifications.showToast( { message: i18n.inserted || 'Inserted' } );
			}
		} );
	}

	function render( type, category ) {
		var $grid = $overlay.find( '.wakoo-lib__grid' ).empty();
		var list = items.filter( function ( t ) {
			return t.type === type && ( ! category || category === 'all' || t.subtype === category );
		} );
		list.forEach( function ( t ) {
			var $card = $(
				'<div class="wakoo-lib__card">' +
					'<div class="wakoo-lib__thumb"><img alt="" src="' + ( t.thumbnail || ( L.thumbBase + t.template_id + '.svg' ) ) + '"></div>' +
					'<div class="wakoo-lib__meta"><span class="wakoo-lib__name"></span>' +
					'<span class="wakoo-lib__btns">' + ( t.preview ? '<button class="wakoo-lib__preview">' + ( i18n.preview || 'Vista previa' ) + '</button>' : '' ) + '<button class="wakoo-lib__insert">' + ( i18n.insert || 'Insert' ) + '</button></span></div>' +
				'</div>'
			);
			$card.find( '.wakoo-lib__name' ).text( t.title );
			$card.find( '.wakoo-lib__insert' ).on( 'click', function () { insert( t.template_id, t.title ); } );
			$card.find( '.wakoo-lib__preview, .wakoo-lib__thumb' ).on( 'click', function () { showPreview( t ); } );
			$grid.append( $card );
		} );
		if ( ! list.length ) {
			$grid.append( '<p class="wakoo-lib__empty">—</p>' );
		}
	}

	function showPreview( t ) {
		if ( ! t.preview ) { return; }
		var $p = $( '<div class="wakoo-lib__pv"><div class="wakoo-lib__pv-box">' +
			'<div class="wakoo-lib__pv-bar"><b></b><span><button class="wakoo-lib__pv-ins">' + ( i18n.insert || 'Insert' ) + '</button><button class="wakoo-lib__pv-x">&times;</button></span></div>' +
			'<div class="wakoo-lib__pv-img"><img alt="" src="' + t.preview + '"></div></div></div>' );
		$p.find( 'b' ).text( t.title );
		function done() { $p.remove(); }
		$p.find( '.wakoo-lib__pv-x' ).on( 'click', done );
		$p.on( 'click', function ( e ) { if ( e.target === $p[ 0 ] ) { done(); } } );
		$p.find( '.wakoo-lib__pv-ins' ).on( 'click', function () { done(); insert( t.template_id, t.title ); } );
		$overlay.append( $p );
	}

	function categories( type ) {
		var set = {};
		items.forEach( function ( t ) { if ( t.type === type ) { set[ t.subtype ] = 1; } } );
		return Object.keys( set );
	}

	function buildChips( type ) {
		var $chips = $overlay.find( '.wakoo-lib__chips' ).empty();
		var cats = [ 'all' ].concat( categories( type ) );
		cats.forEach( function ( c, idx ) {
			var $b = $( '<button class="wakoo-lib__chip"></button>' ).text( c === 'all' ? ( i18n.all || 'All' ) : c );
			if ( 0 === idx ) { $b.addClass( 'is-active' ); }
			$b.on( 'click', function () {
				$chips.find( '.wakoo-lib__chip' ).removeClass( 'is-active' );
				$b.addClass( 'is-active' );
				render( type, c );
			} );
			$chips.append( $b );
		} );
	}

	function switchType( type ) {
		$overlay.find( '.wakoo-lib__tab' ).removeClass( 'is-active' );
		$overlay.find( '.wakoo-lib__tab[data-type="' + type + '"]' ).addClass( 'is-active' );
		buildChips( type );
		render( type, 'all' );
	}

	function build() {
		$overlay = $(
			'<div class="wakoo-lib" role="dialog" aria-label="' + ( i18n.library || 'Wakoo' ) + '">' +
				'<div class="wakoo-lib__panel">' +
					'<div class="wakoo-lib__head">' +
						'<span class="wakoo-lib__logo">' + ( i18n.library || 'Wakoo' ) + '</span>' +
						'<div class="wakoo-lib__tabs">' +
							'<button class="wakoo-lib__tab is-active" data-type="block">' + ( i18n.blocks || 'Blocks' ) + '</button>' +
							'<button class="wakoo-lib__tab" data-type="page">' + ( i18n.pages || 'Pages' ) + '</button>' +
							'<button class="wakoo-lib__tab" data-type="popup">' + ( i18n.popups || 'Popups' ) + '</button>' +
							'<button class="wakoo-lib__tab" data-type="floating">' + ( i18n.floating || 'Floating' ) + '</button>' +
						'</div>' +
						'<button class="wakoo-lib__close" aria-label="close">&times;</button>' +
					'</div>' +
					'<div class="wakoo-lib__chips"></div>' +
					'<div class="wakoo-lib__grid"><p class="wakoo-lib__empty">' + ( i18n.loading || 'Loading' ) + '</p></div>' +
				'</div>' +
			'</div>'
		);
		$overlay.find( '.wakoo-lib__close' ).on( 'click', close );
		$overlay.on( 'click', function ( e ) { if ( e.target === $overlay[ 0 ] ) { close(); } } );
		$overlay.find( '.wakoo-lib__tab' ).on( 'click', function () { switchType( $( this ).data( 'type' ) ); } );
		$( 'body' ).append( $overlay );
	}

	function open() {
		if ( ! $overlay ) { build(); }
		$overlay.addClass( 'is-open' );
		if ( items ) {
			switchType( 'block' );
			return;
		}
		request( 'wakoo_library_items' ).done( function ( res ) {
			items = ( res && res.success ) ? res.data : [];
			switchType( 'block' );
		} );
	}

	function close() {
		if ( $overlay ) { $overlay.removeClass( 'is-open' ); }
	}

	// Launcher button in the editor's top bar.
	function addLauncher() {
		if ( document.querySelector( '.wakoo-lib-launch' ) ) {
			return;
		}
		var host = document.querySelector( '#elementor-editor-wrapper-v2' ) || document.body;
		var $btn = $( '<button class="wakoo-lib-launch" title="' + ( i18n.open || 'Wakoo' ) + '">✦ Wakoo</button>' );
		$btn.on( 'click', open );
		$( host ).append( $btn );
	}

	$( window ).on( 'elementor/init', function () {
		var tries = 0;
		var timer = setInterval( function () {
			tries++;
			if ( window.$e && $e.components && $e.components.get( 'library' ) ) {
				addNativeTabs();
				addLauncher();
				clearInterval( timer );
			} else if ( tries > 60 ) {
				addLauncher();
				clearInterval( timer );
			}
		}, 250 );
	} );
}( jQuery ) );
