<?php
/**
 * Wakoo template library: blocks and full pages inside the Elementor editor.
 *
 * Registers a template-library source (Source_Wakoo) reading JSON designs from
 * modules/library/templates/. The designs show up in Elementor's "Add Template"
 * modal under a Wakoo tab and are inserted like any other template.
 *
 * All designs are original and ship under the plugin's GPL license.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Library;

defined( 'ABSPATH' ) || die();

class Module {

	public static function init() {
		// Elementor builds its template-library manager during elementor/init and
		// offers no registration hook, so register the source right after it exists.
		add_action( 'elementor/init', [ __CLASS__, 'register_source' ], 20 );
		add_action( 'elementor/editor/after_enqueue_scripts', [ __CLASS__, 'enqueue_editor' ] );
		add_action( 'elementor/editor/after_enqueue_styles', [ __CLASS__, 'enqueue_style' ] );
		// Self-contained library panel (works regardless of Elementor's remote library).
		add_action( 'wp_ajax_wakoo_library_items', [ __CLASS__, 'ajax_items' ] );
		add_action( 'wp_ajax_wakoo_library_content', [ __CLASS__, 'ajax_content' ] );
	}

	private static function source() {
		require_once __DIR__ . '/source.php';
		static $src = null;
		if ( null === $src ) {
			$src = new Source_Wakoo();
		}
		return $src;
	}

	public static function ajax_items() {
		check_ajax_referer( 'wakoo_library', 'nonce' );
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error();
		}
		wp_send_json_success( self::source()->get_items() );
	}

	public static function ajax_content() {
		check_ajax_referer( 'wakoo_library', 'nonce' );
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error();
		}
		$id = isset( $_POST['template_id'] ) ? sanitize_text_field( wp_unslash( $_POST['template_id'] ) ) : '';
		wp_send_json_success( self::source()->get_data( [ 'template_id' => $id ] ) );
	}

	public static function enqueue_style() {
		wp_enqueue_style( 'wakoo-library', WAKOO_MODULES_URL . 'library/editor.css', [], WAKOO_VERSION );
	}

	public static function register_source() {
		$manager = \Elementor\Plugin::instance()->templates_manager;
		if ( ! $manager ) {
			return;
		}
		require_once __DIR__ . '/source.php';
		require_once __DIR__ . '/offline.php';
		$manager->register_source( Source_Wakoo::class );
	}

	public static function enqueue_editor() {
		wp_enqueue_script(
			'wakoo-library',
			WAKOO_MODULES_URL . 'library/editor.js',
			[ 'jquery', 'elementor-editor' ],
			WAKOO_VERSION,
			true
		);
		wp_localize_script( 'wakoo-library', 'WakooLibrary', [
			'sourceId'  => 'wakoo',
			'title'     => __( 'Wakoo', 'wakoo' ),
			'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
			'nonce'     => wp_create_nonce( 'wakoo_library' ),
			'thumbBase' => WAKOO_MODULES_URL . 'library/thumbnails/',
			'i18n'      => [
				'library'  => __( 'Biblioteca Wakoo', 'wakoo' ),
				'blocks'   => __( 'Bloques', 'wakoo' ),
				'pages'    => __( 'Páginas', 'wakoo' ),
				'popups'   => __( 'Popups', 'wakoo' ),
				'floating' => __( 'Flotantes', 'wakoo' ),
				'all'      => __( 'Todos', 'wakoo' ),
				'insert'   => __( 'Insertar', 'wakoo' ),
				'preview'  => __( 'Vista previa', 'wakoo' ),
				'open'     => __( 'Biblioteca Wakoo', 'wakoo' ),
				'loading'  => __( 'Cargando…', 'wakoo' ),
				'inserted' => __( 'Plantilla insertada', 'wakoo' ),
			],
		] );
	}
}

Module::init();
