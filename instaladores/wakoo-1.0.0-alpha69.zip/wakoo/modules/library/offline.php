<?php
/**
 * Lets the Wakoo template library work even when Elementor cannot reach its own
 * template-info server (my.elementor.com).
 *
 * Elementor's library modal aborts with an empty grid if that info request fails,
 * which also hides Wakoo's own (local) templates. Here we let the real request run;
 * only if it fails do we return a minimal valid payload so Elementor still renders
 * the modal and aggregates Wakoo's templates. No third-party content is faked.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Library;

defined( 'ABSPATH' ) || die();

class Offline {

	// Elementor library endpoints that, when unreachable, otherwise break or hang the
	// template modal and hide Wakoo's own templates.
	const INFO = 'my.elementor.com/api/v1/templates/info';
	const REMOTE = 'my.elementor.com/api/connect/v1/library/templates';
	const CLOUD = 'cloud-library';

	public static function init() {
		add_filter( 'pre_http_request', [ __CLASS__, 'maybe_fallback' ], 20, 3 );
		// Safety net: make sure Wakoo templates are always in the modal data.
		add_filter( 'elementor/library/full-data', [ __CLASS__, 'ensure_wakoo_templates' ] );
	}

	public static function maybe_fallback( $preempt, $args, $url ) {
		if ( false !== $preempt ) {
			return $preempt;
		}
		$url = (string) $url;
		$is_info   = false !== strpos( $url, self::INFO );
		$is_remote = false !== strpos( $url, self::REMOTE );
		$is_cloud  = false !== strpos( $url, self::CLOUD );
		if ( ! $is_info && ! $is_remote && ! $is_cloud ) {
			return $preempt;
		}
		// Try the real request once, without re-entering this filter.
		remove_filter( 'pre_http_request', [ __CLASS__, 'maybe_fallback' ], 20 );
		$method   = ! empty( $args['method'] ) ? strtoupper( $args['method'] ) : 'GET';
		$response = ( 'POST' === $method ) ? wp_remote_post( $url, $args ) : wp_remote_get( $url, $args );
		add_filter( 'pre_http_request', [ __CLASS__, 'maybe_fallback' ], 20, 3 );

		if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
			return $response; // Online: use Elementor's real data.
		}

		// Offline: an empty but valid payload so aggregation does not break or hang.
		$body = $is_info ? [ 'templates' => [], 'types_data' => (object) [] ] : [];
		return [
			'headers'  => [],
			'body'     => wp_json_encode( $body ),
			'response' => [ 'code' => 200, 'message' => 'OK' ],
			'cookies'  => [],
			'filename' => null,
		];
	}

	public static function ensure_wakoo_templates( $data ) {
		if ( empty( $data['templates'] ) || ! is_array( $data['templates'] ) ) {
			$data['templates'] = [];
		}
		foreach ( $data['templates'] as $t ) {
			if ( isset( $t['source'] ) && 'wakoo' === $t['source'] ) {
				return $data; // Already aggregated.
			}
		}
		$source = \Elementor\Plugin::instance()->templates_manager->get_source( 'wakoo' );
		if ( $source ) {
			$data['templates'] = array_merge( $data['templates'], $source->get_items() );
		}
		return $data;
	}
}

Offline::init();
