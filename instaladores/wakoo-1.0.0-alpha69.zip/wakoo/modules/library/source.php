<?php
/**
 * Elementor template-library source backed by the JSON files in templates/.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Library;

use Elementor\TemplateLibrary\Source_Base;

defined( 'ABSPATH' ) || die();

class Source_Wakoo extends Source_Base {

	public function get_id() {
		return 'wakoo';
	}

	public function get_title() {
		return __( 'Wakoo', 'wakoo' );
	}

	public function register_data() {}

	private function dir() {
		return __DIR__ . '/templates/';
	}

	private function index() {
		$file = $this->dir() . 'index.json';
		if ( ! is_readable( $file ) ) {
			return [];
		}
		$data = json_decode( file_get_contents( $file ), true );
		return is_array( $data ) ? $data : [];
	}

	private function prepare( $entry ) {
		return [
			'template_id'     => $entry['id'],
			'source'          => $this->get_id(),
			'type'            => $entry['type'],
			'subtype'         => $entry['subtype'],
			'title'           => $entry['title'],
			'thumbnail'       => WAKOO_MODULES_URL . 'library/thumbnails/' . $entry['id'] . ( file_exists( $this->dir() . '../thumbnails/' . $entry['id'] . '.jpg' ) ? '.jpg' : '.svg' ),
			'preview'         => file_exists( $this->dir() . '../previews/' . $entry['id'] . '.jpg' ) ? WAKOO_MODULES_URL . 'library/previews/' . $entry['id'] . '.jpg' : '',
			'date'            => time(),
			'author'          => 'Wakoo',
			'tags'            => [ $entry['subtype'] ],
			'isPro'           => false,
			'accessLevel'     => 0,
			'accessTier'      => 'free',
			'popularityIndex' => 0,
			'trendIndex'      => 0,
			'hasPageSettings' => false,
			'url'             => '',
			'favorite'        => false,
		];
	}

	public function get_items( $args = [] ) {
		$items = array_map( [ $this, 'prepare' ], $this->index() );
		if ( ! empty( $args['type'] ) ) {
			$types = (array) $args['type'];
			$items = array_values( array_filter( $items, function ( $i ) use ( $types ) {
				return in_array( $i['type'], $types, true );
			} ) );
		}
		return $items;
	}

	public function get_item( $template_id ) {
		foreach ( $this->index() as $entry ) {
			if ( $entry['id'] === $template_id ) {
				return $this->prepare( $entry );
			}
		}
		return [];
	}

	public function get_data( array $args ) {
		$template_id = preg_replace( '/[^a-z0-9\-]/', '', $args['template_id'] );
		$file = $this->dir() . $template_id . '.json';
		if ( ! $template_id || ! is_readable( $file ) ) {
			return [ 'content' => [] ];
		}
		$data = json_decode( file_get_contents( $file ), true );
		$content = isset( $data['content'] ) && is_array( $data['content'] ) ? $data['content'] : [];
		$content = $this->replace_elements_ids( $content );
		$content = $this->process_export_import_content( $content, 'on_import' );
		return [
			'content'       => $content,
			'page_settings' => [],
		];
	}

	// Read-only source: Wakoo ships these templates; the user can't edit or delete them here.
	public function delete_template( $template_id ) {}
	public function save_item( $template_data ) {
		return new \WP_Error( 'wakoo_readonly', __( 'Wakoo templates are read-only.', 'wakoo' ) );
	}
	public function update_item( $new_data ) {
		return new \WP_Error( 'wakoo_readonly', __( 'Wakoo templates are read-only.', 'wakoo' ) );
	}
	public function export_template( $template_id ) {
		return new \WP_Error( 'wakoo_readonly', __( 'Wakoo templates are read-only.', 'wakoo' ) );
	}
}
