<?php
/**
 * Territorio storage: the log table (case history, private messages and the audit trail)
 * and the private file store (documents that never get a public URL).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

defined( 'ABSPATH' ) || die();

class Store {

	/** Log visibility: public = applicant and staff; internal = staff only; audit = audit screen only. */
	const VIS = [ 'public', 'internal', 'audit' ];

	/** Allowed private uploads: extension => mime. */
	const FILES = [
		'pdf' => 'application/pdf', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp',
		'doc' => 'application/msword', 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
		'xls' => 'application/vnd.ms-excel', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
		'odt' => 'application/vnd.oasis.opendocument.text', 'ods' => 'application/vnd.oasis.opendocument.spreadsheet',
		'csv' => 'text/csv', 'txt' => 'text/plain', 'zip' => 'application/zip',
	];

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'wakoo_tlog';
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$t = self::table();
		dbDelta( "CREATE TABLE $t (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			obj_type varchar(32) NOT NULL DEFAULT '',
			obj_id bigint(20) unsigned NOT NULL DEFAULT 0,
			kind varchar(32) NOT NULL DEFAULT '',
			vis varchar(16) NOT NULL DEFAULT 'internal',
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			message text NOT NULL,
			who varchar(24) NOT NULL DEFAULT '',
			created datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY obj (obj_type,obj_id),
			KEY vis (vis,created)
		) " . $wpdb->get_charset_collate() . ';' );
		self::protect_dir();
	}

	/**
	 * One log line. Every sensitive action calls this (audit). $vis: public | internal | audit.
	 */
	public static function log( $obj_type, $obj_id, $kind, $message, $vis = 'audit', $user = null ) {
		global $wpdb;
		$wpdb->insert( self::table(), [ // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			'obj_type' => substr( sanitize_key( $obj_type ), 0, 32 ),
			'obj_id'   => (int) $obj_id,
			'kind'     => substr( sanitize_key( $kind ), 0, 32 ),
			'vis'      => in_array( $vis, self::VIS, true ) ? $vis : 'audit',
			'user_id'  => null === $user ? get_current_user_id() : (int) $user,
			'message'  => wp_kses( (string) $message, [ 'br' => [] ] ),
			'who'      => Module::who(),
			'created'  => current_time( 'mysql', true ),
		] );
		return (int) $wpdb->insert_id;
	}

	/** Log lines of one object, oldest first. $vis = list of visibilities to include. */
	public static function lines( $obj_type, $obj_id, $vis = [ 'public' ] ) {
		global $wpdb;
		$vis = array_values( array_intersect( (array) $vis, self::VIS ) );
		if ( ! $vis ) { return []; }
		$in = implode( ',', array_fill( 0, count( $vis ), '%s' ) );
		$sql = $wpdb->prepare( 'SELECT * FROM ' . self::table() . " WHERE obj_type = %s AND obj_id = %d AND vis IN ($in) ORDER BY id ASC LIMIT 500", array_merge( [ $obj_type, (int) $obj_id ], $vis ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		return (array) $wpdb->get_results( $sql ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL
	}

	/** Audit screen: latest lines, optionally filtered by object type. */
	public static function latest( $type = '', $limit = 200, $offset = 0 ) {
		global $wpdb;
		$where = $type ? $wpdb->prepare( 'WHERE obj_type = %s', $type ) : '';
		return (array) $wpdb->get_results( 'SELECT * FROM ' . self::table() . " $where ORDER BY id DESC LIMIT " . (int) $limit . ' OFFSET ' . (int) $offset ); // phpcs:ignore
	}

	/* ---------------------------------------------------------------- private files */

	/** Folder outside the web root when WAKOO_PRIVATE_DIR is defined (recommended), else a locked uploads folder. */
	public static function dir() {
		if ( defined( 'WAKOO_PRIVATE_DIR' ) && WAKOO_PRIVATE_DIR ) { return untrailingslashit( WAKOO_PRIVATE_DIR ); }
		$u = wp_upload_dir( null, false );
		return $u['basedir'] . '/wakoo-privado';
	}

	public static function protect_dir() {
		$d = self::dir();
		if ( ! wp_mkdir_p( $d ) ) { return false; }
		$files = [
			'.htaccess'  => "Require all denied\nDeny from all\n",
			'index.php'  => "<?php // Silence.\n",
			'web.config' => '<?xml version="1.0"?><configuration><system.webServer><authorization><deny users="*" /></authorization></system.webServer></configuration>',
		];
		foreach ( $files as $n => $c ) {
			if ( ! file_exists( "$d/$n" ) ) { file_put_contents( "$d/$n", $c ); } // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		return true;
	}

	/**
	 * Keep one uploaded file ($_FILES entry). Returns the record or WP_Error.
	 * Records live in the owner post's meta (_wakoo_t_files); the file has a random name and no URL.
	 */
	public static function keep( $f, $label = '' ) {
		if ( empty( $f['tmp_name'] ) || ! empty( $f['error'] ) ) { return new \WP_Error( 'upload', __( 'No se pudo recibir el archivo.', 'wakoo' ) ); }
		$max = max( 1, (int) Module::settings()['max_mb'] ) * MB_IN_BYTES;
		if ( (int) $f['size'] > $max ) { return new \WP_Error( 'size', sprintf( __( 'El archivo supera el límite de %d MB.', 'wakoo' ), (int) Module::settings()['max_mb'] ) ); }
		$name  = sanitize_file_name( (string) $f['name'] );
		$check = wp_check_filetype_and_ext( $f['tmp_name'], $name, self::FILES );
		$ext   = strtolower( (string) ( $check['ext'] ?: pathinfo( $name, PATHINFO_EXTENSION ) ) );
		if ( empty( $check['type'] ) || ! isset( self::FILES[ $ext ] ) ) { return new \WP_Error( 'type', __( 'Tipo de archivo no permitido. Formatos: PDF, imágenes, Word, Excel, OpenDocument, CSV, TXT o ZIP.', 'wakoo' ) ); }
		if ( ! self::protect_dir() ) { return new \WP_Error( 'dir', __( 'No se pudo preparar el almacenamiento privado.', 'wakoo' ) ); }
		$token = wp_generate_password( 24, false );
		$dest  = self::dir() . '/' . $token . '.bin';
		if ( ! @move_uploaded_file( $f['tmp_name'], $dest ) && ! ( defined( 'WAKOO_TESTING' ) && @rename( $f['tmp_name'], $dest ) ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return new \WP_Error( 'move', __( 'No se pudo guardar el archivo.', 'wakoo' ) );
		}
		return [
			'id'    => $token,
			'name'  => $name,
			'label' => sanitize_text_field( $label ),
			'size'  => (int) $f['size'],
			'mime'  => $check['type'],
			'user'  => get_current_user_id(),
			'time'  => time(),
			'hash'  => hash_file( 'sha256', $dest ),
		];
	}

	public static function files( $post_id ) {
		$f = get_post_meta( $post_id, Module::PRE . 'files', true );
		return is_array( $f ) ? $f : [];
	}

	public static function add_file( $post_id, $rec ) {
		$all            = self::files( $post_id );
		$all[ $rec['id'] ] = $rec;
		update_post_meta( $post_id, Module::PRE . 'files', $all );
	}

	/** Remove a file record and its bytes. */
	public static function drop_file( $post_id, $token ) {
		$all = self::files( $post_id );
		if ( ! isset( $all[ $token ] ) ) { return false; }
		$path = self::dir() . '/' . preg_replace( '/[^A-Za-z0-9]/', '', $token ) . '.bin';
		if ( file_exists( $path ) ) { wp_delete_file( $path ); }
		unset( $all[ $token ] );
		update_post_meta( $post_id, Module::PRE . 'files', $all );
		return true;
	}

	/** Who may download the files of a post: its owner (applicant / company owner) or staff who can edit it. */
	public static function can_read( $post_id ) {
		$p = get_post( $post_id );
		if ( ! $p || ! is_user_logged_in() ) { return false; }
		if ( (int) $p->post_author === get_current_user_id() ) { return true; }
		return current_user_can( 'edit_post', $post_id );
	}

	public static function download_url( $post_id, $token ) {
		return wp_nonce_url( add_query_arg( [ 'action' => 'wakoo_t_file', 'p' => (int) $post_id, 'f' => $token ], admin_url( 'admin-post.php' ) ), 'wakoo_t_file_' . $post_id );
	}

	/** Stream a private file after checking who asks. */
	public static function serve() {
		$pid   = isset( $_GET['p'] ) ? (int) $_GET['p'] : 0;
		$token = isset( $_GET['f'] ) ? preg_replace( '/[^A-Za-z0-9]/', '', (string) wp_unslash( $_GET['f'] ) ) : '';
		if ( ! $pid || ! $token || ! wp_verify_nonce( $_GET['_wpnonce'] ?? '', 'wakoo_t_file_' . $pid ) || ! self::can_read( $pid ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			wp_die( esc_html__( 'No tiene acceso a este documento.', 'wakoo' ), '', [ 'response' => 403 ] );
		}
		$all = self::files( $pid );
		$path = self::dir() . '/' . $token . '.bin';
		if ( ! isset( $all[ $token ] ) || ! is_readable( $path ) ) { wp_die( esc_html__( 'Documento no encontrado.', 'wakoo' ), '', [ 'response' => 404 ] ); }
		self::log( get_post_type( $pid ), $pid, 'file_read', sprintf( 'Descarga de «%s»', $all[ $token ]['name'] ), 'audit' );
		nocache_headers();
		header( 'Content-Type: ' . $all[ $token ]['mime'] );
		header( 'Content-Length: ' . filesize( $path ) );
		header( 'Content-Disposition: attachment; filename="' . rawurlencode( $all[ $token ]['name'] ) . '"' );
		header( 'X-Content-Type-Options: nosniff' );
		readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		exit;
	}
}
