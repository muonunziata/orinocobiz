<?php
/**
 * Academia (MVP LMS): enrolment, lessons, quizzes, progress, completion and verifiable
 * certificates. Courses may instead point to an external Moodle course (link only: no SSO).
 *
 * Data: enrolment in user meta `_wakoo_t_courses` [ course => [ date, status ] ] (status
 * enrolled | interest | completed); progress in `_wakoo_t_prog_<course>` [ lesson => [ done, score ] ];
 * certificates are private `wakoo_cert` posts with a random verification code.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

defined( 'ABSPATH' ) || die();

class Academy {

	const ENROL = '_wakoo_t_courses';
	const PROG  = '_wakoo_t_prog_';

	public static function init() {
		foreach ( [ 'enroll' => 'enroll', 'lesson_done' => 'lesson_done', 'quiz' => 'quiz_post' ] as $a => $fn ) {
			add_action( 'admin_post_wakoo_t_' . $a, [ __CLASS__, $fn ] );
			add_action( 'admin_post_nopriv_wakoo_t_' . $a, [ Forms::class, 'need_login' ] );
		}
		add_action( 'template_redirect', [ __CLASS__, 'print_cert' ] );
	}

	/** Course status: open (enrolment), design (interest list only), closed. */
	public static function status( $course ) {
		$s = Module::meta( $course, 'cstatus', 'open' );
		return in_array( $s, [ 'open', 'design', 'closed' ], true ) ? $s : 'open';
	}

	public static function lessons( $course ) {
		return get_posts( [ 'post_type' => Module::LESSON, 'post_status' => 'publish', 'numberposts' => 200, 'orderby' => [ 'menu_order' => 'ASC', 'ID' => 'ASC' ],
			'meta_key' => Module::PRE . 'course', 'meta_value' => (int) $course ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
	}

	public static function enrolment( $uid, $course = 0 ) {
		$all = get_user_meta( $uid, self::ENROL, true );
		$all = is_array( $all ) ? $all : [];
		return $course ? ( $all[ $course ] ?? null ) : $all;
	}

	public static function progress( $uid, $course ) {
		$p = get_user_meta( $uid, self::PROG . (int) $course, true );
		return is_array( $p ) ? $p : [];
	}

	/** Quiz of a lesson: [ [ q, options[], answer ] ]. */
	public static function quiz( $lesson ) {
		$q = json_decode( (string) Module::meta( $lesson, 'quiz', '[]' ), true );
		$out = [];
		foreach ( (array) $q as $it ) {
			if ( ! empty( $it['q'] ) && ! empty( $it['options'] ) && is_array( $it['options'] ) ) {
				$out[] = [ 'q' => (string) $it['q'], 'options' => array_values( array_map( 'strval', $it['options'] ) ), 'answer' => (int) ( $it['answer'] ?? 0 ) ];
			}
		}
		return $out;
	}

	/** Percentage of lessons completed (a lesson with a quiz counts when the quiz is passed). */
	public static function percent( $uid, $course ) {
		$ls = self::lessons( $course );
		if ( ! $ls ) { return 0; }
		$p = self::progress( $uid, $course );
		$done = 0;
		foreach ( $ls as $l ) { if ( ! empty( $p[ $l->ID ]['done'] ) ) { $done++; } }
		return (int) floor( $done * 100 / count( $ls ) );
	}

	private static function course_from_post() {
		$c = isset( $_POST['course'] ) ? (int) $_POST['course'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$p = get_post( $c );
		return ( $p && Module::COURSE === $p->post_type && 'publish' === $p->post_status ) ? $p : null;
	}

	private static function nonce( $a ) {
		if ( ! isset( $_POST['_wkt'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wkt'] ) ), 'wakoo_t_' . $a ) ) { Forms::back( 'expired' ); }
	}

	public static function enroll() {
		self::nonce( 'enroll' );
		$c = self::course_from_post();
		if ( ! $c ) { Forms::back( 'denied' ); }
		$st = self::status( $c->ID );
		if ( 'closed' === $st ) { Forms::back( 'closed' ); }
		if ( empty( $_POST['consent'] ) ) { Forms::back( 'consent' ); } // phpcs:ignore WordPress.Security.NonceVerification
		$uid = get_current_user_id();
		$all = self::enrolment( $uid );
		if ( empty( $all[ $c->ID ] ) || ( 'interest' === $all[ $c->ID ]['status'] && 'open' === $st ) ) {
			$all[ $c->ID ] = [ 'date' => time(), 'status' => 'open' === $st ? 'enrolled' : 'interest' ];
			update_user_meta( $uid, self::ENROL, $all );
			Store::log( Module::COURSE, $c->ID, 'enroll', ( 'open' === $st ? 'Inscripción' : 'Registro de interés' ) . ' del usuario #' . $uid, 'audit' );
		}
		Forms::back( 'open' === $st ? 'enrolled' : 'interest' );
	}

	private static function lesson_from_post( $uid ) {
		$l = isset( $_POST['lesson'] ) ? (int) $_POST['lesson'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$p = get_post( $l );
		if ( ! $p || Module::LESSON !== $p->post_type || 'publish' !== $p->post_status ) { return null; }
		$c = (int) Module::meta( $p->ID, 'course' );
		$e = self::enrolment( $uid, $c );
		return ( $e && in_array( $e['status'], [ 'enrolled', 'completed' ], true ) ) ? [ $p, $c ] : null;
	}

	public static function lesson_done() {
		self::nonce( 'lesson_done' );
		$uid = get_current_user_id();
		$r   = self::lesson_from_post( $uid );
		if ( ! $r ) { Forms::back( 'denied' ); }
		[ $l, $c ] = $r;
		if ( self::quiz( $l->ID ) ) { Forms::back( 'denied' ); } // Lessons with a quiz complete by passing it.
		self::mark( $uid, $c, $l->ID, 100 );
		Forms::back( self::maybe_complete( $uid, $c ) ? 'certified' : 'lesson_ok' );
	}

	public static function quiz_post() {
		self::nonce( 'quiz' );
		$uid = get_current_user_id();
		$r   = self::lesson_from_post( $uid );
		if ( ! $r ) { Forms::back( 'denied' ); }
		[ $l, $c ] = $r;
		if ( ! Module::rate( 'quiz_' . $l->ID, 10 ) ) { Forms::back( 'limit' ); }
		$qs = self::quiz( $l->ID );
		if ( ! $qs ) { Forms::back( 'denied' ); }
		$ok = 0;
		foreach ( $qs as $i => $q ) {
			$a = isset( $_POST[ 'q' . $i ] ) ? (int) $_POST[ 'q' . $i ] : -1; // phpcs:ignore WordPress.Security.NonceVerification
			if ( $a === $q['answer'] ) { $ok++; }
		}
		$score = (int) round( $ok * 100 / count( $qs ) );
		$pass  = (int) Module::meta( $l->ID, 'pass', 70 );
		Store::log( Module::LESSON, $l->ID, 'quiz', sprintf( 'Evaluación del usuario #%d: %d%%', $uid, $score ), 'audit' );
		if ( $score < $pass ) {
			$p = self::progress( $uid, $c );
			$p[ $l->ID ] = [ 'done' => 0, 'score' => $score, 'tries' => (int) ( $p[ $l->ID ]['tries'] ?? 0 ) + 1 ];
			update_user_meta( $uid, self::PROG . $c, $p );
			Forms::back( 'quiz_ko' );
		}
		self::mark( $uid, $c, $l->ID, $score );
		$back = isset( $_POST['_back'] ) ? remove_query_arg( 'leccion', esc_url_raw( wp_unslash( $_POST['_back'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		Forms::back( self::maybe_complete( $uid, $c ) ? 'certified' : 'quiz_ok', [], $back );
	}

	private static function mark( $uid, $c, $lesson, $score ) {
		$p = self::progress( $uid, $c );
		$p[ $lesson ] = [ 'done' => time(), 'score' => (int) $score, 'tries' => (int) ( $p[ $lesson ]['tries'] ?? 0 ) + 1 ];
		update_user_meta( $uid, self::PROG . $c, $p );
	}

	/** All lessons done: completion record + certificate (once). Returns true when it just completed. */
	public static function maybe_complete( $uid, $c ) {
		if ( self::percent( $uid, $c ) < 100 ) { return false; }
		$all = self::enrolment( $uid );
		if ( ( $all[ $c ]['status'] ?? '' ) === 'completed' ) { return false; }
		$all[ $c ]['status']   = 'completed';
		$all[ $c ]['finished'] = time();
		update_user_meta( $uid, self::ENROL, $all );
		if ( 'no' !== Module::meta( $c, 'certify', 'yes' ) ) { self::issue( $uid, $c ); }
		Store::log( Module::COURSE, $c, 'complete', 'Curso completado por el usuario #' . $uid, 'audit' );
		return true;
	}

	public static function issue( $uid, $c ) {
		$u    = get_userdata( $uid );
		$code = strtoupper( wp_generate_password( 4, false ) . '-' . wp_generate_password( 4, false ) . '-' . wp_generate_password( 4, false ) );
		$pid  = wp_insert_post( [ 'post_type' => Module::CERT, 'post_status' => 'private', 'post_title' => $u->display_name . ' · ' . get_the_title( $c ), 'post_author' => $uid ] );
		if ( ! $pid || is_wp_error( $pid ) ) { return ''; }
		foreach ( [ 'code' => $code, 'user' => $uid, 'course' => $c, 'name' => $u->display_name, 'course_title' => get_the_title( $c ), 'hours' => Module::meta( $c, 'hours' ), 'date' => gmdate( 'Y-m-d' ) ] as $k => $v ) {
			update_post_meta( $pid, Module::PRE . $k, $v );
		}
		return $code;
	}

	public static function cert_by_code( $code ) {
		$code = strtoupper( preg_replace( '/[^A-Za-z0-9\-]/', '', (string) $code ) );
		if ( strlen( $code ) < 8 ) { return null; }
		$q = get_posts( [ 'post_type' => Module::CERT, 'post_status' => [ 'private', 'publish' ], 'numberposts' => 1, 'meta_key' => Module::PRE . 'code', 'meta_value' => $code ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
		return $q ? $q[0] : null;
	}

	public static function certs_of( $uid ) {
		return get_posts( [ 'post_type' => Module::CERT, 'post_status' => [ 'private', 'publish' ], 'numberposts' => 100, 'author' => (int) $uid ] );
	}

	/** Printable certificate for its owner or staff: ?wkt_cert=CODE. */
	public static function print_cert() {
		if ( empty( $_GET['wkt_cert'] ) ) { return; } // phpcs:ignore WordPress.Security.NonceVerification
		$c = self::cert_by_code( sanitize_text_field( wp_unslash( $_GET['wkt_cert'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! $c || ! is_user_logged_in() || ( (int) $c->post_author !== get_current_user_id() && ! current_user_can( 'edit_others_wk_certs' ) ) ) {
			wp_die( esc_html__( 'Certificado no disponible.', 'wakoo' ), '', [ 'response' => 403 ] );
		}
		$m      = function ( $k ) use ( $c ) { return (string) Module::meta( $c->ID, $k ); };
		$issuer = Module::settings()['issuer'] ?: get_bloginfo( 'name' );
		$verify = Module::page_url( 'verify', [ 'codigo' => $m( 'code' ) ] );
		nocache_headers();
		?><!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex">
		<title><?php echo esc_html( $m( 'course_title' ) ); ?></title>
		<style>
		@page{size:A4 landscape;margin:0}body{margin:0;font-family:Inter,"Source Sans 3",Arial,sans-serif;color:#10355B;background:#F4F6F8}
		.c{box-sizing:border-box;width:297mm;height:210mm;margin:0 auto;background:#fff;padding:22mm 26mm;border:10px solid #10355B;outline:2px solid #C5A15B;outline-offset:-22px;display:flex;flex-direction:column;justify-content:space-between}
		.k{letter-spacing:.18em;text-transform:uppercase;font-size:12px;color:#465363}h1{font-size:40px;margin:8mm 0 2mm}h2{font-size:26px;margin:2mm 0;color:#174A7E}
		.n{font-size:34px;font-weight:700;border-bottom:2px solid #C5A15B;display:inline-block;padding-bottom:2mm}.f{display:flex;justify-content:space-between;font-size:12px;color:#465363}
		.p{position:fixed;top:12px;right:12px}@media print{.p{display:none}body{background:#fff}}
		</style></head><body>
		<button class="p" onclick="window.print()"><?php esc_html_e( 'Imprimir o guardar en PDF', 'wakoo' ); ?></button>
		<div class="c"><div><div class="k"><?php echo esc_html( $issuer ); ?></div><h1><?php esc_html_e( 'Certificado de finalización', 'wakoo' ); ?></h1>
		<p><?php esc_html_e( 'Se certifica que', 'wakoo' ); ?></p><div class="n"><?php echo esc_html( $m( 'name' ) ); ?></div>
		<p><?php esc_html_e( 'completó el curso', 'wakoo' ); ?></p><h2><?php echo esc_html( $m( 'course_title' ) ); ?></h2>
		<?php if ( $m( 'hours' ) ) { echo '<p>' . esc_html( sprintf( __( 'Duración: %s horas', 'wakoo' ), $m( 'hours' ) ) ) . '</p>'; } ?></div>
		<div class="f"><span><?php echo esc_html( sprintf( __( 'Fecha: %s', 'wakoo' ), date_i18n( 'j \d\e F \d\e Y', strtotime( $m( 'date' ) ) ) ) ); ?></span>
		<span><?php echo esc_html( sprintf( __( 'Código de verificación: %s', 'wakoo' ), $m( 'code' ) ) ); ?><?php echo $verify ? '<br>' . esc_html( $verify ) : ''; ?></span></div></div>
		</body></html>
		<?php
		exit;
	}
}
