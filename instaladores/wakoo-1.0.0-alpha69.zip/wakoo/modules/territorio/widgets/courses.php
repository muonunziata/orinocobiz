<?php
/**
 * «Cursos de la academia (Wakoo)»: course catalogue, optionally grouped by school.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class W_Courses extends Base {

	public function get_name() { return 'wakoo-t-courses'; }
	public function get_title() { return __( 'Cursos de la academia (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-library-open'; }
	public function get_keywords() { return [ 'academia', 'cursos', 'formación', 'escuelas', 'lms', 'wakoo' ]; }

	protected function controls() {
		$this->start_controls_section( 'sec_main', [ 'label' => __( 'Cursos', 'wakoo' ) ] );
		$this->add_control( 'school', [ 'label' => __( 'Solo la escuela (slug, opcional)', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$this->add_control( 'group', [ 'label' => __( 'Agrupar por escuela', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'demo', [ 'label' => __( 'Incluir cursos de demostración', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'cols', [ 'label' => __( 'Columnas', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => '3', 'options' => [ '1' => '1', '2' => '2', '3' => '3', '4' => '4' ], 'selectors' => [ '{{WRAPPER}} .wkt-grid' => '--cols: {{VALUE}};' ] ] );
		$this->end_controls_section();
	}

	protected function texts() {
		return [
			'empty'  => [ __( 'Sin cursos', 'wakoo' ), __( 'La oferta de cursos de esta escuela está en diseño.', 'wakoo' ) ],
			'open'   => [ __( 'Estado: abierto', 'wakoo' ), __( 'Inscripción abierta', 'wakoo' ) ],
			'design' => [ __( 'Estado: en diseño', 'wakoo' ), __( 'En diseño · registre su interés', 'wakoo' ) ],
			'closed' => [ __( 'Estado: cerrado', 'wakoo' ), __( 'Cerrado', 'wakoo' ) ],
			'demo'   => [ __( 'Etiqueta: demostración', 'wakoo' ), __( 'Curso de demostración', 'wakoo' ) ],
			'hours'  => [ __( 'Horas (%s)', 'wakoo' ), __( '%s horas', 'wakoo' ) ],
			'free'   => [ __( 'Gratuito', 'wakoo' ), __( 'Gratuito', 'wakoo' ) ],
			'more'   => [ __( 'Enlace', 'wakoo' ), __( 'Ver el curso', 'wakoo' ) ],
		];
	}

	private function card( $c ) {
		$st   = Academy::status( $c->ID );
		$mode = [ 'virtual' => __( 'Virtual', 'wakoo' ), 'mixta' => __( 'Mixta', 'wakoo' ), 'presencial' => __( 'Presencial', 'wakoo' ) ][ Module::meta( $c->ID, 'mode' ) ] ?? '';
		$h    = Module::meta( $c->ID, 'hours' );
		echo '<article class="wkt-card wkt-course-card">';
		echo '<p class="wkt-badges">' . $this->badge( $this->t( $st ), 'open' === $st ? 'ok' : ( 'design' === $st ? 'info' : 'soft' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		if ( 'yes' === Module::meta( $c->ID, 'demo' ) ) { echo ' ' . $this->badge( $this->t( 'demo' ), 'warn' ); } // phpcs:ignore WordPress.Security.EscapeOutput
		echo '</p><h3 class="wkt-card__t"><a href="' . esc_url( get_permalink( $c ) ) . '">' . esc_html( $c->post_title ) . '</a></h3>';
		if ( $c->post_excerpt ) { echo '<p class="wkt-muted">' . esc_html( $c->post_excerpt ) . '</p>'; }
		echo '<p class="wkt-small wkt-muted">' . esc_html( implode( ' · ', array_filter( [ $h ? sprintf( $this->t( 'hours' ), $h ) : '', $mode, Module::meta( $c->ID, 'cost' ) ?: $this->t( 'free' ) ] ) ) ) . '</p>';
		echo '<a class="wkt-more-link" href="' . esc_url( get_permalink( $c ) ) . '" aria-label="' . esc_attr( $this->t( 'more' ) . ': ' . $c->post_title ) . '">' . esc_html( $this->t( 'more' ) ) . ' <span aria-hidden="true">→</span></a></article>';
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$args = [ 'post_type' => Module::COURSE, 'post_status' => 'publish', 'numberposts' => 200, 'orderby' => [ 'menu_order' => 'ASC', 'title' => 'ASC' ] ];
		if ( ! empty( $s['school'] ) ) { $args['tax_query'] = [ [ 'taxonomy' => Module::T_SCHOOL, 'field' => 'slug', 'terms' => sanitize_title( $s['school'] ) ] ]; } // phpcs:ignore WordPress.DB.SlowDBQuery
		$list = get_posts( $args );
		if ( 'yes' !== ( $s['demo'] ?? '' ) ) { $list = array_filter( $list, function ( $c ) { return 'yes' !== Module::meta( $c->ID, 'demo' ); } ); }
		echo '<div class="wkt wkt-courses">';
		if ( ! $list ) { echo '<div class="wkt-empty">' . esc_html( $this->t( 'empty' ) ) . '</div></div>'; return; }
		if ( 'yes' === ( $s['group'] ?? '' ) && empty( $s['school'] ) ) {
			$groups = [];
			foreach ( $list as $c ) {
				$t = Module::terms( $c->ID, Module::T_SCHOOL );
				$groups[ $t ? $t[0]->term_id : 0 ][] = $c;
			}
			$order = array_keys( $this->term_options( Module::T_SCHOOL ) );
			foreach ( array_merge( $order, [ 0 ] ) as $tid ) {
				if ( '' === $tid || empty( $groups[ $tid ] ) ) { continue; }
				$term = $tid ? get_term( $tid ) : null;
				echo '<section class="wkt-school"><h3 class="wkt-h">' . esc_html( $term ? $term->name : '—' ) . '</h3>';
				if ( $term && $term->description ) { echo '<p class="wkt-muted">' . esc_html( $term->description ) . '</p>'; }
				echo '<div class="wkt-grid">';
				foreach ( $groups[ $tid ] as $c ) { $this->card( $c ); }
				echo '</div></section>';
			}
		} else {
			echo '<div class="wkt-grid">';
			foreach ( $list as $c ) { $this->card( $c ); }
			echo '</div>';
		}
		echo '</div>';
	}
}
