<?php
/**
 * «Acceso al portal»: sign in, create an account (with data-processing consent) or, when
 * signed in, links to the private panels.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class W_Access extends Base {

	public function get_name() { return 'wakoo-t-access'; }
	public function get_title() { return __( 'Acceso al portal (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-lock-user'; }
	public function get_keywords() { return [ 'login', 'registro', 'cuenta', 'acceso', 'portal', 'wakoo' ]; }

	protected function controls() {
		$this->start_controls_section( 'sec_main', [ 'label' => __( 'Acceso', 'wakoo' ) ] );
		$this->add_control( 'privacy', [ 'label' => __( 'Enlace a la política de privacidad', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$this->end_controls_section();
	}

	protected function texts() {
		return [
			'login_title' => [ __( 'Título: iniciar sesión', 'wakoo' ), __( 'Iniciar sesión', 'wakoo' ) ],
			'reg_title'   => [ __( 'Título: crear cuenta', 'wakoo' ), __( 'Crear una cuenta', 'wakoo' ) ],
			'reg_intro'   => [ __( 'Texto: crear cuenta', 'wakoo' ), __( 'Una sola cuenta sirve para la ventanilla del inversionista, el directorio empresarial y la academia.', 'wakoo' ) ],
			'name'        => [ __( 'Campo: nombre', 'wakoo' ), __( 'Nombre y apellido', 'wakoo' ) ],
			'email'       => [ __( 'Campo: correo', 'wakoo' ), __( 'Correo electrónico', 'wakoo' ) ],
			'pass'        => [ __( 'Campo: contraseña', 'wakoo' ), __( 'Contraseña (mínimo 10 caracteres)', 'wakoo' ) ],
			'consent'     => [ __( 'Consentimiento', 'wakoo' ), __( 'Acepto el tratamiento de mis datos para gestionar mi cuenta y mis solicitudes, según la política de privacidad.', 'wakoo' ) ],
			'reg_btn'     => [ __( 'Botón: crear cuenta', 'wakoo' ), __( 'Crear cuenta', 'wakoo' ) ],
			'lost'        => [ __( 'Enlace: contraseña olvidada', 'wakoo' ), __( '¿Olvidó su contraseña?', 'wakoo' ) ],
			'hello'       => [ __( 'Saludo (%s = nombre)', 'wakoo' ), __( 'Hola, %s', 'wakoo' ) ],
			'p_cases'     => [ __( 'Enlace: mis solicitudes', 'wakoo' ), __( 'Mis solicitudes en la ventanilla', 'wakoo' ) ],
			'p_company'   => [ __( 'Enlace: mi empresa', 'wakoo' ), __( 'Mi empresa en el directorio', 'wakoo' ) ],
			'p_student'   => [ __( 'Enlace: mi aprendizaje', 'wakoo' ), __( 'Mis cursos en la academia', 'wakoo' ) ],
			'logout'      => [ __( 'Enlace: cerrar sesión', 'wakoo' ), __( 'Cerrar sesión', 'wakoo' ) ],
			'reg_off'     => [ __( 'Registro desactivado', 'wakoo' ), __( 'El registro de nuevas cuentas está cerrado en este momento.', 'wakoo' ) ],
		];
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$back = $this->get( 'volver' );
		$back = $back ? wp_validate_redirect( esc_url_raw( rawurldecode( $back ) ), '' ) : '';
		echo '<div class="wkt wkt-access">';
		$this->notice();
		if ( is_user_logged_in() && ! $this->in_editor() ) {
			$u = wp_get_current_user();
			echo '<div class="wkt-card"><h2 class="wkt-h">' . esc_html( sprintf( $this->t( 'hello' ), $u->display_name ) ) . '</h2><ul class="wkt-links">';
			foreach ( [ 'cases' => 'p_cases', 'company' => 'p_company', 'student' => 'p_student' ] as $p => $l ) {
				$url = Module::page_url( $p );
				if ( $url ) { echo '<li><a href="' . esc_url( $url ) . '">' . esc_html( $this->t( $l ) ) . '</a></li>'; }
			}
			echo '<li><a href="' . esc_url( wp_logout_url( home_url( '/' ) ) ) . '">' . esc_html( $this->t( 'logout' ) ) . '</a></li></ul>';
			if ( $back ) { echo '<p><a class="wkt-btn" href="' . esc_url( $back ) . '">' . esc_html__( 'Continuar', 'wakoo' ) . '</a></p>'; }
			echo '</div></div>';
			return;
		}
		echo '<div class="wkt-cols"><div class="wkt-card"><h2 class="wkt-h">' . esc_html( $this->t( 'login_title' ) ) . '</h2>';
		wp_login_form( [ 'redirect' => $back ?: ( Module::page_url( 'cases' ) ?: home_url( '/' ) ), 'label_username' => $this->t( 'email' ), 'form_id' => 'wkt-login-' . $this->get_id(), 'id_username' => 'wkt-u-' . $this->get_id(), 'id_password' => 'wkt-p-' . $this->get_id(), 'id_remember' => 'wkt-r-' . $this->get_id(), 'id_submit' => 'wkt-s-' . $this->get_id() ] );
		echo '<p><a href="' . esc_url( wp_lostpassword_url() ) . '">' . esc_html( $this->t( 'lost' ) ) . '</a></p></div>';
		echo '<div class="wkt-card"><h2 class="wkt-h">' . esc_html( $this->t( 'reg_title' ) ) . '</h2>';
		if ( empty( Module::settings()['register'] ) ) {
			echo '<p>' . esc_html( $this->t( 'reg_off' ) ) . '</p></div></div></div>';
			return;
		}
		echo '<p>' . esc_html( $this->t( 'reg_intro' ) ) . '</p>';
		$old = Forms::old( 'register' );
		$this->form_open( 'register' );
		$this->field( 'name', $this->t( 'name' ), 'text', [ 'required' => true, 'value' => $old['name'] ?? '', 'attr' => 'autocomplete="name" maxlength="100"' ] );
		$this->field( 'email', $this->t( 'email' ), 'email', [ 'required' => true, 'value' => $old['email'] ?? '', 'attr' => 'autocomplete="email"' ] );
		$this->field( 'pass', $this->t( 'pass' ), 'password', [ 'required' => true, 'attr' => 'autocomplete="new-password" minlength="10"' ] );
		$priv = ! empty( $s['privacy']['url'] ) ? ' <a href="' . esc_url( $s['privacy']['url'] ) . '" target="_blank">↗</a>' : '';
		$this->check( 'consent', esc_html( $this->t( 'consent' ) ) . $priv, false, true );
		echo '<button type="submit" class="wkt-btn">' . esc_html( $this->t( 'reg_btn' ) ) . '</button></form></div></div></div>';
	}
}
