<?php
/**
 * «Curso (Wakoo)»: course sheet and player. Public: description, facts, lesson titles.
 * Enrolled students: lessons (video, text, materials), quizzes, progress and certificate.
 * Courses «en diseño» only take an interest registration.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class W_Course extends Base {

	public function get_name() { return 'wakoo-t-course'; }
	public function get_title() { return __( 'Curso (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-video-playlist'; }
	public function get_keywords() { return [ 'curso', 'lecciones', 'academia', 'lms', 'evaluación', 'certificado', 'wakoo' ]; }

	protected function controls() {
		$this->start_controls_section( 'sec_main', [ 'label' => __( 'Curso', 'wakoo' ) ] );
		$this->add_control( 'course', [ 'label' => __( 'Curso (ID; vacío = el que se está viendo)', 'wakoo' ), 'type' => Controls_Manager::NUMBER ] );
		$this->end_controls_section();
	}

	protected function texts() {
		return [
			'none'     => [ __( 'Sin curso', 'wakoo' ), __( 'Este curso no está disponible.', 'wakoo' ) ],
			'demo'     => [ __( 'Aviso de demostración', 'wakoo' ), __( 'Curso de demostración: muestra cómo funciona la academia. Sus contenidos son de ejemplo y no tienen valor académico.', 'wakoo' ) ],
			'hours'    => [ __( 'Duración', 'wakoo' ), __( 'Duración', 'wakoo' ) ],
			'h'        => [ __( 'Horas (%s)', 'wakoo' ), __( '%s horas', 'wakoo' ) ],
			'mode'     => [ __( 'Modalidad', 'wakoo' ), __( 'Modalidad', 'wakoo' ) ],
			'level'    => [ __( 'Nivel', 'wakoo' ), __( 'Nivel', 'wakoo' ) ],
			'cost'     => [ __( 'Costo', 'wakoo' ), __( 'Costo', 'wakoo' ) ],
			'free'     => [ __( 'Gratuito', 'wakoo' ), __( 'Gratuito', 'wakoo' ) ],
			'cert'     => [ __( 'Certificación', 'wakoo' ), __( 'Certificación', 'wakoo' ) ],
			'cert_yes' => [ __( 'Con certificado', 'wakoo' ), __( 'Certificado verificable al completar', 'wakoo' ) ],
			'cert_no'  => [ __( 'Sin certificado', 'wakoo' ), __( 'Sin certificado', 'wakoo' ) ],
			'lessons'  => [ __( 'Título: lecciones', 'wakoo' ), __( 'Contenido del curso', 'wakoo' ) ],
			'nolesson' => [ __( 'Sin lecciones', 'wakoo' ), __( 'Las lecciones se publicarán cuando el curso abra la inscripción.', 'wakoo' ) ],
			'enroll'   => [ __( 'Botón: inscribirse', 'wakoo' ), __( 'Inscribirme en el curso', 'wakoo' ) ],
			'interest' => [ __( 'Botón: interés', 'wakoo' ), __( 'Avisarme cuando abra la inscripción', 'wakoo' ) ],
			'design'   => [ __( 'Texto: en diseño', 'wakoo' ), __( 'Este curso está en diseño. Registre su interés y le avisaremos cuando abra la inscripción.', 'wakoo' ) ],
			'closed'   => [ __( 'Texto: cerrado', 'wakoo' ), __( 'La inscripción de este curso está cerrada.', 'wakoo' ) ],
			'consent'  => [ __( 'Consentimiento', 'wakoo' ), __( 'Acepto que el portal guarde mi inscripción y mi progreso para gestionar el curso y emitir el certificado.', 'wakoo' ) ],
			'login'    => [ __( 'Sin sesión', 'wakoo' ), __( 'Inicie sesión o cree una cuenta gratuita para inscribirse.', 'wakoo' ) ],
			'progress' => [ __( 'Progreso (%d)', 'wakoo' ), __( 'Progreso: %d %%', 'wakoo' ) ],
			'noted'    => [ __( 'Interés registrado', 'wakoo' ), __( 'Su interés está registrado. Le avisaremos cuando abra la inscripción.', 'wakoo' ) ],
			'start'    => [ __( 'Botón: empezar', 'wakoo' ), __( 'Ir a la lección', 'wakoo' ) ],
			'done'     => [ __( 'Lección hecha', 'wakoo' ), __( 'Completada', 'wakoo' ) ],
			'back'     => [ __( 'Volver al índice', 'wakoo' ), __( 'Volver al contenido del curso', 'wakoo' ) ],
			'material' => [ __( 'Materiales', 'wakoo' ), __( 'Materiales', 'wakoo' ) ],
			'quiz'     => [ __( 'Título: evaluación', 'wakoo' ), __( 'Evaluación de la lección', 'wakoo' ) ],
			'pass'     => [ __( 'Nota mínima (%d)', 'wakoo' ), __( 'Nota mínima para aprobar: %d %%', 'wakoo' ) ],
			'send'     => [ __( 'Botón: enviar evaluación', 'wakoo' ), __( 'Enviar respuestas', 'wakoo' ) ],
			'mark'     => [ __( 'Botón: completar', 'wakoo' ), __( 'Marcar como completada', 'wakoo' ) ],
			'finished' => [ __( 'Curso completado', 'wakoo' ), __( 'Completó este curso.', 'wakoo' ) ],
			'see_cert' => [ __( 'Ver certificado', 'wakoo' ), __( 'Ver o imprimir el certificado', 'wakoo' ) ],
			'moodle'   => [ __( 'Enlace a Moodle', 'wakoo' ), __( 'Este curso se imparte en el aula virtual Moodle', 'wakoo' ) ],
		];
	}

	private function video( $url ) {
		if ( ! $url ) { return; }
		if ( preg_match( '/\.(mp4|webm)(\?|$)/i', $url ) ) {
			echo '<div class="wkt-video"><video controls preload="metadata" src="' . esc_url( $url ) . '"></video></div>';
			return;
		}
		$html = wp_oembed_get( $url );
		if ( $html ) { echo '<div class="wkt-video">' . $html . '</div>'; } // phpcs:ignore WordPress.Security.EscapeOutput
	}

	private function lesson( $c, $l, $prog ) {
		echo '<article class="wkt-lesson"><p><a href="' . esc_url( remove_query_arg( 'leccion', $this->here() ) ) . '">← ' . esc_html( $this->t( 'back' ) ) . '</a></p>';
		echo '<h3 class="wkt-h">' . esc_html( $l->post_title ) . ( ! empty( $prog[ $l->ID ]['done'] ) ? ' ' . $this->badge( $this->t( 'done' ), 'ok' ) : '' ) . '</h3>'; // phpcs:ignore WordPress.Security.EscapeOutput
		$this->video( (string) Module::meta( $l->ID, 'video' ) );
		echo '<div class="wkt-prose">' . wp_kses_post( wpautop( $l->post_content ) ) . '</div>';
		$mat = $this->link_lines( Module::meta( $l->ID, 'material' ) );
		if ( $mat ) {
			echo '<h4>' . esc_html( $this->t( 'material' ) ) . '</h4><ul class="wkt-links">';
			foreach ( $mat as $m ) { echo '<li>' . ( $m[1] ? '<a href="' . esc_url( $m[1] ) . '">' . esc_html( $m[0] ) . '</a>' : esc_html( $m[0] ) ) . '</li>'; }
			echo '</ul>';
		}
		$quiz = Academy::quiz( $l->ID );
		if ( $quiz ) {
			echo '<section class="wkt-card wkt-quiz"><h4>' . esc_html( $this->t( 'quiz' ) ) . '</h4><p class="wkt-small wkt-muted">' . esc_html( sprintf( $this->t( 'pass' ), (int) Module::meta( $l->ID, 'pass', 70 ) ) ) . '</p>';
			$this->form_open( 'quiz' );
			echo '<input type="hidden" name="lesson" value="' . (int) $l->ID . '">';
			foreach ( $quiz as $i => $q ) {
				echo '<fieldset class="wkt-fieldset"><legend>' . esc_html( ( $i + 1 ) . '. ' . $q['q'] ) . '</legend>';
				foreach ( $q['options'] as $k => $o ) { echo '<label class="wkt-check"><input type="radio" name="q' . (int) $i . '" value="' . (int) $k . '" required> <span>' . esc_html( $o ) . '</span></label>'; }
				echo '</fieldset>';
			}
			echo '<button class="wkt-btn" type="submit">' . esc_html( $this->t( 'send' ) ) . '</button></form></section>';
		} elseif ( empty( $prog[ $l->ID ]['done'] ) ) {
			$this->form_open( 'lesson_done', false, '', remove_query_arg( 'leccion', $this->here() ) );
			echo '<input type="hidden" name="lesson" value="' . (int) $l->ID . '"><button class="wkt-btn" type="submit">' . esc_html( $this->t( 'mark' ) ) . '</button></form>';
		}
		echo '</article>';
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$c = $this->current( Module::COURSE, $s['course'] ?? 0 );
		echo '<div class="wkt wkt-course">';
		if ( ! $c ) { echo '<div class="wkt-empty">' . esc_html( $this->t( 'none' ) ) . '</div></div>'; return; }
		$this->notice();
		$st   = Academy::status( $c->ID );
		$uid  = get_current_user_id();
		$enr  = $uid ? Academy::enrolment( $uid, $c->ID ) : null;
		$in   = $enr && in_array( $enr['status'], [ 'enrolled', 'completed' ], true );
		$prog = $in ? Academy::progress( $uid, $c->ID ) : [];
		$ls   = Academy::lessons( $c->ID );
		if ( 'yes' === Module::meta( $c->ID, 'demo' ) ) { echo '<p class="wkt-callout" role="note">' . esc_html( $this->t( 'demo' ) ) . '</p>'; }

		$lid = (int) $this->get( 'leccion' );
		if ( $in && $lid ) {
			foreach ( $ls as $l ) { if ( $l->ID === $lid ) { $this->lesson( $c, $l, $prog ); echo '</div>'; return; } }
		}

		$mode = [ 'virtual' => __( 'Virtual', 'wakoo' ), 'mixta' => __( 'Mixta', 'wakoo' ), 'presencial' => __( 'Presencial', 'wakoo' ) ][ Module::meta( $c->ID, 'mode' ) ] ?? '';
		echo '<div class="wkt-sheet__body"><div class="wkt-sheet__main">';
		if ( $c->post_content ) { echo '<div class="wkt-prose">' . wp_kses_post( wpautop( $c->post_content ) ) . '</div>'; }
		echo '<h3 class="wkt-h">' . esc_html( $this->t( 'lessons' ) ) . '</h3>';
		if ( ! $ls ) {
			echo '<p class="wkt-muted">' . esc_html( $this->t( 'nolesson' ) ) . '</p>';
		} else {
			echo '<ol class="wkt-lessons">';
			foreach ( $ls as $l ) {
				$done = ! empty( $prog[ $l->ID ]['done'] );
				echo '<li class="' . ( $done ? 'is-done' : '' ) . '"><span>' . esc_html( $l->post_title ) . '</span>';
				if ( $in ) { echo $done ? ' ' . $this->badge( $this->t( 'done' ), 'ok' ) : ' <a href="' . esc_url( add_query_arg( 'leccion', $l->ID, $this->here() ) ) . '">' . esc_html( $this->t( 'start' ) ) . '</a>'; } // phpcs:ignore WordPress.Security.EscapeOutput
				echo '</li>';
			}
			echo '</ol>';
		}
		echo '</div><aside class="wkt-sheet__side"><div class="wkt-card"><dl class="wkt-dl">';
		$facts = [
			'hours' => Module::meta( $c->ID, 'hours' ) ? sprintf( $this->t( 'h' ), Module::meta( $c->ID, 'hours' ) ) : '',
			'mode'  => $mode,
			'level' => (string) Module::meta( $c->ID, 'level' ),
			'cost'  => Module::meta( $c->ID, 'cost' ) ?: $this->t( 'free' ),
			'cert'  => 'no' === Module::meta( $c->ID, 'certify', 'yes' ) ? $this->t( 'cert_no' ) : $this->t( 'cert_yes' ),
		];
		foreach ( $facts as $k => $v ) { if ( '' !== $v ) { echo '<div><dt>' . esc_html( $this->t( $k ) ) . '</dt><dd>' . esc_html( $v ) . '</dd></div>'; } }
		echo '</dl>';
		if ( Module::meta( $c->ID, 'criteria' ) ) { echo '<p class="wkt-small wkt-muted">' . esc_html( Module::meta( $c->ID, 'criteria' ) ) . '</p>'; }

		$moodle = (string) Module::meta( $c->ID, 'moodle' );
		if ( $moodle ) { echo '<p><a class="wkt-btn wkt-btn--ghost" href="' . esc_url( $moodle ) . '" rel="noopener">' . esc_html( $this->t( 'moodle' ) ) . '</a></p>'; }

		if ( $in ) {
			$pc = Academy::percent( $uid, $c->ID );
			echo '<p class="wkt-small">' . esc_html( sprintf( $this->t( 'progress' ), $pc ) ) . '</p><div class="wkt-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' . (int) $pc . '"><i style="--w:' . (int) $pc . '%"></i></div>';
			if ( 'completed' === $enr['status'] ) {
				echo '<p>' . esc_html( $this->t( 'finished' ) ) . '</p>';
				foreach ( Academy::certs_of( $uid ) as $ct ) {
					if ( (int) Module::meta( $ct->ID, 'course' ) === $c->ID ) { echo '<p><a class="wkt-btn" href="' . esc_url( add_query_arg( 'wkt_cert', Module::meta( $ct->ID, 'code' ), home_url( '/' ) ) ) . '" target="_blank" rel="noopener">' . esc_html( $this->t( 'see_cert' ) ) . '</a></p>'; break; }
				}
			}
		} elseif ( 'closed' === $st ) {
			echo '<p class="wkt-muted">' . esc_html( $this->t( 'closed' ) ) . '</p>';
		} elseif ( $enr && 'interest' === $enr['status'] && 'design' === $st ) {
			echo '<p>' . esc_html( $this->t( 'noted' ) ) . '</p>';
		} elseif ( ! $uid ) {
			if ( 'design' === $st ) { echo '<p class="wkt-small">' . esc_html( $this->t( 'design' ) ) . '</p>'; }
			$this->login_box( $this->t( 'login' ) );
		} else {
			if ( 'design' === $st ) { echo '<p class="wkt-small">' . esc_html( $this->t( 'design' ) ) . '</p>'; }
			$this->form_open( 'enroll' );
			echo '<input type="hidden" name="course" value="' . (int) $c->ID . '">';
			$this->check( 'consent', esc_html( $this->t( 'consent' ) ), false, true );
			echo '<button class="wkt-btn" type="submit">' . esc_html( $this->t( 'open' === $st ? 'enroll' : 'interest' ) ) . '</button></form>';
		}
		echo '</div></aside></div></div>';
	}
}
