<?php
/**
 * «Necesidades de compra»: open purchase needs published by registered companies, with an
 * offer form for signed-in companies. The portal connects; it never awards.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

defined( 'ABSPATH' ) || die();

class W_Needs extends Base {

	public function get_name() { return 'wakoo-t-needs'; }
	public function get_title() { return __( 'Necesidades de compra (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-cart-medium'; }
	public function get_keywords() { return [ 'compras', 'necesidades', 'proveedores', 'ofertas', 'marketplace', 'wakoo' ]; }

	protected function texts() {
		return [
			'empty'   => [ __( 'Sin necesidades', 'wakoo' ), __( 'No hay necesidades de compra abiertas en este momento. Las empresas registradas pueden publicarlas desde su panel.', 'wakoo' ) ],
			'by'      => [ __( 'Publicada por', 'wakoo' ), __( 'Publicada por', 'wakoo' ) ],
			'qty'     => [ __( 'Cantidad', 'wakoo' ), __( 'Cantidad o alcance', 'wakoo' ) ],
			'until'   => [ __( 'Fecha límite', 'wakoo' ), __( 'Recibe ofertas hasta', 'wakoo' ) ],
			'offer'   => [ __( 'Título: ofertar', 'wakoo' ), __( 'Enviar una oferta', 'wakoo' ) ],
			'subject' => [ __( 'Campo: asunto', 'wakoo' ), __( 'Asunto', 'wakoo' ) ],
			'message' => [ __( 'Campo: mensaje', 'wakoo' ), __( 'Su propuesta (alcance, plazos, condiciones)', 'wakoo' ) ],
			'send'    => [ __( 'Botón: enviar', 'wakoo' ), __( 'Enviar oferta', 'wakoo' ) ],
			'login'   => [ __( 'Sin sesión', 'wakoo' ), __( 'Inicie sesión con la cuenta de su empresa para enviar ofertas.', 'wakoo' ) ],
			'note'    => [ __( 'Aviso', 'wakoo' ), __( 'Las ofertas llegan al panel de la empresa compradora. La selección y la contratación son decisiones de cada empresa.', 'wakoo' ) ],
		];
	}

	protected function render() {
		$today = current_time( 'Y-m-d' );
		$list  = array_filter( get_posts( [ 'post_type' => Module::NEED, 'post_status' => 'publish', 'numberposts' => 100 ] ), function ( $n ) use ( $today ) {
			$dl = (string) Module::meta( $n->ID, 'deadline' );
			return 'yes' !== Module::meta( $n->ID, 'closed' ) && ( '' === $dl || $dl >= $today );
		} );
		echo '<div class="wkt wkt-needs">';
		$this->notice();
		if ( ! $list ) { echo '<div class="wkt-empty">' . esc_html( $this->t( 'empty' ) ) . '</div></div>'; return; }
		foreach ( $list as $n ) {
			$co = (int) Module::meta( $n->ID, 'company' );
			echo '<details class="wkt-card wkt-need"><summary><span class="wkt-need__t">' . esc_html( $n->post_title ) . '</span><span class="wkt-muted wkt-small">' . esc_html( implode( ' · ', array_filter( [ Module::term_names( $n->ID, Module::T_SECTOR ), Module::term_names( $n->ID, Module::T_MUN ) ] ) ) ) . '</span></summary>';
			echo '<div class="wkt-prose">' . wp_kses_post( wpautop( esc_html( $n->post_content ) ) ) . '</div><dl class="wkt-dl">';
			if ( $co ) { echo '<div><dt>' . esc_html( $this->t( 'by' ) ) . '</dt><dd><a href="' . esc_url( get_permalink( $co ) ) . '">' . esc_html( get_the_title( $co ) ) . '</a></dd></div>'; }
			if ( Module::meta( $n->ID, 'qty' ) ) { echo '<div><dt>' . esc_html( $this->t( 'qty' ) ) . '</dt><dd>' . esc_html( Module::meta( $n->ID, 'qty' ) ) . '</dd></div>'; }
			if ( Module::meta( $n->ID, 'deadline' ) ) { echo '<div><dt>' . esc_html( $this->t( 'until' ) ) . '</dt><dd>' . esc_html( date_i18n( 'd/m/Y', strtotime( Module::meta( $n->ID, 'deadline' ) ) ) ) . '</dd></div>'; }
			echo '</dl><h3 class="wkt-h">' . esc_html( $this->t( 'offer' ) ) . '</h3>';
			if ( ! is_user_logged_in() ) {
				$this->login_box( $this->t( 'login' ) );
			} elseif ( (int) $n->post_author !== get_current_user_id() ) {
				$this->form_open( 'rfq' );
				echo '<input type="hidden" name="need" value="' . (int) $n->ID . '">';
				$this->field( 'subject', $this->t( 'subject' ), 'text', [ 'required' => true, 'value' => $n->post_title ] );
				$this->field( 'message', $this->t( 'message' ), 'textarea', [ 'required' => true, 'attr' => 'minlength="20"' ] );
				echo '<button class="wkt-btn" type="submit">' . esc_html( $this->t( 'send' ) ) . '</button></form>';
			}
			echo '</details>';
		}
		echo '<p class="wkt-small wkt-muted">' . esc_html( $this->t( 'note' ) ) . '</p></div>';
	}
}
