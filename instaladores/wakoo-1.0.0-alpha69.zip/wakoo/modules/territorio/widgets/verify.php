<?php
/**
 * «Verificar certificado (Wakoo)»: anyone can check a certificate code. Shows only the
 * holder's name, the course, hours and date (what the certificate itself says).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

defined( 'ABSPATH' ) || die();

class W_Verify extends Base {

	public function get_name() { return 'wakoo-t-verify'; }
	public function get_title() { return __( 'Verificar certificado (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-check-circle'; }
	public function get_keywords() { return [ 'verificar', 'certificado', 'código', 'academia', 'wakoo' ]; }

	protected function texts() {
		return [
			'code'   => [ __( 'Campo: código', 'wakoo' ), __( 'Código de verificación', 'wakoo' ) ],
			'help'   => [ __( 'Ayuda', 'wakoo' ), __( 'Está impreso al pie del certificado, con el formato XXXX-XXXX-XXXX.', 'wakoo' ) ],
			'send'   => [ __( 'Botón', 'wakoo' ), __( 'Verificar', 'wakoo' ) ],
			'ok'     => [ __( 'Válido', 'wakoo' ), __( 'Certificado válido', 'wakoo' ) ],
			'ko'     => [ __( 'No encontrado', 'wakoo' ), __( 'No encontramos un certificado con ese código. Revise que esté bien escrito.', 'wakoo' ) ],
			'holder' => [ __( 'Titular', 'wakoo' ), __( 'Titular', 'wakoo' ) ],
			'course' => [ __( 'Curso', 'wakoo' ), __( 'Curso', 'wakoo' ) ],
			'hours'  => [ __( 'Horas', 'wakoo' ), __( 'Duración (horas)', 'wakoo' ) ],
			'date'   => [ __( 'Fecha', 'wakoo' ), __( 'Fecha de emisión', 'wakoo' ) ],
		];
	}

	protected function render() {
		$code = $this->get( 'codigo' );
		$id   = 'wkt-v-' . $this->get_id();
		echo '<div class="wkt wkt-verify"><form class="wkt-form wkt-verify__form" method="get" action="' . esc_url( remove_query_arg( 'codigo', $this->here() ) ) . '" role="search">';
		echo '<div class="wkt-field"><label for="' . esc_attr( $id ) . '">' . esc_html( $this->t( 'code' ) ) . '</label><input id="' . esc_attr( $id ) . '" name="codigo" type="text" value="' . esc_attr( $code ) . '" autocomplete="off" spellcheck="false" aria-describedby="' . esc_attr( $id ) . '-h" required><small id="' . esc_attr( $id ) . '-h" class="wkt-help">' . esc_html( $this->t( 'help' ) ) . '</small></div>';
		echo '<button class="wkt-btn" type="submit">' . esc_html( $this->t( 'send' ) ) . '</button></form>';
		if ( '' !== $code ) {
			$c = Module::rate( 'verify', 60 ) ? Academy::cert_by_code( $code ) : null;
			echo '<div class="wkt-result" role="status">';
			if ( ! $c ) {
				echo '<div class="wkt-notice wkt-notice--err">' . esc_html( $this->t( 'ko' ) ) . '</div>';
			} else {
				echo '<div class="wkt-card wkt-cert-ok"><p>' . $this->badge( $this->t( 'ok' ), 'ok' ) . '</p><dl class="wkt-dl">'; // phpcs:ignore WordPress.Security.EscapeOutput
				foreach ( [ 'holder' => 'name', 'course' => 'course_title', 'hours' => 'hours', 'date' => 'date' ] as $l => $k ) {
					$v = (string) Module::meta( $c->ID, $k );
					if ( '' === $v ) { continue; }
					if ( 'date' === $k ) { $v = date_i18n( 'd/m/Y', strtotime( $v ) ); }
					echo '<div><dt>' . esc_html( $this->t( $l ) ) . '</dt><dd>' . esc_html( $v ) . '</dd></div>';
				}
				echo '</dl></div>';
			}
			echo '</div>';
		}
		echo '</div>';
	}
}
