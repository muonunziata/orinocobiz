<?php
/**
 * «Mi empresa» (panel): create/edit the company profile, choose which contact data are public,
 * keep private documents, read and answer quote requests, publish purchase needs.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

defined( 'ABSPATH' ) || die();

class W_CompanyPanel extends Base {

	public function get_name() { return 'wakoo-t-companypanel'; }
	public function get_title() { return __( 'Directorio: panel de la empresa (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-user-circle-o'; }
	public function get_keywords() { return [ 'empresa', 'panel', 'proveedor', 'registro', 'directorio', 'wakoo' ]; }

	protected function texts() {
		return [
			'login'     => [ __( 'Sin sesión', 'wakoo' ), __( 'Inicie sesión o cree una cuenta para registrar su empresa en el directorio.', 'wakoo' ) ],
			'tab_prof'  => [ __( 'Pestaña: perfil', 'wakoo' ), __( 'Perfil', 'wakoo' ) ],
			'tab_docs'  => [ __( 'Pestaña: documentos', 'wakoo' ), __( 'Documentos', 'wakoo' ) ],
			'tab_inbox' => [ __( 'Pestaña: consultas', 'wakoo' ), __( 'Consultas', 'wakoo' ) ],
			'tab_needs' => [ __( 'Pestaña: necesidades', 'wakoo' ), __( 'Necesidades de compra', 'wakoo' ) ],
			'status'    => [ __( 'Estado del perfil', 'wakoo' ), __( 'Estado del perfil', 'wakoo' ) ],
			'pending'   => [ __( 'Pendiente', 'wakoo' ), __( 'Pendiente de revisión', 'wakoo' ) ],
			'publish'   => [ __( 'Publicado', 'wakoo' ), __( 'Publicado en el directorio', 'wakoo' ) ],
			'trade'     => [ __( 'Campo: nombre comercial', 'wakoo' ), __( 'Nombre comercial', 'wakoo' ) ],
			'legal'     => [ __( 'Campo: razón social', 'wakoo' ), __( 'Razón social (no se publica)', 'wakoo' ) ],
			'rif'       => [ __( 'Campo: RIF', 'wakoo' ), __( 'RIF (no se publica)', 'wakoo' ) ],
			'cat'       => [ __( 'Campo: categoría', 'wakoo' ), __( 'Categoría', 'wakoo' ) ],
			'cat_pick'  => [ __( 'Elegir categoría', 'wakoo' ), __( 'Elija una categoría', 'wakoo' ) ],
			'sector'    => [ __( 'Campo: sector', 'wakoo' ), __( 'Sector principal', 'wakoo' ) ],
			'mun'       => [ __( 'Campo: municipio', 'wakoo' ), __( 'Municipio', 'wakoo' ) ],
			'none'      => [ __( 'Opción: ninguno', 'wakoo' ), __( '—', 'wakoo' ) ],
			'desc'      => [ __( 'Campo: presentación', 'wakoo' ), __( 'Presentación de la empresa', 'wakoo' ) ],
			'products'  => [ __( 'Campo: productos', 'wakoo' ), __( 'Productos y servicios (uno por línea)', 'wakoo' ) ],
			'caps'      => [ __( 'Campo: capacidades', 'wakoo' ), __( 'Capacidades técnicas (una por línea)', 'wakoo' ) ],
			'equip'     => [ __( 'Campo: equipos', 'wakoo' ), __( 'Equipos disponibles (uno por línea)', 'wakoo' ) ],
			'certs'     => [ __( 'Campo: certificaciones', 'wakoo' ), __( 'Certificaciones (una por línea)', 'wakoo' ) ],
			'contact'   => [ __( 'Título: contacto', 'wakoo' ), __( 'Datos de contacto: marque los que autoriza publicar', 'wakoo' ) ],
			'publish_q' => [ __( 'Casilla: publicar', 'wakoo' ), __( 'Publicar', 'wakoo' ) ],
			'consent'   => [ __( 'Consentimiento', 'wakoo' ), __( 'Declaro que los datos son ciertos y autorizo publicar en el directorio solo los campos marcados. Los documentos y el RIF no se publican.', 'wakoo' ) ],
			'save'      => [ __( 'Botón: guardar', 'wakoo' ), __( 'Guardar perfil', 'wakoo' ) ],
			'docs_i'    => [ __( 'Texto: documentos', 'wakoo' ), __( 'Suba aquí los documentos que el equipo revisará para el nivel «Documentación verificada» (registro mercantil, RIF, certificaciones…). Son privados.', 'wakoo' ) ],
			'docs_f'    => [ __( 'Campo: documentos', 'wakoo' ), __( 'Documentos', 'wakoo' ) ],
			'upload'    => [ __( 'Botón: subir', 'wakoo' ), __( 'Subir', 'wakoo' ) ],
			'no_docs'   => [ __( 'Sin documentos', 'wakoo' ), __( 'Sin documentos.', 'wakoo' ) ],
			'inbox_in'  => [ __( 'Título: recibidas', 'wakoo' ), __( 'Recibidas', 'wakoo' ) ],
			'inbox_out' => [ __( 'Título: enviadas', 'wakoo' ), __( 'Enviadas', 'wakoo' ) ],
			'no_msgs'   => [ __( 'Sin consultas', 'wakoo' ), __( 'No hay consultas.', 'wakoo' ) ],
			'reply'     => [ __( 'Campo: respuesta', 'wakoo' ), __( 'Responder', 'wakoo' ) ],
			'send'      => [ __( 'Botón: enviar', 'wakoo' ), __( 'Enviar', 'wakoo' ) ],
			'need_t'    => [ __( 'Campo: necesidad', 'wakoo' ), __( '¿Qué necesita comprar o contratar?', 'wakoo' ) ],
			'need_d'    => [ __( 'Campo: detalle', 'wakoo' ), __( 'Detalle (especificaciones, lugar de entrega, condiciones)', 'wakoo' ) ],
			'need_q'    => [ __( 'Campo: cantidad', 'wakoo' ), __( 'Cantidad o alcance', 'wakoo' ) ],
			'need_dl'   => [ __( 'Campo: fecha límite', 'wakoo' ), __( 'Fecha límite para ofertas', 'wakoo' ) ],
			'need_btn'  => [ __( 'Botón: publicar necesidad', 'wakoo' ), __( 'Enviar a revisión', 'wakoo' ) ],
			'my_needs'  => [ __( 'Título: mis necesidades', 'wakoo' ), __( 'Mis necesidades', 'wakoo' ) ],
			'first'     => [ __( 'Primero el perfil', 'wakoo' ), __( 'Guarde primero el perfil de su empresa.', 'wakoo' ) ],
		];
	}

	protected function render() {
		echo '<div class="wkt wkt-cpanel">';
		$this->notice();
		if ( ! is_user_logged_in() ) { $this->login_box( $this->t( 'login' ) ); echo '</div>'; return; }
		$c   = Forms::my_company();
		$tab = sanitize_key( $this->get( 'tab' ) ) ?: 'perfil';
		$tabs = [ 'perfil' => 'tab_prof', 'documentos' => 'tab_docs', 'consultas' => 'tab_inbox', 'necesidades' => 'tab_needs' ];
		echo '<nav class="wkt-tabs" aria-label="' . esc_attr__( 'Secciones del panel', 'wakoo' ) . '">';
		foreach ( $tabs as $k => $l ) { echo '<a href="' . esc_url( add_query_arg( 'tab', $k, remove_query_arg( 'tab', $this->here() ) ) ) . '"' . ( $tab === $k ? ' aria-current="page"' : '' ) . '>' . esc_html( $this->t( $l ) ) . '</a>'; }
		echo '</nav>';
		if ( 'perfil' !== $tab && ! $c ) { echo '<div class="wkt-empty">' . esc_html( $this->t( 'first' ) ) . '</div></div>'; return; }
		switch ( $tab ) {
			case 'documentos': $this->docs( $c ); break;
			case 'consultas': $this->inbox( $c ); break;
			case 'necesidades': $this->needs( $c ); break;
			default: $this->profile( $c );
		}
		echo '</div>';
	}

	private function profile( $c ) {
		$old = Forms::old( 'company' );
		$v   = function ( $k, $meta = null ) use ( $c, $old ) { return $old[ $k ] ?? ( $c ? (string) ( null === $meta ? '' : Module::meta( $c->ID, $meta ) ) : '' ); };
		$tid = function ( $tax ) use ( $c ) { $t = $c ? Module::terms( $c->ID, $tax ) : []; return $t ? (string) $t[0]->term_id : ''; };
		if ( $c ) {
			echo '<p class="wkt-status">' . esc_html( $this->t( 'status' ) ) . ': ' . $this->badge( 'publish' === $c->post_status ? $this->t( 'publish' ) : $this->t( 'pending' ), 'publish' === $c->post_status ? 'ok' : 'warn' ) . ' ' . $this->badge( Module::levels()[ Module::meta( $c->ID, 'level', 'registrada' ) ] ?? '', 'soft' ); // phpcs:ignore WordPress.Security.EscapeOutput
			if ( 'publish' === $c->post_status ) { echo ' <a href="' . esc_url( get_permalink( $c ) ) . '">' . esc_html__( 'Ver perfil público', 'wakoo' ) . '</a>'; }
			echo '</p>';
		}
		$this->form_open( 'company', true, 'wkt-grid-form' );
		$this->field( 'trade_name', $this->t( 'trade' ), 'text', [ 'required' => true, 'value' => $old['trade_name'] ?? ( $c ? $c->post_title : '' ), 'attr' => 'autocomplete="organization"' ] );
		$this->field( 'legal_name', $this->t( 'legal' ), 'text', [ 'value' => $v( 'legal_name', 'legal_name' ) ] );
		$this->field( 'rif', $this->t( 'rif' ), 'text', [ 'value' => $v( 'rif', 'rif' ) ] );
		$this->field( 'cat', $this->t( 'cat' ), 'select', [ 'required' => true, 'value' => $old['cat'] ?? $tid( Module::T_CCAT ), 'options' => $this->term_options( Module::T_CCAT, $this->t( 'cat_pick' ) ) ] );
		$this->field( 'sector', $this->t( 'sector' ), 'select', [ 'value' => $old['sector'] ?? $tid( Module::T_SECTOR ), 'options' => $this->term_options( Module::T_SECTOR, $this->t( 'none' ) ) ] );
		$this->field( 'municipio', $this->t( 'mun' ), 'select', [ 'value' => $old['municipio'] ?? $tid( Module::T_MUN ), 'options' => $this->term_options( Module::T_MUN, $this->t( 'none' ) ) ] );
		$this->field( 'desc', $this->t( 'desc' ), 'textarea', [ 'required' => true, 'wide' => true, 'value' => $old['desc'] ?? ( $c ? $c->post_content : '' ), 'attr' => 'minlength="30"' ] );
		foreach ( [ 'products' => 'products', 'capabilities' => 'caps', 'equipment' => 'equip', 'certs' => 'certs' ] as $k => $l ) {
			$this->field( $k, $this->t( $l ), 'textarea', [ 'rows' => 4, 'value' => $v( $k, $k ) ] );
		}
		echo '<fieldset class="wkt-field wkt-field--wide wkt-fieldset"><legend>' . esc_html( $this->t( 'contact' ) ) . '</legend><div class="wkt-grid-form">';
		$pub = $c ? (array) Module::meta( $c->ID, 'public', [] ) : [];
		foreach ( Forms::contact_fields() as $k => $l ) {
			echo '<div>';
			$this->field( $k, $l, 'web' === $k ? 'url' : ( 'email' === $k ? 'email' : 'text' ), [ 'value' => $v( $k, $k ) ] );
			$this->check( 'show_' . $k, esc_html( $this->t( 'publish_q' ) ), in_array( $k, $pub, true ) );
			echo '</div>';
		}
		echo '</div></fieldset><div class="wkt-field wkt-field--wide">';
		$this->check( 'consent', esc_html( $this->t( 'consent' ) ), false, true );
		echo '</div><div class="wkt-field wkt-field--wide"><button class="wkt-btn" type="submit">' . esc_html( $this->t( 'save' ) ) . '</button></div></form>';
	}

	private function docs( $c ) {
		echo '<p>' . esc_html( $this->t( 'docs_i' ) ) . '</p>';
		$files = Store::files( $c->ID );
		if ( $files ) {
			echo '<ul class="wkt-links">';
			foreach ( $files as $f ) { echo '<li><a href="' . esc_url( Store::download_url( $c->ID, $f['id'] ) ) . '">' . esc_html( $f['name'] ) . '</a> <small>' . esc_html( size_format( $f['size'] ) . ' · ' . wp_date( 'd/m/Y', $f['time'] ) ) . '</small></li>'; }
			echo '</ul>';
		} else {
			echo '<p class="wkt-muted">' . esc_html( $this->t( 'no_docs' ) ) . '</p>';
		}
		$this->form_open( 'company_doc', true );
		$this->field( 'docs', $this->t( 'docs_f' ), 'file', [ 'required' => true ] );
		echo '<button class="wkt-btn" type="submit">' . esc_html( $this->t( 'upload' ) ) . '</button></form>';
	}

	private function inbox( $c ) {
		$uid = get_current_user_id();
		$in  = get_posts( [ 'post_type' => Module::RFQ, 'post_status' => 'private', 'numberposts' => 50, 'meta_key' => Module::PRE . 'to_user', 'meta_value' => $uid ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
		$out = get_posts( [ 'post_type' => Module::RFQ, 'post_status' => 'private', 'numberposts' => 50, 'author' => $uid ] );
		foreach ( [ 'inbox_in' => $in, 'inbox_out' => $out ] as $title => $list ) {
			echo '<h3 class="wkt-h">' . esc_html( $this->t( $title ) ) . '</h3>';
			if ( ! $list ) { echo '<p class="wkt-muted">' . esc_html( $this->t( 'no_msgs' ) ) . '</p>'; continue; }
			foreach ( $list as $r ) {
				$from = (int) Module::meta( $r->ID, 'from' );
				$who  = 'inbox_in' === $title ? ( $from ? get_the_title( $from ) : get_the_author_meta( 'display_name', $r->post_author ) ) : get_the_title( (int) Module::meta( $r->ID, 'to' ) );
				echo '<details class="wkt-card wkt-msg"><summary><strong>' . esc_html( $r->post_title ) . '</strong> <span class="wkt-muted">· ' . esc_html( $who . ' · ' . get_the_date( 'd/m/Y', $r ) ) . '</span></summary><div class="wkt-prose">' . wp_kses_post( wpautop( esc_html( $r->post_content ) ) ) . '</div><ol class="wkt-timeline">';
				foreach ( Store::lines( Module::RFQ, $r->ID, [ 'public' ] ) as $l ) {
					echo '<li class="' . ( (int) $l->user_id === $uid ? 'is-you' : 'is-team' ) . '"><p class="wkt-timeline__meta">' . esc_html( get_the_author_meta( 'display_name', $l->user_id ) . ' · ' . get_date_from_gmt( $l->created, 'd/m/Y H:i' ) ) . '</p><p>' . nl2br( esc_html( $l->message ) ) . '</p></li>';
				}
				echo '</ol>';
				$this->form_open( 'rfq_reply' );
				echo '<input type="hidden" name="rfq" value="' . (int) $r->ID . '">';
				$this->field( 'message', $this->t( 'reply' ), 'textarea', [ 'rows' => 3, 'required' => true ] );
				echo '<button class="wkt-btn" type="submit">' . esc_html( $this->t( 'send' ) ) . '</button></form></details>';
			}
		}
	}

	private function needs( $c ) {
		$mine = get_posts( [ 'post_type' => Module::NEED, 'post_status' => [ 'publish', 'pending' ], 'numberposts' => 50, 'author' => get_current_user_id() ] );
		if ( $mine ) {
			echo '<h3 class="wkt-h">' . esc_html( $this->t( 'my_needs' ) ) . '</h3><ul class="wkt-links">';
			foreach ( $mine as $n ) { echo '<li>' . esc_html( $n->post_title ) . ' ' . $this->badge( 'publish' === $n->post_status ? $this->t( 'publish' ) : $this->t( 'pending' ), 'publish' === $n->post_status ? 'ok' : 'warn' ) . '</li>'; } // phpcs:ignore WordPress.Security.EscapeOutput
			echo '</ul>';
		}
		$this->form_open( 'need', false, 'wkt-grid-form' );
		$this->field( 'title', $this->t( 'need_t' ), 'text', [ 'required' => true, 'wide' => true ] );
		$this->field( 'desc', $this->t( 'need_d' ), 'textarea', [ 'required' => true, 'wide' => true, 'attr' => 'minlength="30"' ] );
		$this->field( 'qty', $this->t( 'need_q' ), 'text' );
		$this->field( 'deadline', $this->t( 'need_dl' ), 'date' );
		$this->field( 'sector', $this->t( 'sector' ), 'select', [ 'options' => $this->term_options( Module::T_SECTOR, $this->t( 'none' ) ) ] );
		$this->field( 'municipio', $this->t( 'mun' ), 'select', [ 'options' => $this->term_options( Module::T_MUN, $this->t( 'none' ) ) ] );
		echo '<div class="wkt-field wkt-field--wide"><button class="wkt-btn" type="submit">' . esc_html( $this->t( 'need_btn' ) ) . '</button></div></form>';
	}
}
