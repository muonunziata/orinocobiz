<?php
/**
 * «Panel del estudiante (Wakoo)»: the signed-in user's courses, progress and certificates.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

defined( 'ABSPATH' ) || die();

class W_Student extends Base {

	public function get_name() { return 'wakoo-t-student'; }
	public function get_title() { return __( 'Panel del estudiante (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-person'; }
	public function get_keywords() { return [ 'estudiante', 'mis cursos', 'progreso', 'certificados', 'academia', 'wakoo' ]; }

	protected function texts() {
		return [
			'login'    => [ __( 'Sin sesión', 'wakoo' ), __( 'Inicie sesión para ver sus cursos, su progreso y sus certificados.', 'wakoo' ) ],
			'courses'  => [ __( 'Título: mis cursos', 'wakoo' ), __( 'Mis cursos', 'wakoo' ) ],
			'none'     => [ __( 'Sin cursos', 'wakoo' ), __( 'Todavía no está inscrito en ningún curso.', 'wakoo' ) ],
			'catalog'  => [ __( 'Enlace al catálogo', 'wakoo' ), __( 'Ver la oferta de la academia', 'wakoo' ) ],
			'enrolled' => [ __( 'Estado: inscrito', 'wakoo' ), __( 'En curso', 'wakoo' ) ],
			'interest' => [ __( 'Estado: interés', 'wakoo' ), __( 'Interés registrado', 'wakoo' ) ],
			'completed'=> [ __( 'Estado: completado', 'wakoo' ), __( 'Completado', 'wakoo' ) ],
			'progress' => [ __( 'Progreso (%d)', 'wakoo' ), __( '%d %% completado', 'wakoo' ) ],
			'go'       => [ __( 'Botón: continuar', 'wakoo' ), __( 'Continuar', 'wakoo' ) ],
			'certs'    => [ __( 'Título: certificados', 'wakoo' ), __( 'Mis certificados', 'wakoo' ) ],
			'nocert'   => [ __( 'Sin certificados', 'wakoo' ), __( 'Los certificados aparecen aquí al completar un curso.', 'wakoo' ) ],
			'code'     => [ __( 'Código', 'wakoo' ), __( 'Código de verificación', 'wakoo' ) ],
			'print'    => [ __( 'Imprimir', 'wakoo' ), __( 'Ver o imprimir', 'wakoo' ) ],
		];
	}

	protected function controls() {
		$this->start_controls_section( 'sec_main', [ 'label' => __( 'Panel', 'wakoo' ) ] );
		$this->add_control( 'catalog', [ 'label' => __( 'Enlace al catálogo de cursos', 'wakoo' ), 'type' => \Elementor\Controls_Manager::URL ] );
		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		echo '<div class="wkt wkt-student">';
		$this->notice();
		if ( ! is_user_logged_in() ) { $this->login_box( $this->t( 'login' ) ); echo '</div>'; return; }
		$uid = get_current_user_id();
		$all = Academy::enrolment( $uid );
		echo '<h3 class="wkt-h">' . esc_html( $this->t( 'courses' ) ) . '</h3>';
		if ( ! $all ) {
			echo '<div class="wkt-empty"><p>' . esc_html( $this->t( 'none' ) ) . '</p>';
			if ( ! empty( $s['catalog']['url'] ) ) { echo '<p><a class="wkt-btn" href="' . esc_url( $s['catalog']['url'] ) . '">' . esc_html( $this->t( 'catalog' ) ) . '</a></p>'; }
			echo '</div>';
		} else {
			echo '<div class="wkt-grid">';
			foreach ( $all as $cid => $e ) {
				$c = get_post( $cid );
				if ( ! $c || 'publish' !== $c->post_status ) { continue; }
				$st = $e['status'] ?? 'enrolled';
				$pc = 'interest' === $st ? 0 : Academy::percent( $uid, $cid );
				echo '<article class="wkt-card"><p>' . $this->badge( $this->t( $st ), 'completed' === $st ? 'ok' : ( 'interest' === $st ? 'info' : 'soft' ) ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
				echo '<h4 class="wkt-card__t">' . esc_html( $c->post_title ) . '</h4>';
				if ( 'interest' !== $st ) { echo '<div class="wkt-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' . (int) $pc . '"><i style="--w:' . (int) $pc . '%"></i></div><p class="wkt-small">' . esc_html( sprintf( $this->t( 'progress' ), $pc ) ) . '</p>'; }
				echo '<a class="wkt-more-link" href="' . esc_url( get_permalink( $c ) ) . '">' . esc_html( $this->t( 'go' ) ) . ' <span aria-hidden="true">→</span></a></article>';
			}
			echo '</div>';
		}
		echo '<h3 class="wkt-h">' . esc_html( $this->t( 'certs' ) ) . '</h3>';
		$certs = Academy::certs_of( $uid );
		if ( ! $certs ) { echo '<p class="wkt-muted">' . esc_html( $this->t( 'nocert' ) ) . '</p>'; }
		else {
			echo '<ul class="wkt-list">';
			foreach ( $certs as $ct ) {
				$code = (string) Module::meta( $ct->ID, 'code' );
				echo '<li><strong>' . esc_html( Module::meta( $ct->ID, 'course_title' ) ) . '</strong> · ' . esc_html( date_i18n( 'd/m/Y', strtotime( Module::meta( $ct->ID, 'date' ) ) ) ) . ' · <span class="wkt-muted">' . esc_html( $this->t( 'code' ) ) . ':</span> <code class="wkt-code">' . esc_html( $code ) . '</code> · <a href="' . esc_url( add_query_arg( 'wkt_cert', $code, home_url( '/' ) ) ) . '" target="_blank" rel="noopener">' . esc_html( $this->t( 'print' ) ) . '</a></li>';
			}
			echo '</ul>';
		}
		echo '</div>';
	}
}
