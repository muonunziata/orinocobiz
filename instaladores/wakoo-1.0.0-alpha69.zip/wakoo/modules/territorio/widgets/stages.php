<?php
/**
 * «Estado de la cartera»: how many published projects are in each preparation stage
 * (real numbers from the portal's own catalogue), with a short legend.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class W_Stages extends Base {

	public function get_name() { return 'wakoo-t-stages'; }
	public function get_title() { return __( 'Estado de la cartera (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-skill-bar'; }
	public function get_keywords() { return [ 'proyectos', 'estados', 'cartera', 'barras', 'wakoo' ]; }

	protected function controls() {
		$this->start_controls_section( 'sec_main', [ 'label' => __( 'Estados', 'wakoo' ) ] );
		$this->add_control( 'link', [ 'label' => __( 'Enlace a la cartera (filtra por estado)', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$this->add_control( 'zero', [ 'label' => __( 'Mostrar estados sin proyectos', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();
	}

	protected function texts() {
		$t = [ 'total' => [ __( 'Total (%d)', 'wakoo' ), __( '%d proyectos publicados en la cartera', 'wakoo' ) ], 'empty' => [ __( 'Sin proyectos', 'wakoo' ), __( 'La cartera aún no tiene proyectos publicados.', 'wakoo' ) ] ];
		foreach ( Module::stages() as $k => $l ) { $t[ 's_' . $k ] = [ $l, $l ]; }
		return $t;
	}

	protected function render() {
		$s   = $this->get_settings_for_display();
		$n   = Admin::numbers( 'stages' );
		$tot = array_sum( $n );
		$max = max( 1, max( $n ) );
		$url = $s['link']['url'] ?? '';
		echo '<div class="wkt wkt-stages">';
		if ( ! $tot ) { echo '<div class="wkt-empty">' . esc_html( $this->t( 'empty' ) ) . '</div></div>'; return; }
		echo '<p class="wkt-stages__total">' . esc_html( sprintf( $this->t( 'total' ), $tot ) ) . '</p><ul>';
		foreach ( $n as $k => $v ) {
			if ( ! $v && 'yes' !== ( $s['zero'] ?? '' ) ) { continue; }
			$label = esc_html( $this->t( 's_' . $k ) );
			echo '<li class="wkt-stage wkt-stage--' . esc_attr( $k ) . '"><span class="wkt-stage__label">' . ( $url && $v ? '<a href="' . esc_url( add_query_arg( 'estado', $k, $url ) ) . '">' . $label . '</a>' : $label ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<span class="wkt-stage__bar" aria-hidden="true"><i style="--w:' . esc_attr( (string) round( $v * 100 / $max ) ) . '%"></i></span><span class="wkt-stage__n">' . (int) $v . '</span></li>';
		}
		echo '</ul></div>';
	}
}
