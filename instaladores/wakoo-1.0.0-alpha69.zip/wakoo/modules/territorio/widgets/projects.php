<?php
/**
 * «Cartera de proyectos»: catalogue with search, filters (municipio, sector, estado, rango de
 * inversión when there are amounts) and pagination, drawn on the server (readable without JS).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class W_Projects extends Base {

	public function get_name() { return 'wakoo-t-projects'; }
	public function get_title() { return __( 'Cartera de proyectos (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-posts-grid'; }
	public function get_keywords() { return [ 'proyectos', 'inversion', 'cartera', 'catalogo', 'filtros', 'wakoo' ]; }

	protected function controls() {
		$this->start_controls_section( 'sec_main', [ 'label' => __( 'Catálogo', 'wakoo' ) ] );
		$this->add_control( 'sector', [ 'label' => __( 'Solo este sector (slug)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'description' => __( 'Vacío = todos. Para las páginas sectoriales.', 'wakoo' ) ] );
		$this->add_control( 'filters', [ 'label' => __( 'Mostrar buscador y filtros', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'per', [ 'label' => __( 'Proyectos por página', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 9, 'min' => 1, 'max' => 60 ] );
		$this->add_control( 'paging', [ 'label' => __( 'Mostrar paginación', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'cols', [ 'label' => __( 'Columnas', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => '3', 'options' => [ '1' => '1', '2' => '2', '3' => '3', '4' => '4' ], 'selectors' => [ '{{WRAPPER}} .wkt-grid' => '--cols: {{VALUE}};' ] ] );
		$this->end_controls_section();
	}

	protected function texts() {
		return [
			'search'   => [ __( 'Campo: buscar', 'wakoo' ), __( 'Buscar proyecto', 'wakoo' ) ],
			'all_mun'  => [ __( 'Todos los municipios', 'wakoo' ), __( 'Todos los municipios', 'wakoo' ) ],
			'all_sec'  => [ __( 'Todos los sectores', 'wakoo' ), __( 'Todos los sectores', 'wakoo' ) ],
			'all_st'   => [ __( 'Todos los estados', 'wakoo' ), __( 'Todos los estados', 'wakoo' ) ],
			'all_inv'  => [ __( 'Cualquier inversión', 'wakoo' ), __( 'Cualquier inversión', 'wakoo' ) ],
			'l_mun'    => [ __( 'Etiqueta: municipio', 'wakoo' ), __( 'Municipio', 'wakoo' ) ],
			'l_sec'    => [ __( 'Etiqueta: sector', 'wakoo' ), __( 'Sector', 'wakoo' ) ],
			'l_st'     => [ __( 'Etiqueta: estado', 'wakoo' ), __( 'Estado de preparación', 'wakoo' ) ],
			'l_inv'    => [ __( 'Etiqueta: inversión', 'wakoo' ), __( 'Inversión', 'wakoo' ) ],
			'filter'   => [ __( 'Botón: filtrar', 'wakoo' ), __( 'Filtrar', 'wakoo' ) ],
			'clear'    => [ __( 'Enlace: limpiar', 'wakoo' ), __( 'Limpiar filtros', 'wakoo' ) ],
			'count'    => [ __( 'Recuento (%d)', 'wakoo' ), __( '%d proyectos', 'wakoo' ) ],
			'none'     => [ __( 'Sin resultados', 'wakoo' ), __( 'No hay proyectos que coincidan con la búsqueda. La cartera se amplía a medida que las iniciativas se documentan y validan.', 'wakoo' ) ],
			'empty'    => [ __( 'Cartera vacía', 'wakoo' ), __( 'Todavía no hay proyectos publicados en este sector. Si tiene una iniciativa, preséntela en la ventanilla del inversionista.', 'wakoo' ) ],
			'no_amt'   => [ __( 'Sin estimación', 'wakoo' ), __( 'Sin estimación de inversión publicada', 'wakoo' ) ],
			'estimate' => [ __( 'Etiqueta: estimación', 'wakoo' ), __( 'estimación', 'wakoo' ) ],
			'verified' => [ __( 'Etiqueta: verificada', 'wakoo' ), __( 'cifra verificada', 'wakoo' ) ],
			'more'     => [ __( 'Enlace: ver ficha', 'wakoo' ), __( 'Ver ficha', 'wakoo' ) ],
			'subregion'=> [ __( 'Sin municipio', 'wakoo' ), __( 'Localización por definir', 'wakoo' ) ],
		];
	}

	/** Investment ranges (USD) used only when some project has an amount. */
	private static function ranges() {
		return [ 'r1' => [ 0, 1000000, '< 1 M' ], 'r2' => [ 1000000, 10000000, '1 – 10 M' ], 'r3' => [ 10000000, 50000000, '10 – 50 M' ], 'r4' => [ 50000000, PHP_INT_MAX, '> 50 M' ] ];
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$fixed = sanitize_title( (string) ( $s['sector'] ?? '' ) );
		$q     = $this->get( 'q' );
		$mun   = (int) $this->get( 'municipio' );
		$sec   = $fixed ? 0 : (int) $this->get( 'sector' );
		$st    = sanitize_key( $this->get( 'estado' ) );
		$inv   = sanitize_key( $this->get( 'inv' ) );
		$per   = max( 1, (int) ( $s['per'] ?? 9 ) );
		$pg    = max( 1, (int) $this->get( 'pg' ) );

		$base = [ 'post_type' => Module::PROJECT, 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids', 'orderby' => [ 'menu_order' => 'ASC', 'title' => 'ASC' ] ];
		$tax  = [];
		if ( $fixed ) { $tax[] = [ 'taxonomy' => Module::T_SECTOR, 'field' => 'slug', 'terms' => $fixed ]; }
		$all_ids  = get_posts( $base + ( $tax ? [ 'tax_query' => $tax ] : [] ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		$has_amts = false;
		foreach ( $all_ids as $id ) { if ( is_numeric( Module::meta( $id, 'amount' ) ) ) { $has_amts = true; break; } }

		if ( $sec ) { $tax[] = [ 'taxonomy' => Module::T_SECTOR, 'field' => 'term_id', 'terms' => $sec ]; }
		if ( $mun ) { $tax[] = [ 'taxonomy' => Module::T_MUN, 'field' => 'term_id', 'terms' => $mun ]; }
		$args = $base;
		if ( $tax ) { $args['tax_query'] = $tax; } // phpcs:ignore WordPress.DB.SlowDBQuery
		if ( '' !== $q ) { $args['s'] = $q; }
		$meta = [];
		if ( $st && isset( Module::stages()[ $st ] ) ) { $meta[] = [ 'key' => Module::PRE . 'stage', 'value' => $st ]; }
		if ( $meta ) { $args['meta_query'] = $meta; } // phpcs:ignore WordPress.DB.SlowDBQuery
		$ids = get_posts( $args );
		if ( $has_amts && isset( self::ranges()[ $inv ] ) ) {
			$r   = self::ranges()[ $inv ];
			$ids = array_values( array_filter( $ids, function ( $id ) use ( $r ) { $a = Module::meta( $id, 'amount' ); return is_numeric( $a ) && $a >= $r[0] && $a < $r[1]; } ) );
		}
		$total = count( $ids );
		$pages = (int) ceil( $total / $per );
		$show  = array_slice( $ids, ( $pg - 1 ) * $per, $per );

		echo '<div class="wkt wkt-projects">';
		if ( 'yes' === ( $s['filters'] ?? '' ) && $all_ids ) {
			echo '<form class="wkt-filters" method="get" action="' . esc_url( remove_query_arg( [ 'q', 'municipio', 'sector', 'estado', 'inv', 'pg' ], $this->here() ) ) . '" role="search">';
			$this->field( 'q', $this->t( 'search' ), 'search', [ 'value' => $q ] );
			$this->field( 'municipio', $this->t( 'l_mun' ), 'select', [ 'value' => $mun ?: '', 'options' => $this->term_options( Module::T_MUN, $this->t( 'all_mun' ) ) ] );
			if ( ! $fixed ) { $this->field( 'sector', $this->t( 'l_sec' ), 'select', [ 'value' => $sec ?: '', 'options' => $this->term_options( Module::T_SECTOR, $this->t( 'all_sec' ) ) ] ); }
			$this->field( 'estado', $this->t( 'l_st' ), 'select', [ 'value' => $st, 'options' => [ '' => $this->t( 'all_st' ) ] + Module::stages() ] );
			if ( $has_amts ) { $this->field( 'inv', $this->t( 'l_inv' ), 'select', [ 'value' => $inv, 'options' => [ '' => $this->t( 'all_inv' ) ] + wp_list_pluck( self::ranges(), 2 ) ] ); }
			echo '<div class="wkt-filters__go"><button class="wkt-btn" type="submit">' . esc_html( $this->t( 'filter' ) ) . '</button>';
			if ( $q || $mun || $sec || $st || $inv ) { echo ' <a href="' . esc_url( remove_query_arg( [ 'q', 'municipio', 'sector', 'estado', 'inv', 'pg' ], $this->here() ) ) . '">' . esc_html( $this->t( 'clear' ) ) . '</a>'; }
			echo '</div></form><p class="wkt-count" aria-live="polite">' . esc_html( sprintf( $this->t( 'count' ), $total ) ) . '</p>';
		}
		if ( ! $all_ids ) {
			echo '<div class="wkt-empty">' . esc_html( $this->t( 'empty' ) ) . '</div></div>';
			return;
		}
		if ( ! $show ) {
			echo '<div class="wkt-empty">' . esc_html( $this->t( 'none' ) ) . '</div></div>';
			return;
		}
		echo '<ul class="wkt-grid">';
		foreach ( $show as $id ) { $this->card( $id ); }
		echo '</ul>';
		if ( 'yes' === ( $s['paging'] ?? 'yes' ) ) {
			$this->pager( $pg, $pages );
		}
		echo '</div>';
	}

	private function card( $id ) {
		$stage = Module::meta( $id, 'stage', 'conceptual' );
		$money = Module::money( $id );
		$mun   = Module::term_names( $id, Module::T_MUN );
		echo '<li class="wkt-card wkt-pcard"><div class="wkt-pcard__top"><span class="wkt-code">' . esc_html( Module::meta( $id, 'code' ) ) . '</span>' . $this->badge( Module::stages()[ $stage ] ?? '', 'stage-' . $stage ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<h3 class="wkt-pcard__title"><a href="' . esc_url( get_permalink( $id ) ) . '">' . esc_html( get_the_title( $id ) ) . '</a></h3>';
		echo '<p class="wkt-pcard__text">' . esc_html( wp_trim_words( get_the_excerpt( $id ), 28, '…' ) ) . '</p><dl class="wkt-dl">';
		echo '<div><dt>' . esc_html( $this->t( 'l_sec' ) ) . '</dt><dd>' . esc_html( Module::term_names( $id, Module::T_SECTOR ) ?: '—' ) . '</dd></div>';
		echo '<div><dt>' . esc_html( $this->t( 'l_mun' ) ) . '</dt><dd>' . esc_html( $mun ?: $this->t( 'subregion' ) ) . '</dd></div>';
		echo '<div><dt>' . esc_html( $this->t( 'l_inv' ) ) . '</dt><dd>' . ( $money ? esc_html( $money ) . ' <small>(' . esc_html( 'verified' === Module::meta( $id, 'amount_kind' ) ? $this->t( 'verified' ) : $this->t( 'estimate' ) ) . ')</small>' : '<span class="wkt-muted">' . esc_html( $this->t( 'no_amt' ) ) . '</span>' ) . '</dd></div>';
		echo '</dl><a class="wkt-more" href="' . esc_url( get_permalink( $id ) ) . '" aria-label="' . esc_attr( $this->t( 'more' ) . ': ' . get_the_title( $id ) ) . '">' . esc_html( $this->t( 'more' ) ) . ' <span aria-hidden="true">→</span></a></li>';
	}
}
