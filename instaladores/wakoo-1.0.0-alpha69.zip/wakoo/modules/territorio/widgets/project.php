<?php
/**
 * «Ficha de proyecto»: the standard sheet of one project (the single being viewed, or a chosen
 * one). Separates estimates from verified figures and lists what still needs validation.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class W_Project extends Base {

	public function get_name() { return 'wakoo-t-project'; }
	public function get_title() { return __( 'Ficha de proyecto (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-single-post'; }
	public function get_keywords() { return [ 'proyecto', 'ficha', 'inversion', 'wakoo' ]; }

	protected function controls() {
		$this->start_controls_section( 'sec_main', [ 'label' => __( 'Proyecto', 'wakoo' ) ] );
		$this->add_control( 'project', [ 'label' => __( 'Proyecto (ID; vacío = el que se está viendo)', 'wakoo' ), 'type' => Controls_Manager::NUMBER ] );
		$this->add_control( 'contact', [ 'label' => __( 'Enlace del botón de contacto', 'wakoo' ), 'type' => Controls_Manager::URL, 'description' => __( 'Normalmente la página de la ventanilla. Se añade ?proyecto=CÓDIGO.', 'wakoo' ) ] );
		$this->end_controls_section();
	}

	protected function texts() {
		$t = [
			'back'       => [ __( 'Enlace: volver', 'wakoo' ), __( 'Volver a la cartera', 'wakoo' ) ],
			'stage'      => [ __( 'Estado de preparación', 'wakoo' ), __( 'Estado de preparación', 'wakoo' ) ],
			'desc'       => [ __( 'Título: descripción', 'wakoo' ), __( 'Descripción', 'wakoo' ) ],
			'facts'      => [ __( 'Título: ficha técnica', 'wakoo' ), __( 'Ficha técnica', 'wakoo' ) ],
			'invest'     => [ __( 'Título: inversión', 'wakoo' ), __( 'Inversión', 'wakoo' ) ],
			'no_amt'     => [ __( 'Sin estimación', 'wakoo' ), __( 'No hay una estimación de inversión publicada para este proyecto.', 'wakoo' ) ],
			'estimate'   => [ __( 'Estimación', 'wakoo' ), __( 'Estimación (no es una cifra verificada)', 'wakoo' ) ],
			'verified'   => [ __( 'Verificada', 'wakoo' ), __( 'Cifra verificada', 'wakoo' ) ],
			'src'        => [ __( 'Fuente', 'wakoo' ), __( 'Fuente', 'wakoo' ) ],
			'date'       => [ __( 'Fecha', 'wakoo' ), __( 'Fecha', 'wakoo' ) ],
			'location'   => [ __( 'Título: ubicación', 'wakoo' ), __( 'Ubicación', 'wakoo' ) ],
			'geo_no'     => [ __( 'Ubicación sin verificar', 'wakoo' ), __( 'La ubicación geográfica aún no está verificada, por eso no se muestra en el mapa.', 'wakoo' ) ],
			'pending'    => [ __( 'Título: pendiente de validación', 'wakoo' ), __( 'Datos pendientes de validación', 'wakoo' ) ],
			'docs'       => [ __( 'Título: documentación', 'wakoo' ), __( 'Documentación pública', 'wakoo' ) ],
			'no_docs'    => [ __( 'Sin documentos', 'wakoo' ), __( 'Todavía no hay documentos públicos de este proyecto.', 'wakoo' ) ],
			'contact'    => [ __( 'Botón: contacto', 'wakoo' ), __( 'Manifestar interés por este proyecto', 'wakoo' ) ],
			'note'       => [ __( 'Aviso general', 'wakoo' ), __( 'La información de esta ficha es una propuesta para evaluación. No constituye una oferta, un permiso ni un compromiso de las instituciones.', 'wakoo' ) ],
			'none'       => [ __( 'Sin datos', 'wakoo' ), __( 'Por definir', 'wakoo' ) ],
		];
		foreach ( Admin::fields( Module::PROJECT ) as $k => $d ) {
			if ( in_array( $k, [ 'objective', 'scale', 'infra', 'market', 'permits', 'studies', 'jobs', 'risks', 'timeline', 'precond', 'responsible', 'source' ], true ) ) { $t[ 'f_' . $k ] = [ $d[0], $d[0] ]; }
		}
		$t['f_sector'] = [ __( 'Sector', 'wakoo' ), __( 'Sector', 'wakoo' ) ];
		$t['f_mun']    = [ __( 'Municipio', 'wakoo' ), __( 'Municipio', 'wakoo' ) ];
		return $t;
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$p = $this->current( Module::PROJECT, $s['project'] ?? 0 );
		if ( ! $p ) { echo '<div class="wkt-empty">' . esc_html__( 'Elija un proyecto.', 'wakoo' ) . '</div>'; return; }
		$id = $p->ID;
		$m  = function ( $k ) use ( $id ) { return (string) Module::meta( $id, $k ); };
		$stage = $m( 'stage' ) ?: 'conceptual';
		$scale = Admin::fields( Module::PROJECT )['scale'][2][ $m( 'scale' ) ] ?? '';

		echo '<article class="wkt wkt-sheet">';
		echo '<header class="wkt-sheet__head"><p class="wkt-sheet__meta"><span class="wkt-code">' . esc_html( $m( 'code' ) ) . '</span>' . $this->badge( Module::stages()[ $stage ] ?? '', 'stage-' . $stage ) . ( $scale ? $this->badge( $scale, 'soft' ) : '' ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<h1 class="wkt-sheet__title">' . esc_html( get_the_title( $p ) ) . '</h1>';
		if ( $m( 'objective' ) ) { echo '<p class="wkt-sheet__lead">' . esc_html( $m( 'objective' ) ) . '</p>'; }
		echo '</header>';

		// Stage track: where the project is among the seven stages.
		$keys = array_keys( Module::stages() );
		$pos  = array_search( $stage, $keys, true );
		echo '<div class="wkt-track" role="group" aria-label="' . esc_attr( $this->t( 'stage' ) ) . '"><ol>';
		foreach ( array_slice( Module::stages(), 0, 6, true ) as $k => $l ) {
			$i = array_search( $k, $keys, true );
			$c = 'suspendido' === $stage ? '' : ( $i < $pos ? 'is-done' : ( $i === $pos ? 'is-now' : '' ) );
			echo '<li class="' . esc_attr( $c ) . '"' . ( $i === $pos ? ' aria-current="step"' : '' ) . '><span>' . esc_html( $l ) . '</span></li>';
		}
		echo '</ol>' . ( 'suspendido' === $stage ? '<p class="wkt-muted">' . esc_html( Module::stages()['suspendido'] ) . '</p>' : '' ) . '</div>';

		echo '<div class="wkt-sheet__body"><div class="wkt-sheet__main">';
		$content = apply_filters( 'the_content', $p->post_content ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals
		if ( trim( wp_strip_all_tags( $content ) ) ) { echo '<section><h2 class="wkt-h">' . esc_html( $this->t( 'desc' ) ) . '</h2><div class="wkt-prose">' . wp_kses_post( $content ) . '</div></section>'; }
		echo '<section><h2 class="wkt-h">' . esc_html( $this->t( 'facts' ) ) . '</h2><dl class="wkt-facts">';
		$rows = [ 'f_sector' => Module::term_names( $id, Module::T_SECTOR ), 'f_mun' => Module::term_names( $id, Module::T_MUN ) ];
		foreach ( [ 'market', 'infra', 'permits', 'studies', 'jobs', 'risks', 'timeline', 'precond', 'responsible' ] as $k ) { $rows[ 'f_' . $k ] = $m( $k ); }
		foreach ( $rows as $k => $v ) {
			echo '<div><dt>' . esc_html( $this->t( $k ) ) . '</dt><dd>' . ( '' !== $v ? nl2br( esc_html( $v ) ) : '<span class="wkt-muted">' . esc_html( $this->t( 'none' ) ) . '</span>' ) . '</dd></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</dl></section>';
		if ( $m( 'pending' ) ) {
			echo '<section class="wkt-callout"><h2 class="wkt-h">' . esc_html( $this->t( 'pending' ) ) . '</h2><ul>';
			foreach ( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $m( 'pending' ) ) ) ) as $l ) { echo '<li>' . esc_html( ltrim( $l, '-•· ' ) ) . '</li>'; }
			echo '</ul></section>';
		}
		echo '</div><aside class="wkt-sheet__side">';
		echo '<section class="wkt-card"><h2 class="wkt-h">' . esc_html( $this->t( 'invest' ) ) . '</h2>';
		$money = Module::money( $id );
		if ( $money ) {
			$ver = 'verified' === $m( 'amount_kind' );
			echo '<p class="wkt-money">' . esc_html( $money ) . '</p>' . $this->badge( $ver ? $this->t( 'verified' ) : $this->t( 'estimate' ), $ver ? 'ok' : 'warn' ); // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<dl class="wkt-dl"><div><dt>' . esc_html( $this->t( 'src' ) ) . '</dt><dd>' . esc_html( $m( 'amount_src' ) ?: $this->t( 'none' ) ) . '</dd></div><div><dt>' . esc_html( $this->t( 'date' ) ) . '</dt><dd>' . esc_html( $m( 'amount_date' ) ? date_i18n( 'd/m/Y', strtotime( $m( 'amount_date' ) ) ) : $this->t( 'none' ) ) . '</dd></div></dl>';
		} else {
			echo '<p class="wkt-muted">' . esc_html( $this->t( 'no_amt' ) ) . '</p>';
		}
		echo '</section><section class="wkt-card"><h2 class="wkt-h">' . esc_html( $this->t( 'location' ) ) . '</h2>';
		if ( $m( 'location' ) ) { echo '<p>' . esc_html( $m( 'location' ) ) . '</p>'; }
		if ( 'yes' === $m( 'geo_ok' ) && is_numeric( $m( 'lat' ) ) && is_numeric( $m( 'lng' ) ) ) {
			echo '<p class="wkt-mono">' . esc_html( $m( 'lat' ) . ', ' . $m( 'lng' ) ) . '</p><p class="wkt-muted">' . esc_html( $this->t( 'src' ) . ': ' . ( $m( 'geo_source' ) ?: $this->t( 'none' ) ) ) . '</p>';
		} else {
			echo '<p class="wkt-muted">' . esc_html( $this->t( 'geo_no' ) ) . '</p>';
		}
		echo '</section><section class="wkt-card"><h2 class="wkt-h">' . esc_html( $this->t( 'docs' ) ) . '</h2>';
		$docs = $this->link_lines( $m( 'docs' ) );
		if ( $docs ) {
			echo '<ul class="wkt-links">';
			foreach ( $docs as $d ) { echo '<li>' . ( $d[1] ? '<a href="' . esc_url( $d[1] ) . '">' . esc_html( $d[0] ) . '</a>' : esc_html( $d[0] ) ) . '</li>'; } // phpcs:ignore WordPress.Security.EscapeOutput
			echo '</ul>';
		} else {
			echo '<p class="wkt-muted">' . esc_html( $this->t( 'no_docs' ) ) . '</p>';
		}
		if ( $m( 'source' ) ) { echo '<p class="wkt-small">' . esc_html( $this->t( 'f_source' ) . ': ' . $m( 'source' ) ) . '</p>'; }
		echo '</section>';
		$url = ! empty( $s['contact']['url'] ) ? $s['contact']['url'] : Module::page_url( 'cases' );
		if ( $url ) { echo '<a class="wkt-btn wkt-btn--block" href="' . esc_url( add_query_arg( 'proyecto', rawurlencode( $m( 'code' ) ?: (string) $id ), $url ) ) . '">' . esc_html( $this->t( 'contact' ) ) . '</a>'; }
		echo '<p class="wkt-small wkt-muted">' . esc_html( $this->t( 'note' ) ) . '</p></aside></div></article>';
	}
}
