<?php
/**
 * «Mis solicitudes» (panel del solicitante): own cases, status track, public messages,
 * private documents and replies. Internal notes never reach this panel.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

defined( 'ABSPATH' ) || die();

class W_Cases extends Base {

	public function get_name() { return 'wakoo-t-cases'; }
	public function get_title() { return __( 'Ventanilla: panel del solicitante (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-folder-o'; }
	public function get_keywords() { return [ 'ventanilla', 'expediente', 'panel', 'solicitudes', 'seguimiento', 'wakoo' ]; }

	protected function texts() {
		return [
			'login'    => [ __( 'Sin sesión', 'wakoo' ), __( 'Inicie sesión para ver sus solicitudes y su expediente.', 'wakoo' ) ],
			'mine'     => [ __( 'Título: mis solicitudes', 'wakoo' ), __( 'Mis solicitudes', 'wakoo' ) ],
			'none'     => [ __( 'Sin solicitudes', 'wakoo' ), __( 'Aún no ha presentado ninguna iniciativa.', 'wakoo' ) ],
			'new'      => [ __( 'Botón: nueva', 'wakoo' ), __( 'Presentar una iniciativa', 'wakoo' ) ],
			'new_url'  => [ __( 'Enlace de «nueva» (URL)', 'wakoo' ), '' ],
			'code'     => [ __( 'Columna: código', 'wakoo' ), __( 'Código', 'wakoo' ) ],
			'name'     => [ __( 'Columna: iniciativa', 'wakoo' ), __( 'Iniciativa', 'wakoo' ) ],
			'status'   => [ __( 'Columna: estado', 'wakoo' ), __( 'Estado', 'wakoo' ) ],
			'date'     => [ __( 'Columna: fecha', 'wakoo' ), __( 'Registrada', 'wakoo' ) ],
			'open'     => [ __( 'Enlace: abrir', 'wakoo' ), __( 'Abrir expediente', 'wakoo' ) ],
			'history'  => [ __( 'Título: historial', 'wakoo' ), __( 'Historial y mensajes', 'wakoo' ) ],
			'docs'     => [ __( 'Título: documentos', 'wakoo' ), __( 'Documentos del expediente', 'wakoo' ) ],
			'no_docs'  => [ __( 'Sin documentos', 'wakoo' ), __( 'Sin documentos.', 'wakoo' ) ],
			'reqs'     => [ __( 'Título: requisitos', 'wakoo' ), __( 'Requisitos recibidos', 'wakoo' ) ],
			'reply'    => [ __( 'Título: responder', 'wakoo' ), __( 'Escribir al equipo o añadir documentos', 'wakoo' ) ],
			'message'  => [ __( 'Campo: mensaje', 'wakoo' ), __( 'Mensaje', 'wakoo' ) ],
			'add_docs' => [ __( 'Campo: documentos', 'wakoo' ), __( 'Documentos', 'wakoo' ) ],
			'send'     => [ __( 'Botón: enviar', 'wakoo' ), __( 'Enviar', 'wakoo' ) ],
			'closed'   => [ __( 'Expediente cerrado', 'wakoo' ), __( 'Este expediente está cerrado. Si necesita retomarlo, presente una nueva solicitud indicando este código.', 'wakoo' ) ],
			'you'      => [ __( 'Autor: usted', 'wakoo' ), __( 'Usted', 'wakoo' ) ],
			'team'     => [ __( 'Autor: equipo', 'wakoo' ), __( 'Ventanilla', 'wakoo' ) ],
			'back'     => [ __( 'Enlace: volver', 'wakoo' ), __( 'Todas mis solicitudes', 'wakoo' ) ],
			'note'     => [ __( 'Aviso', 'wakoo' ), __( 'La ventanilla registra, orienta y hace seguimiento. Los permisos y autorizaciones los otorgan los organismos competentes.', 'wakoo' ) ],
		];
	}

	protected function render() {
		echo '<div class="wkt wkt-cases">';
		$this->notice();
		if ( ! is_user_logged_in() ) { $this->login_box( $this->t( 'login' ) ); echo '</div>'; return; }
		$uid  = get_current_user_id();
		$open = (int) $this->get( 'expediente' );
		$p    = $open ? get_post( $open ) : null;
		if ( $p && Module::CASE_T === $p->post_type && (int) $p->post_author === $uid ) {
			$this->detail( $p );
			echo '</div>';
			return;
		}
		$list = get_posts( [ 'post_type' => Module::CASE_T, 'post_status' => [ 'private', 'publish' ], 'author' => $uid, 'numberposts' => 100 ] );
		$new  = $this->t( 'new_url' ) ?: Module::page_url( 'cases_new' );
		echo '<div class="wkt-bar"><h2 class="wkt-h">' . esc_html( $this->t( 'mine' ) ) . '</h2>' . ( $new ? '<a class="wkt-btn" href="' . esc_url( $new ) . '">' . esc_html( $this->t( 'new' ) ) . '</a>' : '' ) . '</div>';
		if ( ! $list ) { echo '<div class="wkt-empty">' . esc_html( $this->t( 'none' ) ) . '</div></div>'; return; }
		$st = Module::statuses();
		echo '<div class="wkt-table-wrap"><table class="wkt-table"><thead><tr><th scope="col">' . esc_html( $this->t( 'code' ) ) . '</th><th scope="col">' . esc_html( $this->t( 'name' ) ) . '</th><th scope="col">' . esc_html( $this->t( 'status' ) ) . '</th><th scope="col">' . esc_html( $this->t( 'date' ) ) . '</th><th scope="col"><span class="screen-reader-text">' . esc_html( $this->t( 'open' ) ) . '</span></th></tr></thead><tbody>';
		foreach ( $list as $c ) {
			$k = Module::meta( $c->ID, 'status' );
			echo '<tr><td class="wkt-mono">' . esc_html( Module::meta( $c->ID, 'code' ) ) . '</td><td>' . esc_html( $c->post_title ) . '</td><td>' . $this->badge( $st[ $k ][0] ?? $k, ! empty( $st[ $k ][1] ) ? 'soft' : 'info' ) . '</td><td>' . esc_html( get_the_date( 'd/m/Y', $c ) ) . '</td><td><a href="' . esc_url( add_query_arg( 'expediente', $c->ID, $this->here() ) ) . '">' . esc_html( $this->t( 'open' ) ) . '</a></td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</tbody></table></div><p class="wkt-small wkt-muted">' . esc_html( $this->t( 'note' ) ) . '</p></div>';
	}

	private function detail( $p ) {
		$st   = Module::statuses();
		$cur  = Module::meta( $p->ID, 'status' );
		$keys = array_keys( $st );
		$pos  = array_search( $cur, $keys, true );
		echo '<p><a href="' . esc_url( remove_query_arg( 'expediente', $this->here() ) ) . '">← ' . esc_html( $this->t( 'back' ) ) . '</a></p>';
		echo '<header class="wkt-sheet__head"><p class="wkt-sheet__meta"><span class="wkt-code">' . esc_html( Module::meta( $p->ID, 'code' ) ) . '</span>' . $this->badge( $st[ $cur ][0] ?? $cur, 'info' ) . '</p><h2 class="wkt-sheet__title">' . esc_html( $p->post_title ) . '</h2></header>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<div class="wkt-track"><ol>';
		foreach ( $st as $k => $d ) {
			$i = array_search( $k, $keys, true );
			echo '<li class="' . esc_attr( $i < $pos ? 'is-done' : ( $i === $pos ? 'is-now' : '' ) ) . '"' . ( $i === $pos ? ' aria-current="step"' : '' ) . '><span>' . esc_html( $d[0] ) . '</span></li>';
		}
		echo '</ol></div><div class="wkt-sheet__body"><div class="wkt-sheet__main"><h3 class="wkt-h">' . esc_html( $this->t( 'history' ) ) . '</h3><ol class="wkt-timeline">';
		foreach ( array_reverse( Store::lines( Module::CASE_T, $p->ID, [ 'public' ] ) ) as $l ) {
			$mine = (int) $l->user_id === (int) $p->post_author && 'applicant' === $l->kind;
			echo '<li class="' . ( $mine ? 'is-you' : 'is-team' ) . '"><p class="wkt-timeline__meta">' . esc_html( ( $mine ? $this->t( 'you' ) : $this->t( 'team' ) ) . ' · ' . get_date_from_gmt( $l->created, 'd/m/Y H:i' ) ) . '</p><p>' . nl2br( esc_html( $l->message ) ) . '</p></li>';
		}
		echo '</ol>';
		if ( ! empty( $st[ $cur ][1] ) ) {
			echo '<p class="wkt-callout">' . esc_html( $this->t( 'closed' ) ) . '</p>';
		} else {
			echo '<h3 class="wkt-h">' . esc_html( $this->t( 'reply' ) ) . '</h3>';
			$this->form_open( 'reply', true );
			echo '<input type="hidden" name="case" value="' . (int) $p->ID . '">';
			$this->field( 'message', $this->t( 'message' ), 'textarea', [ 'rows' => 4 ] );
			$this->field( 'docs', $this->t( 'add_docs' ), 'file' );
			echo '<button class="wkt-btn" type="submit">' . esc_html( $this->t( 'send' ) ) . '</button></form>';
		}
		echo '</div><aside class="wkt-sheet__side"><section class="wkt-card"><h3 class="wkt-h">' . esc_html( $this->t( 'docs' ) ) . '</h3>';
		$files = Store::files( $p->ID );
		if ( $files ) {
			echo '<ul class="wkt-links">';
			foreach ( $files as $f ) { echo '<li><a href="' . esc_url( Store::download_url( $p->ID, $f['id'] ) ) . '">' . esc_html( $f['name'] ) . '</a> <small>' . esc_html( size_format( $f['size'] ) ) . '</small></li>'; }
			echo '</ul>';
		} else {
			echo '<p class="wkt-muted">' . esc_html( $this->t( 'no_docs' ) ) . '</p>';
		}
		$done = array_map( 'intval', (array) Module::meta( $p->ID, 'checklist', [] ) );
		echo '</section><section class="wkt-card"><h3 class="wkt-h">' . esc_html( $this->t( 'reqs' ) ) . '</h3><ul class="wkt-checks">';
		foreach ( Module::requirements() as $i => $r ) { echo '<li class="' . ( in_array( $i, $done, true ) ? 'is-ok' : '' ) . '">' . esc_html( $r ) . '</li>'; }
		echo '</ul></section></aside></div>';
	}
}
