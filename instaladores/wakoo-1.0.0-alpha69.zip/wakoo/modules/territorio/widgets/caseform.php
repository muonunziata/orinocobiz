<?php
/**
 * «Presentar una iniciativa» (ventanilla única): registers an initiative with a unique code,
 * classification, private documents and consent. Records and guides; never approves.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

defined( 'ABSPATH' ) || die();

class W_CaseForm extends Base {

	public function get_name() { return 'wakoo-t-caseform'; }
	public function get_title() { return __( 'Ventanilla: presentar iniciativa (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-form-horizontal'; }
	public function get_keywords() { return [ 'ventanilla', 'inversionista', 'solicitud', 'expediente', 'formulario', 'wakoo' ]; }

	protected function texts() {
		return [
			'login'    => [ __( 'Sin sesión', 'wakoo' ), __( 'Para presentar una iniciativa necesita una cuenta. Así podrá seguir su expediente, recibir mensajes y añadir documentos.', 'wakoo' ) ],
			'title'    => [ __( 'Campo: nombre de la iniciativa', 'wakoo' ), __( 'Nombre de la iniciativa', 'wakoo' ) ],
			'promoter' => [ __( 'Campo: promotor', 'wakoo' ), __( 'Empresa o promotor', 'wakoo' ) ],
			'contact'  => [ __( 'Campo: contacto', 'wakoo' ), __( 'Teléfono de contacto (opcional)', 'wakoo' ) ],
			'kind'     => [ __( 'Campo: tipo', 'wakoo' ), __( 'Tipo de iniciativa', 'wakoo' ) ],
			'kinds'    => [ __( 'Tipos (uno por línea)', 'wakoo' ), "Nueva inversión productiva\nAmpliación de una actividad existente\nServicios para la industria o la energía\nEmprendimiento o cooperativa\nInterés en un proyecto de la cartera\nOtra" ],
			'sector'   => [ __( 'Campo: sector', 'wakoo' ), __( 'Sector', 'wakoo' ) ],
			'mun'      => [ __( 'Campo: municipio', 'wakoo' ), __( 'Municipio', 'wakoo' ) ],
			'mun_none' => [ __( 'Municipio sin definir', 'wakoo' ), __( 'Aún no definido', 'wakoo' ) ],
			'sec_pick' => [ __( 'Elegir sector', 'wakoo' ), __( 'Elija un sector', 'wakoo' ) ],
			'maturity' => [ __( 'Campo: madurez', 'wakoo' ), __( 'Grado de preparación', 'wakoo' ) ],
			'location' => [ __( 'Campo: localización', 'wakoo' ), __( 'Localización propuesta (si existe)', 'wakoo' ) ],
			'amount'   => [ __( 'Campo: inversión', 'wakoo' ), __( 'Inversión preliminar estimada (opcional)', 'wakoo' ) ],
			'currency' => [ __( 'Campo: moneda', 'wakoo' ), __( 'Moneda', 'wakoo' ) ],
			'jobs'     => [ __( 'Campo: empleos', 'wakoo' ), __( 'Empleos directos estimados (opcional)', 'wakoo' ) ],
			'services' => [ __( 'Campo: servicios', 'wakoo' ), __( 'Servicios que necesitaría (electricidad, agua, vialidad, telecomunicaciones, terreno…)', 'wakoo' ) ],
			'desc'     => [ __( 'Campo: descripción', 'wakoo' ), __( 'Descripción de la iniciativa (qué, para qué mercado, con qué recursos)', 'wakoo' ) ],
			'docs'     => [ __( 'Campo: documentos', 'wakoo' ), __( 'Documentos (opcional, hasta 5: PDF, Word, Excel o imágenes)', 'wakoo' ) ],
			'docs_h'   => [ __( 'Ayuda: documentos', 'wakoo' ), __( 'Se guardan en un expediente privado: solo usted y el equipo autorizado pueden verlos.', 'wakoo' ) ],
			'reqs'     => [ __( 'Título: requisitos', 'wakoo' ), __( 'Información que le pediremos durante la revisión', 'wakoo' ) ],
			'consent'  => [ __( 'Consentimiento', 'wakoo' ), __( 'Autorizo el tratamiento de estos datos para registrar, orientar y hacer seguimiento a mi iniciativa. Entiendo que la ventanilla no concede permisos ni aprueba proyectos.', 'wakoo' ) ],
			'send'     => [ __( 'Botón: enviar', 'wakoo' ), __( 'Registrar iniciativa', 'wakoo' ) ],
			'interest' => [ __( 'Título prellenado (%s = proyecto)', 'wakoo' ), __( 'Interés en el proyecto %s', 'wakoo' ) ],
		];
	}

	protected function render() {
		echo '<div class="wkt wkt-caseform">';
		$this->notice();
		if ( ! is_user_logged_in() && ! $this->in_editor() ) { $this->login_box( $this->t( 'login' ) ); echo '</div>'; return; }
		$old = Forms::old( 'case' );
		$prj = $this->get( 'proyecto' );
		$sec = $this->get( 'sector' );
		$sec_id = '';
		if ( $sec && ( $t = get_term_by( 'slug', sanitize_title( $sec ), Module::T_SECTOR ) ) ) { $sec_id = (string) $t->term_id; }
		$kinds = array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $this->t( 'kinds' ) ) ) );
		$this->form_open( 'case', true, 'wkt-grid-form' );
		$this->field( 'title', $this->t( 'title' ), 'text', [ 'required' => true, 'wide' => true, 'value' => $old['title'] ?? ( $prj ? sprintf( $this->t( 'interest' ), $prj ) : '' ), 'attr' => 'maxlength="180"' ] );
		$this->field( 'promoter', $this->t( 'promoter' ), 'text', [ 'required' => true, 'value' => $old['promoter'] ?? '', 'attr' => 'autocomplete="organization"' ] );
		$this->field( 'contact', $this->t( 'contact' ), 'tel', [ 'value' => $old['contact'] ?? '', 'attr' => 'autocomplete="tel"' ] );
		$this->field( 'kind', $this->t( 'kind' ), 'select', [ 'value' => $old['kind'] ?? ( $prj ? ( $kinds[4] ?? '' ) : '' ), 'options' => array_combine( $kinds, $kinds ) ] );
		$this->field( 'sector', $this->t( 'sector' ), 'select', [ 'required' => true, 'value' => $old['sector'] ?? $sec_id, 'options' => $this->term_options( Module::T_SECTOR, $this->t( 'sec_pick' ) ) ] );
		$this->field( 'municipio', $this->t( 'mun' ), 'select', [ 'value' => $old['municipio'] ?? '', 'options' => $this->term_options( Module::T_MUN, $this->t( 'mun_none' ) ) ] );
		$this->field( 'maturity', $this->t( 'maturity' ), 'select', [ 'value' => $old['maturity'] ?? 'conceptual', 'options' => array_slice( Module::stages(), 0, 4, true ) ] );
		$this->field( 'location', $this->t( 'location' ), 'text', [ 'value' => $old['location'] ?? '' ] );
		$this->field( 'amount', $this->t( 'amount' ), 'text', [ 'value' => $old['amount'] ?? '', 'attr' => 'inputmode="numeric"' ] );
		$this->field( 'currency', $this->t( 'currency' ), 'select', [ 'value' => $old['currency'] ?? 'USD', 'options' => [ 'USD' => 'USD', 'EUR' => 'EUR', 'VES' => 'VES' ] ] );
		$this->field( 'jobs', $this->t( 'jobs' ), 'number', [ 'value' => $old['jobs'] ?? '', 'attr' => 'min="0"' ] );
		$this->field( 'desc', $this->t( 'desc' ), 'textarea', [ 'required' => true, 'wide' => true, 'rows' => 7, 'value' => $old['desc'] ?? '', 'help' => __( 'Mínimo 40 caracteres.', 'wakoo' ), 'attr' => 'minlength="40"' ] );
		$this->field( 'services', $this->t( 'services' ), 'textarea', [ 'wide' => true, 'rows' => 3, 'value' => $old['services'] ?? '' ] );
		$this->field( 'docs', $this->t( 'docs' ), 'file', [ 'wide' => true, 'help' => $this->t( 'docs_h' ) ] );
		$reqs = Module::requirements();
		if ( $reqs ) {
			echo '<div class="wkt-field wkt-field--wide wkt-reqs"><p class="wkt-label">' . esc_html( $this->t( 'reqs' ) ) . '</p><ul>';
			foreach ( $reqs as $r ) { echo '<li>' . esc_html( $r ) . '</li>'; }
			echo '</ul></div>';
		}
		echo '<div class="wkt-field wkt-field--wide">';
		$this->check( 'consent', esc_html( $this->t( 'consent' ) ), false, true );
		echo '</div><div class="wkt-field wkt-field--wide"><button type="submit" class="wkt-btn">' . esc_html( $this->t( 'send' ) ) . '</button></div></form></div>';
	}
}
