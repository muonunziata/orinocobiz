<?php
/**
 * «Observatorio (Wakoo)»: indicator cards with their technical sheet (source, date, period,
 * owner, method, verification). Values come from the series typed by the analyst or are
 * computed live from the portal's own records. Test data never shows as official.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class W_Observatory extends Base {

	public function get_name() { return 'wakoo-t-observatory'; }
	public function get_title() { return __( 'Observatorio (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-dashboard'; }
	public function get_keywords() { return [ 'observatorio', 'indicadores', 'datos', 'gráficos', 'estadísticas', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-territorio', 'wakoo-territorio-obs' ]; }

	protected function controls() {
		$this->start_controls_section( 'sec_main', [ 'label' => __( 'Indicadores', 'wakoo' ) ] );
		$this->add_control( 'group', [ 'label' => __( 'Solo el grupo', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => '', 'options' => [ '' => __( 'Todos', 'wakoo' ), 'inversion' => __( 'Inversión', 'wakoo' ), 'proyectos' => __( 'Proyectos', 'wakoo' ), 'empleo' => __( 'Empleo y formación', 'wakoo' ), 'proveedores' => __( 'Proveedores y producción', 'wakoo' ), 'territorio' => __( 'Obras y servicios', 'wakoo' ), 'gestion' => __( 'Gestión institucional', 'wakoo' ) ] ] );
		$this->add_control( 'cols', [ 'label' => __( 'Columnas', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => '2', 'options' => [ '1' => '1', '2' => '2', '3' => '3' ], 'selectors' => [ '{{WRAPPER}} .wkt-obs__grid' => '--cols: {{VALUE}};' ] ] );
		$this->add_control( 'demo', [ 'label' => __( 'Mostrar indicadores de prueba (marcados como tales)', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => '', 'description' => __( 'Solo para revisar el diseño. Déjelo apagado en el sitio publicado.', 'wakoo' ) ] );
		$this->end_controls_section();
	}

	protected function texts() {
		return [
			'empty'    => [ __( 'Sin indicadores', 'wakoo' ), __( 'El observatorio publicará cada indicador cuando tenga fuente, responsable y metodología definidos. Todavía no hay indicadores públicos.', 'wakoo' ) ],
			'nodata'   => [ __( 'Sin datos', 'wakoo' ), __( 'Sin datos publicados todavía', 'wakoo' ) ],
			'sheet'    => [ __( 'Ficha técnica', 'wakoo' ), __( 'Ficha técnica', 'wakoo' ) ],
			'source'   => [ __( 'Fuente', 'wakoo' ), __( 'Fuente', 'wakoo' ) ],
			'updated'  => [ __( 'Actualización', 'wakoo' ), __( 'Actualización', 'wakoo' ) ],
			'period'   => [ __( 'Periodicidad', 'wakoo' ), __( 'Periodicidad', 'wakoo' ) ],
			'owner'    => [ __( 'Responsable', 'wakoo' ), __( 'Responsable', 'wakoo' ) ],
			'method'   => [ __( 'Metodología', 'wakoo' ), __( 'Metodología', 'wakoo' ) ],
			'check'    => [ __( 'Verificación', 'wakoo' ), __( 'Verificación', 'wakoo' ) ],
			'unit'     => [ __( 'Unidad', 'wakoo' ), __( 'Unidad', 'wakoo' ) ],
			'live'     => [ __( 'Dato automático', 'wakoo' ), __( 'Calculado en tiempo real con los registros del portal', 'wakoo' ) ],
			'demo'     => [ __( 'Aviso de prueba', 'wakoo' ), __( 'DATOS DE PRUEBA: no son cifras oficiales', 'wakoo' ) ],
			'unverif'  => [ __( 'Valor no verificado', 'wakoo' ), __( 'valor no verificado', 'wakoo' ) ],
			'days'     => [ __( 'Unidad: días', 'wakoo' ), __( 'días', 'wakoo' ) ],
			'table'    => [ __( 'Tabla de datos', 'wakoo' ), __( 'Ver los datos en tabla', 'wakoo' ) ],
			'col_p'    => [ __( 'Columna: periodo', 'wakoo' ), __( 'Periodo', 'wakoo' ) ],
			'col_v'    => [ __( 'Columna: valor', 'wakoo' ), __( 'Valor', 'wakoo' ) ],
		];
	}

	/** [ labels[], values[], verified[] ] of an indicator. */
	private function data( $id ) {
		$auto = (string) Module::meta( $id, 'auto' );
		if ( $auto ) {
			$n = Admin::numbers( $auto );
			$names = [ 'stages' => Module::stages(), 'cases' => wp_list_pluck( Module::statuses(), 0 ), 'companies' => Module::levels() ];
			if ( 'response' === $auto ) {
				return null === $n['avg'] ? [ [], [], [] ] : [ [ $this->t( 'days' ) ], [ $n['avg'] ], [ true ] ];
			}
			if ( 'certs' === $auto ) { return [ [ get_the_title( $id ) ], [ (int) $n['certs'] ], [ true ] ]; }
			$l = [];
			foreach ( array_keys( $n ) as $k ) { $l[] = $names[ $auto ][ $k ] ?? $k; }
			return array_sum( $n ) ? [ $l, array_values( $n ), array_fill( 0, count( $n ), true ) ] : [ [], [], [] ];
		}
		$l = $v = $ok = [];
		foreach ( preg_split( '/\r\n|\r|\n/', (string) Module::meta( $id, 'series' ) ) as $line ) {
			$p = array_map( 'trim', explode( ';', $line ) );
			if ( count( $p ) < 2 || '' === $p[0] || ! is_numeric( str_replace( ',', '.', $p[1] ) ) ) { continue; }
			$l[]  = $p[0];
			$v[]  = (float) str_replace( ',', '.', $p[1] );
			$ok[] = in_array( strtolower( $p[2] ?? '' ), [ 'si', 'sí', 'yes', '1', 'verificado' ], true );
		}
		return [ $l, $v, $ok ];
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$args = [ 'post_type' => Module::IND, 'post_status' => 'publish', 'numberposts' => 100, 'orderby' => [ 'menu_order' => 'ASC', 'title' => 'ASC' ] ];
		$list = array_filter( get_posts( $args ), function ( $p ) use ( $s ) {
			if ( 'yes' !== Module::meta( $p->ID, 'public' ) ) { return false; }
			if ( 'yes' === Module::meta( $p->ID, 'demo' ) && 'yes' !== ( $s['demo'] ?? '' ) ) { return false; }
			return ! $s['group'] || Module::meta( $p->ID, 'group' ) === $s['group'];
		} );
		echo '<div class="wkt wkt-obs">';
		if ( ! $list ) { echo '<div class="wkt-empty">' . esc_html( $this->t( 'empty' ) ) . '</div></div>'; return; }
		echo '<div class="wkt-obs__grid">';
		foreach ( $list as $p ) {
			[ $labels, $values, $ok ] = $this->data( $p->ID );
			$demo  = 'yes' === Module::meta( $p->ID, 'demo' );
			$check = Module::meta( $p->ID, 'check', 'pendiente' );
			$auto  = (bool) Module::meta( $p->ID, 'auto' );
			$unit  = (string) Module::meta( $p->ID, 'unit' );
			$chart = Module::meta( $p->ID, 'chart', 'line' );
			echo '<article class="wkt-card wkt-ind' . ( $demo ? ' is-demo' : '' ) . '">';
			if ( $demo ) { echo '<p class="wkt-ind__demo" role="note">' . esc_html( $this->t( 'demo' ) ) . '</p>'; }
			echo '<header class="wkt-ind__head"><h3 class="wkt-ind__t">' . esc_html( $p->post_title ) . '</h3>' . $this->badge( Module::checks()[ $check ] ?? $check, 'verificado' === $check ? 'ok' : 'warn' ) . '</header>'; // phpcs:ignore WordPress.Security.EscapeOutput
			if ( $p->post_excerpt ) { echo '<p class="wkt-muted wkt-small">' . esc_html( $p->post_excerpt ) . '</p>'; }
			if ( ! $values ) {
				echo '<p class="wkt-ind__none">' . esc_html( $this->t( 'nodata' ) ) . '</p>';
			} else {
				$last = count( $values ) - 1;
				$num  = ( in_array( $chart, [ 'doughnut', 'bar' ], true ) && $auto ) ? array_sum( $values ) : $values[ $last ];
				echo '<p class="wkt-ind__value"><strong>' . esc_html( number_format_i18n( $num, floor( $num ) == $num ? 0 : 1 ) ) . '</strong> <span>' . esc_html( $unit ) . '</span>';
				if ( ! $auto ) { echo ' <span class="wkt-muted wkt-small">' . esc_html( $labels[ $last ] ) . ( $ok[ $last ] ? '' : ' · ' . esc_html( $this->t( 'unverif' ) ) ) . '</span>'; }
				echo '</p>';
				if ( 'none' !== $chart && count( $values ) > 1 ) {
					$cfg = [ 'type' => $chart, 'labels' => $labels, 'values' => $values, 'ok' => $ok, 'unit' => $unit, 'demo' => $demo ];
					echo '<div class="wkt-ind__chart"><canvas data-wkt-chart="' . esc_attr( wp_json_encode( $cfg ) ) . '" role="img" aria-label="' . esc_attr( $p->post_title ) . '"></canvas></div>';
					echo '<details class="wkt-more"><summary>' . esc_html( $this->t( 'table' ) ) . '</summary><table class="wkt-table"><thead><tr><th scope="col">' . esc_html( $this->t( 'col_p' ) ) . '</th><th scope="col">' . esc_html( $this->t( 'col_v' ) ) . '</th></tr></thead><tbody>';
					foreach ( $values as $i => $v ) { echo '<tr><td>' . esc_html( $labels[ $i ] ) . '</td><td>' . esc_html( number_format_i18n( $v, floor( $v ) == $v ? 0 : 2 ) . ( $ok[ $i ] ? '' : ' (' . $this->t( 'unverif' ) . ')' ) ) . '</td></tr>'; }
					echo '</tbody></table></details>';
				}
			}
			echo '<details class="wkt-more"><summary>' . esc_html( $this->t( 'sheet' ) ) . '</summary><dl class="wkt-dl">';
			if ( $auto ) { echo '<div><dt>' . esc_html( $this->t( 'source' ) ) . '</dt><dd>' . esc_html( $this->t( 'live' ) ) . '</dd></div>'; }
			foreach ( [ 'unit', 'source', 'updated', 'period', 'owner', 'method' ] as $k ) {
				$v = (string) Module::meta( $p->ID, $k );
				if ( '' === $v || ( $auto && 'source' === $k ) ) { continue; }
				if ( 'updated' === $k ) { $v = date_i18n( 'd/m/Y', strtotime( $v ) ); }
				echo '<div><dt>' . esc_html( $this->t( $k ) ) . '</dt><dd>' . esc_html( $v ) . '</dd></div>';
			}
			echo '<div><dt>' . esc_html( $this->t( 'check' ) ) . '</dt><dd>' . esc_html( Module::checks()[ $check ] ?? $check ) . '</dd></div></dl></details></article>';
		}
		echo '</div></div>';
	}
}
