/* Wakoo Territorio: small front helpers (accessible form validation). */
( function () {
	'use strict';
	function boot( root ) {
		( root || document ).querySelectorAll( '.wkt-form' ).forEach( function ( f ) {
			if ( f.dataset.wktReady ) { return; }
			f.dataset.wktReady = '1';
			f.addEventListener( 'submit', function ( e ) {
				var bad = Array.prototype.filter.call( f.querySelectorAll( '[required]' ), function ( el ) {
					if ( el.type === 'checkbox' ) { return ! el.checked; }
					if ( el.type === 'radio' ) { return ! f.querySelector( 'input[name="' + el.name + '"]:checked' ); }
					return ! String( el.value || '' ).trim();
				} );
				f.querySelectorAll( '[aria-invalid]' ).forEach( function ( el ) { el.removeAttribute( 'aria-invalid' ); } );
				if ( bad.length ) {
					e.preventDefault();
					bad.forEach( function ( el ) { el.setAttribute( 'aria-invalid', 'true' ); } );
					bad[0].focus();
					return;
				}
				var b = f.querySelector( 'button[type="submit"]' );
				if ( b ) { setTimeout( function () { b.disabled = true; }, 0 ); }
			} );
		} );
	}
	document.addEventListener( 'DOMContentLoaded', function () { boot(); } );
	window.addEventListener( 'elementor/frontend/init', function () {
		if ( window.elementorFrontend && elementorFrontend.hooks ) {
			elementorFrontend.hooks.addAction( 'frontend/element_ready/global', function ( $el ) { boot( $el[0] ); } );
		}
	} );
} )();
