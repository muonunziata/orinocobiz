/* Wakoo Territorio: observatory charts (Chart.js 2.9, bundled). Unverified points are drawn
   hollow; test data is drawn in grey with a dashed line. */
( function () {
	'use strict';
	var NAVY = '#10355B', BLUE = '#174A7E', GOLD = '#C5A15B', GREY = '#8A96A5';
	var PALETTE = [ NAVY, GOLD, BLUE, '#5B7FA6', '#9C7B3C', '#2F6A86', '#B5BFCB' ];
	function boot( root ) {
		if ( ! window.Chart ) { return; }
		( root || document ).querySelectorAll( '[data-wkt-chart]' ).forEach( function ( c ) {
			if ( c.dataset.wktReady ) { return; }
			c.dataset.wktReady = '1';
			var d = JSON.parse( c.getAttribute( 'data-wkt-chart' ) || '{}' );
			var color = d.demo ? GREY : NAVY;
			var reduce = window.matchMedia && matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
			var ds = { data: d.values, label: d.unit || '' };
			if ( d.type === 'doughnut' ) {
				ds.backgroundColor = d.values.map( function ( v, i ) { return d.demo ? GREY : PALETTE[ i % PALETTE.length ]; } );
				ds.borderColor = '#fff';
			} else if ( d.type === 'bar' ) {
				ds.backgroundColor = d.values.map( function ( v, i ) { return d.ok[ i ] ? color : 'rgba(16,53,91,.25)'; } );
			} else {
				ds.borderColor = color;
				ds.backgroundColor = 'rgba(23,74,126,.08)';
				ds.borderDash = d.demo ? [ 6, 4 ] : [];
				ds.pointBackgroundColor = d.ok.map( function ( ok ) { return ok ? GOLD : '#fff'; } );
				ds.pointBorderColor = d.ok.map( function () { return color; } );
				ds.pointRadius = 4;
				ds.lineTension = .25;
				ds.fill = true;
			}
			new Chart( c.getContext( '2d' ), {
				type: d.type || 'line',
				data: { labels: d.labels, datasets: [ ds ] },
				options: {
					responsive: true, maintainAspectRatio: false,
					animation: reduce ? false : { duration: 900 },
					legend: { display: d.type === 'doughnut', position: 'bottom', labels: { fontColor: '#1C2733', boxWidth: 12 } },
					scales: d.type === 'doughnut' ? {} : {
						xAxes: [ { gridLines: { display: false }, ticks: { fontColor: '#465363' } } ],
						yAxes: [ { gridLines: { color: 'rgba(70,83,99,.12)' }, ticks: { fontColor: '#465363', beginAtZero: true } } ]
					},
					tooltips: { callbacks: { label: function ( item, data ) {
						var v = data.datasets[0].data[ item.index ];
						return ' ' + Number( v ).toLocaleString() + ( d.unit ? ' ' + d.unit : '' );
					} } }
				}
			} );
		} );
	}
	document.addEventListener( 'DOMContentLoaded', function () { boot(); } );
	window.addEventListener( 'elementor/frontend/init', function () {
		if ( window.elementorFrontend && elementorFrontend.hooks ) {
			elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-t-observatory.default', function ( $el ) { boot( $el[0] ); } );
		}
	} );
} )();
