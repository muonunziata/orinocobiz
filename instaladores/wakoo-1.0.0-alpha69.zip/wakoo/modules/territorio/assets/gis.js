/* Wakoo Territorio: map (Leaflet). Only draws what the server sends: public layers and
   projects with a verified location. */
( function () {
	'use strict';
	function esc( s ) { return String( s == null ? '' : s ).replace( /[&<>"']/g, function ( c ) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ c ]; } ); }
	function popup( f, t ) {
		var h = '<strong>' + esc( f.name ) + '</strong>';
		if ( f.stage ) { h += '<div>' + esc( f.stage ) + '</div>'; }
		if ( f.desc ) { h += '<div>' + esc( f.desc ) + '</div>'; }
		h += '<div><em>' + esc( f.ok ? t.ok : t.ko ) + '</em></div>';
		if ( f.src ) { h += '<div>' + esc( t.src ) + ': ' + esc( f.src ) + ( f.date ? ' (' + esc( f.date ) + ')' : '' ) + '</div>'; }
		if ( f.url ) { h += '<div><a href="' + esc( f.url ) + '">' + esc( t.more ) + '</a></div>'; }
		return h;
	}
	function pin( color ) {
		return L.divIcon( { className: '', html: '<span class="wkt-gis__pin" style="--c:' + esc( color ) + '"></span>', iconSize: [ 18, 18 ], iconAnchor: [ 9, 9 ] } );
	}
	function boot( root ) {
		( root || document ).querySelectorAll( '[data-wkt-gis]' ).forEach( function ( w ) {
			if ( w.dataset.wktReady || ! window.L ) { return; }
			w.dataset.wktReady = '1';
			var cfg = JSON.parse( w.getAttribute( 'data-wkt-gis' ) || '{}' );
			var box = w.querySelector( '.wkt-gis__map' );
			var map = L.map( box, { scrollWheelZoom: false } ).setView( cfg.center || [ 0, 0 ], cfg.zoom || 8 );
			box.addEventListener( 'focus', function () { map.scrollWheelZoom.enable(); } );
			box.addEventListener( 'blur', function () { map.scrollWheelZoom.disable(); } );
			L.tileLayer( cfg.tiles, { attribution: cfg.attr, maxZoom: 18 } ).addTo( map );
			var t = cfg.i18n || {}, toggles = w.querySelector( '[data-wkt-gis-toggles]' ), bounds = [];
			function add( layer, group ) {
				map.addLayer( group );
				var id = 'wkt-l-' + Math.random().toString( 36 ).slice( 2 );
				var lab = document.createElement( 'label' );
				lab.innerHTML = '<input type="checkbox" checked id="' + id + '"><span class="wkt-gis__sw" style="background:' + esc( layer.color ) + '"></span><span>' + esc( layer.name ) + ' (' + layer.items.length + ')</span>';
				lab.querySelector( 'input' ).addEventListener( 'change', function ( e ) { e.target.checked ? map.addLayer( group ) : map.removeLayer( group ); } );
				toggles.appendChild( lab );
			}
			( cfg.layers || [] ).forEach( function ( layer ) {
				var g = L.featureGroup();
				layer.items.forEach( function ( f ) {
					var m = f.geo ? L.geoJSON( f.geo, { style: { color: layer.color, weight: 3, fillOpacity: .15 }, pointToLayer: function ( p, ll ) { return L.marker( ll, { icon: pin( layer.color ) } ); } } ) : L.marker( f.pt, { icon: pin( layer.color ), title: f.name, alt: f.name } );
					m.bindPopup( popup( f, t ) ).addTo( g );
				} );
				add( layer, g );
				bounds.push( g.getBounds() );
			} );
			var proj = null, sel = w.querySelector( '[data-wkt-gis-sector]' );
			function drawProjects() {
				if ( ! cfg.projects ) { return; }
				var keep = sel ? sel.value : '';
				if ( proj ) { proj.clearLayers(); } else { proj = L.featureGroup(); add( cfg.projects, proj ); }
				cfg.projects.items.forEach( function ( f ) {
					if ( keep && ( f.sectors || [] ).indexOf( keep ) < 0 ) { return; }
					L.marker( f.pt, { icon: pin( cfg.projects.color ), title: f.name, alt: f.name } ).bindPopup( popup( f, t ) ).addTo( proj );
				} );
			}
			drawProjects();
			if ( proj && proj.getLayers().length ) { bounds.push( proj.getBounds() ); }
			if ( sel ) { sel.addEventListener( 'change', drawProjects ); }
			var all = bounds.filter( function ( b ) { return b && b.isValid(); } );
			if ( all.length ) {
				var b = all[0];
				all.slice( 1 ).forEach( function ( x ) { b.extend( x ); } );
				map.fitBounds( b, { padding: [ 30, 30 ], maxZoom: 12 } );
			}
			if ( 'ResizeObserver' in window ) { new ResizeObserver( function () { map.invalidateSize(); } ).observe( box ); }
		} );
	}
	document.addEventListener( 'DOMContentLoaded', function () { boot(); } );
	window.addEventListener( 'elementor/frontend/init', function () {
		if ( window.elementorFrontend && elementorFrontend.hooks ) {
			elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-t-gis.default', function ( $el ) { boot( $el[0] ); } );
		}
	} );
} )();
