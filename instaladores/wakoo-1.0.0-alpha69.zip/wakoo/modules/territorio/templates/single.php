<?php
/**
 * Single project / company / course without a chosen template: the theme's header and
 * footer around the matching sheet widget.
 *
 * @package Wakoo
 */

defined( 'ABSPATH' ) || die();

$wakoo_w = [ 'wakoo_project' => 'wakoo-t-project', 'wakoo_company' => 'wakoo-t-company', 'wakoo_course' => 'wakoo-t-course' ][ get_post_type() ] ?? '';
get_header();
echo '<main id="content" class="wkt-single">';
if ( 'wakoo_course' === get_post_type() ) { the_title( '<h1 class="wkt-single__title">', '</h1>' ); }
if ( $wakoo_w && class_exists( '\Elementor\Plugin' ) ) {
	$wakoo_el = \Elementor\Plugin::$instance->elements_manager->create_element_instance( [ 'id' => 'wktsheet', 'elType' => 'widget', 'widgetType' => $wakoo_w, 'settings' => [] ] );
	if ( $wakoo_el ) {
		\Elementor\Plugin::$instance->frontend->enqueue_styles();
		$wakoo_el->print_element();
	}
}
echo '</main>';
get_footer();
