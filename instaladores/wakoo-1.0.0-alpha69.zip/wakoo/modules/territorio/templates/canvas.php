<?php
/**
 * Single project / company / course drawn by the template chosen in Territorio → Ajustes
 * (blank canvas: the template brings its own header, sheet widget and footer).
 *
 * @package Wakoo
 */

defined( 'ABSPATH' ) || die();

$wakoo_tpl = (int) ( $GLOBALS['wakoo_t_tpl'] ?? 0 );
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class( 'elementor-template-canvas wakoo-territorio-page' ); ?>>
<?php
wp_body_open();
echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $wakoo_tpl, true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
wp_footer();
?>
</body>
</html>
