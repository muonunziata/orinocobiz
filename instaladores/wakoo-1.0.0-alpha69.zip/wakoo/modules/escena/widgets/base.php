<?php
/**
 * Shared helpers for the Escena widgets.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Escena\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Wakoo\Modules\Escena\Module;

defined( 'ABSPATH' ) || die();

abstract class Base extends Widget_Base {

	public function get_categories() { return [ 'wakoo-escena' ]; }
	public function get_style_depends() { return [ 'wakoo-escena' ]; }
	public function get_script_depends() { return [ 'wakoo-escena' ]; }
	public function has_widget_inner_wrapper(): bool { return false; }

	/** href + target + rel for a URL control value. */
	protected function href( $link, $fallback = '#' ) {
		$url = is_array( $link ) && ! empty( $link['url'] ) ? $link['url'] : $fallback;
		$out = ' href="' . esc_url( $url ) . '"';
		if ( is_array( $link ) && ! empty( $link['is_external'] ) ) {
			$out .= ' target="_blank"';
		}
		$rel = [];
		if ( is_array( $link ) && ! empty( $link['nofollow'] ) ) {
			$rel[] = 'nofollow';
		}
		if ( is_array( $link ) && ! empty( $link['is_external'] ) ) {
			$rel[] = 'noopener';
		}
		if ( $rel ) {
			$out .= ' rel="' . implode( ' ', $rel ) . '"';
		}
		return $out;
	}

	/** URL of a MEDIA control, falling back to a bundled image. */
	protected function media( $value, $fallback = '' ) {
		if ( is_array( $value ) && ! empty( $value['url'] ) ) {
			return $value['url'];
		}
		return $fallback ? Module::img( $fallback ) : '';
	}

	protected function media_default( $file ) {
		return [ 'url' => Module::img( $file ), 'id' => '' ];
	}

	protected function icon( $icon ) {
		if ( empty( $icon['value'] ) ) {
			return '';
		}
		ob_start();
		Icons_Manager::render_icon( $icon, [ 'aria-hidden' => 'true' ] );
		return ob_get_clean();
	}

	/** Small inline SVG icons used for fixed UI (arrows, play, search, menu). */
	protected static function svg( $name ) {
		$p = [
			'arrow'  => '<path d="M5 12h14M13 6l6 6-6 6"/>',
			'up'     => '<path d="M7 17 17 7M8 7h9v9"/>',
			'left'   => '<path d="M19 12H5M11 6l-6 6 6 6"/>',
			'play'   => '<path d="M8 5.5v13l11-6.5z" fill="currentColor" stroke="none"/>',
			'search' => '<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/>',
			'menu'   => '<path d="M4 7h16M4 12h16M4 17h16"/>',
			'close'  => '<path d="M6 6l12 12M18 6 6 18"/>',
			'plus'   => '<path d="M12 5v14M5 12h14"/>',
			'globe'  => '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.6 2.6 2.6 14.4 0 17M12 3.5c-2.6 2.6-2.6 14.4 0 17"/>',
		];
		return '<svg class="wk-esc-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . ( $p[ $name ] ?? '' ) . '</svg>';
	}

	/** Language switcher markup (also used inside the header). */
	protected function lang_switch_html( $style = 'pill' ) {
		$h = '<div class="wk-esc-lang wk-esc-lang--' . esc_attr( $style ) . '" role="group" aria-label="Idioma / Language / 语言">';
		foreach ( \Wakoo\Modules\Escena\Lang::SHORT as $l => $label ) {
			$h .= '<button type="button" class="wk-esc-lang__b" data-wk-set-lang="' . $l . '" lang="' . ( 'zh' === $l ? 'zh-CN' : $l ) . '">' . esc_html( $label ) . '</button>';
		}
		return $h . '</div>';
	}

	/** Glass style controls shared by the cards. */
	protected function glass_controls( $selector, $bg = 'rgba(255,255,255,0.42)', $label = '' ) {
		$this->start_controls_section( 'sec_glass', [
			'label' => $label ? $label : __( 'Vidrio', 'wakoo' ),
			'tab'   => Controls_Manager::TAB_STYLE,
		] );
		$this->add_control( 'glass_bg', [
			'label'     => __( 'Color del vidrio', 'wakoo' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => $bg,
			'selectors' => [ '{{WRAPPER}} ' . $selector => 'background-color: {{VALUE}};' ],
		] );
		$this->add_control( 'glass_blur', [
			'label'     => __( 'Desenfoque (px)', 'wakoo' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => [ 'px' => [ 'min' => 0, 'max' => 40 ] ],
			'default'   => [ 'size' => 18, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} ' . $selector => '-webkit-backdrop-filter: blur({{SIZE}}px) saturate(1.2); backdrop-filter: blur({{SIZE}}px) saturate(1.2);' ],
		] );
		$this->add_control( 'glass_text', [
			'label'     => __( 'Color del texto', 'wakoo' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} ' . $selector => '--wk-esc-ink: {{VALUE}};' ],
		] );
		$this->end_controls_section();
	}
}
