<?php
/**
 * Escena: row/grid of glass cards (services, values, team). Icon or round photo, title, text, link.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Escena\Widgets;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Wakoo\Modules\Escena\Lang;

defined( 'ABSPATH' ) || die();

class Cards extends Base {

	public function get_name() { return 'wakoo-esc-cards'; }
	public function get_title() { return __( 'Tarjetas de vidrio (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-gallery-grid'; }
	public function get_keywords() { return [ 'wakoo', 'escena', 'tarjetas', 'servicios', 'equipo', 'cards', 'vidrio' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_cards', [ 'label' => __( 'Tarjetas', 'wakoo' ) ] );
		$this->add_control( 'mode', [
			'label'   => __( 'Imagen de cada tarjeta', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'icon',
			'options' => [ 'icon' => __( 'Icono', 'wakoo' ), 'photo' => __( 'Foto redonda (equipo)', 'wakoo' ), 'cover' => __( 'Foto de fondo', 'wakoo' ) ],
		] );
		$r = new Repeater();
		$r->add_control( 'icon', [ 'label' => __( 'Icono', 'wakoo' ), 'type' => Controls_Manager::ICONS, 'default' => [ 'value' => 'fas fa-drafting-compass', 'library' => 'fa-solid' ] ] );
		$r->add_control( 'image', [ 'label' => __( 'Foto', 'wakoo' ), 'type' => Controls_Manager::MEDIA, 'description' => __( 'Vacío = imagen de ejemplo de Wakoo.', 'wakoo' ) ] );
		Lang::rep( $r, 'title', __( 'Título', 'wakoo' ), [ 'es' => 'Título', 'en' => 'Title', 'zh' => '标题' ] );
		Lang::rep( $r, 'text', __( 'Texto', 'wakoo' ), [], 'textarea' );
		$r->add_control( 'link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$defs = [
			[ 'fas fa-drafting-compass', 'Arquitectura', 'Architecture', '建筑设计', 'Proyectos residenciales y comerciales, del boceto a la obra terminada.', 'Residential and commercial projects, from first sketch to finished build.', '住宅与商业项目，从草图到竣工。' ],
			[ 'fas fa-couch', 'Interiorismo', 'Interior Design', '室内设计', 'Espacios cálidos y funcionales con materiales nobles y luz natural.', 'Warm, functional spaces with honest materials and natural light.', '以天然材料与自然光打造温暖实用的空间。' ],
			[ 'fas fa-leaf', 'Paisajismo', 'Landscape', '景观设计', 'Jardines y exteriores que continúan la arquitectura hacia la naturaleza.', 'Gardens and outdoor spaces that carry architecture into nature.', '让建筑延伸至自然的花园与户外空间。' ],
			[ 'fas fa-cube', 'Visualización 3D', '3D Visualisation', '三维可视化', 'Renders y recorridos para ver tu proyecto antes de construirlo.', 'Renders and walkthroughs to see your project before it is built.', '在建造之前通过渲染与漫游预览你的项目。' ],
		];
		$this->add_control( 'items', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'title_field' => '{{{ title }}}',
			'default'     => array_map( function ( $d ) {
				return [ 'icon' => [ 'value' => $d[0], 'library' => 'fa-solid' ], 'title' => $d[1], 'title_en' => $d[2], 'title_zh' => $d[3], 'text' => $d[4], 'text_en' => $d[5], 'text_zh' => $d[6], 'link' => [ 'url' => '' ] ];
			}, $defs ),
		] );
		Lang::controls( $this, 'more', __( 'Texto del enlace', 'wakoo' ), [ 'es' => 'Saber más', 'en' => 'Learn more', 'zh' => '了解更多' ] );
		$this->add_control( 'cols', [ 'label' => __( 'Columnas en pantalla ancha', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => '4', 'options' => [ '2' => '2', '3' => '3', '4' => '4', '5' => '5' ] ] );
		$this->add_control( 'numbers', [ 'label' => __( 'Numerar tarjetas (01, 02…)', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();
		$this->glass_controls( '.wk-esc-cards__c', 'rgba(255,255,255,0.5)' );
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$mode  = in_array( $s['mode'] ?? 'icon', [ 'icon', 'photo', 'cover' ], true ) ? $s['mode'] : 'icon';
		$items = array_values( (array) $s['items'] );
		echo '<div class="wk-esc-cards wk-esc-cards--' . esc_attr( $mode ) . '" style="--cols:' . (int) ( $s['cols'] ?? 4 ) . '">';
		foreach ( $items as $k => $i ) {
			$has_link = ! empty( $i['link']['url'] );
			$tag      = $has_link ? 'a' : 'div';
			$img      = 'icon' === $mode ? '' : $this->media( $i['image'] ?? [], ( 'photo' === $mode ? 'avatar-' . ( ( $k % 2 ) + 1 ) : 'project-' . ( ( $k % 6 ) + 1 ) ) . '.jpg' );
			echo '<' . $tag . ' class="wk-esc-cards__c wk-esc-glass"' . ( $has_link ? $this->href( $i['link'] ) : '' ) . '>';
			if ( 'cover' === $mode ) {
				echo '<img class="wk-esc-cards__cover" src="' . esc_url( $img ) . '" alt="" loading="lazy">';
			}
			echo '<span class="wk-esc-cards__top">';
			if ( 'photo' === $mode ) {
				echo '<img class="wk-esc-cards__photo" src="' . esc_url( $img ) . '" alt="" loading="lazy">';
			} elseif ( 'icon' === $mode ) {
				echo '<span class="wk-esc-cards__ic">' . $this->icon( $i['icon'] ?? [] ) . '</span>';
			}
			if ( 'yes' === ( $s['numbers'] ?? '' ) ) {
				echo '<span class="wk-esc-cards__n">' . esc_html( sprintf( '%02d', $k + 1 ) ) . '</span>';
			}
			echo '</span><span class="wk-esc-cards__b">';
			echo '<span class="wk-esc-cards__t">' . Lang::out( $i, 'title' ) . '</span>';
			if ( Lang::has( $i, 'text' ) ) {
				echo '<span class="wk-esc-cards__p">' . Lang::out( $i, 'text' ) . '</span>';
			}
			if ( $has_link && Lang::has( $s, 'more' ) ) {
				echo '<span class="wk-esc-cards__more">' . Lang::out( $s, 'more' ) . self::svg( 'arrow' ) . '</span>';
			}
			echo '</span></' . $tag . '>';
		}
		echo '</div>';
	}
}
