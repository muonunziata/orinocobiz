<?php
/**
 * Escena: contact card (details + form) in glass. The form uses Wakoo Forms underneath:
 * messages are saved in the Wakoo inbox and emailed, with the same spam protection.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Escena\Widgets;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Wakoo\Modules\Escena\Lang;

defined( 'ABSPATH' ) || die();

class Contact extends Base {

	public function get_name() { return 'wakoo-esc-contact'; }
	public function get_title() { return __( 'Contacto de vidrio (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-form-horizontal'; }
	public function get_keywords() { return [ 'wakoo', 'escena', 'contacto', 'formulario', 'form', 'email' ]; }

	public function get_script_depends() { return [ 'wakoo-escena', 'wakoo-forms' ]; }

	/** Fixed fields: key => [ type, required, labels, placeholders ]. */
	private static function fields() {
		return [
			'name'  => [ 'text', true, [ 'Nombre', 'Name', '姓名' ], [ 'Tu nombre', 'Your name', '你的名字' ] ],
			'email' => [ 'email', true, [ 'Email', 'Email', '邮箱' ], [ 'tu@email.com', 'you@email.com', 'you@email.com' ] ],
			'topic' => [ 'select', false, [ 'Me interesa', "I'm interested in", '我感兴趣的是' ], [ '', '', '' ] ],
			'msg'   => [ 'textarea', true, [ 'Mensaje', 'Message', '留言' ], [ 'Cuéntanos tu proyecto', 'Tell us about your project', '告诉我们你的项目' ] ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_info', [ 'label' => __( 'Datos de contacto', 'wakoo' ) ] );
		Lang::controls( $this, 'info_title', __( 'Título', 'wakoo' ), [ 'es' => 'Estudio', 'en' => 'Studio', 'zh' => '工作室' ] );
		$r = new Repeater();
		$r->add_control( 'icon', [ 'label' => __( 'Icono', 'wakoo' ), 'type' => Controls_Manager::ICONS, 'default' => [ 'value' => 'far fa-envelope', 'library' => 'fa-regular' ] ] );
		Lang::rep( $r, 'label', __( 'Etiqueta', 'wakoo' ), [ 'es' => 'Email', 'en' => 'Email', 'zh' => '邮箱' ] );
		Lang::rep( $r, 'value', __( 'Dato', 'wakoo' ), [ 'es' => 'hola@estudio.com', 'en' => '', 'zh' => '' ] );
		$r->add_control( 'link', [ 'label' => __( 'Enlace (mailto:, tel:, mapa…)', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$defs = [
			[ 'far fa-envelope', 'fa-regular', [ 'Email', 'Email', '邮箱' ], [ 'hola@mrlproduction.com', '', '' ], 'mailto:hola@mrlproduction.com' ],
			[ 'fas fa-phone', 'fa-solid', [ 'Teléfono', 'Phone', '电话' ], [ '+34 600 000 000', '', '' ], 'tel:+34600000000' ],
			[ 'fas fa-map-marker-alt', 'fa-solid', [ 'Estudio', 'Studio', '地址' ], [ 'Calle del Mar 12, Palma', '12 Sea Street, Palma', '帕尔马 海洋街12号' ], '' ],
			[ 'far fa-clock', 'fa-regular', [ 'Horario', 'Hours', '营业时间' ], [ 'Lun–Vie · 9:00–18:00', 'Mon–Fri · 9am–6pm', '周一至周五 · 9:00–18:00' ], '' ],
		];
		$this->add_control( 'info', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'title_field' => '{{{ label }}}',
			'default'     => array_map( function ( $d ) {
				return [ 'icon' => [ 'value' => $d[0], 'library' => $d[1] ], 'label' => $d[2][0], 'label_en' => $d[2][1], 'label_zh' => $d[2][2], 'value' => $d[3][0], 'value_en' => $d[3][1], 'value_zh' => $d[3][2], 'link' => [ 'url' => $d[4] ] ];
			}, $defs ),
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_form', [ 'label' => __( 'Formulario', 'wakoo' ) ] );
		Lang::controls( $this, 'form_title', __( 'Título', 'wakoo' ), [ 'es' => 'Cuéntanos tu idea', 'en' => 'Tell us your idea', 'zh' => '告诉我们你的想法' ] );
		foreach ( self::fields() as $key => $f ) {
			Lang::controls( $this, 'l_' . $key, sprintf( __( 'Campo: %s', 'wakoo' ), $f[2][0] ), [ 'es' => $f[2][0], 'en' => $f[2][1], 'zh' => $f[2][2] ] );
			if ( 'select' !== $f[0] ) {
				Lang::controls( $this, 'p_' . $key, sprintf( __( 'Texto de ayuda: %s', 'wakoo' ), $f[2][0] ), [ 'es' => $f[3][0], 'en' => $f[3][1], 'zh' => $f[3][2] ] );
			}
		}
		Lang::controls( $this, 'topics', __( 'Opciones de "Me interesa" (una por línea)', 'wakoo' ), [
			'es' => "Arquitectura\nInteriorismo\nPaisajismo\nOtro",
			'en' => "Architecture\nInterior design\nLandscape\nOther",
			'zh' => "建筑设计\n室内设计\n景观设计\n其他",
		], 'textarea' );
		Lang::controls( $this, 'btn', __( 'Botón', 'wakoo' ), [ 'es' => 'Enviar mensaje', 'en' => 'Send message', 'zh' => '发送留言' ] );
		Lang::controls( $this, 'ok', __( 'Mensaje de éxito', 'wakoo' ), [ 'es' => '¡Gracias! Te responderemos muy pronto.', 'en' => "Thank you! We'll get back to you soon.", 'zh' => '谢谢！我们会尽快回复你。' ] );
		Lang::controls( $this, 'err', __( 'Mensaje de error', 'wakoo' ), [ 'es' => 'Revisa los campos marcados.', 'en' => 'Please check the highlighted fields.', 'zh' => '请检查标出的字段。' ] );
		Lang::controls( $this, 'sending', __( 'Mensaje "enviando"', 'wakoo' ), [ 'es' => 'Enviando…', 'en' => 'Sending…', 'zh' => '发送中…' ] );
		$this->add_control( 'email_to', [ 'label' => __( 'Enviar a (email)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'placeholder' => get_option( 'admin_email' ), 'separator' => 'before' ] );
		$this->add_control( 'store', [ 'label' => __( 'Guardar en la bandeja de Wakoo', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();

		$this->glass_controls( '.wk-esc-contact__card', 'rgba(255,255,255,0.55)' );
	}

	private function lines( array $s, $id, $lang ) {
		return array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', Lang::get( $s, $id, $lang ) ) ) ) );
	}

	protected function render() {
		$s = $this->get_settings_for_display();

		echo '<div class="wk-esc-contact">';
		// Details.
		echo '<div class="wk-esc-contact__card wk-esc-contact__info wk-esc-glass">';
		echo '<span class="wk-esc-contact__h">' . Lang::out( $s, 'info_title' ) . '</span><ul>';
		foreach ( (array) $s['info'] as $i ) {
			$link = ! empty( $i['link']['url'] );
			echo '<li>' . ( $link ? '<a' . $this->href( $i['link'] ) . '>' : '<span class="wk-esc-contact__row">' );
			echo '<span class="wk-esc-round wk-esc-contact__ic">' . $this->icon( $i['icon'] ?? [] ) . '</span>';
			echo '<span class="wk-esc-contact__tx"><span class="wk-esc-contact__l">' . Lang::out( $i, 'label' ) . '</span><span class="wk-esc-contact__v">' . Lang::out( $i, 'value' ) . '</span></span>';
			echo $link ? '</a>' : '</span>';
			echo '</li>';
		}
		echo '</ul></div>';

		// Form (Wakoo Forms protocol).
		$fields = self::fields();
		$cfg    = [];
		$n      = 0;
		foreach ( $fields as $key => $f ) {
			$n++;
			$cfg[] = [ 'name' => 'f' . $n, 'type' => $f[0], 'label' => Lang::get( $s, 'l_' . $key, 'es' ), 'required' => $f[1], 'accept' => '', 'conditional' => false ];
		}
		$form_key = md5( get_the_ID() . '|' . $this->get_id() . '|escena' );
		if ( class_exists( '\Wakoo\Modules\Forms\Module' ) && ! \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			\Wakoo\Modules\Forms\Module::register_form( $form_key, [
				'title'    => wp_strip_all_tags( Lang::get( $s, 'form_title', 'es' ) ),
				'to'       => sanitize_email( $s['email_to'] ?? '' ),
				'subject'  => '',
				'success'  => Lang::get( $s, 'ok', 'es' ),
				'redirect' => '',
				'store'    => 'yes' === ( $s['store'] ?? 'yes' ),
				'fields'   => $cfg,
			] );
		}
		$msgs = [];
		foreach ( [ 'ok', 'err', 'sending' ] as $m ) {
			$msgs[ $m ] = json_decode( Lang::map( $s, $m ), true );
		}
		echo '<form class="wakoo-form wk-esc-contact__card wk-esc-contact__form wk-esc-glass" method="post" novalidate data-key="' . esc_attr( $form_key ) . '" data-wk-msgs="' . esc_attr( wp_json_encode( $msgs ) ) . '">';
		echo '<span class="wk-esc-contact__h">' . Lang::out( $s, 'form_title' ) . '</span>';
		echo '<div class="wk-esc-contact__fields">';
		$n = 0;
		foreach ( $fields as $key => $f ) {
			$n++;
			$name = 'f' . $n;
			$id   = 'wk-esc-' . $this->get_id() . '-' . $key;
			$req  = $f[1] ? ' required' : '';
			echo '<div class="wakoo-form__field wk-esc-contact__f wk-esc-contact__f--' . esc_attr( $key ) . '" data-name="' . esc_attr( $name ) . '">';
			echo '<label for="' . esc_attr( $id ) . '">' . Lang::out( $s, 'l_' . $key ) . ( $f[1] ? ' <span aria-hidden="true">*</span>' : '' ) . '</label>';
			if ( 'select' === $f[0] ) {
				echo '<select id="' . esc_attr( $id ) . '" name="fields[' . esc_attr( $name ) . ']">';
				$es = $this->lines( $s, 'topics', 'es' );
				$en = $this->lines( $s, 'topics', 'en' );
				$zh = $this->lines( $s, 'topics', 'zh' );
				foreach ( $es as $k => $opt ) {
					$map = [ 'text' => [ 'es' => $opt, 'en' => $en[ $k ] ?? $opt, 'zh' => $zh[ $k ] ?? $opt ] ];
					echo '<option value="' . esc_attr( $opt ) . '" data-wk-attr="' . esc_attr( wp_json_encode( $map ) ) . '">' . esc_html( $opt ) . '</option>';
				}
				echo '</select>';
			} else {
				$ph   = json_decode( Lang::map( $s, 'p_' . $key ), true );
				$attr = ' data-wk-attr="' . esc_attr( wp_json_encode( [ 'placeholder' => $ph ] ) ) . '" placeholder="' . esc_attr( $ph['es'] ) . '"';
				if ( 'textarea' === $f[0] ) {
					echo '<textarea id="' . esc_attr( $id ) . '" name="fields[' . esc_attr( $name ) . ']" rows="3"' . $attr . $req . '></textarea>';
				} else {
					echo '<input id="' . esc_attr( $id ) . '" type="' . esc_attr( $f[0] ) . '" name="fields[' . esc_attr( $name ) . ']"' . $attr . $req . ( 'email' === $f[0] ? ' autocomplete="email"' : ' autocomplete="name"' ) . '>';
				}
			}
			echo '</div>';
		}
		echo '</div>';
		echo '<button type="submit" class="wakoo-form__submit wk-esc-btn"><span>' . Lang::out( $s, 'btn' ) . '</span>' . self::svg( 'arrow' ) . '</button>';
		echo '<input type="text" name="wakoo_hp" class="wakoo-form__hp" tabindex="-1" autocomplete="off" aria-hidden="true">';
		echo '<input type="hidden" name="wakoo_ts" value="">';
		echo '<div class="wakoo-form__msg wk-esc-contact__msg" role="status" aria-live="polite"></div>';
		echo '</form></div>';
	}
}
