<?php
/**
 * Escena: project gallery that fits the screen (category filter + pages of glass cards).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Escena\Widgets;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Wakoo\Modules\Escena\Lang;

defined( 'ABSPATH' ) || die();

class Works extends Base {

	public function get_name() { return 'wakoo-esc-works'; }
	public function get_title() { return __( 'Galería de proyectos (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-posts-grid'; }
	public function get_keywords() { return [ 'wakoo', 'escena', 'proyectos', 'portfolio', 'galeria', 'filtro', 'obras' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_items', [ 'label' => __( 'Proyectos', 'wakoo' ) ] );
		$r = new Repeater();
		$r->add_control( 'image', [ 'label' => __( 'Imagen', 'wakoo' ), 'type' => Controls_Manager::MEDIA, 'description' => __( 'Vacío = imagen de ejemplo de Wakoo.', 'wakoo' ) ] );
		Lang::rep( $r, 'title', __( 'Título', 'wakoo' ), [ 'es' => 'Proyecto', 'en' => 'Project', 'zh' => '项目' ] );
		Lang::rep( $r, 'cat', __( 'Categoría', 'wakoo' ), [ 'es' => 'Arquitectura', 'en' => 'Architecture', 'zh' => '建筑' ] );
		$r->add_control( 'year', [ 'label' => __( 'Año o lugar', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '2026' ] );
		$r->add_control( 'link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$A = [ 'Arquitectura', 'Architecture', '建筑' ];
		$I = [ 'Interiores', 'Interiors', '室内' ];
		$P = [ 'Paisajismo', 'Landscape', '景观' ];
		$defs = [
			[ 'Villa Horizonte', 'The Horizon Villa', '地平线别墅', $A, 'Mallorca · 2026' ],
			[ 'Casa del Lago', 'Lake House', '湖畔之家', $I, 'Como · 2025' ],
			[ 'Refugio del Bosque', 'Forest Retreat', '森林隐居', $A, 'Asturias · 2025' ],
			[ 'Pabellón Duna', 'Dune Pavilion', '沙丘亭', $P, 'Cádiz · 2024' ],
			[ 'Estudio Cumbre', 'Summit Studio', '山顶工作室', $I, 'Andorra · 2024' ],
			[ 'Casa Patio', 'Courtyard House', '庭院之家', $P, 'Sevilla · 2023' ],
			[ 'Mirador Norte', 'North Lookout', '北望台', $A, 'Cantabria · 2023' ],
			[ 'Loft Ribera', 'Riverside Loft', '河畔阁楼', $I, 'Bilbao · 2022' ],
		];
		$this->add_control( 'items', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'title_field' => '{{{ title }}}',
			'default'     => array_map( function ( $d ) {
				return [ 'title' => $d[0], 'title_en' => $d[1], 'title_zh' => $d[2], 'cat' => $d[3][0], 'cat_en' => $d[3][1], 'cat_zh' => $d[3][2], 'year' => $d[4], 'link' => [ 'url' => '' ] ];
			}, $defs ),
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_opts', [ 'label' => __( 'Filtro y páginas', 'wakoo' ) ] );
		$this->add_control( 'filter', [ 'label' => __( 'Botones de categoría', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		Lang::controls( $this, 'all', __( 'Texto de "Todos"', 'wakoo' ), [ 'es' => 'Todos', 'en' => 'All', 'zh' => '全部' ] );
		$this->add_control( 'per_wide', [ 'label' => __( 'Proyectos por página (pantalla ancha)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 4, 'min' => 1, 'max' => 8 ] );
		$this->add_control( 'per_tall', [ 'label' => __( 'Proyectos por página (móvil y tablet vertical)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 4, 'min' => 1, 'max' => 6 ] );
		$this->end_controls_section();
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$items = array_values( (array) $s['items'] );
		$cfg   = [ 'wide' => max( 1, (int) ( $s['per_wide'] ?? 4 ) ), 'tall' => max( 1, (int) ( $s['per_tall'] ?? 4 ) ) ];
		echo '<div class="wk-esc-works" data-wk-works="' . esc_attr( wp_json_encode( $cfg ) ) . '" style="--wide:' . (int) $cfg['wide'] . ';--tall:' . (int) $cfg['tall'] . '">';
		echo '<div class="wk-esc-works__bar">';
		if ( 'yes' === ( $s['filter'] ?? '' ) ) {
			$cats = [];
			foreach ( $items as $i ) {
				$key = sanitize_title( $i['cat'] ?? '' );
				if ( $key && ! isset( $cats[ $key ] ) ) {
					$cats[ $key ] = $i;
				}
			}
			echo '<div class="wk-esc-works__filters wk-esc-glass" role="group">';
			echo '<button type="button" class="wk-esc-works__f is-on" data-f="" aria-pressed="true">' . Lang::out( $s, 'all' ) . '</button>';
			foreach ( $cats as $key => $i ) {
				echo '<button type="button" class="wk-esc-works__f" data-f="' . esc_attr( $key ) . '" aria-pressed="false">' . Lang::out( $i, 'cat' ) . '</button>';
			}
			echo '</div>';
		}
		echo '<div class="wk-esc-works__pager"><span class="wk-esc-works__count"><b>01</b> / 01</span>';
		echo '<button type="button" class="wk-esc-round wk-esc-works__prev" aria-label="&larr;">' . self::svg( 'left' ) . '</button>';
		echo '<button type="button" class="wk-esc-round wk-esc-round--dark wk-esc-works__next" aria-label="&rarr;">' . self::svg( 'arrow' ) . '</button></div>';
		echo '</div><div class="wk-esc-works__grid">';
		foreach ( $items as $k => $i ) {
			$img  = $this->media( $i['image'] ?? [], 'project-' . ( ( $k % 6 ) + 1 ) . '.jpg' );
			$link = ! empty( $i['link']['url'] );
			$tag  = $link ? 'a' . $this->href( $i['link'] ) : 'div';
			echo '<' . $tag . ' class="wk-esc-works__c" data-cat="' . esc_attr( sanitize_title( $i['cat'] ?? '' ) ) . '">';
			echo '<img src="' . esc_url( $img ) . '" alt="" loading="lazy">';
			echo '<span class="wk-esc-works__cap wk-esc-glass"><span class="wk-esc-works__t">' . Lang::out( $i, 'title' ) . '</span>';
			echo '<span class="wk-esc-works__m">' . Lang::out( $i, 'cat' ) . ( '' !== trim( (string) ( $i['year'] ?? '' ) ) ? ' · ' . esc_html( $i['year'] ) : '' ) . '</span>';
			echo ( $link ? '<span class="wk-esc-round wk-esc-round--light wk-esc-works__go">' . self::svg( 'up' ) . '</span>' : '' ) . '</span>';
			echo '</' . strtok( $tag, ' ' ) . '>';
		}
		echo '</div></div>';
	}
}
