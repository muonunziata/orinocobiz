<?php
/**
 * Escena: dark glass call-to-action card (round image, arrow, title, text).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Escena\Widgets;

use Elementor\Controls_Manager;
use Wakoo\Modules\Escena\Lang;

defined( 'ABSPATH' ) || die();

class Cta extends Base {

	public function get_name() { return 'wakoo-esc-cta'; }
	public function get_title() { return __( 'Tarjeta de llamada (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-call-to-action'; }
	public function get_keywords() { return [ 'wakoo', 'escena', 'cta', 'tarjeta', 'llamada', 'contacto' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_cta', [ 'label' => __( 'Contenido', 'wakoo' ) ] );
		$this->add_control( 'image', [ 'label' => __( 'Imagen redonda', 'wakoo' ), 'type' => Controls_Manager::MEDIA, 'description' => __( 'Vacío = imagen de ejemplo de Wakoo.', 'wakoo' ) ] );
		Lang::controls( $this, 'title', __( 'Título', 'wakoo' ), [ 'es' => 'Haz realidad tu visión', 'en' => 'Bring Your Vision To Life', 'zh' => '让你的愿景成真' ] );
		Lang::controls( $this, 'text', __( 'Texto', 'wakoo' ), [ 'es' => 'Creemos juntos un espacio que se sienta como tú.', 'en' => "Let's create a space that feels like you.", 'zh' => '一起打造真正属于你的空间。' ], 'textarea' );
		$this->add_control( 'link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL, 'default' => [ 'url' => '#contacto' ] ] );
		$this->end_controls_section();
		$this->glass_controls( '.wk-esc-cta', 'rgba(28,25,22,0.72)' );
	}

	protected function render() {
		$s   = $this->get_settings_for_display();
		$img = $this->media( $s['image'] ?? [], 'cta.jpg' );
		echo '<a class="wk-esc-cta wk-esc-glass"' . $this->href( $s['link'] ?? [] ) . '>';
		echo '<span class="wk-esc-cta__top">';
		if ( $img ) {
			echo '<img class="wk-esc-cta__img" src="' . esc_url( $img ) . '" alt="" loading="lazy">';
		}
		echo '<span class="wk-esc-round wk-esc-round--light wk-esc-cta__go">' . self::svg( 'up' ) . '</span></span>';
		echo '<span class="wk-esc-cta__t">' . Lang::out( $s, 'title' ) . '</span>';
		if ( Lang::has( $s, 'text' ) ) {
			echo '<span class="wk-esc-cta__p">' . Lang::out( $s, 'text' ) . '</span>';
		}
		echo '</a>';
	}
}
