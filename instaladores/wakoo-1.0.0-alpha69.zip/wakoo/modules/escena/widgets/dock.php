<?php
/**
 * Escena: vertical glass dock (icon links, round thumbnail, showreel button).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Escena\Widgets;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Wakoo\Modules\Escena\Lang;

defined( 'ABSPATH' ) || die();

class Dock extends Base {

	public function get_name() { return 'wakoo-esc-dock'; }
	public function get_title() { return __( 'Barra lateral de vidrio (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-navigation-vertical'; }
	public function get_keywords() { return [ 'wakoo', 'escena', 'barra', 'lateral', 'dock', 'iconos', 'showreel' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_items', [ 'label' => __( 'Iconos', 'wakoo' ) ] );
		$r = new Repeater();
		$r->add_control( 'icon', [ 'label' => __( 'Icono', 'wakoo' ), 'type' => Controls_Manager::ICONS, 'default' => [ 'value' => 'fas fa-home', 'library' => 'fa-solid' ] ] );
		Lang::rep( $r, 'label', __( 'Nombre (accesible)', 'wakoo' ), [ 'es' => 'Enlace', 'en' => 'Link', 'zh' => '链接' ] );
		$r->add_control( 'link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$r->add_control( 'active', [ 'label' => __( 'Activo', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ] );
		$defs = [
			[ 'fas fa-home', 'fa-solid', 'Inicio', 'Home', '首页', 'yes' ],
			[ 'fas fa-th-large', 'fa-solid', 'Galería', 'Gallery', '图库', '' ],
			[ 'far fa-folder', 'fa-regular', 'Proyectos', 'Projects', '项目', '' ],
			[ 'far fa-heart', 'fa-regular', 'Favoritos', 'Favourites', '收藏', '' ],
			[ 'far fa-comment-alt', 'fa-regular', 'Mensajes', 'Messages', '留言', '' ],
		];
		$this->add_control( 'items', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'title_field' => '{{{ label }}}',
			'default'     => array_map( function ( $d ) {
				return [ 'icon' => [ 'value' => $d[0], 'library' => $d[1] ], 'label' => $d[2], 'label_en' => $d[3], 'label_zh' => $d[4], 'active' => $d[5], 'link' => [ 'url' => '#' ] ];
			}, $defs ),
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_thumb', [ 'label' => __( 'Miniatura y showreel', 'wakoo' ) ] );
		$this->add_control( 'thumb', [ 'label' => __( 'Imagen redonda', 'wakoo' ), 'type' => Controls_Manager::MEDIA, 'description' => __( 'Vacío = imagen de ejemplo de Wakoo.', 'wakoo' ) ] );
		$this->add_control( 'thumb_link', [ 'label' => __( 'Enlace de la imagen', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$this->add_control( 'reel', [ 'label' => __( 'Mostrar showreel', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		Lang::controls( $this, 'reel_label', __( 'Texto', 'wakoo' ), [ 'es' => 'Ver showreel', 'en' => 'Watch Showreel', 'zh' => '观看作品' ] );
		$this->add_control( 'reel_video', [
			'label'       => __( 'Vídeo (archivo .mp4/.webm de tu biblioteca)', 'wakoo' ),
			'type'        => Controls_Manager::MEDIA,
			'media_types' => [ 'video' ],
			'description' => __( 'Se abre en una ventana sobre la página. Si lo dejas vacío, el botón usa el enlace de abajo.', 'wakoo' ),
		] );
		$this->add_control( 'reel_link', [ 'label' => __( 'Enlace alternativo', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$this->end_controls_section();

		$this->glass_controls( '.wk-esc-dock', 'rgba(255,255,255,0.45)' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		echo '<aside class="wk-esc-dock wk-esc-glass">';
		echo '<ul class="wk-esc-dock__list">';
		foreach ( (array) $s['items'] as $i ) {
			$active = 'yes' === ( $i['active'] ?? '' );
			echo '<li><a class="wk-esc-dock__i' . ( $active ? ' is-active' : '' ) . '"' . $this->href( $i['link'] ?? [] ) . ' data-wk-attr="' . esc_attr( wp_json_encode( [ 'aria-label' => json_decode( Lang::map( $i, 'label' ), true ), 'title' => json_decode( Lang::map( $i, 'label' ), true ) ] ) ) . '" aria-label="' . esc_attr( $i['label'] ) . '" title="' . esc_attr( $i['label'] ) . '">' . $this->icon( $i['icon'] ?? [] ) . '</a></li>';
		}
		echo '</ul>';
		$thumb = $this->media( $s['thumb'] ?? [], 'thumb.jpg' );
		if ( $thumb ) {
			$tag = ! empty( $s['thumb_link']['url'] ) ? 'a' . $this->href( $s['thumb_link'] ) : 'span';
			echo '<' . $tag . ' class="wk-esc-dock__thumb"><img src="' . esc_url( $thumb ) . '" alt="" loading="lazy"></' . strtok( $tag, ' ' ) . '>';
		}
		if ( 'yes' === ( $s['reel'] ?? '' ) ) {
			$video = $this->media( $s['reel_video'] ?? [] );
			$attrs = $video ? ' href="#" data-wk-video="' . esc_url( $video ) . '"' : $this->href( $s['reel_link'] ?? [] );
			echo '<a class="wk-esc-dock__reel"' . $attrs . '><span class="wk-esc-round wk-esc-round--line">' . self::svg( 'play' ) . '</span><span class="wk-esc-dock__reel-t">' . Lang::out( $s, 'reel_label' ) . '</span></a>';
		}
		echo '</aside>';
	}
}
