<?php
/**
 * Escena: vertical word list with a side rule ("Modern / Sustainable / ...").
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Escena\Widgets;

use Elementor\Controls_Manager;
use Wakoo\Modules\Escena\Lang;

defined( 'ABSPATH' ) || die();

class Tags extends Base {

	public function get_name() { return 'wakoo-esc-tags'; }
	public function get_title() { return __( 'Palabras verticales (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-bullet-list'; }
	public function get_keywords() { return [ 'wakoo', 'escena', 'etiquetas', 'palabras', 'lista' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_words', [ 'label' => __( 'Palabras', 'wakoo' ) ] );
		Lang::controls( $this, 'words', __( 'Una por línea', 'wakoo' ), [
			'es' => "Moderno\nSostenible\nFuncional\nAtemporal",
			'en' => "Modern\nSustainable\nFunctional\nTimeless",
			'zh' => "现代\n可持续\n实用\n永恒",
		], 'textarea' );
		$this->end_controls_section();
		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Colores', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'c', [ 'label' => __( 'Texto y línea', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wk-esc-tags' => '--wk-esc-ink: {{VALUE}};' ] ] );
		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		echo '<ul class="wk-esc-tags">';
		$lists = [];
		foreach ( array_keys( Lang::LANGS ) as $l ) {
			$lists[ $l ] = array_values( array_filter( array_map( 'trim', explode( "\n", Lang::get( $s, 'words', $l ) ) ) ) );
		}
		$n = max( array_map( 'count', $lists ) );
		for ( $k = 0; $k < $n; $k++ ) {
			echo '<li>';
			foreach ( $lists as $l => $words ) {
				echo '<span data-wk-l="' . $l . '">' . esc_html( $words[ $k ] ?? '' ) . '</span>';
			}
			echo '</li>';
		}
		echo '</ul>';
	}
}
