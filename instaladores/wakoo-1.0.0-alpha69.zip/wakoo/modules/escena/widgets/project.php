<?php
/**
 * Escena: featured-project glass card with its own slider (image, title, text, link, avatars, 01 / 06, arrows).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Escena\Widgets;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Wakoo\Modules\Escena\Lang;

defined( 'ABSPATH' ) || die();

class Project extends Base {

	public function get_name() { return 'wakoo-esc-project'; }
	public function get_title() { return __( 'Proyecto destacado (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-slider-push'; }
	public function get_keywords() { return [ 'wakoo', 'escena', 'proyecto', 'destacado', 'slider', 'carrusel', 'tarjeta' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_slides', [ 'label' => __( 'Proyectos', 'wakoo' ) ] );
		Lang::controls( $this, 'badge', __( 'Etiqueta de la imagen', 'wakoo' ), [ 'es' => 'Proyecto destacado', 'en' => 'Featured Project', 'zh' => '精选项目' ] );
		$r = new Repeater();
		$r->add_control( 'image', [ 'label' => __( 'Imagen', 'wakoo' ), 'type' => Controls_Manager::MEDIA ] );
		Lang::rep( $r, 'title', __( 'Título', 'wakoo' ), [ 'es' => 'Proyecto', 'en' => 'Project', 'zh' => '项目' ] );
		Lang::rep( $r, 'desc', __( 'Descripción', 'wakoo' ), [], 'textarea' );
		$r->add_control( 'link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$defs = [
			[ 'Villa Horizonte', 'The Horizon Villa', '地平线别墅', 'Una villa moderna que se funde con su entorno natural con una arquitectura mínima.', 'A modern villa that blends natural surroundings with minimal architecture.', '一座以极简建筑融入自然环境的现代别墅。' ],
			[ 'Casa del Lago', 'Lake House', '湖畔之家', 'Grandes ventanales sobre el agua y madera cálida en cada estancia.', 'Floor-to-ceiling glass over the water and warm timber in every room.', '临水的落地玻璃，每个房间都有温暖的木材。' ],
			[ 'Refugio del Bosque', 'Forest Retreat', '森林隐居', 'Un refugio de líneas sencillas entre pinos, pensado para desconectar.', 'A simple-lined retreat among the pines, designed to unplug.', '松林间线条简洁的隐居之所，专为放松而设计。' ],
			[ 'Pabellón Duna', 'Dune Pavilion', '沙丘亭', 'Hormigón claro y patios en sombra frente al mar.', 'Pale concrete and shaded courtyards facing the sea.', '面朝大海的浅色混凝土与荫凉庭院。' ],
			[ 'Estudio Cumbre', 'Summit Studio', '山顶工作室', 'Un estudio de trabajo con vistas abiertas a la montaña.', 'A working studio with open views of the mountains.', '拥有开阔山景的工作室。' ],
			[ 'Casa Patio', 'Courtyard House', '庭院之家', 'La vida gira alrededor de un patio con olivo y agua.', 'Life revolves around a courtyard with an olive tree and water.', '生活围绕着一个有橄榄树和水景的庭院展开。' ],
		];
		$this->add_control( 'slides', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'title_field' => '{{{ title }}}',
			'default'     => array_map( function ( $d, $k ) {
				return [ 'image' => [ 'url' => '', 'id' => '' ], 'title' => $d[0], 'title_en' => $d[1], 'title_zh' => $d[2], 'desc' => $d[3], 'desc_en' => $d[4], 'desc_zh' => $d[5], 'link' => [ 'url' => '#' ] ];
			}, $defs, array_keys( $defs ) ),
			'description' => __( 'Sin imagen se usan las imágenes de ejemplo de Wakoo.', 'wakoo' ),
		] );
		Lang::controls( $this, 'more', __( 'Texto del enlace', 'wakoo' ), [ 'es' => 'Ver proyecto', 'en' => 'View Project', 'zh' => '查看项目' ] );
		$this->add_control( 'autoplay', [ 'label' => __( 'Pasar solo cada (segundos, 0 = no)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 6, 'min' => 0, 'max' => 60 ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_team', [ 'label' => __( 'Equipo', 'wakoo' ) ] );
		$this->add_control( 'team', [ 'label' => __( 'Mostrar avatares', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'avatars', [
			'label'   => __( 'Avatares', 'wakoo' ),
			'type'    => Controls_Manager::GALLERY,
			'default' => [],
			'description' => __( 'Sin imágenes se muestran dos avatares de ejemplo.', 'wakoo' ),
		] );
		$this->add_control( 'team_link', [ 'label' => __( 'Enlace del botón +', 'wakoo' ), 'type' => Controls_Manager::URL, 'default' => [ 'url' => '#contacto' ] ] );
		$this->end_controls_section();

		$this->glass_controls( '.wk-esc-proj', 'rgba(255,255,255,0.42)' );
	}

	protected function render() {
		$s      = $this->get_settings_for_display();
		$slides = array_values( (array) $s['slides'] );
		$n      = count( $slides );
		if ( ! $n ) {
			return;
		}
		$cfg = [ 'autoplay' => max( 0, (int) ( $s['autoplay'] ?? 0 ) ) ];
		echo '<div class="wk-esc-proj wk-esc-glass" data-wk-proj="' . esc_attr( wp_json_encode( $cfg ) ) . '" aria-roledescription="carousel">';
		echo '<div class="wk-esc-proj__media">';
		foreach ( $slides as $k => $sl ) {
			$img = $this->media( $sl['image'] ?? [], 'project-' . ( ( $k % 6 ) + 1 ) . '.jpg' );
			echo '<img class="wk-esc-proj__img' . ( 0 === $k ? ' is-on' : '' ) . '" src="' . esc_url( $img ) . '" alt="" ' . ( $k ? 'loading="lazy"' : '' ) . '>';
		}
		echo '<span class="wk-esc-proj__badge">' . Lang::out( $s, 'badge' ) . '</span>';
		if ( 'yes' === ( $s['team'] ?? '' ) ) {
			$avs = [];
			foreach ( (array) $s['avatars'] as $a ) {
				if ( ! empty( $a['url'] ) ) {
					$avs[] = $a['url'];
				}
			}
			if ( ! $avs ) {
				$avs = [ \Wakoo\Modules\Escena\Module::img( 'avatar-1.jpg' ), \Wakoo\Modules\Escena\Module::img( 'avatar-2.jpg' ) ];
			}
			echo '<span class="wk-esc-proj__team">';
			foreach ( array_slice( $avs, 0, 3 ) as $a ) {
				echo '<img src="' . esc_url( $a ) . '" alt="">';
			}
			echo '<a class="wk-esc-proj__plus"' . $this->href( $s['team_link'] ?? [] ) . ' aria-label="+">' . self::svg( 'plus' ) . '</a></span>';
		}
		echo '</div><div class="wk-esc-proj__body">';
		echo '<div class="wk-esc-proj__slides">';
		foreach ( $slides as $k => $sl ) {
			echo '<div class="wk-esc-proj__slide' . ( 0 === $k ? ' is-on' : '' ) . '"' . ( $k ? ' aria-hidden="true"' : '' ) . '>';
			echo '<h3 class="wk-esc-proj__t">' . Lang::out( $sl, 'title' ) . '</h3>';
			echo '<p class="wk-esc-proj__d">' . Lang::out( $sl, 'desc' ) . '</p>';
			echo '<a class="wk-esc-proj__more"' . $this->href( $sl['link'] ?? [] ) . ' tabindex="' . ( $k ? '-1' : '0' ) . '">' . Lang::out( $s, 'more' ) . self::svg( 'arrow' ) . '</a>';
			echo '</div>';
		}
		echo '</div>';
		printf( '<span class="wk-esc-proj__count"><b>%s</b> / %s</span>', esc_html( sprintf( '%02d', 1 ) ), esc_html( sprintf( '%02d', $n ) ) );
		echo '<div class="wk-esc-proj__nav"><span class="wk-esc-proj__bars" aria-hidden="true">';
		for ( $k = 0; $k < $n; $k++ ) {
			echo '<i' . ( 0 === $k ? ' class="is-on"' : '' ) . '></i>';
		}
		echo '</span><button type="button" class="wk-esc-round wk-esc-proj__prev" aria-label="&larr;">' . self::svg( 'left' ) . '</button>';
		echo '<button type="button" class="wk-esc-round wk-esc-round--dark wk-esc-proj__next" aria-label="&rarr;">' . self::svg( 'arrow' ) . '</button></div>';
		echo '</div></div>';
	}
}
