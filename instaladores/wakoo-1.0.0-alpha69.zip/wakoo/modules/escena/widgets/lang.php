<?php
/**
 * Language switcher (ES / EN / 中文) usable anywhere.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Escena\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Lang_Switch extends Base {

	public function get_name() { return 'wakoo-lang-switch'; }
	public function get_title() { return __( 'Selector de idioma (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-globe'; }
	public function get_categories() { return [ 'wakoo-escena', 'basic' ]; }
	public function get_keywords() { return [ 'wakoo', 'idioma', 'language', 'traduccion', 'ingles', 'chino', 'espanol' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_lang', [ 'label' => __( 'Idiomas', 'wakoo' ) ] );
		$this->add_control( 'note', [
			'type' => Controls_Manager::RAW_HTML,
			'raw'  => __( 'Cambia entre español (por defecto), inglés y chino en todos los widgets Wakoo de la página. Para widgets de otros plugins usa Avanzado → Idioma (Wakoo). También funciona con ?lang=en o ?lang=zh en la dirección.', 'wakoo' ),
		] );
		$this->add_control( 'style', [ 'label' => __( 'Estilo', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'pill', 'options' => [ 'pill' => __( 'Pastilla', 'wakoo' ), 'mini' => __( 'Compacto', 'wakoo' ) ] ] );
		$this->add_responsive_control( 'align', [
			'label'     => __( 'Alineación', 'wakoo' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => [
				'flex-start' => [ 'title' => 'L', 'icon' => 'eicon-text-align-left' ],
				'center'     => [ 'title' => 'C', 'icon' => 'eicon-text-align-center' ],
				'flex-end'   => [ 'title' => 'R', 'icon' => 'eicon-text-align-right' ],
			],
			'selectors' => [ '{{WRAPPER}} .wk-esc-langw' => 'justify-content: {{VALUE}};' ],
		] );
		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		echo '<div class="wk-esc-langw">' . $this->lang_switch_html( 'mini' === ( $s['style'] ?? '' ) ? 'mini' : 'pill' ) . '</div>';
	}
}
