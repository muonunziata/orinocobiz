<?php
/**
 * Escena: glass header (logo, pill menu, search, language, call to action).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Escena\Widgets;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Wakoo\Modules\Escena\Lang;

defined( 'ABSPATH' ) || die();

class Header extends Base {

	public function get_name() { return 'wakoo-esc-header'; }
	public function get_title() { return __( 'Cabecera de vidrio (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-header'; }
	public function get_keywords() { return [ 'wakoo', 'escena', 'cabecera', 'header', 'menu', 'vidrio' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_logo', [ 'label' => __( 'Logo', 'wakoo' ) ] );
		$this->add_control( 'logo', [
			'label'       => __( 'Imagen del logo (opcional)', 'wakoo' ),
			'type'        => Controls_Manager::MEDIA,
			'description' => __( 'Si no subes imagen se usa el monograma de texto.', 'wakoo' ),
		] );
		$this->add_control( 'mark', [ 'label' => __( 'Monograma', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'MP' ] );
		Lang::controls( $this, 'brand', __( 'Nombre', 'wakoo' ), [ 'es' => 'MR L PRODUCTION', 'en' => 'MR L PRODUCTION', 'zh' => 'MR L 制作' ] );
		$this->add_control( 'logo_link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL, 'default' => [ 'url' => '/' ] ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_menu', [ 'label' => __( 'Menú', 'wakoo' ) ] );
		$r = new Repeater();
		Lang::rep( $r, 'label', __( 'Texto', 'wakoo' ), [ 'es' => 'Enlace', 'en' => 'Link', 'zh' => '链接' ] );
		$r->add_control( 'link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$r->add_control( 'active', [ 'label' => __( 'Activo', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ] );
		$items = [
			[ 'Inicio', 'Home', '首页', 'yes' ],
			[ 'Proyectos', 'Projects', '项目', '' ],
			[ 'Servicios', 'Services', '服务', '' ],
			[ 'Nosotros', 'About', '关于我们', '' ],
			[ 'Contacto', 'Contact', '联系我们', '' ],
		];
		$this->add_control( 'menu', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'title_field' => '{{{ label }}}',
			'default'     => array_map( function ( $i ) {
				return [ 'label' => $i[0], 'label_en' => $i[1], 'label_zh' => $i[2], 'active' => $i[3], 'link' => [ 'url' => '#' ] ];
			}, $items ),
		] );
		Lang::controls( $this, 'menu_aria', __( 'Texto del botón de menú (móvil)', 'wakoo' ), [ 'es' => 'Menú', 'en' => 'Menu', 'zh' => '菜单' ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_tools', [ 'label' => __( 'Buscador e idioma', 'wakoo' ) ] );
		$this->add_control( 'search', [ 'label' => __( 'Mostrar buscador', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		Lang::controls( $this, 'search_ph', __( 'Texto del buscador', 'wakoo' ), [ 'es' => 'Buscar…', 'en' => 'Search…', 'zh' => '搜索…' ] );
		$this->add_control( 'lang', [ 'label' => __( 'Mostrar selector de idioma', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_cta', [ 'label' => __( 'Botón', 'wakoo' ) ] );
		Lang::controls( $this, 'cta', __( 'Texto', 'wakoo' ), [ 'es' => 'Empezar un proyecto', 'en' => 'Start a Project', 'zh' => '开始项目' ] );
		$this->add_control( 'cta_link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL, 'default' => [ 'url' => '#contacto' ] ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Colores', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'ink', [ 'label' => __( 'Texto', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wk-esc-head' => '--wk-esc-ink: {{VALUE}};' ] ] );
		$this->add_control( 'dark', [ 'label' => __( 'Activo y botón', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wk-esc-head' => '--wk-esc-dark: {{VALUE}};' ] ] );
		$this->add_control( 'pill', [ 'label' => __( 'Fondo del menú', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wk-esc-head' => '--wk-esc-glass: {{VALUE}};' ] ] );
		$this->end_controls_section();
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$logo = $this->media( $s['logo'] ?? [] );
		$uid  = 'wk-esc-nav-' . $this->get_id();

		echo '<header class="wk-esc-head">';
		echo '<a class="wk-esc-head__logo"' . $this->href( $s['logo_link'] ?? [], home_url( '/' ) ) . '>';
		if ( $logo ) {
			echo '<img src="' . esc_url( $logo ) . '" alt="" class="wk-esc-head__img">';
		} elseif ( '' !== trim( (string) $s['mark'] ) ) {
			echo '<span class="wk-esc-head__mark" aria-hidden="true">' . esc_html( $s['mark'] ) . '</span>';
		}
		echo '<span class="wk-esc-head__brand">' . Lang::out( $s, 'brand' ) . '</span></a>';

		echo '<nav class="wk-esc-head__nav" id="' . esc_attr( $uid ) . '"><ul>';
		foreach ( (array) $s['menu'] as $i ) {
			$active = 'yes' === ( $i['active'] ?? '' );
			echo '<li><a class="wk-esc-head__link' . ( $active ? ' is-active' : '' ) . '"' . $this->href( $i['link'] ?? [] ) . ( $active ? ' aria-current="page"' : '' ) . '>' . Lang::out( $i, 'label' ) . '</a></li>';
		}
		$cta = '<a class="wk-esc-head__cta"' . $this->href( $s['cta_link'] ?? [] ) . '><span class="wk-esc-head__cta-t">' . Lang::out( $s, 'cta' ) . '</span><span class="wk-esc-head__cta-i">' . self::svg( 'arrow' ) . '</span></a>';
		echo '</ul><div class="wk-esc-head__navcta">' . $cta . '</div></nav>';

		echo '<div class="wk-esc-head__tools">';
		if ( 'yes' === ( $s['lang'] ?? '' ) ) {
			echo $this->lang_switch_html( 'mini' );
		}
		if ( 'yes' === ( $s['search'] ?? '' ) ) {
			echo '<form class="wk-esc-head__search" role="search" method="get" action="' . esc_url( home_url( '/' ) ) . '">';
			echo '<input type="search" name="s" class="wk-esc-head__q" data-wk-attr="' . esc_attr( wp_json_encode( [ 'placeholder' => json_decode( Lang::map( $s, 'search_ph' ), true ), 'aria-label' => json_decode( Lang::map( $s, 'search_ph' ), true ) ] ) ) . '" placeholder="' . esc_attr( $s['search_ph'] ) . '" aria-label="' . esc_attr( $s['search_ph'] ) . '">';
			echo '<button type="button" class="wk-esc-round wk-esc-head__sbtn" aria-expanded="false" aria-label="' . esc_attr( $s['search_ph'] ) . '">' . self::svg( 'search' ) . '</button>';
			echo '</form>';
		}
		echo $cta;
		echo '<button type="button" class="wk-esc-round wk-esc-head__burger" aria-expanded="false" aria-controls="' . esc_attr( $uid ) . '" data-wk-attr="' . esc_attr( wp_json_encode( [ 'aria-label' => json_decode( Lang::map( $s, 'menu_aria' ), true ) ] ) ) . '" aria-label="' . esc_attr( $s['menu_aria'] ) . '">' . self::svg( 'menu' ) . '</button>';
		echo '</div></header>';
	}
}
