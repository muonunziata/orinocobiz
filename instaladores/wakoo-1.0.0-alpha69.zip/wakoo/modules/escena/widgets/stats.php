<?php
/**
 * Escena: glass stats card (icon, animated number, label).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Escena\Widgets;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Wakoo\Modules\Escena\Lang;

defined( 'ABSPATH' ) || die();

class Stats extends Base {

	public function get_name() { return 'wakoo-esc-stats'; }
	public function get_title() { return __( 'Cifras de vidrio (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-counter'; }
	public function get_keywords() { return [ 'wakoo', 'escena', 'cifras', 'contador', 'estadisticas', 'numeros' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_items', [ 'label' => __( 'Cifras', 'wakoo' ) ] );
		$r = new Repeater();
		$r->add_control( 'icon', [ 'label' => __( 'Icono', 'wakoo' ), 'type' => Controls_Manager::ICONS, 'default' => [ 'value' => 'far fa-building', 'library' => 'fa-regular' ] ] );
		$r->add_control( 'number', [ 'label' => __( 'Número', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 100 ] );
		$r->add_control( 'suffix', [ 'label' => __( 'Sufijo', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '+' ] );
		Lang::rep( $r, 'label', __( 'Texto', 'wakoo' ), [ 'es' => 'Etiqueta', 'en' => 'Label', 'zh' => '标签' ] );
		$defs = [
			[ 'far fa-building', 'fa-regular', 250, 'Proyectos terminados', 'Projects Complete', '已完成项目' ],
			[ 'fas fa-users', 'fa-solid', 120, 'Clientes felices', 'Happy Clients', '满意客户' ],
			[ 'fas fa-globe', 'fa-solid', 15, 'Países', 'Countries Worldwide', '覆盖国家' ],
		];
		$this->add_control( 'items', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'title_field' => '{{{ number }}}{{{ suffix }}} {{{ label }}}',
			'default'     => array_map( function ( $d ) {
				return [ 'icon' => [ 'value' => $d[0], 'library' => $d[1] ], 'number' => $d[2], 'suffix' => '+', 'label' => $d[3], 'label_en' => $d[4], 'label_zh' => $d[5] ];
			}, $defs ),
		] );
		$this->add_control( 'animate', [ 'label' => __( 'Animar números', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();
		$this->glass_controls( '.wk-esc-stats', 'rgba(255,255,255,0.42)' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		echo '<div class="wk-esc-stats wk-esc-glass"' . ( 'yes' === ( $s['animate'] ?? '' ) ? ' data-wk-count' : '' ) . '>';
		foreach ( (array) $s['items'] as $i ) {
			$num = (float) ( $i['number'] ?? 0 );
			echo '<div class="wk-esc-stats__i"><span class="wk-esc-stats__ic">' . $this->icon( $i['icon'] ?? [] ) . '</span>';
			echo '<span class="wk-esc-stats__n"><span data-wk-to="' . esc_attr( $num ) . '">' . esc_html( rtrim( rtrim( number_format( $num, 2, '.', '' ), '0' ), '.' ) ) . '</span>' . esc_html( $i['suffix'] ?? '' ) . '</span>';
			echo '<span class="wk-esc-stats__l">' . Lang::out( $i, 'label' ) . '</span></div>';
		}
		echo '</div>';
	}
}
