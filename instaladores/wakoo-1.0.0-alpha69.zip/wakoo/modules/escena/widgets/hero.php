<?php
/**
 * Escena: hero text (eyebrow, big title with accent word, text, two buttons).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Escena\Widgets;

use Elementor\Controls_Manager;
use Wakoo\Modules\Escena\Lang;

defined( 'ABSPATH' ) || die();

class Hero extends Base {

	public function get_name() { return 'wakoo-esc-hero'; }
	public function get_title() { return __( 'Título de escena (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-t-letter'; }
	public function get_keywords() { return [ 'wakoo', 'escena', 'hero', 'titulo', 'portada' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_text', [ 'label' => __( 'Textos', 'wakoo' ) ] );
		Lang::controls( $this, 'eyebrow', __( 'Antetítulo', 'wakoo' ), [ 'es' => 'Arquitectura — Interiores — Paisajes', 'en' => 'Architecture — Interiors — Landscapes', 'zh' => '建筑 — 室内 — 景观' ] );
		Lang::controls( $this, 'title', __( 'Título', 'wakoo' ), [ 'es' => 'Espacios que|{inspiran}', 'en' => 'Spaces|That {Inspire}', 'zh' => '启迪人心的|{空间}' ], 'text', [
			'description' => __( 'Usa | para saltar de línea y {palabra} para la palabra en color.', 'wakoo' ),
		] );
		Lang::controls( $this, 'text', __( 'Texto', 'wakoo' ), [
			'es' => 'Diseñamos espacios con sentido que unen arquitectura, naturaleza y vida moderna.',
			'en' => 'We design meaningful spaces that blend architecture, nature and modern living.',
			'zh' => '我们设计有意义的空间，融合建筑、自然与现代生活。',
		], 'textarea' );
		$this->add_control( 'tag', [ 'label' => __( 'Etiqueta HTML del título', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'h1', 'options' => [ 'h1' => 'H1', 'h2' => 'H2', 'div' => 'div' ] ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_btn', [ 'label' => __( 'Botones', 'wakoo' ) ] );
		Lang::controls( $this, 'btn1', __( 'Botón principal', 'wakoo' ), [ 'es' => 'Ver nuestro trabajo', 'en' => 'Explore Our Work', 'zh' => '浏览作品' ] );
		$this->add_control( 'btn1_link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL, 'default' => [ 'url' => '#proyectos' ] ] );
		Lang::controls( $this, 'btn2', __( 'Botón de vídeo', 'wakoo' ), [ 'es' => 'Ver showreel', 'en' => 'Watch Showreel', 'zh' => '观看作品' ] );
		$this->add_control( 'btn2_video', [ 'label' => __( 'Vídeo (.mp4/.webm)', 'wakoo' ), 'type' => Controls_Manager::MEDIA, 'media_types' => [ 'video' ] ] );
		$this->add_control( 'btn2_link', [ 'label' => __( 'Enlace si no hay vídeo', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Colores', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'c_title', [ 'label' => __( 'Título', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wk-esc-hero__t' => 'color: {{VALUE}};' ] ] );
		$this->add_control( 'c_accent', [ 'label' => __( 'Palabra en color', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wk-esc-accent' => 'color: {{VALUE}};' ] ] );
		$this->add_control( 'c_text', [ 'label' => __( 'Texto y antetítulo', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wk-esc-hero' => '--wk-esc-ink: {{VALUE}};' ] ] );
		$this->add_control( 'c_btn', [ 'label' => __( 'Botón principal', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wk-esc-hero' => '--wk-esc-dark: {{VALUE}};' ] ] );
		$this->add_control( 'size', [
			'label'       => __( 'Tamaño del título (%)', 'wakoo' ),
			'type'        => Controls_Manager::SLIDER,
			'range'       => [ 'px' => [ 'min' => 50, 'max' => 150 ] ],
			'default'     => [ 'size' => 100, 'unit' => 'px' ],
			'selectors'   => [ '{{WRAPPER}} .wk-esc-hero' => '--wk-esc-tscale: calc({{SIZE}} / 100);' ],
			'description' => __( 'El título se adapta solo a la pantalla; esto lo agranda o reduce.', 'wakoo' ),
		] );
		$this->end_controls_section();
	}

	protected function render() {
		$s   = $this->get_settings_for_display();
		$tag = in_array( $s['tag'] ?? 'h1', [ 'h1', 'h2', 'div' ], true ) ? $s['tag'] : 'h1';
		echo '<div class="wk-esc-hero">';
		if ( Lang::has( $s, 'eyebrow' ) ) {
			echo '<p class="wk-esc-hero__eye">' . Lang::out( $s, 'eyebrow' ) . '</p>';
		}
		echo '<' . $tag . ' class="wk-esc-hero__t">' . Lang::out( $s, 'title', 'accent' ) . '</' . $tag . '>';
		if ( Lang::has( $s, 'text' ) ) {
			echo '<p class="wk-esc-hero__p">' . Lang::out( $s, 'text' ) . '</p>';
		}
		echo '<div class="wk-esc-hero__btns">';
		if ( Lang::has( $s, 'btn1' ) ) {
			echo '<a class="wk-esc-btn"' . $this->href( $s['btn1_link'] ?? [] ) . '><span>' . Lang::out( $s, 'btn1' ) . '</span>' . self::svg( 'arrow' ) . '</a>';
		}
		if ( Lang::has( $s, 'btn2' ) ) {
			$video = $this->media( $s['btn2_video'] ?? [] );
			$attrs = $video ? ' href="#" data-wk-video="' . esc_url( $video ) . '"' : $this->href( $s['btn2_link'] ?? [] );
			echo '<a class="wk-esc-play"' . $attrs . '><span class="wk-esc-round wk-esc-round--line">' . self::svg( 'play' ) . '</span><span>' . Lang::out( $s, 'btn2' ) . '</span></a>';
		}
		echo '</div></div>';
	}
}
