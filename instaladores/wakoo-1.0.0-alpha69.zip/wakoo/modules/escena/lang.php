<?php
/**
 * Wakoo languages: Spanish (default), English and Chinese for every editable text.
 *
 * Each translatable control is stored three times (id, id_en, id_zh) and printed as three sibling spans with
 * data-wk-l="es|en|zh". A tiny inline script in <head> sets html[data-wakoo-lang] (from ?lang=, the visitor's
 * last choice, or the default) and CSS shows only the matching spans, so pages stay cache-friendly and switching
 * language is instant. Empty translations fall back to Spanish.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Escena;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Lang {

	const LANGS = [
		'es' => 'Español',
		'en' => 'English',
		'zh' => '中文',
	];

	/** Short labels for tabs and the switcher. */
	const SHORT = [
		'es' => 'ES',
		'en' => 'EN',
		'zh' => '中文',
	];

	public static function key( $id, $lang ) {
		return 'es' === $lang ? $id : $id . '_' . $lang;
	}

	/**
	 * Adds one control per language inside ES / EN / 中文 tabs.
	 *
	 * @param \Elementor\Controls_Stack $w    Widget.
	 * @param string                    $id   Base control id (Spanish).
	 * @param string                    $label Label.
	 * @param array                     $d    Defaults [ 'es' => , 'en' => , 'zh' => ].
	 * @param string                    $type text | textarea | wysiwyg.
	 * @param array                     $extra Extra control args (e.g. description).
	 */
	public static function controls( $w, $id, $label, array $d, $type = 'text', array $extra = [] ) {
		$types = [
			'text'     => Controls_Manager::TEXT,
			'textarea' => Controls_Manager::TEXTAREA,
			'wysiwyg'  => Controls_Manager::WYSIWYG,
		];
		$w->start_controls_tabs( $id . '_ltabs' );
		foreach ( self::LANGS as $l => $name ) {
			$w->start_controls_tab( $id . '_ltab_' . $l, [ 'label' => self::SHORT[ $l ] ] );
			$args = [
				'label'       => $label . ' · ' . $name,
				'type'        => $types[ $type ],
				'default'     => $d[ $l ] ?? '',
				'label_block' => true,
				'dynamic'     => [ 'active' => true ],
			];
			if ( 'es' !== $l ) {
				$args['description'] = __( 'Si lo dejas vacío se muestra el texto en español.', 'wakoo' );
			}
			if ( 'textarea' === $type ) {
				$args['rows'] = 3;
			}
			$w->add_control( self::key( $id, $l ), array_merge( $args, $extra ) );
			$w->end_controls_tab();
		}
		$w->end_controls_tabs();
	}

	/** Same for a repeater: three fields with the language in the label (tabs are not reliable inside repeaters). */
	public static function rep( $rep, $id, $label, array $d, $type = 'text' ) {
		foreach ( self::LANGS as $l => $name ) {
			$rep->add_control( self::key( $id, $l ), [
				'label'       => $label . ' · ' . self::SHORT[ $l ],
				'type'        => 'textarea' === $type ? Controls_Manager::TEXTAREA : Controls_Manager::TEXT,
				'default'     => $d[ $l ] ?? '',
				'label_block' => true,
				'rows'        => 2,
			] );
		}
	}

	/** Raw value for a language with Spanish fallback. */
	public static function get( array $s, $id, $lang ) {
		$v = isset( $s[ self::key( $id, $lang ) ] ) ? (string) $s[ self::key( $id, $lang ) ] : '';
		if ( '' === trim( $v ) && 'es' !== $lang ) {
			$v = isset( $s[ $id ] ) ? (string) $s[ $id ] : '';
		}
		return $v;
	}

	/** True when the Spanish (base) value is not empty. */
	public static function has( array $s, $id ) {
		return '' !== trim( (string) ( $s[ $id ] ?? '' ) );
	}

	/**
	 * Prints the three language variants.
	 *
	 * @param string $mode text (escaped) | accent (escaped, {word} => <em>) | lines (one span per line) | html (kses).
	 */
	public static function out( array $s, $id, $mode = 'text', $class = '' ) {
		$html = '';
		foreach ( array_keys( self::LANGS ) as $l ) {
			$v = self::get( $s, $id, $l );
			switch ( $mode ) {
				case 'accent':
					$v = preg_replace( '/\{([^}]+)\}/u', '<em class="wk-esc-accent">$1</em>', esc_html( $v ) );
					$v = str_replace( '|', '<br>', $v );
					break;
				case 'html':
					$v = wp_kses_post( $v );
					break;
				default:
					$v = esc_html( $v );
			}
			$html .= '<span data-wk-l="' . $l . '" lang="' . ( 'zh' === $l ? 'zh-CN' : $l ) . '"' . ( $class ? ' class="' . esc_attr( $class ) . '"' : '' ) . '>' . $v . '</span>';
		}
		return $html;
	}

	/** JSON map for attributes that JS swaps (aria-label, placeholder, alt). */
	public static function map( array $s, $id ) {
		$m = [];
		foreach ( array_keys( self::LANGS ) as $l ) {
			$m[ $l ] = self::get( $s, $id, $l );
		}
		return wp_json_encode( $m );
	}

	/** Inline head script: decides the language before the page paints. */
	public static function head_script() {
		$default = apply_filters( 'wakoo_lang_default', 'es' );
		$detect  = (bool) apply_filters( 'wakoo_lang_detect_browser', false );
		?>
<script id="wakoo-lang-boot">(function(){var L=['es','en','zh'],d=<?php echo wp_json_encode( $default ); ?>,l=null;try{var q=new URLSearchParams(location.search).get('lang');if(q&&L.indexOf(q)>-1){l=q;localStorage.setItem('wakooLang',q);}if(!l){var m=localStorage.getItem('wakooLang');if(L.indexOf(m)>-1)l=m;}}catch(e){}<?php if ( $detect ) : ?>if(!l){var n=(navigator.language||'').slice(0,2);if(L.indexOf(n)>-1)l=n;}<?php endif; ?>l=l||d;var h=document.documentElement;h.setAttribute('data-wakoo-lang',l);h.lang=l==='zh'?'zh-CN':l;})();</script>
		<?php
	}
}
