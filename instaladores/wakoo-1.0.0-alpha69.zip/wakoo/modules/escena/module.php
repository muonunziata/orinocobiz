<?php
/**
 * Wakoo Escena: full-screen "scene" pages (no scroll, glass cards) plus the ES / EN / 中文 language layer.
 *
 * Widgets: cabecera de vidrio, barra lateral, título hero, etiquetas verticales, proyecto destacado, cifras,
 * tarjeta CTA and selector de idioma. Layout classes for containers (wk-esc-frame, wk-esc-card, wk-esc-main,
 * wk-esc-top, wk-esc-bottom) live in escena.css; every image can be replaced from the editor.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Escena;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Module {

	const WIDGETS = [
		'header'  => 'Header',
		'dock'    => 'Dock',
		'hero'    => 'Hero',
		'tags'    => 'Tags',
		'project' => 'Project',
		'stats'   => 'Stats',
		'cta'     => 'Cta',
		'cards'   => 'Cards',
		'works'   => 'Works',
		'contact' => 'Contact',
		'lang'    => 'Lang_Switch',
	];

	public static function url( $path = '' ) {
		return WAKOO_MODULES_URL . 'escena/' . $path;
	}

	public static function img( $name ) {
		return self::url( 'assets/img/' . $name );
	}

	public static function init() {
		require_once __DIR__ . '/lang.php';
		add_action( 'elementor/elements/categories_registered', function ( $mgr ) {
			$mgr->add_category( 'wakoo-escena', [ 'title' => __( 'Wakoo · Escena', 'wakoo' ), 'icon' => 'eicon-device-desktop' ] );
		} );
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widgets' ] );
		add_action( 'elementor/frontend/after_register_scripts', function () {
			wp_register_script( 'wakoo-escena', self::url( 'assets/escena.js' ), [], WAKOO_VERSION, true );
		} );
		add_action( 'elementor/frontend/after_register_styles', function () {
			wp_register_style( 'wakoo-escena', self::url( 'assets/escena.css' ), [], WAKOO_VERSION );
		} );
		// Language boot + visibility rules: tiny, inline, on every front-end page (also the editor preview).
		add_action( 'wp_head', [ __CLASS__, 'head' ], 1 );
		// "Idioma" option for every element (core widgets too): show it only in one language.
		add_action( 'elementor/element/common/_section_style/after_section_end', [ __CLASS__, 'lang_section' ] );
		add_action( 'elementor/element/common-optimized/_section_style/after_section_end', [ __CLASS__, 'lang_section' ] );
		add_action( 'elementor/element/container/section_layout/after_section_end', [ __CLASS__, 'lang_section' ] );
		// Canvas body class so scene pages never scroll.
		add_filter( 'body_class', [ __CLASS__, 'body_class' ], 20 );
		// Scene pages use the bundled Jost font: never call Google Fonts there.
		add_filter( 'elementor/frontend/print_google_fonts', function ( $print ) {
			return self::is_scene() ? false : $print;
		} );
	}

	public static function register_widgets( $wm ) {
		require_once __DIR__ . '/widgets/base.php';
		foreach ( self::WIDGETS as $file => $class ) {
			require_once __DIR__ . '/widgets/' . $file . '.php';
			$fqcn = __NAMESPACE__ . '\\Widgets\\' . $class;
			$wm->register( new $fqcn() );
		}
	}

	public static function head() {
		Lang::head_script();
		echo '<style id="wakoo-lang-css">'
			. 'html:not([data-wakoo-lang="en"]) [data-wk-l="en"],html:not([data-wakoo-lang="zh"]) [data-wk-l="zh"],'
			. 'html[data-wakoo-lang="en"] [data-wk-l="es"],html[data-wakoo-lang="zh"] [data-wk-l="es"],'
			. 'html:not([data-wakoo-lang="en"]) .wk-lang-only-en,html:not([data-wakoo-lang="zh"]) .wk-lang-only-zh,'
			. 'html[data-wakoo-lang="en"] .wk-lang-only-es,html[data-wakoo-lang="zh"] .wk-lang-only-es{display:none!important}'
			. '</style>' . "\n";
	}

	public static function lang_section( $el ) {
		if ( $el->get_controls( 'wk_lang_only' ) ) {
			return;
		}
		$el->start_controls_section( 'wk_lang_section', [
			'label' => __( 'Idioma (Wakoo)', 'wakoo' ),
			'tab'   => Controls_Manager::TAB_ADVANCED,
		] );
		$el->add_control( 'wk_lang_only', [
			'label'        => __( 'Mostrar en', 'wakoo' ),
			'type'         => Controls_Manager::SELECT,
			'default'      => '',
			'options'      => [
				''   => __( 'Todos los idiomas', 'wakoo' ),
				'es' => __( 'Solo español', 'wakoo' ),
				'en' => __( 'Solo inglés', 'wakoo' ),
				'zh' => __( 'Solo chino', 'wakoo' ),
			],
			'prefix_class' => 'wk-lang-only-',
			'description'  => __( 'Para widgets que no son de Wakoo: duplica el elemento, tradúcelo y elige aquí en qué idioma se ve cada copia.', 'wakoo' ),
		] );
		$el->end_controls_section();
	}

	/** True on a singular page whose Elementor content contains a scene frame. */
	public static function is_scene() {
		if ( ! is_singular() ) {
			return false;
		}
		$data = get_post_meta( get_queried_object_id(), '_elementor_data', true );
		return is_string( $data ) && false !== strpos( $data, 'wk-esc-frame' );
	}

	public static function body_class( $classes ) {
		if ( self::is_scene() ) {
			$classes[] = 'wk-esc-page';
			// The scene has its own responsive layout; Wakoo's generic mobile optimizer would fight it.
			$classes   = array_values( array_diff( $classes, [ 'wakoo-rwd' ] ) );
		}
		return $classes;
	}
}

Module::init();
