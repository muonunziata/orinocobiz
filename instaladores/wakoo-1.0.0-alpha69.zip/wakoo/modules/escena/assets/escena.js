/* Wakoo Escena: language switch, header menu/search, video lightbox, project slider, number count-up. No libraries. */
(function () {
	'use strict';

	var LANGS = ['es', 'en', 'zh'];
	var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	/* ------------------------------------------------------------ language */

	function currentLang() {
		var l = document.documentElement.getAttribute('data-wakoo-lang');
		return LANGS.indexOf(l) > -1 ? l : 'es';
	}

	function applyAttrs(root) {
		var l = currentLang();
		(root || document).querySelectorAll('[data-wk-attr]').forEach(function (el) {
			var map;
			try { map = JSON.parse(el.getAttribute('data-wk-attr')); } catch (e) { return; }
			Object.keys(map).forEach(function (attr) {
				var v = map[attr] && (map[attr][l] || map[attr].es);
				if (!v) { return; }
				if (attr === 'text') { el.textContent = v; } else { el.setAttribute(attr, v); }
			});
		});
		(root || document).querySelectorAll('[data-wk-set-lang]').forEach(function (b) {
			var on = b.getAttribute('data-wk-set-lang') === l;
			b.classList.toggle('is-on', on);
			b.setAttribute('aria-pressed', on ? 'true' : 'false');
		});
	}

	function setLang(l) {
		if (LANGS.indexOf(l) < 0) { return; }
		var h = document.documentElement;
		h.setAttribute('data-wakoo-lang', l);
		h.lang = l === 'zh' ? 'zh-CN' : l;
		try { localStorage.setItem('wakooLang', l); } catch (e) {}
		try {
			var u = new URL(location.href);
			if (u.searchParams.has('lang')) { u.searchParams.set('lang', l); history.replaceState(null, '', u); }
		} catch (e) {}
		applyAttrs();
		document.querySelectorAll('[data-wk-msgs]').forEach(function (f) { var m = f.querySelector('.wakoo-form__msg'); if (m) { msgLang(f, m); } });
		document.dispatchEvent(new CustomEvent('wakoo:lang', { detail: { lang: l } }));
	}

	document.addEventListener('click', function (e) {
		var b = e.target.closest && e.target.closest('[data-wk-set-lang]');
		if (b) { e.preventDefault(); setLang(b.getAttribute('data-wk-set-lang')); }
	});

	/* ------------------------------------------------------------ video lightbox */

	function openVideo(src, opener) {
		var box = document.createElement('div');
		box.className = 'wk-esc-lb';
		box.setAttribute('role', 'dialog');
		box.setAttribute('aria-modal', 'true');
		var v = document.createElement('video');
		v.src = src; v.controls = true; v.autoplay = true; v.playsInline = true;
		var x = document.createElement('button');
		x.type = 'button'; x.className = 'wk-esc-round wk-esc-round--light'; x.setAttribute('aria-label', '×'); x.textContent = '×';
		box.appendChild(v); box.appendChild(x);
		document.body.appendChild(box);
		x.focus();
		function close() {
			v.pause(); box.remove(); document.removeEventListener('keydown', key);
			if (opener) { opener.focus(); }
		}
		function key(ev) { if (ev.key === 'Escape') { close(); } }
		x.addEventListener('click', close);
		box.addEventListener('click', function (ev) { if (ev.target === box) { close(); } });
		document.addEventListener('keydown', key);
	}

	document.addEventListener('click', function (e) {
		var a = e.target.closest && e.target.closest('[data-wk-video]');
		if (!a) { return; }
		e.preventDefault();
		openVideo(a.getAttribute('data-wk-video'), a);
	});

	/* ------------------------------------------------------------ header */

	function initHeader(h) {
		var burger = h.querySelector('.wk-esc-head__burger');
		if (burger) {
			burger.addEventListener('click', function () {
				var open = h.classList.toggle('is-open');
				burger.setAttribute('aria-expanded', open ? 'true' : 'false');
			});
			document.addEventListener('click', function (e) {
				if (h.classList.contains('is-open') && !h.contains(e.target)) {
					h.classList.remove('is-open'); burger.setAttribute('aria-expanded', 'false');
				}
			});
			document.addEventListener('keydown', function (e) {
				if (e.key === 'Escape' && h.classList.contains('is-open')) {
					h.classList.remove('is-open'); burger.setAttribute('aria-expanded', 'false'); burger.focus();
				}
			});
		}
		var form = h.querySelector('.wk-esc-head__search');
		if (form) {
			var q = form.querySelector('input'), btn = form.querySelector('.wk-esc-head__sbtn');
			btn.addEventListener('click', function () {
				if (form.classList.contains('is-open') && q.value.trim()) { form.submit(); return; }
				var open = form.classList.toggle('is-open');
				btn.setAttribute('aria-expanded', open ? 'true' : 'false');
				if (open) { q.focus(); }
			});
			q.addEventListener('keydown', function (e) {
				if (e.key === 'Escape') { form.classList.remove('is-open'); btn.setAttribute('aria-expanded', 'false'); btn.focus(); }
			});
		}
	}

	/* ------------------------------------------------------------ project slider */

	function initProject(p) {
		var imgs = p.querySelectorAll('.wk-esc-proj__img');
		var slides = p.querySelectorAll('.wk-esc-proj__slide');
		var bars = p.querySelectorAll('.wk-esc-proj__bars i');
		var count = p.querySelector('.wk-esc-proj__count b');
		var n = slides.length, i = 0, timer = null, cfg = {};
		try { cfg = JSON.parse(p.getAttribute('data-wk-proj') || '{}'); } catch (e) {}
		if (n < 2) { return; }
		function go(k) {
			i = (k + n) % n;
			[imgs, slides, bars].forEach(function (list) {
				list.forEach(function (el, j) { el.classList.toggle('is-on', j === i); });
			});
			slides.forEach(function (el, j) {
				el.setAttribute('aria-hidden', j === i ? 'false' : 'true');
				var a = el.querySelector('a'); if (a) { a.tabIndex = j === i ? 0 : -1; }
			});
			if (count) { count.textContent = (i + 1 < 10 ? '0' : '') + (i + 1); }
		}
		function start() {
			stop();
			if (cfg.autoplay > 0 && !reduce) { timer = setInterval(function () { go(i + 1); }, cfg.autoplay * 1000); }
		}
		function stop() { if (timer) { clearInterval(timer); timer = null; } }
		p.querySelector('.wk-esc-proj__prev').addEventListener('click', function () { go(i - 1); start(); });
		p.querySelector('.wk-esc-proj__next').addEventListener('click', function () { go(i + 1); start(); });
		p.addEventListener('mouseenter', stop);
		p.addEventListener('mouseleave', start);
		p.addEventListener('focusin', stop);
		var x0 = null;
		p.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true });
		p.addEventListener('touchend', function (e) {
			if (x0 === null) { return; }
			var dx = e.changedTouches[0].clientX - x0; x0 = null;
			if (Math.abs(dx) > 40) { go(dx < 0 ? i + 1 : i - 1); start(); }
		});
		start();
	}

	/* ------------------------------------------------------------ works gallery */

	function initWorks(w) {
		var cfg = {}; try { cfg = JSON.parse(w.getAttribute('data-wk-works') || '{}'); } catch (e) {}
		var cards = [].slice.call(w.querySelectorAll('.wk-esc-works__c'));
		var count = w.querySelector('.wk-esc-works__count');
		var filter = '', page = 0;
		var tall = window.matchMedia('(orientation: portrait)');
		function per() { return Math.max(1, (tall.matches ? cfg.tall : cfg.wide) || 4); }
		function draw() {
			var list = cards.filter(function (c) { return !filter || c.getAttribute('data-cat') === filter; });
			var pages = Math.max(1, Math.ceil(list.length / per()));
			page = (page + pages) % pages;
			cards.forEach(function (c) { c.hidden = true; c.classList.remove('is-in'); });
			list.slice(page * per(), page * per() + per()).forEach(function (c, k) {
				c.hidden = false;
				if (!reduce) { c.style.transitionDelay = (k * 60) + 'ms'; requestAnimationFrame(function () { c.classList.add('is-in'); }); } else { c.classList.add('is-in'); }
			});
			if (count) { count.innerHTML = '<b>' + (page + 1 < 10 ? '0' : '') + (page + 1) + '</b> / ' + (pages < 10 ? '0' : '') + pages; }
			w.classList.toggle('is-single', pages < 2);
		}
		w.querySelectorAll('.wk-esc-works__f').forEach(function (b) {
			b.addEventListener('click', function () {
				filter = b.getAttribute('data-f'); page = 0;
				w.querySelectorAll('.wk-esc-works__f').forEach(function (x) { x.classList.toggle('is-on', x === b); x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); });
				draw();
			});
		});
		w.querySelector('.wk-esc-works__prev').addEventListener('click', function () { page--; draw(); });
		w.querySelector('.wk-esc-works__next').addEventListener('click', function () { page++; draw(); });
		if (tall.addEventListener) { tall.addEventListener('change', function () { page = 0; draw(); }); }
		draw();
	}

	/* ------------------------------------------------------------ contact form messages in the current language */

	function msgLang(form, m) {
		var map = {}; try { map = JSON.parse(form.getAttribute('data-wk-msgs') || '{}'); } catch (e) {}
		var key = m.classList.contains('is-ok') ? 'ok' : m.classList.contains('is-err') ? 'err' : m.classList.contains('is-info') ? 'sending' : '';
		var l = currentLang();
		var v = key && map[key] && (map[key][l] || map[key].es);
		if (v && m.textContent !== v) { m.textContent = v; }
	}

	function initMsgs(form) {
		var m = form.querySelector('.wakoo-form__msg');
		if (!m || !('MutationObserver' in window)) { return; }
		new MutationObserver(function () { msgLang(form, m); }).observe(m, { childList: true, characterData: true, subtree: true, attributes: true, attributeFilter: ['class'] });
	}

	/* ------------------------------------------------------------ count-up */

	function initCount(box) {
		var nums = box.querySelectorAll('[data-wk-to]');
		if (reduce || !('IntersectionObserver' in window)) { return; }
		var io = new IntersectionObserver(function (entries) {
			entries.forEach(function (en) {
				if (!en.isIntersecting) { return; }
				io.disconnect();
				nums.forEach(function (el) {
					var to = parseFloat(el.getAttribute('data-wk-to')) || 0, dec = (String(to).split('.')[1] || '').length, t0 = null;
					function step(t) {
						if (t0 === null) { t0 = t; }
						var k = Math.min(1, (t - t0) / 1400), e = 1 - Math.pow(1 - k, 3);
						el.textContent = (to * e).toFixed(dec);
						if (k < 1) { requestAnimationFrame(step); }
					}
					el.textContent = '0';
					requestAnimationFrame(step);
				});
			});
		}, { threshold: 0.3 });
		io.observe(box);
	}

	/* ------------------------------------------------------------ boot */

	function boot(root) {
		root = root || document;
		var scope = root.querySelectorAll ? root : document;
		scope.querySelectorAll('.wk-esc-head').forEach(function (h) { if (!h.dataset.wakooInit) { h.dataset.wakooInit = '1'; initHeader(h); } });
		scope.querySelectorAll('[data-wk-proj]').forEach(function (p) { if (!p.dataset.wakooInit) { p.dataset.wakooInit = '1'; initProject(p); } });
		scope.querySelectorAll('[data-wk-works]').forEach(function (w) { if (!w.dataset.wakooInit) { w.dataset.wakooInit = '1'; initWorks(w); } });
		scope.querySelectorAll('[data-wk-msgs]').forEach(function (f) { if (!f.dataset.wakooMsgs) { f.dataset.wakooMsgs = '1'; initMsgs(f); } });
		scope.querySelectorAll('[data-wk-count]').forEach(function (b) { if (!b.dataset.wakooInit) { b.dataset.wakooInit = '1'; initCount(b); } });
		applyAttrs(scope);
	}

	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', function () { boot(); }); } else { boot(); }

	// Elementor editor preview re-renders widgets one by one.
	window.addEventListener('elementor/frontend/init', function () {
		if (!window.elementorFrontend || !window.elementorFrontend.hooks) { return; }
		window.elementorFrontend.hooks.addAction('frontend/element_ready/global', function ($el) {
			var el = $el && $el[0];
			if (el && el.querySelector && el.querySelector('.wk-esc-head, [data-wk-proj], [data-wk-count], [data-wk-set-lang], [data-wk-attr], [data-wk-works], [data-wk-msgs]')) { boot(el); }
		});
	});

	window.WakooLang = { set: setLang, get: currentLang };
})();
