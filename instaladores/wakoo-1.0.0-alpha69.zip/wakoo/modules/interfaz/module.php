<?php
/**
 * Wakoo Interfaz: animated interface widgets (sidebar, tab bars, login screens, OTP, dashboard, scroll video).
 *
 * The login, sign-up and code widgets talk to WordPress for real through admin-ajax. The server never trusts
 * the browser for options: it reads the widget's own settings from the Elementor document (post id + element id).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Interfaz;

defined( 'ABSPATH' ) || die();

class Module {

	const WIDGETS = [
		'sidebar'      => 'Sidebar',
		'tabbar'       => 'Tabbar',
		'liquid-login' => 'Liquid_Login',
		'glass-auth'   => 'Glass_Auth',
		'slide-auth'   => 'Slide_Auth',
		'scroll-video' => 'Scroll_Video',
		'dashboard'    => 'Dashboard',
		'otp'          => 'Otp',
	];

	public static function url( $path = '' ) {
		return WAKOO_MODULES_URL . 'interfaz/' . $path;
	}

	public static function init() {
		add_action( 'elementor/elements/categories_registered', function ( $mgr ) {
			$mgr->add_category( 'wakoo-interfaz', [ 'title' => __( 'Wakoo · Interfaz', 'wakoo' ), 'icon' => 'eicon-apps' ] );
		} );
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widgets' ] );
		add_action( 'elementor/frontend/after_register_scripts', function () {
			wp_register_script( 'wakoo-ui-core', self::url( 'assets/core.js' ), [], WAKOO_VERSION, true );
			wp_localize_script( 'wakoo-ui-core', 'wakooUi', [ 'ajax' => admin_url( 'admin-ajax.php' ) ] );
			foreach ( array_keys( self::WIDGETS ) as $w ) {
				wp_register_script( 'wakoo-ui-' . $w, self::url( 'assets/' . $w . '.js' ), [ 'wakoo-ui-core' ], WAKOO_VERSION, true );
			}
		} );
		add_action( 'elementor/frontend/after_register_styles', function () {
			foreach ( array_keys( self::WIDGETS ) as $w ) {
				wp_register_style( 'wakoo-ui-' . $w, self::url( 'assets/' . $w . '.css' ), [], WAKOO_VERSION );
			}
		} );
		foreach ( [ 'login', 'register', 'otp_send', 'otp_verify' ] as $a ) {
			add_action( 'wp_ajax_wakoo_ui_' . $a, [ __CLASS__, 'ajax_' . $a ] );
			add_action( 'wp_ajax_nopriv_wakoo_ui_' . $a, [ __CLASS__, 'ajax_' . $a ] );
		}
	}

	public static function register_widgets( $wm ) {
		require_once __DIR__ . '/widgets/base.php';
		foreach ( self::WIDGETS as $file => $class ) {
			if ( ! is_file( __DIR__ . '/widgets/' . $file . '.php' ) ) {
				continue;
			}
			require_once __DIR__ . '/widgets/' . $file . '.php';
			$fqcn = __NAMESPACE__ . '\\Widgets\\' . $class;
			$wm->register( new $fqcn() );
		}
	}

	/* ---------------------------------------------------------------- helpers */

	/** Settings of one element of an Elementor document, or null. */
	public static function element_settings( $post_id, $el_id ) {
		$post_id = absint( $post_id );
		$el_id   = preg_replace( '/[^a-z0-9]/i', '', (string) $el_id );
		if ( ! $post_id || ! $el_id || ! class_exists( '\Elementor\Plugin' ) ) {
			return null;
		}
		$doc = \Elementor\Plugin::$instance->documents->get( $post_id );
		if ( ! $doc ) {
			return null;
		}
		$found = null;
		$walk  = function ( $els ) use ( &$walk, &$found, $el_id ) {
			foreach ( (array) $els as $el ) {
				if ( $found ) {
					return;
				}
				if ( isset( $el['id'] ) && $el['id'] === $el_id ) {
					$found = isset( $el['settings'] ) ? (array) $el['settings'] : [];
					return;
				}
				if ( ! empty( $el['elements'] ) ) {
					$walk( $el['elements'] );
				}
			}
		};
		$walk( $doc->get_elements_data() );
		return $found;
	}

	/** Simple per-visitor limiter (hashed IP, no personal data stored). */
	protected static function limited( $bucket, $max, $window ) {
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$key = 'wk_ui_' . $bucket . '_' . substr( hash_hmac( 'sha256', $ip, wp_salt( 'nonce' ) ), 0, 20 );
		$n   = (int) get_transient( $key );
		if ( $n >= $max ) {
			return true;
		}
		set_transient( $key, $n + 1, $window );
		return false;
	}

	protected static function start( $bucket, $max, $window ) {
		check_ajax_referer( 'wakoo_ui_auth', 'nonce' );
		if ( self::limited( $bucket, $max, $window ) ) {
			wp_send_json_error( [ 'msg' => __( 'Demasiados intentos. Espera unos minutos.', 'wakoo' ) ], 429 );
		}
		$s = self::element_settings( isset( $_POST['post'] ) ? wp_unslash( $_POST['post'] ) : 0, isset( $_POST['el'] ) ? wp_unslash( $_POST['el'] ) : '' );
		if ( null === $s ) {
			wp_send_json_error( [ 'msg' => __( 'No se encontró el formulario.', 'wakoo' ) ], 400 );
		}
		return $s;
	}

	protected static function redirect_from( $s, $key = 'redirect' ) {
		$url = isset( $s[ $key ]['url'] ) ? $s[ $key ]['url'] : '';
		return $url ? esc_url_raw( $url ) : '';
	}

	/* ---------------------------------------------------------------- login / sign-up */

	public static function ajax_login() {
		$s = self::start( 'login', 10, 15 * MINUTE_IN_SECONDS );
		if ( 'demo' === ( $s['action_mode'] ?? 'login' ) ) {
			wp_send_json_success( [ 'demo' => 1, 'redirect' => self::redirect_from( $s ) ] );
		}
		$login = isset( $_POST['user'] ) ? sanitize_text_field( wp_unslash( $_POST['user'] ) ) : '';
		$pass  = isset( $_POST['pass'] ) ? (string) wp_unslash( $_POST['pass'] ) : '';
		if ( '' === $login || '' === $pass ) {
			wp_send_json_error( [ 'msg' => __( 'Escribe tu usuario o email y tu contraseña.', 'wakoo' ) ] );
		}
		if ( is_email( $login ) ) {
			$u = get_user_by( 'email', $login );
			if ( $u ) {
				$login = $u->user_login;
			}
		}
		$user = wp_signon( [ 'user_login' => $login, 'user_password' => $pass, 'remember' => ! empty( $_POST['remember'] ) ], is_ssl() );
		if ( is_wp_error( $user ) ) {
			wp_send_json_error( [ 'msg' => __( 'Usuario o contraseña incorrectos.', 'wakoo' ) ] );
		}
		wp_send_json_success( [ 'redirect' => self::redirect_from( $s ), 'name' => $user->display_name ] );
	}

	public static function ajax_register() {
		$s = self::start( 'reg', 5, HOUR_IN_SECONDS );
		if ( 'demo' === ( $s['action_mode'] ?? 'login' ) ) {
			wp_send_json_success( [ 'demo' => 1, 'redirect' => self::redirect_from( $s, 'redirect_reg' ) ] );
		}
		if ( ! get_option( 'users_can_register' ) ) {
			wp_send_json_error( [ 'msg' => __( 'El registro está cerrado en este sitio.', 'wakoo' ) ] );
		}
		if ( ! empty( $_POST['wk_hp'] ) ) {
			wp_send_json_error( [ 'msg' => __( 'No se pudo crear la cuenta.', 'wakoo' ) ] );
		}
		$name  = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$pass  = isset( $_POST['pass'] ) ? (string) wp_unslash( $_POST['pass'] ) : '';
		$pass2 = isset( $_POST['pass2'] ) ? (string) wp_unslash( $_POST['pass2'] ) : $pass;
		if ( ! is_email( $email ) ) {
			wp_send_json_error( [ 'msg' => __( 'Escribe un email válido.', 'wakoo' ) ] );
		}
		if ( email_exists( $email ) ) {
			wp_send_json_error( [ 'msg' => __( 'Ya hay una cuenta con ese email.', 'wakoo' ) ] );
		}
		if ( strlen( $pass ) < 8 ) {
			wp_send_json_error( [ 'msg' => __( 'La contraseña necesita al menos 8 caracteres.', 'wakoo' ) ] );
		}
		if ( $pass !== $pass2 ) {
			wp_send_json_error( [ 'msg' => __( 'Las contraseñas no coinciden.', 'wakoo' ) ] );
		}
		$base  = sanitize_user( $name ? $name : strstr( $email, '@', true ), true );
		$base  = $base ? strtolower( str_replace( ' ', '', $base ) ) : 'usuario';
		$login = $base;
		for ( $i = 2; username_exists( $login ); $i++ ) {
			$login = $base . $i;
		}
		$id = wp_insert_user( [
			'user_login'   => $login,
			'user_email'   => $email,
			'user_pass'    => $pass,
			'display_name' => $name ? $name : $login,
			'first_name'   => $name,
			'role'         => get_option( 'default_role', 'subscriber' ),
		] );
		if ( is_wp_error( $id ) ) {
			wp_send_json_error( [ 'msg' => $id->get_error_message() ] );
		}
		wp_new_user_notification( $id, null, 'admin' );
		wp_set_current_user( $id );
		wp_set_auth_cookie( $id, true, is_ssl() );
		wp_send_json_success( [ 'redirect' => self::redirect_from( $s, 'redirect_reg' ) ] );
	}

	/* ---------------------------------------------------------------- one-time codes by email */

	protected static function otp_key( $email, $el ) {
		return 'wk_ui_otp_' . substr( hash_hmac( 'sha256', strtolower( $email ) . '|' . $el, wp_salt( 'auth' ) ), 0, 32 );
	}

	public static function ajax_otp_send() {
		$s = self::start( 'otps', 5, HOUR_IN_SECONDS );
		if ( 'email' !== ( $s['otp_mode'] ?? 'demo' ) ) {
			wp_send_json_success( [ 'demo' => 1 ] );
		}
		$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		if ( ! is_email( $email ) ) {
			wp_send_json_error( [ 'msg' => __( 'Escribe un email válido.', 'wakoo' ) ] );
		}
		$len  = max( 4, min( 8, (int) ( $s['digits'] ?? 4 ) ) );
		$code = '';
		for ( $i = 0; $i < $len; $i++ ) {
			$code .= (string) random_int( 0, 9 );
		}
		$el = isset( $_POST['el'] ) ? sanitize_key( wp_unslash( $_POST['el'] ) ) : '';
		set_transient( self::otp_key( $email, $el ), [ 'h' => wp_hash_password( $code ), 'n' => 0 ], 10 * MINUTE_IN_SECONDS );
		$subject = ! empty( $s['mail_subject'] ) ? $s['mail_subject'] : __( 'Tu código de verificación', 'wakoo' );
		/* translators: 1: code, 2: site name */
		$body = sprintf( __( "Tu código es: %1\$s\n\nCaduca en 10 minutos. Si no lo pediste, ignora este mensaje.\n\n%2\$s", 'wakoo' ), $code, get_bloginfo( 'name' ) );
		if ( ! wp_mail( $email, $subject, $body ) ) {
			wp_send_json_error( [ 'msg' => __( 'No se pudo enviar el email.', 'wakoo' ) ] );
		}
		wp_send_json_success( [ 'sent' => 1 ] );
	}

	public static function ajax_otp_verify() {
		$s    = self::start( 'otpv', 30, 15 * MINUTE_IN_SECONDS );
		$code = isset( $_POST['code'] ) ? preg_replace( '/\D/', '', wp_unslash( $_POST['code'] ) ) : '';
		if ( 'email' !== ( $s['otp_mode'] ?? 'demo' ) ) {
			$want = preg_replace( '/\D/', '', (string) ( $s['demo_code'] ?? '1234' ) ); // Elementor does not store control defaults
			if ( '' === $want || hash_equals( $want, $code ) ) {
				wp_send_json_success( [ 'redirect' => self::redirect_from( $s ) ] );
			}
			wp_send_json_error( [ 'msg' => __( 'Código incorrecto.', 'wakoo' ), 'bad' => 1 ] );
		}
		$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$el    = isset( $_POST['el'] ) ? sanitize_key( wp_unslash( $_POST['el'] ) ) : '';
		$key   = self::otp_key( $email, $el );
		$data  = get_transient( $key );
		if ( ! $data || $data['n'] >= 5 ) {
			delete_transient( $key );
			wp_send_json_error( [ 'msg' => __( 'El código caducó. Pide uno nuevo.', 'wakoo' ), 'expired' => 1 ] );
		}
		if ( ! wp_check_password( $code, $data['h'] ) ) {
			$data['n']++;
			set_transient( $key, $data, 10 * MINUTE_IN_SECONDS );
			wp_send_json_error( [ 'msg' => __( 'Código incorrecto.', 'wakoo' ), 'bad' => 1 ] );
		}
		delete_transient( $key );
		$out = [ 'redirect' => self::redirect_from( $s ) ];
		if ( 'yes' === ( $s['otp_login'] ?? '' ) ) {
			$u = get_user_by( 'email', $email );
			if ( $u && ! user_can( $u, 'manage_options' ) ) {
				wp_set_current_user( $u->ID );
				wp_set_auth_cookie( $u->ID, true, is_ssl() );
				$out['logged'] = 1;
			}
		}
		wp_send_json_success( $out );
	}
}

Module::init();
