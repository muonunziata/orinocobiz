<?php
/**
 * Panel (dashboard V18): dark pill rail with tooltips and an arrow on the active view, and views that
 * blur in card by card: Resumen, Guardados, Almacenamiento or any saved Elementor template.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Interfaz\Widgets;

use Elementor\Controls_Manager;
use Elementor\Repeater;

defined( 'ABSPATH' ) || die();

class Dashboard extends Base {

	const LABELS = [
		'members' => 'Members',
		'impact' => 'Impact',
		'statistics' => 'Statistics',
		'weekly' => 'Weekly',
		'monthly' => 'Monthly',
		'tasks' => 'Tasks complete',
		'pcomplete' => 'Project complete',
		'pprogress' => 'Project in progress',
		'lastvideos' => 'Last videos',
		'notifications' => 'Notifications',
		'overview' => 'Overview',
		'shared' => 'Shared',
		'comments' => 'Comments',
		'link' => 'Link',
		'all' => 'All',
		'videos' => 'Videos',
		'docs' => 'Docs',
		'links' => 'Links',
		'restore' => 'Restore all',
		'collections' => 'Collections',
		'items' => 'items',
		'savednow' => 'items saved right now',
		'storage' => 'Storage',
		'usedof' => '%1$s GB of %2$s GB used',
		'of' => 'of',
		'upload' => 'Upload file',
		'folders' => 'Folders',
		'recent' => 'Recent files',
	];

	private $s = [];

	private function l( $k ) {
		$v = $this->s[ 'lbl_' . $k ] ?? '';
		return esc_html( '' !== $v ? $v : self::LABELS[ $k ] );
	}

	protected function asset() { return 'dashboard'; }
	public function get_name() { return 'wakoo-ui-dashboard'; }
	public function get_title() { return __( 'Panel (dashboard)', 'wakoo' ); }
	public function get_icon() { return 'eicon-dashboard'; }
	public function get_keywords() { return [ 'dashboard', 'panel', 'admin', 'estadisticas', 'app', 'saas', 'wakoo' ]; }

	private function templates() {
		$out = [ '' => __( '— Elige una plantilla —', 'wakoo' ) ];
		$q   = get_posts( [ 'post_type' => 'elementor_library', 'posts_per_page' => 200, 'post_status' => 'publish', 'orderby' => 'title', 'order' => 'ASC' ] );
		foreach ( $q as $p ) {
			$out[ (string) $p->ID ] = $p->post_title;
		}
		return $out;
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_views', [ 'label' => __( 'Barra y vistas', 'wakoo' ) ] );
		$this->add_control( 'logo', [ 'label' => __( 'Logo', 'wakoo' ), 'type' => Controls_Manager::ICONS, 'default' => [ 'value' => 'fas fa-feather-alt', 'library' => 'fa-solid' ] ] );
		$r = new Repeater();
		$r->add_control( 'label', [ 'label' => __( 'Nombre (tooltip)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Vista', 'wakoo' ) ] );
		$r->add_control( 'icon', [ 'label' => __( 'Icono', 'wakoo' ), 'type' => Controls_Manager::ICONS, 'default' => [ 'value' => 'fas fa-th-large', 'library' => 'fa-solid' ] ] );
		$r->add_control( 'kind', [
			'label'   => __( 'Contenido', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'overview',
			'options' => [
				'overview' => __( 'Resumen (tarjetas del vídeo)', 'wakoo' ),
				'saved'    => __( 'Guardados', 'wakoo' ),
				'storage'  => __( 'Almacenamiento', 'wakoo' ),
				'template' => __( 'Una plantilla de Elementor', 'wakoo' ),
				'link'     => __( 'Solo un enlace', 'wakoo' ),
			],
		] );
		$r->add_control( 'template', [ 'label' => __( 'Plantilla', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'options' => $this->templates(), 'default' => '', 'condition' => [ 'kind' => 'template' ], 'description' => __( 'Diseña la vista en Plantillas → Plantillas guardadas y elígela aquí.', 'wakoo' ) ] );
		$r->add_control( 'link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL, 'condition' => [ 'kind' => 'link' ] ] );
		$this->add_control( 'views', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'title_field' => '{{{ label }}}',
			'default'     => [
				[ 'label' => 'Videos', 'icon' => [ 'value' => 'fas fa-video', 'library' => 'fa-solid' ], 'kind' => 'link' ],
				[ 'label' => 'Profile', 'icon' => [ 'value' => 'far fa-user', 'library' => 'fa-regular' ], 'kind' => 'link' ],
				[ 'label' => 'Dashboard', 'icon' => [ 'value' => 'fas fa-th-large', 'library' => 'fa-solid' ], 'kind' => 'overview' ],
				[ 'label' => 'Saved', 'icon' => [ 'value' => 'far fa-bookmark', 'library' => 'fa-regular' ], 'kind' => 'saved' ],
				[ 'label' => 'Cloud', 'icon' => [ 'value' => 'fas fa-cloud', 'library' => 'fa-solid' ], 'kind' => 'storage' ],
				[ 'label' => 'Messages', 'icon' => [ 'value' => 'far fa-comment-dots', 'library' => 'fa-regular' ], 'kind' => 'link' ],
				[ 'label' => 'Settings', 'icon' => [ 'value' => 'fas fa-cog', 'library' => 'fa-solid' ], 'kind' => 'link' ],
			],
		] );
		$this->add_control( 'logout', [ 'label' => __( 'Botón de salir abajo', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'hash', [ 'label' => __( 'Recordar la vista en la dirección (#vista)', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();

		/* Resumen */
		$this->start_controls_section( 'sec_over', [ 'label' => __( 'Vista Resumen', 'wakoo' ) ] );
		$this->add_control( 'b_title', [ 'label' => __( 'Banner: título (*acento*)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => "Work's always better *together*", 'label_block' => true ] );
		$this->add_control( 'b_text', [ 'label' => __( 'Banner: texto', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'default' => "Add teammates and you'll be able to collaborate and quickly get a sense of what's happening at work." ] );
		$this->add_control( 'b_btn', [ 'label' => __( 'Banner: botón', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Add member' ] );
		$this->add_control( 'b_link', [ 'label' => __( 'Banner: enlace', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$m = new Repeater();
		$m->add_control( 'name', [ 'label' => __( 'Nombre', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Sophia Brown' ] );
		$m->add_control( 'photo', [ 'label' => __( 'Foto', 'wakoo' ), 'type' => Controls_Manager::MEDIA ] );
		$this->add_control( 'members', [ 'label' => __( 'Miembros', 'wakoo' ), 'type' => Controls_Manager::REPEATER, 'fields' => $m->get_controls(), 'title_field' => '{{{ name }}}', 'default' => [ [ 'name' => 'Sophia Brown' ], [ 'name' => 'Alex Johnson' ], [ 'name' => 'Daniel Turner' ], [ 'name' => 'Mia Lopez' ], [ 'name' => 'Leo Park' ], [ 'name' => 'Emma Ross' ] ] ] );
		$this->add_control( 'd_value', [ 'label' => __( 'Dato principal', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '10,2h', 'separator' => 'before' ] );
		$this->add_control( 'd_label', [ 'label' => __( 'Nombre del dato', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Data' ] );
		$this->add_control( 'impact', [ 'label' => __( 'Barras «Impact» (números separados por comas)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '42,78,58' ] );
		$this->add_control( 's_a', [ 'label' => __( 'Estadística: tareas hechas', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 47 ] );
		$this->add_control( 's_b', [ 'label' => __( 'Estadística: total', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 75 ] );
		$this->add_control( 'meet', [ 'label' => __( 'Reunión destacada', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Breakthrough Brainstorm' ] );
		$this->add_control( 'meet_t', [ 'label' => __( 'Hora de la reunión', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '12:40 pm' ] );
		$this->add_control( 'p_title', [ 'label' => __( 'Promoción: título', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Unleash Your Potential' ] );
		$this->add_control( 'p_text', [ 'label' => __( 'Promoción: texto', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Indulge in the ultimate subscription' ] );
		$this->add_control( 'p_btn', [ 'label' => __( 'Promoción: botón', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Upgrade plan' ] );
		$this->add_control( 'p_link', [ 'label' => __( 'Promoción: enlace', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$v = new Repeater();
		$v->add_control( 'title', [ 'label' => __( 'Título', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Video' ] );
		$v->add_control( 'dur', [ 'label' => __( 'Duración', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '8 min' ] );
		$v->add_control( 'image', [ 'label' => __( 'Imagen', 'wakoo' ), 'type' => Controls_Manager::MEDIA ] );
		$v->add_control( 'color', [ 'label' => __( 'Color (sin imagen)', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#7B4DFF' ] );
		$v->add_control( 'link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$this->add_control( 'videos', [ 'label' => __( 'Últimos vídeos', 'wakoo' ), 'type' => Controls_Manager::REPEATER, 'fields' => $v->get_controls(), 'title_field' => '{{{ title }}}', 'default' => [
			[ 'title' => 'Brain Aneurysm Clipping with the Leica M530 OH6', 'dur' => '8 min', 'color' => '#7B4DFF' ],
			[ 'title' => 'About the National Hospital for Neurology', 'dur' => '6 min', 'color' => '#3D6BFF' ],
			[ 'title' => 'Visualizing the Surgical Field', 'dur' => '5 min', 'color' => '#E0457B' ],
		] ] );
		$n = new Repeater();
		$n->add_control( 'name', [ 'label' => __( 'Quién', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Jennifer Campbell' ] );
		$n->add_control( 'text', [ 'label' => __( 'Texto', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'invites You to a Call', 'label_block' => true ] );
		$n->add_control( 'time', [ 'label' => __( 'Cuándo', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '15 min ago' ] );
		$this->add_control( 'notes', [ 'label' => __( 'Notificaciones', 'wakoo' ), 'type' => Controls_Manager::REPEATER, 'fields' => $n->get_controls(), 'title_field' => '{{{ name }}}', 'default' => [
			[ 'name' => 'Jennifer Campbell', 'text' => "invites You to a Call: 'Personal Development Strategies'", 'time' => '15 min ago' ],
			[ 'name' => 'Sarah Thompson', 'text' => "left a Comment on Your Video: 'Mastering the Art of Photography'", 'time' => '1 hour ago' ],
			[ 'name' => 'David Turner', 'text' => 'Watched Your Video', 'time' => '3 hours ago' ],
		] ] );
		$this->end_controls_section();

		/* Guardados */
		$this->start_controls_section( 'sec_saved', [ 'label' => __( 'Vista Guardados', 'wakoo' ) ] );
		$this->add_control( 'sv_title', [ 'label' => __( 'Título', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Saved for later' ] );
		$this->add_control( 'sv_sub', [ 'label' => __( 'Subtítulo', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Videos, docs and links you bookmarked across the workspace.', 'label_block' => true ] );
		$si = new Repeater();
		$si->add_control( 'type', [ 'label' => __( 'Tipo', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'video', 'options' => [ 'video' => 'Video', 'doc' => 'Doc', 'link' => 'Link' ] ] );
		$si->add_control( 'title', [ 'label' => __( 'Título', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Item' ] );
		$si->add_control( 'meta', [ 'label' => __( 'Detalle', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Library' ] );
		$si->add_control( 'color', [ 'label' => __( 'Color', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#C9B8F5' ] );
		$si->add_control( 'image', [ 'label' => __( 'Imagen', 'wakoo' ), 'type' => Controls_Manager::MEDIA ] );
		$si->add_control( 'link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$this->add_control( 'saved', [ 'type' => Controls_Manager::REPEATER, 'fields' => $si->get_controls(), 'title_field' => '{{{ title }}}', 'default' => [
			[ 'type' => 'video', 'title' => 'Brain Aneurysm Clipping with the Leica M530', 'meta' => 'Last videos', 'color' => '#7B4DFF' ],
			[ 'type' => 'doc', 'title' => 'Q2 Design Review — Findings & Next Steps', 'meta' => 'Workspace Studio', 'color' => '#C9B8F5' ],
			[ 'type' => 'link', 'title' => 'Material motion guidelines', 'meta' => 'm3.material.io', 'color' => '#F7C6DE' ],
			[ 'type' => 'video', 'title' => 'Awake Craniotomy: Language Mapping', 'meta' => 'Library', 'color' => '#D93A6A' ],
			[ 'type' => 'doc', 'title' => 'Onboarding checklist for new teammates', 'meta' => 'People Ops', 'color' => '#C7E8C9' ],
			[ 'type' => 'link', 'title' => 'Inclusive design patterns cheat sheet', 'meta' => 'a11yproject.com', 'color' => '#C9DBFA' ],
			[ 'type' => 'video', 'title' => 'Endoscopic Pituitary Surgery Walkthrough', 'meta' => 'Library', 'color' => '#2FA58F' ],
		] ] );
		$co = new Repeater();
		$co->add_control( 'name', [ 'label' => __( 'Colección', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Collection' ] );
		$co->add_control( 'count', [ 'label' => __( 'Elementos', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 12 ] );
		$co->add_control( 'pct', [ 'label' => __( 'Progreso (%)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 60 ] );
		$this->add_control( 'collections', [ 'label' => __( 'Colecciones', 'wakoo' ), 'type' => Controls_Manager::REPEATER, 'fields' => $co->get_controls(), 'title_field' => '{{{ name }}}', 'default' => [
			[ 'name' => 'Neurosurgery reference', 'count' => 24, 'pct' => 80 ],
			[ 'name' => 'Design inspiration', 'count' => 41, 'pct' => 55 ],
			[ 'name' => 'Team onboarding', 'count' => 9, 'pct' => 35 ],
			[ 'name' => 'Read later', 'count' => 17, 'pct' => 20 ],
		] ] );
		$this->end_controls_section();

		/* Almacenamiento */
		$this->start_controls_section( 'sec_store', [ 'label' => __( 'Vista Almacenamiento', 'wakoo' ) ] );
		$this->add_control( 'st_title', [ 'label' => __( 'Título', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Cloud storage' ] );
		$this->add_control( 'st_used', [ 'label' => __( 'Usado (GB)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 4.2, 'step' => 0.1 ] );
		$this->add_control( 'st_total', [ 'label' => __( 'Total (GB)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 10 ] );
		$sg = new Repeater();
		$sg->add_control( 'label', [ 'label' => __( 'Tipo', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Videos' ] );
		$sg->add_control( 'value', [ 'label' => __( 'GB', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 1, 'step' => 0.1 ] );
		$sg->add_control( 'color', [ 'label' => __( 'Color', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#7B4DFF' ] );
		$this->add_control( 'segments', [ 'label' => __( 'Reparto', 'wakoo' ), 'type' => Controls_Manager::REPEATER, 'fields' => $sg->get_controls(), 'title_field' => '{{{ label }}}', 'default' => [
			[ 'label' => 'Videos', 'value' => 2.4, 'color' => '#111111' ], [ 'label' => 'Images', 'value' => 1.1, 'color' => '#8C7BFF' ], [ 'label' => 'Docs', 'value' => 0.7, 'color' => '#F3A6C8' ],
		] ] );
		$fo = new Repeater();
		$fo->add_control( 'name', [ 'label' => __( 'Carpeta o archivo', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Folder' ] );
		$fo->add_control( 'info', [ 'label' => __( 'Detalle', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '12 files · 2.1 GB' ] );
		$fo->add_control( 'file', [ 'label' => __( 'Es un archivo (va a «Recientes»)', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ] );
		$fo->add_control( 'link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$this->add_control( 'folders', [ 'label' => __( 'Carpetas y archivos', 'wakoo' ), 'type' => Controls_Manager::REPEATER, 'fields' => $fo->get_controls(), 'title_field' => '{{{ name }}}', 'default' => [
			[ 'name' => 'Surgery footage', 'info' => '32 files · 2.4 GB' ], [ 'name' => 'Lecture slides', 'info' => '18 files · 640 MB' ], [ 'name' => 'Brand assets', 'info' => '54 files · 820 MB' ], [ 'name' => 'Team photos', 'info' => '120 files · 1.1 GB' ],
			[ 'name' => 'Q2-review.pdf', 'info' => '2.4 MB · Today', 'file' => 'yes' ], [ 'name' => 'craniotomy-final.mp4', 'info' => '480 MB · Yesterday', 'file' => 'yes' ], [ 'name' => 'onboarding.docx', 'info' => '96 KB · Mon', 'file' => 'yes' ],
		] ] );
		$this->end_controls_section();

		/* Etiquetas */
		$this->start_controls_section( 'sec_labels', [ 'label' => __( 'Etiquetas fijas', 'wakoo' ) ] );
		foreach ( self::LABELS as $k => $d ) {
			$this->add_control( 'lbl_' . $k, [ 'label' => $d, 'type' => Controls_Manager::TEXT, 'default' => $d ] );
		}
		$this->end_controls_section();

		/* Estilo */
		$this->start_controls_section( 'st_main', [ 'label' => __( 'Colores y tamaño', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_responsive_control( 'db_h', [
			'label'      => __( 'Alto', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px', 'vh' ],
			'range'      => [ 'px' => [ 'min' => 480, 'max' => 1400 ], 'vh' => [ 'min' => 50, 'max' => 100 ] ],
			'default'    => [ 'unit' => 'px', 'size' => 780 ],
			'selectors'  => [ '{{WRAPPER}} .wk-ui-db' => '--db-h: {{SIZE}}{{UNIT}};' ],
		] );
		$this->var_color( 'c_bg', __( 'Fondo', 'wakoo' ), '--db-bg', '#EEEFF3' );
		$this->var_color( 'c_card', __( 'Tarjetas', 'wakoo' ), '--db-card', '#FFFFFF' );
		$this->var_color( 'c_rail', __( 'Barra', 'wakoo' ), '--db-rail', '#101012' );
		$this->var_color( 'c_ac', __( 'Acento (lavanda)', 'wakoo' ), '--db-ac', '#B9A8FF' );
		$this->var_color( 'c_text', __( 'Texto', 'wakoo' ), '--db-text', '#141418' );
		$this->var_color( 'c_muted', __( 'Texto suave', 'wakoo' ), '--db-muted', '#8B8D98' );
		$this->var_slider( 'radius', __( 'Redondez de las tarjetas', 'wakoo' ), '--db-r', 18, 0, 36 );
		$this->typo( 't_h', __( 'Títulos', 'wakoo' ), '.wk-ui-db h3, .wk-ui-db__h' );
		$this->typo( 't_b', __( 'Textos', 'wakoo' ), '.wk-ui-db' );
		$this->end_controls_section();
	}

	/* ---------------------------------------------------------------- helpers */

	private function accent( $text ) {
		$p = explode( '*', esc_html( (string) $text ) );
		$o = '';
		foreach ( $p as $i => $x ) { $o .= $i % 2 ? '<em>' . $x . '</em>' : $x; }
		return $o;
	}

	private function avatar( $name, $url = '' ) {
		if ( $url ) {
			return '<img class="wk-ui-db__av" src="' . esc_url( $url ) . '" alt="">';
		}
		$cols = [ '#F6C7A8', '#B9D3F5', '#D9C8F7', '#BFE5C9', '#F7D58A', '#F3B2C7' ];
		$c    = $cols[ abs( crc32( $name ) ) % count( $cols ) ];
		$in   = strtoupper( mb_substr( $name, 0, 1 ) . mb_substr( (string) strrchr( ' ' . $name, ' ' ), 1, 1 ) );
		return '<span class="wk-ui-db__av" style="--c:' . esc_attr( $c ) . '">' . esc_html( $in ) . '</span>';
	}

	private function blob( $color, $img = '' ) {
		if ( $img ) {
			return '<span class="wk-ui-db__thumb"><img src="' . esc_url( $img ) . '" alt="" loading="lazy"></span>';
		}
		return '<span class="wk-ui-db__thumb"><span class="wk-ui-db__blob" style="--c:' . esc_attr( $color ) . '"></span></span>';
	}

	private function href( $l ) {
		return ! empty( $l['url'] ) ? esc_url( $l['url'] ) : '#';
	}

	private function view_overview( $s ) {
		ob_start();
		$members = (array) $s['members'];
		$bars    = array_map( 'floatval', array_filter( array_map( 'trim', explode( ',', (string) $s['impact'] ) ), 'strlen' ) );
		$max     = $bars ? max( $bars ) : 1;
		$pct     = max( 0, min( 100, ( (float) $s['s_b'] ) ? 100 * (float) $s['s_a'] / (float) $s['s_b'] : 0 ) );
		$ts      = current_time( 'timestamp' );
		?>
		<div class="wk-ui-db__over">
			<div class="wk-ui-db__left">
				<div class="wk-ui-db__card wk-ui-db__banner">
					<div><h3><?php echo $this->accent( $s['b_title'] ); // phpcs:ignore ?></h3><p><?php echo esc_html( $s['b_text'] ); ?></p>
					<a class="wk-ui-db__pill" href="<?php echo $this->href( $s['b_link'] ); // phpcs:ignore ?>"><span>+</span><?php echo esc_html( $s['b_btn'] ); ?></a></div>
					<span class="wk-ui-db__flower" aria-hidden="true"></span>
				</div>
				<div class="wk-ui-db__row3">
					<div class="wk-ui-db__card"><div class="wk-ui-db__h"><?php echo $this->l( 'members' ); ?> <span class="wk-ui-db__plus">+</span></div>
						<div class="wk-ui-db__members"><?php foreach ( array_slice( $members, 0, 6 ) as $mm ) { echo '<span>' . $this->avatar( $mm['name'], $mm['photo']['url'] ?? '' ) . '<small>' . esc_html( $mm['name'] ) . '</small></span>'; } // phpcs:ignore ?></div></div>
					<div class="wk-ui-db__card"><div class="wk-ui-db__h"><small><?php echo esc_html( $s['d_label'] ); ?></small><span>→</span></div><div class="wk-ui-db__big"><?php echo esc_html( $s['d_value'] ); ?></div>
						<div class="wk-ui-db__meter"><i style="--w:62%"></i><i style="--w:24%"></i><i style="--w:14%"></i></div>
						<div class="wk-ui-db__legend"><span>+50%</span><span>+33%</span><span>+17%</span></div></div>
					<div class="wk-ui-db__card"><div class="wk-ui-db__h"><small><?php echo $this->l( 'impact' ); ?></small></div><div class="wk-ui-db__bars"><?php foreach ( $bars as $b ) { echo '<i style="--h:' . esc_attr( round( 100 * $b / $max ) ) . '%"></i>'; } ?></div></div>
				</div>
				<div class="wk-ui-db__row2">
					<div class="wk-ui-db__card"><div class="wk-ui-db__h"><?php echo $this->l( 'statistics' ); ?> <span class="wk-ui-db__seg"><b><?php echo $this->l( 'weekly' ); ?></b><span><?php echo $this->l( 'monthly' ); ?></span></span></div>
						<div class="wk-ui-db__stat"><strong><?php echo (int) $s['s_a']; ?></strong><strong class="is-soft"><?php echo (int) $s['s_b']; ?></strong><small><?php echo $this->l( 'tasks' ); ?></small></div>
						<div class="wk-ui-db__ring" style="--p:<?php echo esc_attr( round( $pct ) ); ?>"></div>
						<div class="wk-ui-db__tiles"><span><b>▣</b><?php echo (int) $s['s_a']; ?><small><?php echo $this->l( 'pcomplete' ); ?></small></span><span><b>◎</b><?php echo (int) $s['s_b'] - (int) $s['s_a']; ?><small><?php echo $this->l( 'pprogress' ); ?></small></span></div></div>
					<div class="wk-ui-db__stack">
						<div class="wk-ui-db__card wk-ui-db__meet"><span class="wk-ui-db__dot"></span><div><b><?php echo esc_html( $s['meet'] ); ?></b><small><?php echo esc_html( $s['meet_t'] ); ?></small></div><span class="wk-ui-db__spin" aria-hidden="true"></span></div>
						<div class="wk-ui-db__card wk-ui-db__promo"><span class="wk-ui-db__coil" aria-hidden="true"></span><div><h3><?php echo esc_html( $s['p_title'] ); ?></h3><p><?php echo esc_html( $s['p_text'] ); ?></p><a class="wk-ui-db__pill is-ac" href="<?php echo $this->href( $s['p_link'] ); // phpcs:ignore ?>"><?php echo esc_html( $s['p_btn'] ); ?></a></div></div>
					</div>
				</div>
			</div>
			<div class="wk-ui-db__right">
				<div class="wk-ui-db__card wk-ui-db__cal"><div class="wk-ui-db__h wk-ui-db__month"><?php echo esc_html( wp_date( 'F, Y', $ts ) ); ?><span><button type="button" data-cal="-1" aria-label="<?php esc_attr_e( 'Semana anterior', 'wakoo' ); ?>">‹</button><button type="button" data-cal="1" aria-label="<?php esc_attr_e( 'Semana siguiente', 'wakoo' ); ?>">›</button></span></div>
					<div class="wk-ui-db__week" data-today="<?php echo esc_attr( wp_date( 'Y-m-d', $ts ) ); ?>"></div></div>
				<div class="wk-ui-db__card"><div class="wk-ui-db__h"><?php echo $this->l( 'lastvideos' ); ?> <span>⚙</span></div><div class="wk-ui-db__videos">
					<?php foreach ( (array) $s['videos'] as $vv ) { echo '<a href="' . $this->href( $vv['link'] ) . '" class="wk-ui-db__video">' . $this->blob( $vv['color'], $vv['image']['url'] ?? '' ) . '<em>' . esc_html( $vv['dur'] ) . '</em><span>' . esc_html( $vv['title'] ) . '</span></a>'; } // phpcs:ignore ?>
				</div></div>
				<div class="wk-ui-db__card wk-ui-db__notes"><div class="wk-ui-db__h"><?php echo $this->l( 'notifications' ); ?> <span class="wk-ui-db__bell">●</span></div>
					<div class="wk-ui-db__tabs"><b><?php echo $this->l( 'overview' ); ?></b><span><?php echo $this->l( 'shared' ); ?></span><span><?php echo $this->l( 'comments' ); ?></span></div>
					<?php foreach ( (array) $s['notes'] as $nn ) { echo '<div class="wk-ui-db__note">' . $this->avatar( $nn['name'] ) . '<p><b>' . esc_html( $nn['name'] ) . '</b> ' . esc_html( $nn['text'] ) . '<small>' . esc_html( $nn['time'] ) . '</small></p><span class="wk-ui-db__chip">' . $this->l( 'link' ) . '</span></div>'; } // phpcs:ignore ?>
				</div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	private function view_saved( $s ) {
		$icons = [ 'doc' => '<svg viewBox="0 0 24 24"><path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5M10 13h6M10 17h6"/></svg>', 'link' => '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>' ];
		$o     = '<div class="wk-ui-db__head"><div><h3 class="wk-ui-db__title">' . esc_html( $s['sv_title'] ) . '</h3><p>' . esc_html( $s['sv_sub'] ) . '</p></div><div class="wk-ui-db__filters" role="group"><b data-f="all">' . $this->l( 'all' ) . '</b><span data-f="video">' . $this->l( 'videos' ) . '</span><span data-f="doc">' . $this->l( 'docs' ) . '</span><span data-f="link">' . $this->l( 'links' ) . '</span><a class="wk-ui-db__pill" href="#">⟲ ' . $this->l( 'restore' ) . '</a></div></div>';
		$o    .= '<div class="wk-ui-db__saved"><div class="wk-ui-db__grid">';
		foreach ( (array) $s['saved'] as $it ) {
			$type = $it['type'] ?? 'video';
			$img  = $it['image']['url'] ?? '';
			$th   = 'video' === $type ? $this->blob( $it['color'], $img ) : '<span class="wk-ui-db__thumb is-flat" style="--c:' . esc_attr( $it['color'] ) . '"><i>' . $icons[ $type ] . '</i></span>';
			$o   .= '<a class="wk-ui-db__card wk-ui-db__item" data-type="' . esc_attr( $type ) . '" href="' . $this->href( $it['link'] ) . '">' . $th . '<em>' . esc_html( ucfirst( $type ) ) . '</em><b>' . esc_html( $it['title'] ) . '</b><small>' . esc_html( $it['meta'] ) . '</small><span class="wk-ui-db__acts"><i>↗</i><i class="is-on">▮</i></span></a>';
		}
		$o .= '</div><div class="wk-ui-db__card wk-ui-db__cols"><div class="wk-ui-db__h">' . $this->l( 'collections' ) . ' <span class="wk-ui-db__plus">+</span></div>';
		foreach ( (array) $s['collections'] as $k => $c ) {
			$o .= '<div class="wk-ui-db__col' . ( 0 === $k ? ' is-on' : '' ) . '"><span class="wk-ui-db__ci">▣</span><span><b>' . esc_html( $c['name'] ) . '</b><i style="--w:' . esc_attr( (int) $c['pct'] ) . '%"></i></span><small>' . (int) $c['count'] . ' ' . $this->l( 'items' ) . '</small></div>';
		}
		$o .= '<p class="wk-ui-db__foot"><b>' . count( (array) $s['saved'] ) . '</b> ' . $this->l( 'savednow' ) . '</p></div></div>';
		return $o;
	}

	private function view_storage( $s ) {
		$tot  = max( 0.1, (float) $s['st_total'] );
		$used = (float) $s['st_used'];
		$off  = 0;
		$segs = '';
		$leg  = '';
		foreach ( (array) $s['segments'] as $g ) {
			$p     = 100 * (float) $g['value'] / $tot;
			$segs .= '<circle r="42" cx="50" cy="50" pathLength="100" stroke="' . esc_attr( $g['color'] ) . '" stroke-dasharray="' . esc_attr( max( 0, $p - 1.2 ) ) . ' 100" stroke-dashoffset="' . esc_attr( -$off ) . '"/>';
			$off  += $p;
			$leg  .= '<li><i style="background:' . esc_attr( $g['color'] ) . '"></i>' . esc_html( $g['label'] ) . '<b>' . esc_html( $g['value'] ) . ' GB</b></li>';
		}
		$o  = '<div class="wk-ui-db__head"><div><h3 class="wk-ui-db__title">' . esc_html( $s['st_title'] ) . '</h3><p>' . sprintf( $this->l( 'usedof' ), esc_html( $used ), esc_html( $tot ) ) . '</p></div><div class="wk-ui-db__filters"><a class="wk-ui-db__pill is-dark" href="#">⇪ ' . $this->l( 'upload' ) . '</a></div></div>';
		$o .= '<div class="wk-ui-db__store"><div class="wk-ui-db__card wk-ui-db__donut"><div class="wk-ui-db__h">' . $this->l( 'storage' ) . '</div><div class="wk-ui-db__dw"><svg viewBox="0 0 100 100" aria-hidden="true"><circle r="42" cx="50" cy="50" class="is-track"/>' . $segs . '</svg><span><b>' . esc_html( $used ) . '</b><small>' . $this->l( 'of' ) . ' ' . esc_html( $tot ) . ' GB</small></span></div><ul>' . $leg . '</ul></div>';
		$o .= '<div class="wk-ui-db__card"><div class="wk-ui-db__h">' . $this->l( 'folders' ) . '</div><div class="wk-ui-db__folders">';
		$files = '';
		foreach ( (array) $s['folders'] as $f ) {
			if ( 'yes' === ( $f['file'] ?? '' ) ) {
				$files .= '<a class="wk-ui-db__file" href="' . $this->href( $f['link'] ) . '"><span class="wk-ui-db__ci">▤</span><b>' . esc_html( $f['name'] ) . '</b><small>' . esc_html( $f['info'] ) . '</small><i>⋯</i></a>';
			} else {
				$o .= '<a class="wk-ui-db__folder" href="' . $this->href( $f['link'] ) . '"><span class="wk-ui-db__ci">▰</span><b>' . esc_html( $f['name'] ) . '</b><small>' . esc_html( $f['info'] ) . '</small></a>';
			}
		}
		$o .= '</div></div><div class="wk-ui-db__card wk-ui-db__files"><div class="wk-ui-db__h">' . $this->l( 'recent' ) . '</div>' . $files . '</div></div>';
		return $o;
	}

	protected function render() {
		$s       = $this->get_settings_for_display();
		$this->s = $s;
		$views = (array) $s['views'];
		$first = null;
		foreach ( $views as $i => $v ) {
			if ( 'link' !== ( $v['kind'] ?? 'link' ) ) { $first = $i; break; }
		}
		echo '<div class="wk-ui wk-ui-db" data-cfg="' . esc_attr( wp_json_encode( [ 'hash' => 'yes' === ( $s['hash'] ?? '' ) ] ) ) . '">';
		echo '<nav class="wk-ui-db__rail" aria-label="' . esc_attr__( 'Panel', 'wakoo' ) . '"><span class="wk-ui-db__logo">' . $this->icon( $s['logo'] ) . '</span><span class="wk-ui-db__railnav">'; // phpcs:ignore
		foreach ( $views as $i => $v ) {
			$kind = $v['kind'] ?? 'link';
			$slug = sanitize_title( $v['label'] );
			$attr = 'link' === $kind ? ' href="' . $this->href( $v['link'] ?? [] ) . '"' : ' href="#' . esc_attr( $slug ) . '" data-view="' . esc_attr( $slug ) . '"';
			echo '<a class="wk-ui-db__nav' . ( $i === $first ? ' is-active' : '' ) . '"' . $attr . ' data-tip="' . esc_attr( $v['label'] ) . '" aria-label="' . esc_attr( $v['label'] ) . '">' . $this->icon( $v['icon'] ) . '</a>'; // phpcs:ignore
		}
		echo '</span>';
		if ( 'yes' === ( $s['logout'] ?? '' ) ) {
			echo '<a class="wk-ui-db__nav wk-ui-db__out" href="' . esc_url( wp_logout_url( home_url( '/' ) ) ) . '" data-tip="' . esc_attr__( 'Salir', 'wakoo' ) . '" aria-label="' . esc_attr__( 'Salir', 'wakoo' ) . '"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10"/></svg></a>';
		}
		echo '<span class="wk-ui-db__tip" aria-hidden="true"></span></nav>';
		echo '<div class="wk-ui-db__main"><div class="wk-ui-db__skel" aria-hidden="true"><i></i><i></i><i></i><i></i></div>';
		foreach ( $views as $i => $v ) {
			$kind = $v['kind'] ?? 'link';
			if ( 'link' === $kind ) { continue; }
			echo '<section class="wk-ui-db__view wk-ui-db__view--' . esc_attr( $kind ) . ( $i === $first ? ' is-current' : '' ) . '" data-view="' . esc_attr( sanitize_title( $v['label'] ) ) . '"' . ( $i === $first ? '' : ' hidden' ) . '>';
			if ( 'overview' === $kind ) {
				echo $this->view_overview( $s ); // phpcs:ignore
			} elseif ( 'saved' === $kind ) {
				echo $this->view_saved( $s ); // phpcs:ignore
			} elseif ( 'storage' === $kind ) {
				echo $this->view_storage( $s ); // phpcs:ignore
			} elseif ( ! empty( $v['template'] ) && class_exists( '\Elementor\Plugin' ) ) {
				echo '<div class="wk-ui-db__card wk-ui-db__tpl">' . \Elementor\Plugin::$instance->frontend->get_builder_content_for_display( (int) $v['template'], true ) . '</div>'; // phpcs:ignore
			} else {
				echo '<div class="wk-ui-db__card wk-ui-db__tpl"><p>' . esc_html__( 'Elige una plantilla para esta vista.', 'wakoo' ) . '</p></div>';
			}
			echo '</section>';
		}
		echo '</div></div>';
	}
}
