<?php
/**
 * Verificación OTP «baraja»: code boxes with a light sweep on every digit; when complete they fan out
 * like a hand of cards, stack into one card, trace a border while checking and turn green when verified.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Interfaz\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Otp extends Base {

	protected function asset() { return 'otp'; }
	public function get_name() { return 'wakoo-ui-otp'; }
	public function get_title() { return __( 'Verificación OTP (baraja)', 'wakoo' ); }
	public function get_icon() { return 'eicon-lock'; }
	public function get_keywords() { return [ 'otp', 'codigo', 'verificacion', '2fa', 'pin', 'login', 'acceso', 'wakoo' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_text', [ 'label' => __( 'Textos', 'wakoo' ) ] );
		$t = function ( $id, $label, $default, $type = Controls_Manager::TEXT ) {
			$this->add_control( $id, [ 'label' => $label, 'type' => $type, 'default' => $default, 'label_block' => true ] );
		};
		$t( 'title', __( 'Título', 'wakoo' ), 'Enter your code' );
		$t( 'sub', __( 'Subtítulo', 'wakoo' ), 'We texted a {n}-digit code to *+1 415 ••• 0142*.' );
		$this->add_control( 'sub_note', [ 'type' => Controls_Manager::RAW_HTML, 'raw' => __( '{n} = número de cifras · {email} = email escrito · *texto* = en negrita.', 'wakoo' ), 'content_classes' => 'elementor-descriptor' ] );
		$t( 'title_check', __( 'Título al comprobar', 'wakoo' ), 'Checking your code' );
		$t( 'sub_check', __( 'Subtítulo al comprobar', 'wakoo' ), 'One moment — we’re confirming it.' );
		$t( 'title_ok', __( 'Título al verificar', 'wakoo' ), 'Verified' );
		$t( 'sub_ok', __( 'Subtítulo al verificar', 'wakoo' ), 'Setting up your session...' );
		$t( 'badge', __( 'Insignia', 'wakoo' ), 'Verified' );
		$t( 'cta', __( 'Botón final', 'wakoo' ), 'Continue' );
		$t( 'bad', __( 'Si el código no coincide', 'wakoo' ), 'That code didn’t match. Try again.' );
		$t( 'resend_q', __( 'Pregunta de reenvío', 'wakoo' ), 'Didn’t get a code?' );
		$t( 'resend', __( 'Enlace de reenvío', 'wakoo' ), 'Resend' );
		$t( 'resent', __( 'Tras reenviar', 'wakoo' ), 'Sent ✓' );
		$t( 'hint', __( 'Ayuda bajo la tarjeta', 'wakoo' ), 'Type it, paste it, or hit *Enter* — *1234* is the good one.' );
		$this->add_control( 'grab', [ 'label' => __( 'Asa superior (estilo hoja)', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'head', [ 'label' => __( 'Encabezado sobre la tarjeta', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => '', 'separator' => 'before' ] );
		$this->add_control( 'head_eyebrow', [ 'label' => __( 'Antetítulo', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'COMPONENT · 100', 'condition' => [ 'head' => 'yes' ] ] );
		$this->add_control( 'head_title', [ 'label' => __( 'Encabezado', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'OTP Verification', 'condition' => [ 'head' => 'yes' ] ] );
		$this->add_control( 'head_tag', [ 'label' => __( 'Etiqueta', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'DECK', 'condition' => [ 'head' => 'yes' ] ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_code', [ 'label' => __( 'Código', 'wakoo' ) ] );
		$this->add_control( 'digits', [ 'label' => __( 'Cifras', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 4, 'max' => 8, 'default' => 4 ] );
		$this->add_control( 'otp_mode', [
			'label'   => __( 'Modo', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'demo',
			'options' => [
				'demo'  => __( 'Demostración (código fijo)', 'wakoo' ),
				'email' => __( 'Código real por email', 'wakoo' ),
			],
		] );
		$this->add_control( 'demo_code', [ 'label' => __( 'Código correcto', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '1234', 'description' => __( 'Vacío: acepta cualquier código.', 'wakoo' ), 'condition' => [ 'otp_mode' => 'demo' ] ] );
		$this->add_control( 'email_label', [ 'label' => __( 'Texto del campo email', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Email', 'condition' => [ 'otp_mode' => 'email' ] ] );
		$this->add_control( 'email_btn', [ 'label' => __( 'Botón «enviar código»', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Send code', 'condition' => [ 'otp_mode' => 'email' ] ] );
		$this->add_control( 'mail_subject', [ 'label' => __( 'Asunto del email', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Tu código de verificación', 'wakoo' ), 'condition' => [ 'otp_mode' => 'email' ] ] );
		$this->add_control( 'otp_login', [
			'label'        => __( 'Iniciar sesión al verificar', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => '',
			'description'  => __( 'Entra sin contraseña con la cuenta de ese email (nunca con cuentas de administrador).', 'wakoo' ),
			'condition'    => [ 'otp_mode' => 'email' ],
		] );
		$this->add_control( 'auto_submit', [ 'label' => __( 'Comprobar al escribir la última cifra', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'description' => __( 'Si lo apagas, se comprueba con Enter.', 'wakoo' ) ] );
		$this->add_control( 'redirect', [ 'label' => __( 'Ir a esta página con «Continue»', 'wakoo' ), 'type' => Controls_Manager::URL, 'placeholder' => home_url( '/mi-cuenta/' ), 'description' => __( 'Vacío: vuelve a empezar (en demostración) o recarga la página.', 'wakoo' ) ] );
		$this->add_control( 'auto_go', [ 'label' => __( 'Seguir solo tras (segundos, 0 = esperar el botón)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 30, 'default' => 0 ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_fx', [ 'label' => __( 'Animación', 'wakoo' ) ] );
		$this->add_control( 'fan', [ 'label' => __( 'Abanico de cartas al completar', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'fan_deg', [ 'label' => __( 'Giro de las cartas (grados)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 30, 'default' => 9, 'condition' => [ 'fan' => 'yes' ] ] );
		$this->add_control( 'speed', [ 'label' => __( 'Velocidad (1 = como el vídeo)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0.3, 'max' => 3, 'step' => 0.1, 'default' => 1 ] );
		$this->add_control( 'sparks', [ 'label' => __( 'Chispas al verificar', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'vibrate', [ 'label' => __( 'Vibrar en el móvil si el código falla', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();

		$this->start_controls_section( 'st_card', [ 'label' => __( 'Tarjeta', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->var_slider( 'card_w', __( 'Ancho máximo', 'wakoo' ), '--otp-cw', 360, 240, 700, 'px', '.wk-ui', true );
		$this->var_slider( 'card_r', __( 'Redondez', 'wakoo' ), '--otp-cr', 26, 0, 60 );
		$this->var_color( 'card_bg', __( 'Fondo', 'wakoo' ), '--otp-card', '#17191E' );
		$this->var_color( 'card_b', __( 'Borde', 'wakoo' ), '--otp-cb', '#262A31' );
		$this->var_color( 'title_c', __( 'Título', 'wakoo' ), '--otp-title', '#F4F6FA' );
		$this->var_color( 'text_c', __( 'Texto', 'wakoo' ), '--otp-text', '#9AA1AD' );
		$this->var_color( 'head_c', __( 'Encabezado', 'wakoo' ), '--otp-head', '#C9D1DE' );
		$this->typo( 't_title', __( 'Título', 'wakoo' ), '.wk-ui-otp__title' );
		$this->typo( 't_sub', __( 'Subtítulo', 'wakoo' ), '.wk-ui-otp__sub' );
		$this->end_controls_section();

		$this->start_controls_section( 'st_box', [ 'label' => __( 'Cajas', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'bw', [ 'label' => __( 'Ancho de caja', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 32, 'max' => 120, 'default' => 52 ] );
		$this->add_control( 'bh', [ 'label' => __( 'Alto de caja', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 36, 'max' => 160, 'default' => 62 ] );
		$this->add_control( 'br', [ 'label' => __( 'Redondez de caja', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 40, 'default' => 13 ] );
		$this->var_slider( 'bgap', __( 'Separación', 'wakoo' ), '--otp-gap', 10, 0, 40 );
		$this->var_color( 'box1', __( 'Caja: arriba', 'wakoo' ), '--otp-b1', '#222B3D' );
		$this->var_color( 'box2', __( 'Caja: abajo', 'wakoo' ), '--otp-b2', '#141925' );
		$this->var_color( 'box_b', __( 'Caja: borde', 'wakoo' ), '--otp-bb', '#2D3546' );
		$this->var_color( 'digit_c', __( 'Cifras', 'wakoo' ), '--otp-digit', '#F4F6FA' );
		$this->var_color( 'accent', __( 'Luz azul (foco y barrido)', 'wakoo' ), '--otp-ac', '#5B8CFF' );
		$this->var_color( 'ok_c', __( 'Verde «Verified»', 'wakoo' ), '--otp-ok', '#2EE6A6' );
		$this->var_color( 'err_c', __( 'Error', 'wakoo' ), '--otp-err', '#FF6B7A' );
		$this->typo( 't_digit', __( 'Cifras', 'wakoo' ), '.wk-ui-otp__d' );
		$this->end_controls_section();
	}

	/** Escapes text and turns *word* into <b>word</b>. */
	protected function rich( $text, $rep = [] ) {
		$text = esc_html( strtr( (string) $text, $rep ) );
		return preg_replace( '/\*([^*]+)\*/', '<b>$1</b>', $text );
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$n    = max( 4, min( 8, (int) ( $s['digits'] ?: 4 ) ) );
		$bw   = max( 32, (int) ( $s['bw'] ?: 52 ) );
		$bh   = max( 36, (int) ( $s['bh'] ?: 62 ) );
		$br   = max( 0, (int) ( '' === $s['br'] ? 13 : $s['br'] ) );
		$mail = 'email' === ( $s['otp_mode'] ?? 'demo' );
		$rep  = [ '{n}' => $n ];
		$cfg  = [
			'n'      => $n,
			'mail'   => $mail,
			'auto'   => 'yes' === ( $s['auto_submit'] ?? 'yes' ),
			'fan'    => 'yes' === ( $s['fan'] ?? 'yes' ),
			'deg'    => (float) ( '' === ( $s['fan_deg'] ?? '' ) ? 9 : $s['fan_deg'] ),
			'speed'  => max( 0.3, (float) ( $s['speed'] ?: 1 ) ),
			'sparks' => 'yes' === ( $s['sparks'] ?? 'yes' ),
			'vib'    => 'yes' === ( $s['vibrate'] ?? 'yes' ),
			'go'     => (float) ( $s['auto_go'] ?: 0 ),
			'url'    => ! empty( $s['redirect']['url'] ) ? esc_url( $s['redirect']['url'] ) : '',
			'demo'   => $this->is_editor() && ! $mail ? preg_replace( '/\D/', '', (string) $s['demo_code'] ) : null,
			't'      => [
				'title' => (string) $s['title'], 'sub' => $this->rich( $s['sub'], $rep ),
				'check' => (string) $s['title_check'], 'subCheck' => (string) $s['sub_check'],
				'ok'    => (string) $s['title_ok'], 'subOk' => (string) $s['sub_ok'],
				'resend' => (string) $s['resend'], 'resent' => (string) $s['resent'], 'bad' => (string) $s['bad'],
			],
		];
		$rect = sprintf( '<svg class="wk-ui-otp__trace" viewBox="0 0 %1$d %2$d" aria-hidden="true"><rect x="1" y="1" width="%3$d" height="%4$d" rx="%5$d" pathLength="100"/></svg>', $bw, $bh, $bw - 2, $bh - 2, max( 0, $br - 1 ) );

		echo '<div class="wk-ui wk-ui-otp' . ( $mail ? ' is-ask' : '' ) . '" style="--otp-bw:' . esc_attr( $bw ) . 'px;--otp-bh:' . esc_attr( $bh ) . 'px;--otp-br:' . esc_attr( $br ) . 'px;--n:' . esc_attr( $n ) . '" data-cfg="' . esc_attr( wp_json_encode( $cfg ) ) . '"' . $this->auth_attrs() . '>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( 'yes' === ( $s['head'] ?? '' ) ) {
			echo '<div class="wk-ui-otp__headline"><small>' . esc_html( $s['head_eyebrow'] ) . '</small><h2>' . esc_html( $s['head_title'] ) . ( '' !== $s['head_tag'] ? ' <em>' . esc_html( $s['head_tag'] ) . '</em>' : '' ) . '</h2></div>';
		}
		echo '<div class="wk-ui-otp__card">';
		if ( 'yes' === ( $s['grab'] ?? 'yes' ) ) {
			echo '<span class="wk-ui-otp__grab" aria-hidden="true"></span>';
		}
		echo '<div class="wk-ui-otp__text" aria-live="polite"><h3 class="wk-ui-otp__title">' . esc_html( $s['title'] ) . '</h3><p class="wk-ui-otp__sub">' . $this->rich( $s['sub'], $rep ) . '</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $mail ) {
			echo '<form class="wk-ui-otp__ask" novalidate><input type="email" name="email" autocomplete="email" required placeholder="' . esc_attr( $s['email_label'] ) . '" aria-label="' . esc_attr( $s['email_label'] ) . '"><button type="submit">' . esc_html( $s['email_btn'] ) . '</button></form>';
		}
		echo '<div class="wk-ui-otp__deck">';
		echo '<input class="wk-ui-otp__input" type="text" inputmode="numeric" pattern="[0-9]*" autocomplete="one-time-code" maxlength="' . esc_attr( $n ) . '" aria-label="' . esc_attr( sprintf( /* translators: %d digits */ __( 'Código de %d cifras', 'wakoo' ), $n ) ) . '">';
		for ( $i = 0; $i < $n; $i++ ) {
			echo '<span class="wk-ui-otp__box" style="--i:' . (int) $i . ';--k:' . esc_attr( $i - ( $n - 1 ) / 2 ) . ';--k2:' . esc_attr( pow( $i - ( $n - 1 ) / 2, 2 ) ) . '" aria-hidden="true"><span class="wk-ui-otp__d"></span><i class="wk-ui-otp__caret"></i>' . $rect . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '<span class="wk-ui-otp__final" aria-hidden="true">' . $rect . '<svg class="wk-ui-otp__check" viewBox="0 0 24 24"><path d="M7 12.5l3.2 3.2L17 9" pathLength="1"/></svg>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $cfg['sparks'] ) {
			echo '<span class="wk-ui-otp__sparks">';
			for ( $i = 0; $i < 12; $i++ ) {
				echo '<i style="--a:' . (int) ( $i * 30 ) . 'deg"></i>';
			}
			echo '</span>';
		}
		echo '</span></div>';
		echo '<p class="wk-ui-otp__err" role="alert"></p>';
		echo '<div class="wk-ui-otp__done"><span class="wk-ui-otp__badge"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>' . esc_html( $s['badge'] ) . '</span><button type="button" class="wk-ui-otp__cta">' . esc_html( $s['cta'] ) . '</button></div>';
		if ( '' !== (string) $s['resend'] ) {
			echo '<p class="wk-ui-otp__foot">' . esc_html( $s['resend_q'] ) . ' <button type="button" class="wk-ui-otp__resend">' . esc_html( $s['resend'] ) . '</button></p>';
		}
		echo '</div>';
		if ( '' !== (string) $s['hint'] ) {
			echo '<p class="wk-ui-otp__hint">' . $this->rich( $s['hint'], $rep ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div>';
	}
}
