<?php
/**
 * Barra lateral: collapsible icon sidebar that opens on hover (or click), with profile, search,
 * badges, groups and a light / dark switch.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Interfaz\Widgets;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Box_Shadow;

defined( 'ABSPATH' ) || die();

class Sidebar extends Base {

	protected function asset() { return 'sidebar'; }
	public function get_name() { return 'wakoo-ui-sidebar'; }
	public function get_title() { return __( 'Barra lateral animada', 'wakoo' ); }
	public function get_icon() { return 'eicon-sidebar'; }
	public function get_keywords() { return [ 'sidebar', 'barra lateral', 'menu', 'navegacion', 'panel', 'dashboard', 'wakoo' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_profile', [ 'label' => __( 'Perfil', 'wakoo' ) ] );
		$this->add_control( 'show_profile', [ 'label' => __( 'Mostrar perfil', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'use_user', [
			'label'        => __( 'Usar el usuario conectado', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'description'  => __( 'Si hay sesión iniciada, muestra su nombre, rol y avatar en lugar de los de abajo.', 'wakoo' ),
			'condition'    => [ 'show_profile' => 'yes' ],
		] );
		$this->add_control( 'avatar', [ 'label' => __( 'Foto', 'wakoo' ), 'type' => Controls_Manager::MEDIA, 'default' => [ 'url' => \Wakoo\Modules\Interfaz\Module::url( 'assets/img/avatar.svg' ) ], 'condition' => [ 'show_profile' => 'yes' ] ] );
		$this->add_control( 'name', [ 'label' => __( 'Nombre', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Ananya Sharma', 'condition' => [ 'show_profile' => 'yes' ] ] );
		$this->add_control( 'role', [ 'label' => __( 'Cargo', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Admin', 'condition' => [ 'show_profile' => 'yes' ] ] );
		$this->add_control( 'profile_link', [ 'label' => __( 'Enlace del perfil', 'wakoo' ), 'type' => Controls_Manager::URL, 'condition' => [ 'show_profile' => 'yes' ] ] );
		$this->add_control( 'show_search', [ 'label' => __( 'Buscador', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'separator' => 'before' ] );
		$this->add_control( 'search_ph', [ 'label' => __( 'Texto del buscador', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Buscar en el panel', 'wakoo' ), 'condition' => [ 'show_search' => 'yes' ] ] );
		$this->add_control( 'search_action', [
			'label'     => __( 'Al buscar', 'wakoo' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'filter',
			'options'   => [ 'filter' => __( 'Filtrar los elementos del menú', 'wakoo' ), 'site' => __( 'Buscar en el sitio', 'wakoo' ) ],
			'condition' => [ 'show_search' => 'yes' ],
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_items', [ 'label' => __( 'Elementos del menú', 'wakoo' ) ] );
		$r = new Repeater();
		$r->add_control( 'kind', [ 'label' => __( 'Tipo', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'item', 'options' => [ 'item' => __( 'Enlace', 'wakoo' ), 'sep' => __( 'Separador', 'wakoo' ), 'title' => __( 'Título de grupo', 'wakoo' ) ] ] );
		$r->add_control( 'label', [ 'label' => __( 'Texto', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Elemento', 'wakoo' ), 'condition' => [ 'kind!' => 'sep' ] ] );
		$r->add_control( 'icon', [ 'label' => __( 'Icono', 'wakoo' ), 'type' => Controls_Manager::ICONS, 'default' => [ 'value' => 'far fa-circle', 'library' => 'fa-regular' ], 'condition' => [ 'kind' => 'item' ] ] );
		$r->add_control( 'link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL, 'condition' => [ 'kind' => 'item' ] ] );
		$r->add_control( 'badge', [ 'label' => __( 'Insignia', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'condition' => [ 'kind' => 'item' ] ] );
		$r->add_control( 'active', [ 'label' => __( 'Activo al cargar', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'condition' => [ 'kind' => 'item' ] ] );
		$items = [
			[ 'Dashboard', 'fas fa-th-large', 'fa-solid', '', 'yes' ],
			[ 'Support', 'far fa-user', 'fa-regular', '', '' ],
			[ 'Customers', 'fas fa-user-friends', 'fa-solid', '', '' ],
			[ 'Tickets', 'fas fa-ticket-alt', 'fa-solid', '', '' ],
			[ 'sep' ],
			[ 'Tasks', 'fas fa-thumbtack', 'fa-solid', '2', '' ],
			[ 'Projects', 'fas fa-sitemap', 'fa-solid', '', '' ],
			[ 'Application', 'far fa-envelope', 'fa-regular', '', '' ],
			[ 'User Management', 'fas fa-user-cog', 'fa-solid', '', '' ],
		];
		$def = [];
		foreach ( $items as $it ) {
			$def[] = 1 === count( $it ) ? [ 'kind' => 'sep' ] : [ 'kind' => 'item', 'label' => $it[0], 'icon' => [ 'value' => $it[1], 'library' => $it[2] ], 'badge' => $it[3], 'active' => $it[4] ];
		}
		$this->add_control( 'items', [ 'type' => Controls_Manager::REPEATER, 'fields' => $r->get_controls(), 'default' => $def, 'title_field' => '{{{ "sep" === kind ? "———" : label }}}' ] );
		$this->add_control( 'auto_active', [ 'label' => __( 'Marcar la página actual', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'description' => __( 'Activa el elemento cuyo enlace es la página abierta.', 'wakoo' ) ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_actions', [ 'label' => __( 'Botones de abajo', 'wakoo' ) ] );
		$this->add_control( 'show_theme', [ 'label' => __( 'Botón claro / oscuro', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'theme_scope', [
			'label'     => __( 'El modo oscuro afecta a', 'wakoo' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'widget',
			'options'   => [ 'widget' => __( 'Solo la barra', 'wakoo' ), 'page' => __( 'Toda la página (clase wakoo-dark en body)', 'wakoo' ) ],
			'condition' => [ 'show_theme' => 'yes' ],
		] );
		$this->add_control( 'start_dark', [ 'label' => __( 'Empezar en oscuro', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ] );
		$a = new Repeater();
		$a->add_control( 'label', [ 'label' => __( 'Nombre (tooltip)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Acción', 'wakoo' ) ] );
		$a->add_control( 'icon', [ 'label' => __( 'Icono', 'wakoo' ), 'type' => Controls_Manager::ICONS, 'default' => [ 'value' => 'fas fa-cog', 'library' => 'fa-solid' ] ] );
		$a->add_control( 'link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$a->add_control( 'logout', [ 'label' => __( 'Cerrar sesión', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'description' => __( 'Usa el enlace de salida de WordPress.', 'wakoo' ) ] );
		$this->add_control( 'actions', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $a->get_controls(),
			'title_field' => '{{{ label }}}',
			'default'     => [
				[ 'label' => __( 'Ajustes', 'wakoo' ), 'icon' => [ 'value' => 'fas fa-cog', 'library' => 'fa-solid' ] ],
				[ 'label' => __( 'Nuevo', 'wakoo' ), 'icon' => [ 'value' => 'fas fa-plus', 'library' => 'fa-solid' ] ],
				[ 'label' => __( 'Salir', 'wakoo' ), 'icon' => [ 'value' => 'fas fa-sign-out-alt', 'library' => 'fa-solid' ], 'logout' => 'yes' ],
			],
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_behaviour', [ 'label' => __( 'Comportamiento', 'wakoo' ) ] );
		$this->add_control( 'mode', [
			'label'   => __( 'Abrir', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'hover',
			'options' => [
				'hover'  => __( 'Al pasar el ratón (como el vídeo)', 'wakoo' ),
				'click'  => __( 'Con un botón', 'wakoo' ),
				'open'   => __( 'Siempre abierta', 'wakoo' ),
				'closed' => __( 'Siempre cerrada (solo iconos)', 'wakoo' ),
			],
		] );
		$this->add_control( 'remember', [ 'label' => __( 'Recordar abierta/cerrada', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'condition' => [ 'mode' => 'click' ] ] );
		$this->add_control( 'position', [
			'label'   => __( 'Posición', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'inline',
			'options' => [ 'inline' => __( 'En su sitio (dentro del contenedor)', 'wakoo' ), 'fixed' => __( 'Fija a la izquierda de la pantalla', 'wakoo' ), 'fixed-right' => __( 'Fija a la derecha de la pantalla', 'wakoo' ) ],
		] );
		$this->add_control( 'overlay', [ 'label' => __( 'Al abrirse, flota sobre el contenido', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'description' => __( 'Si no, empuja el contenido de al lado.', 'wakoo' ) ] );
		$this->add_control( 'tooltips', [ 'label' => __( 'Tooltips cuando está cerrada', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => '' ] );
		$this->var_slider( 'dur', __( 'Duración de la animación (s)', 'wakoo' ), '--sb-dur', 0.35, 0.1, 2, 's' );
		$this->end_controls_section();

		/* ---- style */
		$this->start_controls_section( 'st_size', [ 'label' => __( 'Tamaño', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->var_slider( 'w_closed', __( 'Ancho cerrada', 'wakoo' ), '--sb-w0', 72, 48, 140 );
		$this->var_slider( 'w_open', __( 'Ancho abierta', 'wakoo' ), '--sb-w1', 264, 160, 420 );
		$this->add_responsive_control( 'height', [
			'label'      => __( 'Alto', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px', 'vh' ],
			'range'      => [ 'px' => [ 'min' => 300, 'max' => 1400 ], 'vh' => [ 'min' => 30, 'max' => 100 ] ],
			'default'    => [ 'unit' => 'px', 'size' => 700 ],
			'selectors'  => [ '{{WRAPPER}} .wk-ui-sb' => '--sb-h: {{SIZE}}{{UNIT}};' ],
		] );
		$this->var_slider( 'item_h', __( 'Alto de cada elemento', 'wakoo' ), '--sb-item', 44, 32, 64 );
		$this->var_slider( 'radius', __( 'Redondez', 'wakoo' ), '--sb-radius', 16, 0, 40 );
		$this->var_slider( 'item_radius', __( 'Redondez del resaltado', 'wakoo' ), '--sb-iradius', 12, 0, 30 );
		$this->var_slider( 'icon_size', __( 'Tamaño de iconos', 'wakoo' ), '--sb-icon', 18, 12, 30 );
		$this->add_group_control( Group_Control_Box_Shadow::get_type(), [ 'name' => 'shadow', 'selector' => '{{WRAPPER}} .wk-ui-sb__panel' ] );
		$this->end_controls_section();

		$this->start_controls_section( 'st_light', [ 'label' => __( 'Colores (modo claro)', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->var_color( 'c_bg', __( 'Fondo', 'wakoo' ), '--sb-bg', '#FFFFFF' );
		$this->var_color( 'c_text', __( 'Texto', 'wakoo' ), '--sb-text', '#1F2430' );
		$this->var_color( 'c_muted', __( 'Texto suave', 'wakoo' ), '--sb-muted', '#8A93A6' );
		$this->var_color( 'c_hover', __( 'Fondo al pasar', 'wakoo' ), '--sb-hover', '#F2F5FA' );
		$this->var_color( 'c_active', __( 'Fondo activo', 'wakoo' ), '--sb-active-bg', '#E8F1FF' );
		$this->var_color( 'c_active_t', __( 'Texto activo', 'wakoo' ), '--sb-active', '#1A73E8' );
		$this->var_color( 'c_accent', __( 'Acento (insignias)', 'wakoo' ), '--sb-accent', '#1A73E8' );
		$this->var_color( 'c_border', __( 'Bordes', 'wakoo' ), '--sb-border', '#EDF0F5' );
		$this->var_color( 'c_chip', __( 'Fondo de los botones', 'wakoo' ), '--sb-chip', '#F3F5F9' );
		$this->end_controls_section();

		$this->start_controls_section( 'st_dark', [ 'label' => __( 'Colores (modo oscuro)', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->var_color( 'd_bg', __( 'Fondo', 'wakoo' ), '--sbd-bg', '#1B1F27' );
		$this->var_color( 'd_text', __( 'Texto', 'wakoo' ), '--sbd-text', '#E7EAF0' );
		$this->var_color( 'd_muted', __( 'Texto suave', 'wakoo' ), '--sbd-muted', '#7D8698' );
		$this->var_color( 'd_hover', __( 'Fondo al pasar', 'wakoo' ), '--sbd-hover', '#242a35' );
		$this->var_color( 'd_active', __( 'Fondo activo', 'wakoo' ), '--sbd-active-bg', '#1D3157' );
		$this->var_color( 'd_active_t', __( 'Texto activo', 'wakoo' ), '--sbd-active', '#5B9BFF' );
		$this->var_color( 'd_border', __( 'Bordes', 'wakoo' ), '--sbd-border', '#2A303B' );
		$this->var_color( 'd_chip', __( 'Fondo de los botones', 'wakoo' ), '--sbd-chip', '#242a35' );
		$this->end_controls_section();

		$this->start_controls_section( 'st_type', [ 'label' => __( 'Tipografía', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->typo( 't_name', __( 'Nombre', 'wakoo' ), '.wk-ui-sb__name' );
		$this->typo( 't_role', __( 'Cargo', 'wakoo' ), '.wk-ui-sb__role' );
		$this->typo( 't_item', __( 'Elementos', 'wakoo' ), '.wk-ui-sb__label' );
		$this->end_controls_section();
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$mode  = $s['mode'] ?? 'hover';
		$name  = $s['name'];
		$role  = $s['role'];
		$photo = $s['avatar']['url'] ?? '';
		if ( 'yes' === ( $s['use_user'] ?? '' ) && is_user_logged_in() && ! $this->is_editor() ) {
			$u     = wp_get_current_user();
			$name  = $u->display_name;
			$roles = wp_roles()->roles;
			$role  = $u->roles ? translate_user_role( $roles[ $u->roles[0] ]['name'] ?? $u->roles[0] ) : '';
			$photo = get_avatar_url( $u->ID, [ 'size' => 96 ] );
		}
		$cfg = [
			'mode'     => $mode,
			'remember' => 'yes' === ( $s['remember'] ?? '' ),
			'scope'    => $s['theme_scope'] ?? 'widget',
			'auto'     => 'yes' === ( $s['auto_active'] ?? '' ),
			'search'   => $s['search_action'] ?? 'filter',
			'key'      => 'wk_sb_' . $this->get_id(),
		];
		$cls = [ 'wk-ui', 'wk-ui-sb', 'wk-ui-sb--' . $mode, 'wk-ui-sb--' . ( $s['position'] ?? 'inline' ) ];
		if ( 'open' === $mode ) { $cls[] = 'is-open'; }
		if ( 'yes' === ( $s['start_dark'] ?? '' ) ) { $cls[] = 'is-dark'; }
		if ( 'yes' === ( $s['overlay'] ?? '' ) ) { $cls[] = 'wk-ui-sb--overlay'; }
		if ( 'yes' === ( $s['tooltips'] ?? '' ) ) { $cls[] = 'wk-ui-sb--tips'; }

		echo '<div class="' . esc_attr( implode( ' ', $cls ) ) . '" data-cfg="' . esc_attr( wp_json_encode( $cfg ) ) . '">';
		echo '<aside class="wk-ui-sb__panel" aria-label="' . esc_attr__( 'Menú lateral', 'wakoo' ) . '">';

		if ( 'yes' === ( $s['show_profile'] ?? '' ) ) {
			$tag  = ! empty( $s['profile_link']['url'] ) ? 'a' : 'div';
			$href = 'a' === $tag ? ' href="' . esc_url( $s['profile_link']['url'] ) . '"' : '';
			echo '<' . $tag . $href . ' class="wk-ui-sb__profile">'; // phpcs:ignore WordPress.Security.EscapeOutput
			if ( $photo ) {
				echo '<img class="wk-ui-sb__avatar" src="' . esc_url( $photo ) . '" alt="" loading="lazy">';
			}
			echo '<span class="wk-ui-sb__details"><span class="wk-ui-sb__name">' . esc_html( $name ) . '</span><span class="wk-ui-sb__role">' . esc_html( $role ) . '</span></span>';
			echo '<svg class="wk-ui-sb__chevron" viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';
			echo '</' . $tag . '>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		if ( 'click' === $mode ) {
			echo '<button type="button" class="wk-ui-sb__toggle" aria-expanded="false" aria-label="' . esc_attr__( 'Abrir o cerrar el menú', 'wakoo' ) . '"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg></button>';
		}
		if ( 'yes' === ( $s['show_search'] ?? '' ) ) {
			echo '<form class="wk-ui-sb__search" role="search" action="' . esc_url( home_url( '/' ) ) . '">';
			echo '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>';
			echo '<input type="search" name="s" placeholder="' . esc_attr( $s['search_ph'] ) . '" aria-label="' . esc_attr( $s['search_ph'] ) . '">';
			echo '</form>';
		}

		echo '<nav class="wk-ui-sb__nav">';
		foreach ( (array) $s['items'] as $i => $it ) {
			$kind = $it['kind'] ?? 'item';
			if ( 'sep' === $kind ) {
				echo '<hr class="wk-ui-sb__sep">';
				continue;
			}
			if ( 'title' === $kind ) {
				echo '<div class="wk-ui-sb__group"><span class="wk-ui-sb__label">' . esc_html( $it['label'] ) . '</span></div>';
				continue;
			}
			$url  = $it['link']['url'] ?? '';
			$attr = $url ? ' href="' . esc_url( $url ) . '"' . ( ! empty( $it['link']['is_external'] ) ? ' target="_blank" rel="noopener"' : '' ) : ' href="#" role="button"';
			echo '<a class="wk-ui-sb__item' . ( 'yes' === ( $it['active'] ?? '' ) ? ' is-active' : '' ) . '"' . $attr . ' data-tip="' . esc_attr( $it['label'] ) . '">'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<span class="wk-ui-sb__icon">' . $this->icon( $it['icon'] ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<span class="wk-ui-sb__label">' . esc_html( $it['label'] ) . '</span>';
			if ( '' !== (string) ( $it['badge'] ?? '' ) ) {
				echo '<span class="wk-ui-sb__badge">' . esc_html( $it['badge'] ) . '</span>';
			}
			echo '</a>';
		}
		echo '</nav>';

		echo '<div class="wk-ui-sb__actions">';
		if ( 'yes' === ( $s['show_theme'] ?? '' ) ) {
			echo '<button type="button" class="wk-ui-sb__action wk-ui-sb__theme" data-tip="' . esc_attr__( 'Claro / oscuro', 'wakoo' ) . '" aria-label="' . esc_attr__( 'Cambiar a modo oscuro o claro', 'wakoo' ) . '">'
				. '<svg class="wk-ui-sb__moon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>'
				. '<svg class="wk-ui-sb__sun" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2m-7.07-17.07 1.41 1.41m11.32 11.32 1.41 1.41M2 12h2m16 0h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></svg>'
				. '</button>';
		}
		foreach ( (array) $s['actions'] as $a ) {
			$url = 'yes' === ( $a['logout'] ?? '' ) ? wp_logout_url( home_url( '/' ) ) : ( $a['link']['url'] ?? '' );
			echo '<a class="wk-ui-sb__action" href="' . esc_url( $url ? $url : '#' ) . '" data-tip="' . esc_attr( $a['label'] ) . '" aria-label="' . esc_attr( $a['label'] ) . '">' . $this->icon( $a['icon'] ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div>';

		echo '</aside></div>';
	}
}
