<?php
/**
 * Acceso de metal líquido: a silver "Sign in" capsule that tears into the email and password fields,
 * with a mercury neck that stretches, snaps and drips back (one SVG path redrawn every frame).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Interfaz\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Liquid_Login extends Base {

	protected function asset() { return 'liquid-login'; }
	public function get_name() { return 'wakoo-ui-liquid-login'; }
	public function get_title() { return __( 'Acceso de metal líquido', 'wakoo' ); }
	public function get_icon() { return 'eicon-lock-user'; }
	public function get_keywords() { return [ 'login', 'acceso', 'iniciar sesion', 'liquid', 'metal', 'mercurio', 'boton', 'wakoo' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_text', [ 'label' => __( 'Textos', 'wakoo' ) ] );
		$this->add_control( 'btn', [ 'label' => __( 'Botón', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Sign in' ] );
		$this->add_control( 'l_user', [ 'label' => __( 'Campo 1', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Email' ] );
		$this->add_control( 'ph_user', [ 'label' => __( 'Ejemplo del campo 1', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '' ] );
		$this->add_control( 'l_pass', [ 'label' => __( 'Campo 2', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Password' ] );
		$this->add_control( 'busy', [ 'label' => __( 'Mientras entra', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Signing in' ] );
		$this->add_control( 'done', [ 'label' => __( 'Al entrar', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Signed in' ] );
		$this->add_control( 'hint', [ 'label' => __( 'Ayuda bajo los campos', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Enter para seguir · Esc para cerrar', 'wakoo' ) ] );
		$this->add_control( 'forgot', [ 'label' => __( 'Enlace «¿Olvidaste la contraseña?»', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => '' ] );
		$this->end_controls_section();

		$this->auth_controls( false );

		$this->start_controls_section( 'sec_phys', [ 'label' => __( 'Física del líquido', 'wakoo' ) ] );
		$this->add_control( 'pull', [ 'label' => __( 'PULL: cuánto se separan las mitades (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 120, 'default' => 26, 'description' => __( 'Con 60 el metal se estira más del doble.', 'wakoo' ) ] );
		$this->add_control( 'neck', [ 'label' => __( 'NECK: grosor del cuello (0-1)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0.05, 'max' => 0.9, 'step' => 0.01, 'default' => 0.34 ] );
		$this->add_control( 'k', [ 'label' => __( 'Rigidez del muelle (k)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 10, 'max' => 400, 'default' => 55 ] );
		$this->add_control( 'damping', [ 'label' => __( 'Amortiguación', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 60, 'default' => 11, 'description' => __( 'Baja a 4 y el botón tiembla como gelatina.', 'wakoo' ) ] );
		$this->end_controls_section();

		$this->start_controls_section( 'st_size', [ 'label' => __( 'Tamaños', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'bw', [ 'label' => __( 'Ancho del botón', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 210, 'min' => 100, 'max' => 500 ] );
		$this->add_control( 'bh', [ 'label' => __( 'Alto del botón', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 50, 'min' => 30, 'max' => 120 ] );
		$this->add_control( 'fw', [ 'label' => __( 'Ancho de los campos', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 280, 'min' => 160, 'max' => 700 ] );
		$this->add_control( 'fh', [ 'label' => __( 'Alto de cada campo', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 58, 'min' => 36, 'max' => 120 ] );
		$this->add_control( 'gap', [ 'label' => __( 'Separación entre campos', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 10, 'min' => 0, 'max' => 60 ] );
		$this->add_control( 'fr', [ 'label' => __( 'Redondez de los campos', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 14, 'min' => 0, 'max' => 40 ] );
		$this->add_responsive_control( 'align', [
			'label'     => __( 'Alineación', 'wakoo' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => [ 'flex-start' => [ 'title' => __( 'Izquierda', 'wakoo' ), 'icon' => 'eicon-text-align-left' ], 'center' => [ 'title' => __( 'Centro', 'wakoo' ), 'icon' => 'eicon-text-align-center' ], 'flex-end' => [ 'title' => __( 'Derecha', 'wakoo' ), 'icon' => 'eicon-text-align-right' ] ],
			'default'   => 'center',
			'selectors' => [ '{{WRAPPER}} .wk-ui-lq' => 'align-items: {{VALUE}};' ],
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'st_color', [ 'label' => __( 'Colores', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->var_color( 'm1', __( 'Metal claro', 'wakoo' ), '--lq-m1', '#F3F5F7' );
		$this->var_color( 'm2', __( 'Metal medio', 'wakoo' ), '--lq-m2', '#C9CFD5' );
		$this->var_color( 'm3', __( 'Metal sombra', 'wakoo' ), '--lq-m3', '#9AA3AB' );
		$this->var_color( 'btn_t', __( 'Texto del botón', 'wakoo' ), '--lq-btn', '#2B3138' );
		$this->var_color( 'ok', __( 'Tinte «Signed in»', 'wakoo' ), '--lq-ok', '#CFEDE2' );
		$this->var_color( 'ok_t', __( 'Marca ✓', 'wakoo' ), '--lq-okt', '#1F8F6A' );
		$this->var_color( 'field', __( 'Fondo de los campos', 'wakoo' ), '--lq-field', '#1A2028' );
		$this->var_color( 'field_b', __( 'Borde de los campos', 'wakoo' ), '--lq-fb', '#2A323C' );
		$this->var_color( 'focus', __( 'Borde al escribir', 'wakoo' ), '--lq-focus', '#3BB58F' );
		$this->var_color( 'label_c', __( 'Etiquetas', 'wakoo' ), '--lq-label', '#8D97A3' );
		$this->var_color( 'input_c', __( 'Texto escrito', 'wakoo' ), '--lq-input', '#F2F5F8' );
		$this->var_color( 'err_c', __( 'Errores', 'wakoo' ), '--lq-err', '#FF7A7A' );
		$this->typo( 't_btn', __( 'Botón', 'wakoo' ), '.wk-ui-lq__txt' );
		$this->typo( 't_input', __( 'Campos', 'wakoo' ), '.wk-ui-lq__half input' );
		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		if ( $this->logged_in_short_circuit( $s, 'wk-ui-lq' ) ) {
			return;
		}
		$n   = function ( $k, $d ) use ( $s ) { return isset( $s[ $k ] ) && '' !== $s[ $k ] ? (float) $s[ $k ] : $d; };
		$cfg = [
			'bw' => $n( 'bw', 210 ), 'bh' => $n( 'bh', 50 ), 'fw' => $n( 'fw', 280 ), 'fh' => $n( 'fh', 58 ), 'gap' => $n( 'gap', 10 ), 'fr' => $n( 'fr', 14 ),
			'pull' => $n( 'pull', 26 ), 'neck' => $n( 'neck', .34 ), 'k' => $n( 'k', 55 ), 'd' => $n( 'damping', 11 ),
			'demo' => 'demo' === ( $s['action_mode'] ?? 'login' ),
			'busy' => (string) $s['busy'], 'done' => (string) $s['done'], 'btn' => (string) $s['btn'],
		];
		$uid = 'wklq' . $this->get_id();
		echo '<div class="wk-ui wk-ui-lq" data-cfg="' . esc_attr( wp_json_encode( $cfg ) ) . '"' . $this->auth_attrs() . '>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<form class="wk-ui-lq__stage" novalidate autocomplete="on">';
		echo '<div class="wk-ui-lq__half wk-ui-lq__half--a"><span class="wk-ui-lq__metal"></span><label for="' . esc_attr( $uid ) . 'u">' . esc_html( $s['l_user'] ) . '</label><input id="' . esc_attr( $uid ) . 'u" name="log" type="text" inputmode="email" autocomplete="username" placeholder="' . esc_attr( $s['ph_user'] ) . '" tabindex="-1"></div>';
		echo '<div class="wk-ui-lq__half wk-ui-lq__half--b"><span class="wk-ui-lq__metal"></span><label for="' . esc_attr( $uid ) . 'p">' . esc_html( $s['l_pass'] ) . '</label><input id="' . esc_attr( $uid ) . 'p" name="pwd" type="password" autocomplete="current-password" tabindex="-1"></div>';
		echo '<svg class="wk-ui-lq__neck" aria-hidden="true"><defs><linearGradient id="' . esc_attr( $uid ) . 'g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" class="wk-ui-lq__s2"/><stop offset=".5" class="wk-ui-lq__s3"/><stop offset="1" class="wk-ui-lq__s2"/></linearGradient></defs><path fill="url(#' . esc_attr( $uid ) . 'g)"/><circle fill="url(#' . esc_attr( $uid ) . 'g)" r="0"/><circle fill="url(#' . esc_attr( $uid ) . 'g)" r="0"/></svg>';
		echo '<button type="button" class="wk-ui-lq__btn"><span class="wk-ui-lq__icon" aria-hidden="true"></span><span class="wk-ui-lq__txt">' . esc_html( $s['btn'] ) . '</span></button>';
		echo '<button type="submit" hidden tabindex="-1"></button>';
		echo '</form>';
		echo '<p class="wk-ui-lq__msg" role="status" aria-live="polite"></p>';
		if ( ! empty( $s['hint'] ) ) {
			echo '<p class="wk-ui-lq__hint">' . esc_html( $s['hint'] ) . '</p>';
		}
		if ( 'yes' === ( $s['forgot'] ?? '' ) ) {
			echo '<a class="wk-ui-lq__forgot" href="' . esc_url( wp_lostpassword_url() ) . '">' . esc_html__( '¿Olvidaste la contraseña?', 'wakoo' ) . '</a>';
		}
		echo '</div>';
	}
}
