<?php
/**
 * Acceso de vidrio V7: glass card with cut corners; switching between "Welcome Back" and "Create Account"
 * folds the card into an octagon, joins the two corner plates in the centre, flashes and unfolds.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Interfaz\Widgets;

use Elementor\Controls_Manager;
use Elementor\Repeater;

defined( 'ABSPATH' ) || die();

class Glass_Auth extends Base {

	protected function asset() { return 'glass-auth'; }
	public function get_name() { return 'wakoo-ui-glass-auth'; }
	public function get_title() { return __( 'Acceso de vidrio (login y registro)', 'wakoo' ); }
	public function get_icon() { return 'eicon-lock-user'; }
	public function get_keywords() { return [ 'login', 'registro', 'sign up', 'acceso', 'vidrio', 'glass', 'formulario', 'wakoo' ]; }

	protected function register_controls() {
		$t = function ( $id, $label, $def ) {
			$this->add_control( $id, [ 'label' => $label, 'type' => Controls_Manager::TEXT, 'default' => $def, 'label_block' => true ] );
		};
		$this->start_controls_section( 'sec_login', [ 'label' => __( 'Iniciar sesión', 'wakoo' ) ] );
		$t( 'l_title', __( 'Título (entre *asteriscos* va el color de acento)', 'wakoo' ), 'Welcome *Back*' );
		$t( 'l_sub', __( 'Subtítulo', 'wakoo' ), 'Enter your credentials to access your secure account' );
		$t( 'l_email', __( 'Etiqueta email', 'wakoo' ), 'Email Address' );
		$t( 'l_email_ph', __( 'Ejemplo email', 'wakoo' ), 'name@domain.com' );
		$t( 'l_pass', __( 'Etiqueta contraseña', 'wakoo' ), 'Password' );
		$this->add_control( 'show_remember', [ 'label' => __( 'Casilla «Recordarme»', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$t( 'l_remember', __( 'Texto «Recordarme»', 'wakoo' ), 'Remember me' );
		$this->add_control( 'show_forgot', [ 'label' => __( 'Enlace «¿Olvidaste…?»', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$t( 'l_forgot', __( 'Texto «¿Olvidaste…?»', 'wakoo' ), 'Forgot password?' );
		$t( 'l_btn', __( 'Botón', 'wakoo' ), 'Sign In' );
		$t( 'l_switch', __( 'Pie', 'wakoo' ), "Don't have an account?" );
		$t( 'l_switch_link', __( 'Enlace del pie', 'wakoo' ), 'Sign Up' );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_reg', [ 'label' => __( 'Crear cuenta', 'wakoo' ) ] );
		$this->add_control( 'register', [ 'label' => __( 'Permitir crear cuenta', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$t( 'r_title', __( 'Título', 'wakoo' ), 'Create *Account*' );
		$t( 'r_sub', __( 'Subtítulo', 'wakoo' ), 'Join us today to access your secure workspace' );
		$t( 'r_name', __( 'Etiqueta nombre', 'wakoo' ), 'Full Name' );
		$t( 'r_name_ph', __( 'Ejemplo nombre', 'wakoo' ), 'Alex Johnson' );
		$t( 'r_pass2', __( 'Etiqueta repetir contraseña', 'wakoo' ), 'Confirm Password' );
		$t( 'r_terms', __( 'Casilla de condiciones', 'wakoo' ), 'I agree to the Terms & Privacy Policy' );
		$this->add_control( 'terms_link', [ 'label' => __( 'Enlace a las condiciones', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$t( 'r_btn', __( 'Botón', 'wakoo' ), 'Create Account' );
		$t( 'r_switch', __( 'Pie', 'wakoo' ), 'Already have an account?' );
		$t( 'r_switch_link', __( 'Enlace del pie', 'wakoo' ), 'Sign In' );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_social', [ 'label' => __( 'Botones sociales', 'wakoo' ) ] );
		$this->add_control( 'show_social', [ 'label' => __( 'Mostrar', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'description' => __( 'Pon en cada botón el enlace de acceso de tu plugin de login social (por ejemplo Nextend Social Login: /wp-login.php?loginSocial=google).', 'wakoo' ) ] );
		$t( 'or', __( 'Separador', 'wakoo' ), 'Or continue with' );
		$r = new Repeater();
		$r->add_control( 'label', [ 'label' => __( 'Texto', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Google' ] );
		$r->add_control( 'icon', [ 'label' => __( 'Icono', 'wakoo' ), 'type' => Controls_Manager::ICONS, 'default' => [ 'value' => 'fab fa-google', 'library' => 'fa-brands' ] ] );
		$r->add_control( 'link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$this->add_control( 'social', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'title_field' => '{{{ label }}}',
			'default'     => [
				[ 'label' => 'Google', 'icon' => [ 'value' => 'fab fa-google', 'library' => 'fa-brands' ] ],
				[ 'label' => 'Apple', 'icon' => [ 'value' => 'fab fa-apple', 'library' => 'fa-brands' ] ],
			],
			'condition'   => [ 'show_social' => 'yes' ],
		] );
		$this->end_controls_section();

		$this->auth_controls( true );

		$this->start_controls_section( 'st_card', [ 'label' => __( 'Tarjeta', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_responsive_control( 'card_w', [
			'label'      => __( 'Ancho', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px', '%' ],
			'range'      => [ 'px' => [ 'min' => 280, 'max' => 720 ] ],
			'default'    => [ 'unit' => 'px', 'size' => 430 ],
			'selectors'  => [ '{{WRAPPER}} .wk-ui-ga__card' => 'width: {{SIZE}}{{UNIT}};' ],
		] );
		$this->var_slider( 'cut', __( 'Tamaño del corte de las esquinas', 'wakoo' ), '--ga-cut', 34, 0, 80 );
		$this->var_slider( 'blur', __( 'Desenfoque del vidrio', 'wakoo' ), '--ga-blur', 18, 0, 40 );
		$this->var_color( 'glass', __( 'Color del vidrio', 'wakoo' ), '--ga-glass', 'rgba(16,16,18,0.62)' );
		$this->var_color( 'edge', __( 'Borde', 'wakoo' ), '--ga-edge', 'rgba(255,255,255,0.16)' );
		$this->var_color( 'accent', __( 'Acento', 'wakoo' ), '--ga-accent', '#FFD60A' );
		$this->var_color( 'accent_t', __( 'Texto sobre el acento', 'wakoo' ), '--ga-on-accent', '#141414' );
		$this->var_color( 'text', __( 'Texto', 'wakoo' ), '--ga-text', '#F5F5F5' );
		$this->var_color( 'muted', __( 'Texto suave', 'wakoo' ), '--ga-muted', 'rgba(255,255,255,0.55)' );
		$this->var_color( 'field', __( 'Fondo de los campos', 'wakoo' ), '--ga-field', 'rgba(255,255,255,0.05)' );
		$this->add_control( 'corners', [ 'label' => __( 'Placas en las esquinas', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->typo( 't_title', __( 'Título', 'wakoo' ), '.wk-ui-ga__title' );
		$this->typo( 't_body', __( 'Textos y campos', 'wakoo' ), '.wk-ui-ga__card' );
		$this->end_controls_section();

		$this->start_controls_section( 'st_bg', [ 'label' => __( 'Fondo animado', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'backdrop', [ 'label' => __( 'Ondas doradas detrás de la tarjeta', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'description' => __( 'Desactívalo para usar el fondo (imagen o vídeo) del contenedor.', 'wakoo' ) ] );
		$this->var_color( 'bg1', __( 'Fondo', 'wakoo' ), '--ga-bg', '#060606' );
		$this->var_color( 'bg2', __( 'Ondas', 'wakoo' ), '--ga-wave', '#C98A1B' );
		$this->add_responsive_control( 'min_h', [
			'label'      => __( 'Alto mínimo', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px', 'vh' ],
			'range'      => [ 'px' => [ 'min' => 300, 'max' => 1200 ], 'vh' => [ 'min' => 30, 'max' => 100 ] ],
			'default'    => [ 'unit' => 'px', 'size' => 720 ],
			'selectors'  => [ '{{WRAPPER}} .wk-ui-ga' => 'min-height: {{SIZE}}{{UNIT}};' ],
		] );
		$this->end_controls_section();
	}

	private function title( $text ) {
		$parts = explode( '*', (string) $text );
		$out   = '';
		foreach ( $parts as $i => $p ) {
			$out .= $i % 2 ? '<span>' . esc_html( $p ) . '</span>' : esc_html( $p );
		}
		return $out;
	}

	private function field( $type, $name, $label, $ph, $icon, $ac, $uid ) {
		$icons = [
			'mail' => '<path d="M4 6h16v12H4z"/><path d="m4 7 8 6 8-6"/>',
			'lock' => '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
			'user' => '<circle cx="12" cy="8" r="4"/><path d="M4 20a8 8 0 0 1 16 0"/>',
		];
		$id  = $uid . $name;
		$out = '<div class="wk-ui-ga__field wk-ui-ga__anim"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label><div class="wk-ui-ga__box">'
			. '<svg viewBox="0 0 24 24" aria-hidden="true">' . $icons[ $icon ] . '</svg>'
			. '<input id="' . esc_attr( $id ) . '" type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" placeholder="' . esc_attr( $ph ) . '" autocomplete="' . esc_attr( $ac ) . '" required>';
		if ( 'password' === $type ) {
			$out .= '<button type="button" class="wk-ui-ga__eye" aria-label="' . esc_attr__( 'Mostrar u ocultar la contraseña', 'wakoo' ) . '"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg></button>';
		}
		return $out . '</div></div>';
	}

	private function social( $s ) {
		if ( 'yes' !== ( $s['show_social'] ?? '' ) || empty( $s['social'] ) ) {
			return '';
		}
		$out = '<div class="wk-ui-ga__or wk-ui-ga__anim"><span>' . esc_html( $s['or'] ) . '</span></div><div class="wk-ui-ga__social wk-ui-ga__anim">';
		foreach ( $s['social'] as $b ) {
			$url  = $b['link']['url'] ?? '';
			$out .= '<a class="wk-ui-ga__soc" href="' . esc_url( $url ? $url : '#' ) . '">' . $this->icon( $b['icon'] ) . '<span>' . esc_html( $b['label'] ) . '</span></a>';
		}
		return $out . '</div>';
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		if ( $this->logged_in_short_circuit( $s, 'wk-ui-ga' ) ) {
			return;
		}
		$uid   = 'wkga' . $this->get_id();
		$reg   = 'yes' === ( $s['register'] ?? '' );
		$cfg   = [ 'demo' => 'demo' === ( $s['action_mode'] ?? 'login' ) ];
		$arrow = '<svg class="wk-ui-ga__arrow" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg>';

		echo '<div class="wk-ui wk-ui-ga' . ( 'yes' === ( $s['backdrop'] ?? '' ) ? ' has-backdrop' : '' ) . '" data-cfg="' . esc_attr( wp_json_encode( $cfg ) ) . '"' . $this->auth_attrs() . '>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( 'yes' === ( $s['backdrop'] ?? '' ) ) {
			echo '<div class="wk-ui-ga__waves" aria-hidden="true"><svg viewBox="0 0 1200 800" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="' . esc_attr( $uid ) . 'w" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="var(--ga-wave,#c98a1b)" stop-opacity="0"/><stop offset=".45" stop-color="var(--ga-wave,#c98a1b)"/><stop offset=".55" stop-color="#ffe2a0"/><stop offset="1" stop-color="var(--ga-wave,#c98a1b)" stop-opacity="0"/></linearGradient></defs>';
			for ( $i = 0; $i < 7; $i++ ) {
				$y = 120 + $i * 85;
				echo '<path class="wk-ui-ga__wave" style="--d:' . ( $i * -2.1 ) . 's" d="M-100 ' . $y . ' C 250 ' . ( $y - 220 ) . ', 520 ' . ( $y + 260 ) . ', 820 ' . ( $y - 40 ) . ' S 1200 ' . ( $y - 260 ) . ', 1320 ' . ( $y + 60 ) . '" stroke="url(#' . esc_attr( $uid ) . 'w)" stroke-width="' . ( 10 + ( $i % 3 ) * 14 ) . '" fill="none"/>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '</svg></div>';
		}
		echo '<div class="wk-ui-ga__card' . ( 'yes' === ( $s['corners'] ?? '' ) ? ' has-plates' : '' ) . '">';
		echo '<span class="wk-ui-ga__plate wk-ui-ga__plate--a" aria-hidden="true"></span><span class="wk-ui-ga__plate wk-ui-ga__plate--b" aria-hidden="true"></span><span class="wk-ui-ga__flash" aria-hidden="true"></span>';

		// Login pane.
		echo '<form class="wk-ui-ga__pane is-current" data-pane="login" novalidate>';
		echo '<h3 class="wk-ui-ga__title wk-ui-ga__anim">' . $this->title( $s['l_title'] ) . '</h3><p class="wk-ui-ga__sub wk-ui-ga__anim">' . esc_html( $s['l_sub'] ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo $this->field( 'email', 'user', $s['l_email'], $s['l_email_ph'], 'mail', 'username', $uid ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo $this->field( 'password', 'pass', $s['l_pass'], '••••••••', 'lock', 'current-password', $uid ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<div class="wk-ui-ga__row wk-ui-ga__anim">';
		if ( 'yes' === ( $s['show_remember'] ?? '' ) ) {
			echo '<label class="wk-ui-ga__check"><input type="checkbox" name="remember" value="1" checked><i></i>' . esc_html( $s['l_remember'] ) . '</label>';
		}
		if ( 'yes' === ( $s['show_forgot'] ?? '' ) ) {
			echo '<a class="wk-ui-ga__forgot" href="' . esc_url( wp_lostpassword_url() ) . '">' . esc_html( $s['l_forgot'] ) . '</a>';
		}
		echo '</div>';
		echo '<p class="wk-ui-ga__msg" role="status" aria-live="polite"></p>';
		echo '<button type="submit" class="wk-ui-ga__btn wk-ui-ga__anim"><span>' . esc_html( $s['l_btn'] ) . '</span>' . $arrow . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo $this->social( $s ); // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $reg ) {
			echo '<p class="wk-ui-ga__foot wk-ui-ga__anim">' . esc_html( $s['l_switch'] ) . ' <a href="#" data-go="register">' . esc_html( $s['l_switch_link'] ) . '</a></p>';
		}
		echo '</form>';

		// Register pane.
		if ( $reg ) {
			$terms = $s['r_terms'];
			if ( ! empty( $s['terms_link']['url'] ) ) {
				$terms = '<a href="' . esc_url( $s['terms_link']['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $terms ) . '</a>';
			} else {
				$terms = esc_html( $terms );
			}
			echo '<form class="wk-ui-ga__pane" data-pane="register" novalidate hidden>';
			echo '<h3 class="wk-ui-ga__title wk-ui-ga__anim">' . $this->title( $s['r_title'] ) . '</h3><p class="wk-ui-ga__sub wk-ui-ga__anim">' . esc_html( $s['r_sub'] ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo $this->field( 'text', 'name', $s['r_name'], $s['r_name_ph'], 'user', 'name', $uid . 'r' ); // phpcs:ignore WordPress.Security.EscapeOutput
			echo $this->field( 'email', 'email', $s['l_email'], $s['l_email_ph'], 'mail', 'email', $uid . 'r' ); // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<div class="wk-ui-ga__cols">';
			echo $this->field( 'password', 'pass', $s['l_pass'], '••••••••', 'lock', 'new-password', $uid . 'r' ); // phpcs:ignore WordPress.Security.EscapeOutput
			echo $this->field( 'password', 'pass2', $s['r_pass2'], '••••••••', 'lock', 'new-password', $uid . 'r' ); // phpcs:ignore WordPress.Security.EscapeOutput
			echo '</div>';
			echo '<input type="text" name="wk_hp" class="wk-ui-hp" tabindex="-1" autocomplete="off" aria-hidden="true">';
			echo '<div class="wk-ui-ga__row wk-ui-ga__anim"><label class="wk-ui-ga__check"><input type="checkbox" name="agree" value="1" required><i></i>' . $terms . '</label></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<p class="wk-ui-ga__msg" role="status" aria-live="polite"></p>';
			echo '<button type="submit" class="wk-ui-ga__btn wk-ui-ga__anim"><span>' . esc_html( $s['r_btn'] ) . '</span>' . $arrow . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo $this->social( $s ); // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<p class="wk-ui-ga__foot wk-ui-ga__anim">' . esc_html( $s['r_switch'] ) . ' <a href="#" data-go="login">' . esc_html( $s['r_switch_link'] ) . '</a></p>';
			echo '</form>';
		}
		echo '</div></div>';
	}
}
