<?php
/**
 * Barra de pestañas V2: three animated tab bars (lamp, floating bubble, liquid drop).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Interfaz\Widgets;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Box_Shadow;

defined( 'ABSPATH' ) || die();

class Tabbar extends Base {

	protected function asset() { return 'tabbar'; }
	public function get_name() { return 'wakoo-ui-tabbar'; }
	public function get_title() { return __( 'Barra de pestañas animada', 'wakoo' ); }
	public function get_icon() { return 'eicon-tabs'; }
	public function get_keywords() { return [ 'tabs', 'pestañas', 'navegacion', 'tab bar', 'menu inferior', 'bottom', 'liquid', 'wakoo' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_items', [ 'label' => __( 'Pestañas', 'wakoo' ) ] );
		$this->add_control( 'style', [
			'label'   => __( 'Estilo', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'liquid',
			'options' => [
				'lamp'   => __( 'Lámpara (oscura, luz arriba)', 'wakoo' ),
				'bubble' => __( 'Burbuja flotante', 'wakoo' ),
				'liquid' => __( 'Gota líquida con textos', 'wakoo' ),
			],
		] );
		$r = new Repeater();
		$r->add_control( 'label', [ 'label' => __( 'Texto', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Pestaña', 'wakoo' ) ] );
		$r->add_control( 'icon', [ 'label' => __( 'Icono', 'wakoo' ), 'type' => Controls_Manager::ICONS, 'default' => [ 'value' => 'far fa-circle', 'library' => 'fa-regular' ] ] );
		$r->add_control( 'link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL, 'description' => __( 'Vacío o #ancla: solo cambia la pestaña. También puede apuntar al ID de una sección (#servicios).', 'wakoo' ) ] );
		$r->add_control( 'color', [ 'label' => __( 'Color (estilo gota)', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#E9A6C8' ] );
		$r->add_control( 'active', [ 'label' => __( 'Activa al cargar', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ] );
		$this->add_control( 'items', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'title_field' => '{{{ label }}}',
			'default'     => [
				[ 'label' => 'Home', 'icon' => [ 'value' => 'fas fa-home', 'library' => 'fa-solid' ], 'color' => '#B9D3F5', 'active' => 'yes' ],
				[ 'label' => 'Likes', 'icon' => [ 'value' => 'far fa-heart', 'library' => 'fa-regular' ], 'color' => '#F2A7CB' ],
				[ 'label' => 'Add', 'icon' => [ 'value' => 'fas fa-plus-circle', 'library' => 'fa-solid' ], 'color' => '#D3B4F2' ],
				[ 'label' => 'Profile', 'icon' => [ 'value' => 'far fa-user', 'library' => 'fa-regular' ], 'color' => '#A9D8F2' ],
				[ 'label' => 'Alerts', 'icon' => [ 'value' => 'far fa-bell', 'library' => 'fa-regular' ], 'color' => '#F5D49A' ],
			],
		] );
		$this->add_control( 'labels', [ 'label' => __( 'Mostrar textos', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'auto', 'options' => [ 'auto' => __( 'Según el estilo', 'wakoo' ), 'yes' => __( 'Sí', 'wakoo' ), 'no' => __( 'No', 'wakoo' ) ] ] );
		$this->add_control( 'home_line', [ 'label' => __( 'Línea inferior decorativa', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'condition' => [ 'style' => 'bubble' ] ] );
		$this->add_control( 'scrollspy', [ 'label' => __( 'Seguir las secciones al hacer scroll', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'description' => __( 'Con enlaces #ancla, la pestaña cambia sola al llegar a cada sección.', 'wakoo' ) ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_place', [ 'label' => __( 'Posición', 'wakoo' ) ] );
		$this->add_control( 'position', [
			'label'   => __( 'Dónde', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'inline',
			'options' => [
				'inline'        => __( 'En su sitio', 'wakoo' ),
				'bottom-mobile' => __( 'Fija abajo solo en el móvil', 'wakoo' ),
				'bottom'        => __( 'Fija abajo siempre', 'wakoo' ),
			],
		] );
		$this->add_responsive_control( 'align', [
			'label'     => __( 'Alineación', 'wakoo' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => [ 'flex-start' => [ 'title' => __( 'Izquierda', 'wakoo' ), 'icon' => 'eicon-text-align-left' ], 'center' => [ 'title' => __( 'Centro', 'wakoo' ), 'icon' => 'eicon-text-align-center' ], 'flex-end' => [ 'title' => __( 'Derecha', 'wakoo' ), 'icon' => 'eicon-text-align-right' ] ],
			'default'   => 'center',
			'selectors' => [ '{{WRAPPER}} .wk-ui-tb' => 'justify-content: {{VALUE}};' ],
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'st_bar', [ 'label' => __( 'Barra', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_responsive_control( 'width', [
			'label'      => __( 'Ancho', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px', '%' ],
			'range'      => [ 'px' => [ 'min' => 200, 'max' => 900 ], '%' => [ 'min' => 20, 'max' => 100 ] ],
			'default'    => [ 'unit' => 'px', 'size' => 380 ],
			'selectors'  => [ '{{WRAPPER}} .wk-ui-tb__bar' => 'width: {{SIZE}}{{UNIT}};' ],
		] );
		$this->var_slider( 'bar_h', __( 'Alto', 'wakoo' ), '--tb-h', 56, 40, 100 );
		$this->var_slider( 'bar_r', __( 'Redondez', 'wakoo' ), '--tb-r', 28, 0, 50 );
		$this->var_slider( 'icon_s', __( 'Tamaño de iconos', 'wakoo' ), '--tb-icon', 18, 12, 32 );
		$this->var_slider( 'dur', __( 'Duración (s)', 'wakoo' ), '--tb-dur', 0.5, 0.15, 2, 's' );
		$this->var_color( 'bg', __( 'Fondo', 'wakoo' ), '--tb-bg', '' );
		$this->var_color( 'ic', __( 'Iconos', 'wakoo' ), '--tb-ic', '' );
		$this->var_color( 'ac', __( 'Activo / acento', 'wakoo' ), '--tb-ac', '' );
		$this->add_control( 'tint', [ 'label' => __( 'Teñir la barra con el color de la pestaña (gota)', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'condition' => [ 'style' => 'liquid' ] ] );
		$this->add_group_control( Group_Control_Box_Shadow::get_type(), [ 'name' => 'shadow', 'selector' => '{{WRAPPER}} .wk-ui-tb__bar' ] );
		$this->typo( 't_label', __( 'Textos', 'wakoo' ), '.wk-ui-tb__label' );
		$this->end_controls_section();
	}

	protected function render() {
		$s      = $this->get_settings_for_display();
		$style  = $s['style'] ?? 'liquid';
		$labels = $s['labels'] ?? 'auto';
		$labels = 'auto' === $labels ? ( 'liquid' === $style ? 'yes' : 'no' ) : $labels;
		$items  = (array) $s['items'];
		$active = 0;
		foreach ( $items as $i => $it ) {
			if ( 'yes' === ( $it['active'] ?? '' ) ) { $active = $i; break; }
		}
		$goo = 'wk-goo-' . $this->get_id();
		$cfg = [ 'style' => $style, 'spy' => 'yes' === ( $s['scrollspy'] ?? '' ), 'tint' => 'yes' === ( $s['tint'] ?? '' ) ];
		$cls = 'wk-ui wk-ui-tb wk-ui-tb--' . $style . ' wk-ui-tb--' . ( $s['position'] ?? 'inline' ) . ( 'yes' === $labels ? ' has-labels' : '' ) . ( 'yes' === ( $s['home_line'] ?? '' ) ? ' has-line' : '' );

		echo '<div class="' . esc_attr( $cls ) . '" data-cfg="' . esc_attr( wp_json_encode( $cfg ) ) . '" style="--n:' . count( $items ) . ';--i:' . (int) $active . '">';
		if ( 'liquid' === $style ) {
			echo '<svg class="wk-ui-tb__defs" aria-hidden="true" width="0" height="0"><filter id="' . esc_attr( $goo ) . '"><feGaussianBlur in="SourceGraphic" stdDeviation="7" result="b"/><feColorMatrix in="b" mode="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 22 -9" result="g"/><feComposite in="SourceGraphic" in2="g" operator="atop"/></filter></svg>';
		}
		echo '<nav class="wk-ui-tb__bar" aria-label="' . esc_attr__( 'Pestañas', 'wakoo' ) . '">';
		if ( 'liquid' === $style ) {
			echo '<span class="wk-ui-tb__goo" style="filter:url(#' . esc_attr( $goo ) . ')"><span class="wk-ui-tb__fill"></span><span class="wk-ui-tb__drop"></span></span>';
			echo '<span class="wk-ui-tb__bubble" aria-hidden="true"></span>';
		} else {
			echo '<span class="wk-ui-tb__ind" aria-hidden="true"></span>';
		}
		foreach ( $items as $i => $it ) {
			$url   = $it['link']['url'] ?? '';
			$color = ! empty( $it['color'] ) ? $it['color'] : '#E9A6C8';
			echo '<a class="wk-ui-tb__item' . ( $i === $active ? ' is-active' : '' ) . '" href="' . esc_url( $url ? $url : '#' ) . '"' . ( $i === $active ? ' aria-current="page"' : '' ) . ' style="--c:' . esc_attr( $color ) . '" data-i="' . (int) $i . '">';
			echo '<span class="wk-ui-tb__icon">' . $this->icon( $it['icon'] ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<span class="wk-ui-tb__label">' . esc_html( $it['label'] ) . '</span>';
			echo '</a>';
		}
		echo '</nav></div>';
	}
}
