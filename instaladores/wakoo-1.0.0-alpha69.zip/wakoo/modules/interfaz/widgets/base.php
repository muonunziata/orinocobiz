<?php
/**
 * Shared base for the Wakoo Interfaz widgets.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Interfaz\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;

defined( 'ABSPATH' ) || die();

abstract class Base extends Widget_Base {

	/** Asset key, e.g. "sidebar" → wakoo-ui-sidebar.css/js. */
	abstract protected function asset();

	public function get_categories() { return [ 'wakoo-interfaz' ]; }
	public function get_script_depends() { return [ 'wakoo-ui-core', 'wakoo-ui-' . $this->asset() ]; }
	public function get_style_depends() { return [ 'wakoo-ui-' . $this->asset() ]; }

	protected function is_editor() {
		return class_exists( '\Elementor\Plugin' ) && ( \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode() );
	}

	/** data-* attributes the auth widgets send back to admin-ajax. */
	protected function auth_attrs() {
		$post = get_the_ID();
		$doc  = class_exists( '\Elementor\Plugin' ) ? \Elementor\Plugin::$instance->documents->get_current() : null;
		if ( $doc ) {
			$post = $doc->get_main_id();
		}
		return sprintf(
			' data-post="%d" data-el="%s" data-nonce="%s"%s',
			(int) $post,
			esc_attr( $this->get_id() ),
			esc_attr( wp_create_nonce( 'wakoo_ui_auth' ) ),
			$this->is_editor() ? ' data-editor="1"' : ''
		);
	}

	protected function icon( $icon, $attrs = [ 'aria-hidden' => 'true' ] ) {
		if ( empty( $icon['value'] ) ) {
			return '';
		}
		ob_start();
		Icons_Manager::render_icon( $icon, $attrs );
		return ob_get_clean();
	}

	protected function color( $id, $label, $selector, $default = '', $prop = 'color' ) {
		$this->add_control( $id, [
			'label'     => $label,
			'type'      => Controls_Manager::COLOR,
			'default'   => $default,
			'selectors' => [ '{{WRAPPER}} ' . $selector => $prop . ': {{VALUE}};' ],
		] );
	}

	/** Colour stored as a CSS custom property on the widget root. */
	protected function var_color( $id, $label, $var, $default = '', $root = '.wk-ui' ) {
		$this->add_control( $id, [
			'label'     => $label,
			'type'      => Controls_Manager::COLOR,
			'default'   => $default,
			'selectors' => [ '{{WRAPPER}} ' . $root => $var . ': {{VALUE}};' ],
		] );
	}

	protected function var_slider( $id, $label, $var, $default, $min, $max, $unit = 'px', $root = '.wk-ui', $responsive = false ) {
		$args = [
			'label'      => $label,
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ $unit ],
			'range'      => [ $unit => [ 'min' => $min, 'max' => $max, 'step' => ( 'px' === $unit || '' === $unit ) ? 1 : 0.05 ] ],
			'default'    => [ 'unit' => $unit, 'size' => $default ],
			'selectors'  => [ '{{WRAPPER}} ' . $root => $var . ': {{SIZE}}{{UNIT}};' ],
		];
		if ( 's' === $unit || 'ms' === $unit || '' === $unit ) {
			// Unitless values (seconds, factors): a plain number field.
			$args = [
				'label'     => $label,
				'type'      => Controls_Manager::NUMBER,
				'min'       => $min,
				'max'       => $max,
				'step'      => 's' === $unit ? 0.05 : ( '' === $unit ? 0.01 : 1 ),
				'default'   => $default,
				'selectors' => [ '{{WRAPPER}} ' . $root => $var . ': {{VALUE}}' . $unit . ';' ],
			];
		}
		if ( $responsive ) {
			$this->add_responsive_control( $id, $args );
		} else {
			$this->add_control( $id, $args );
		}
	}

	protected function typo( $id, $label, $selector ) {
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name'     => $id,
			'label'    => $label,
			'selector' => '{{WRAPPER}} ' . $selector,
		] );
	}

	/** Action / redirect / logged-in controls shared by the login widgets. */
	protected function auth_controls( $with_register = true ) {
		$this->start_controls_section( 'sec_action', [ 'label' => __( 'Acción', 'wakoo' ) ] );
		$this->add_control( 'action_mode', [
			'label'   => __( 'Al enviar', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'login',
			'options' => [
				'login' => __( 'Iniciar sesión en WordPress (real)', 'wakoo' ),
				'demo'  => __( 'Demostración (solo la animación)', 'wakoo' ),
			],
			'description' => $with_register ? __( 'El registro necesita «Cualquiera puede registrarse» en Ajustes → Generales.', 'wakoo' ) : '',
		] );
		$this->add_control( 'redirect', [
			'label'       => __( 'Ir a esta página al entrar', 'wakoo' ),
			'type'        => Controls_Manager::URL,
			'placeholder' => home_url( '/mi-cuenta/' ),
			'description' => __( 'Vacío: se queda en la página y la recarga.', 'wakoo' ),
		] );
		if ( $with_register ) {
			$this->add_control( 'redirect_reg', [
				'label'       => __( 'Ir a esta página al registrarse', 'wakoo' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => home_url( '/bienvenida/' ),
			] );
		}
		$this->add_control( 'logged_in', [
			'label'   => __( 'Si el visitante ya inició sesión', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'show',
			'options' => [
				'show'    => __( 'Mostrar igual', 'wakoo' ),
				'message' => __( 'Mostrar un mensaje', 'wakoo' ),
				'hide'    => __( 'Ocultar el widget', 'wakoo' ),
			],
		] );
		$this->add_control( 'logged_msg', [
			'label'     => __( 'Mensaje', 'wakoo' ),
			'type'      => Controls_Manager::TEXT,
			'default'   => __( 'Hola, {name}. Ya iniciaste sesión.', 'wakoo' ),
			'condition' => [ 'logged_in' => 'message' ],
		] );
		$this->end_controls_section();
	}

	/** Returns true when the widget must not render the form (already logged in). */
	protected function logged_in_short_circuit( $s, $class ) {
		if ( $this->is_editor() || ! is_user_logged_in() || 'show' === ( $s['logged_in'] ?? 'show' ) ) {
			return false;
		}
		if ( 'message' === $s['logged_in'] ) {
			$u = wp_get_current_user();
			echo '<div class="wk-ui ' . esc_attr( $class ) . ' wk-ui-logged">' . esc_html( str_replace( '{name}', $u->display_name, (string) $s['logged_msg'] ) )
				. ' <a href="' . esc_url( wp_logout_url( get_permalink() ) ) . '">' . esc_html__( 'Cerrar sesión', 'wakoo' ) . '</a></div>';
		}
		return true;
	}
}
