<?php
/**
 * Login / registro diagonal: two-panel box where a slanted colour sheet sweeps across and the fields slide in
 * one after another with blur.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Interfaz\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Slide_Auth extends Base {

	protected function asset() { return 'slide-auth'; }
	public function get_name() { return 'wakoo-ui-slide-auth'; }
	public function get_title() { return __( 'Login / registro diagonal', 'wakoo' ); }
	public function get_icon() { return 'eicon-form-horizontal'; }
	public function get_keywords() { return [ 'login', 'registro', 'sign up', 'acceso', 'diagonal', 'animado', 'formulario', 'wakoo' ]; }

	protected function register_controls() {
		$t = function ( $id, $label, $def, $type = Controls_Manager::TEXT ) {
			$this->add_control( $id, [ 'label' => $label, 'type' => $type, 'default' => $def, 'label_block' => true ] );
		};
		$this->start_controls_section( 'sec_login', [ 'label' => __( 'Iniciar sesión', 'wakoo' ) ] );
		$t( 'l_title', __( 'Título', 'wakoo' ), 'Login' );
		$t( 'l_user', __( 'Campo usuario', 'wakoo' ), 'Username' );
		$t( 'l_pass', __( 'Campo contraseña', 'wakoo' ), 'Password' );
		$t( 'l_btn', __( 'Botón', 'wakoo' ), 'Login' );
		$t( 'l_switch', __( 'Pie', 'wakoo' ), "Don't have an account?" );
		$t( 'l_switch_link', __( 'Enlace del pie', 'wakoo' ), 'Sign Up' );
		$t( 'l_info_t', __( 'Título del panel de color', 'wakoo' ), 'WELCOME BACK!' );
		$t( 'l_info', __( 'Texto del panel de color', 'wakoo' ), "We are happy to have you with us again. If you need anything, we are here to help.", Controls_Manager::TEXTAREA );
		$this->add_control( 'show_forgot', [ 'label' => __( 'Enlace «¿Olvidaste la contraseña?»', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_reg', [ 'label' => __( 'Registro', 'wakoo' ) ] );
		$t( 'r_title', __( 'Título', 'wakoo' ), 'Register' );
		$t( 'r_user', __( 'Campo nombre', 'wakoo' ), 'Username' );
		$t( 'r_email', __( 'Campo email', 'wakoo' ), 'Email' );
		$t( 'r_pass', __( 'Campo contraseña', 'wakoo' ), 'Password' );
		$t( 'r_btn', __( 'Botón', 'wakoo' ), 'Register' );
		$t( 'r_switch', __( 'Pie', 'wakoo' ), 'Already have an account?' );
		$t( 'r_switch_link', __( 'Enlace del pie', 'wakoo' ), 'Sign In' );
		$t( 'r_info_t', __( 'Título del panel de color', 'wakoo' ), 'WELCOME!' );
		$t( 'r_info', __( 'Texto del panel de color', 'wakoo' ), "We're delighted to have you here. If you need any assistance, feel free to reach out.", Controls_Manager::TEXTAREA );
		$this->add_control( 'start', [ 'label' => __( 'Empezar mostrando', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'login', 'options' => [ 'login' => __( 'Iniciar sesión', 'wakoo' ), 'register' => __( 'Registro', 'wakoo' ) ] ] );
		$this->end_controls_section();

		$this->auth_controls( true );

		$this->start_controls_section( 'st_box', [ 'label' => __( 'Caja', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_responsive_control( 'box_w', [
			'label'      => __( 'Ancho', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px', '%' ],
			'range'      => [ 'px' => [ 'min' => 300, 'max' => 1100 ] ],
			'default'    => [ 'unit' => 'px', 'size' => 750 ],
			'selectors'  => [ '{{WRAPPER}} .wk-ui-sa__box' => 'width: {{SIZE}}{{UNIT}};' ],
		] );
		$this->var_slider( 'box_h', __( 'Alto', 'wakoo' ), '--sa-h', 450, 360, 700 );
		$this->var_color( 'accent', __( 'Color principal', 'wakoo' ), '--sa-accent', '#E46033' );
		$this->var_color( 'dark', __( 'Fondo', 'wakoo' ), '--sa-dark', '#25252B' );
		$this->var_color( 'text', __( 'Texto', 'wakoo' ), '--sa-text', '#FFFFFF' );
		$this->var_slider( 'glow', __( 'Brillo del borde', 'wakoo' ), '--sa-glow', 25, 0, 80 );
		$this->var_slider( 'radius', __( 'Redondez', 'wakoo' ), '--sa-radius', 0, 0, 40 );
		$this->var_slider( 'speed', __( 'Duración del barrido (s)', 'wakoo' ), '--sa-speed', 1.5, 0.4, 4, 's' );
		$this->typo( 't_title', __( 'Títulos', 'wakoo' ), '.wk-ui-sa h2' );
		$this->typo( 't_info', __( 'Textos del panel', 'wakoo' ), '.wk-ui-sa__info p' );
		$this->end_controls_section();
	}

	private function input( $type, $name, $label, $icon, $ac, $i, $j ) {
		$paths = [
			'user' => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0z"/>',
			'mail' => '<path d="M3 5h18v14H3z"/><path d="m3 6 9 7 9-7" fill="none" stroke="var(--_dark)" stroke-width="1.6"/>',
			'lock' => '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3" fill="none" stroke="currentColor" stroke-width="2"/>',
		];
		return '<div class="wk-ui-sa__in wk-ui-sa__anim" style="--i:' . $i . ';--j:' . $j . '"><input type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" required autocomplete="' . esc_attr( $ac ) . '" placeholder=" "><label>' . esc_html( $label ) . '</label><svg viewBox="0 0 24 24" aria-hidden="true">' . $paths[ $icon ] . '</svg></div>';
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		if ( $this->logged_in_short_circuit( $s, 'wk-ui-sa' ) ) {
			return;
		}
		$cfg = [ 'demo' => 'demo' === ( $s['action_mode'] ?? 'login' ) ];
		$reg = 'register' === ( $s['start'] ?? 'login' );
		echo '<div class="wk-ui wk-ui-sa" data-cfg="' . esc_attr( wp_json_encode( $cfg ) ) . '"' . $this->auth_attrs() . '>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<div class="wk-ui-sa__box' . ( $reg ? ' is-active' : '' ) . '">';
		echo '<span class="wk-ui-sa__bg1" aria-hidden="true"></span><span class="wk-ui-sa__bg2" aria-hidden="true"></span>';

		echo '<form class="wk-ui-sa__form wk-ui-sa__form--login" data-act="login" novalidate>';
		echo '<h2 class="wk-ui-sa__anim" style="--i:0;--j:21">' . esc_html( $s['l_title'] ) . '</h2>';
		echo $this->input( 'text', 'user', $s['l_user'], 'user', 'username', 1, 22 ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo $this->input( 'password', 'pass', $s['l_pass'], 'lock', 'current-password', 2, 23 ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<p class="wk-ui-sa__msg" role="status" aria-live="polite"></p>';
		echo '<button type="submit" class="wk-ui-sa__btn wk-ui-sa__anim" style="--i:3;--j:24">' . esc_html( $s['l_btn'] ) . '</button>';
		echo '<p class="wk-ui-sa__link wk-ui-sa__anim" style="--i:4;--j:25">' . esc_html( $s['l_switch'] ) . '<br><a href="#" data-go="register">' . esc_html( $s['l_switch_link'] ) . '</a>';
		if ( 'yes' === ( $s['show_forgot'] ?? '' ) ) {
			echo '<br><a class="wk-ui-sa__forgot" href="' . esc_url( wp_lostpassword_url() ) . '">' . esc_html__( '¿Olvidaste la contraseña?', 'wakoo' ) . '</a>';
		}
		echo '</p></form>';
		echo '<div class="wk-ui-sa__info wk-ui-sa__info--login"><h2 class="wk-ui-sa__anim" style="--i:0;--j:20">' . esc_html( $s['l_info_t'] ) . '</h2><p class="wk-ui-sa__anim" style="--i:1;--j:21">' . esc_html( $s['l_info'] ) . '</p></div>';

		echo '<form class="wk-ui-sa__form wk-ui-sa__form--register" data-act="register" novalidate>';
		echo '<h2 class="wk-ui-sa__anim" style="--i:17;--j:0">' . esc_html( $s['r_title'] ) . '</h2>';
		echo $this->input( 'text', 'name', $s['r_user'], 'user', 'name', 18, 1 ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo $this->input( 'email', 'email', $s['r_email'], 'mail', 'email', 19, 2 ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo $this->input( 'password', 'pass', $s['r_pass'], 'lock', 'new-password', 20, 3 ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<input type="text" name="wk_hp" class="wk-ui-hp" tabindex="-1" autocomplete="off" aria-hidden="true">';
		echo '<p class="wk-ui-sa__msg" role="status" aria-live="polite"></p>';
		echo '<button type="submit" class="wk-ui-sa__btn wk-ui-sa__anim" style="--i:21;--j:4">' . esc_html( $s['r_btn'] ) . '</button>';
		echo '<p class="wk-ui-sa__link wk-ui-sa__anim" style="--i:22;--j:5">' . esc_html( $s['r_switch'] ) . '<br><a href="#" data-go="login">' . esc_html( $s['r_switch_link'] ) . '</a></p>';
		echo '</form>';
		echo '<div class="wk-ui-sa__info wk-ui-sa__info--register"><h2 class="wk-ui-sa__anim" style="--i:17;--j:0">' . esc_html( $s['r_info_t'] ) . '</h2><p class="wk-ui-sa__anim" style="--i:18;--j:1">' . esc_html( $s['r_info'] ) . '</p></div>';

		echo '</div></div>';
	}
}
