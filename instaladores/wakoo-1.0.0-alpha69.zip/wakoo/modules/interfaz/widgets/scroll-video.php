<?php
/**
 * Hero con vídeo al hacer scroll: the "interactive website made with AI" pattern. A video (or an image
 * sequence) of a 3D object plays forwards and backwards with the scroll while the section stays pinned,
 * with a big headline, side text, a call to action and text layers that appear along the way.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Interfaz\Widgets;

use Elementor\Controls_Manager;
use Elementor\Repeater;

defined( 'ABSPATH' ) || die();

class Scroll_Video extends Base {

	protected function asset() { return 'scroll-video'; }
	public function get_name() { return 'wakoo-ui-scroll-video'; }
	public function get_title() { return __( 'Hero con vídeo al hacer scroll', 'wakoo' ); }
	public function get_icon() { return 'eicon-video-camera'; }
	public function get_keywords() { return [ 'hero', 'video', 'scroll', 'scrub', '3d', 'secuencia', 'landing', 'apple', 'ia', 'wakoo' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_media', [ 'label' => __( 'Vídeo u objeto', 'wakoo' ) ] );
		$this->add_control( 'source', [
			'label'   => __( 'Fuente', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'demo',
			'options' => [
				'demo'     => __( 'Demostración: pila de píldoras 3D (sin archivos)', 'wakoo' ),
				'video'    => __( 'Vídeo MP4 / WebM', 'wakoo' ),
				'sequence' => __( 'Secuencia de imágenes (la más fluida)', 'wakoo' ),
				'image'    => __( 'Una imagen (flota y gira con el ratón)', 'wakoo' ),
			],
		] );
		$this->add_control( 'video', [
			'label'       => __( 'Vídeo', 'wakoo' ),
			'type'        => Controls_Manager::MEDIA,
			'media_types' => [ 'video' ],
			'condition'   => [ 'source' => 'video' ],
			'description' => __( 'Para que vaya suave al hacer scroll, expórtalo con un fotograma clave en cada fotograma (ffmpeg: -g 1) y sin sonido. Un vídeo generado con IA de un objeto que gira o se monta funciona muy bien.', 'wakoo' ),
		] );
		$this->add_control( 'video_url', [ 'label' => __( 'O dirección del vídeo', 'wakoo' ), 'type' => Controls_Manager::URL, 'condition' => [ 'source' => 'video' ] ] );
		$this->add_control( 'frames', [ 'label' => __( 'Fotogramas (en orden)', 'wakoo' ), 'type' => Controls_Manager::GALLERY, 'condition' => [ 'source' => 'sequence' ], 'description' => __( 'Sube los fotogramas numerados (por ejemplo 60-150 JPG/WebP). Se ordenan por nombre de archivo.', 'wakoo' ) ] );
		$this->add_control( 'image', [ 'label' => __( 'Imagen', 'wakoo' ), 'type' => Controls_Manager::MEDIA, 'condition' => [ 'source' => 'image' ] ] );
		$this->add_control( 'poster', [ 'label' => __( 'Imagen de respaldo', 'wakoo' ), 'type' => Controls_Manager::MEDIA, 'condition' => [ 'source' => [ 'video', 'sequence' ] ], 'description' => __( 'Se ve mientras carga y con «reducir movimiento».', 'wakoo' ) ] );
		$this->add_control( 'demo_color', [ 'label' => __( 'Color de las píldoras', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#2F3BFF', 'condition' => [ 'source' => 'demo' ] ] );
		$this->add_control( 'drive', [
			'label'     => __( 'Se mueve con', 'wakoo' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'scroll',
			'separator' => 'before',
			'options'   => [
				'scroll' => __( 'El scroll (la sección se queda fija)', 'wakoo' ),
				'mouse'  => __( 'El ratón (izquierda → derecha)', 'wakoo' ),
				'loop'   => __( 'Solo, en bucle', 'wakoo' ),
				'hover'  => __( 'Al pasar el ratón', 'wakoo' ),
			],
		] );
		$this->add_control( 'scroll_len', [ 'label' => __( 'Recorrido del scroll (% de pantalla)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 100, 'max' => 1200, 'default' => 300, 'condition' => [ 'drive' => 'scroll' ] ] ); // not "length": Elementor iterates settings with _.each, which treats it as array-like
		$this->add_control( 'smooth', [ 'label' => __( 'Suavizado (0 = directo, 0.95 = muy suave)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 0.97, 'step' => 0.01, 'default' => 0.85 ] );
		$this->add_control( 'reverse', [ 'label' => __( 'Al revés', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ] );
		$this->add_control( 'mobile_auto', [ 'label' => __( 'En el móvil, reproducir solo en bucle', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => '' ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_text', [ 'label' => __( 'Textos', 'wakoo' ) ] );
		$this->add_control( 'layout', [
			'label'   => __( 'Diseño', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'landing',
			'options' => [
				'landing' => __( 'Landing: titular arriba y objeto en el centro', 'wakoo' ),
				'full'    => __( 'Pantalla completa: vídeo de fondo y marca enorme', 'wakoo' ),
				'split'   => __( 'Dividido: texto a la izquierda, objeto a la derecha', 'wakoo' ),
			],
		] );
		$this->add_control( 'eyebrow', [ 'label' => __( 'Antetítulo', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '' ] );
		$this->add_control( 'heading', [ 'label' => __( 'Titular', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'default' => "Your next landing page\ncould look like this", 'rows' => 3 ] );
		$this->add_control( 'heading_tag', [ 'label' => __( 'Etiqueta', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'h1', 'options' => [ 'h1' => 'H1', 'h2' => 'H2', 'div' => 'div' ] ] );
		$this->add_control( 'side', [ 'label' => __( 'Texto lateral', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'default' => 'Learn 3D animations in less than 3 days with our latest course' ] );
		$this->add_control( 'cta', [ 'label' => __( 'Botón', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Join now' ] );
		$this->add_control( 'cta_link', [ 'label' => __( 'Enlace del botón', 'wakoo' ), 'type' => Controls_Manager::URL, 'default' => [ 'url' => '#' ] ] );
		$this->add_control( 'caption', [ 'label' => __( 'Nota pequeña (abajo)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => 'Scroll to explore' ] );
		$this->add_control( 'intro', [ 'label' => __( 'Animar el titular al cargar', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$l = new Repeater();
		$l->add_control( 'text', [ 'label' => __( 'Texto', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'default' => __( 'Texto que aparece durante el scroll', 'wakoo' ) ] );
		$l->add_control( 'from', [ 'label' => __( 'Aparece en (%)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 100, 'default' => 30 ] );
		$l->add_control( 'to', [ 'label' => __( 'Se va en (%)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 100, 'default' => 60 ] );
		$l->add_control( 'pos', [ 'label' => __( 'Posición', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'left', 'options' => [ 'left' => __( 'Izquierda', 'wakoo' ), 'right' => __( 'Derecha', 'wakoo' ), 'center' => __( 'Centro', 'wakoo' ), 'bottom' => __( 'Abajo', 'wakoo' ) ] ] );
		$this->add_control( 'layers', [
			'label'       => __( 'Textos durante el scroll', 'wakoo' ),
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $l->get_controls(),
			'title_field' => '{{{ from }}}–{{{ to }}}%: {{{ text }}}',
			'default'     => [
				[ 'text' => 'Soft. Light. Stacked.', 'from' => 20, 'to' => 50, 'pos' => 'left' ],
				[ 'text' => 'Built to hold its shape.', 'from' => 55, 'to' => 85, 'pos' => 'right' ],
			],
			'condition'   => [ 'drive' => 'scroll' ],
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'st_box', [ 'label' => __( 'Sección', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->var_color( 'bg', __( 'Fondo', 'wakoo' ), '--sv-bg', '' );
		$this->var_color( 'fg', __( 'Texto', 'wakoo' ), '--sv-fg', '' );
		$this->var_color( 'ac', __( 'Acento (botón)', 'wakoo' ), '--sv-ac', '' );
		$this->add_responsive_control( 'media_w', [
			'label'      => __( 'Tamaño del objeto', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ '%', 'px', 'vw' ],
			'range'      => [ '%' => [ 'min' => 10, 'max' => 100 ], 'px' => [ 'min' => 100, 'max' => 1600 ] ],
			'selectors'  => [ '{{WRAPPER}} .wk-ui-sv__media' => '--sv-mw: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'fit', [ 'label' => __( 'Ajuste', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'contain', 'options' => [ 'contain' => __( 'Entero', 'wakoo' ), 'cover' => __( 'Llenar', 'wakoo' ) ] ] );
		$this->add_control( 'blend', [ 'label' => __( 'Mezcla del vídeo con el fondo', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'normal', 'options' => [ 'normal' => __( 'Normal', 'wakoo' ), 'multiply' => __( 'Multiplicar (quita fondos blancos)', 'wakoo' ), 'screen' => __( 'Trama (quita fondos negros)', 'wakoo' ) ], 'selectors' => [ '{{WRAPPER}} .wk-ui-sv__media' => 'mix-blend-mode: {{VALUE}};' ] ] );
		$this->add_control( 'overlay', [ 'label' => __( 'Oscurecer el vídeo (pantalla completa)', 'wakoo' ), 'type' => Controls_Manager::SLIDER, 'range' => [ 'px' => [ 'min' => 0, 'max' => 0.9, 'step' => 0.05 ] ], 'default' => [ 'size' => 0.1 ], 'selectors' => [ '{{WRAPPER}} .wk-ui-sv' => '--sv-ov: {{SIZE}};' ], 'condition' => [ 'layout' => 'full' ] ] );
		$this->add_control( 'progress', [ 'label' => __( 'Barra de progreso', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'condition' => [ 'drive' => 'scroll' ] ] );
		$this->typo( 't_head', __( 'Titular', 'wakoo' ), '.wk-ui-sv__title' );
		$this->typo( 't_side', __( 'Texto lateral', 'wakoo' ), '.wk-ui-sv__side p' );
		$this->typo( 't_layer', __( 'Textos durante el scroll', 'wakoo' ), '.wk-ui-sv__layer' );
		$this->end_controls_section();
	}

	protected function render() {
		$s      = $this->get_settings_for_display();
		$source = $s['source'] ?? 'demo';
		$frames = [];
		if ( 'sequence' === $source && ! empty( $s['frames'] ) ) {
			$list = $s['frames'];
			usort( $list, function ( $a, $b ) {
				return strnatcasecmp( basename( (string) ( $a['url'] ?? '' ) ), basename( (string) ( $b['url'] ?? '' ) ) );
			} );
			foreach ( $list as $f ) {
				if ( ! empty( $f['url'] ) ) { $frames[] = esc_url_raw( $f['url'] ); }
			}
		}
		$video = 'video' === $source ? ( ! empty( $s['video']['url'] ) ? $s['video']['url'] : ( $s['video_url']['url'] ?? '' ) ) : '';
		$cfg   = [
			'source' => $source,
			'drive'  => $s['drive'] ?? 'scroll',
			'len'    => max( 100, (int) ( $s['scroll_len'] ?? 300 ) ),
			'smooth' => (float) ( $s['smooth'] ?? .85 ),
			'rev'    => 'yes' === ( $s['reverse'] ?? '' ),
			'mauto'  => 'yes' === ( $s['mobile_auto'] ?? '' ),
			'fit'    => $s['fit'] ?? 'contain',
			'frames' => $frames,
			'color'  => $s['demo_color'] ?? '#2F3BFF',
		];
		$layout = $s['layout'] ?? 'landing';
		$cls    = 'wk-ui wk-ui-sv wk-ui-sv--' . $layout . ' wk-ui-sv--' . $cfg['drive'] . ( 'yes' === ( $s['intro'] ?? '' ) ? ' has-intro' : '' );
		$h      = 'scroll' === $cfg['drive'] ? ' style="height:' . (int) $cfg['len'] . 'vh"' : '';
		$tag    = in_array( $s['heading_tag'] ?? 'h1', [ 'h1', 'h2', 'div' ], true ) ? $s['heading_tag'] : 'h1';

		echo '<section class="' . esc_attr( $cls ) . '" data-cfg="' . esc_attr( wp_json_encode( $cfg ) ) . '"' . $h . '>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<div class="wk-ui-sv__pin">';
		echo '<div class="wk-ui-sv__media">';
		$poster = $s['poster']['url'] ?? '';
		if ( 'video' === $source && $video ) {
			echo '<video class="wk-ui-sv__video" src="' . esc_url( $video ) . '" muted playsinline preload="auto"' . ( $poster ? ' poster="' . esc_url( $poster ) . '"' : '' ) . ( 'loop' === $cfg['drive'] ? ' autoplay loop' : '' ) . ' style="object-fit:' . esc_attr( $cfg['fit'] ) . '"></video>';
		} elseif ( 'image' === $source && ! empty( $s['image']['url'] ) ) {
			echo '<img class="wk-ui-sv__img" src="' . esc_url( $s['image']['url'] ) . '" alt="" style="object-fit:' . esc_attr( $cfg['fit'] ) . '">';
		} else {
			echo '<canvas class="wk-ui-sv__canvas"' . ( $poster ? ' style="background:url(' . esc_url( $poster ) . ') center/' . esc_attr( $cfg['fit'] ) . ' no-repeat"' : '' ) . '></canvas>';
		}
		echo '</div>';

		echo '<div class="wk-ui-sv__copy">';
		if ( ! empty( $s['eyebrow'] ) ) {
			echo '<p class="wk-ui-sv__eyebrow">' . esc_html( $s['eyebrow'] ) . '</p>';
		}
		if ( '' !== trim( (string) $s['heading'] ) ) {
			echo '<' . $tag . ' class="wk-ui-sv__title">'; // phpcs:ignore WordPress.Security.EscapeOutput
			foreach ( preg_split( '/\R/', trim( (string) $s['heading'] ) ) as $li => $line ) {
				echo '<span class="wk-ui-sv__line" style="--l:' . (int) $li . '"><span>' . esc_html( $line ) . '</span></span>';
			}
			echo '</' . $tag . '>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div>';

		if ( ! empty( $s['side'] ) || ! empty( $s['cta'] ) ) {
			echo '<div class="wk-ui-sv__side">';
			if ( ! empty( $s['side'] ) ) {
				echo '<p>' . esc_html( $s['side'] ) . '</p>';
			}
			if ( ! empty( $s['cta'] ) ) {
				$url = $s['cta_link']['url'] ?? '#';
				echo '<a class="wk-ui-sv__cta" href="' . esc_url( $url ? $url : '#' ) . '"><span class="wk-ui-sv__dot"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14m-6-6 6 6-6 6"/></svg></span>' . esc_html( $s['cta'] ) . '</a>';
			}
			echo '</div>';
		}
		if ( ! empty( $s['caption'] ) ) {
			echo '<p class="wk-ui-sv__caption">' . esc_html( $s['caption'] ) . '</p>';
		}
		foreach ( (array) ( $s['layers'] ?? [] ) as $ly ) {
			echo '<p class="wk-ui-sv__layer wk-ui-sv__layer--' . esc_attr( $ly['pos'] ?? 'left' ) . '" data-from="' . (float) $ly['from'] . '" data-to="' . (float) $ly['to'] . '">' . nl2br( esc_html( $ly['text'] ) ) . '</p>';
		}
		if ( 'scroll' === $cfg['drive'] && 'yes' === ( $s['progress'] ?? '' ) ) {
			echo '<span class="wk-ui-sv__bar" aria-hidden="true"><i></i></span>';
		}
		echo '</div></section>';
	}
}
