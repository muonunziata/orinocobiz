/* Wakoo Interfaz · Dashboard V18 */
( function () {
	'use strict';
	var ui = window.wakooUi;

	ui.define( '.wk-ui-db', function ( root ) {
		var cfg = ui.cfg( root ), reduced = ui.reduced();
		var navs = root.querySelectorAll( '.wk-ui-db__nav[data-view]' ), views = root.querySelectorAll( '.wk-ui-db__view' );
		var tip = root.querySelector( '.wk-ui-db__tip' ), rail = root.querySelector( '.wk-ui-db__rail' );
		var busy = false;

		// stagger index for every card of a view
		function stagger( view ) {
			view.querySelectorAll( '.wk-ui-db__head, .wk-ui-db__card' ).forEach( function ( c, i ) { c.style.setProperty( '--k', Math.min( i, 14 ) ); } );
		}
		function reveal( view ) {
			stagger( view );
			view.classList.add( 'is-pre' );
			view.offsetWidth; // eslint-disable-line no-unused-expressions
			view.classList.remove( 'is-pre' );
		}
		views.forEach( stagger );

		if ( ! reduced && ! ui.inEditor() ) {
			root.classList.add( 'is-intro' );
			var cur0 = root.querySelector( '.wk-ui-db__view.is-current' );
			if ( cur0 ) { cur0.classList.add( 'is-pre' ); }
			requestAnimationFrame( function () { setTimeout( function () { if ( cur0 ) { cur0.classList.remove( 'is-pre' ); } }, 260 ); } );
			setTimeout( function () { root.classList.remove( 'is-intro' ); }, 900 );
		}

		function show( slug, push ) {
			var next = root.querySelector( '.wk-ui-db__view[data-view="' + slug + '"]' );
			var cur = root.querySelector( '.wk-ui-db__view.is-current' );
			if ( ! next || next === cur || busy ) { return; }
			navs.forEach( function ( n ) { n.classList.toggle( 'is-active', n.getAttribute( 'data-view' ) === slug ); } );
			if ( push && cfg.hash && history.replaceState ) { history.replaceState( null, '', '#' + slug ); }
			var swap = function () {
				if ( cur ) { cur.classList.remove( 'is-current', 'is-out' ); cur.hidden = true; }
				next.hidden = false; next.classList.add( 'is-current' );
			};
			if ( reduced ) { swap(); return; }
			busy = true;
			if ( cur ) { cur.classList.add( 'is-out' ); }
			setTimeout( function () {
				root.classList.add( 'is-loading' );
				if ( cur ) { cur.style.visibility = 'hidden'; }
				setTimeout( function () {
					if ( cur ) { cur.style.visibility = ''; }
					swap();
					root.classList.remove( 'is-loading' );
					reveal( next );
					busy = false;
				}, 320 );
			}, 220 );
		}
		navs.forEach( function ( n ) {
			n.addEventListener( 'click', function ( e ) { e.preventDefault(); show( n.getAttribute( 'data-view' ), true ); } );
		} );
		if ( cfg.hash && location.hash ) {
			var h = decodeURIComponent( location.hash.slice( 1 ) );
			if ( root.querySelector( '.wk-ui-db__view[data-view="' + h + '"]' ) ) { reduced = true; show( h ); reduced = ui.reduced(); }
		}

		// rail tooltips
		if ( tip && rail ) {
			rail.querySelectorAll( '.wk-ui-db__nav[data-tip]' ).forEach( function ( n ) {
				var on = function () {
					tip.textContent = n.getAttribute( 'data-tip' );
					tip.style.top = ( n.offsetTop + n.offsetHeight / 2 - 11 ) + 'px';
					tip.classList.add( 'is-on' );
				};
				var off = function () { tip.classList.remove( 'is-on' ); };
				n.addEventListener( 'pointerenter', on ); n.addEventListener( 'focus', on );
				n.addEventListener( 'pointerleave', off ); n.addEventListener( 'blur', off );
			} );
		}

		// week calendar
		var week = root.querySelector( '.wk-ui-db__week' );
		if ( week ) {
			var lang = document.documentElement.lang || 'es';
			var today = new Date( ( week.getAttribute( 'data-today' ) || '' ) + 'T12:00:00' );
			if ( isNaN( today ) ) { today = new Date(); }
			var month = root.querySelector( '.wk-ui-db__month' ), offset = 0;
			var fmtD, fmtM;
			try { fmtD = new Intl.DateTimeFormat( lang, { weekday: 'short' } ); fmtM = new Intl.DateTimeFormat( lang, { month: 'long', year: 'numeric' } ); } catch ( e ) { fmtD = fmtM = null; }
			var paint = function () {
				var start = new Date( today );
				start.setDate( today.getDate() - ( ( today.getDay() + 6 ) % 7 ) + offset * 7 );
				var html = '';
				for ( var i = 0; i < 7; i++ ) {
					var d = new Date( start ); d.setDate( start.getDate() + i );
					var isT = d.toDateString() === today.toDateString();
					html += '<span' + ( isT ? ' class="is-today"' : '' ) + '><small>' + ( fmtD ? fmtD.format( d ).replace( '.', '' ) : '' ) + '</small>' + d.getDate() + '</span>';
				}
				week.innerHTML = html;
				if ( month && fmtM ) {
					var t = month.firstChild;
					if ( t && 3 === t.nodeType ) { var m = fmtM.format( new Date( start.getTime() + 3 * 864e5 ) ); t.nodeValue = m.charAt( 0 ).toUpperCase() + m.slice( 1 ).replace( ' de ', ', ' ); }
				}
				if ( ! reduced && week.animate ) { week.animate( [ { opacity: 0, transform: 'translateX(' + ( paint.dir * 12 ) + 'px)' }, { opacity: 1, transform: 'none' } ], { duration: 260, easing: 'ease-out' } ); }
			};
			paint.dir = 0;
			root.querySelectorAll( '[data-cal]' ).forEach( function ( b ) {
				b.addEventListener( 'click', function () { paint.dir = parseInt( b.getAttribute( 'data-cal' ), 10 ); offset += paint.dir; paint(); } );
			} );
			paint();
		}

		// saved filters
		root.querySelectorAll( '.wk-ui-db__filters' ).forEach( function ( bar ) {
			var chips = bar.querySelectorAll( '[data-f]' );
			if ( ! chips.length ) { return; }
			var items = bar.closest( '.wk-ui-db__view' ).querySelectorAll( '.wk-ui-db__item' );
			chips.forEach( function ( c ) {
				c.setAttribute( 'role', 'button' ); c.tabIndex = 0;
				var pick = function () {
					var f = c.getAttribute( 'data-f' );
					chips.forEach( function ( o ) { o.classList.toggle( 'is-on', o === c ); o.classList.toggle( 'is-off', o !== c ); } );
					items.forEach( function ( it, i ) {
						var hide = 'all' !== f && it.getAttribute( 'data-type' ) !== f;
						it.classList.toggle( 'is-hidden', hide );
						if ( ! hide && ! reduced && it.animate ) { it.animate( [ { opacity: 0, filter: 'blur(6px)', transform: 'scale(.96)' }, { opacity: 1, filter: 'blur(0)', transform: 'none' } ], { duration: 320, delay: i * 30, easing: 'ease-out', fill: 'backwards' } ); }
					} );
				};
				c.addEventListener( 'click', pick );
				c.addEventListener( 'keydown', function ( e ) { if ( 'Enter' === e.key || ' ' === e.key ) { e.preventDefault(); pick(); } } );
			} );
		} );

		// segmented weekly/monthly toggle
		root.querySelectorAll( '.wk-ui-db__seg' ).forEach( function ( seg ) {
			seg.addEventListener( 'click', function ( e ) {
				var t = e.target.closest( 'b, span' );
				if ( ! t || t === seg ) { return; }
				seg.querySelectorAll( 'b, span' ).forEach( function ( o ) { o.classList.toggle( 'is-off', o !== t ); o.classList.toggle( 'is-on', o === t ); } );
			} );
		} );
	} );
}() );
