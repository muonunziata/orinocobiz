/* Wakoo Interfaz · Barra lateral animada */
( function () {
	'use strict';
	var ui = window.wakooUi;

	ui.define( '.wk-ui-sb', function ( root ) {
		var cfg = ui.cfg( root );
		var panel = root.querySelector( '.wk-ui-sb__panel' );
		var actions = root.querySelector( '.wk-ui-sb__actions' );
		var coarse = window.matchMedia && window.matchMedia( '(hover: none)' ).matches;
		var closeTimer;

		/* FLIP the bottom buttons when they switch between column and row. */
		function setOpen( open ) {
			if ( 'open' === cfg.mode ) { open = true; }
			if ( 'closed' === cfg.mode ) { open = false; }
			if ( open === root.classList.contains( 'is-open' ) ) { return; }
			var btns = actions ? Array.prototype.slice.call( actions.children ) : [];
			var first = btns.map( function ( b ) { return b.getBoundingClientRect(); } );
			root.classList.toggle( 'is-open', open );
			var tg = root.querySelector( '.wk-ui-sb__toggle' );
			if ( tg ) { tg.setAttribute( 'aria-expanded', open ? 'true' : 'false' ); }
			if ( ui.reduced() || ! btns.length || ! btns[ 0 ].animate ) { return; }
			btns.forEach( function ( b, i ) {
				var last = b.getBoundingClientRect();
				var dx = first[ i ].left - last.left, dy = first[ i ].top - last.top;
				if ( dx || dy ) {
					b.animate( [ { transform: 'translate(' + dx + 'px,' + dy + 'px)' }, { transform: 'none' } ], { duration: 350, easing: 'ease', delay: i * 15 } );
				}
			} );
		}

		if ( 'hover' === cfg.mode && ! coarse ) {
			panel.addEventListener( 'pointerenter', function () { clearTimeout( closeTimer ); setOpen( true ); } );
			panel.addEventListener( 'pointerleave', function () { closeTimer = setTimeout( function () { if ( ! panel.contains( document.activeElement ) ) { setOpen( false ); } }, 60 ); } );
			panel.addEventListener( 'focusin', function () { setOpen( true ); } );
			panel.addEventListener( 'focusout', function () { setTimeout( function () { if ( ! panel.contains( document.activeElement ) && ! panel.matches( ':hover' ) ) { setOpen( false ); } }, 0 ); } );
		}
		if ( 'hover' === cfg.mode && coarse ) {
			// Touch: the first tap opens the panel, links work once it is open.
			panel.addEventListener( 'click', function ( e ) {
				if ( ! root.classList.contains( 'is-open' ) ) { e.preventDefault(); setOpen( true ); }
			}, true );
			document.addEventListener( 'click', function ( e ) { if ( ! root.contains( e.target ) ) { setOpen( false ); } } );
		}
		if ( 'click' === cfg.mode ) {
			var saved = null;
			try { saved = cfg.remember ? localStorage.getItem( cfg.key ) : null; } catch ( e ) {}
			if ( '1' === saved ) { root.classList.add( 'is-open' ); }
			var tg = root.querySelector( '.wk-ui-sb__toggle' );
			if ( tg ) {
				tg.addEventListener( 'click', function () {
					var open = ! root.classList.contains( 'is-open' );
					setOpen( open );
					try { if ( cfg.remember ) { localStorage.setItem( cfg.key, open ? '1' : '0' ); } } catch ( e ) {}
				} );
			}
		}

		/* Search: a click on the closed magnifier opens the bar and focuses the field. */
		var form = root.querySelector( '.wk-ui-sb__search' );
		if ( form ) {
			var input = form.querySelector( 'input' );
			form.addEventListener( 'click', function () {
				if ( ! root.classList.contains( 'is-open' ) ) { setOpen( true ); setTimeout( function () { input.focus(); }, 200 ); }
			} );
			if ( 'filter' === cfg.search ) {
				form.addEventListener( 'submit', function ( e ) { e.preventDefault(); } );
				input.addEventListener( 'input', function () {
					var q = input.value.trim().toLowerCase();
					root.querySelectorAll( '.wk-ui-sb__item' ).forEach( function ( it ) {
						it.style.display = ! q || it.textContent.toLowerCase().indexOf( q ) > -1 ? '' : 'none';
					} );
					root.querySelectorAll( '.wk-ui-sb__sep, .wk-ui-sb__group' ).forEach( function ( x ) { x.style.display = q ? 'none' : ''; } );
				} );
			}
		}

		/* Active item: current URL, then clicks on "#" items. */
		var items = root.querySelectorAll( '.wk-ui-sb__item' );
		if ( cfg.auto ) {
			var here = location.href.split( '#' )[ 0 ].replace( /\/$/, '' );
			items.forEach( function ( it ) {
				var h = ( it.getAttribute( 'href' ) || '' ).split( '#' )[ 0 ].replace( /\/$/, '' );
				if ( h && h === here ) { items.forEach( function ( x ) { x.classList.remove( 'is-active' ); } ); it.classList.add( 'is-active' ); }
			} );
		}
		items.forEach( function ( it ) {
			it.addEventListener( 'click', function ( e ) {
				if ( '#' === it.getAttribute( 'href' ) ) { e.preventDefault(); }
				items.forEach( function ( x ) { x.classList.remove( 'is-active' ); } );
				it.classList.add( 'is-active' );
			} );
		} );

		/* Light / dark. */
		var th = root.querySelector( '.wk-ui-sb__theme' );
		var tkey = 'page' === cfg.scope ? 'wakoo_dark' : cfg.key + '_dark';
		function applyDark( on ) {
			root.classList.toggle( 'is-dark', on );
			if ( 'page' === cfg.scope ) {
				document.body.classList.toggle( 'wakoo-dark', on );
				document.querySelectorAll( '.wk-ui-sb' ).forEach( function ( o ) { o.classList.toggle( 'is-dark', on ); } );
			}
		}
		try {
			var st = localStorage.getItem( tkey );
			if ( null !== st ) { applyDark( '1' === st ); }
		} catch ( e ) {}
		if ( th ) {
			th.addEventListener( 'click', function () {
				var on = ! root.classList.contains( 'is-dark' );
				applyDark( on );
				try { localStorage.setItem( tkey, on ? '1' : '0' ); } catch ( e ) {}
			} );
		}

		/* Tooltips while closed. */
		if ( root.classList.contains( 'wk-ui-sb--tips' ) ) {
			var tip = document.createElement( 'div' );
			tip.className = 'wk-ui-sb__tip';
			root.appendChild( tip );
			root.querySelectorAll( '[data-tip]' ).forEach( function ( el ) {
				el.addEventListener( 'pointerenter', function () {
					if ( root.classList.contains( 'is-open' ) ) { return; }
					tip.textContent = el.getAttribute( 'data-tip' );
					var r = el.getBoundingClientRect(), rr = root.getBoundingClientRect();
					tip.style.top = ( r.top - rr.top + r.height / 2 - 13 ) + 'px';
					tip.classList.add( 'is-on' );
				} );
				el.addEventListener( 'pointerleave', function () { tip.classList.remove( 'is-on' ); } );
			} );
		}
	} );
}() );
