/* Wakoo Interfaz · Hero con vídeo al hacer scroll */
( function () {
	'use strict';
	var ui = window.wakooUi;
	function clamp( x, a, b ) { return Math.max( a, Math.min( b, x ) ); }

	/* Built-in demo: inflatable pills that drop in and stack while you scroll. */
	function pills( canvas, color ) {
		var ctx = canvas.getContext( '2d' ), N = 5;
		function shade( hex, amt ) {
			var n = parseInt( hex.replace( '#', '' ), 16 ), r = n >> 16, g = ( n >> 8 ) & 255, b = n & 255;
			var f = function ( c ) { return Math.round( clamp( amt > 0 ? c + ( 255 - c ) * amt : c * ( 1 + amt ), 0, 255 ) ); };
			return 'rgb(' + f( r ) + ',' + f( g ) + ',' + f( b ) + ')';
		}
		function pill( x, y, w, h, base, squash ) {
			var hh = h * ( 1 - squash * 0.25 ), ww = w * ( 1 + squash * 0.06 );
			var r = hh / 2;
			var g = ctx.createLinearGradient( 0, y - hh / 2, 0, y + hh / 2 );
			g.addColorStop( 0, shade( base, .45 ) ); g.addColorStop( .28, shade( base, .08 ) ); g.addColorStop( .7, base ); g.addColorStop( 1, shade( base, -.45 ) );
			ctx.beginPath();
			ctx.moveTo( x - ww / 2 + r, y - hh / 2 ); ctx.lineTo( x + ww / 2 - r, y - hh / 2 );
			ctx.arc( x + ww / 2 - r, y, r, -Math.PI / 2, Math.PI / 2 ); ctx.lineTo( x - ww / 2 + r, y + hh / 2 );
			ctx.arc( x - ww / 2 + r, y, r, Math.PI / 2, Math.PI * 1.5 ); ctx.closePath();
			ctx.fillStyle = g; ctx.fill();
			// glossy highlight
			ctx.save(); ctx.clip();
			var hl = ctx.createLinearGradient( 0, y - hh / 2, 0, y );
			hl.addColorStop( 0, 'rgba(255,255,255,.75)' ); hl.addColorStop( 1, 'rgba(255,255,255,0)' );
			ctx.fillStyle = hl; ctx.beginPath();
			ctx.ellipse( x - ww * .08, y - hh * .22, ww * .36, hh * .16, 0, 0, Math.PI * 2 ); ctx.fill();
			ctx.restore();
		}
		return function ( t ) {
			var dpr = Math.min( 2, window.devicePixelRatio || 1 ), W = canvas.clientWidth, H = canvas.clientHeight;
			if ( canvas.width !== Math.round( W * dpr ) ) { canvas.width = Math.round( W * dpr ); canvas.height = Math.round( H * dpr ); }
			ctx.setTransform( dpr, 0, 0, dpr, 0, 0 ); ctx.clearRect( 0, 0, W, H );
			var pw = W * .62, ph = Math.min( H * .16, pw * .26 ), cx = W / 2, base = H * .86, step = ph * .78;
			// shadow
			ctx.fillStyle = 'rgba(0,0,0,.12)'; ctx.beginPath(); ctx.ellipse( cx, base + ph * .42, pw * .48, ph * .16, 0, 0, Math.PI * 2 ); ctx.fill();
			for ( var i = 0; i < N; i++ ) {
				var u = clamp( t * ( N + 0.6 ) - i * 0.92, 0, 1 );
				if ( u <= 0 ) { continue; }
				var target = base - i * step, start = -ph;
				var e = 1 - Math.pow( 1 - u, 3 );
				var y = start + ( target - start ) * e;
				var squash = u > .85 ? Math.sin( ( u - .85 ) / .15 * Math.PI ) * .9 : 0;
				pill( cx + Math.sin( ( 1 - u ) * 3 + i ) * W * .03 * ( 1 - u ), y, pw * ( 1 - i * .015 ), ph, i === N - 1 ? '#f3f4f8' : color, squash );
			}
		};
	}

	ui.define( '.wk-ui-sv', function ( root ) {
		var cfg = ui.cfg( root );
		var video = root.querySelector( 'video' ), canvas = root.querySelector( 'canvas' ), img = root.querySelector( '.wk-ui-sv__img' );
		var bar = root.querySelector( '.wk-ui-sv__bar' ), layers = root.querySelectorAll( '.wk-ui-sv__layer' );
		var reduced = ui.reduced();
		var mobile = window.matchMedia && window.matchMedia( '(max-width: 767px)' ).matches;
		var drive = cfg.drive;
		if ( mobile && cfg.mauto ) { drive = 'loop'; root.style.height = ''; root.classList.remove( 'wk-ui-sv--scroll' ); root.classList.add( 'wk-ui-sv--loop' ); }

		requestAnimationFrame( function () { root.classList.add( 'is-in' ); } );

		/* renderer: draw(progress 0..1) */
		var draw = function () {};
		if ( 'demo' === cfg.source && canvas ) {
			draw = pills( canvas, cfg.color || '#2f3bff' );
		} else if ( 'sequence' === cfg.source && canvas && cfg.frames && cfg.frames.length ) {
			var frames = cfg.frames.map( function ( src, i ) {
				var im = new Image(); im.decoding = 'async';
				if ( i < 3 ) { im.src = src; } else { setTimeout( function () { im.src = src; }, 30 + i * 8 ); }
				return im;
			} );
			var ctx = canvas.getContext( '2d' ), lastIdx = -1;
			draw = function ( t ) {
				var idx = Math.round( t * ( frames.length - 1 ) ), im = frames[ idx ];
				// nearest loaded frame
				for ( var k = 0; ( ! im.complete || ! im.naturalWidth ) && k < frames.length; k++ ) { im = frames[ clamp( idx - k, 0, frames.length - 1 ) ]; }
				if ( ! im.complete || ! im.naturalWidth || ( idx === lastIdx && canvas.width ) ) { return; }
				lastIdx = idx;
				var dpr = Math.min( 2, window.devicePixelRatio || 1 ), W = canvas.clientWidth, H = canvas.clientHeight;
				if ( canvas.width !== Math.round( W * dpr ) ) { canvas.width = Math.round( W * dpr ); canvas.height = Math.round( H * dpr ); }
				ctx.setTransform( dpr, 0, 0, dpr, 0, 0 ); ctx.clearRect( 0, 0, W, H );
				var s = ( 'cover' === cfg.fit ? Math.max : Math.min )( W / im.naturalWidth, H / im.naturalHeight );
				var w = im.naturalWidth * s, h = im.naturalHeight * s;
				ctx.drawImage( im, ( W - w ) / 2, ( H - h ) / 2, w, h );
				canvas.style.background = 'none';
			};
		} else if ( video ) {
			video.muted = true;
			draw = function ( t ) {
				if ( ! video.duration || 'loop' === drive ) { return; }
				var target = t * ( video.duration - 0.05 );
				if ( Math.abs( video.currentTime - target ) > 0.02 && ! video.seeking ) { video.currentTime = target; }
			};
			// iOS needs a play/pause before seeking works.
			video.addEventListener( 'loadedmetadata', function () { if ( 'loop' !== drive ) { var pr = video.play(); if ( pr && pr.then ) { pr.then( function () { video.pause(); } ).catch( function () {} ); } } } );
		} else if ( img ) {
			draw = function ( t, mx, my ) {
				img.style.transform = 'translate3d(' + ( ( mx || 0 ) * 14 ) + 'px,' + ( Math.sin( t * Math.PI * 2 ) * 10 + ( my || 0 ) * 10 ) + 'px,0) rotate(' + ( ( mx || 0 ) * 4 ) + 'deg) scale(' + ( 1 + t * .08 ) + ')';
			};
		}

		var target = 0, cur = 0, mx = 0, my = 0, raf = 0;
		function apply( p ) {
			var t = cfg.rev ? 1 - p : p;
			draw( t, mx, my );
			if ( bar ) { bar.style.setProperty( '--p', p ); }
			layers.forEach( function ( ly ) {
				var a = parseFloat( ly.getAttribute( 'data-from' ) ) / 100, b = parseFloat( ly.getAttribute( 'data-to' ) ) / 100, edge = .06;
				var o = clamp( Math.min( ( p - a ) / edge, ( b - p ) / edge ), 0, 1 );
				ly.style.opacity = o; ly.style.transform = 'translateY(' + ( ( 1 - o ) * 24 * ( p < a + edge ? 1 : -1 ) ) + 'px)';
			} );
		}
		function tick() {
			var k = reduced ? 1 : 1 - clamp( cfg.smooth, 0, .97 );
			cur += ( target - cur ) * k;
			if ( Math.abs( target - cur ) < 0.0005 ) { cur = target; }
			apply( cur );
			raf = cur !== target ? requestAnimationFrame( tick ) : 0;
		}
		function want( p ) { target = clamp( p, 0, 1 ); if ( ! raf ) { raf = requestAnimationFrame( tick ); } }

		if ( reduced ) { apply( 'demo' === cfg.source ? 1 : 0 ); return; }

		if ( 'scroll' === drive ) {
			var onScroll = function () {
				var r = root.getBoundingClientRect(), span = root.offsetHeight - window.innerHeight;
				want( span > 0 ? -r.top / span : 0 );
			};
			window.addEventListener( 'scroll', onScroll, { passive: true } );
			window.addEventListener( 'resize', onScroll );
			onScroll();
		} else if ( 'mouse' === drive ) {
			root.addEventListener( 'pointermove', function ( e ) {
				var r = root.getBoundingClientRect();
				mx = ( e.clientX - r.left ) / r.width * 2 - 1; my = ( e.clientY - r.top ) / r.height * 2 - 1;
				want( ( mx + 1 ) / 2 );
			} );
			want( 'demo' === cfg.source ? 1 : 0.5 );
		} else if ( 'hover' === drive ) {
			var dir = 0, hv = 0, last = 0;
			var step = function ( now ) {
				var dt = Math.min( .05, ( now - ( last || now ) ) / 1000 ); last = now;
				hv = clamp( hv + dir * dt / 2.2, 0, 1 ); apply( hv );
				if ( ( dir > 0 && hv < 1 ) || ( dir < 0 && hv > 0 ) ) { requestAnimationFrame( step ); } else { last = 0; }
			};
			root.addEventListener( 'pointerenter', function () { dir = 1; if ( video && video.duration ) { video.play(); return; } requestAnimationFrame( step ); } );
			root.addEventListener( 'pointerleave', function () { dir = -1; if ( video && video.duration ) { video.pause(); return; } requestAnimationFrame( step ); } );
			apply( 0 );
		} else {
			// loop
			if ( video ) { video.loop = true; var pl = video.play(); if ( pl && pl.catch ) { pl.catch( function () {} ); } }
			else {
				var t0 = performance.now(), period = 'demo' === cfg.source ? 5200 : Math.max( 1500, ( cfg.frames || [] ).length * 42 );
				( function loop( now ) {
					var u = ( ( now - t0 ) % period ) / period;
					apply( 'demo' === cfg.source ? Math.min( 1, u * 1.35 ) : u );
					requestAnimationFrame( loop );
				}( t0 ) );
			}
		}
	} );
}() );
