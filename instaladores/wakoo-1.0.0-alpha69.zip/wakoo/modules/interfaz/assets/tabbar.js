/* Wakoo Interfaz · Barra de pestañas animada */
( function () {
	'use strict';
	var ui = window.wakooUi;

	ui.define( '.wk-ui-tb', function ( root ) {
		var cfg = ui.cfg( root );
		var items = Array.prototype.slice.call( root.querySelectorAll( '.wk-ui-tb__item' ) );
		var ind = root.querySelector( '.wk-ui-tb__ind' );
		var drop = root.querySelector( '.wk-ui-tb__drop' );
		var bubble = root.querySelector( '.wk-ui-tb__bubble' );
		var cur = Math.max( 0, items.findIndex( function ( it ) { return it.classList.contains( 'is-active' ); } ) );
		var h = function () { return root.querySelector( '.wk-ui-tb__bar' ).offsetHeight; };

		function paintLiquid( i ) {
			var c = items[ i ] && items[ i ].style.getPropertyValue( '--c' );
			if ( c ) { root.style.setProperty( '--_cur', c ); }
			root.classList.toggle( 'is-tinted', !! cfg.tint );
			if ( bubble ) {
				var ic = items[ i ].querySelector( '.wk-ui-tb__icon' );
				bubble.innerHTML = ic ? ic.innerHTML : '';
			}
		}

		function select( i, animate ) {
			if ( i === cur || ! items[ i ] ) { return; }
			var from = cur;
			cur = i;
			items.forEach( function ( it, k ) {
				it.classList.toggle( 'is-active', k === i );
				if ( k === i ) { it.setAttribute( 'aria-current', 'page' ); } else { it.removeAttribute( 'aria-current' ); }
			} );
			root.style.setProperty( '--i', i );
			var still = ui.reduced() || ! animate;
			var dur = parseFloat( getComputedStyle( root ).getPropertyValue( '--_dur' ) ) || 0.5;
			if ( dur < 5 ) { dur *= 1000; }

			if ( 'bubble' === cfg.style && ind && ! still && ind.animate ) {
				// Squash and stretch while the bubble travels.
				var dist = Math.abs( i - from );
				ind.animate( [
					{ transform: 'scale(1,1)' },
					{ transform: 'scale(' + ( 1 + Math.min( .5, .18 * dist ) ) + ',.78) translateY(10%)', offset: .45 },
					{ transform: 'scale(.92,1.08)', offset: .8 },
					{ transform: 'scale(1,1)' }
				], { duration: dur, easing: 'ease-in-out' } );
			}
			if ( 'lamp' === cfg.style && ind && ! still && ind.animate ) {
				ind.animate( [ { opacity: 1 }, { opacity: .35, offset: .5 }, { opacity: 1 } ], { duration: dur } );
			}
			if ( 'liquid' === cfg.style ) {
				paintLiquid( i );
				if ( ! still && drop && drop.animate ) {
					var H = h(), up = -H * 1.25;
					// Rise from inside the bar, overshoot upwards (the goo neck stretches and snaps), then settle on the edge.
					var kf = [
						{ transform: 'translateY(' + ( H * .33 ) + 'px) scale(.45)' },
						{ transform: 'translateY(' + up + 'px) scale(1.05)', offset: .45 },
						{ transform: 'translateY(' + ( H * .08 ) + 'px) scale(.95,1.04)', offset: .78 },
						{ transform: 'translateY(0) scale(1)' }
					];
					var opt = { duration: dur * 1.6, easing: 'cubic-bezier(.33,0,.2,1)' };
					drop.animate( kf, opt );
					if ( bubble ) {
						bubble.animate( kf.map( function ( f, k ) { var o = Object.assign( {}, f ); o.opacity = k === 0 ? 0 : 1; return o; } ), opt );
					}
				}
			}
		}

		if ( 'liquid' === cfg.style ) { paintLiquid( cur ); }

		items.forEach( function ( it, i ) {
			it.addEventListener( 'click', function ( e ) {
				var href = it.getAttribute( 'href' ) || '#';
				var anchor = '#' === href.charAt( 0 );
				if ( ui.inEditor() ) { e.preventDefault(); select( i, true ); return; }
				if ( anchor ) {
					if ( '#' === href ) { e.preventDefault(); }
					select( i, true );
					return;
				}
				if ( e.metaKey || e.ctrlKey || e.shiftKey || '_blank' === it.target ) { return; }
				e.preventDefault();
				select( i, true );
				setTimeout( function () { window.location.href = href; }, ui.reduced() ? 0 : 420 );
			} );
		} );

		// Active tab = current page.
		var here = location.href.split( '#' )[ 0 ].replace( /\/$/, '' );
		items.forEach( function ( it, i ) {
			var hr = ( it.getAttribute( 'href' ) || '' );
			if ( hr && '#' !== hr.charAt( 0 ) && hr.split( '#' )[ 0 ].replace( /\/$/, '' ) === here ) { select( i, false ); }
		} );

		// Scroll spy for #anchors.
		if ( cfg.spy && 'IntersectionObserver' in window ) {
			var map = [];
			items.forEach( function ( it, i ) {
				var hr = it.getAttribute( 'href' ) || '';
				if ( hr.length > 1 && '#' === hr.charAt( 0 ) ) {
					var t = document.getElementById( hr.slice( 1 ) );
					if ( t ) { map.push( [ t, i ] ); }
				}
			} );
			var io = new IntersectionObserver( function ( entries ) {
				entries.forEach( function ( en ) {
					if ( en.isIntersecting ) {
						map.forEach( function ( m ) { if ( m[ 0 ] === en.target ) { select( m[ 1 ], true ); } } );
					}
				} );
			}, { rootMargin: '-45% 0px -50% 0px' } );
			map.forEach( function ( m ) { io.observe( m[ 0 ] ); } );
		}
	} );
}() );
