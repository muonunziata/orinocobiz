/* Wakoo Interfaz · Acceso de vidrio V7 */
( function () {
	'use strict';
	var ui = window.wakooUi;

	ui.define( '.wk-ui-ga', function ( root ) {
		var cfg = ui.cfg( root );
		var demo = cfg.demo || root.hasAttribute( 'data-editor' );
		var card = root.querySelector( '.wk-ui-ga__card' );
		var panes = {};
		root.querySelectorAll( '.wk-ui-ga__pane' ).forEach( function ( p ) { panes[ p.getAttribute( 'data-pane' ) ] = p; } );
		var busy = false;

		function stagger( pane ) {
			pane.querySelectorAll( '.wk-ui-ga__anim' ).forEach( function ( el, i ) { el.style.transitionDelay = ( i * 0.04 ) + 's'; } );
		}
		Object.keys( panes ).forEach( function ( k ) { stagger( panes[ k ] ); } );

		function measure( pane ) {
			var was = pane.hidden;
			pane.hidden = false;
			var h = pane.offsetHeight;
			pane.hidden = was;
			var cs = getComputedStyle( card );
			return h + parseFloat( cs.paddingTop ) + parseFloat( cs.paddingBottom );
		}

		function go( name ) {
			var next = panes[ name ], cur = root.querySelector( '.wk-ui-ga__pane.is-current' );
			if ( ! next || next === cur || busy ) { return; }
			busy = true;
			if ( ui.reduced() ) {
				cur.hidden = true; cur.classList.remove( 'is-current' ); next.hidden = false; next.classList.add( 'is-current' ); busy = false;
				focusFirst( next ); return;
			}
			var h0 = card.offsetHeight, h1 = measure( next );
			card.style.height = h0 + 'px';
			cur.querySelectorAll( '.wk-ui-ga__anim' ).forEach( function ( el ) { el.style.transitionDelay = '0s'; } );
			cur.classList.add( 'is-out' );
			setTimeout( function () { root.classList.add( 'is-morph' ); card.style.height = Math.round( ( h0 + h1 ) / 2 ) + 'px'; }, 160 );
			setTimeout( function () { root.classList.add( 'is-flash' ); }, 640 );
			setTimeout( function () {
				cur.hidden = true; cur.classList.remove( 'is-current', 'is-out' ); stagger( cur );
				next.classList.add( 'is-pre' ); next.hidden = false; next.classList.add( 'is-current' );
				card.style.height = h1 + 'px';
				root.classList.remove( 'is-morph' );
				void next.offsetWidth;
				next.classList.remove( 'is-pre' );
			}, 900 );
			setTimeout( function () { root.classList.remove( 'is-flash' ); card.style.height = ''; busy = false; focusFirst( next ); }, 1450 );
		}
		function focusFirst( p ) { var i = p.querySelector( 'input:not([type=checkbox])' ); if ( i ) { i.focus( { preventScroll: true } ); } }

		root.addEventListener( 'click', function ( e ) {
			var a = e.target.closest( '[data-go]' );
			if ( a ) { e.preventDefault(); go( a.getAttribute( 'data-go' ) ); return; }
			var eye = e.target.closest( '.wk-ui-ga__eye' );
			if ( eye ) {
				var inp = eye.parentNode.querySelector( 'input' );
				var show = 'password' === inp.type;
				inp.type = show ? 'text' : 'password';
				eye.classList.toggle( 'is-on', show );
			}
			var soc = e.target.closest( '.wk-ui-ga__soc' );
			if ( soc && '#' === soc.getAttribute( 'href' ) ) { e.preventDefault(); }
		} );

		function say( pane, t, ok ) {
			var m = pane.querySelector( '.wk-ui-ga__msg' );
			if ( m ) { m.textContent = t || ''; m.classList.toggle( 'is-ok', !! ok ); }
		}
		function shake() { root.classList.remove( 'is-shake' ); void root.offsetWidth; root.classList.add( 'is-shake' ); }

		Object.keys( panes ).forEach( function ( name ) {
			var form = panes[ name ];
			form.addEventListener( 'submit', function ( e ) {
				e.preventDefault();
				var btn = form.querySelector( '.wk-ui-ga__btn' );
				if ( btn.classList.contains( 'is-busy' ) ) { return; }
				var bad = Array.prototype.find.call( form.querySelectorAll( 'input[required]' ), function ( i ) { return 'checkbox' === i.type ? ! i.checked : ! i.value.trim(); } );
				if ( bad ) { shake(); say( form, bad.type === 'checkbox' ? bad.closest( 'label' ).textContent : ( form.querySelector( 'label[for="' + bad.id + '"]' ) || {} ).textContent ); bad.focus(); return; }
				var data = {};
				form.querySelectorAll( 'input' ).forEach( function ( i ) { if ( 'checkbox' !== i.type || i.checked ) { data[ i.name ] = i.value; } } );
				btn.classList.add( 'is-busy' ); say( form, '' );
				var req = demo ? ui.wait( 900 ).then( function () { return { success: true, data: {} }; } ) : ui.post( root, 'login' === name ? 'login' : 'register', data );
				req.then( function ( res ) {
					btn.classList.remove( 'is-busy' );
					if ( res && res.success ) {
						say( form, '✓', true );
						var label = btn.querySelector( 'span' ), old = label.textContent;
						label.textContent = '✓';
						if ( ! demo ) { setTimeout( function () { ui.go( res.data && res.data.redirect ); }, 600 ); }
						else { setTimeout( function () { label.textContent = old; say( form, '' ); }, 1600 ); }
					} else {
						say( form, ( res && res.data && res.data.msg ) || 'Error' ); shake();
					}
				} );
			} );
		} );
	} );
}() );
