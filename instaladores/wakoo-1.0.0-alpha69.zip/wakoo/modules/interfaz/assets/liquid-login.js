/* Wakoo Interfaz · Acceso de metal líquido
 * The capsule is two halves driven by two springs: "p" morphs button → fields and "pull" pushes the halves
 * apart. Between them, one SVG path (the mercury neck) is redrawn every frame; it thins as the halves separate,
 * snaps, and its two drops are pulled back into the edges. */
( function () {
	'use strict';
	var ui = window.wakooUi;
	function clamp( x, a, b ) { return Math.max( a, Math.min( b, x ) ); }
	function lerp( a, b, t ) { return a + ( b - a ) * t; }
	function smooth( a, b, x ) { var t = clamp( ( x - a ) / ( b - a ), 0, 1 ); return t * t * ( 3 - 2 * t ); }

	ui.define( '.wk-ui-lq', function ( root ) {
		var c = ui.cfg( root );
		var demo = c.demo || root.hasAttribute( 'data-editor' );
		var form = root.querySelector( '.wk-ui-lq__stage' );
		var A = root.querySelector( '.wk-ui-lq__half--a' ), B = root.querySelector( '.wk-ui-lq__half--b' );
		var inU = A.querySelector( 'input' ), inP = B.querySelector( 'input' );
		var btn = root.querySelector( '.wk-ui-lq__btn' ), txt = root.querySelector( '.wk-ui-lq__txt' );
		var msg = root.querySelector( '.wk-ui-lq__msg' );
		var svg = root.querySelector( '.wk-ui-lq__neck' ), path = svg.querySelector( 'path' ), drops = svg.querySelectorAll( 'circle' );

		var SW = Math.max( c.bw, c.fw ), SH = 2 * c.fh + c.gap, cx = SW / 2, cy = SH / 2;
		form.style.width = SW + 'px'; form.style.maxWidth = '100%'; form.style.height = SH + 'px';
		svg.setAttribute( 'viewBox', '0 0 ' + SW + ' ' + SH );

		var p = ui.spring( 0, 150, 23 );            // morph
		var pull = ui.spring( 0, c.k, c.d );        // separation of the halves (px)
		var snapDist = Math.max( 10, c.gap + c.pull * 0.75 );
		var snapped = false, snapAt = 0, state = 'closed', raf = 0, last = 0, pullTimer;

		function draw( now ) {
			var e = clamp( p.x, 0, 1.08 ), ec = clamp( e, 0, 1 );
			var W = lerp( c.bw, c.fw, ec ), h = lerp( c.bh / 2, c.fh, ec );
			var gap = Math.max( 0, c.gap * ec + pull.x );
			var outer = lerp( c.bh / 2, c.fr, ec ), inner = c.fr * smooth( 0.35, 1, ec );
			var m = 1 - smooth( 0.55, 0.92, ec ), f = smooth( 0.8, 1, ec );
			// stage may be narrower than SW on small screens
			var sw = form.clientWidth || SW, k = sw / SW, ccx = cx * k, w = W * k;
			A.style.cssText = 'left:' + ( ccx - w / 2 ) + 'px;top:' + ( cy - gap / 2 - h ) + 'px;width:' + w + 'px;height:' + ( h + ( gap < 1 ? 1 : 0 ) ) + 'px;border-radius:' + outer + 'px ' + outer + 'px ' + inner + 'px ' + inner + 'px;--m:' + m + ';--f:' + f;
			B.style.cssText = 'left:' + ( ccx - w / 2 ) + 'px;top:' + ( cy + gap / 2 ) + 'px;width:' + w + 'px;height:' + h + 'px;border-radius:' + inner + 'px ' + inner + 'px ' + outer + 'px ' + outer + 'px;--m:' + m + ';--f:' + f;
			A.style.borderColor = B.style.borderColor = m > 0.5 ? 'transparent' : '';
			root.style.setProperty( '--m', m );
			root.style.setProperty( '--t', 1 - smooth( 0, 0.22, ec ) );
			svg.setAttribute( 'viewBox', '0 0 ' + sw + ' ' + SH );

			var yA = cy - gap / 2, yB = cy + gap / 2, ym = cy;
			var e0 = w * c.neck / 2;
			var wm = e0 * Math.pow( clamp( 1 - gap / snapDist, 0, 1 ), 1.3 );
			if ( ! snapped && gap > 0.4 && ( wm < 1.1 || ec > 0.9 ) && 'opening' === dir ) { snapped = true; snapAt = now; }
			if ( ! snapped && gap > 0.4 && m > 0.02 ) {
				var q = gap * 0.28;
				path.setAttribute( 'd',
					'M' + ( ccx - e0 ) + ' ' + ( yA - 1 ) +
					'C' + ( ccx - e0 * 0.45 ) + ' ' + yA + ' ' + ( ccx - wm ) + ' ' + ( ym - q ) + ' ' + ( ccx - wm ) + ' ' + ym +
					'C' + ( ccx - wm ) + ' ' + ( ym + q ) + ' ' + ( ccx - e0 * 0.45 ) + ' ' + yB + ' ' + ( ccx - e0 ) + ' ' + ( yB + 1 ) +
					'L' + ( ccx + e0 ) + ' ' + ( yB + 1 ) +
					'C' + ( ccx + e0 * 0.45 ) + ' ' + yB + ' ' + ( ccx + wm ) + ' ' + ( ym + q ) + ' ' + ( ccx + wm ) + ' ' + ym +
					'C' + ( ccx + wm ) + ' ' + ( ym - q ) + ' ' + ( ccx + e0 * 0.45 ) + ' ' + yA + ' ' + ( ccx + e0 ) + ' ' + ( yA - 1 ) + 'Z' );
			} else {
				path.setAttribute( 'd', '' );
			}
			// After the snap, two drops are pulled back into the edges.
			var dt = snapped ? ( now - snapAt ) / 220 : 2;
			if ( dt < 1 ) {
				var r = 3.2 * ( 1 - dt ), t = dt * dt;
				drops[ 0 ].setAttribute( 'cx', ccx ); drops[ 0 ].setAttribute( 'cy', lerp( ym - 2, yA, t ) ); drops[ 0 ].setAttribute( 'r', r );
				drops[ 1 ].setAttribute( 'cx', ccx ); drops[ 1 ].setAttribute( 'cy', lerp( ym + 2, yB, t ) ); drops[ 1 ].setAttribute( 'r', r );
			} else {
				drops[ 0 ].setAttribute( 'r', 0 ); drops[ 1 ].setAttribute( 'r', 0 );
			}
			return dt < 1;
		}

		var dir = 'opening';
		function loop( now ) {
			var dt = Math.min( 0.034, ( now - ( last || now ) ) / 1000 ); last = now;
			p.step( dt ); pull.step( dt );
			var dropping = draw( now );
			if ( ! p.done() || ! pull.done() || dropping ) { raf = requestAnimationFrame( loop ); } else { raf = 0; last = 0; }
		}
		function kick() {
			if ( ui.reduced() ) { p.x = p.target; p.v = 0; pull.x = pull.target = 0; pull.v = 0; draw( performance.now() ); return; }
			if ( ! raf ) { last = 0; raf = requestAnimationFrame( loop ); }
		}
		function pulse( amount, hold ) {
			clearTimeout( pullTimer );
			pull.target = amount;
			pullTimer = setTimeout( function () { pull.target = 0; kick(); }, hold );
		}

		function open() {
			dir = 'opening'; snapped = false; state = 'open';
			root.classList.add( 'is-open' ); root.classList.remove( 'is-ok', 'is-busy' );
			inU.tabIndex = 0; inP.tabIndex = 0; btn.tabIndex = -1;
			p.target = 1; pulse( c.pull, 170 ); kick();
			setTimeout( function () { if ( 'open' === state ) { ( inU.value ? inP : inU ).focus( { preventScroll: true } ); } }, ui.reduced() ? 0 : 260 );
		}
		function close( label ) {
			dir = 'closing'; snapped = false;
			root.classList.remove( 'is-open' );
			inU.tabIndex = -1; inP.tabIndex = -1; btn.tabIndex = 0;
			if ( label ) { txt.textContent = label; }
			p.target = 0; pulse( c.pull * 0.45, 120 ); kick();
		}
		function say( t ) { msg.textContent = t || ''; }
		function shake() {
			root.classList.remove( 'is-shake' ); void root.offsetWidth; root.classList.add( 'is-shake' );
		}

		btn.addEventListener( 'click', function () {
			if ( 'busy' === state ) { return; }
			if ( 'ok' === state ) {
				if ( ! demo ) { return; }
				root.classList.remove( 'is-ok' ); txt.textContent = c.btn; state = 'closed'; draw( performance.now() ); return;
			}
			say( '' ); open();
		} );
		inU.addEventListener( 'keydown', function ( e ) {
			if ( 'Enter' === e.key ) { e.preventDefault(); if ( inU.value.trim() ) { inP.focus(); } else { shake(); } }
		} );
		inP.addEventListener( 'keydown', function ( e ) { if ( 'Enter' === e.key ) { e.preventDefault(); submit(); } } );
		form.addEventListener( 'submit', function ( e ) { e.preventDefault(); submit(); } );
		root.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key && 'open' === state ) { state = 'closed'; close( c.btn ); btn.focus( { preventScroll: true } ); }
		} );
		document.addEventListener( 'pointerdown', function ( e ) {
			if ( 'open' === state && ! root.contains( e.target ) && ! inU.value && ! inP.value ) { state = 'closed'; close( c.btn ); }
		} );

		function submit() {
			if ( 'open' !== state ) { return; }
			if ( ! inU.value.trim() ) { shake(); inU.focus(); return; }
			if ( ! inP.value ) { shake(); inP.focus(); return; }
			state = 'busy'; say( '' );
			root.classList.add( 'is-busy' );
			close( c.busy );
			var started = Date.now();
			var req = demo ? ui.wait( 900 ).then( function () { return { success: true, data: { demo: 1 } }; } )
				: ui.post( root, 'login', { user: inU.value.trim(), pass: inP.value, remember: 1 } );
			req.then( function ( res ) {
				return ui.wait( Math.max( 0, 700 - ( Date.now() - started ) ) ).then( function () { return res; } );
			} ).then( function ( res ) {
				root.classList.remove( 'is-busy' );
				if ( res && res.success ) {
					state = 'ok'; root.classList.add( 'is-ok' ); txt.textContent = c.done;
					draw( performance.now() );
					if ( ! demo ) { setTimeout( function () { ui.go( res.data && res.data.redirect ); }, 900 ); }
					else { inP.value = ''; }
				} else {
					state = 'closed'; txt.textContent = c.btn;
					open();
					inP.value = '';
					say( ( res && res.data && res.data.msg ) || 'Error' );
					setTimeout( shake, 380 );
				}
			} );
		}

		draw( performance.now() );
		window.addEventListener( 'resize', function () { draw( performance.now() ); } );
	} );
}() );
