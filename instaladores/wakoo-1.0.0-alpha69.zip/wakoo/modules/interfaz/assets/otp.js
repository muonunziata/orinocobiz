/* Wakoo Interfaz · Verificación OTP «baraja» */
( function () {
	'use strict';
	var ui = window.wakooUi;

	ui.define( '.wk-ui-otp', function ( root ) {
		var cfg = ui.cfg( root ), n = cfg.n || 4, t = cfg.t || {};
		var sp = cfg.speed || 1, reduced = ui.reduced();
		var input = root.querySelector( '.wk-ui-otp__input' ), boxes = root.querySelectorAll( '.wk-ui-otp__box' );
		var title = root.querySelector( '.wk-ui-otp__title' ), sub = root.querySelector( '.wk-ui-otp__sub' ), text = root.querySelector( '.wk-ui-otp__text' );
		var err = root.querySelector( '.wk-ui-otp__err' ), cta = root.querySelector( '.wk-ui-otp__cta' ), resend = root.querySelector( '.wk-ui-otp__resend' );
		var ask = root.querySelector( '.wk-ui-otp__ask' );
		var email = '', busy = false, last = '', goUrl = cfg.url || '';
		var subTpl = sub ? sub.innerHTML : '';
		root.style.setProperty( '--_sp', sp );
		root.style.setProperty( '--_deg', cfg.fan ? cfg.deg : 0 );

		function ms( x ) { return reduced ? 0 : x / sp; }
		function setText( a, b, html ) {
			if ( ! text ) { return Promise.resolve(); }
			if ( reduced ) { title.textContent = a; if ( html ) { sub.innerHTML = b; } else { sub.textContent = b; } return Promise.resolve(); }
			text.classList.add( 'is-swap' );
			return ui.wait( 220 ).then( function () {
				title.textContent = a;
				if ( html ) { sub.innerHTML = b; } else { sub.textContent = b; }
				text.classList.remove( 'is-swap' );
			} );
		}
		function esc( s ) { var d = document.createElement( 'div' ); d.textContent = s; return d.innerHTML; }

		function paint() {
			var v = input.value, focused = document.activeElement === input;
			boxes.forEach( function ( b, i ) {
				var d = b.querySelector( '.wk-ui-otp__d' ), ch = v.charAt( i );
				if ( d.textContent !== ch ) {
					d.textContent = ch;
					// restart the pop + light sweep on every new digit
					b.classList.remove( 'is-fill' );
					if ( ch ) { b.offsetWidth; b.classList.add( 'is-fill' ); } // eslint-disable-line no-unused-expressions
				}
				b.classList.toggle( 'is-focus', focused && ! busy && i === Math.min( v.length, n - 1 ) && ! ( v.length === n && i === n - 1 && ch ) );
			} );
		}

		function reset( keepErr ) {
			root.classList.remove( 'is-fan', 'is-stack', 'is-check', 'is-ok', 'is-done', 'is-bad' );
			input.value = ''; last = ''; busy = false; input.disabled = false;
			if ( ! keepErr ) { err.textContent = ''; }
			paint();
		}

		function fail( msg ) {
			root.classList.remove( 'is-check' );
			setText( t.title, subTpl, true );
			ui.wait( ms( 120 ) ).then( function () {
				root.classList.remove( 'is-stack' );
				return ui.wait( ms( 260 ) );
			} ).then( function () {
				root.classList.remove( 'is-fan' );
				root.classList.add( 'is-bad' );
				err.textContent = msg || '';
				if ( cfg.vib && navigator.vibrate ) { navigator.vibrate( [ 30, 40, 30 ] ); }
				return ui.wait( 520 );
			} ).then( function () {
				reset( true );
				input.focus();
			} );
		}

		function verify() {
			var code = input.value;
			if ( busy || code.length !== n ) { return; }
			busy = true; input.disabled = true; err.textContent = '';
			paint();
			var req = cfg.demo !== null && undefined !== cfg.demo
				? Promise.resolve( { success: ! cfg.demo || cfg.demo === code, data: { bad: 1 } } )
				: ui.post( root, 'otp_verify', { code: code, email: email } );
			var seq = ui.wait( ms( 320 ) ).then( function () {
				if ( cfg.fan ) { root.classList.add( 'is-fan' ); return ui.wait( ms( 620 ) ); }
			} ).then( function () {
				root.classList.add( 'is-stack' );
				return ui.wait( ms( 520 ) );
			} ).then( function () {
				root.classList.add( 'is-check' );
				return setText( t.check, t.subCheck );
			} ).then( function () { return ui.wait( ms( 900 ) ); } );
			Promise.all( [ req, seq ] ).then( function ( r ) {
				var res = r[ 0 ] || {};
				if ( ! res.success ) { var dt = res.data || {}; fail( dt.bad && t.bad ? t.bad : ( dt.msg || '' ) ); return; }
				if ( res.data && res.data.redirect ) { goUrl = res.data.redirect; }
				root.classList.remove( 'is-check' );
				root.classList.add( 'is-check', 'is-ok' );
				setText( t.ok, t.subOk ).then( function () { return ui.wait( ms( 650 ) ); } ).then( function () {
					root.classList.add( 'is-done' );
					if ( cfg.go > 0 && ! ui.inEditor() ) { setTimeout( go, cfg.go * 1000 ); }
				} );
			} );
		}

		function go() {
			if ( goUrl && ! ui.inEditor() ) { ui.go( goUrl ); return; }
			if ( cfg.mail && ! ui.inEditor() ) { location.reload(); return; }
			// demo: play again
			setText( t.title, subTpl, true );
			reset();
			input.focus();
		}

		input.addEventListener( 'input', function () {
			var v = input.value.replace( /\D/g, '' ).slice( 0, n );
			if ( v !== input.value ) { input.value = v; }
			if ( v !== last ) { err.textContent = ''; root.classList.remove( 'is-bad' ); }
			last = v;
			paint();
			if ( v.length === n && cfg.auto ) { verify(); }
		} );
		input.addEventListener( 'keydown', function ( e ) {
			if ( 'Enter' === e.key ) { e.preventDefault(); verify(); }
			// keep the caret at the end: the boxes are filled left to right
			if ( 'ArrowLeft' === e.key || 'ArrowRight' === e.key || 'Home' === e.key ) { e.preventDefault(); }
		} );
		input.addEventListener( 'focus', function () { var l = input.value.length; input.setSelectionRange( l, l ); paint(); } );
		input.addEventListener( 'blur', paint );
		input.addEventListener( 'click', function () { var l = input.value.length; input.setSelectionRange( l, l ); } );
		if ( cta ) { cta.addEventListener( 'click', go ); }

		// email step (real codes)
		function send() {
			var btn = ask && ask.querySelector( 'button' );
			if ( btn ) { btn.disabled = true; }
			return ui.post( root, 'otp_send', { email: email } ).then( function ( r ) {
				if ( btn ) { btn.disabled = false; }
				if ( ! r.success ) { err.textContent = ( r.data && r.data.msg ) || ''; return false; }
				return true;
			} );
		}
		if ( ask ) {
			ask.addEventListener( 'submit', function ( e ) {
				e.preventDefault();
				var f = ask.querySelector( 'input' );
				email = ( f.value || '' ).trim();
				if ( ! f.checkValidity() || ! email ) { err.textContent = f.validationMessage || ''; f.focus(); return; }
				err.textContent = '';
				send().then( function ( ok ) {
					if ( ! ok ) { return; }
					subTpl = subTpl.split( '{email}' ).join( esc( email ) );
					sub.innerHTML = subTpl;
					root.classList.remove( 'is-ask' );
					input.focus();
				} );
			} );
		} else if ( sub ) {
			subTpl = subTpl.split( '{email}' ).join( '' );
			sub.innerHTML = subTpl;
		}

		if ( resend ) {
			resend.addEventListener( 'click', function () {
				if ( resend.disabled ) { return; }
				resend.disabled = true;
				var done = function () {
					resend.textContent = t.resent || '✓';
					setTimeout( function () { resend.textContent = t.resend; resend.disabled = false; }, 30000 );
				};
				if ( cfg.mail && email ) { send().then( function ( ok ) { if ( ok ) { done(); } else { resend.disabled = false; } } ); } else { done(); }
				reset(); input.focus();
			} );
		}

		paint();
	} );
}() );
