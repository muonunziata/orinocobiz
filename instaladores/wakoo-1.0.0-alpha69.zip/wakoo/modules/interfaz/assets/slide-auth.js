/* Wakoo Interfaz · Login / registro diagonal */
( function () {
	'use strict';
	var ui = window.wakooUi;

	ui.define( '.wk-ui-sa', function ( root ) {
		var cfg = ui.cfg( root );
		var demo = cfg.demo || root.hasAttribute( 'data-editor' );
		var box = root.querySelector( '.wk-ui-sa__box' );

		root.addEventListener( 'click', function ( e ) {
			var a = e.target.closest( '[data-go]' );
			if ( ! a ) { return; }
			e.preventDefault();
			box.classList.toggle( 'is-active', 'register' === a.getAttribute( 'data-go' ) );
			var f = root.querySelector( '.wk-ui-sa__form--' + a.getAttribute( 'data-go' ) + ' input' );
			if ( f ) { setTimeout( function () { f.focus( { preventScroll: true } ); }, 1200 ); }
		} );

		root.querySelectorAll( '.wk-ui-sa__form' ).forEach( function ( form ) {
			form.addEventListener( 'submit', function ( e ) {
				e.preventDefault();
				var btn = form.querySelector( '.wk-ui-sa__btn' ), msg = form.querySelector( '.wk-ui-sa__msg' );
				var empty = Array.prototype.find.call( form.querySelectorAll( 'input[required]' ), function ( i ) { return ! i.value.trim(); } );
				if ( empty ) { empty.focus(); return; }
				var data = {};
				form.querySelectorAll( 'input' ).forEach( function ( i ) { data[ i.name ] = i.value; } );
				btn.classList.add( 'is-busy' ); msg.textContent = ''; msg.classList.remove( 'is-ok' );
				var req = demo ? ui.wait( 900 ).then( function () { return { success: true, data: {} }; } ) : ui.post( root, form.getAttribute( 'data-act' ), data );
				req.then( function ( res ) {
					btn.classList.remove( 'is-busy' );
					if ( res && res.success ) {
						msg.textContent = '✓'; msg.classList.add( 'is-ok' );
						if ( ! demo ) { setTimeout( function () { ui.go( res.data && res.data.redirect ); }, 500 ); }
						else { setTimeout( function () { msg.textContent = ''; }, 1500 ); }
					} else {
						msg.textContent = ( res && res.data && res.data.msg ) || 'Error';
					}
				} );
			} );
		} );
	} );
}() );
