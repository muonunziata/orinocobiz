/* Wakoo Interfaz: tiny shared runtime (boot once per element, ajax helper, springs). */
( function () {
	'use strict';
	var ui = window.wakooUi = window.wakooUi || {};
	var defs = ui.defs = ui.defs || [];

	ui.reduced = function () {
		return !! ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches );
	};
	ui.inEditor = function () {
		return document.body && document.body.classList.contains( 'elementor-editor-active' );
	};

	function run( def, scope ) {
		var list = ( scope || document ).querySelectorAll( def.sel );
		Array.prototype.forEach.call( list, function ( el ) {
			if ( el.dataset.wakooInit ) { return; }
			el.dataset.wakooInit = '1';
			try { def.init( el ); } catch ( e ) { if ( window.console ) { console.error( e ); } }
		} );
	}

	/** Register a widget initialiser for a CSS selector. */
	ui.define = function ( sel, init ) {
		var def = { sel: sel, init: init };
		defs.push( def );
		if ( 'loading' === document.readyState ) {
			document.addEventListener( 'DOMContentLoaded', function () { run( def ); } );
		} else {
			run( def );
		}
	};

	function hookElementor() {
		if ( ! window.elementorFrontend || ! window.elementorFrontend.hooks ) { return false; }
		window.elementorFrontend.hooks.addAction( 'frontend/element_ready/global', function ( $scope ) {
			var node = $scope && $scope[ 0 ];
			if ( ! node ) { return; }
			defs.forEach( function ( d ) { run( d, node ); } );
		} );
		return true;
	}
	if ( ! ui.hooked ) {
		ui.hooked = true;
		if ( ! hookElementor() ) {
			window.addEventListener( 'elementor/frontend/init', hookElementor );
		}
	}

	/** POST to admin-ajax; resolves with the JSON body ({success, data}). */
	ui.post = function ( root, action, fields ) {
		var fd = new FormData();
		fd.append( 'action', 'wakoo_ui_' + action );
		fd.append( 'nonce', root.getAttribute( 'data-nonce' ) || '' );
		fd.append( 'post', root.getAttribute( 'data-post' ) || '' );
		fd.append( 'el', root.getAttribute( 'data-el' ) || '' );
		Object.keys( fields || {} ).forEach( function ( k ) { fd.append( k, fields[ k ] ); } );
		return fetch( ( window.wakooUi && window.wakooUi.ajax ) || '/wp-admin/admin-ajax.php', { method: 'POST', body: fd, credentials: 'same-origin' } )
			.then( function ( r ) { return r.json().catch( function () { return { success: false, data: {} }; } ); } )
			.catch( function () { return { success: false, data: { msg: 'Error de conexión' } }; } );
	};

	ui.go = function ( url ) {
		if ( url ) { window.location.href = url; } else { window.location.reload(); }
	};

	ui.cfg = function ( el ) {
		try { return JSON.parse( el.getAttribute( 'data-cfg' ) || '{}' ); } catch ( e ) { return {}; }
	};

	/** Damped spring integrator: returns {x, v, step(dt), done()} */
	ui.spring = function ( x, k, d ) {
		var s = { x: x, v: 0, target: x, k: k || 170, d: d || 26 };
		s.step = function ( dt ) {
			var n = Math.max( 1, Math.ceil( dt / ( 1 / 240 ) ) ), h = dt / n;
			for ( var i = 0; i < n; i++ ) {
				var a = -s.k * ( s.x - s.target ) - s.d * s.v;
				s.v += a * h; s.x += s.v * h;
			}
			return s.x;
		};
		s.done = function () { return Math.abs( s.x - s.target ) < 0.001 && Math.abs( s.v ) < 0.01; };
		return s;
	};

	ui.wait = function ( ms ) { return new Promise( function ( r ) { setTimeout( r, ms ); } ); };
}() );
