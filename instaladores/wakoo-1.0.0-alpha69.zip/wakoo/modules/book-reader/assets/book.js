( function () {
	'use strict';

	var pdfjsLib = window.pdfjsLib || ( window.pdfjsDistBuildPdf );
	function lib() { return window.pdfjsLib || window.pdfjsDistBuildPdf; }

	function initOne( root ) {
		if ( root.__wakooBook ) { return; }
		root.__wakooBook = true;
		var cfg;
		try { cfg = JSON.parse( root.getAttribute( 'data-wakoo-book' ) || '{}' ); } catch ( e ) { return; }
		if ( ! cfg.pdf ) { return; }

		var PDF = lib();
		if ( ! PDF || ! window.St || ! window.St.PageFlip ) {
			// Libraries not ready yet; retry shortly.
			root.__wakooBook = false;
			return setTimeout( function () { initOne( root ); }, 200 );
		}
		if ( window.WakooBook && window.WakooBook.worker ) {
			PDF.GlobalWorkerOptions.workerSrc = window.WakooBook.worker;
		}

		var loading = root.querySelector( '.wakoo-book__loading' );
		var flipEl  = root.querySelector( '.wakoo-book__flip' );
		var pageLbl = root.querySelector( '.wakoo-book__page' );

		PDF.getDocument( cfg.pdf ).promise.then( function ( pdf ) {
			var pages = [];
			var tasks = [];
			for ( var i = 1; i <= pdf.numPages; i++ ) {
				tasks.push( renderPage( PDF, pdf, i ) );
			}
			return Promise.all( tasks );
		} ).then( function ( images ) {
			if ( loading ) { loading.style.display = 'none'; }
			buildFlip( root, flipEl, pageLbl, images, cfg );
		} ).catch( function ( err ) {
			if ( loading ) { loading.textContent = 'No se pudo cargar el documento.'; }
			if ( window.console ) { console.error( 'Wakoo Book:', err ); }
		} );
	}

	function renderPage( PDF, pdf, num ) {
		return pdf.getPage( num ).then( function ( page ) {
			var scale = 1.5;
			var viewport = page.getViewport( { scale: scale } );
			var canvas = document.createElement( 'canvas' );
			var ctx = canvas.getContext( '2d' );
			canvas.width = viewport.width;
			canvas.height = viewport.height;
			return page.render( { canvasContext: ctx, viewport: viewport } ).promise.then( function () {
				return { src: canvas.toDataURL( 'image/jpeg', 0.85 ), w: viewport.width, h: viewport.height };
			} );
		} );
	}

	function buildFlip( root, flipEl, pageLbl, images, cfg ) {
		if ( ! images.length ) { return; }
		var ratio = images[ 0 ].w / images[ 0 ].h;
		var h = root.clientHeight || 600;
		var w = Math.round( h * ratio );

		var pageWidth = Math.min( w, Math.floor( ( root.clientWidth - 20 ) / ( cfg.single ? 1 : 2 ) ) );
		var pageHeight = Math.round( pageWidth / ratio );

		var pf = new window.St.PageFlip( flipEl, {
			width: pageWidth,
			height: pageHeight,
			size: 'stretch',
			minWidth: 200,
			maxWidth: 2000,
			minHeight: 300,
			maxHeight: 2000,
			drawShadow: !! cfg.shadow,
			flippingTime: 600,
			usePortrait: !! cfg.single,
			showCover: true,
			mobileScrollSupport: true,
		} );

		var items = images.map( function ( im ) {
			var d = document.createElement( 'div' );
			d.className = 'wakoo-book__page-item';
			var img = document.createElement( 'img' );
			img.src = im.src; img.alt = '';
			d.appendChild( img );
			return d;
		} );

		pf.loadFromImages ? pf.loadFromImages( images.map( function ( im ) { return im.src; } ) ) : loadDom( pf, flipEl, items );

		function label() {
			if ( pageLbl ) { pageLbl.textContent = ( pf.getCurrentPageIndex() + 1 ) + ' / ' + images.length; }
		}
		label();
		pf.on( 'flip', label );

		var prev = root.querySelector( '.wakoo-book__prev' );
		var next = root.querySelector( '.wakoo-book__next' );
		if ( prev ) { prev.addEventListener( 'click', function () { pf.flipPrev(); } ); }
		if ( next ) { next.addEventListener( 'click', function () { pf.flipNext(); } ); }
	}

	function loadDom( pf, flipEl, items ) {
		items.forEach( function ( it ) { flipEl.appendChild( it ); } );
		pf.loadFromHTML( flipEl.querySelectorAll( '.wakoo-book__page-item' ) );
	}

	function boot() {
		var roots = document.querySelectorAll( '.wakoo-book[data-wakoo-book]' );
		for ( var i = 0; i < roots.length; i++ ) { initOne( roots[ i ] ); }
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}
	// Elementor editor: re-init when a widget is added/edited.
	if ( window.jQuery ) {
		jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend ) {
				elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-book-reader.default', function ( $scope ) {
					var el = $scope[ 0 ].querySelector( '.wakoo-book[data-wakoo-book]' );
					if ( el ) { initOne( el ); }
				} );
			}
		} );
	}
}() );
