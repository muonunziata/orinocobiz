<?php
/**
 * Wakoo Book Reader: a page-flip reader widget for PDF (and, where the server
 * can convert them, Word/PowerPoint) documents.
 *
 * Rendering is client-side: PDF.js rasterises each page and StPageFlip turns
 * them into a flippable book. Office files are converted to PDF once with
 * LibreOffice (if installed) and cached under uploads/wakoo-book/.
 *
 * Bundled libraries (see vendor/CREDITS.txt): StPageFlip (MIT), PDF.js (Apache-2.0).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Book_Reader;

defined( 'ABSPATH' ) || die();

class Module {

	const OFFICE = [ 'doc', 'docx', 'ppt', 'pptx', 'odt', 'odp', 'xls', 'xlsx' ];

	public static function init() {
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'register_assets' ] );
		add_action( 'elementor/frontend/after_register_styles', [ __CLASS__, 'register_styles' ] );
	}

	public static function register_widget( $widgets_manager ) {
		require_once __DIR__ . '/widget.php';
		$widgets_manager->register( new Widget() );
	}

	public static function register_assets() {
		$base = WAKOO_MODULES_URL . 'book-reader/';
		wp_register_script( 'wakoo-pdfjs', $base . 'vendor/pdf.min.js', [], WAKOO_VERSION, true );
		wp_register_script( 'wakoo-pageflip', $base . 'vendor/page-flip.browser.js', [], WAKOO_VERSION, true );
		wp_register_script( 'wakoo-book', $base . 'assets/book.js', [ 'wakoo-pdfjs', 'wakoo-pageflip' ], WAKOO_VERSION, true );
		wp_localize_script( 'wakoo-book', 'WakooBook', [ 'worker' => $base . 'vendor/pdf.worker.min.js' ] );
	}

	public static function register_styles() {
		$base = WAKOO_MODULES_URL . 'book-reader/';
		wp_register_style( 'wakoo-pageflip', $base . 'vendor/page-flip.css', [], WAKOO_VERSION );
		wp_register_style( 'wakoo-book', $base . 'assets/book.css', [ 'wakoo-pageflip' ], WAKOO_VERSION );
	}

	/**
	 * Return a browser-loadable PDF URL for a document URL. If it is an Office
	 * file and LibreOffice is available, convert it to PDF once and cache it.
	 * Returns '' when it cannot be turned into a PDF.
	 */
	public static function resolve_pdf( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url ) {
			return '';
		}
		$ext = strtolower( pathinfo( wp_parse_url( $url, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
		if ( 'pdf' === $ext ) {
			return $url;
		}
		if ( ! in_array( $ext, self::OFFICE, true ) ) {
			return $url; // let the browser try; unknown types fall through.
		}

		// Office → PDF via LibreOffice (local files only).
		$src_path = self::local_path( $url );
		if ( ! $src_path || ! is_readable( $src_path ) ) {
			return '';
		}
		$soffice = self::soffice_bin();
		if ( ! $soffice ) {
			return '';
		}

		$uploads = wp_upload_dir();
		$out_dir = trailingslashit( $uploads['basedir'] ) . 'wakoo-book';
		$out_url = trailingslashit( $uploads['baseurl'] ) . 'wakoo-book';
		if ( ! file_exists( $out_dir ) ) {
			wp_mkdir_p( $out_dir );
		}
		$hash    = md5( $src_path . '|' . filemtime( $src_path ) );
		$pdf_file = $out_dir . '/' . $hash . '.pdf';
		$pdf_url  = $out_url . '/' . $hash . '.pdf';
		if ( file_exists( $pdf_file ) ) {
			return $pdf_url;
		}

		$profile = $out_dir . '/.lo-profile';
		$cmd = sprintf(
			'%s --headless --norestore -env:UserInstallation=%s --convert-to pdf --outdir %s %s 2>&1',
			escapeshellcmd( $soffice ),
			escapeshellarg( 'file://' . $profile ),
			escapeshellarg( $out_dir ),
			escapeshellarg( $src_path )
		);
		@exec( $cmd, $o, $code ); // phpcs:ignore
		$generated = $out_dir . '/' . pathinfo( $src_path, PATHINFO_FILENAME ) . '.pdf';
		if ( file_exists( $generated ) ) {
			@rename( $generated, $pdf_file ); // phpcs:ignore
			return $pdf_url;
		}
		return file_exists( $pdf_file ) ? $pdf_url : '';
	}

	private static function soffice_bin() {
		foreach ( [ 'soffice', 'libreoffice' ] as $bin ) {
			$p = @shell_exec( 'command -v ' . escapeshellarg( $bin ) . ' 2>/dev/null' ); // phpcs:ignore
			if ( $p && trim( $p ) ) {
				return trim( $p );
			}
		}
		return '';
	}

	private static function local_path( $url ) {
		$uploads = wp_upload_dir();
		if ( 0 === strpos( $url, $uploads['baseurl'] ) ) {
			return str_replace( $uploads['baseurl'], $uploads['basedir'], $url );
		}
		$id = attachment_url_to_postid( $url );
		if ( $id ) {
			$f = get_attached_file( $id );
			if ( $f ) {
				return $f;
			}
		}
		return '';
	}
}

Module::init();
