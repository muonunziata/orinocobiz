<?php
/**
 * Wakoo Book Reader widget (page-flip document viewer).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Book_Reader;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Widget extends Widget_Base {

	public function get_name() { return 'wakoo-book-reader'; }
	public function get_title() { return __( 'Lector de libro (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-document-file'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'pdf', 'libro', 'flip', 'documento', 'wakoo', 'book' ]; }
	public function get_script_depends() { return [ 'wakoo-book' ]; }
	public function get_style_depends() { return [ 'wakoo-book' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec', [ 'label' => __( 'Documento', 'wakoo' ) ] );

		$this->add_control( 'source', [
			'label'   => __( 'Origen', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'file',
			'options' => [ 'file' => __( 'Subir archivo', 'wakoo' ), 'url' => __( 'Enlace (URL)', 'wakoo' ) ],
		] );

		$this->add_control( 'file', [
			'label'       => __( 'Archivo (PDF, Word, PowerPoint)', 'wakoo' ),
			'type'        => Controls_Manager::MEDIA,
			'media_types' => [ 'application' ],
			'condition'   => [ 'source' => 'file' ],
		] );

		$this->add_control( 'url', [
			'label'       => __( 'URL del documento (PDF)', 'wakoo' ),
			'type'        => Controls_Manager::URL,
			'options'     => false,
			'placeholder' => 'https://.../documento.pdf',
			'condition'   => [ 'source' => 'url' ],
		] );

		$this->add_control( 'office_note', [
			'type' => Controls_Manager::RAW_HTML,
			'raw'  => __( 'Word/PowerPoint se convierten a PDF automáticamente si el servidor tiene LibreOffice. Si no, sube un PDF.', 'wakoo' ),
			'content_classes' => 'elementor-descriptor',
		] );

		$this->add_responsive_control( 'height', [
			'label'      => __( 'Alto', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'range'      => [ 'px' => [ 'min' => 300, 'max' => 1200 ] ],
			'default'    => [ 'unit' => 'px', 'size' => 600 ],
			'selectors'  => [ '{{WRAPPER}} .wakoo-book' => 'height: {{SIZE}}{{UNIT}};' ],
		] );

		$this->add_control( 'single', [
			'label'        => __( 'Una página a la vez (móvil)', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => 'yes',
		] );

		$this->add_control( 'shadow', [
			'label'        => __( 'Sombra de página', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => 'yes',
		] );

		$this->add_control( 'bg', [
			'label'     => __( 'Fondo', 'wakoo' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#2b2b3a',
			'selectors' => [ '{{WRAPPER}} .wakoo-book' => 'background: {{VALUE}};' ],
		] );

		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$raw = 'url' === ( $s['source'] ?? 'file' )
			? ( $s['url']['url'] ?? '' )
			: ( $s['file']['url'] ?? '' );

		$pdf = Module::resolve_pdf( $raw );

		if ( '' === $pdf ) {
			if ( current_user_can( 'edit_posts' ) ) {
				echo '<div class="wakoo-book__notice">' . esc_html__( 'Selecciona un PDF, o un Word/PowerPoint (se convierte a PDF si el servidor tiene LibreOffice).', 'wakoo' ) . '</div>';
			}
			return;
		}

		$cfg = [
			'pdf'    => $pdf,
			'single' => ( 'yes' === ( $s['single'] ?? 'yes' ) ),
			'shadow' => ( 'yes' === ( $s['shadow'] ?? 'yes' ) ),
		];
		printf(
			'<div class="wakoo-book" data-wakoo-book="%s"><div class="wakoo-book__loading">%s</div><div class="wakoo-book__flip"></div><div class="wakoo-book__nav"><button class="wakoo-book__prev" aria-label="Anterior">‹</button><span class="wakoo-book__page"></span><button class="wakoo-book__next" aria-label="Siguiente">›</button></div></div>',
			esc_attr( wp_json_encode( $cfg ) ),
			esc_html__( 'Cargando documento…', 'wakoo' )
		);
	}
}
