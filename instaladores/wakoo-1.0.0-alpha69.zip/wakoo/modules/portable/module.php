<?php
/**
 * Wakoo Portable: export pages, posts, templates and popups built with the
 * builder to a single .json file, and import that file on another site.
 *
 * Native (no cloud, no account): the file is the transport. Needs the
 * unfiltered_html capability to import, because a template can contain
 * HTML/JS widgets, same as Elementor's own import.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Portable;

defined( 'ABSPATH' ) || die();

require_once __DIR__ . '/analysis.php';

class Module {

	const FORMAT    = 'wakoo-export';
	const VERSION   = 1;
	const MAX_BYTES = 8388608; // 8 MB.
	const TYPES     = [ 'page', 'post', 'elementor_library', 'wakoo_popup', 'wakoo_place' ];

	/** Zip pack limits (a pack is never extracted to disk: entries are read one by one). */
	const ZIP_MAX_BYTES   = 134217728; // 128 MB upload.
	const ZIP_MAX_ENTRIES = 600;
	const ZIP_MAX_FILE    = 26214400;  // 25 MB per file.
	const ZIP_MAX_TOTAL   = 268435456; // 256 MB uncompressed in total.
	const PACK_JSON       = 'wakoo-pack.json';
	const PACK_SCHEME     = 'wakoo-pack://';
	const PACK_MEDIA      = [
		'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp',
		'avif' => 'image/avif', 'mp4' => 'video/mp4', 'webm' => 'video/webm', 'mp3' => 'audio/mpeg', 'ogg' => 'audio/ogg',
		'wav' => 'audio/wav', 'pdf' => 'application/pdf', 'vtt' => 'text/vtt',
	];

	/** Meta keys copied on export / accepted on import (prefix match for _wakoo_). */
	const META_KEYS = [ '_elementor_data', '_elementor_page_settings', '_elementor_edit_mode', '_elementor_template_type', '_wp_page_template' ];

	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ], 30 );
		add_action( 'admin_post_wakoo_export', [ __CLASS__, 'handle_export' ] );
		add_action( 'admin_post_wakoo_import', [ __CLASS__, 'handle_import' ] );
		add_action( 'admin_post_wakoo_export_zip', [ __CLASS__, 'handle_export_zip' ] );
		add_action( 'admin_post_wakoo_pack_styles', [ __CLASS__, 'handle_styles' ] );
		add_action( 'wp_head', [ __CLASS__, 'print_styles' ], 8 );
		// "Descargar esta página": one page as a .zip pack, from the editor, the admin bar and the list rows.
		add_action( 'admin_post_wakoo_download', [ __CLASS__, 'handle_download' ] );
		add_filter( 'page_row_actions', [ __CLASS__, 'row_action' ], 30, 2 );
		add_filter( 'post_row_actions', [ __CLASS__, 'row_action' ], 30, 2 );
		add_action( 'admin_bar_menu', [ __CLASS__, 'admin_bar' ], 230 );
		add_action( 'elementor/editor/after_enqueue_scripts', [ __CLASS__, 'editor_script' ] );
	}

	public static function menu() {
		add_submenu_page( 'wakoo-seo', __( 'Exportar / importar', 'wakoo' ), __( 'Exportar / importar', 'wakoo' ), 'manage_options', 'wakoo-portable', [ __CLASS__, 'page' ] );
	}

	/* ---------- core (also used by tests) ---------- */

	private static function meta_allowed( $key ) {
		if ( '_wakoo_pack_ref' === $key ) { return false; } // Managed by the importer (see ref_of / find_ref).
		if ( in_array( $key, self::META_KEYS, true ) || 0 === strpos( $key, '_wakoo_' ) ) { return true; }
		foreach ( (array) apply_filters( 'wakoo_portable_meta_prefixes', [] ) as $pre ) { if ( $pre && 0 === strpos( $key, $pre ) ) { return true; } }
		return false;
	}

	/** Post types packs can carry: the built-in list plus what modules add (filter `wakoo_portable_types`). */
	public static function types() {
		return array_values( array_unique( array_merge( self::TYPES, (array) apply_filters( 'wakoo_portable_types', [] ) ) ) );
	}

	/** Build the export array for the given post IDs. */
	public static function build_export( array $ids ) {
		$items = [];
		foreach ( $ids as $id ) {
			$p = get_post( (int) $id );
			if ( ! $p || ! in_array( $p->post_type, self::types(), true ) || ! current_user_can( 'edit_post', $p->ID ) ) { continue; }
			$meta = [];
			foreach ( get_post_meta( $p->ID ) as $k => $vals ) {
				if ( ! self::meta_allowed( $k ) ) { continue; }
				$v = maybe_unserialize( $vals[0] );
				if ( '_elementor_data' === $k && is_string( $v ) ) {
					$dec = json_decode( $v, true );
					$v = is_array( $dec ) ? $dec : $v;
				}
				$meta[ $k ] = $v;
			}
			$item = [
				'content' => get_post_meta( $p->ID, '_elementor_data', true ) ? null : $p->post_content,
				'title'   => $p->post_title,
				'type'    => $p->post_type,
				'slug'    => $p->post_name,
				'excerpt' => $p->post_excerpt,
				'ref'     => self::ref_of( $p->ID ),
				'meta'    => $meta,
			];
			if ( $p->post_parent ) { $item['parent'] = get_page_uri( $p->post_parent ); }
			$terms = self::export_terms( $p );
			if ( $terms ) { $item['terms'] = $terms; }
			if ( $p->menu_order ) { $item['menu_order'] = (int) $p->menu_order; }
			$items[] = array_filter( $item, function ( $v ) { return null !== $v; } );
		}
		return [
			'format'   => self::FORMAT,
			'version'  => self::VERSION,
			'source'   => home_url( '/' ),
			'exported' => gmdate( 'c' ),
			'items'    => $items,
		];
	}

	/**
	 * Create draft posts from an export array.
	 *
	 * @return array|\WP_Error list of [id,title,type] created.
	 */
	/** Large packs (many pages, image thumbnails) can outlast the host's default 30 s / 128 MB: give the import room. */
	private static function raise_limits() {
		if ( function_exists( 'wp_raise_memory_limit' ) ) { wp_raise_memory_limit( 'admin' ); }
		if ( function_exists( 'set_time_limit' ) && false === strpos( (string) ini_get( 'disable_functions' ), 'set_time_limit' ) ) { @set_time_limit( 300 ); } // phpcs:ignore WordPress.PHP.NoSilencedErrors
		ignore_user_abort( true );
	}

	public static function import_data( $data, array $opts = [] ) {
		self::raise_limits();
		if ( ! is_array( $data ) || ( $data['format'] ?? '' ) !== self::FORMAT || empty( $data['items'] ) || ! is_array( $data['items'] ) ) {
			return new \WP_Error( 'format', __( 'El archivo no es una exportación de Wakoo.', 'wakoo' ) );
		}
		if ( (int) ( $data['version'] ?? 0 ) > self::VERSION ) {
			return new \WP_Error( 'version', __( 'El archivo viene de una versión más nueva de Wakoo.', 'wakoo' ) );
		}
		$made = []; $keys = []; $parents = [];
		$pack = sanitize_key( $opts['pack_id'] ?? ( $data['pack'] ?? '' ) );
		foreach ( $data['items'] as $it ) {
			if ( ! empty( $opts['map'] ) ) { $it = self::map_media( $it, $opts['map'] ); }
			$type = $it['type'] ?? '';
			if ( ! in_array( $type, self::types(), true ) || ! post_type_exists( $type ) ) { continue; }
			$status = 'draft';
			if ( ! empty( $opts['publish'] ) && current_user_can( get_post_type_object( $type )->cap->publish_posts ) ) { $status = 'publish'; }
			$arr = [
				'post_type'    => $type,
				'post_status'  => $status,
				'post_title'   => sanitize_text_field( $it['title'] ?? '' ) . ( empty( $opts['pack'] ) ? ' ' . __( '(importado)', 'wakoo' ) : '' ),
				'post_excerpt' => sanitize_textarea_field( $it['excerpt'] ?? '' ),
			];
			// Gutenberg / classic content travels as it is (importing needs unfiltered_html, like Elementor's import).
			if ( isset( $it['content'] ) && is_string( $it['content'] ) ) { $arr['post_content'] = $it['content']; }
			if ( ! empty( $opts['pack'] ) && ! empty( $it['slug'] ) ) { $arr['post_name'] = sanitize_title( $it['slug'] ); }
			if ( isset( $it['menu_order'] ) ) { $arr['menu_order'] = (int) $it['menu_order']; }
			// Publication date (e.g. examples in the order they should be listed): "YYYY-MM-DD HH:MM:SS", site time.
			if ( ! empty( $it['date'] ) && is_string( $it['date'] ) && preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $it['date'] ) ) {
				$arr['post_date']     = $it['date'];
				$arr['post_date_gmt'] = get_gmt_from_date( $it['date'] );
			}
			// Parent known already (packs list parents first): set it now so the slug is unique within the parent.
			if ( ! empty( $it['parent'] ) && is_string( $it['parent'] ) && isset( $keys[ sanitize_key( $it['parent'] ) ] ) ) {
				$arr['post_parent'] = $keys[ sanitize_key( $it['parent'] ) ];
			}
			$key = isset( $it['key'] ) ? sanitize_key( $it['key'] ) : '';
			$ref = ( $pack && $key ) ? $pack . ':' . $key : '';
			if ( ! $ref && isset( $it['ref'] ) && is_string( $it['ref'] ) && preg_match( '/^[a-z0-9_\-]+:[a-z0-9_\-]+$/', $it['ref'] ) ) { $ref = $it['ref']; }
			$old = $ref ? self::find_ref( $ref, $type ) : 0;
			if ( $old && ! empty( $opts['replace'] ) ) {
				$arr['ID'] = $old;
				if ( 'publish' === get_post_status( $old ) ) { $arr['post_status'] = 'publish'; }
				$id = wp_update_post( wp_slash( $arr ), true );
			} else {
				$id = wp_insert_post( wp_slash( $arr ), true );
			}
			if ( is_wp_error( $id ) ) { continue; }
			// Backup refs (site_tag:pID) always mean the original post, never a copy made from it.
			if ( $ref && 0 !== strpos( $ref, self::site_tag() . ':' ) ) { update_post_meta( $id, '_wakoo_pack_ref', $ref ); }
			if ( $key ) { $keys[ $key ] = $id; }
			if ( ! empty( $it['parent'] ) && is_string( $it['parent'] ) ) { $parents[ $id ] = [ $it['parent'], $arr['post_name'] ?? '' ]; }
			foreach ( (array) ( $it['meta'] ?? [] ) as $k => $v ) {
				if ( ! self::meta_allowed( $k ) ) { continue; }
				if ( '_elementor_data' === $k && is_array( $v ) ) {
					$v = wp_slash( wp_json_encode( $v ) );
				} else {
					$v = wp_slash( $v );
				}
				update_post_meta( $id, $k, is_string( $v ) ? $v : $v );
			}
			if ( ! empty( $it['terms'] ) && is_array( $it['terms'] ) ) { self::import_terms( $id, $type, $it['terms'] ); }
			if ( ! get_post_meta( $id, '_elementor_edit_mode', true ) && get_post_meta( $id, '_elementor_data', true ) ) {
				update_post_meta( $id, '_elementor_edit_mode', 'builder' );
			}
			if ( 'elementor_library' === $type && ! get_post_meta( $id, '_elementor_template_type', true ) ) {
				update_post_meta( $id, '_elementor_template_type', 'page' );
			}
			$made[] = [ 'id' => $id, 'title' => get_the_title( $id ), 'type' => $type, 'updated' => (bool) $old ];
		}
		$menus = ( ! empty( $opts['pack'] ) && ! empty( $data['menus'] ) && is_array( $data['menus'] ) ) ? self::make_menus( $data['menus'], $keys, $pack ) : [];
		// Site settings first, so links to the pack's front page resolve to the home URL.
		if ( ! empty( $opts['site'] ) && is_array( $opts['site'] ) ) { self::apply_site( $opts['site'], $keys, (array) ( $opts['map'] ?? [] ) ); }
		if ( $keys || $parents ) { self::link_items( $keys, $parents, $made, $menus ); }
		if ( class_exists( '\Elementor\Plugin' ) ) {
			\Elementor\Plugin::instance()->files_manager->clear_cache();
		}
		return $made;
	}


	/* ---------- pack references (parents, links between items, site settings) ---------- */

	/** Post created by an earlier import of the same pack item (pack:key), so re-importing updates it. */
	private static function find_ref( $ref, $type ) {
		// A page downloaded from this same site: restore the original post.
		if ( preg_match( '/^' . self::site_tag() . ':p(\d+)$/', $ref, $m ) ) {
			return ( get_post_type( (int) $m[1] ) === $type && 'trash' !== get_post_status( (int) $m[1] ) ) ? (int) $m[1] : 0;
		}
		$q = get_posts( [ 'post_type' => $type, 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_wakoo_pack_ref', 'meta_value' => $ref ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
		return $q ? (int) $q[0] : 0;
	}

	/** Terms of a post, per taxonomy: [ tax => [ { slug, name, meta: { wk_*: value } } ] ]. */
	private static function export_terms( $p ) {
		$out = [];
		foreach ( get_object_taxonomies( $p->post_type ) as $tax ) {
			$terms = get_the_terms( $p, $tax );
			if ( ! is_array( $terms ) || ! $terms ) { continue; }
			foreach ( $terms as $t ) {
				$meta = [];
				foreach ( (array) get_term_meta( $t->term_id ) as $k => $v ) {
					if ( 0 === strpos( $k, 'wk_' ) && isset( $v[0] ) && '' !== $v[0] ) { $meta[ $k ] = (string) $v[0]; }
				}
				$path = [];
				if ( is_taxonomy_hierarchical( $tax ) ) {
					foreach ( array_reverse( get_ancestors( $t->term_id, $tax, 'taxonomy' ) ) as $a ) { $at = get_term( $a, $tax ); if ( $at && ! is_wp_error( $at ) ) { $path[] = $at->name; } }
					$path[] = $t->name;
				}
				$out[ $tax ][] = array_filter( [ 'slug' => $t->slug, 'name' => $t->name, 'path' => count( $path ) > 1 ? $path : null, 'meta' => $meta ] );
			}
		}
		return $out;
	}

	/** Give an imported post its terms, creating the ones that do not exist yet (names per language in wk_* meta). */
	private static function import_terms( $id, $type, $terms ) {
		foreach ( (array) $terms as $tax => $list ) {
			$tax = sanitize_key( $tax );
			if ( ! taxonomy_exists( $tax ) || ! is_object_in_taxonomy( $type, $tax ) ) { continue; }
			$ids = [];
			foreach ( (array) $list as $t ) {
				$name = sanitize_text_field( is_array( $t ) ? ( $t['name'] ?? '' ) : (string) $t );
				$slug = sanitize_title( is_array( $t ) ? ( $t['slug'] ?? $name ) : (string) $t );
				if ( '' === $slug ) { continue; }
				// Folders and other trees: "path" (names from the top) rebuilds the same parents on the new site.
				if ( is_array( $t ) && ! empty( $t['path'] ) && is_array( $t['path'] ) && is_taxonomy_hierarchical( $tax ) ) {
					$tid = self::term_path( $tax, $t['path'] );
					if ( $tid ) { $ids[] = $tid; }
					continue;
				}
				$term = get_term_by( 'slug', $slug, $tax );
				if ( $term ) {
					$tid = (int) $term->term_id;
					if ( '' !== $name && $name !== $term->name ) { wp_update_term( $tid, $tax, [ 'name' => $name ] ); } // The pack keeps the names up to date.
				} else {
					$r = wp_insert_term( '' !== $name ? $name : $slug, $tax, [ 'slug' => $slug ] );
					if ( is_wp_error( $r ) ) { continue; }
					$tid = (int) $r['term_id'];
				}
				foreach ( (array) ( is_array( $t ) ? ( $t['meta'] ?? [] ) : [] ) as $k => $v ) {
					if ( 0 === strpos( (string) $k, 'wk_' ) ) { update_term_meta( $tid, sanitize_key( $k ), sanitize_text_field( (string) $v ) ); }
				}
				$ids[] = $tid;
			}
			wp_set_object_terms( $id, $ids, $tax );
		}
	}

	/** Term from a path of names in a hierarchical taxonomy (created where missing). */
	private static function term_path( $tax, array $names ) {
		$parent = 0;
		foreach ( $names as $n ) {
			$n = sanitize_text_field( (string) $n );
			if ( '' === $n ) { continue; }
			$found = 0;
			foreach ( get_terms( [ 'taxonomy' => $tax, 'parent' => $parent, 'hide_empty' => false ] ) as $t ) {
				if ( 0 === strcasecmp( html_entity_decode( $t->name, ENT_QUOTES, 'UTF-8' ), $n ) ) { $found = (int) $t->term_id; break; }
			}
			if ( ! $found ) {
				$r = wp_insert_term( $n, $tax, [ 'parent' => $parent, 'slug' => sanitize_title( $n ) . '-' . wp_generate_password( 4, false, false ) ] );
				if ( is_wp_error( $r ) ) { return 0; }
				$found = (int) $r['term_id'];
			}
			$parent = $found;
		}
		return $parent;
	}

	/** Put an imported image in the folder the pack says ("folder": [ "Páginas", "Inicio" ]), unless it already has one. */
	private static function media_folder( $aid, $path ) {
		if ( ! $aid || ! is_array( $path ) || ! $path || ! class_exists( '\Wakoo\Modules\Folders\Module' ) ) { return; }
		$F = '\Wakoo\Modules\Folders\Module';
		if ( $F::folder_of( $aid, 'attachment' ) ) { return; }
		$fid = $F::ensure_path( 'attachment', array_slice( $path, 0, 8 ) );
		if ( $fid ) { wp_set_object_terms( $aid, [ $fid ], $F::tax( 'attachment' ) ); }
	}

	/** Short id of this site (no domain inside the pack): tells a backup of this site from a pack of another one. */
	private static function site_tag() {
		return 'wkbk' . substr( md5( home_url( '/' ) ), 0, 8 );
	}

	/** pack:key that lets a re-import update this same post: its pack ref, or a backup ref of this site. */
	private static function ref_of( $id ) {
		$ref = (string) get_post_meta( $id, '_wakoo_pack_ref', true );
		return preg_match( '/^[a-z0-9_\-]+:[a-z0-9_\-]+$/', $ref ) ? $ref : self::site_tag() . ':p' . (int) $id;
	}

	/**
	 * Second pass: page parents (key of another item, or an existing page path) and the
	 * placeholders wakoo-pack://post/<key> (new ID) and wakoo-pack://link/<key> (its URL).
	 */
	private static function link_items( array $keys, array $parents, array $made, array $menus = [] ) {
		foreach ( $parents as $id => $pp ) {
			list( $p, $slug ) = $pp;
			$pk  = sanitize_key( $p );
			$pid = $keys[ $pk ] ?? 0;
			if ( ! $pid ) { $pg = get_page_by_path( trim( $p, '/' ) ); $pid = $pg ? $pg->ID : 0; }
			if ( $pid && $pid !== $id ) {
				$upd = [ 'ID' => $id, 'post_parent' => $pid ];
				if ( $slug ) { $upd['post_name'] = $slug; } // Re-apply the wanted slug, now unique inside its parent.
				wp_update_post( $upd );
			}
		}
		$urls = [];
		foreach ( $keys as $k => $id ) { $urls[ $k ] = self::item_url( $id ); }
		foreach ( $made as $m ) {
			// Other text fields (e.g. an ad's link) can point to pack items too.
			foreach ( get_post_meta( $m['id'] ) as $mk => $vals ) {
				$v = maybe_unserialize( $vals[0] ?? '' );
				if ( '_elementor_data' !== $mk && is_string( $v ) && false !== strpos( $v, 'wakoo-pack:' ) && self::meta_allowed( $mk ) ) {
					update_post_meta( $m['id'], $mk, wp_slash( self::resolve_refs( $v, $keys, $urls, $menus ) ) );
				}
			}
			$raw = get_post_meta( $m['id'], '_elementor_data', true );
			if ( ! is_string( $raw ) || false === strpos( $raw, 'wakoo-pack:' ) ) { continue; }
			$dec = json_decode( $raw, true );
			if ( ! is_array( $dec ) ) { continue; }
			$dec = self::resolve_refs( $dec, $keys, $urls, $menus );
			update_post_meta( $m['id'], '_elementor_data', wp_slash( wp_json_encode( $dec ) ) );
		}
	}

	/** Pretty URL even while the page is still a draft (drafts have no permalink yet). */
	private static function item_url( $id ) {
		if ( 'page' === get_option( 'show_on_front' ) && (int) get_option( 'page_on_front' ) === (int) $id ) { return home_url( '/' ); }
		if ( 'page' === get_post_type( $id ) && get_option( 'permalink_structure' ) ) {
			$uri = get_page_uri( $id );
			if ( $uri ) { return user_trailingslashit( home_url( '/' . $uri ) ); }
		}
		return get_permalink( $id );
	}

	private static function resolve_refs( $node, array $keys, array $urls, array $menus = [] ) {
		if ( is_string( $node ) ) {
			if ( false === strpos( $node, 'wakoo-pack://' ) ) { return $node; }
			return preg_replace_callback( '#wakoo-pack://(post|link|menu)/([a-z0-9_\-]+)(\#[A-Za-z0-9_\-]*)?#', function ( $m ) use ( $keys, $urls, $menus ) {
				$k = $m[2];
				if ( 'menu' === $m[1] ) { return isset( $menus[ $k ] ) ? (string) $menus[ $k ] : ''; }
				if ( ! isset( $keys[ $k ] ) ) { return 'post' === $m[1] ? '' : home_url( '/' ); }
				return 'post' === $m[1] ? (string) $keys[ $k ] : $urls[ $k ] . ( $m[3] ?? '' );
			}, $node );
		}
		if ( is_array( $node ) ) {
			foreach ( $node as $k => $v ) { $node[ $k ] = self::resolve_refs( $v, $keys, $urls, $menus ); }
		}
		return $node;
	}

	/**
	 * WordPress menus described by the pack: [ { key, name, items: [ { title, link: <item key> | url: <https://…>, children: [] } ] } ].
	 * Links to pack pages are real page items, so they follow later slug changes. Re-importing rebuilds the same menu.
	 *
	 * @return array key => menu term id.
	 */
	private static function make_menus( array $menus, array $keys, $pack ) {
		$out = [];
		foreach ( $menus as $m ) {
			$key  = sanitize_key( $m['key'] ?? '' );
			$name = sanitize_text_field( $m['name'] ?? $key );
			if ( ! $key || ! $name ) { continue; }
			$obj = wp_get_nav_menu_object( $name );
			$mid = $obj ? (int) $obj->term_id : (int) wp_create_nav_menu( $name );
			if ( ! $mid || is_wp_error( $mid ) ) { continue; }
			foreach ( (array) wp_get_nav_menu_items( $mid, [ 'post_status' => 'any' ] ) as $old ) { wp_delete_post( $old->ID, true ); }
			self::menu_items( $mid, (array) ( $m['items'] ?? [] ), $keys, 0 );
			$out[ $key ] = $mid;
		}
		return $out;
	}

	private static function menu_items( $mid, array $items, array $keys, $parent ) {
		$order = 0;
		foreach ( $items as $it ) {
			$args = [ 'menu-item-title' => sanitize_text_field( $it['title'] ?? '' ), 'menu-item-status' => 'publish', 'menu-item-parent-id' => $parent, 'menu-item-position' => ++$order ];
			$lk   = sanitize_key( $it['link'] ?? '' );
			if ( $lk && isset( $keys[ $lk ] ) ) {
				$args += [ 'menu-item-object' => get_post_type( $keys[ $lk ] ), 'menu-item-object-id' => $keys[ $lk ], 'menu-item-type' => 'post_type' ];
			} else {
				$args += [ 'menu-item-type' => 'custom', 'menu-item-url' => esc_url_raw( $it['url'] ?? '#' ) ];
			}
			$iid = wp_update_nav_menu_item( $mid, 0, $args );
			if ( ! is_wp_error( $iid ) && ! empty( $it['children'] ) ) { self::menu_items( $mid, (array) $it['children'], $keys, $iid ); }
		}
	}

	/** Options a pack may set: only these, never anything about users or security. */
	const SITE_OPTIONS = [ 'blogname', 'blogdescription', 'elementor_google_font', 'elementor_font_display', 'elementor_disable_color_schemes', 'elementor_disable_typography_schemes', 'elementor_load_fa4_shim' ];

	private static function apply_site( array $site, array $keys, array $map = [] ) {
		if ( ! empty( $site['front_page'] ) && isset( $keys[ sanitize_key( $site['front_page'] ) ] ) ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', (int) $keys[ sanitize_key( $site['front_page'] ) ] );
		}
		// Site icon (favicon / app icon): an image of the pack, e.g. "images/site-icon.png" (square, 512 px or more).
		if ( ! empty( $site['site_icon'] ) && is_string( $site['site_icon'] ) ) {
			$k   = self::pack_key( $site['site_icon'] );
			$aid = $k && isset( $map[ $k ] ) ? (int) $map[ $k ]['id'] : 0;
			if ( $aid && wp_attachment_is_image( $aid ) ) {
				update_option( 'site_icon', $aid );
			}
		}
		foreach ( (array) ( $site['options'] ?? [] ) as $k => $v ) {
			if ( in_array( $k, self::SITE_OPTIONS, true ) && is_scalar( $v ) ) { update_option( $k, sanitize_text_field( (string) $v ) ); }
		}
		if ( ! empty( $site['wakoo'] ) && is_array( $site['wakoo'] ) ) {
			self::apply_wakoo( $site['wakoo'], $keys );
		}
	}

	/**
	 * Wakoo settings a pack may set, so an imported site works without manual steps. Closed list,
	 * merged into what the site already has; never API keys, IDs of external accounts, emails or users.
	 *   languages:      [ [ code, name ], … ]  first = master (Wakoo Idiomas)
	 *   public_default: code visitors land on
	 *   members:        { template: <pack key>, account: <pack key>, slug, max_gallery }
	 *   seo:            { consent_mode, consent_region, org_name, meta_desc, og, twitter, jsonld }
 *   territorio:     see modules/territorio (templates and pages by pack key, map centre, code prefix)
	 */
	private static function apply_wakoo( array $w, array $keys ) {
		$id_of = function ( $key ) use ( $keys ) { $k = sanitize_key( (string) $key ); return isset( $keys[ $k ] ) ? (int) $keys[ $k ] : 0; };

		if ( ! empty( $w['languages'] ) && is_array( $w['languages'] ) && class_exists( '\Wakoo\Modules\Idiomas\Module' ) ) {
			$lines = [];
			foreach ( $w['languages'] as $l ) {
				$code = sanitize_key( is_array( $l ) ? ( $l[0] ?? '' ) : (string) $l );
				$name = sanitize_text_field( is_array( $l ) ? ( $l[1] ?? '' ) : '' );
				if ( $code ) { $lines[ $code ] = $code . '|' . ( '' !== $name ? $name : strtoupper( $code ) ); }
			}
			if ( $lines ) {
				update_option( \Wakoo\Modules\Idiomas\Module::OPTION, implode( "\n", array_slice( $lines, 0, 20 ) ) );
			}
		}
		if ( ! empty( $w['public_default'] ) && class_exists( '\Wakoo\Modules\Idiomas\Module' ) ) {
			$def = sanitize_key( (string) $w['public_default'] );
			if ( isset( \Wakoo\Modules\Idiomas\Module::languages()[ $def ] ) ) {
				update_option( \Wakoo\Modules\Idiomas\Module::PUBDEF, $def );
			}
		}

		if ( ! empty( $w['members'] ) && is_array( $w['members'] ) && class_exists( '\Wakoo\Modules\Members\Module' ) ) {
			$m   = $w['members'];
			$opt = \Wakoo\Modules\Members\Module::settings();
			if ( ! empty( $m['template'] ) && $id_of( $m['template'] ) ) { $opt['template'] = $id_of( $m['template'] ); }
			if ( ! empty( $m['account'] ) && $id_of( $m['account'] ) ) { $opt['account'] = $id_of( $m['account'] ); }
			if ( ! empty( $m['slug'] ) ) { $opt['slug'] = sanitize_title( (string) $m['slug'] ) ?: $opt['slug']; }
			if ( ! empty( $m['max_gallery'] ) ) { $opt['max_gallery'] = min( 40, max( 1, (int) $m['max_gallery'] ) ); }
			update_option( \Wakoo\Modules\Members\Module::OPTION, $opt );
		}

		if ( ! empty( $w['places'] ) && is_array( $w['places'] ) && class_exists( '\Wakoo\Modules\Places\Module' ) ) {
			$opt = \Wakoo\Modules\Places\Module::settings();
			if ( ! empty( $w['places']['page'] ) && $id_of( $w['places']['page'] ) ) { $opt['page'] = $id_of( $w['places']['page'] ); }
			update_option( \Wakoo\Modules\Places\Module::OPTION, $opt );
		}

		if ( ! empty( $w['seo'] ) && is_array( $w['seo'] ) && class_exists( '\Wakoo\Modules\Seo\Module' ) ) {
			$s   = $w['seo'];
			$opt = \Wakoo\Modules\Seo\Module::opts();
			if ( in_array( $s['consent_mode'] ?? '', [ 'off', 'basic', 'advanced' ], true ) ) { $opt['consent_mode'] = $s['consent_mode']; }
			if ( in_array( $s['consent_region'] ?? '', [ 'all', 'eu' ], true ) ) { $opt['consent_region'] = $s['consent_region']; }
			if ( ! empty( $s['org_name'] ) ) { $opt['org_name'] = sanitize_text_field( (string) $s['org_name'] ); }
			foreach ( [ 'meta_desc', 'og', 'twitter', 'jsonld', 'llms', 'ai_bots' ] as $k ) {
				if ( isset( $s[ $k ] ) ) { $opt[ $k ] = empty( $s[ $k ] ) ? 0 : 1; }
			}
			update_option( \Wakoo\Modules\Seo\Module::OPTION, $opt );
		}
		// Modules with their own pack settings (e.g. `territorio`) read them here.
		do_action( 'wakoo_portable_site', $w, $keys );
	}

	/* ---------- pack styles (global CSS + self-hosted fonts that travel with a pack) ---------- */

	const STYLES_OPTION = 'wakoo_pack_styles';

	public static function print_styles() {
		$all = get_option( self::STYLES_OPTION, [] );
		if ( ! is_array( $all ) ) { return; }
		foreach ( $all as $pack => $css ) {
			if ( is_string( $css ) && '' !== trim( $css ) ) {
				echo "\n<style id=\"wakoo-pack-" . esc_attr( $pack ) . "\">\n" . $css . "\n</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- admin-imported CSS (unfiltered_html).
			}
		}
	}

	public static function handle_styles() {
		if ( ! current_user_can( 'unfiltered_html' ) || ! check_admin_referer( 'wakoo_pack_styles' ) ) { wp_die( esc_html__( 'No autorizado.', 'wakoo' ) ); }
		$all = (array) get_option( self::STYLES_OPTION, [] );
		foreach ( (array) wp_unslash( $_POST['wakoo_css'] ?? [] ) as $pack => $css ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$pack = sanitize_key( $pack );
			if ( isset( $all[ $pack ] ) ) { $all[ $pack ] = str_ireplace( '</style', '', (string) $css ); }
		}
		foreach ( (array) ( $_POST['wakoo_css_del'] ?? [] ) as $pack ) { unset( $all[ sanitize_key( $pack ) ] ); } // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		update_option( self::STYLES_OPTION, $all );
		wp_safe_redirect( add_query_arg( [ 'page' => 'wakoo-portable', 'msg' => 'css' ], admin_url( 'admin.php' ) ) );
		exit;
	}

	/** Font files are written to uploads/wakoo-packs/<pack>/fonts/ after a magic-byte check (woff/woff2 only). */
	private static function save_font( $pack, $name, $bytes ) {
		$magic = substr( $bytes, 0, 4 );
		if ( 'wOF2' !== $magic && 'wOFF' !== $magic ) { return false; }
		$up  = wp_get_upload_dir();
		$rel = 'wakoo-packs/' . $pack . '/fonts/';
		if ( ! wp_mkdir_p( $up['basedir'] . '/' . $rel ) ) { return false; }
		$file = sanitize_file_name( basename( $name ) );
		file_put_contents( $up['basedir'] . '/' . $rel . $file, $bytes ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return $up['baseurl'] . '/' . $rel . $file;
	}

	/* ---------- zip packs ---------- */

	/** Normalise a path found inside a pack; false when it is not a safe relative path. */
	private static function safe_path( $name ) {
		$name = str_replace( '\\', '/', (string) $name );
		if ( '' === $name || '/' === substr( $name, -1 ) || false !== strpos( $name, "\0" ) ) { return false; }
		$name = ltrim( preg_replace( '#^\./#', '', $name ), '/' );
		foreach ( explode( '/', $name ) as $seg ) {
			if ( '' === $seg || '.' === $seg || '..' === $seg || '.' === $seg[0] ) { return false; }
		}
		return preg_match( '#^[\p{L}\p{N}_\-./ ()]+$#u', $name ) ? $name : false;
	}

	/** Replace pack media references in one item by the imported attachment URLs/ids. */
	private static function map_media( $node, array $map ) {
		if ( is_string( $node ) ) {
			$k = self::pack_key( $node );
			if ( $k && isset( $map[ $k ] ) ) { return $map[ $k ]['url']; }
			if ( false !== strpos( $node, 'images/' ) || false !== strpos( $node, 'media/' ) || false !== strpos( $node, self::PACK_SCHEME ) ) {
				foreach ( $map as $path => $m ) {
					$node = str_replace( [ self::PACK_SCHEME . $path, '"' . $path . '"', "'" . $path . "'", '(' . $path . ')' ], [ $m['url'], '"' . $m['url'] . '"', "'" . $m['url'] . "'", '(' . $m['url'] . ')' ], $node );
				}
			}
			return $node;
		}
		if ( ! is_array( $node ) ) { return $node; }
		if ( isset( $node['url'] ) && is_string( $node['url'] ) ) {
			$k = self::pack_key( $node['url'] );
			if ( $k && isset( $map[ $k ] ) ) {
				$node['url'] = $map[ $k ]['url'];
				$node['id']  = $map[ $k ]['id'];
				if ( isset( $node['source'] ) ) { $node['source'] = 'library'; }
			}
		}
		foreach ( $node as $key => $val ) {
			if ( 'url' === $key && is_string( $val ) ) { continue; }
			$node[ $key ] = self::map_media( $val, $map );
		}
		return $node;
	}

	private static function pack_key( $v ) {
		if ( ! is_string( $v ) || strlen( $v ) > 300 ) { return false; }
		if ( 0 === strpos( $v, self::PACK_SCHEME ) ) { $v = substr( $v, strlen( self::PACK_SCHEME ) ); }
		return self::safe_path( $v );
	}

	/**
	 * Import a Wakoo pack (.zip): wakoo-pack.json (same format as the .json
	 * export) and/or Elementor template .json files, plus images/media that are
	 * added to the media library and linked into the templates.
	 *
	 * @return array|\WP_Error { items: [], media: int, skipped: [] }
	 */
	public static function import_zip( $file, array $opts = [] ) {
		self::raise_limits();
		if ( ! class_exists( '\ZipArchive' ) ) { return new \WP_Error( 'nozip', __( 'Este servidor no tiene la extensión ZipArchive de PHP.', 'wakoo' ) ); }
		$zip = new \ZipArchive();
		if ( true !== $zip->open( $file ) ) { return new \WP_Error( 'zip', __( 'No se pudo abrir el zip.', 'wakoo' ) ); }
		if ( $zip->numFiles < 1 || $zip->numFiles > self::ZIP_MAX_ENTRIES ) { $zip->close(); return new \WP_Error( 'zip', __( 'El zip está vacío o tiene demasiados archivos.', 'wakoo' ) ); }

		$total = 0; $json = []; $media = []; $skipped = []; $fonts = []; $css_files = [];
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$st = $zip->statIndex( $i );
			if ( ! $st || '/' === substr( $st['name'], -1 ) ) { continue; }
			$name = self::safe_path( $st['name'] );
			if ( false === $name ) { $skipped[] = $st['name']; continue; }
			$total += (int) $st['size'];
			if ( $st['size'] > self::ZIP_MAX_FILE || $total > self::ZIP_MAX_TOTAL ) { $zip->close(); return new \WP_Error( 'zip', __( 'El contenido del zip es demasiado grande.', 'wakoo' ) ); }
			$ext = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
			if ( 'json' === $ext ) { $json[ $name ] = $i; }
			elseif ( in_array( $ext, [ 'woff2', 'woff' ], true ) ) { $fonts[ $name ] = $i; }
			elseif ( 'css' === $ext ) { $css_files[ $name ] = $i; }
			elseif ( isset( self::PACK_MEDIA[ $ext ] ) ) { $media[ $name ] = [ $i, $ext ]; }
			elseif ( ! in_array( $ext, [ 'md', 'txt', 'html' ], true ) ) { $skipped[] = $name; }
		}

		$packinfo = [];
		// 1) Templates (read first: the pack id and media alts live there).
		$items = [];
		foreach ( $json as $name => $idx ) {
			$dec = json_decode( (string) $zip->getFromIndex( $idx ), true );
			if ( ! is_array( $dec ) ) { $skipped[] = $name; continue; }
			if ( ( $dec['format'] ?? '' ) === self::FORMAT ) {
				foreach ( (array) ( $dec['items'] ?? [] ) as $it ) { $items[] = $it; }
				if ( ! $packinfo ) { $packinfo = $dec; }
			} elseif ( isset( $dec['content'] ) && is_array( $dec['content'] ) ) { // Elementor's own template export.
				$items[] = [
					'title' => $dec['title'] ?? pathinfo( $name, PATHINFO_FILENAME ),
					'type'  => 'elementor_library',
					'meta'  => [
						'_elementor_data'          => $dec['content'],
						'_elementor_page_settings' => $dec['page_settings'] ?? [],
						'_elementor_template_type' => $dec['type'] ?? 'page',
					],
				];
			} else { $skipped[] = $name; }
		}
		// 2) Media -> library (re-imports of the same pack reuse the files).
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		$map = []; $nmedia = 0;
		$pack = sanitize_key( $packinfo['pack'] ?? '' );
		$minfo = (array) ( $packinfo['media'] ?? [] );
		$same  = ( $packinfo['origin'] ?? '' ) === self::site_tag();
		foreach ( $media as $name => $info ) {
			if ( $same && ! empty( $minfo[ $name ]['file'] ) ) {
				$prev = get_posts( [ 'post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_wp_attached_file', 'meta_value' => (string) $minfo[ $name ]['file'] ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
				if ( $prev ) { $map[ $name ] = [ 'id' => (int) $prev[0], 'url' => wp_get_attachment_url( $prev[0] ) ]; self::media_folder( (int) $prev[0], $minfo[ $name ]['folder'] ?? null ); continue; }
			}
			if ( $pack ) {
				$prev = get_posts( [ 'post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_wakoo_pack_file', 'meta_value' => $pack . ':' . $name ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
				if ( $prev ) { $map[ $name ] = [ 'id' => (int) $prev[0], 'url' => wp_get_attachment_url( $prev[0] ) ]; self::media_folder( (int) $prev[0], $minfo[ $name ]['folder'] ?? null ); continue; }
			}
			$bytes = $zip->getFromIndex( $info[0] );
			if ( false === $bytes || '' === $bytes ) { continue; }
			$tmp = wp_tempnam( basename( $name ) );
			file_put_contents( $tmp, $bytes ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			$ft = wp_check_filetype_and_ext( $tmp, basename( $name ), self::PACK_MEDIA );
			if ( empty( $ft['type'] ) && 'avif' !== $info[1] ) { @unlink( $tmp ); $skipped[] = $name; continue; } // phpcs:ignore
			$sf  = [ 'name' => sanitize_file_name( basename( $name ) ), 'tmp_name' => $tmp ];
			$res = wp_handle_sideload(
				$sf,
				[ 'test_form' => false, 'mimes' => array_merge( self::PACK_MEDIA, [ 'avif' => 'image/avif' ] ) ]
			);
			if ( ! empty( $res['error'] ) || empty( $res['file'] ) ) { @unlink( $tmp ); $skipped[] = $name; continue; } // phpcs:ignore
			$aid = wp_insert_attachment( [
				'post_mime_type' => $res['type'],
				'post_title'     => sanitize_text_field( pathinfo( $name, PATHINFO_FILENAME ) ),
				'post_status'    => 'inherit',
			], $res['file'] );
			if ( is_wp_error( $aid ) || ! $aid ) { continue; }
			wp_update_attachment_metadata( $aid, wp_generate_attachment_metadata( $aid, $res['file'] ) );
			$alt = isset( $opts['alts'][ $name ] ) ? $opts['alts'][ $name ] : ( $minfo[ $name ]['alt'] ?? '' );
			if ( $pack ) { update_post_meta( $aid, '_wakoo_pack_file', $pack . ':' . $name ); }
			if ( ! empty( $minfo[ $name ]['caption'] ) ) { wp_update_post( [ 'ID' => $aid, 'post_excerpt' => sanitize_text_field( $minfo[ $name ]['caption'] ) ] ); }
			if ( '' !== $alt ) { update_post_meta( $aid, '_wp_attachment_image_alt', sanitize_text_field( $alt ) ); }
			$map[ $name ] = [ 'id' => (int) $aid, 'url' => wp_get_attachment_url( $aid ) ];
			self::media_folder( (int) $aid, $minfo[ $name ]['folder'] ?? null );
			$nmedia++;
		}

		// 3) Pack styles: self-hosted fonts and one global stylesheet, kept per pack id (editable on this screen).
		$site = (array) ( $packinfo['site'] ?? [] );
		if ( $pack && ( $fonts || ! empty( $site['css_file'] ) || ! empty( $site['css'] ) ) ) {
			$fmap = [];
			foreach ( $fonts as $name => $idx ) {
				$u = self::save_font( $pack, $name, (string) $zip->getFromIndex( $idx ) );
				if ( $u ) { $fmap[ self::PACK_SCHEME . $name ] = $u; } else { $skipped[] = $name; }
			}
			$css = (string) ( $site['css'] ?? '' );
			$cf  = isset( $site['css_file'] ) ? self::safe_path( $site['css_file'] ) : false;
			if ( $cf && isset( $css_files[ $cf ] ) ) { $css .= "\n" . (string) $zip->getFromIndex( $css_files[ $cf ] ); }
			$css = str_ireplace( '</style', '', strtr( $css, $fmap ) );
			foreach ( $map as $path => $m ) { $css = str_replace( self::PACK_SCHEME . $path, $m['url'], $css ); }
			$all = (array) get_option( self::STYLES_OPTION, [] );
			$all[ $pack ] = $css;
			update_option( self::STYLES_OPTION, $all );
		}
		$zip->close();
		if ( ! $items ) { return new \WP_Error( 'empty', __( 'El zip no contiene plantillas de Wakoo (wakoo-pack.json) ni plantillas de Elementor (.json).', 'wakoo' ) ); }
		$res = self::import_data( [ 'format' => self::FORMAT, 'version' => self::VERSION, 'items' => $items, 'menus' => $packinfo['menus'] ?? [] ], array_merge( [ 'replace' => true ], $opts, [ 'pack' => true, 'map' => $map, 'pack_id' => $pack, 'site' => $site ] ) );
		if ( is_wp_error( $res ) ) { return $res; }
		return [ 'items' => $res, 'media' => $nmedia, 'skipped' => $skipped ];
	}

	/** Export selected items as a zip pack with their images (re-importable by import_zip). */
	public static function build_zip( array $ids, $snapshot = '', $snap_url = '' ) {
		$data = self::build_export( $ids );
		$up   = wp_get_upload_dir();
		$base = trailingslashit( $up['baseurl'] );
		$dir  = trailingslashit( $up['basedir'] );
		$files = []; // zip path => absolute file.
		$json  = wp_json_encode( $data['items'], JSON_UNESCAPED_SLASHES );
		if ( preg_match_all( '#' . preg_quote( $base, '#' ) . '([A-Za-z0-9_\-./ ()]+\.(?:jpe?g|png|gif|webp|avif|mp4|webm|mp3|ogg|wav|pdf))#i', str_replace( '\/', '/', $json ), $m ) ) {
			foreach ( array_unique( $m[1] ) as $rel ) {
				$abs = $dir . $rel;
				if ( false !== strpos( $rel, '..' ) || ! is_file( $abs ) ) { continue; }
				$aid   = attachment_url_to_postid( $base . $rel );
				$fpath = [];
				if ( $aid && class_exists( '\Wakoo\Modules\Folders\Module' ) ) {
					$F     = '\Wakoo\Modules\Folders\Module';
					$fpath = $F::path_of( $F::folder_of( $aid, 'attachment' ), 'attachment' );
				}
				// The zip keeps the same folders as Wakoo Carpetas: images/paginas/inicio/foto.webp.
				$sub = $fpath ? implode( '/', array_map( 'sanitize_title', $fpath ) ) . '/' : '';
				$zp  = 'images/' . $sub . sanitize_file_name( basename( $rel ) );
				if ( isset( $files[ $zp ] ) && $files[ $zp ] !== $abs ) { $zp = 'images/' . $sub . substr( md5( $rel ), 0, 6 ) . '-' . sanitize_file_name( basename( $rel ) ); }
				$files[ $zp ] = $abs;
				$data['media'][ $zp ] = array_filter( [ 'file' => $rel, 'alt' => $aid ? (string) get_post_meta( $aid, '_wp_attachment_image_alt', true ) : '', 'folder' => $fpath ] );
				$data['items'] = json_decode( str_replace( [ $base . $rel, str_replace( '/', '\/', $base . $rel ) ], [ self::PACK_SCHEME . $zp, str_replace( '/', '\/', self::PACK_SCHEME . $zp ) ], wp_json_encode( $data['items'], JSON_UNESCAPED_SLASHES ) ), true );
			}
		}
		$data['source'] = '';
		$data['origin'] = self::site_tag();
		$tmp = wp_tempnam( 'wakoo-pack' );
		$zip = new \ZipArchive();
		$zip->open( $tmp, \ZipArchive::OVERWRITE );
		$zip->addFromString( self::PACK_JSON, wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT ) );
		$zip->addFromString( 'README.md', "# Paquete Wakoo\n\nImporta este zip en Wakoo > Exportar / importar > Importar paquete (.zip).\nLas imágenes de la carpeta images/ se añaden a la biblioteca de medios y se enlazan solas.\n\nCopia de seguridad: en la misma web, con la casilla «actualizar» marcada, el zip restaura las páginas originales (mismo diseño, textos e imágenes). Sin marcarla, crea copias nuevas.\n\nwakoo-pack.json tiene el diseño completo (contenedores, widgets y sus ajustes) para analizarlo o hacer otra versión.\n" );
		foreach ( $files as $zp => $abs ) { $zip->addFile( $abs, $zp ); }
		// One page: add how it is made (structure, texts, styles), whatever builder made it.
		if ( 1 === count( $ids ) ) {
			$an = Analysis::build( (int) $ids[0], $snapshot, $snap_url, array_values( $files ) );
			foreach ( $an['strings'] as $zp => $str ) { $zip->addFromString( $zp, $str ); }
			foreach ( $an['files'] as $zp => $abs ) { $zip->addFile( $abs, $zp ); }
		}
		$zip->close();
		return $tmp;
	}

	public static function handle_export_zip() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'wakoo_export' ) ) { wp_die( esc_html__( 'No autorizado.', 'wakoo' ) ); }
		if ( ! class_exists( '\ZipArchive' ) ) { wp_die( esc_html__( 'Este servidor no tiene ZipArchive.', 'wakoo' ) ); }
		$ids = isset( $_POST['ids'] ) ? array_map( 'intval', (array) wp_unslash( $_POST['ids'] ) ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( ! $ids ) { wp_safe_redirect( add_query_arg( [ 'page' => 'wakoo-portable', 'msg' => 'none' ], admin_url( 'admin.php' ) ) ); exit; }
		self::send_zip( self::build_zip( $ids ), 'wakoo-pack-' . gmdate( 'Y-m-d' ) . '.zip' );
	}

	private static function send_zip( $tmp, $filename ) {
		nocache_headers();
		header( 'Content-Type: application/zip' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Content-Length: ' . filesize( $tmp ) );
		readfile( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		@unlink( $tmp ); // phpcs:ignore
		exit;
	}

	/* ---------- "Descargar esta página" ---------- */

	private static function can_download( $id ) {
		$p = $id ? get_post( $id ) : null;
		return $p && ( in_array( $p->post_type, self::TYPES, true ) || is_post_type_viewable( $p->post_type ) ) && 'trash' !== $p->post_status
			&& 'attachment' !== $p->post_type && current_user_can( 'edit_post', $p->ID );
	}

	private static function download_url( $id = 0 ) {
		$args = [ 'action' => 'wakoo_download', '_wpnonce' => wp_create_nonce( 'wakoo_download' ) ];
		if ( $id ) { $args['post'] = (int) $id; }
		return add_query_arg( $args, admin_url( 'admin-post.php' ) );
	}

	/** The saved version of one page/template/popup as a .zip pack (design, texts and images). */
	public static function handle_download() {
		$id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! check_admin_referer( 'wakoo_download' ) || ! self::can_download( $id ) ) { wp_die( esc_html__( 'No autorizado.', 'wakoo' ) ); }
		if ( ! class_exists( '\ZipArchive' ) ) { wp_die( esc_html__( 'Este servidor no tiene ZipArchive.', 'wakoo' ) ); }
		$slug = sanitize_file_name( get_post_field( 'post_name', $id ) ?: 'pagina-' . $id );
		$snap = isset( $_POST['snapshot'] ) ? (string) wp_unslash( $_POST['snapshot'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- page HTML, only written into the zip.
		$from = isset( $_POST['snap_url'] ) ? esc_url_raw( wp_unslash( $_POST['snap_url'] ) ) : '';
		self::send_zip( self::build_zip( [ $id ], $snap, $from ), 'wakoo-' . $slug . '-' . wp_date( 'Y-m-d-Hi' ) . '.zip' );
	}

	public static function row_action( $actions, $post ) {
		if ( self::can_download( $post->ID ) ) {
			$actions['wakoo_download'] = '<a href="' . esc_url( self::download_url( $post->ID ) ) . '" title="' . esc_attr__( 'Descarga la página como paquete .zip de Wakoo: para analizarla, hacer otra versión o restaurarla.', 'wakoo' ) . '">' . esc_html__( 'Descargar', 'wakoo' ) . '</a>';
		}
		return $actions;
	}

	public static function admin_bar( $bar ) {
		$id = is_admin() ? ( isset( $_GET['post'] ) ? (int) $_GET['post'] : 0 ) : ( is_singular() ? get_queried_object_id() : 0 ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! self::can_download( $id ) ) { return; }
		if ( ! is_admin() ) { add_action( 'wp_footer', [ __CLASS__, 'snapshot_script' ], 99 ); }
		$bar->add_node( [
			'id'     => 'wakoo_download',
			'parent' => $bar->get_node( 'wakoo_edit' ) ? 'wakoo_edit' : false,
			'title'  => esc_html__( 'Descargar esta página (.zip)', 'wakoo' ),
			'href'   => self::download_url( $id ),
			'meta'   => [ 'title' => __( 'Diseño completo e imágenes, para analizarla, hacer otra versión o restaurarla.', 'wakoo' ) ],
		] );
	}

	/** Viewing the page: the download sends the page exactly as it is shown (any builder), for the analysis. */
	public static function snapshot_script() {
		?>
		<script>
		( function () {
			var a = document.querySelector( '#wp-admin-bar-wakoo_download > a' );
			if ( ! a ) { return; }
			a.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				var copy = document.documentElement.cloneNode( true );
				[ '#wpadminbar', '#wp-admin-bar-wakoo_download' ].forEach( function ( s ) { var n = copy.querySelector( s ); if ( n ) { n.remove(); } } );
				var f = document.createElement( 'form' );
				f.method = 'post';
				f.action = a.href;
				f.style.display = 'none';
				[ [ 'snapshot', '<!DOCTYPE html>
' + copy.outerHTML ], [ 'snap_url', window.location.href ] ].forEach( function ( v ) {
					var t = document.createElement( 'textarea' );
					t.name = v[ 0 ];
					t.value = v[ 1 ];
					f.appendChild( t );
				} );
				document.body.appendChild( f );
				f.submit();
				setTimeout( function () { f.remove(); }, 3000 );
			} );
		}() );
		</script>
		<?php
	}

	public static function editor_script() {
		wp_enqueue_script( 'wakoo-portable-editor', plugins_url( 'assets/editor.js', __FILE__ ), [ 'jquery' ], WAKOO_VERSION, true );
		wp_localize_script( 'wakoo-portable-editor', 'wakooDownload', [
			'url'   => self::download_url(),
			'label' => __( 'Descargar esta página (.zip)', 'wakoo' ),
			'dirty' => __( 'Se descarga la última versión guardada y hay cambios sin guardar. ¿Descargar igualmente?', 'wakoo' ),
		] );
	}

	/* ---------- admin handlers ---------- */

	public static function handle_export() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'wakoo_export' ) ) {
			wp_die( esc_html__( 'No autorizado.', 'wakoo' ) );
		}
		$ids = isset( $_POST['ids'] ) ? array_map( 'intval', (array) wp_unslash( $_POST['ids'] ) ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( ! $ids ) {
			wp_safe_redirect( add_query_arg( [ 'page' => 'wakoo-portable', 'msg' => 'none' ], admin_url( 'admin.php' ) ) );
			exit;
		}
		$out = self::build_export( $ids );
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="wakoo-export-' . gmdate( 'Y-m-d' ) . '.json"' );
		echo wp_json_encode( $out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	/** Keep only thumbnail/medium/large when importing packs. */
	public static function light_sizes( $sizes ) {
		return array_intersect_key( (array) $sizes, array_flip( [ 'thumbnail', 'medium', 'large' ] ) );
	}

	public static function handle_import() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'wakoo_import' ) ) {
			wp_die( esc_html__( 'No autorizado.', 'wakoo' ) );
		}
		$back = function ( $msg, $n = 0 ) {
			wp_safe_redirect( add_query_arg( [ 'page' => 'wakoo-portable', 'msg' => $msg, 'n' => $n ], admin_url( 'admin.php' ) ) );
			exit;
		};
		if ( ! current_user_can( 'unfiltered_html' ) ) { $back( 'caps' ); }
		$f = $_FILES['wakoo_file'] ?? null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( ! $f || ! empty( $f['error'] ) || empty( $f['tmp_name'] ) || ! is_uploaded_file( $f['tmp_name'] ) ) { $back( 'nofile' ); }
		$ext = strtolower( pathinfo( (string) $f['name'], PATHINFO_EXTENSION ) );
		$publish = ! empty( $_POST['wakoo_publish'] );
		if ( 'zip' === $ext ) {
			if ( $f['size'] > self::ZIP_MAX_BYTES ) { $back( 'big' ); }
			// Big packs resize many images: lift the time/memory limits so a slow host does not die half way ("critical error").
			ignore_user_abort( true );
			if ( function_exists( 'set_time_limit' ) ) { @set_time_limit( 0 ); } // phpcs:ignore
			wp_raise_memory_limit( 'admin' );
			wp_raise_memory_limit( 'image' );
			// Only the sizes a page really needs: it makes the import several times faster.
			add_filter( 'intermediate_image_sizes_advanced', [ __CLASS__, 'light_sizes' ] );
			try {
				$res = self::import_zip( $f['tmp_name'], [ 'publish' => $publish, 'replace' => ! empty( $_POST['wakoo_replace'] ) ] );
			} catch ( \Throwable $e ) {
				error_log( '[Wakoo] import_zip failed: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() ); // phpcs:ignore
				$res = new \WP_Error( 'fail', $e->getMessage() );
			}
			remove_filter( 'intermediate_image_sizes_advanced', [ __CLASS__, 'light_sizes' ] );
			if ( is_wp_error( $res ) ) { $back( 'fail' === $res->get_error_code() ? 'zip_fail' : 'zip_' . $res->get_error_code() ); }
			set_transient( 'wakoo_pack_report_' . get_current_user_id(), [ 'items' => $res['items'], 'media' => $res['media'], 'skipped' => array_slice( $res['skipped'], 0, 30 ) ], 300 );
			$back( 'okzip', count( $res['items'] ) );
		}
		if ( $f['size'] > self::MAX_BYTES ) { $back( 'big' ); }
		$data = json_decode( (string) file_get_contents( $f['tmp_name'] ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$res  = self::import_data( $data, [ 'publish' => $publish ] );
		if ( is_wp_error( $res ) ) { $back( 'bad' ); }
		$back( 'ok', count( $res ) );
	}

	/* ---------- page ---------- */

	/**
	 * "Exportar", folded so it does not fill the page: by type and, inside, by folder
	 * (Wakoo Carpetas), with search, "select all" per group and the number chosen.
	 */
	private static function export_box() {
		$posts = get_posts( [
			'post_type'      => self::TYPES,
			'post_status'    => [ 'publish', 'draft', 'private' ],
			'posts_per_page' => 1000,
			'meta_key'       => '_elementor_data', // phpcs:ignore WordPress.DB.SlowDBQuery
			'orderby'        => 'title',
			'order'          => 'ASC',
		] );
		$names   = [ 'page' => __( 'Páginas', 'wakoo' ), 'post' => __( 'Entradas', 'wakoo' ), 'elementor_library' => __( 'Plantillas', 'wakoo' ), 'wakoo_popup' => __( 'Popups', 'wakoo' ) ];
		$folders = class_exists( '\Wakoo\Modules\Folders\Module' ) ? '\Wakoo\Modules\Folders\Module' : '';
		$by_type = [];
		foreach ( $posts as $p ) { $by_type[ $p->post_type ][] = $p; }

		echo '<details class="wk-ex-box"><summary><span class="wk-ex-sum-title">' . esc_html__( 'Exportar', 'wakoo' ) . '</span> <span class="description">' . esc_html( sprintf( /* translators: %d: items */ __( '%d elementos hechos con el editor. Ábrelo para elegir qué descargar.', 'wakoo' ), count( $posts ) ) ) . '</span></summary>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="wk-ex-form">';
		wp_nonce_field( 'wakoo_export' );
		echo '<input type="hidden" name="action" value="wakoo_export">';
		if ( ! $posts ) {
			echo '<p>' . esc_html__( 'Todavía no hay contenido hecho con el editor.', 'wakoo' ) . '</p></form></details>';
			return;
		}
		echo '<p class="wk-ex-tools"><input type="search" class="wk-ex-q" placeholder="' . esc_attr__( 'Buscar por título…', 'wakoo' ) . '" aria-label="' . esc_attr__( 'Buscar por título', 'wakoo' ) . '"> '
			. '<button type="button" class="button-link wk-ex-open">' . esc_html__( 'Abrir todo', 'wakoo' ) . '</button> · <button type="button" class="button-link wk-ex-close">' . esc_html__( 'Cerrar todo', 'wakoo' ) . '</button></p>';
		foreach ( $by_type as $type => $list ) {
			// Groups: one per folder (with its path), then "Sin carpeta".
			$groups = [];
			foreach ( $list as $p ) {
				$key = 'none';
				if ( $folders && taxonomy_exists( $folders::tax( $type ) ) ) {
					$t = wp_get_object_terms( $p->ID, $folders::tax( $type ), [ 'fields' => 'ids' ] );
					$key = ( ! is_wp_error( $t ) && $t ) ? 'f' . $t[0] : 'none';
				}
				$groups[ $key ][] = $p;
			}
			$labels = [];
			foreach ( array_keys( $groups ) as $key ) {
				if ( 'none' === $key ) { $labels[ $key ] = '📄 ' . __( 'Sin carpeta', 'wakoo' ); continue; }
				$path = [];
				$tid  = (int) substr( $key, 1 );
				while ( $tid ) { $term = get_term( $tid ); if ( ! $term || is_wp_error( $term ) ) { break; } array_unshift( $path, $term->name ); $tid = (int) $term->parent; }
				$labels[ $key ] = '📁 ' . implode( ' › ', $path );
			}
			uksort( $groups, function ( $x, $y ) use ( $labels ) { return 'none' === $x ? 1 : ( 'none' === $y ? -1 : strcasecmp( $labels[ $x ], $labels[ $y ] ) ); } );
			echo '<details class="wk-ex-type"' . ( 1 === count( $by_type ) ? ' open' : '' ) . '><summary><label class="wk-ex-all"><input type="checkbox" aria-label="' . esc_attr( sprintf( /* translators: %s: type */ __( 'Elegir todo: %s', 'wakoo' ), $names[ $type ] ?? $type ) ) . '"></label> <strong>' . esc_html( $names[ $type ] ?? $type ) . '</strong> <span class="wk-ex-n">' . count( $list ) . '</span></summary>';
			foreach ( $groups as $key => $items ) {
				$one = 1 === count( $groups );
				echo '<details class="wk-ex-folder"' . ( $one ? ' open' : '' ) . '><summary><label class="wk-ex-all"><input type="checkbox" aria-label="' . esc_attr( sprintf( /* translators: %s: folder */ __( 'Elegir todo: %s', 'wakoo' ), $labels[ $key ] ) ) . '"></label> ' . esc_html( $labels[ $key ] ) . ' <span class="wk-ex-n">' . count( $items ) . '</span></summary><ul>';
				foreach ( $items as $p ) {
					$st = 'publish' === $p->post_status ? '' : ' <em>(' . esc_html( $p->post_status ) . ')</em>';
					echo '<li data-title="' . esc_attr( strtolower( $p->post_title ) ) . '"><label><input type="checkbox" class="wk-ex" name="ids[]" value="' . (int) $p->ID . '"> ' . esc_html( $p->post_title ?: '#' . $p->ID ) . $st . '</label></li>';
				}
				echo '</ul></details>';
			}
			echo '</details>';
		}
		echo '<div class="wk-ex-bar"><span class="wk-ex-count">' . esc_html__( '0 elegidos', 'wakoo' ) . '</span> ';
		submit_button( __( 'Descargar archivo .json', 'wakoo' ), 'primary', 'submit', false );
		echo ' <button type="submit" class="button" formaction="' . esc_url( admin_url( 'admin-post.php?action=wakoo_export_zip' ) ) . '" name="action" value="wakoo_export_zip">' . esc_html__( 'Descargar paquete .zip con imágenes', 'wakoo' ) . '</button></div>';
		echo '</form></details>';
		?>
		<style>
		.wk-ex-box{max-width:820px;background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:0 16px;margin:18px 0}
		.wk-ex-box>summary{cursor:pointer;padding:14px 0;list-style:revert}
		.wk-ex-sum-title{font-size:1.3em;font-weight:600;margin-right:6px}
		.wk-ex-form{padding-bottom:14px}
		.wk-ex-tools{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
		.wk-ex-q{min-width:260px}
		.wk-ex-type,.wk-ex-folder{border:1px solid #f0f0f1;border-radius:8px;margin:8px 0;padding:0 10px;background:#fcfcfc}
		.wk-ex-folder{background:#fff;margin-left:14px}
		.wk-ex-type>summary,.wk-ex-folder>summary{cursor:pointer;padding:9px 0;display:flex;align-items:center;gap:6px}
		.wk-ex-n{background:#f0f0f1;border-radius:999px;padding:0 8px;font-size:12px;color:#50575e}
		.wk-ex-folder ul{margin:0 0 10px;padding:0 0 0 26px;columns:2;column-gap:24px}
		.wk-ex-folder li{margin:4px 0;break-inside:avoid}
		.wk-ex-folder li[hidden]{display:none}
		.wk-ex-bar{position:sticky;bottom:0;background:#fff;border-top:1px solid #dcdcde;padding:10px 0;margin-top:10px;display:flex;align-items:center;gap:8px;flex-wrap:wrap}
		.wk-ex-count{font-weight:600;margin-right:6px}
		@media (max-width:782px){.wk-ex-folder ul{columns:1}}
		</style>
		<script>
		( function () {
			var f = document.querySelector( '.wk-ex-form' );
			if ( ! f ) { return; }
			var tpl = <?php echo wp_json_encode( __( '%d elegidos', 'wakoo' ) ); ?>;
			function count() {
				var n = f.querySelectorAll( '.wk-ex:checked' ).length;
				f.querySelector( '.wk-ex-count' ).textContent = tpl.replace( '%d', n );
				f.querySelectorAll( 'details' ).forEach( function ( d ) {
					var all = d.querySelectorAll( '.wk-ex' ), on = d.querySelectorAll( '.wk-ex:checked' ), box = d.querySelector( ':scope > summary .wk-ex-all input' );
					if ( box ) { box.checked = all.length && on.length === all.length; box.indeterminate = on.length > 0 && on.length < all.length; }
				} );
			}
			f.addEventListener( 'change', function ( e ) {
				var box = e.target.closest( '.wk-ex-all' );
				if ( box ) { e.target.closest( 'details' ).querySelectorAll( '.wk-ex' ).forEach( function ( c ) { if ( ! c.closest( 'li' ).hidden ) { c.checked = e.target.checked; } } ); }
				count();
			} );
			// A click on a group's checkbox selects it without folding or unfolding the group.
			f.querySelectorAll( '.wk-ex-all' ).forEach( function ( l ) { l.addEventListener( 'click', function ( e ) { e.stopPropagation(); } ); } );
			f.querySelector( '.wk-ex-q' ).addEventListener( 'input', function () {
				var q = this.value.toLowerCase().trim();
				f.querySelectorAll( '.wk-ex-folder li' ).forEach( function ( li ) { li.hidden = q && li.dataset.title.indexOf( q ) < 0; } );
				f.querySelectorAll( '.wk-ex-folder, .wk-ex-type' ).forEach( function ( d ) { var any = d.querySelector( 'li:not([hidden])' ); d.hidden = ! any; if ( q && any ) { d.open = true; } } );
			} );
			f.querySelector( '.wk-ex-open' ).addEventListener( 'click', function () { f.querySelectorAll( 'details' ).forEach( function ( d ) { d.open = true; } ); } );
			f.querySelector( '.wk-ex-close' ).addEventListener( 'click', function () { f.querySelectorAll( 'details' ).forEach( function ( d ) { d.open = false; } ); } );
			count();
		}() );
		</script>
		<?php
	}

	public static function page() {
		$msgs = [
			'ok'     => [ 'success', __( 'Importado. Los elementos están como borrador, revísalos y publícalos.', 'wakoo' ) ],
			'none'   => [ 'warning', __( 'Marca al menos un elemento para exportar.', 'wakoo' ) ],
			'bad'    => [ 'error', __( 'El archivo no es una exportación válida de Wakoo.', 'wakoo' ) ],
			'nofile' => [ 'error', __( 'No se recibió ningún archivo.', 'wakoo' ) ],
			'big'    => [ 'error', __( 'El archivo es demasiado grande (máximo 8 MB el .json, 128 MB el .zip).', 'wakoo' ) ],
			'okzip'  => [ 'success', __( 'Paquete importado.', 'wakoo' ) ],
			'zip_zip' => [ 'error', __( 'No se pudo leer el zip o es demasiado grande.', 'wakoo' ) ],
			'zip_empty' => [ 'error', __( 'El zip no contiene plantillas de Wakoo (wakoo-pack.json) ni plantillas de Elementor (.json).', 'wakoo' ) ],
			'zip_fail' => [ 'error', __( 'La importación falló a medias; revisa wp-content/debug.log. Lo ya creado quedó como borrador.', 'wakoo' ) ],
			'zip_nozip' => [ 'error', __( 'Este servidor no tiene la extensión ZipArchive de PHP.', 'wakoo' ) ],
			'caps'   => [ 'error', __( 'Tu usuario no puede importar contenido con HTML sin filtrar.', 'wakoo' ) ],
			'css'    => [ 'success', __( 'Estilos de paquetes guardados.', 'wakoo' ) ],
		];
		$m = isset( $_GET['msg'] ) ? sanitize_key( $_GET['msg'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		echo '<div class="wrap"><h1>' . esc_html__( 'Exportar e importar', 'wakoo' ) . '</h1>';
		if ( isset( $msgs[ $m ] ) ) {
			$extra = ( 'ok' === $m && ! empty( $_GET['n'] ) ) ? ' (' . (int) $_GET['n'] . ')' : ''; // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-' . esc_attr( $msgs[ $m ][0] ) . '"><p>' . esc_html( $msgs[ $m ][1] . $extra ) . '</p></div>';
		}

		$rep = get_transient( 'wakoo_pack_report_' . get_current_user_id() );
		if ( $rep && 'okzip' === $m ) {
			delete_transient( 'wakoo_pack_report_' . get_current_user_id() );
			echo '<div class="notice notice-info"><p>' . esc_html( sprintf( /* translators: %d: media files */ __( 'Imágenes y medios añadidos a la biblioteca: %d.', 'wakoo' ), (int) $rep['media'] ) ) . '</p><ul style="list-style:disc;margin-left:20px">';
			foreach ( $rep['items'] as $r ) {
				echo '<li>' . esc_html( $r['title'] ) . ' — <a href="' . esc_url( get_edit_post_link( $r['id'] ) ) . '">' . esc_html__( 'abrir', 'wakoo' ) . '</a></li>';
			}
			echo '</ul>';
			if ( $rep['skipped'] ) { echo '<p>' . esc_html__( 'Archivos ignorados (tipo no permitido o ruta no segura):', 'wakoo' ) . ' ' . esc_html( implode( ', ', $rep['skipped'] ) ) . '</p>'; }
			echo '</div>';
		}

		self::export_box();

		echo '<h2>' . esc_html__( 'Importar', 'wakoo' ) . '</h2>';
		echo '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'wakoo_import' );
		echo '<input type="hidden" name="action" value="wakoo_import">';
		echo '<p><input type="file" name="wakoo_file" accept=".json,.zip,application/json,application/zip" required></p>';
		echo '<p><label><input type="checkbox" name="wakoo_replace" value="1" checked> ' . esc_html__( 'Si el paquete ya se importó antes, actualizar esas páginas e imágenes en vez de duplicarlas (con una página descargada de esta web, la restaura)', 'wakoo' ) . '</label></p>';
		echo '<p><label><input type="checkbox" name="wakoo_publish" value="1"> ' . esc_html__( 'Publicar al importar (si no, se crean como borrador)', 'wakoo' ) . '</label></p>';
		echo '<p class="description">' . esc_html__( 'Acepta un .json de Wakoo o un paquete .zip (wakoo-pack.json o plantillas de Elementor .json, más la carpeta images/). Las imágenes del zip se añaden a la biblioteca de medios y se enlazan solas; con un .json, siguen apuntando a la web de origen.', 'wakoo' ) . '</p>';
		submit_button( __( 'Importar archivo', 'wakoo' ), 'secondary' );
		echo '</form>';

		$styles = get_option( self::STYLES_OPTION, [] );
		if ( $styles && is_array( $styles ) && current_user_can( 'unfiltered_html' ) ) {
			echo '<h2>' . esc_html__( 'Estilos de los paquetes', 'wakoo' ) . '</h2>';
			echo '<p class="description">' . esc_html__( 'CSS global que trajo cada paquete (sistema de diseño y fuentes alojadas en tu web). Se carga en todas las páginas.', 'wakoo' ) . '</p>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'wakoo_pack_styles' );
			echo '<input type="hidden" name="action" value="wakoo_pack_styles">';
			foreach ( $styles as $pack => $css ) {
				echo '<h3>' . esc_html( $pack ) . '</h3><textarea name="wakoo_css[' . esc_attr( $pack ) . ']" rows="12" style="width:100%;max-width:900px;font-family:monospace" spellcheck="false">' . esc_textarea( $css ) . '</textarea>';
				echo '<p><label><input type="checkbox" name="wakoo_css_del[]" value="' . esc_attr( $pack ) . '"> ' . esc_html__( 'Quitar estos estilos', 'wakoo' ) . '</label></p>';
			}
			submit_button( __( 'Guardar estilos', 'wakoo' ), 'secondary' );
			echo '</form>';
		}
		echo '</div>';
	}
}

Module::init();
