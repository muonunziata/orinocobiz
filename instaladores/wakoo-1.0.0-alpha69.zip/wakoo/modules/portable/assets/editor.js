( function ( $ ) {
	'use strict';

	/** "Descargar esta página" in the editor menu: the saved version of the open document as a Wakoo .zip pack. */
	function download() {
		var doc = elementor.documents && elementor.documents.getCurrent ? elementor.documents.getCurrent() : null,
			id = doc ? doc.id : ( elementor.config.document || {} ).id;
		if ( ! id ) { return; }
		if ( doc && doc.editor && doc.editor.isChanged && ! window.confirm( wakooDownload.dirty ) ) { return; }
		window.location.href = wakooDownload.url + '&post=' + encodeURIComponent( id );
	}

	function register() {
		var bar = window.elementorV2 && window.elementorV2.editorAppBar;
		// Top app bar (Elementor 3.x/4.x): the "..." document menu.
		if ( bar && bar.documentOptionsMenu ) {
			bar.documentOptionsMenu.registerAction( {
				id: 'wakoo-download-page',
				priority: 40,
				props: {
					icon: function () { return window.React ? window.React.createElement( 'i', { className: 'eicon-download-bold' } ) : null; },
					title: wakooDownload.label,
					onClick: function ( e ) { if ( e && e.preventDefault ) { e.preventDefault(); } download(); }
				}
			} );
			return;
		}
		// Classic panel menu.
		var menu = elementor.modules && elementor.modules.layouts && elementor.modules.layouts.panel && elementor.modules.layouts.panel.pages && elementor.modules.layouts.panel.pages.menu;
		if ( menu && menu.Menu && menu.Menu.addItem ) {
			menu.Menu.addItem( { name: 'wakoo-download-page', icon: 'eicon-download-bold', title: wakooDownload.label, callback: download }, 'more' );
		}
	}

	if ( window.elementor && window.elementor.config ) {
		register();
	} else {
		$( window ).on( 'elementor:init', register );
	}
}( jQuery ) );
