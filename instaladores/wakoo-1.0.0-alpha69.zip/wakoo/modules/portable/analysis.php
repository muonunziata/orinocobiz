<?php
/**
 * Wakoo Portable · page analysis: everything needed to understand a page,
 * whatever built it (Elementor, Wakoo, Gutenberg, Classic, Divi, WPBakery…),
 * so a new or optimised version can be made in Wakoo.
 *
 * Added to "Descargar esta página" as analisis/:
 * - estructura.md / estructura.json: builder, theme, template, SEO, sections,
 *   heading outline, images (alt, size), links, buttons, forms, embeds,
 *   structured data, colours and fonts in use, menus, fields and terms;
 * - textos.md: every heading and paragraph in order (to rewrite or translate);
 * - pagina.html: the page as the visitor sees it (sent by the browser when the
 *   download starts from the admin bar), else the rendered content;
 * - contenido-original.html and bloques.json: the stored content and blocks;
 * - estilos/: the site's own CSS files and the inline styles of the page;
 * - imagenes/: images of the page not already in images/.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Portable;

defined( 'ABSPATH' ) || die();

class Analysis {

	const MAX_HTML   = 6291456;  // 6 MB of page HTML.
	const MAX_CSS    = 4194304;  // 4 MB of CSS files.
	const MAX_IMAGES = 41943040; // 40 MB of extra images.

	/**
	 * @return array{ strings: array<string,string>, files: array<string,string> } zip path => contents / absolute file.
	 */
	public static function build( $post_id, $snapshot = '', $snap_url = '', array $already = [] ) {
		$p = get_post( $post_id );
		if ( ! $p ) { return [ 'strings' => [], 'files' => [] ]; }
		$snapshot = is_string( $snapshot ) && strlen( $snapshot ) <= self::MAX_HTML && false !== stripos( $snapshot, '<html' ) ? $snapshot : '';
		$html     = $snapshot ?: self::rendered( $p );
		$data     = [
			'page'     => self::page_info( $p, $snap_url ),
			'builder'  => self::builder( $p ),
			'theme'    => self::theme(),
			'source'   => $snapshot ? 'browser-snapshot' : 'rendered-content',
		];
		$dom = self::dom( $html );
		$data += $dom ? self::read_dom( $dom ) : [];
		$css = self::css( $dom, $html );
		$data['design'] = self::design( $css['all'] );
		$data['menus']  = self::menus();
		$data['fields'] = self::fields( $p );
		$data['terms']  = self::terms( $p );

		$strings = [
			'analisis/LEEME.md'              => self::readme( $p ),
			'analisis/estructura.md'         => self::markdown( $data ),
			'analisis/estructura.json'       => wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
			'analisis/textos.md'             => self::texts_md( $dom, $p ),
			'analisis/pagina.html'           => $html,
			'analisis/contenido-original.html' => (string) $p->post_content,
		];
		if ( has_blocks( $p->post_content ) ) {
			$strings['analisis/bloques.json'] = wp_json_encode( self::slim_blocks( parse_blocks( $p->post_content ) ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		}
		if ( '' !== trim( $css['inline'] ) ) { $strings['analisis/estilos/en-la-pagina.css'] = $css['inline']; }
		$files = $css['files'];
		// Images of the page (uploads) that the pack does not carry already.
		$up = wp_get_upload_dir();
		$total = 0;
		foreach ( array_unique( $data['images_local'] ?? [] ) as $rel ) {
			$abs = trailingslashit( $up['basedir'] ) . $rel;
			if ( false !== strpos( $rel, '..' ) || ! is_file( $abs ) || in_array( $abs, $already, true ) ) { continue; }
			$total += filesize( $abs );
			if ( $total > self::MAX_IMAGES ) { break; }
			$files[ 'analisis/imagenes/' . sanitize_file_name( basename( $rel ) ) ] = $abs;
		}
		unset( $data['images_local'] );
		return [ 'strings' => $strings, 'files' => $files ];
	}

	/** The content as WordPress renders it (when no browser snapshot came with the download). */
	private static function rendered( $p ) {
		$body = '';
		if ( get_post_meta( $p->ID, '_elementor_data', true ) && class_exists( '\Elementor\Plugin' ) ) {
			$body = \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $p->ID, true );
		}
		if ( '' === trim( (string) $body ) ) {
			$GLOBALS['post'] = $p; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
			setup_postdata( $p );
			$body = apply_filters( 'the_content', $p->post_content ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals
			wp_reset_postdata();
		}
		return '<!DOCTYPE html><html lang="' . esc_attr( get_bloginfo( 'language' ) ) . '"><head><meta charset="utf-8"><title>' . esc_html( get_the_title( $p ) ) . '</title></head><body><main>' . $body . '</main></body></html>';
	}

	private static function page_info( $p, $snap_url ) {
		$tpl = (string) get_post_meta( $p->ID, '_wp_page_template', true );
		return array_filter( [
			'id'         => $p->ID,
			'title'      => get_the_title( $p ),
			'type'       => $p->post_type,
			'status'     => $p->post_status,
			'url'        => get_permalink( $p ),
			'seen_at'    => $snap_url ? esc_url_raw( $snap_url ) : null,
			'slug'       => $p->post_name,
			'parent'     => $p->post_parent ? get_page_uri( $p->post_parent ) : null,
			'template'   => $tpl ?: 'default',
			'modified'   => $p->post_modified_gmt,
			'language'   => (string) get_post_meta( $p->ID, '_wakoo_lang', true ) ?: get_bloginfo( 'language' ),
			'excerpt'    => $p->post_excerpt ?: null,
			'featured'   => get_the_post_thumbnail_url( $p, 'full' ) ?: null,
			'front_page' => (int) get_option( 'page_on_front' ) === $p->ID,
		] );
	}

	/** Which tool built the page (several can be true). */
	private static function builder( $p ) {
		$c = (string) $p->post_content;
		$m = function ( $k ) use ( $p ) { return (bool) get_post_meta( $p->ID, $k, true ); };
		$found = [];
		if ( $m( '_elementor_data' ) ) { $found[] = 'Elementor' . ( false !== strpos( (string) get_post_meta( $p->ID, '_elementor_data', true ), '"widgetType":"wakoo' ) ? ' + Wakoo' : '' ); }
		if ( has_blocks( $c ) ) {
			$names = [];
			foreach ( parse_blocks( $c ) as $b ) { if ( $b['blockName'] ) { $names[ $b['blockName'] ] = ( $names[ $b['blockName'] ] ?? 0 ) + 1; } }
			$found[] = 'Gutenberg (' . implode( ', ', array_map( function ( $k, $v ) { return $k . ' ×' . $v; }, array_keys( $names ), $names ) ) . ')';
		}
		$short = [ 'vc_' => 'WPBakery', 'et_pb_' => 'Divi', 'fusion_' => 'Avada Fusion', 'fl_builder' => 'Beaver Builder', 'cs_' => 'Cornerstone', 'tatsu_' => 'Tatsu' ];
		foreach ( $short as $k => $name ) { if ( false !== strpos( $c, '[' . $k ) ) { $found[] = $name; } }
		if ( $m( '_fl_builder_enabled' ) ) { $found[] = 'Beaver Builder'; }
		if ( $m( '_bricks_page_content_2' ) ) { $found[] = 'Bricks'; }
		if ( $m( 'ct_builder_shortcodes' ) || $m( '_ct_builder_json' ) ) { $found[] = 'Oxygen'; }
		if ( $m( '_breakdance_data' ) ) { $found[] = 'Breakdance'; }
		if ( ! $found ) { $found[] = '' !== trim( $c ) ? 'Classic editor (HTML)' : 'Theme template only'; }
		return array_values( array_unique( $found ) );
	}

	private static function theme() {
		$t = wp_get_theme();
		$plugins = [];
		if ( ! function_exists( 'get_plugins' ) ) { require_once ABSPATH . 'wp-admin/includes/plugin.php'; }
		$all = get_plugins();
		foreach ( (array) get_option( 'active_plugins', [] ) as $f ) { if ( isset( $all[ $f ] ) ) { $plugins[] = $all[ $f ]['Name'] . ' ' . $all[ $f ]['Version']; } }
		return array_filter( [ 'name' => $t->get( 'Name' ), 'version' => $t->get( 'Version' ), 'parent' => $t->parent() ? $t->parent()->get( 'Name' ) : null, 'block_theme' => function_exists( 'wp_is_block_theme' ) && wp_is_block_theme(), 'plugins' => $plugins ] );
	}

	private static function dom( $html ) {
		if ( '' === trim( $html ) || ! class_exists( '\DOMDocument' ) ) { return null; }
		$d = new \DOMDocument();
		libxml_use_internal_errors( true );
		$d->loadHTML( '<?xml encoding="utf-8"?>' . $html, LIBXML_NOWARNING | LIBXML_NOERROR );
		libxml_clear_errors();
		return $d;
	}

	private static function text( $n ) {
		return trim( preg_replace( '/\s+/u', ' ', (string) $n->textContent ) );
	}

	private static function abs_url( $u ) {
		$u = trim( (string) $u );
		if ( '' === $u || 0 === strpos( $u, 'data:' ) ) { return ''; }
		if ( 0 === strpos( $u, '//' ) ) { return 'https:' . $u; }
		if ( 0 === strpos( $u, '/' ) ) { return home_url( $u ); }
		return $u;
	}

	private static function read_dom( \DOMDocument $d ) {
		$x    = new \DOMXPath( $d );
		$home = wp_parse_url( home_url(), PHP_URL_HOST );
		$base = trailingslashit( wp_get_upload_dir()['baseurl'] );
		$out  = [ 'seo' => [], 'outline' => [], 'sections' => [], 'images' => [], 'links' => [ 'internal' => [], 'external' => [] ], 'buttons' => [], 'forms' => [], 'embeds' => [], 'jsonld' => [], 'images_local' => [] ];
		$html = $x->query( '//html' )->item( 0 );
		$out['seo']['lang'] = $html ? $html->getAttribute( 'lang' ) : '';
		$t = $x->query( '//title' )->item( 0 );
		$out['seo']['title'] = $t ? self::text( $t ) : '';
		foreach ( $x->query( '//meta[@name or @property]' ) as $m ) {
			$k = $m->getAttribute( 'name' ) ?: $m->getAttribute( 'property' );
			if ( preg_match( '/^(description|robots|viewport|keywords|og:|twitter:)/i', $k ) ) { $out['seo'][ $k ] = $m->getAttribute( 'content' ); }
		}
		foreach ( $x->query( '//link[@rel="canonical" or @rel="alternate"][@href]' ) as $l ) {
			$out['seo'][ 'canonical' === $l->getAttribute( 'rel' ) ? 'canonical' : 'hreflang:' . $l->getAttribute( 'hreflang' ) ] = $l->getAttribute( 'href' );
		}
		// Landmarks and big blocks (header, nav, main, sections, footer) with their first heading.
		foreach ( $x->query( '//header|//nav|//main|//section|//article|//aside|//footer|//*[contains(concat(" ",@class," ")," elementor-top-section ") or contains(concat(" ",@class," ")," e-parent ")]' ) as $n ) {
			if ( count( $out['sections'] ) >= 80 ) { break; }
			$h = $x->query( './/h1|.//h2|.//h3', $n )->item( 0 );
			$out['sections'][] = array_filter( [ 'tag' => $n->nodeName, 'id' => $n->getAttribute( 'id' ) ?: null, 'class' => mb_substr( $n->getAttribute( 'class' ), 0, 120 ) ?: null, 'heading' => $h ? mb_substr( self::text( $h ), 0, 120 ) : null, 'words' => str_word_count( self::text( $n ) ) ] );
		}
		foreach ( $x->query( '//h1|//h2|//h3|//h4|//h5|//h6' ) as $h ) {
			$txt = self::text( $h );
			if ( '' !== $txt ) { $out['outline'][] = [ 'level' => (int) substr( $h->nodeName, 1 ), 'text' => mb_substr( $txt, 0, 200 ) ]; }
		}
		foreach ( $x->query( '//img' ) as $i ) {
			$src = self::abs_url( $i->getAttribute( 'src' ) ?: $i->getAttribute( 'data-src' ) );
			if ( ! $src ) { continue; }
			$out['images'][] = array_filter( [ 'src' => $src, 'alt' => $i->getAttribute( 'alt' ), 'width' => $i->getAttribute( 'width' ) ?: null, 'height' => $i->getAttribute( 'height' ) ?: null, 'loading' => $i->getAttribute( 'loading' ) ?: null ], function ( $v ) { return null !== $v; } );
			if ( 0 === strpos( $src, $base ) ) { $out['images_local'][] = preg_replace( '/-\d+x\d+(?=\.[a-z0-9]+$)/i', '', substr( strtok( $src, '?' ), strlen( $base ) ) ); }
		}
		// Background images written in style="" (heroes, banners).
		foreach ( $x->query( '//*[contains(@style,"url(")]' ) as $n ) {
			if ( preg_match_all( '/url\(\s*[\'"]?([^\'")]+)/i', $n->getAttribute( 'style' ), $mm ) ) {
				foreach ( $mm[1] as $u ) {
					$u = self::abs_url( $u );
					$out['images'][] = [ 'src' => $u, 'background' => true ];
					if ( 0 === strpos( $u, $base ) ) { $out['images_local'][] = substr( strtok( $u, '?' ), strlen( $base ) ); }
				}
			}
		}
		foreach ( $x->query( '//a[@href]' ) as $a ) {
			$href = self::abs_url( $a->getAttribute( 'href' ) );
			if ( ! $href || 0 === strpos( $href, '#' ) || 0 === stripos( $href, 'javascript:' ) ) { continue; }
			$host = wp_parse_url( $href, PHP_URL_HOST );
			$row  = [ 'text' => mb_substr( self::text( $a ) ?: $a->getAttribute( 'aria-label' ), 0, 100 ), 'href' => $href ];
			if ( ! $host || $host === $home ) { $out['links']['internal'][] = $row; } elseif ( count( $out['links']['external'] ) < 150 ) { $out['links']['external'][] = $row; }
			if ( preg_match( '/\b(button|btn|cta)\b/i', $a->getAttribute( 'class' ) . ' ' . $a->getAttribute( 'role' ) ) ) { $out['buttons'][] = $row; }
		}
		foreach ( $x->query( '//button' ) as $b ) { $t = self::text( $b ); if ( '' !== $t ) { $out['buttons'][] = [ 'text' => mb_substr( $t, 0, 80 ), 'type' => $b->getAttribute( 'type' ) ]; } }
		$out['links']['internal'] = array_slice( array_values( array_unique( $out['links']['internal'], SORT_REGULAR ) ), 0, 200 );
		foreach ( $x->query( '//form' ) as $f ) {
			$fields = [];
			foreach ( $x->query( './/input|.//select|.//textarea', $f ) as $in ) {
				$type = 'input' === $in->nodeName ? ( $in->getAttribute( 'type' ) ?: 'text' ) : $in->nodeName;
				if ( in_array( $type, [ 'hidden', 'submit' ], true ) ) { continue; }
				$id    = $in->getAttribute( 'id' );
				$label = ( $id && preg_match( '/^[\w\-:.]+$/', $id ) ) ? $x->query( '//label[@for="' . $id . '"]' )->item( 0 ) : null;
				$fields[] = array_filter( [ 'type' => $type, 'name' => $in->getAttribute( 'name' ), 'label' => $label ? self::text( $label ) : ( $in->getAttribute( 'placeholder' ) ?: $in->getAttribute( 'aria-label' ) ), 'required' => $in->hasAttribute( 'required' ) ] );
			}
			$out['forms'][] = [ 'action' => $f->getAttribute( 'action' ), 'method' => strtoupper( $f->getAttribute( 'method' ) ?: 'GET' ), 'fields' => $fields ];
		}
		foreach ( $x->query( '//iframe|//video|//audio' ) as $e ) { $out['embeds'][] = [ 'tag' => $e->nodeName, 'src' => self::abs_url( $e->getAttribute( 'src' ) ?: $e->getAttribute( 'data-src' ) ) ]; }
		foreach ( $x->query( '//script[@type="application/ld+json"]' ) as $s ) {
			$j = json_decode( $s->textContent, true );
			if ( is_array( $j ) ) { $out['jsonld'][] = $j['@type'] ?? array_map( function ( $g ) { return $g['@type'] ?? '?'; }, (array) ( $j['@graph'] ?? [] ) ); }
		}
		$words = 0; // Visible words only (not the data inside scripts and styles).
		foreach ( $x->query( '//body//text()[not(ancestor::script) and not(ancestor::style) and not(ancestor::noscript)]' ) as $t ) { $words += str_word_count( (string) $t->nodeValue ); }
		$out['words'] = $words;
		return $out;
	}

	/** The site's own stylesheets of the page (copied from disk) and the inline <style> blocks. */
	private static function css( $dom, $html ) {
		$res = [ 'files' => [], 'inline' => '', 'all' => '' ];
		if ( ! $dom ) { return $res; }
		$x = new \DOMXPath( $dom );
		foreach ( $x->query( '//style' ) as $s ) { $res['inline'] .= "/* <style" . ( $s->getAttribute( 'id' ) ? ' id="' . $s->getAttribute( 'id' ) . '"' : '' ) . "> */\n" . $s->textContent . "\n\n"; }
		$res['all'] = $res['inline'];
		$site  = untrailingslashit( site_url() );
		$total = 0;
		foreach ( $x->query( '//link[@rel="stylesheet"][@href]' ) as $l ) {
			$href = strtok( self::abs_url( $l->getAttribute( 'href' ) ), '?' );
			if ( 0 !== strpos( $href, $site . '/' ) ) { continue; }
			$file = wp_normalize_path( ABSPATH . ltrim( substr( $href, strlen( $site ) ), '/' ) );
			$real = realpath( $file );
			if ( ! $real || 0 !== strpos( wp_normalize_path( $real ), wp_normalize_path( ABSPATH ) ) || 'css' !== strtolower( pathinfo( $real, PATHINFO_EXTENSION ) ) ) { continue; }
			$total += filesize( $real );
			if ( $total > self::MAX_CSS ) { break; }
			$rel = ltrim( substr( $href, strlen( $site ) ), '/' );
			$res['files'][ 'analisis/estilos/' . str_replace( '/', '__', $rel ) ] = $real;
			$res['all'] .= (string) file_get_contents( $real ) . "\n"; // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		return $res;
	}

	/** Colours and fonts the page's CSS uses most. */
	private static function design( $css ) {
		$colors = [];
		if ( preg_match_all( '/#(?:[0-9a-f]{3}){1,2}\b|rgba?\([^)]+\)/i', $css, $m ) ) {
			foreach ( $m[0] as $c ) { $c = strtolower( preg_replace( '/\s+/', '', $c ) ); $colors[ $c ] = ( $colors[ $c ] ?? 0 ) + 1; }
		}
		arsort( $colors );
		$fonts = [];
		if ( preg_match_all( '/font-family\s*:\s*([^;}{]+)/i', $css, $m ) ) {
			foreach ( $m[1] as $f ) { $f = trim( explode( ',', str_replace( [ '"', "'" ], '', $f ) )[0] ); if ( '' !== $f && false === strpos( $f, 'var(' ) ) { $fonts[ $f ] = ( $fonts[ $f ] ?? 0 ) + 1; } }
		}
		arsort( $fonts );
		$vars = [];
		if ( preg_match_all( '/(--[a-z0-9\-]+)\s*:\s*([^;}{]{1,60})/i', $css, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $v ) { if ( count( $vars ) < 60 && preg_match( '/color|font|radius|space|gap|shadow|accent|primary|secondary/i', $v[1] ) ) { $vars[ $v[1] ] = trim( $v[2] ); } }
		}
		return [ 'colors' => array_slice( $colors, 0, 16, true ), 'fonts' => array_slice( $fonts, 0, 8, true ), 'css_variables' => $vars ];
	}

	private static function menus() {
		$out = [];
		$locations = get_nav_menu_locations();
		foreach ( $locations as $loc => $menu_id ) {
			$items = $menu_id ? wp_get_nav_menu_items( $menu_id ) : [];
			if ( ! $items ) { continue; }
			$out[ $loc ] = array_map( function ( $i ) { return [ 'title' => $i->title, 'url' => $i->url, 'parent' => (int) $i->menu_item_parent ]; }, $items );
		}
		return $out;
	}

	/** Custom fields (no secrets): public keys and the usual SEO plugin fields. */
	private static function fields( $p ) {
		$out  = [];
		$seo  = [ '_yoast_wpseo_title', '_yoast_wpseo_metadesc', '_yoast_wpseo_focuskw', 'rank_math_title', 'rank_math_description', 'rank_math_focus_keyword', '_aioseo_title', '_aioseo_description', '_wakoo_seo_title', '_wakoo_seo_desc', '_wp_page_template' ];
		foreach ( get_post_meta( $p->ID ) as $k => $v ) {
			if ( ( '_' === $k[0] && ! in_array( $k, $seo, true ) ) || preg_match( '/pass|token|secret|api[_-]?key|nonce|session|email/i', $k ) ) { continue; }
			$val = maybe_unserialize( $v[0] );
			$out[ $k ] = is_scalar( $val ) ? mb_substr( (string) $val, 0, 1000 ) : '(array)';
		}
		return $out;
	}

	private static function terms( $p ) {
		$out = [];
		foreach ( get_object_taxonomies( $p->post_type ) as $tax ) {
			$t = get_the_terms( $p, $tax );
			if ( is_array( $t ) && $t ) { $out[ $tax ] = wp_list_pluck( $t, 'name' ); }
		}
		return $out;
	}

	private static function slim_blocks( array $blocks ) {
		$out = [];
		foreach ( $blocks as $b ) {
			if ( ! $b['blockName'] && '' === trim( $b['innerHTML'] ) ) { continue; }
			$out[] = array_filter( [ 'block' => $b['blockName'] ?: 'html', 'attrs' => $b['attrs'] ?: null, 'html' => trim( wp_strip_all_tags( $b['innerHTML'] ) ) ? mb_substr( trim( $b['innerHTML'] ), 0, 4000 ) : null, 'inner' => $b['innerBlocks'] ? self::slim_blocks( $b['innerBlocks'] ) : null ] );
		}
		return $out;
	}

	/** Headings and paragraphs in reading order. */
	private static function texts_md( $dom, $p ) {
		$lines = [ '# ' . get_the_title( $p ), '' ];
		if ( ! $dom ) { return implode( "\n", $lines ); }
		$x    = new \DOMXPath( $dom );
		$main = $x->query( '//main' )->item( 0 ) ?: $x->query( '//body' )->item( 0 );
		if ( ! $main ) { return implode( "\n", $lines ); }
		$seen = [];
		foreach ( $x->query( './/h1|.//h2|.//h3|.//h4|.//h5|.//h6|.//p|.//li|.//blockquote|.//figcaption|.//a[contains(@class,"button")]', $main ) as $n ) {
			$t = self::text( $n );
			if ( '' === $t || isset( $seen[ $t ] ) || mb_strlen( $t ) < 2 ) { continue; }
			$seen[ $t ] = 1;
			if ( preg_match( '/^h([1-6])$/', $n->nodeName, $m ) ) { $lines[] = ''; $lines[] = str_repeat( '#', (int) $m[1] ) . ' ' . $t; continue; }
			$lines[] = ( 'li' === $n->nodeName ? '- ' : ( 'a' === $n->nodeName ? '[Botón] ' : '' ) ) . $t;
		}
		return implode( "\n", $lines ) . "\n";
	}

	private static function markdown( array $d ) {
		$pg = $d['page'];
		$l  = [ '# Análisis de «' . $pg['title'] . '»', '', '- URL: ' . ( $pg['url'] ?? '' ), '- Tipo: ' . $pg['type'] . ' · plantilla: ' . ( $pg['template'] ?? 'default' ) . ' · idioma: ' . ( $pg['language'] ?? '' ), '- Construida con: ' . implode( ' · ', $d['builder'] ), '- Tema: ' . ( $d['theme']['name'] ?? '' ) . ' ' . ( $d['theme']['version'] ?? '' ) . ( ! empty( $d['theme']['parent'] ) ? ' (hijo de ' . $d['theme']['parent'] . ')' : '' ), '- Origen del HTML: ' . ( 'browser-snapshot' === $d['source'] ? 'la página tal como la ve el visitante (captura del navegador)' : 'el contenido renderizado por WordPress (descárgala desde la barra de administración, viendo la página, para tener la captura completa)' ), '- Palabras: ' . ( $d['words'] ?? 0 ), '' ];
		$l[] = '## SEO';
		foreach ( (array) ( $d['seo'] ?? [] ) as $k => $v ) { if ( '' !== (string) $v ) { $l[] = '- ' . $k . ': ' . $v; } }
		$l[] = '';
		$l[] = '## Estructura (secciones)';
		foreach ( (array) ( $d['sections'] ?? [] ) as $s ) { $l[] = '- <' . $s['tag'] . '>' . ( isset( $s['id'] ) ? ' #' . $s['id'] : '' ) . ( isset( $s['heading'] ) ? ' — ' . $s['heading'] : '' ) . ' (' . ( $s['words'] ?? 0 ) . ' palabras)'; }
		$l[] = '';
		$l[] = '## Títulos';
		foreach ( (array) ( $d['outline'] ?? [] ) as $h ) { $l[] = str_repeat( '  ', $h['level'] - 1 ) . '- H' . $h['level'] . ': ' . $h['text']; }
		$l[] = '';
		$l[] = '## Imágenes (' . count( (array) ( $d['images'] ?? [] ) ) . ')';
		foreach ( array_slice( (array) ( $d['images'] ?? [] ), 0, 80 ) as $i ) { $l[] = '- ' . $i['src'] . ( ! empty( $i['background'] ) ? ' (fondo)' : ' · alt: ' . ( '' !== ( $i['alt'] ?? '' ) ? '«' . $i['alt'] . '»' : 'FALTA' ) ); }
		$l[] = '';
		$l[] = '## Botones y llamadas a la acción';
		foreach ( array_slice( (array) ( $d['buttons'] ?? [] ), 0, 60 ) as $b ) { $l[] = '- ' . $b['text'] . ( isset( $b['href'] ) ? ' → ' . $b['href'] : '' ); }
		$l[] = '';
		$l[] = '## Formularios';
		foreach ( (array) ( $d['forms'] ?? [] ) as $f ) { $l[] = '- ' . $f['method'] . ' ' . $f['action'] . ': ' . implode( ', ', array_map( function ( $x ) { return ( $x['label'] ?? $x['name'] ?? '?' ) . ' (' . $x['type'] . ( ! empty( $x['required'] ) ? ', obligatorio' : '' ) . ')'; }, $f['fields'] ) ); }
		$l[] = '';
		$l[] = '## Enlaces';
		$l[] = '- Internos: ' . count( (array) ( $d['links']['internal'] ?? [] ) ) . ' · externos: ' . count( (array) ( $d['links']['external'] ?? [] ) ) . ' (lista completa en estructura.json)';
		$l[] = '';
		$l[] = '## Insertados (mapas, vídeos)';
		foreach ( (array) ( $d['embeds'] ?? [] ) as $e ) { $l[] = '- ' . $e['tag'] . ': ' . $e['src']; }
		$l[] = '';
		$l[] = '## Datos estructurados';
		foreach ( (array) ( $d['jsonld'] ?? [] ) as $j ) { $l[] = '- ' . ( is_array( $j ) ? implode( ', ', (array) $j ) : $j ); }
		$l[] = '';
		$l[] = '## Diseño';
		$l[] = '- Colores más usados: ' . implode( ', ', array_keys( $d['design']['colors'] ) );
		$l[] = '- Fuentes: ' . implode( ', ', array_keys( $d['design']['fonts'] ) );
		foreach ( $d['design']['css_variables'] as $k => $v ) { $l[] = '- ' . $k . ': ' . $v; }
		$l[] = '';
		if ( $d['menus'] ) {
			$l[] = '## Menús del sitio';
			foreach ( $d['menus'] as $loc => $items ) { $l[] = '- ' . $loc . ': ' . implode( ' · ', wp_list_pluck( $items, 'title' ) ); }
			$l[] = '';
		}
		if ( $d['terms'] ) { $l[] = '## Taxonomías'; foreach ( $d['terms'] as $t => $names ) { $l[] = '- ' . $t . ': ' . implode( ', ', $names ); } $l[] = ''; }
		if ( $d['fields'] ) { $l[] = '## Campos'; foreach ( $d['fields'] as $k => $v ) { $l[] = '- ' . $k . ': ' . $v; } $l[] = ''; }
		$l[] = '## Plugins activos';
		$l[] = implode( ', ', (array) ( $d['theme']['plugins'] ?? [] ) );
		return implode( "\n", $l ) . "\n";
	}

	private static function readme( $p ) {
		return "# Análisis de la página «" . get_the_title( $p ) . "»\n\n"
			. "Esta carpeta describe cómo está hecha la página, la haya construido Elementor, Wakoo, Gutenberg u otro constructor.\n\n"
			. "- estructura.md: resumen legible (secciones, títulos, imágenes con su texto alternativo, botones, formularios, SEO, colores, fuentes, menús).\n"
			. "- estructura.json: lo mismo, completo, para herramientas.\n"
			. "- textos.md: todos los títulos y párrafos en orden.\n"
			. "- pagina.html: la página tal como se ve (o el contenido renderizado).\n"
			. "- contenido-original.html y bloques.json: el contenido guardado en WordPress.\n"
			. "- estilos/ e imagenes/: el CSS del sitio y las imágenes de la página.\n\n"
			. "Para hacer una versión nueva u optimizada en Wakoo: dale este zip a Claude y pídele «crea en Wakoo una versión optimizada de esta página»."
			. " Claude seguirá el formato de paquetes de Wakoo y devolverá un .zip importable en Wakoo → Exportar / importar.\n";
	}
}
