<?php
/**
 * Wakoo Countdown widget.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Countdown;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Widget extends Widget_Base {

	public function get_name() { return 'wakoo-countdown'; }
	public function get_title() { return __( 'Contador regresivo (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-countdown'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'contador', 'countdown', 'cuenta atras', 'oferta', 'lanzamiento', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-countdown' ]; }
	public function get_style_depends() { return [ 'wakoo-countdown' ]; }

	protected function register_controls() {

		$this->start_controls_section( 'sec_time', [ 'label' => __( 'Tiempo', 'wakoo' ) ] );
		$this->add_control( 'mode', [
			'label'   => __( 'Tipo', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'date',
			'options' => [
				'date'      => __( 'Hasta una fecha', 'wakoo' ),
				'evergreen' => __( 'Por visitante (empieza al entrar)', 'wakoo' ),
			],
		] );
		$this->add_control( 'due', [
			'label'          => __( 'Fecha y hora final', 'wakoo' ),
			'type'           => Controls_Manager::DATE_TIME,
			'default'        => gmdate( 'Y-m-d H:i', time() + 7 * DAY_IN_SECONDS ),
			'picker_options' => [ 'enableTime' => true ],
			'description'    => __( 'Según la zona horaria de WordPress.', 'wakoo' ),
			'condition'      => [ 'mode' => 'date' ],
		] );
		$this->add_control( 'hours', [ 'label' => __( 'Duración (horas)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 720, 'default' => 24, 'condition' => [ 'mode' => 'evergreen' ] ] );
		$this->add_control( 'show_days', [ 'label' => __( 'Mostrar días', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_labels', [ 'label' => __( 'Textos', 'wakoo' ) ] );
		$this->add_control( 'l_d', [ 'label' => __( 'Días', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Días', 'wakoo' ) ] );
		$this->add_control( 'l_h', [ 'label' => __( 'Horas', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Horas', 'wakoo' ) ] );
		$this->add_control( 'l_m', [ 'label' => __( 'Minutos', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Min', 'wakoo' ) ] );
		$this->add_control( 'l_s', [ 'label' => __( 'Segundos', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Seg', 'wakoo' ) ] );
		$this->add_control( 'end_action', [
			'label'   => __( 'Al terminar', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'message',
			'options' => [ 'message' => __( 'Mostrar mensaje', 'wakoo' ), 'hide' => __( 'Ocultar contador', 'wakoo' ), 'zero' => __( 'Dejar en cero', 'wakoo' ) ],
		] );
		$this->add_control( 'end_msg', [ 'label' => __( 'Mensaje final', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( '¡La oferta ha terminado!', 'wakoo' ), 'condition' => [ 'end_action' => 'message' ] ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'box_bg', [ 'label' => __( 'Fondo de las cajas', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#1A1A2E', 'selectors' => [ '{{WRAPPER}} .wakoo-cd__box' => 'background: {{VALUE}};' ] ] );
		$this->add_control( 'num_color', [ 'label' => __( 'Color de los números', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#FFFFFF', 'selectors' => [ '{{WRAPPER}} .wakoo-cd__num' => 'color: {{VALUE}};' ] ] );
		$this->add_control( 'lab_color', [ 'label' => __( 'Color de las etiquetas', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#C9C6F2', 'selectors' => [ '{{WRAPPER}} .wakoo-cd__lab' => 'color: {{VALUE}};' ] ] );
		$this->add_control( 'radius', [ 'label' => __( 'Redondez (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 12, 'selectors' => [ '{{WRAPPER}} .wakoo-cd__box' => 'border-radius: {{VALUE}}px;' ] ] );
		$this->end_controls_section();
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$mode = $s['mode'] ?? 'date';
		$cfg  = [
			'mode'   => $mode,
			'end'    => $s['end_action'] ?? 'message',
			'hours'  => max( 1, (int) ( $s['hours'] ?? 24 ) ),
			'key'    => 'wakoo_cd_' . $this->get_id() . '_' . get_the_ID(),
			'target' => 0,
		];
		if ( 'date' === $mode ) {
			try {
				$dt = new \DateTimeImmutable( (string) $s['due'], wp_timezone() );
				$cfg['target'] = $dt->getTimestamp() * 1000;
			} catch ( \Exception $e ) {
				$cfg['target'] = 0;
			}
		}
		$units = [];
		if ( 'yes' === ( $s['show_days'] ?? '' ) ) { $units['d'] = $s['l_d']; }
		$units['h'] = $s['l_h'];
		$units['m'] = $s['l_m'];
		$units['s'] = $s['l_s'];

		echo '<div class="wakoo-cd" data-wakoo="' . esc_attr( wp_json_encode( $cfg ) ) . '" role="timer" aria-live="off">';
		echo '<div class="wakoo-cd__units">';
		foreach ( $units as $k => $label ) {
			echo '<div class="wakoo-cd__box" data-u="' . esc_attr( $k ) . '"><span class="wakoo-cd__num">00</span><span class="wakoo-cd__lab">' . esc_html( $label ) . '</span></div>';
		}
		echo '</div>';
		if ( 'message' === ( $s['end_action'] ?? '' ) ) {
			echo '<div class="wakoo-cd__end" hidden>' . esc_html( $s['end_msg'] ) . '</div>';
		}
		echo '</div>';
	}
}
