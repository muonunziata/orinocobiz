<?php
/**
 * Wakoo Countdown: a countdown to a date, or an "evergreen" one per visitor.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Countdown;

defined( 'ABSPATH' ) || die();

class Module {

	public static function init() {
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_action( 'elementor/frontend/after_register_scripts', function () {
			wp_register_script( 'wakoo-countdown', WAKOO_MODULES_URL . 'countdown/assets/countdown.js', [], WAKOO_VERSION, true );
		} );
		add_action( 'elementor/frontend/after_register_styles', function () {
			wp_register_style( 'wakoo-countdown', WAKOO_MODULES_URL . 'countdown/assets/countdown.css', [], WAKOO_VERSION );
		} );
	}

	public static function register_widget( $wm ) {
		require_once __DIR__ . '/widget.php';
		$wm->register( new Widget() );
	}
}

Module::init();
