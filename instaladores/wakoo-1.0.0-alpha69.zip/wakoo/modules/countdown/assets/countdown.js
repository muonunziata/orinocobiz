( function () {
	'use strict';
	function pad( n ) { return n < 10 ? '0' + n : String( n ); }

	function init( root ) {
		if ( root.dataset.wakooInit ) { return; }
		root.dataset.wakooInit = '1';
		var cfg; try { cfg = JSON.parse( root.getAttribute( 'data-wakoo' ) || '{}' ); } catch ( e ) { cfg = {}; }
		var target = cfg.target || 0;

		if ( 'evergreen' === cfg.mode ) {
			var start = 0;
			try { start = parseInt( localStorage.getItem( cfg.key ) || '0', 10 ); } catch ( e ) {}
			if ( ! start ) {
				start = Date.now();
				try { localStorage.setItem( cfg.key, String( start ) ); } catch ( e ) {}
			}
			target = start + ( cfg.hours || 24 ) * 3600000;
		}
		var boxes = {};
		Array.prototype.forEach.call( root.querySelectorAll( '.wakoo-cd__box' ), function ( b ) { boxes[ b.getAttribute( 'data-u' ) ] = b.querySelector( '.wakoo-cd__num' ); } );
		var units = root.querySelector( '.wakoo-cd__units' );
		var endMsg = root.querySelector( '.wakoo-cd__end' );
		var timer;

		function tick() {
			var left = Math.max( 0, target - Date.now() );
			var s = Math.floor( left / 1000 );
			var d = Math.floor( s / 86400 ), h = Math.floor( ( s % 86400 ) / 3600 ), m = Math.floor( ( s % 3600 ) / 60 ), sec = s % 60;
			if ( ! boxes.d ) { h += d * 24; }
			if ( boxes.d ) { boxes.d.textContent = pad( d ); }
			boxes.h.textContent = pad( h ); boxes.m.textContent = pad( m ); boxes.s.textContent = pad( sec );
			if ( left <= 0 ) {
				clearInterval( timer );
				if ( 'hide' === cfg.end ) { root.style.display = 'none'; }
				else if ( 'message' === cfg.end ) { if ( units ) { units.hidden = true; } if ( endMsg ) { endMsg.hidden = false; } }
			}
		}
		if ( ! target ) { return; }
		tick();
		timer = setInterval( tick, 1000 );
	}
	function boot( scope ) { ( scope && scope.querySelectorAll ? scope : document ).querySelectorAll( '.wakoo-cd' ).forEach( init ); }
	if ( 'loading' === document.readyState ) { document.addEventListener( 'DOMContentLoaded', function () { boot( document ); } ); } else { boot( document ); }
	if ( window.jQuery ) {
		window.jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend && window.elementorFrontend.hooks ) {
				window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-countdown.default', function ( $s ) { boot( $s[ 0 ] ); } );
			}
		} );
	}
}() );
