<?php
/**
 * Wakoo: a "Wakeeame" (Editar con Wakoo) button, mirroring Elementor's
 * "Edit with Elementor". It opens the builder — where Wakoo's widgets and
 * template library live — and appears in three places:
 *   - the admin bar (when editing or viewing a supported post),
 *   - the Posts/Pages list row actions,
 *   - the block editor (Gutenberg) document panel.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Edit_Button;

defined( 'ABSPATH' ) || die();

class Module {

	const LABEL = 'Wakeeame';

	public static function init() {
		add_action( 'admin_bar_menu', [ __CLASS__, 'admin_bar' ], 220 );
		add_filter( 'post_row_actions', [ __CLASS__, 'row_action' ], 20, 2 );
		add_filter( 'page_row_actions', [ __CLASS__, 'row_action' ], 20, 2 );
		add_action( 'enqueue_block_editor_assets', [ __CLASS__, 'block_editor' ] );
		// Admin-bar button styling (front and back), only when the bar shows.
		add_action( 'wp_head', [ __CLASS__, 'admin_bar_css' ], 100 );
		add_action( 'admin_head', [ __CLASS__, 'admin_bar_css' ], 100 );
	}

	/**
	 * Keep the Wakoo admin-bar item from overlapping its neighbours: size and
	 * space its icon explicitly instead of relying on the generic .ab-icon slot.
	 */
	public static function admin_bar_css() {
		if ( ! is_admin_bar_showing() ) {
			return;
		}
		echo '<style id="wakoo-adminbar">'
			. '#wpadminbar #wp-admin-bar-wakoo_edit > .ab-item{display:flex;align-items:center;}'
			. '#wpadminbar #wp-admin-bar-wakoo_edit .ab-icon{margin-right:5px;}'
			. '</style>';
	}

	/**
	 * Whether this post can be edited with the builder by the current user.
	 */
	private static function can_edit( $post_id ) {
		if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
			return false;
		}
		if ( ! class_exists( '\Elementor\Utils' ) || ! \Elementor\Utils::is_post_support( $post_id ) ) {
			return false;
		}
		$post = get_post( $post_id );
		return $post && 'trash' !== $post->post_status;
	}

	private static function edit_url( $post_id ) {
		return add_query_arg(
			[ 'post' => $post_id, 'action' => 'elementor' ],
			admin_url( 'post.php' )
		);
	}

	public static function admin_bar( $wp_admin_bar ) {
		$post_id = 0;
		if ( is_admin() ) {
			$post_id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
		} elseif ( is_singular() ) {
			$post_id = get_queried_object_id();
		}
		if ( ! self::can_edit( $post_id ) ) {
			return;
		}
		$wp_admin_bar->add_node( [
			'id'    => 'wakoo_edit',
			'title' => '<span class="ab-icon" aria-hidden="true"></span><span class="ab-label">' . esc_html( self::LABEL ) . '</span>',
			'href'  => self::edit_url( $post_id ),
			'meta'  => [ 'title' => __( 'Editar con Wakoo', 'wakoo' ) ],
		] );
	}

	public static function row_action( $actions, $post ) {
		if ( self::can_edit( $post->ID ) ) {
			$actions['wakoo_edit'] = sprintf(
				'<a href="%s">%s</a>',
				esc_url( self::edit_url( $post->ID ) ),
				esc_html( self::LABEL . ' (' . __( 'editar con Wakoo', 'wakoo' ) . ')' )
			);
		}
		return $actions;
	}

	public static function block_editor() {
		$post_id = get_the_ID();
		if ( ! self::can_edit( $post_id ) ) {
			return;
		}
		wp_enqueue_script(
			'wakoo-edit-button',
			WAKOO_MODULES_URL . 'edit-button/block-editor.js',
			[ 'wp-plugins', 'wp-edit-post', 'wp-element', 'wp-components', 'wp-i18n' ],
			WAKOO_VERSION,
			true
		);
		wp_localize_script( 'wakoo-edit-button', 'WakooEditButton', [
			'url'   => self::edit_url( $post_id ),
			'label' => self::LABEL,
			'title' => __( 'Editar con Wakoo', 'wakoo' ),
		] );
	}
}

Module::init();
