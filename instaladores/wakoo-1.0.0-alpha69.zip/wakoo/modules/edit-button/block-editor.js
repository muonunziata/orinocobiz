( function ( wp ) {
	'use strict';
	var cfg = window.WakooEditButton || {};
	if ( ! wp || ! wp.plugins || ! wp.editPost || ! wp.element || ! cfg.url ) {
		return;
	}
	var el = wp.element.createElement;
	var PluginDocumentSettingPanel = wp.editPost.PluginDocumentSettingPanel;
	var Button = wp.components.Button;

	function Panel() {
		return el(
			PluginDocumentSettingPanel,
			{ name: 'wakoo-edit', title: cfg.label, className: 'wakoo-edit-panel' },
			el(
				Button,
				{
					variant: 'primary',
					className: 'wakoo-edit-btn',
					style: { width: '100%', justifyContent: 'center' },
					href: cfg.url,
					title: cfg.title,
				},
				cfg.label
			)
		);
	}

	wp.plugins.registerPlugin( 'wakoo-edit-button', {
		render: Panel,
		icon: 'admin-customizer',
	} );
}( window.wp ) );
