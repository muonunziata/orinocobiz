<?php
/**
 * Wakoo admin menu: one entry in the WordPress sidebar.
 *
 * Every top-level menu a Wakoo module adds (Lugares, Miembros, Popups, SEO…) is
 * taken out of the sidebar and shown as a button on the Wakoo dashboard (Home
 * tab): «Exportar / importar» and «Idiomas» on their own, the rest as drop-down
 * menus with their icon on top. The pages keep their addresses and permissions;
 * while one is open, the «Wakoo» sidebar entry stays highlighted.
 * Filter `wakoo_compact_menu` (false) keeps the old sidebar.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\AdminMenu;

defined( 'ABSPATH' ) || die();

class Module {

	const HOME = 'wakoo';

	/** Pages shown as their own buttons, in this order. */
	const SOLO = [ 'wakoo-portable', 'wakoo-idiomas' ];

	/** [ [ 'slug', 'title', 'icon', 'url', 'items' => [ [ 'slug', 'title', 'url' ] ] ] ] */
	private static $groups = [];

	/** Page slug or menu file → slug of the group it was moved from. */
	private static $owner = [];

	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'collect' ], PHP_INT_MAX );
		add_action( 'admin_footer', [ __CLASS__, 'highlight' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'assets' ] );
	}

	private static function is_ours( $slug ) {
		return self::HOME !== $slug && ( 0 === strpos( $slug, 'wakoo-' ) || false !== strpos( $slug, 'post_type=wakoo_' ) );
	}

	/** Plain menu title: no counters or bubbles. */
	private static function clean( $title ) {
		return trim( wp_strip_all_tags( preg_replace( '#<span[^>]*>.*?</span>#s', '', (string) $title ) ) );
	}

	/** Same address rule as wp-admin/menu-header.php. */
	private static function url( $slug, $parent ) {
		if ( false !== strpos( $slug, '.php' ) ) {
			return admin_url( $slug );
		}
		$file = strtok( $parent, '?' );
		if ( get_plugin_page_hook( $slug, $parent ) && 'admin.php' !== $file && false !== strpos( $file, '.php' ) && file_exists( ABSPATH . 'wp-admin/' . $file ) ) {
			return admin_url( add_query_arg( 'page', $slug, $parent ) );
		}
		return admin_url( 'admin.php?page=' . $slug );
	}

	public static function collect() {
		global $menu, $submenu;
		if ( ! apply_filters( 'wakoo_compact_menu', true ) || ! is_array( $menu ) ) {
			return;
		}
		// Shorter names for some groups (the sidebar titles repeat «Wakoo»).
		$names = [ 'wakoo-seo' => __( 'SEO y sitio', 'wakoo' ), 'wakoo-setup-wizard' => __( 'Asistente', 'wakoo' ) ];
		foreach ( $menu as $pos => $m ) {
			$slug = $m[2] ?? '';
			if ( ! self::is_ours( $slug ) || ! current_user_can( $m[1] ) ) {
				continue;
			}
			$items = [];
			foreach ( (array) ( $submenu[ $slug ] ?? [] ) as $s ) {
				if ( ! current_user_can( $s[1] ) ) { continue; }
				$items[] = [ 'slug' => $s[2], 'title' => self::clean( $s[0] ), 'url' => self::url( $s[2], $slug ) ];
				self::$owner[ $s[2] ] = $slug;
			}
			self::$owner[ $slug ] = $slug;
			$icon = ( isset( $m[6] ) && 0 === strpos( $m[6], 'dashicons-' ) ) ? $m[6] : 'dashicons-admin-generic';
			self::$groups[] = [
				'slug'  => $slug,
				'title' => $names[ $slug ] ?? trim( preg_replace( '/\s*Wakoo\s*/u', ' ', self::clean( $m[0] ) ) ),
				'icon'  => $icon,
				'url'   => self::url( $slug, 'admin.php' ),
				'items' => $items,
			];
			unset( $menu[ $pos ] ); // The page itself stays registered: only the sidebar entry goes.
		}
	}

	/** True on a page that was moved out of the sidebar. */
	private static function on_moved_page() {
		global $plugin_page, $typenow;
		foreach ( array_filter( [ $plugin_page, $typenow ? 'edit.php?post_type=' . $typenow : '' ] ) as $k ) {
			if ( isset( self::$owner[ $k ] ) ) { return true; }
		}
		return false;
	}

	/**
	 * Keep «Wakoo» open in the sidebar on the moved pages. The `parent_file` filter
	 * can't do it: menu-header.php runs get_admin_page_parent() right after it.
	 */
	public static function highlight() {
		if ( ! self::on_moved_page() ) { return; }
		echo "<script>( function () { var li = document.getElementById( 'toplevel_page_" . esc_js( self::HOME ) . "' ); if ( li ) { li.classList.remove( 'wp-not-current-submenu' ); li.classList.add( 'wp-has-current-submenu', 'wp-menu-open' ); var a = li.querySelector( 'a.menu-top' ); if ( a ) { a.classList.add( 'wp-has-current-submenu' ); } } }() );</script>";
	}

	public static function assets() {
		if ( isset( $_GET['page'] ) && self::HOME === $_GET['page'] ) { // phpcs:ignore WordPress.Security.NonceVerification
			wp_enqueue_style( 'dashicons' );
		}
	}

	/** Buttons for the dashboard Home tab. */
	public static function render() {
		if ( ! self::$groups ) {
			return;
		}
		$solo = [];
		foreach ( self::$groups as $gi => $g ) {
			foreach ( $g['items'] as $ii => $it ) {
				if ( in_array( $it['slug'], self::SOLO, true ) ) {
					$solo[ $it['slug'] ] = $it;
					unset( self::$groups[ $gi ]['items'][ $ii ] );
				}
			}
		}
		$icons = [ 'wakoo-portable' => 'dashicons-migrate', 'wakoo-idiomas' => 'dashicons-translation' ];
		echo '<div class="wk-tools"><h3 class="wk-tools__title">' . esc_html__( 'Herramientas de Wakoo', 'wakoo' ) . '</h3><div class="wk-tools__row">';
		foreach ( self::SOLO as $slug ) {
			if ( empty( $solo[ $slug ] ) ) { continue; }
			printf( '<a class="wk-tool wk-tool--solo" href="%s"><span class="dashicons %s" aria-hidden="true"></span><span class="wk-tool__label">%s</span></a>',
				esc_url( $solo[ $slug ]['url'] ), esc_attr( $icons[ $slug ] ), esc_html( $solo[ $slug ]['title'] ) );
		}
		foreach ( self::$groups as $g ) {
			$items = array_values( $g['items'] );
			if ( count( $items ) < 2 ) { // A single page: a plain button.
				printf( '<a class="wk-tool" href="%s"><span class="dashicons %s" aria-hidden="true"></span><span class="wk-tool__label">%s</span></a>',
					esc_url( $items ? $items[0]['url'] : $g['url'] ), esc_attr( $g['icon'] ), esc_html( $g['title'] ) );
				continue;
			}
			echo '<details class="wk-tool wk-tool--menu"><summary><span class="dashicons ' . esc_attr( $g['icon'] ) . '" aria-hidden="true"></span><span class="wk-tool__label">' . esc_html( $g['title'] ) . '</span><span class="wk-tool__caret" aria-hidden="true"></span></summary><ul>';
			foreach ( $items as $it ) {
				echo '<li><a href="' . esc_url( $it['url'] ) . '">' . esc_html( $it['title'] ) . '</a></li>';
			}
			echo '</ul></details>';
		}
		echo '</div></div>';
		self::style();
	}

	private static function style() {
		?>
		<style>
			.wk-tools{margin:28px 0 0}
			.wk-tools__title{margin:0 0 14px;font-size:16px;color:#1d2327}
			.wk-tools__row{display:flex;flex-wrap:wrap;gap:12px;align-items:flex-start}
			.wk-tool{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;width:118px;min-height:96px;box-sizing:border-box;
				padding:16px 10px 12px;border:1px solid #dcdcde;border-radius:12px;background:#fff;color:#1d2327;text-decoration:none;text-align:center;font-weight:600;font-size:13px;line-height:1.25;transition:border-color .15s,box-shadow .15s,transform .15s}
			.wk-tool:hover,.wk-tool:focus-within,.wk-tool[open]{border-color:#7a3bd1;box-shadow:0 8px 22px -12px rgba(90,40,160,.55);color:#1d2327}
			a.wk-tool:hover{transform:translateY(-2px)}
			.wk-tool .dashicons,.wk-tool .dashicons:before{font-family:dashicons!important;font-style:normal!important;font-weight:400!important}
			.wk-tool .dashicons{width:30px;height:30px;font-size:30px;line-height:1;color:#7a3bd1}
			.wk-tool--solo{width:150px;background:linear-gradient(135deg,#c2459d,#6c3bd1);border-color:transparent;color:#fff}
			.wk-tool--solo .dashicons{color:#fff}
			.wk-tool--solo:hover,.wk-tool--solo:focus{color:#fff;border-color:transparent}
			.wk-tool--menu{padding:0}
			.wk-tool--menu summary{list-style:none;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:8px;padding:16px 10px 12px;width:100%;box-sizing:border-box;border-radius:12px}
			.wk-tool--menu summary::-webkit-details-marker{display:none}
			.wk-tool--menu summary:focus-visible{outline:2px solid #7a3bd1;outline-offset:2px}
			.wk-tool__caret{width:0;height:0;border:5px solid transparent;border-top-color:#8c8f94;margin-top:-2px}
			.wk-tool[open] .wk-tool__caret{transform:rotate(180deg);margin-top:-8px}
			.wk-tool--menu ul{position:absolute;z-index:20;top:calc(100% + 6px);left:0;min-width:220px;margin:0;padding:6px;list-style:none;background:#fff;border:1px solid #dcdcde;border-radius:10px;box-shadow:0 14px 34px -14px rgba(0,0,0,.35);text-align:left}
			.wk-tool--menu li{margin:0}
			.wk-tool--menu li a{display:block;padding:8px 10px;border-radius:6px;color:#1d2327;font-weight:500;text-decoration:none}
			.wk-tool--menu li a:hover,.wk-tool--menu li a:focus{background:#f3eefc;color:#5a28a0}
		</style>
		<script>
			( function () {
				var menus = document.querySelectorAll( '.wk-tool--menu' );
				// Only one menu open at a time; a click outside or Esc closes it.
				menus.forEach( function ( d ) {
					d.addEventListener( 'toggle', function () { if ( d.open ) { menus.forEach( function ( o ) { if ( o !== d ) { o.open = false; } } ); } } );
				} );
				document.addEventListener( 'click', function ( e ) { menus.forEach( function ( d ) { if ( ! d.contains( e.target ) ) { d.open = false; } } ); } );
				document.addEventListener( 'keydown', function ( e ) {
					if ( 'Escape' !== e.key ) { return; }
					menus.forEach( function ( d ) { if ( d.open ) { d.open = false; d.querySelector( 'summary' ).focus(); } } );
				} );
			}() );
		</script>
		<?php
	}
}

Module::init();
