<?php
/**
 * Wakoo table-of-contents widget.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Toc;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Widget extends Widget_Base {

	public function get_name() { return 'wakoo-toc'; }
	public function get_title() { return __( 'Índice de contenidos (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-table-of-contents'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'toc', 'indice', 'tabla', 'contenidos', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-toc' ]; }
	public function get_style_depends() { return [ 'wakoo-toc' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec', [ 'label' => __( 'Índice', 'wakoo' ) ] );

		$this->add_control( 'title', [
			'label'   => __( 'Título', 'wakoo' ),
			'type'    => Controls_Manager::TEXT,
			'default' => __( 'Contenido', 'wakoo' ),
		] );
		$this->add_control( 'levels', [
			'label'   => __( 'Niveles de encabezado', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'h2h3',
			'options' => [
				'h2'     => 'H2',
				'h2h3'   => 'H2 + H3',
				'h2h3h4' => 'H2 + H3 + H4',
			],
		] );
		$this->add_control( 'content_selector', [
			'label'       => __( 'Contenedor a analizar', 'wakoo' ),
			'type'        => Controls_Manager::TEXT,
			'default'     => '.elementor',
			'description' => __( 'Selector CSS del área cuyos encabezados se listan. Por defecto toda la página.', 'wakoo' ),
			'label_block' => true,
		] );
		$this->add_control( 'sticky', [
			'label'        => __( 'Fijar al hacer scroll', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => '',
		] );
		$this->add_control( 'sticky_offset', [
			'label'     => __( 'Separación al fijar (px)', 'wakoo' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => [ 'px' => [ 'min' => 0, 'max' => 200 ] ],
			'default'   => [ 'size' => 20 ],
			'condition' => [ 'sticky' => 'yes' ],
		] );

		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$map = [
			'h2'     => 'h2',
			'h2h3'   => 'h2, h3',
			'h2h3h4' => 'h2, h3, h4',
		];
		$headings = $map[ $s['levels'] ?? 'h2h3' ] ?? 'h2, h3';
		$id = 'wakoo-toc-' . $this->get_id();
		$sticky = ( 'yes' === ( $s['sticky'] ?? '' ) );
		$offset = (int) ( $s['sticky_offset']['size'] ?? 20 );

		$cfg = [
			'content'  => trim( $s['content_selector'] ?? '.elementor' ) ?: '.elementor',
			'headings' => $headings,
			'list'     => '#' . $id . ' .wakoo-toc__list',
			'sticky'   => $sticky,
			'offset'   => $offset,
		];

		$cls = 'wakoo-toc' . ( $sticky ? ' wakoo-toc--sticky' : '' );
		$style = $sticky ? sprintf( ' style="position:sticky;top:%dpx;"', $offset ) : '';
		printf( '<nav id="%s" class="%s"%s data-wakoo-toc="%s">', esc_attr( $id ), esc_attr( $cls ), $style, esc_attr( wp_json_encode( $cfg ) ) );
		if ( ! empty( $s['title'] ) ) {
			printf( '<div class="wakoo-toc__title">%s</div>', esc_html( $s['title'] ) );
		}
		echo '<div class="wakoo-toc__list"></div>';
		echo '<div class="wakoo-toc__empty" hidden>' . esc_html__( 'No se encontraron encabezados.', 'wakoo' ) . '</div>';
		echo '</nav>';
	}
}
