<?php
/**
 * Wakoo: automatic table of contents.
 *
 * A widget that builds a clickable table of contents from the headings on the
 * page, with optional sticky behaviour and scroll-spy highlighting. Powered by
 * tocbot (MIT, bundled in vendor/ with CREDITS.txt). No GSAP.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Toc;

defined( 'ABSPATH' ) || die();

class Module {

	public static function init() {
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'assets' ] );
		add_action( 'elementor/frontend/after_register_styles', [ __CLASS__, 'styles' ] );
	}

	public static function register_widget( $wm ) {
		require_once __DIR__ . '/widget.php';
		$wm->register( new Widget() );
	}

	public static function assets() {
		wp_register_script( 'wakoo-tocbot', WAKOO_MODULES_URL . 'toc/vendor/tocbot.min.js', [], '4.25.0', true );
		wp_register_script( 'wakoo-toc', WAKOO_MODULES_URL . 'toc/assets/toc.js', [ 'wakoo-tocbot' ], WAKOO_VERSION, true );
	}

	public static function styles() {
		wp_register_style( 'wakoo-toc', WAKOO_MODULES_URL . 'toc/assets/toc.css', [], WAKOO_VERSION );
	}
}

Module::init();
