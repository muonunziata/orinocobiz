( function () {
	'use strict';

	function build( nav ) {
		if ( nav.dataset.wakooTocInit ) { return; }
		nav.dataset.wakooTocInit = '1';
		if ( ! window.tocbot ) { return; }

		var cfg;
		try { cfg = JSON.parse( nav.getAttribute( 'data-wakoo-toc' ) || '{}' ); } catch ( e ) { return; }

		var content = document.querySelector( cfg.content );
		if ( ! content ) { content = document.body; }

		var offset = cfg.sticky ? ( cfg.offset + 10 ) : 0;

		try {
			window.tocbot.init( {
				tocSelector: cfg.list,
				contentElement: content,
				headingSelector: cfg.headings || 'h2, h3',
				hasInnerContainers: true,
				scrollSmooth: true,
				headingsOffset: offset,
				scrollSmoothOffset: -offset,
				// Don't let the TOC list its own heading or other TOCs.
				ignoreSelector: '.wakoo-toc *',
			} );
		} catch ( e ) {
			return;
		}

		// Show an "empty" note when the page has no matching headings.
		window.setTimeout( function () {
			var list = nav.querySelector( '.wakoo-toc__list' );
			var empty = nav.querySelector( '.wakoo-toc__empty' );
			if ( list && empty && ! list.querySelector( 'a' ) ) {
				list.setAttribute( 'hidden', '' );
				empty.removeAttribute( 'hidden' );
			}
		}, 300 );
	}

	function boot( scope ) {
		( scope || document ).querySelectorAll( '.wakoo-toc' ).forEach( build );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', function () { boot(); } );
	} else {
		boot();
	}
	if ( window.jQuery ) {
		jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend && elementorFrontend.hooks ) {
				elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-toc.default', function ( $s ) { boot( $s[ 0 ] ); } );
			}
		} );
	}
}() );
