/**
 * Wakoo Media Carousel — native image + video carousel. No external library.
 * Autoplay (paused while a video plays), touch/drag swipe, arrows, dots,
 * keyboard, responsive slides-per-view, reduced-motion aware.
 */
( function () {
	'use strict';

	var reduce = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

	function init( root ) {
		if ( root.dataset.wakooInit ) { return; }
		root.dataset.wakooInit = '1';

		var cfg;
		try { cfg = JSON.parse( root.getAttribute( 'data-wakoo' ) || '{}' ); } catch ( e ) { cfg = {}; }
		var viewport = root.querySelector( '.wakoo-mcar__viewport' );
		var track = root.querySelector( '.wakoo-mcar__track' );
		var slides = Array.prototype.slice.call( root.querySelectorAll( '.wakoo-mcar__slide' ) );
		if ( ! track || ! slides.length ) { return; }

		var gap = cfg.gap || 0;
		var index = 0;
		var timer = null;
		var videosPlaying = 0;

		function perView() {
			var w = window.innerWidth;
			if ( w <= 767 ) { return Math.min( cfg.perViewMobile || 1, slides.length ); }
			if ( w <= 1024 ) { return Math.min( cfg.perViewTablet || 2, slides.length ); }
			return Math.min( cfg.perView || 3, slides.length );
		}
		function lastIndex() { return Math.max( 0, slides.length - perView() ); }

		/* ---- layout ---- */
		function layout() {
			var pv = perView();
			track.style.gap = gap + 'px';
			var basis = 'calc((100% - ' + ( gap * ( pv - 1 ) ) + 'px) / ' + pv + ')';
			slides.forEach( function ( s ) {
				s.style.flex = '0 0 ' + basis;
				s.style.maxWidth = basis;
			} );
			if ( index > lastIndex() ) { index = lastIndex(); }
			move( false );
			dotsRender();
		}

		function slideStep() {
			if ( slides.length < 2 ) { return 0; }
			return ( slides[ 1 ].getBoundingClientRect().left - slides[ 0 ].getBoundingClientRect().left );
		}

		function move( animate ) {
			track.style.transition = ( animate && ! reduce ) ? 'transform .45s ease' : 'none';
			track.style.transform = 'translateX(' + ( -index * slideStep() ) + 'px)';
			dotsActive();
		}

		function go( i, animate ) {
			var last = lastIndex();
			if ( cfg.loop ) {
				if ( i < 0 ) { i = last; }
				else if ( i > last ) { i = 0; }
			} else {
				i = Math.max( 0, Math.min( i, last ) );
			}
			index = i;
			move( false !== animate );
		}

		/* ---- dots ---- */
		var dotsWrap = root.querySelector( '.wakoo-mcar__dots' );
		function dotsRender() {
			if ( ! dotsWrap ) { return; }
			dotsWrap.innerHTML = '';
			for ( var i = 0; i <= lastIndex(); i++ ) {
				( function ( n ) {
					var d = document.createElement( 'button' );
					d.type = 'button';
					d.className = 'wakoo-mcar__dot';
					d.setAttribute( 'aria-label', 'Ir a ' + ( n + 1 ) );
					d.addEventListener( 'click', function () { go( n ); restart(); } );
					dotsWrap.appendChild( d );
				}( i ) );
			}
			dotsActive();
		}
		function dotsActive() {
			if ( ! dotsWrap ) { return; }
			var ds = dotsWrap.children;
			for ( var i = 0; i < ds.length; i++ ) {
				ds[ i ].classList.toggle( 'is-active', i === index );
			}
		}

		/* ---- arrows ---- */
		var prev = root.querySelector( '.wakoo-mcar__arrow--prev' );
		var next = root.querySelector( '.wakoo-mcar__arrow--next' );
		if ( prev ) { prev.addEventListener( 'click', function () { go( index - 1 ); restart(); } ); }
		if ( next ) { next.addEventListener( 'click', function () { go( index + 1 ); restart(); } ); }

		/* ---- autoplay ---- */
		function canAuto() { return cfg.autoplay && ! reduce && videosPlaying === 0; }
		function start() {
			stop();
			if ( ! canAuto() ) { return; }
			timer = setInterval( function () { go( index + 1 ); }, cfg.interval || 4000 );
		}
		function stop() { if ( timer ) { clearInterval( timer ); timer = null; } }
		function restart() { stop(); start(); }

		root.addEventListener( 'mouseenter', stop );
		root.addEventListener( 'mouseleave', start );
		root.addEventListener( 'focusin', stop );
		root.addEventListener( 'focusout', start );

		/* ---- video: lazy src + pause others + pause autoplay ---- */
		root.querySelectorAll( '.wakoo-mcar__video' ).forEach( function ( v ) {
			var src = v.querySelector( 'source[data-src]' );
			if ( src && ! src.src ) { src.src = src.getAttribute( 'data-src' ); v.load(); }
			v.addEventListener( 'play', function () {
				videosPlaying++;
				stop();
				root.querySelectorAll( '.wakoo-mcar__video' ).forEach( function ( o ) { if ( o !== v && ! o.paused ) { o.pause(); } } );
			} );
			var done = function () { videosPlaying = Math.max( 0, videosPlaying - 1 ); if ( videosPlaying === 0 ) { start(); } };
			v.addEventListener( 'pause', done );
			v.addEventListener( 'ended', done );
		} );

		/* ---- keyboard ---- */
		root.addEventListener( 'keydown', function ( e ) {
			if ( 'ArrowLeft' === e.key ) { go( index - 1 ); restart(); }
			else if ( 'ArrowRight' === e.key ) { go( index + 1 ); restart(); }
		} );

		/* ---- drag / swipe ---- */
		var dragX = 0, dragging = false, startT = 0;
		function down( e ) {
			if ( e.target.closest( '.wakoo-mcar__video, a' ) ) { return; }
			dragging = true;
			dragX = ( e.touches ? e.touches[ 0 ].clientX : e.clientX );
			startT = -index * slideStep();
			track.style.transition = 'none';
			stop();
		}
		function mv( e ) {
			if ( ! dragging ) { return; }
			var x = ( e.touches ? e.touches[ 0 ].clientX : e.clientX );
			track.style.transform = 'translateX(' + ( startT + ( x - dragX ) ) + 'px)';
		}
		function up( e ) {
			if ( ! dragging ) { return; }
			dragging = false;
			var x = ( e.changedTouches ? e.changedTouches[ 0 ].clientX : e.clientX );
			var d = x - dragX;
			if ( Math.abs( d ) > 40 ) { go( index + ( d < 0 ? 1 : -1 ) ); } else { move( true ); }
			start();
		}
		viewport.addEventListener( 'mousedown', down );
		window.addEventListener( 'mousemove', mv );
		window.addEventListener( 'mouseup', up );
		viewport.addEventListener( 'touchstart', down, { passive: true } );
		viewport.addEventListener( 'touchmove', mv, { passive: true } );
		viewport.addEventListener( 'touchend', up );

		/* ---- resize ---- */
		var rt;
		window.addEventListener( 'resize', function () { clearTimeout( rt ); rt = setTimeout( layout, 150 ); } );

		layout();
		start();
	}

	function boot( scope ) {
		var root = scope && scope.querySelectorAll ? scope : document;
		root.querySelectorAll( '.wakoo-mcar' ).forEach( init );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', function () { boot( document ); } );
	} else {
		boot( document );
	}

	if ( window.jQuery ) {
		window.jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend && window.elementorFrontend.hooks ) {
				window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-media-carousel.default', function ( $scope ) { boot( $scope[ 0 ] ); } );
			}
		} );
	}
}() );
