<?php
/**
 * Wakoo Media Carousel widget: a native carousel of images AND self-hosted
 * videos (no third-party slider library, no external video service).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\MediaCarousel;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Image_Size;

defined( 'ABSPATH' ) || die();

class Widget extends Widget_Base {

	public function get_name() { return 'wakoo-media-carousel'; }
	public function get_title() { return __( 'Carrusel multimedia (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-media-carousel'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'carrusel', 'carousel', 'slider', 'video', 'galeria', 'multimedia', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-media-carousel' ]; }
	public function get_style_depends() { return [ 'wakoo-media-carousel' ]; }

	protected function register_controls() {

		/* ---------- Slides ---------- */
		$this->start_controls_section( 'sec_slides', [ 'label' => __( 'Diapositivas', 'wakoo' ) ] );

		$rep = new Repeater();
		$rep->add_control( 'stype', [
			'label'   => __( 'Tipo', 'wakoo' ),
			'type'    => Controls_Manager::CHOOSE,
			'default' => 'image',
			'options' => [
				'image' => [ 'title' => __( 'Imagen', 'wakoo' ), 'icon' => 'eicon-image' ],
				'video' => [ 'title' => __( 'Vídeo', 'wakoo' ), 'icon' => 'eicon-video-camera' ],
			],
			'toggle'  => false,
		] );
		$rep->add_control( 'simage', [
			'label'     => __( 'Imagen', 'wakoo' ),
			'type'      => Controls_Manager::MEDIA,
			'default'   => [ 'url' => \Elementor\Utils::get_placeholder_image_src() ],
			'condition' => [ 'stype' => 'image' ],
		] );
		$rep->add_control( 'svideo', [
			'label'       => __( 'Vídeo (archivo propio)', 'wakoo' ),
			'type'        => Controls_Manager::MEDIA,
			'media_types' => [ 'video' ],
			'condition'   => [ 'stype' => 'video' ],
		] );
		$rep->add_control( 'sposter', [
			'label'     => __( 'Miniatura del vídeo', 'wakoo' ),
			'type'      => Controls_Manager::MEDIA,
			'condition' => [ 'stype' => 'video' ],
		] );
		$rep->add_control( 'slink', [
			'label'       => __( 'Enlace (solo imagen)', 'wakoo' ),
			'type'        => Controls_Manager::URL,
			'placeholder' => 'https://…',
			'condition'   => [ 'stype' => 'image' ],
		] );
		$rep->add_control( 'scaption', [ 'label' => __( 'Texto', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'label_block' => true ] );

		$this->add_control( 'slides', [
			'label'       => __( 'Diapositivas', 'wakoo' ),
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $rep->get_controls(),
			'title_field' => '{{{ stype === "video" ? "🎬 " : "🖼 " }}}{{{ scaption || "Diapositiva" }}}',
			'default'     => [
				[ 'stype' => 'image' ],
				[ 'stype' => 'image' ],
				[ 'stype' => 'image' ],
			],
		] );

		$this->add_group_control( Group_Control_Image_Size::get_type(), [
			'name'    => 'image_size',
			'default' => 'large',
		] );
		$this->end_controls_section();

		/* ---------- Layout / behaviour ---------- */
		$this->start_controls_section( 'sec_opts', [ 'label' => __( 'Opciones', 'wakoo' ) ] );

		$this->add_responsive_control( 'per_view', [
			'label'          => __( 'Diapositivas visibles', 'wakoo' ),
			'type'           => Controls_Manager::NUMBER,
			'min'            => 1,
			'max'            => 6,
			'default'        => 3,
			'tablet_default' => 2,
			'mobile_default' => 1,
		] );
		$this->add_control( 'gap', [
			'label'   => __( 'Separación (px)', 'wakoo' ),
			'type'    => Controls_Manager::NUMBER,
			'min'     => 0,
			'max'     => 80,
			'default' => 16,
		] );
		$this->add_control( 'ratio', [
			'label'   => __( 'Proporción', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => '16-9',
			'options' => [
				'16-9'  => '16:9',
				'4-3'   => '4:3',
				'1-1'   => '1:1 (cuadrado)',
				'3-4'   => '3:4 (vertical)',
				'auto'  => __( 'Original', 'wakoo' ),
			],
		] );
		$this->add_control( 'autoplay', [ 'label' => __( 'Reproducción automática', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'interval', [
			'label'     => __( 'Intervalo (segundos)', 'wakoo' ),
			'type'      => Controls_Manager::NUMBER,
			'min'       => 1,
			'max'       => 20,
			'default'   => 4,
			'condition' => [ 'autoplay' => 'yes' ],
		] );
		$this->add_control( 'loop', [ 'label' => __( 'Bucle continuo', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'arrows', [ 'label' => __( 'Flechas', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'dots', [ 'label' => __( 'Puntos', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'show_caption', [ 'label' => __( 'Mostrar textos', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();

		/* ---------- Style ---------- */
		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'accent', [
			'label'     => __( 'Color de controles', 'wakoo' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#6C5CE7',
			'selectors' => [ '{{WRAPPER}} .wakoo-mcar' => '--wk-mcar-accent: {{VALUE}};' ],
		] );
		$this->add_control( 'radius', [
			'label'      => __( 'Redondez (px)', 'wakoo' ),
			'type'       => Controls_Manager::NUMBER,
			'min'        => 0,
			'max'        => 40,
			'default'    => 12,
			'selectors'  => [ '{{WRAPPER}} .wakoo-mcar__slide' => 'border-radius: {{VALUE}}px;' ],
		] );
		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$slides = (array) ( $s['slides'] ?? [] );
		if ( ! $slides ) { return; }

		$cfg = [
			'perView'       => max( 1, (int) ( $s['per_view'] ?? 3 ) ),
			'perViewTablet' => max( 1, (int) ( $s['per_view_tablet'] ?? 2 ) ),
			'perViewMobile' => max( 1, (int) ( $s['per_view_mobile'] ?? 1 ) ),
			'gap'           => (int) ( $s['gap'] ?? 16 ),
			'autoplay'      => ( 'yes' === ( $s['autoplay'] ?? '' ) ),
			'interval'      => max( 1, (int) ( $s['interval'] ?? 4 ) ) * 1000,
			'loop'          => ( 'yes' === ( $s['loop'] ?? '' ) ),
			'arrows'        => ( 'yes' === ( $s['arrows'] ?? '' ) ),
			'dots'          => ( 'yes' === ( $s['dots'] ?? '' ) ),
		];
		$ratio = $s['ratio'] ?? '16-9';

		$this->add_render_attribute( 'wrap', 'class', [ 'wakoo-mcar', 'wakoo-mcar--ratio-' . esc_attr( $ratio ) ] );
		$this->add_render_attribute( 'wrap', 'data-wakoo', wp_json_encode( $cfg ) );

		echo '<div ' . $this->get_render_attribute_string( 'wrap' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<div class="wakoo-mcar__viewport"><div class="wakoo-mcar__track">';

		foreach ( $slides as $slide ) {
			$type    = $slide['stype'] ?? 'image';
			$caption = $slide['scaption'] ?? '';
			echo '<div class="wakoo-mcar__slide">';
			echo '<div class="wakoo-mcar__media">';

			if ( 'video' === $type && ! empty( $slide['svideo']['url'] ) ) {
				$poster = ! empty( $slide['sposter']['url'] ) ? ' poster="' . esc_url( $slide['sposter']['url'] ) . '"' : '';
				echo '<video class="wakoo-mcar__video" controls preload="none" playsinline' . $poster . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo '<source data-src="' . esc_url( $slide['svideo']['url'] ) . '">';
				echo '</video>';
			} else {
				$img = '';
				if ( ! empty( $slide['simage']['id'] ) ) {
					$slide['image_size'] = $s['image_size_size'] ?? 'large';
					$slide['image_size_size'] = $s['image_size_size'] ?? 'large';
					$img = Group_Control_Image_Size::get_attachment_image_html( $slide, 'image_size', 'simage' );
				} elseif ( ! empty( $slide['simage']['url'] ) ) {
					$img = '<img src="' . esc_url( $slide['simage']['url'] ) . '" loading="lazy" alt="' . esc_attr( $caption ) . '">';
				}
				if ( ! empty( $slide['slink']['url'] ) ) {
					$this->add_link_attributes( 'lnk_' . md5( $slide['slink']['url'] . $caption ), $slide['slink'] );
					$img = '<a ' . $this->get_render_attribute_string( 'lnk_' . md5( $slide['slink']['url'] . $caption ) ) . '>' . $img . '</a>';
				}
				echo $img; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</div>'; // media

			if ( 'yes' === ( $s['show_caption'] ?? '' ) && '' !== $caption ) {
				echo '<div class="wakoo-mcar__caption">' . esc_html( $caption ) . '</div>';
			}
			echo '</div>'; // slide
		}

		echo '</div></div>'; // track, viewport

		if ( $cfg['arrows'] ) {
			echo '<button type="button" class="wakoo-mcar__arrow wakoo-mcar__arrow--prev" aria-label="' . esc_attr__( 'Anterior', 'wakoo' ) . '">‹</button>';
			echo '<button type="button" class="wakoo-mcar__arrow wakoo-mcar__arrow--next" aria-label="' . esc_attr__( 'Siguiente', 'wakoo' ) . '">›</button>';
		}
		if ( $cfg['dots'] ) {
			echo '<div class="wakoo-mcar__dots" role="tablist"></div>';
		}

		echo '</div>'; // wrap
	}
}
