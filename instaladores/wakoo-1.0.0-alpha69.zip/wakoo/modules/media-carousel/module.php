<?php
/**
 * Wakoo Media Carousel module: registers the native image + video carousel
 * widget and its assets. No third-party slider library or external service.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\MediaCarousel;

defined( 'ABSPATH' ) || die();

class Module {

	public static function init() {
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'scripts' ] );
		add_action( 'elementor/frontend/after_register_styles', [ __CLASS__, 'styles' ] );
	}

	public static function register_widget( $wm ) {
		require_once __DIR__ . '/widget.php';
		$wm->register( new Widget() );
	}

	public static function scripts() {
		wp_register_script( 'wakoo-media-carousel', WAKOO_MODULES_URL . 'media-carousel/assets/carousel.js', [], WAKOO_VERSION, true );
	}

	public static function styles() {
		wp_register_style( 'wakoo-media-carousel', WAKOO_MODULES_URL . 'media-carousel/assets/carousel.css', [], WAKOO_VERSION );
	}
}

Module::init();
