<?php
/**
 * Wakoo Carpetas: virtual folders for the media library, pages, posts,
 * Elementor templates, popups and places, without moving any file or
 * changing any URL.
 *
 * - Each content type has its own folders: a hierarchical taxonomy
 *   `wkf_<post type>` (no tables of its own, native counts, travels with
 *   WordPress exports, removed with the items).
 * - A folder panel next to the lists (Medios, Páginas, Entradas, Plantillas…):
 *   "Todos", "Sin carpeta", the tree with counts, search, new folder,
 *   rename, subfolder, delete, drag & drop to move items and folders,
 *   a "Mover a carpeta" bulk action for keyboard users, and uploads go to
 *   the folder that is open.
 * - In the media window (Elementor, block editor) a folder filter.
 * - Imports the folders of the MediaFlow Pro plugin if the site has them.
 *
 * Ideas from Virtual Media Folders (Per Søderlind) and Simple Media
 * Library Folders (Misha Rudrastyh), behaviour only.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Folders;

defined( 'ABSPATH' ) || die();

class Module {

	const NONCE = 'wakoo_folders';
	const NONE  = -1; // ?wkf=-1: items without a folder.

	public static function init() {
		add_action( 'init', [ __CLASS__, 'register' ], 20 ); // After the post types of other modules.
		if ( ! is_admin() && ! wp_doing_ajax() ) { return; }
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'assets' ] );
		add_action( 'wp_enqueue_media', [ __CLASS__, 'media_filter' ] );
		add_action( 'pre_get_posts', [ __CLASS__, 'filter_list' ] );
		add_filter( 'ajax_query_attachments_args', [ __CLASS__, 'filter_media' ] );
		add_action( 'add_attachment', [ __CLASS__, 'upload_into_folder' ] );
		foreach ( [ 'tree', 'create', 'rename', 'delete', 'move', 'assign', 'import_mfp', 'auto' ] as $a ) {
			add_action( 'wp_ajax_wakoo_folders_' . $a, [ __CLASS__, 'ajax_' . $a ] );
		}
		add_action( 'admin_init', [ __CLASS__, 'bulk_hooks' ] );
	}

	/** Post types with folders (filter `wakoo_folder_types`). */
	public static function types() {
		$t = [ 'attachment', 'page', 'post', 'elementor_library', 'wakoo_popup', 'wakoo_place', 'product' ];
		return array_values( array_filter( (array) apply_filters( 'wakoo_folder_types', $t ), 'post_type_exists' ) );
	}

	public static function tax( $type ) {
		return 'wkf_' . sanitize_key( $type );
	}

	public static function register() {
		foreach ( self::types() as $type ) {
			register_taxonomy( self::tax( $type ), $type, [
				'labels'                => [ 'name' => __( 'Carpetas', 'wakoo' ), 'singular_name' => __( 'Carpeta', 'wakoo' ) ],
				'public'                => false,
				'show_ui'               => false,
				'show_in_rest'          => false,
				'hierarchical'          => true,
				'rewrite'               => false,
				'query_var'             => false,
				'update_count_callback' => '_update_generic_term_count', // Count drafts and media too.
			] );
		}
	}

	/** Who may organise a type: whoever can edit other people's items of that type (media: upload files). */
	private static function can( $type ) {
		if ( 'attachment' === $type ) { return current_user_can( 'upload_files' ); }
		$o = get_post_type_object( $type );
		return $o && current_user_can( $o->cap->edit_others_posts );
	}

	/** The list screen we are on: post type of edit.php / upload.php, or ''. */
	private static function screen_type() {
		$s = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $s ) { return ''; }
		if ( 'upload' === $s->base ) { return 'attachment'; }
		return ( 'edit' === $s->base && in_array( $s->post_type, self::types(), true ) ) ? $s->post_type : '';
	}

	/** Folder tree of a type: [ { id, name, parent, count } ], plus totals. */
	public static function tree( $type ) {
		$terms = get_terms( [ 'taxonomy' => self::tax( $type ), 'hide_empty' => false, 'orderby' => 'name' ] );
		$out   = [];
		foreach ( is_wp_error( $terms ) ? [] : $terms as $t ) {
			$out[] = [ 'id' => (int) $t->term_id, 'name' => html_entity_decode( $t->name, ENT_QUOTES, 'UTF-8' ), 'parent' => (int) $t->parent, 'count' => (int) $t->count ];
		}
		$status = 'attachment' === $type ? [ 'inherit', 'private' ] : [ 'publish', 'draft', 'pending', 'private', 'future' ];
		$base   = [ 'post_type' => $type, 'post_status' => $status, 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => false ];
		$all    = new \WP_Query( $base );
		$none   = new \WP_Query( $base + [ 'tax_query' => [ [ 'taxonomy' => self::tax( $type ), 'operator' => 'NOT EXISTS' ] ] ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
		return [ 'folders' => $out, 'all' => (int) $all->found_posts, 'none' => (int) $none->found_posts ];
	}

	/** Folder from a path of names, created where missing: [ 'Páginas', 'Inicio' ] → term id of "Inicio" (0 if it cannot). */
	public static function ensure_path( $type, array $names ) {
		$tax = self::tax( $type );
		if ( ! taxonomy_exists( $tax ) ) { return 0; }
		$parent = 0;
		foreach ( $names as $n ) {
			$n = sanitize_text_field( (string) $n );
			if ( '' === $n ) { continue; }
			$found = 0;
			foreach ( get_terms( [ 'taxonomy' => $tax, 'parent' => $parent, 'hide_empty' => false ] ) as $t ) {
				if ( 0 === strcasecmp( html_entity_decode( $t->name, ENT_QUOTES, 'UTF-8' ), $n ) ) { $found = (int) $t->term_id; break; }
			}
			if ( ! $found ) {
				$r = wp_insert_term( $n, $tax, [ 'parent' => $parent, 'slug' => sanitize_title( $n ) . '-' . wp_generate_password( 4, false, false ) ] );
				if ( is_wp_error( $r ) ) { return 0; }
				$found = (int) $r['term_id'];
			}
			$parent = $found;
		}
		return $parent;
	}

	/** Names from the top folder down to this one. */
	public static function path_of( $term_id, $type ) {
		$path = [];
		$tax  = self::tax( $type );
		for ( $i = 0; $term_id && $i < 20; $i++ ) {
			$t = get_term( (int) $term_id, $tax );
			if ( ! $t || is_wp_error( $t ) ) { break; }
			array_unshift( $path, html_entity_decode( $t->name, ENT_QUOTES, 'UTF-8' ) );
			$term_id = (int) $t->parent;
		}
		return $path;
	}

	/** The folder an item is in (0 = none). */
	public static function folder_of( $post_id, $type ) {
		$t = taxonomy_exists( self::tax( $type ) ) ? wp_get_object_terms( (int) $post_id, self::tax( $type ), [ 'fields' => 'ids' ] ) : [];
		return ( ! is_wp_error( $t ) && $t ) ? (int) $t[0] : 0;
	}

	/** Images used by a page/post/template: Elementor image controls, upload URLs and the featured image. */
	public static function media_in( $post_id ) {
		static $by_url = [];
		$ids  = [];
		$base = trailingslashit( wp_get_upload_dir()['baseurl'] );
		$walk = function ( $node ) use ( &$walk, &$ids, &$by_url, $base ) {
			if ( ! is_array( $node ) ) { return; }
			if ( isset( $node['url'] ) && is_string( $node['url'] ) && 0 === strpos( $node['url'], $base ) ) {
				$id = isset( $node['id'] ) && is_numeric( $node['id'] ) ? (int) $node['id'] : 0;
				if ( ! $id || 'attachment' !== get_post_type( $id ) ) {
					$u  = preg_replace( '/-\d+x\d+(?=\.[a-z0-9]+$)/i', '', $node['url'] ); // A resized copy belongs to its original.
					$id = $by_url[ $u ] ?? ( $by_url[ $u ] = (int) attachment_url_to_postid( $u ) );
				}
				if ( $id ) { $ids[] = $id; }
			}
			foreach ( $node as $v ) { $walk( $v ); }
		};
		$data = json_decode( (string) get_post_meta( $post_id, '_elementor_data', true ), true );
		$walk( is_array( $data ) ? $data : [] );
		$thumb = (int) get_post_thumbnail_id( $post_id );
		if ( $thumb ) { $ids[] = $thumb; }
		return array_values( array_unique( $ids ) );
	}

	/**
	 * "Ordenar automáticamente".
	 * Media: a folder per page ("Páginas › Inicio", "Entradas › …", "Plantillas › …"), with each image the page uses;
	 * images used by several pages go to "Compartidas". Pages, posts, templates: a folder per language (Wakoo Idiomas).
	 * Only items without a folder move, unless $all.
	 */
	public static function organize( $type, $all = false ) {
		$n = 0;
		if ( 'attachment' === $type ) {
			$groups = [ 'page' => __( 'Páginas', 'wakoo' ), 'post' => __( 'Entradas', 'wakoo' ), 'elementor_library' => __( 'Plantillas', 'wakoo' ), 'wakoo_popup' => __( 'Popups', 'wakoo' ) ];
			$usage  = [];
			foreach ( $groups as $pt => $label ) {
				if ( ! post_type_exists( $pt ) ) { continue; }
				$posts = get_posts( [ 'post_type' => $pt, 'post_status' => [ 'publish', 'draft', 'private' ], 'posts_per_page' => 500, 'meta_key' => '_elementor_data', 'orderby' => 'menu_order title', 'order' => 'ASC' ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
				$I = class_exists( '\Wakoo\Modules\Idiomas\Module' ) ? '\Wakoo\Modules\Idiomas\Module' : '';
				foreach ( $posts as $p ) {
					// The translations of a page are one page: its folder takes the master's name.
					$master = $p->ID;
					if ( $I ) { $tr = $I::translations( $p->ID ); $master = (int) ( $tr[ $I::default_lang() ] ?? $p->ID ); }
					$title = html_entity_decode( get_the_title( $master ), ENT_QUOTES, 'UTF-8' ) ?: '#' . $p->ID;
					foreach ( self::media_in( $p->ID ) as $aid ) { $usage[ $aid ][ $label . "\n" . $title ] = [ $label, $title ]; }
				}
			}
			foreach ( $usage as $aid => $paths ) {
				if ( ! $all && self::folder_of( $aid, 'attachment' ) ) { continue; }
				$path = 1 === count( $paths ) ? array_values( $paths )[0] : [ __( 'Compartidas', 'wakoo' ) ];
				$fid  = self::ensure_path( 'attachment', $path );
				if ( $fid && current_user_can( 'edit_post', $aid ) ) { wp_set_object_terms( $aid, [ $fid ], self::tax( 'attachment' ) ); $n++; }
			}
			return $n;
		}
		if ( ! class_exists( '\Wakoo\Modules\Idiomas\Module' ) ) { return 0; }
		$langs = \Wakoo\Modules\Idiomas\Module::languages();
		$ids   = get_posts( [ 'post_type' => $type, 'post_status' => [ 'publish', 'draft', 'private', 'pending' ], 'posts_per_page' => 1000, 'fields' => 'ids' ] );
		foreach ( $ids as $id ) {
			if ( ! $all && self::folder_of( $id, $type ) ) { continue; }
			$code = \Wakoo\Modules\Idiomas\Module::lang_of( $id );
			$fid  = self::ensure_path( $type, [ $langs[ $code ] ?? strtoupper( $code ) ] );
			if ( $fid && current_user_can( 'edit_post', $id ) ) { wp_set_object_terms( $id, [ $fid ], self::tax( $type ) ); $n++; }
		}
		return $n;
	}

	/* ---------------------------------------------------------------- assets */

	public static function assets() {
		$type = self::screen_type();
		if ( ! $type || ! self::can( $type ) ) { return; }
		$u = WAKOO_MODULES_URL . 'folders/assets/';
		wp_enqueue_style( 'wakoo-folders', $u . 'folders.css', [], WAKOO_VERSION );
		wp_enqueue_script( 'wakoo-folders', $u . 'folders.js', [ 'jquery' ], WAKOO_VERSION, true );
		$current = isset( $_GET['wkf'] ) ? (int) $_GET['wkf'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$hasMfp  = self::mfp_available();
		wp_localize_script( 'wakoo-folders', 'WakooFolders', [
			'ajax'    => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( self::NONCE ),
			'type'    => $type,
			'current' => $current,
			'grid'    => 'attachment' === $type && 'list' !== ( isset( $_GET['mode'] ) ? sanitize_key( $_GET['mode'] ) : get_user_option( 'media_library_mode', get_current_user_id() ) ), // phpcs:ignore WordPress.Security.NonceVerification
			'tree'    => self::tree( $type ),
			'mfp'     => $hasMfp,
			'auto'    => 'attachment' === $type || ( class_exists( '\Wakoo\Modules\Idiomas\Module' ) && in_array( $type, [ 'page', 'post', 'elementor_library', 'wakoo_popup' ], true ) ),
			't'       => [
				'title'    => __( 'Carpetas', 'wakoo' ),
				'all'      => __( 'Todos', 'wakoo' ),
				'none'     => __( 'Sin carpeta', 'wakoo' ),
				'new'      => __( 'Nueva carpeta', 'wakoo' ),
				'newSub'   => __( 'Nueva subcarpeta', 'wakoo' ),
				'name'     => __( 'Nombre de la carpeta', 'wakoo' ),
				'search'   => __( 'Buscar carpeta…', 'wakoo' ),
				'rename'   => __( 'Cambiar nombre', 'wakoo' ),
				'delete'   => __( 'Borrar carpeta', 'wakoo' ),
				'toRoot'   => __( 'Sacar al nivel principal', 'wakoo' ),
				'confirm'  => __( '¿Borrar la carpeta «%s»? Lo que contiene no se borra: queda sin carpeta y sus subcarpetas suben un nivel.', 'wakoo' ),
				'actions'  => __( 'Opciones de la carpeta', 'wakoo' ),
				'drag'     => __( 'Arrastra elementos o carpetas aquí', 'wakoo' ),
				'moved'    => __( 'Movido a «%s».', 'wakoo' ),
				'hide'     => __( 'Ocultar carpetas', 'wakoo' ),
				'show'     => __( 'Carpetas', 'wakoo' ),
				'empty'    => __( 'Aún no hay carpetas. Crea la primera con «+».', 'wakoo' ),
				'mfp'      => __( 'Importar carpetas de MediaFlow', 'wakoo' ),
				'mfpDone'  => __( 'Carpetas importadas: %1$d. Elementos colocados: %2$d.', 'wakoo' ),
				'error'    => __( 'No se pudo completar. Recarga la página e inténtalo de nuevo.', 'wakoo' ),
				'expand'   => __( 'Abrir o cerrar', 'wakoo' ),
				'auto'     => __( 'Ordenar automáticamente', 'wakoo' ),
				'autoAsk'  => 'attachment' === $type
					? __( 'Wakoo creará una carpeta por página («Páginas › Inicio», «Entradas › …») y pondrá en cada una las imágenes que usa; las que usan varias páginas van a «Compartidas». Lo que ya está en una carpeta no se mueve. ¿Seguimos?', 'wakoo' )
					: __( 'Wakoo creará una carpeta por idioma y pondrá en ella cada elemento. Lo que ya está en una carpeta no se mueve. ¿Seguimos?', 'wakoo' ),
				'autoDone' => __( 'Ordenados: %s.', 'wakoo' ),
			],
		] );
	}

	/** Folder filter in the media window (Elementor, block editor, featured image…). */
	public static function media_filter() {
		if ( ! current_user_can( 'upload_files' ) || ! in_array( 'attachment', self::types(), true ) ) { return; }
		$flat = [];
		$tree = self::tree( 'attachment' );
		$walk = function ( $parent, $depth ) use ( &$walk, &$flat, $tree ) {
			foreach ( $tree['folders'] as $f ) {
				if ( $f['parent'] !== $parent ) { continue; }
				$flat[] = [ 'id' => $f['id'], 'name' => str_repeat( '— ', $depth ) . $f['name'], 'count' => $f['count'] ];
				$walk( $f['id'], $depth + 1 );
			}
		};
		$walk( 0, 0 );
		wp_enqueue_script( 'wakoo-folders-media', WAKOO_MODULES_URL . 'folders/assets/media-filter.js', [ 'media-views' ], WAKOO_VERSION, true );
		wp_localize_script( 'wakoo-folders-media', 'WakooFoldersMedia', [
			'folders' => $flat,
			't'       => [ 'all' => __( 'Todas las carpetas', 'wakoo' ), 'none' => __( 'Sin carpeta', 'wakoo' ), 'label' => __( 'Filtrar por carpeta', 'wakoo' ) ],
		] );
	}

	/* ---------------------------------------------------------------- filtering */

	private static function tax_query( $type, $folder ) {
		$tax = self::tax( $type );
		if ( self::NONE === $folder ) { return [ [ 'taxonomy' => $tax, 'operator' => 'NOT EXISTS' ] ]; }
		return [ [ 'taxonomy' => $tax, 'field' => 'term_id', 'terms' => [ $folder ], 'include_children' => false ] ];
	}

	/** List tables (edit.php, upload.php in list mode): ?wkf=<folder> or -1. */
	public static function filter_list( $q ) {
		if ( ! $q->is_main_query() || ! isset( $_GET['wkf'] ) ) { return; } // phpcs:ignore WordPress.Security.NonceVerification
		$type   = self::screen_type();
		$folder = (int) $_GET['wkf']; // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! $type || ! $folder ) { return; }
		$q->set( 'tax_query', array_merge( (array) $q->get( 'tax_query' ), self::tax_query( $type, $folder ) ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
	}

	/** Media grid and media window (WordPress drops unknown props, so the folder is read from the request). */
	public static function filter_media( $args ) {
		$folder = isset( $_REQUEST['query']['wkf'] ) ? (int) $_REQUEST['query']['wkf'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
		if ( $folder && in_array( 'attachment', self::types(), true ) ) {
			$args['tax_query'] = array_merge( (array) ( $args['tax_query'] ?? [] ), self::tax_query( 'attachment', $folder ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		}
		return $args;
	}

	/** A file uploaded while a folder is open goes into that folder. */
	public static function upload_into_folder( $id ) {
		$folder = isset( $_REQUEST['wkf'] ) ? (int) $_REQUEST['wkf'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
		if ( $folder > 0 && current_user_can( 'upload_files' ) && term_exists( $folder, self::tax( 'attachment' ) ) ) {
			wp_set_object_terms( $id, [ $folder ], self::tax( 'attachment' ) );
		}
	}

	/* ---------------------------------------------------------------- bulk action: "Mover a carpeta" */

	public static function bulk_hooks() {
		foreach ( self::types() as $type ) {
			$screen = 'attachment' === $type ? 'upload' : 'edit-' . $type;
			add_filter( 'bulk_actions-' . $screen, function ( $actions ) use ( $type ) {
				if ( ! self::can( $type ) ) { return $actions; }
				$tree = self::tree( $type );
				$actions[ 'wkf_0' ] = '📁 ' . __( 'Quitar de su carpeta', 'wakoo' );
				$walk = function ( $parent, $depth ) use ( &$walk, &$actions, $tree ) {
					foreach ( $tree['folders'] as $f ) {
						if ( $f['parent'] !== $parent ) { continue; }
						/* translators: %s: folder name */
						$actions[ 'wkf_' . $f['id'] ] = '📁 ' . sprintf( __( 'Mover a: %s', 'wakoo' ), str_repeat( '— ', $depth ) . $f['name'] );
						$walk( $f['id'], $depth + 1 );
					}
				};
				$walk( 0, 0 );
				return $actions;
			} );
			add_filter( 'handle_bulk_actions-' . $screen, function ( $redirect, $action, $ids ) use ( $type ) {
				if ( 0 !== strpos( (string) $action, 'wkf_' ) || ! self::can( $type ) ) { return $redirect; }
				$n = self::assign( $type, (int) substr( $action, 4 ), (array) $ids );
				return add_query_arg( 'wkf_moved', $n, $redirect );
			}, 10, 3 );
		}
		add_action( 'admin_notices', function () {
			if ( isset( $_GET['wkf_moved'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				/* translators: %d: items */
				echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sprintf( __( 'Elementos movidos de carpeta: %d.', 'wakoo' ), (int) $_GET['wkf_moved'] ) ) . '</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification
			}
		} );
	}

	/** Put items in a folder (one folder per item; 0 = no folder). Only items the user may edit. */
	public static function assign( $type, $folder, array $ids ) {
		$tax = self::tax( $type );
		if ( $folder > 0 && ! term_exists( $folder, $tax ) ) { return 0; }
		$n = 0;
		foreach ( array_unique( array_map( 'absint', $ids ) ) as $id ) {
			if ( ! $id || get_post_type( $id ) !== $type || ! current_user_can( 'edit_post', $id ) ) { continue; }
			wp_set_object_terms( $id, $folder > 0 ? [ $folder ] : [], $tax );
			$n++;
		}
		return $n;
	}

	/* ---------------------------------------------------------------- ajax */

	private static function guard() {
		check_ajax_referer( self::NONCE, 'nonce' );
		$type = isset( $_POST['type'] ) ? sanitize_key( wp_unslash( $_POST['type'] ) ) : '';
		if ( ! in_array( $type, self::types(), true ) || ! self::can( $type ) ) { wp_send_json_error( [], 403 ); }
		return $type;
	}

	private static function done( $type, $extra = [] ) {
		wp_send_json_success( array_merge( [ 'tree' => self::tree( $type ) ], $extra ) );
	}

	public static function ajax_tree() {
		self::done( self::guard() );
	}

	public static function ajax_create() {
		$type   = self::guard();
		$name   = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		$parent = isset( $_POST['parent'] ) ? absint( $_POST['parent'] ) : 0;
		if ( '' === $name ) { wp_send_json_error( [], 400 ); }
		if ( $parent && ! term_exists( $parent, self::tax( $type ) ) ) { $parent = 0; }
		// Same name in the same place is allowed (WordPress wants unique slugs: give it one).
		$r = wp_insert_term( $name, self::tax( $type ), [ 'parent' => $parent, 'slug' => sanitize_title( $name ) . '-' . wp_generate_password( 4, false, false ) ] );
		if ( is_wp_error( $r ) ) { wp_send_json_error( [ 'message' => $r->get_error_message() ], 400 ); }
		self::done( $type, [ 'id' => (int) $r['term_id'] ] );
	}

	public static function ajax_rename() {
		$type = self::guard();
		$id   = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		if ( ! $id || '' === $name || ! term_exists( $id, self::tax( $type ) ) ) { wp_send_json_error( [], 400 ); }
		wp_update_term( $id, self::tax( $type ), [ 'name' => $name ] );
		self::done( $type );
	}

	/** Delete a folder: its items stay (without folder) and its subfolders move up one level. */
	public static function ajax_delete() {
		$type = self::guard();
		$tax  = self::tax( $type );
		$id   = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$term = $id ? get_term( $id, $tax ) : null;
		if ( ! $term || is_wp_error( $term ) ) { wp_send_json_error( [], 400 ); }
		foreach ( get_terms( [ 'taxonomy' => $tax, 'parent' => $id, 'hide_empty' => false, 'fields' => 'ids' ] ) as $child ) {
			wp_update_term( (int) $child, $tax, [ 'parent' => (int) $term->parent ] );
		}
		wp_delete_term( $id, $tax );
		self::done( $type );
	}

	/** Move a folder inside another one (never inside itself or its own subfolders). */
	public static function ajax_move() {
		$type   = self::guard();
		$tax    = self::tax( $type );
		$id     = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$parent = isset( $_POST['parent'] ) ? absint( $_POST['parent'] ) : 0;
		if ( ! $id || ! term_exists( $id, $tax ) || ( $parent && ! term_exists( $parent, $tax ) ) ) { wp_send_json_error( [], 400 ); }
		if ( $parent === $id || in_array( $id, get_ancestors( $parent, $tax, 'taxonomy' ), true ) ) { wp_send_json_error( [], 400 ); }
		wp_update_term( $id, $tax, [ 'parent' => $parent ] );
		self::done( $type );
	}

	public static function ajax_auto() {
		$type = self::guard();
		self::done( $type, [ 'moved' => self::organize( $type, ! empty( $_POST['all'] ) ) ] );
	}

	public static function ajax_assign() {
		$type   = self::guard();
		$folder = isset( $_POST['folder'] ) ? (int) $_POST['folder'] : 0;
		$ids    = isset( $_POST['ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['ids'] ) ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		self::done( $type, [ 'moved' => self::assign( $type, max( 0, $folder ), $ids ) ] );
	}

	/* ---------------------------------------------------------------- MediaFlow Pro import */

	private static function mfp_available() {
		global $wpdb;
		$t = $wpdb->prefix . 'mfp_folders';
		return current_user_can( 'manage_options' ) && $t === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $t ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/** Copy MediaFlow Pro folders (and what is in them) into Wakoo Carpetas. Its tables are left as they are. */
	public static function ajax_import_mfp() {
		$type = self::guard();
		if ( ! self::mfp_available() ) { wp_send_json_error( [], 403 ); }
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT id, parent, name, post_type FROM {$wpdb->prefix}mfp_folders WHERE is_smart = 0 ORDER BY parent ASC, sort_order ASC, id ASC" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$map = []; $folders = 0; $items = 0;
		// Parents first: repeat while something new could be placed.
		for ( $pass = 0; $pass < 10 && count( $map ) < count( $rows ); $pass++ ) {
			foreach ( $rows as $r ) {
				if ( isset( $map[ $r->id ] ) || ! in_array( $r->post_type, self::types(), true ) ) { continue; }
				if ( $r->parent && ! isset( $map[ $r->parent ] ) ) { continue; }
				$tax  = self::tax( $r->post_type );
				$res  = wp_insert_term( sanitize_text_field( $r->name ), $tax, [ 'parent' => $r->parent ? $map[ $r->parent ] : 0, 'slug' => 'mfp-' . (int) $r->id ] );
				$term = is_wp_error( $res ) ? get_term_by( 'slug', 'mfp-' . (int) $r->id, $tax ) : null;
				$map[ $r->id ] = is_wp_error( $res ) ? ( $term ? (int) $term->term_id : 0 ) : (int) $res['term_id'];
				if ( ! is_wp_error( $res ) ) { $folders++; }
			}
		}
		$by_type = [];
		foreach ( $rows as $r ) { $by_type[ $r->id ] = $r->post_type; }
		$rels = $wpdb->get_results( "SELECT folder_id, post_id FROM {$wpdb->prefix}mfp_relationships" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		foreach ( $rels as $rel ) {
			$term = $map[ $rel->folder_id ] ?? 0;
			$t    = $by_type[ $rel->folder_id ] ?? '';
			if ( $term && $t && get_post_type( (int) $rel->post_id ) === $t ) {
				wp_set_object_terms( (int) $rel->post_id, [ $term ], self::tax( $t ) );
				$items++;
			}
		}
		self::done( $type, [ 'folders' => $folders, 'items' => $items ] );
	}
}

Module::init();
