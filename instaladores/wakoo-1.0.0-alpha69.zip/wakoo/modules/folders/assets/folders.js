/* Wakoo Carpetas: folder panel next to the lists of wp-admin (Medios, Páginas, Entradas, Plantillas…). */
( function ( $ ) {
	'use strict';
	var C = window.WakooFolders;
	if ( ! C ) { return; }
	var t = C.t, tree = C.tree, current = C.current, open = {}, dragIds = [], dragFolder = 0;
	var KEY = 'wakooFolders:' + C.type;
	try { open = JSON.parse( localStorage.getItem( KEY + ':open' ) || '{}' ); } catch ( e ) {}

	function fmt( s, a, b ) { return String( s ).replace( '%s', a ).replace( '%1$d', a ).replace( '%2$d', b ); }

	function post( action, data ) {
		return $.post( C.ajax, $.extend( { action: 'wakoo_folders_' + action, nonce: C.nonce, type: C.type }, data || {} ) ).then( function ( r ) {
			if ( ! r || ! r.success ) { return $.Deferred().reject( r ); }
			tree = r.data.tree;
			render();
			return r.data;
		} ).fail( function () { toast( t.error, true ); } );
	}

	function toast( msg, bad ) {
		var n = $( '<div class="wkf-toast" role="status"></div>' ).toggleClass( 'is-bad', !! bad ).text( msg ).appendTo( 'body' );
		setTimeout( function () { n.addClass( 'is-out' ); setTimeout( function () { n.remove(); }, 400 ); }, 2600 );
	}

	function children( id ) {
		return tree.folders.filter( function ( f ) { return f.parent === id; } ).sort( function ( a, b ) { return a.name.localeCompare( b.name ); } );
	}

	function find( id ) {
		return tree.folders.filter( function ( f ) { return f.id === id; } )[ 0 ];
	}

	/* ---------------------------------------------------------------- panel */

	var $side = $( '<aside id="wakoo-folders" class="wkf" aria-label="' + t.title + '"></aside>' );
	$side.html(
		'<div class="wkf__head"><h2 class="wkf__title">' + t.title + '</h2>' +
		'<button type="button" class="wkf__icon wkf__new" title="' + t.new + '" aria-label="' + t.new + '">+</button>' +
		'<button type="button" class="wkf__icon wkf__hide" title="' + t.hide + '" aria-label="' + t.hide + '">«</button></div>' +
		'<input type="search" class="wkf__search" placeholder="' + t.search + '" aria-label="' + t.search + '">' +
		'<ul class="wkf__fixed"></ul><ul class="wkf__tree" role="tree" aria-label="' + t.title + '"></ul>' +
		'<p class="wkf__hint">' + t.drag + '</p>' +
		( C.auto ? '<button type="button" class="button wkf__auto"><span class="dashicons dashicons-admin-generic" aria-hidden="true"></span> ' + t.auto + '</button>' : '' ) +
		( C.mfp ? '<button type="button" class="button wkf__mfp">' + t.mfp + '</button>' : '' )
	);
	var $show = $( '<button type="button" class="button wkf__show"><span class="dashicons dashicons-category" aria-hidden="true"></span> ' + t.show + '</button>' );

	function row( f, depth ) {
		var kids = children( f.id ), isOpen = !! open[ f.id ], active = f.id === current;
		var $li = $( '<li role="treeitem"></li>' ).attr( 'aria-level', depth + 1 ).attr( 'data-id', f.id );
		if ( kids.length ) { $li.attr( 'aria-expanded', isOpen ? 'true' : 'false' ); }
		var $r = $( '<div class="wkf__row" draggable="true"></div>' ).toggleClass( 'is-active', active ).css( 'padding-left', 8 + depth * 14 );
		$r.append( kids.length ? $( '<button type="button" class="wkf__caret"></button>' ).attr( 'aria-label', t.expand ).text( isOpen ? '▾' : '▸' ) : '<span class="wkf__caret-sp"></span>' );
		$r.append( $( '<button type="button" class="wkf__name"></button>' ).attr( 'aria-current', active ? 'true' : null ).append( '<span class="wkf__ico dashicons dashicons-category" aria-hidden="true"></span>', $( '<span class="wkf__label"></span>' ).text( f.name ) ) );
		$r.append( $( '<span class="wkf__count"></span>' ).text( f.count ) );
		$r.append( $( '<button type="button" class="wkf__more">⋯</button>' ).attr( 'aria-label', t.actions + ': ' + f.name ) );
		$li.append( $r );
		if ( kids.length && isOpen ) {
			var $ul = $( '<ul role="group"></ul>' );
			kids.forEach( function ( k ) { $ul.append( row( k, depth + 1 ) ); } );
			$li.append( $ul );
		}
		return $li;
	}

	function render() {
		var q = $side.find( '.wkf__search' ).val().toLowerCase().trim();
		var $fixed = $side.find( '.wkf__fixed' ).empty();
		[ [ 0, t.all, tree.all, 'dashicons-portfolio' ], [ -1, t.none, tree.none, 'dashicons-media-default' ] ].forEach( function ( x ) {
			$fixed.append( $( '<li></li>' ).attr( 'data-id', x[ 0 ] ).append(
				$( '<div class="wkf__row"></div>' ).toggleClass( 'is-active', current === x[ 0 ] ).append(
					'<span class="wkf__caret-sp"></span>',
					$( '<button type="button" class="wkf__name"></button>' ).attr( 'aria-current', current === x[ 0 ] ? 'true' : null ).append( $( '<span class="wkf__ico dashicons" aria-hidden="true"></span>' ).addClass( x[ 3 ] ), $( '<span class="wkf__label"></span>' ).text( x[ 1 ] ) ),
					$( '<span class="wkf__count"></span>' ).text( x[ 2 ] ) ) ) );
		} );
		var $tree = $side.find( '.wkf__tree' ).empty();
		if ( q ) { // Search: a flat list of matching folders with their path.
			tree.folders.filter( function ( f ) { return f.name.toLowerCase().indexOf( q ) > -1; } ).forEach( function ( f ) {
				var path = [], p = find( f.parent );
				while ( p ) { path.unshift( p.name ); p = find( p.parent ); }
				var $li = row( $.extend( {}, f ), 0 );
				$li.find( 'ul' ).remove();
				$li.find( '.wkf__caret' ).replaceWith( '<span class="wkf__caret-sp"></span>' );
				if ( path.length ) { $li.find( '.wkf__name' ).append( $( '<small class="wkf__path"></small>' ).text( path.join( ' › ' ) ) ); }
				$tree.append( $li );
			} );
		} else {
			children( 0 ).forEach( function ( f ) { $tree.append( row( f, 0 ) ); } );
			if ( ! tree.folders.length ) { $tree.append( $( '<li class="wkf__empty"></li>' ).text( t.empty ) ); }
		}
		// If the open folder is inside a closed one, open its parents.
		var cf = find( current );
		while ( cf && cf.parent ) { if ( ! open[ cf.parent ] ) { open[ cf.parent ] = 1; return render(); } cf = find( cf.parent ); }
	}

	/* ---------------------------------------------------------------- navigation */

	function go( id ) {
		current = id;
		if ( C.grid && window.wp && wp.media && wp.media.frame ) {
			var lib = wp.media.frame.state().get( 'library' );
			if ( lib ) {
				lib.props.set( { wkf: id || '', ignore: Date.now() } );
				setUploadFolder();
				render();
				saveUrl();
				return;
			}
		}
		var u = new URL( window.location.href );
		if ( id ) { u.searchParams.set( 'wkf', id ); } else { u.searchParams.delete( 'wkf' ); }
		u.searchParams.delete( 'paged' );
		window.location.href = u.toString();
	}

	function saveUrl() {
		try {
			var u = new URL( window.location.href );
			if ( current ) { u.searchParams.set( 'wkf', current ); } else { u.searchParams.delete( 'wkf' ); }
			window.history.replaceState( null, '', u );
		} catch ( e ) {}
	}

	/** Files uploaded in the media grid go to the open folder. */
	function setUploadFolder() {
		if ( window.wp && wp.Uploader && wp.Uploader.defaults ) {
			wp.Uploader.defaults.multipart_params = wp.Uploader.defaults.multipart_params || {};
			wp.Uploader.defaults.multipart_params.wkf = current > 0 ? current : 0;
		}
		// The grid's uploader already exists: update it too.
		var up = window.wp && wp.media && wp.media.frame && wp.media.frame.uploader && wp.media.frame.uploader.uploader && wp.media.frame.uploader.uploader.uploader;
		if ( up && up.setOption ) { up.setOption( 'multipart_params', $.extend( {}, up.getOption( 'multipart_params' ) || {}, { wkf: current > 0 ? current : 0 } ) ); }
		$( 'input[name="wkf"]' ).remove();
		if ( current > 0 ) { $( '#plupload-upload-ui, form#file-form' ).first().append( $( '<input type="hidden" name="wkf">' ).val( current ) ); }
	}

	/* ---------------------------------------------------------------- folder actions */

	function ask( label, value ) {
		var v = window.prompt( label, value || '' );
		return v === null ? null : v.trim();
	}

	function menu( $btn, id ) {
		$( '.wkf__menu' ).remove();
		var f = find( id );
		var $m = $( '<div class="wkf__menu" role="menu"></div>' );
		[ [ 'sub', t.newSub ], [ 'rename', t.rename ], f.parent ? [ 'root', t.toRoot ] : null, [ 'delete', t.delete ] ].forEach( function ( a ) {
			if ( a ) { $m.append( $( '<button type="button" role="menuitem"></button>' ).attr( 'data-a', a[ 0 ] ).text( a[ 1 ] ).toggleClass( 'is-danger', 'delete' === a[ 0 ] ) ); }
		} );
		$m.on( 'click', 'button', function () {
			var a = $( this ).data( 'a' );
			$m.remove();
			if ( 'sub' === a ) { var n = ask( t.name ); if ( n ) { open[ id ] = 1; post( 'create', { name: n, parent: id } ); } }
			if ( 'rename' === a ) { var r = ask( t.name, f.name ); if ( r && r !== f.name ) { post( 'rename', { id: id, name: r } ); } }
			if ( 'root' === a ) { post( 'move', { id: id, parent: 0 } ); }
			if ( 'delete' === a && window.confirm( fmt( t.confirm, f.name ) ) ) {
				post( 'delete', { id: id } ).then( function () { if ( current === id ) { go( 0 ); } } );
			}
		} );
		$m.on( 'keydown', function ( e ) { if ( 'Escape' === e.key ) { $m.remove(); $btn.trigger( 'focus' ); } } );
		$btn.after( $m );
		$m.find( 'button' ).first().trigger( 'focus' );
	}

	$side.on( 'click', '.wkf__new', function () { var n = ask( t.name ); if ( n ) { post( 'create', { name: n, parent: current > 0 ? current : 0 } ).then( function () { if ( current > 0 ) { open[ current ] = 1; render(); } } ); } } );
	$side.on( 'click', '.wkf__name', function () { go( +$( this ).closest( 'li' ).data( 'id' ) ); } );
	$side.on( 'click', '.wkf__caret', function () {
		var id = +$( this ).closest( 'li' ).data( 'id' );
		open[ id ] = ! open[ id ];
		try { localStorage.setItem( KEY + ':open', JSON.stringify( open ) ); } catch ( e ) {}
		render();
		$side.find( 'li[data-id="' + id + '"] > .wkf__row .wkf__caret' ).trigger( 'focus' );
	} );
	$side.on( 'click', '.wkf__more', function ( e ) { e.stopPropagation(); menu( $( this ), +$( this ).closest( 'li' ).data( 'id' ) ); } );
	$side.on( 'input', '.wkf__search', render );
	$side.on( 'click', '.wkf__auto', function () {
		if ( ! window.confirm( t.autoAsk ) ) { return; }
		var $b = $( this ).prop( 'disabled', true );
		post( 'auto' ).then( function ( d ) {
			toast( fmt( t.autoDone, d.moved ) );
			if ( C.grid && wp.media && wp.media.frame ) { wp.media.frame.state().get( 'library' ).props.set( { ignore: Date.now() } ); } else { setTimeout( function () { window.location.reload(); }, 900 ); }
		} ).always( function () { $b.prop( 'disabled', false ); } );
	} );
	$side.on( 'click', '.wkf__mfp', function () {
		var $b = $( this ).prop( 'disabled', true );
		post( 'import_mfp' ).then( function ( d ) { toast( fmt( t.mfpDone, d.folders, d.items ) ); $b.remove(); if ( ! C.grid ) { setTimeout( function () { window.location.reload(); }, 900 ); } } ).always( function () { $b.prop( 'disabled', false ); } );
	} );
	$( document ).on( 'click', function ( e ) { if ( ! $( e.target ).closest( '.wkf__menu, .wkf__more' ).length ) { $( '.wkf__menu' ).remove(); } } );
	// Arrow keys move between folders (tree pattern, simplified).
	$side.on( 'keydown', '.wkf__name', function ( e ) {
		var $all = $side.find( '.wkf__name:visible' ), i = $all.index( this );
		if ( 'ArrowDown' === e.key ) { e.preventDefault(); $all.eq( Math.min( i + 1, $all.length - 1 ) ).trigger( 'focus' ); }
		if ( 'ArrowUp' === e.key ) { e.preventDefault(); $all.eq( Math.max( i - 1, 0 ) ).trigger( 'focus' ); }
		if ( 'ArrowRight' === e.key || 'ArrowLeft' === e.key ) {
			var id = +$( this ).closest( 'li' ).data( 'id' );
			if ( id > 0 && children( id ).length && ( 'ArrowRight' === e.key ) !== !! open[ id ] ) { open[ id ] = 'ArrowRight' === e.key; render(); $side.find( 'li[data-id="' + id + '"] > .wkf__row .wkf__name' ).trigger( 'focus' ); }
		}
	} );
	$side.on( 'click', '.wkf__hide', function () { $( 'body' ).addClass( 'wkf-collapsed' ); try { localStorage.setItem( KEY + ':hidden', '1' ); } catch ( e ) {} $show.trigger( 'focus' ); } );
	$show.on( 'click', function () { $( 'body' ).removeClass( 'wkf-collapsed' ); try { localStorage.removeItem( KEY + ':hidden' ); } catch ( e ) {} $side.find( '.wkf__name' ).first().trigger( 'focus' ); } );

	/* ---------------------------------------------------------------- drag & drop */

	function selectedIds( fallback ) {
		var ids = [];
		if ( C.grid && window.wp && wp.media && wp.media.frame ) {
			var sel = wp.media.frame.state().get( 'selection' );
			if ( sel && sel.length ) { ids = sel.pluck( 'id' ); }
		} else {
			$( '#the-list input[type="checkbox"]:checked' ).each( function () { ids.push( +this.value ); } );
		}
		if ( fallback && ids.indexOf( fallback ) < 0 ) { ids = [ fallback ]; }
		return ids;
	}

	// Rows of the lists and tiles of the media grid can be dragged onto a folder.
	$( document ).on( 'dragstart', '#the-list tr, .attachments-browser .attachment', function ( e ) {
		var id = +( $( this ).data( 'id' ) || String( this.id ).replace( /\D+/g, '' ) );
		dragIds = selectedIds( id );
		dragFolder = 0;
		$( 'body' ).addClass( 'wkf-dragging' );
		var dt = e.originalEvent.dataTransfer;
		dt.effectAllowed = 'move';
		dt.setData( 'text/plain', String( dragIds.length ) );
	} );
	$side.on( 'dragstart', '.wkf__tree .wkf__row', function ( e ) {
		dragFolder = +$( this ).closest( 'li' ).data( 'id' );
		dragIds = [];
		$( 'body' ).addClass( 'wkf-dragging' );
		e.originalEvent.dataTransfer.setData( 'text/plain', 'folder' );
		e.stopPropagation();
	} );
	$( document ).on( 'dragend drop', function ( e ) {
		// A row dropped outside the folders must not make the browser open the link it carries.
		if ( 'drop' === e.type && $( 'body' ).hasClass( 'wkf-dragging' ) ) { e.preventDefault(); }
		$( 'body' ).removeClass( 'wkf-dragging' );
		$side.find( '.is-over' ).removeClass( 'is-over' );
	} );
	$( document ).on( 'dragover', function ( e ) { if ( $( 'body' ).hasClass( 'wkf-dragging' ) ) { e.preventDefault(); } } );
	$side.on( 'dragover', '.wkf__row', function ( e ) { e.preventDefault(); $side.find( '.is-over' ).removeClass( 'is-over' ); $( this ).addClass( 'is-over' ); } );
	$side.on( 'dragleave', '.wkf__row', function () { $( this ).removeClass( 'is-over' ); } );
	$side.on( 'drop', '.wkf__row', function ( e ) {
		e.preventDefault();
		var to = +$( this ).closest( 'li' ).data( 'id' );
		if ( dragFolder ) { // A folder onto another folder (or onto "Todos" = top level).
			if ( to !== dragFolder && to >= 0 ) { open[ to ] = 1; post( 'move', { id: dragFolder, parent: to } ); }
			dragFolder = 0;
			return;
		}
		if ( ! dragIds.length ) { return; }
		var name = to > 0 ? ( find( to ) || {} ).name : t.none;
		post( 'assign', { folder: Math.max( 0, to ), ids: dragIds } ).then( function () {
			toast( fmt( t.moved, name ) );
			if ( C.grid && wp.media.frame ) { wp.media.frame.state().get( 'library' ).props.set( { ignore: Date.now() } ); } else if ( current ) { window.location.reload(); }
		} );
		dragIds = [];
	} );

	/* ---------------------------------------------------------------- start */

	$( function () {
		var $wrap = $( '#wpbody-content > .wrap' ).first();
		if ( ! $wrap.length ) { return; }
		$( 'body' ).addClass( 'wkf-on' );
		try { if ( localStorage.getItem( KEY + ':hidden' ) ) { $( 'body' ).addClass( 'wkf-collapsed' ); } } catch ( e ) {}
		$wrap.before( $side );
		$wrap.find( '.wp-header-end, h1' ).first().after( $show );
		$( '#the-list tr' ).attr( 'draggable', 'true' );
		render();
		setUploadFolder();
		if ( C.grid && window.wp && wp.media ) {
			// The grid loads after the page: apply the open folder and keep tiles draggable.
			var tries = 0, wait = setInterval( function () {
				if ( wp.media.frame && wp.media.frame.state && wp.media.frame.state().get( 'library' ) ) {
					clearInterval( wait );
					if ( current ) { wp.media.frame.state().get( 'library' ).props.set( { wkf: current } ); }
				} else if ( ++tries > 40 ) { clearInterval( wait ); }
			}, 150 );
			new MutationObserver( function () { $( '.attachments-browser .attachment:not([draggable])' ).attr( 'draggable', 'true' ); } ).observe( document.body, { childList: true, subtree: true } );
		}
	} );
}( jQuery ) );
