/* Wakoo Carpetas: "filter by folder" in the media window (Elementor, block editor, featured image…). */
( function () {
	'use strict';
	var D = window.WakooFoldersMedia;
	if ( ! D || ! window.wp || ! wp.media || ! wp.media.view || ! wp.media.view.AttachmentsBrowser ) { return; }

	var Filter = wp.media.view.AttachmentFilters.extend( {
		id: 'wakoo-folder-filter',
		className: 'attachment-filters wakoo-folder-filter',
		createFilters: function () {
			var f = {
				all: { text: D.t.all, props: { wkf: '' }, priority: 10 },
				none: { text: D.t.none, props: { wkf: -1 }, priority: 20 }
			};
			D.folders.forEach( function ( x, i ) {
				f[ 'f' + x.id ] = { text: x.name + ' (' + x.count + ')', props: { wkf: x.id }, priority: 30 + i };
			} );
			this.filters = f;
		}
	} );

	var Browser = wp.media.view.AttachmentsBrowser;
	wp.media.view.AttachmentsBrowser = Browser.extend( {
		createToolbar: function () {
			Browser.prototype.createToolbar.apply( this, arguments );
			if ( ! D.folders.length || ! this.toolbar ) { return; }
			this.toolbar.set( 'wakooFolderLabel', new wp.media.view.Label( { value: D.t.label, attributes: { 'for': 'wakoo-folder-filter' }, priority: -76 } ).render() );
			this.toolbar.set( 'wakooFolderFilter', new Filter( { controller: this.controller, model: this.collection.props, priority: -75 } ).render() );
		}
	} );
}() );
