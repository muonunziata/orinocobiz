( function () {
	'use strict';

	function build( el ) {
		if ( el.dataset.wakooLottieInit ) { return; }
		el.dataset.wakooLottieInit = '1';
		if ( ! window.lottie ) { return; }

		var cfg;
		try { cfg = JSON.parse( el.getAttribute( 'data-wakoo-lottie' ) || '{}' ); } catch ( e ) { return; }
		if ( ! cfg.path ) { return; }

		var trigger = cfg.trigger || 'load';
		var autoplay = ( 'load' === trigger );

		var anim = window.lottie.loadAnimation( {
			container: el,
			renderer: 'svg',
			loop: !! cfg.loop,
			autoplay: autoplay,
			path: cfg.path,
		} );

		anim.addEventListener( 'DOMLoaded', function () {
			if ( cfg.speed ) { anim.setSpeed( cfg.speed ); }
			if ( cfg.reverse ) { anim.setDirection( -1 ); }
		} );

		if ( 'hover' === trigger ) {
			el.addEventListener( 'mouseenter', function () { anim.goToAndPlay( 0, true ); } );
		} else if ( 'click' === trigger ) {
			el.addEventListener( 'click', function () { anim.goToAndPlay( 0, true ); } );
		} else if ( 'scroll' === trigger ) {
			if ( window.IntersectionObserver ) {
				var once = false;
				var io = new IntersectionObserver( function ( entries ) {
					entries.forEach( function ( en ) {
						if ( en.isIntersecting && ! once ) { once = true; anim.play(); }
					} );
				}, { threshold: 0.25 } );
				io.observe( el );
			} else {
				anim.play();
			}
		}
	}

	function boot( scope ) {
		( scope || document ).querySelectorAll( '.wakoo-lottie' ).forEach( build );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', function () { boot(); } );
	} else {
		boot();
	}
	if ( window.jQuery ) {
		jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend && elementorFrontend.hooks ) {
				elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-lottie.default', function ( $s ) { boot( $s[ 0 ] ); } );
			}
		} );
	}
}() );
