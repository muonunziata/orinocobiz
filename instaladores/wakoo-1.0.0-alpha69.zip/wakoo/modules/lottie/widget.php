<?php
/**
 * Wakoo Lottie widget.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Lottie;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Widget extends Widget_Base {

	public function get_name() { return 'wakoo-lottie'; }
	public function get_title() { return __( 'Animación Lottie (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-lottie'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'lottie', 'animacion', 'json', 'bodymovin', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-lottie' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec', [ 'label' => __( 'Animación', 'wakoo' ) ] );

		$this->add_control( 'source', [
			'label'   => __( 'Origen', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'url',
			'options' => [ 'file' => __( 'Subir JSON', 'wakoo' ), 'url' => __( 'Enlace (URL)', 'wakoo' ) ],
		] );
		$this->add_control( 'json_file', [
			'label'       => __( 'Archivo JSON', 'wakoo' ),
			'type'        => Controls_Manager::MEDIA,
			'media_types' => [ 'application/json' ],
			'condition'   => [ 'source' => 'file' ],
		] );
		$this->add_control( 'json_url', [
			'label'       => __( 'URL del JSON', 'wakoo' ),
			'type'        => Controls_Manager::TEXT,
			'placeholder' => 'https://.../animation.json',
			'label_block' => true,
			'condition'   => [ 'source' => 'url' ],
		] );

		$this->add_control( 'trigger', [
			'label'   => __( 'Reproducir', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'load',
			'options' => [
				'load'   => __( 'Al cargar', 'wakoo' ),
				'scroll' => __( 'Al entrar en pantalla', 'wakoo' ),
				'hover'  => __( 'Al pasar el ratón', 'wakoo' ),
				'click'  => __( 'Al hacer clic', 'wakoo' ),
			],
		] );
		$this->add_control( 'loop', [
			'label'        => __( 'Repetir en bucle', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => 'yes',
		] );
		$this->add_control( 'reverse', [
			'label'        => __( 'Invertir', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => '',
		] );
		$this->add_control( 'speed', [
			'label'   => __( 'Velocidad', 'wakoo' ),
			'type'    => Controls_Manager::SLIDER,
			'range'   => [ 'px' => [ 'min' => 0.1, 'max' => 3, 'step' => 0.1 ] ],
			'default' => [ 'size' => 1 ],
		] );
		$this->add_responsive_control( 'width', [
			'label'      => __( 'Ancho', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px', '%', 'vw' ],
			'range'      => [ 'px' => [ 'min' => 20, 'max' => 1200 ], '%' => [ 'min' => 5, 'max' => 100 ] ],
			'default'    => [ 'size' => 300, 'unit' => 'px' ],
			'selectors'  => [ '{{WRAPPER}} .wakoo-lottie' => 'width: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'align', [
			'label'     => __( 'Alineación', 'wakoo' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => [
				'flex-start' => [ 'title' => __( 'Izquierda', 'wakoo' ), 'icon' => 'eicon-text-align-left' ],
				'center'     => [ 'title' => __( 'Centro', 'wakoo' ), 'icon' => 'eicon-text-align-center' ],
				'flex-end'   => [ 'title' => __( 'Derecha', 'wakoo' ), 'icon' => 'eicon-text-align-right' ],
			],
			'default'   => 'center',
			'selectors' => [ '{{WRAPPER}} .wakoo-lottie-wrap' => 'display:flex; justify-content: {{VALUE}};' ],
		] );

		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$src = ( 'url' === ( $s['source'] ?? 'url' ) )
			? trim( $s['json_url'] ?? '' )
			: ( $s['json_file']['url'] ?? '' );
		if ( ! $src ) {
			echo '<div class="wakoo-lottie-wrap"><em>' . esc_html__( 'Añade un archivo o URL de animación Lottie.', 'wakoo' ) . '</em></div>';
			return;
		}
		$cfg = [
			'path'    => esc_url( $src ),
			'trigger' => $s['trigger'] ?? 'load',
			'loop'    => ( 'yes' === ( $s['loop'] ?? 'yes' ) ),
			'reverse' => ( 'yes' === ( $s['reverse'] ?? '' ) ),
			'speed'   => (float) ( $s['speed']['size'] ?? 1 ),
		];
		printf(
			'<div class="wakoo-lottie-wrap"><div class="wakoo-lottie" data-wakoo-lottie="%s"></div></div>',
			esc_attr( wp_json_encode( $cfg ) )
		);
	}
}
