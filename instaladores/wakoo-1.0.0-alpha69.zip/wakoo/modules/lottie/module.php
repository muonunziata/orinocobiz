<?php
/**
 * Wakoo: Lottie animation widget.
 *
 * Plays Lottie/Bodymovin JSON animations (upload a .json or paste a URL) with
 * loop, autoplay, speed, reverse and "play on" (load / hover / scroll into
 * view / click) options. Powered by lottie-web (lottie_light build, MIT,
 * bundled in vendor/ with CREDITS.txt). No GSAP.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Lottie;

defined( 'ABSPATH' ) || die();

class Module {

	public static function init() {
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'assets' ] );
	}

	public static function register_widget( $wm ) {
		require_once __DIR__ . '/widget.php';
		$wm->register( new Widget() );
	}

	public static function assets() {
		wp_register_script( 'wakoo-lottie-lib', WAKOO_MODULES_URL . 'lottie/vendor/lottie_light.min.js', [], '5.12.2', true );
		wp_register_script( 'wakoo-lottie', WAKOO_MODULES_URL . 'lottie/assets/lottie.js', [ 'wakoo-lottie-lib' ], WAKOO_VERSION, true );
	}
}

Module::init();
