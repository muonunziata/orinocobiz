<?php
/**
 * "Mi cuenta de miembro (Wakoo)": log in, then edit the micro-profile
 * (texts, logo, gallery, address) from the front end.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Members;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Account_Widget extends Base {

	public function get_name() { return 'wakoo-member-account'; }
	public function get_title() { return __( 'Mi cuenta de miembro (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-lock-user'; }
	public function get_keywords() { return [ 'miembro', 'member', 'cuenta', 'login', 'perfil', 'wakoo' ]; }

	protected function texts() {
		return [
			'login_title' => [ __( 'Título: iniciar sesión', 'wakoo' ), __( 'Entra en tu cuenta de miembro', 'wakoo' ) ],
			'user'        => [ __( 'Campo: usuario', 'wakoo' ), __( 'Usuario o email', 'wakoo' ) ],
			'pass'        => [ __( 'Campo: contraseña', 'wakoo' ), __( 'Contraseña', 'wakoo' ) ],
			'remember'    => [ __( 'Recordarme', 'wakoo' ), __( 'Recordarme', 'wakoo' ) ],
			'login'       => [ __( 'Botón: entrar', 'wakoo' ), __( 'Entrar', 'wakoo' ) ],
			'lost'        => [ __( 'Enlace: contraseña olvidada', 'wakoo' ), __( '¿Olvidaste tu contraseña?', 'wakoo' ) ],
			'not_member'  => [ __( 'Texto: aún no es miembro', 'wakoo' ), __( '¿Aún no eres miembro?', 'wakoo' ) ],
			'apply'       => [ __( 'Enlace: solicitar', 'wakoo' ), __( 'Solicita tu membresía', 'wakoo' ) ],
			'no_profile'  => [ __( 'Mensaje: sin perfil', 'wakoo' ), __( 'Tu cuenta no tiene un perfil de miembro.', 'wakoo' ) ],
			'pending'     => [ __( 'Mensaje: en revisión', 'wakoo' ), __( 'Tu solicitud está en revisión. Te avisaremos por email.', 'wakoo' ) ],
			'suspended'   => [ __( 'Mensaje: suspendido', 'wakoo' ), __( 'Tu perfil no está visible ahora mismo. Escríbenos si tienes dudas.', 'wakoo' ) ],
			'hello'       => [ __( 'Saludo', 'wakoo' ), __( 'Hola, %s', 'wakoo' ) ],
			'view'        => [ __( 'Enlace: ver perfil', 'wakoo' ), __( 'Ver mi perfil público', 'wakoo' ) ],
			'logout'      => [ __( 'Enlace: salir', 'wakoo' ), __( 'Cerrar sesión', 'wakoo' ) ],
			's_profile'   => [ __( 'Bloque: perfil', 'wakoo' ), __( 'Tu perfil', 'wakoo' ) ],
			's_contact'   => [ __( 'Bloque: contacto', 'wakoo' ), __( 'Contacto y ubicación', 'wakoo' ) ],
			's_images'    => [ __( 'Bloque: imágenes', 'wakoo' ), __( 'Logo y galería', 'wakoo' ) ],
			'name'        => [ __( 'Campo: nombre', 'wakoo' ), __( 'Nombre del negocio', 'wakoo' ) ],
			'tagline'     => [ __( 'Campo: lema', 'wakoo' ), __( 'Lema (una línea)', 'wakoo' ) ],
			'category'    => [ __( 'Campo: categoría', 'wakoo' ), __( 'Categoría', 'wakoo' ) ],
			'description' => [ __( 'Campo: descripción', 'wakoo' ), __( 'Descripción', 'wakoo' ) ],
			'contact'     => [ __( 'Campo: contacto', 'wakoo' ), __( 'Persona de contacto', 'wakoo' ) ],
			'email'       => [ __( 'Campo: email público', 'wakoo' ), __( 'Email público', 'wakoo' ) ],
			'phone'       => [ __( 'Campo: teléfono', 'wakoo' ), __( 'Teléfono', 'wakoo' ) ],
			'website'     => [ __( 'Campo: web', 'wakoo' ), __( 'Web', 'wakoo' ) ],
			'address'     => [ __( 'Campo: dirección', 'wakoo' ), __( 'Dirección (se muestra en Google Maps)', 'wakoo' ) ],
			'facebook'    => [ __( 'Campo: Facebook', 'wakoo' ), __( 'Facebook (URL)', 'wakoo' ) ],
			'instagram'   => [ __( 'Campo: Instagram', 'wakoo' ), __( 'Instagram (URL)', 'wakoo' ) ],
			'logo'        => [ __( 'Campo: logo', 'wakoo' ), __( 'Cambiar logo', 'wakoo' ) ],
			'gallery'     => [ __( 'Campo: añadir fotos', 'wakoo' ), __( 'Añadir fotos a la galería (máx. 5 MB cada una)', 'wakoo' ) ],
			'remove'      => [ __( 'Casilla: quitar foto', 'wakoo' ), __( 'Quitar', 'wakoo' ) ],
			'save'        => [ __( 'Botón: guardar', 'wakoo' ), __( 'Guardar cambios', 'wakoo' ) ],
			'saved'       => [ __( 'Mensaje: guardado', 'wakoo' ), __( 'Cambios guardados.', 'wakoo' ) ],
			'saved_err'   => [ __( 'Mensaje: guardado con errores', 'wakoo' ), __( 'Cambios guardados, pero alguna imagen no se pudo subir (solo JPG, PNG, WebP o GIF de hasta 5 MB).', 'wakoo' ) ],
			'expired'     => [ __( 'Mensaje: sesión caducada', 'wakoo' ), __( 'La sesión caducó. Vuelve a intentarlo.', 'wakoo' ) ],
			'chat_title'  => [ __( 'Chat: título', 'wakoo' ), __( 'Mensajes con el equipo', 'wakoo' ) ],
			'chat_new'    => [ __( 'Chat: aviso de nuevos (usa %d)', 'wakoo' ), __( '%d mensajes nuevos', 'wakoo' ) ],
			'chat_team'   => [ __( 'Chat: nombre del equipo', 'wakoo' ), get_bloginfo( 'name' ) ],
			'chat_you'    => [ __( 'Chat: tú', 'wakoo' ), __( 'Tú', 'wakoo' ) ],
			'chat_empty'  => [ __( 'Chat: sin mensajes', 'wakoo' ), __( '¿Dudas, cambios o una promoción? Escríbenos aquí y te responderemos.', 'wakoo' ) ],
			'chat_ph'     => [ __( 'Chat: marcador', 'wakoo' ), __( 'Escribe tu mensaje…', 'wakoo' ) ],
			'chat_send'   => [ __( 'Chat: enviar', 'wakoo' ), __( 'Enviar', 'wakoo' ) ],
			'chat_attach' => [ __( 'Chat: adjuntar', 'wakoo' ), __( 'Adjuntar imagen o PDF', 'wakoo' ) ],
			'chat_error'  => [ __( 'Chat: error', 'wakoo' ), __( 'No se pudo enviar. Inténtalo de nuevo.', 'wakoo' ) ],
			'chat_loading' => [ __( 'Chat: cargando', 'wakoo' ), __( 'Cargando mensajes…', 'wakoo' ) ],
			'm_title'     => [ __( 'Marketplace: título del bloque', 'wakoo' ), __( 'Mis anuncios del marketplace', 'wakoo' ) ],
			'm_add'       => [ __( 'Marketplace: añadir', 'wakoo' ), __( '+ Publicar un producto o servicio', 'wakoo' ) ],
			'm_name'      => [ __( 'Marketplace: nombre', 'wakoo' ), __( 'Producto o servicio', 'wakoo' ) ],
			'm_price'     => [ __( 'Marketplace: precio', 'wakoo' ), __( 'Precio (p. ej. $25 o «Consultar»)', 'wakoo' ) ],
			'm_text'      => [ __( 'Marketplace: descripción', 'wakoo' ), __( 'Descripción', 'wakoo' ) ],
			'm_image'     => [ __( 'Marketplace: foto', 'wakoo' ), __( 'Foto principal (JPG, PNG o WebP, máx. 5 MB)', 'wakoo' ) ],
			'm_gallery'   => [ __( 'Marketplace: más fotos', 'wakoo' ), __( 'Más fotos para la galería (hasta 5)', 'wakoo' ) ],
			'j_title'     => [ __( 'Empleo: título del bloque', 'wakoo' ), __( 'Mis ofertas de empleo', 'wakoo' ) ],
			'j_add'       => [ __( 'Empleo: añadir', 'wakoo' ), __( '+ Publicar una oferta de empleo', 'wakoo' ) ],
			'j_name'      => [ __( 'Empleo: puesto', 'wakoo' ), __( 'Puesto', 'wakoo' ) ],
			'j_type'      => [ __( 'Empleo: jornada', 'wakoo' ), __( 'Jornada', 'wakoo' ) ],
			'type_full'   => [ __( 'Jornada: completa', 'wakoo' ), __( 'Tiempo completo', 'wakoo' ) ],
			'type_part'   => [ __( 'Jornada: parcial', 'wakoo' ), __( 'Media jornada', 'wakoo' ) ],
			'type_contract' => [ __( 'Jornada: temporal', 'wakoo' ), __( 'Por obra o temporal', 'wakoo' ) ],
			'j_location'  => [ __( 'Empleo: lugar', 'wakoo' ), __( 'Lugar de trabajo', 'wakoo' ) ],
			'j_salary'    => [ __( 'Empleo: salario', 'wakoo' ), __( 'Salario (opcional)', 'wakoo' ) ],
			'j_text'      => [ __( 'Empleo: descripción', 'wakoo' ), __( 'Descripción, requisitos y cómo postular', 'wakoo' ) ],
			'j_email'     => [ __( 'Empleo: email', 'wakoo' ), __( 'Email para recibir candidaturas', 'wakoo' ) ],
			'j_url'       => [ __( 'Empleo: enlace', 'wakoo' ), __( 'O enlace para postular (opcional)', 'wakoo' ) ],
			'b_publish'   => [ __( 'Botón: publicar', 'wakoo' ), __( 'Publicar', 'wakoo' ) ],
			'b_delete'    => [ __( 'Botón: borrar', 'wakoo' ), __( 'Borrar', 'wakoo' ) ],
			'b_confirm'   => [ __( 'Confirmar borrado', 'wakoo' ), __( '¿Borrar este anuncio?', 'wakoo' ) ],
			'b_live'      => [ __( 'Estado: publicado (usa %s)', 'wakoo' ), __( 'Publicado hasta el %s', 'wakoo' ) ],
			'b_off'       => [ __( 'Estado: caducado', 'wakoo' ), __( 'Caducado: publícalo de nuevo si sigue vigente', 'wakoo' ) ],
			'b_none'      => [ __( 'Sin anuncios propios', 'wakoo' ), __( 'Todavía no has publicado nada.', 'wakoo' ) ],
			'b_saved'     => [ __( 'Mensaje: publicado', 'wakoo' ), __( 'Publicado. Ya aparece en la plaza comercial.', 'wakoo' ) ],
			'b_deleted'   => [ __( 'Mensaje: borrado', 'wakoo' ), __( 'Anuncio borrado.', 'wakoo' ) ],
			'b_invalid'   => [ __( 'Mensaje: faltan datos', 'wakoo' ), __( 'Pon al menos un título y una descripción.', 'wakoo' ) ],
			'b_limit'     => [ __( 'Mensaje: límite', 'wakoo' ), __( 'Has llegado al máximo de anuncios. Borra alguno para publicar otro.', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_account', [ 'label' => __( 'Cuenta', 'wakoo' ) ] );
		$this->add_control( 'apply_url', [ 'label' => __( 'Página de solicitud', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$this->add_control( 'categories', [ 'label' => __( 'Categorías (una por línea)', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'description' => __( 'Vacío = las categorías de Miembros Wakoo.', 'wakoo' ) ] );
		$this->end_controls_section();
		$this->texts_section();
		$this->style_section();
	}

	/** "Mis anuncios" / "Mis ofertas": what the member has published, delete buttons and a form to publish more. */
	private function board_section( $kind, $s ) {
		$job  = 'job' === $kind;
		$type = $job ? Board::JOB : Board::LISTING;
		$p    = $job ? 'j_' : 'm_';
		echo '<section class="wk-m-card wk-m-board" id="wakoo-board' . ( $job ? '-jobs' : '' ) . '"><h3>' . esc_html( $this->t( $p . 'title' ) ) . '</h3>';
		$mine = Board::mine( $type );
		if ( ! $mine ) {
			echo '<p class="wk-m-note">' . esc_html( $this->t( 'b_none' ) ) . '</p>';
		} else {
			echo '<ul class="wk-m-board__list">';
			foreach ( $mine as $d ) {
				$state = 'publish' === $d['status'] ? sprintf( $this->t( 'b_live' ), $d['expires'] ? wp_date( get_option( 'date_format' ), strtotime( $d['expires'] ) ) : '—' ) : $this->t( 'b_off' );
				echo '<li><span class="wk-m-board__t"><strong>' . esc_html( $d['title'] ) . '</strong>' . ( $d['price'] ? ' · ' . esc_html( $d['price'] ) : '' ) . '<small>' . esc_html( $state ) . '</small></span>';
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(this.dataset.q)" data-q="' . esc_attr( $this->t( 'b_confirm' ) ) . '"><input type="hidden" name="action" value="wakoo_board_delete"><input type="hidden" name="id" value="' . (int) $d['id'] . '"><input type="hidden" name="back" value="' . esc_attr( $this->here() ) . '"><input type="hidden" name="_wknonce" value="' . esc_attr( wp_create_nonce( 'wakoo_board_delete_' . $d['id'] ) ) . '"><button type="submit" class="wk-m-btn wk-m-btn--ghost">' . esc_html( $this->t( 'b_delete' ) ) . '</button></form></li>';
			}
			echo '</ul>';
		}
		echo '<details class="wk-m-board__add"><summary>' . esc_html( $this->t( $p . 'add' ) ) . '</summary>';
		echo '<form class="wk-m-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" enctype="multipart/form-data">';
		echo '<input type="hidden" name="action" value="wakoo_board_save"><input type="hidden" name="wk_type" value="' . esc_attr( $kind ) . '"><input type="hidden" name="back" value="' . esc_attr( $this->here() ) . '"><input type="hidden" name="_wknonce" value="' . esc_attr( wp_create_nonce( 'wakoo_board_save' ) ) . '"><div class="wk-m-grid">';
		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- field() and select() escape.
		if ( $job ) {
			echo $this->field( 'wk_title', $this->t( 'j_name' ), 'text', '', true, ' maxlength="120"' );
			$opts = '';
			foreach ( Board::TYPES as $t ) {
				$opts .= '<option value="' . esc_attr( $t ) . '">' . esc_html( $this->t( 'type_' . $t ) ) . '</option>';
			}
			echo '<div class="wk-m-field"><label for="wkm-' . esc_attr( $this->get_id() ) . '-jt">' . esc_html( $this->t( 'j_type' ) ) . '</label><select id="wkm-' . esc_attr( $this->get_id() ) . '-jt" name="wk_jobtype">' . $opts . '</select></div>';
			echo $this->field( 'wk_location', $this->t( 'j_location' ), 'text', '', false, ' maxlength="80"' );
			echo $this->field( 'wk_price', $this->t( 'j_salary' ), 'text', '', false, ' maxlength="60"' );
			echo '<div class="wk-m-wide">' . $this->field( 'wk_text', $this->t( 'j_text' ), 'textarea', '', true, ' maxlength="3000"' ) . '</div>';
			echo $this->field( 'wk_email', $this->t( 'j_email' ), 'email', '' );
			echo $this->field( 'wk_url', $this->t( 'j_url' ), 'url', '', false, ' placeholder="https://"' );
		} else {
			echo $this->field( 'wk_title', $this->t( 'm_name' ), 'text', '', true, ' maxlength="120"' );
			echo $this->field( 'wk_price', $this->t( 'm_price' ), 'text', '', false, ' maxlength="60"' );
			$cats = $this->categories( $s['categories'] ?? '' );
			echo $cats ? '<div class="wk-m-wide">' . $this->select( 'wk_category', $this->t( 'category' ), $cats ) . '</div>' : '';
			echo '<div class="wk-m-wide">' . $this->field( 'wk_text', $this->t( 'm_text' ), 'textarea', '', true, ' maxlength="3000"' ) . '</div>';
			echo '<div class="wk-m-wide">' . $this->field( 'wk_image', $this->t( 'm_image' ), 'file', '', false, ' accept="image/jpeg,image/png,image/webp"' ) . '</div>';
			echo '<div class="wk-m-wide">' . $this->field( 'wk_gallery[]', $this->t( 'm_gallery' ), 'file', '', false, ' accept="image/jpeg,image/png,image/webp" multiple' ) . '</div>';
		}
		// phpcs:enable
		echo '</div><button type="submit" class="wk-m-btn">' . esc_html( $this->t( 'b_publish' ) ) . '</button></form></details></section>';
	}

	private function login_box( $s ) {
		echo '<div class="wk-m-card wk-m-login"><h3>' . esc_html( $this->t( 'login_title' ) ) . '</h3>';
		wp_login_form( [
			'redirect'       => $this->here(),
			'label_username' => $this->t( 'user' ),
			'label_password' => $this->t( 'pass' ),
			'label_remember' => $this->t( 'remember' ),
			'label_log_in'   => $this->t( 'login' ),
			'id_form'        => 'wkm-login-' . $this->get_id(),
		] );
		echo '<p class="wk-m-links"><a href="' . esc_url( wp_lostpassword_url( $this->here() ) ) . '">' . esc_html( $this->t( 'lost' ) ) . '</a></p>';
		if ( ! empty( $s['apply_url']['url'] ) ) {
			echo '<p class="wk-m-links">' . esc_html( $this->t( 'not_member' ) ) . ' <a href="' . esc_url( $s['apply_url']['url'] ) . '">' . esc_html( $this->t( 'apply' ) ) . '</a></p>';
		}
		echo '</div>';
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		echo '<div class="wk-m wk-m-account" id="wakoo-member">';
		$edit_mode = class_exists( '\Elementor\Plugin' ) && \Elementor\Plugin::$instance->editor->is_edit_mode();
		if ( ! is_user_logged_in() || $edit_mode ) {
			$this->login_box( $s );
			echo '</div>';
			return;
		}
		$pid = Module::profile_of( get_current_user_id() );
		$out = '<a class="wk-m-link" href="' . esc_url( wp_logout_url( $this->here() ) ) . '">' . esc_html( $this->t( 'logout' ) ) . '</a>';
		if ( ! $pid ) {
			echo '<div class="wk-m-card"><p>' . esc_html( $this->t( 'no_profile' ) ) . '</p>' . $out . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return;
		}
		$d = Module::data( $pid );
		if ( 'publish' !== $d['status'] ) {
			echo '<div class="wk-m-card"><p>' . esc_html( $this->t( 'pending' === $d['status'] ? 'pending' : 'suspended' ) ) . '</p>' . $out . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return;
		}
		echo $this->notice( [ // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			'saved'        => [ 'ok', $this->t( 'saved' ) ],
			'saved_errors' => [ 'err', $this->t( 'saved_err' ) ],
			'expired'      => [ 'err', $this->t( 'expired' ) ],
			'board_saved'   => [ 'ok', $this->t( 'b_saved' ) ],
			'board_deleted' => [ 'ok', $this->t( 'b_deleted' ) ],
			'board_invalid' => [ 'err', $this->t( 'b_invalid' ) ],
			'board_limit'   => [ 'err', $this->t( 'b_limit' ) ],
		] );
		echo '<div class="wk-m-bar">' . ( $d['logo'] ? wp_get_attachment_image( $d['logo'], 'thumbnail', false, [ 'class' => 'wk-m-bar__logo' ] ) : '' );
		echo '<div class="wk-m-bar__txt"><strong>' . esc_html( sprintf( $this->t( 'hello' ), wp_get_current_user()->display_name ) ) . '</strong><span>' . esc_html( $d['name'] ) . '</span></div>';
		echo '<a class="wk-m-btn wk-m-btn--ghost" href="' . esc_url( $d['url'] ) . '">' . esc_html( $this->t( 'view' ) ) . '</a>' . $out . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		$unread = Chat::unread( $pid, 'member' );
		echo '<section class="wk-m-card wk-m-chat"><h3>' . esc_html( $this->t( 'chat_title' ) ) . ( $unread ? ' <span class="wk-m-chip">' . esc_html( sprintf( $this->t( 'chat_new' ), $unread ) ) . '</span>' : '' ) . '</h3>';
		echo Chat::box( $pid, 'member', [ // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			'loading'     => $this->t( 'chat_loading' ),
			'empty'       => $this->t( 'chat_empty' ),
			'placeholder' => $this->t( 'chat_ph' ),
			'send'        => $this->t( 'chat_send' ),
			'attach'      => $this->t( 'chat_attach' ),
			'error'       => $this->t( 'chat_error' ),
			'admin'       => $this->t( 'chat_team' ),
			'member'      => $this->t( 'chat_you' ),
			'log'         => $this->t( 'chat_title' ),
		] );
		echo '</section>';

		echo '<form class="wk-m-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" enctype="multipart/form-data">';
		echo '<input type="hidden" name="action" value="wakoo_member_save"><input type="hidden" name="back" value="' . esc_attr( $this->here() ) . '">';
		echo '<input type="hidden" name="_wknonce" value="' . esc_attr( wp_create_nonce( Module::NONCE . '_save' ) ) . '">';
		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- field() escapes.
		echo '<fieldset class="wk-m-card"><legend>' . esc_html( $this->t( 's_profile' ) ) . '</legend><div class="wk-m-grid">';
		echo $this->field( 'wk_name', $this->t( 'name' ), 'text', $d['name'], true );
		$cats = $this->categories( $s['categories'] ?? '' );
		if ( $d['category'] && ! in_array( $d['category'], $cats, true ) ) {
			$cats[] = $d['category'];
		}
		echo $cats ? $this->select( 'wk_category', $this->t( 'category' ), $cats, $d['category'] ) : '';
		echo '<div class="wk-m-wide">' . $this->field( 'wk_tagline', $this->t( 'tagline' ), 'text', $d['tagline'], false, ' maxlength="140"' ) . '</div>';
		echo '<div class="wk-m-wide">' . $this->field( 'wk_description', $this->t( 'description' ), 'textarea', $d['description'], true, ' maxlength="3000"' ) . '</div>';
		echo '</div></fieldset>';

		echo '<fieldset class="wk-m-card"><legend>' . esc_html( $this->t( 's_contact' ) ) . '</legend><div class="wk-m-grid">';
		echo $this->field( 'wk_contact', $this->t( 'contact' ), 'text', $d['contact'] );
		echo $this->field( 'wk_email', $this->t( 'email' ), 'email', $d['email'] );
		echo $this->field( 'wk_phone', $this->t( 'phone' ), 'tel', $d['phone'] );
		echo $this->field( 'wk_website', $this->t( 'website' ), 'url', $d['website'], false, ' placeholder="https://"' );
		echo '<div class="wk-m-wide">' . $this->field( 'wk_address', $this->t( 'address' ), 'text', $d['address'] ) . '</div>';
		echo $this->field( 'wk_facebook', $this->t( 'facebook' ), 'url', $d['facebook'], false, ' placeholder="https://facebook.com/…"' );
		echo $this->field( 'wk_instagram', $this->t( 'instagram' ), 'url', $d['instagram'], false, ' placeholder="https://instagram.com/…"' );
		echo '</div></fieldset>';

		echo '<fieldset class="wk-m-card"><legend>' . esc_html( $this->t( 's_images' ) ) . '</legend>';
		echo $this->field( 'wk_logo', $this->t( 'logo' ), 'file', '', false, ' accept="image/jpeg,image/png,image/webp,image/gif"' );
		if ( $d['gallery'] ) {
			echo '<div class="wk-m-thumbs">';
			foreach ( $d['gallery'] as $aid ) {
				echo '<label class="wk-m-thumb">' . wp_get_attachment_image( $aid, 'thumbnail' ) . '<span><input type="checkbox" name="wk_remove[]" value="' . (int) $aid . '"> ' . esc_html( $this->t( 'remove' ) ) . '</span></label>';
			}
			echo '</div>';
		}
		echo $this->field( 'wk_gallery[]', $this->t( 'gallery' ), 'file', '', false, ' multiple accept="image/jpeg,image/png,image/webp,image/gif"' );
		echo '</fieldset>';
		// phpcs:enable
		echo '<button type="submit" class="wk-m-btn">' . esc_html( $this->t( 'save' ) ) . '</button></form>';
		$this->board_section( 'listing', $s );
		$this->board_section( 'job', $s );
		echo '</div>';
	}
}
