<?php
/**
 * "Busco trabajo (Wakoo)": anyone can publish that they are looking for work.
 * The entry waits in Miembros Wakoo → Empleo until the team approves it.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Members;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Seeker_Widget extends Base {

	public function get_name() { return 'wakoo-job-seeker'; }
	public function get_title() { return __( 'Busco trabajo (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-form-horizontal'; }
	public function get_keywords() { return [ 'empleo', 'trabajo', 'candidato', 'curriculum', 'cv', 'wakoo' ]; }

	protected function texts() {
		return [
			'name'          => [ __( 'Campo: nombre', 'wakoo' ), __( 'Nombre', 'wakoo' ) ],
			'title'         => [ __( 'Campo: puesto buscado', 'wakoo' ), __( 'Qué trabajo buscas', 'wakoo' ) ],
			'jobtype'       => [ __( 'Campo: jornada', 'wakoo' ), __( 'Jornada', 'wakoo' ) ],
			'type_full'     => [ __( 'Jornada: completa', 'wakoo' ), __( 'Tiempo completo', 'wakoo' ) ],
			'type_part'     => [ __( 'Jornada: parcial', 'wakoo' ), __( 'Media jornada', 'wakoo' ) ],
			'type_contract' => [ __( 'Jornada: temporal', 'wakoo' ), __( 'Por obra o temporal', 'wakoo' ) ],
			'location'      => [ __( 'Campo: zona', 'wakoo' ), __( 'Zona', 'wakoo' ) ],
			'text'          => [ __( 'Campo: experiencia', 'wakoo' ), __( 'Experiencia y habilidades', 'wakoo' ) ],
			'email'         => [ __( 'Campo: email', 'wakoo' ), __( 'Email', 'wakoo' ) ],
			'phone'         => [ __( 'Campo: teléfono', 'wakoo' ), __( 'Teléfono (opcional)', 'wakoo' ) ],
			'cv'            => [ __( 'Campo: currículum', 'wakoo' ), __( 'Currículum (PDF, opcional, máx. 5 MB)', 'wakoo' ) ],
			'consent'       => [ __( 'Casilla de privacidad', 'wakoo' ), __( 'Acepto que, tras revisarlo, se publique este anuncio con mi nombre, email y currículum para que me contacten.', 'wakoo' ) ],
			'button'        => [ __( 'Botón', 'wakoo' ), __( 'Enviar', 'wakoo' ) ],
			'sent'          => [ __( 'Mensaje: enviado', 'wakoo' ), __( 'Gracias. Revisaremos tu anuncio antes de publicarlo.', 'wakoo' ) ],
			'invalid'       => [ __( 'Mensaje: faltan datos', 'wakoo' ), __( 'Revisa los campos obligatorios.', 'wakoo' ) ],
			'limit'         => [ __( 'Mensaje: demasiados envíos', 'wakoo' ), __( 'Has enviado varios anuncios seguidos. Inténtalo dentro de una hora.', 'wakoo' ) ],
			'error'         => [ __( 'Mensaje: error', 'wakoo' ), __( 'No se pudo enviar. Recarga la página e inténtalo de nuevo.', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_seeker', [ 'label' => __( 'Formulario', 'wakoo' ) ] );
		$this->add_control( 'privacy_url', [ 'label' => __( 'Enlace a la política de privacidad', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$this->end_controls_section();
		$this->texts_section();
		$this->style_section();
	}

	protected function render() {
		$s       = $this->get_settings_for_display();
		$consent = esc_html( $this->t( 'consent' ) );
		if ( ! empty( $s['privacy_url']['url'] ) ) {
			$consent = '<a href="' . esc_url( $s['privacy_url']['url'] ) . '" target="_blank" rel="noopener">' . $consent . '</a>';
		}
		echo '<div class="wk-m wk-m-seeker" id="wakoo-seeker">';
		echo $this->notice( [ // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			'seeker_sent'    => [ 'ok', $this->t( 'sent' ) ],
			'seeker_invalid' => [ 'err', $this->t( 'invalid' ) ],
			'limit'          => [ 'err', $this->t( 'limit' ) ],
			'expired'        => [ 'err', $this->t( 'error' ) ],
			'error'          => [ 'err', $this->t( 'error' ) ],
		] );
		echo '<form class="wk-m-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" enctype="multipart/form-data">';
		echo '<input type="hidden" name="action" value="wakoo_job_seeker"><input type="hidden" name="back" value="' . esc_attr( $this->here() ) . '"><input type="hidden" name="wk_ts" value="' . (int) time() . '">';
		echo '<input type="hidden" name="_wknonce" value="' . esc_attr( wp_create_nonce( 'wakoo_job_seeker' ) ) . '">';
		echo '<div class="wk-m-hp" aria-hidden="true"><input type="text" name="wk_hp" tabindex="-1" autocomplete="off"></div><div class="wk-m-grid">';
		// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- field() and select() escape.
		echo $this->field( 'wk_name', $this->t( 'name' ), 'text', '', true, ' autocomplete="name" maxlength="80"' );
		echo $this->field( 'wk_title', $this->t( 'title' ), 'text', '', true, ' maxlength="120"' );
		echo $this->type_select( 'wk_jobtype', $this->t( 'jobtype' ) );
		echo $this->field( 'wk_location', $this->t( 'location' ), 'text', '', false, ' maxlength="80"' );
		echo $this->field( 'wk_email', $this->t( 'email' ), 'email', '', true, ' autocomplete="email"' );
		echo $this->field( 'wk_phone', $this->t( 'phone' ), 'tel', '', false, ' autocomplete="tel"' );
		echo '<div class="wk-m-wide">' . $this->field( 'wk_text', $this->t( 'text' ), 'textarea', '', true, ' maxlength="3000"' ) . '</div>';
		echo '<div class="wk-m-wide">' . $this->field( 'wk_cv', $this->t( 'cv' ), 'file', '', false, ' accept="application/pdf"' ) . '</div>';
		// phpcs:enable
		echo '</div><label class="wk-m-check"><input type="checkbox" name="wk_consent" value="1" required> <span>' . $consent . '</span></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<button type="submit" class="wk-m-btn">' . esc_html( $this->t( 'button' ) ) . '</button></form></div>';
	}

	/** Job type drop-down with the widget's own labels. */
	protected function type_select( $name, $label ) {
		$id  = 'wkm-' . $this->get_id() . '-' . sanitize_html_class( $name );
		$out = '<div class="wk-m-field"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label><select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '">';
		foreach ( Board::TYPES as $t ) {
			$out .= '<option value="' . esc_attr( $t ) . '">' . esc_html( $this->t( 'type_' . $t ) ) . '</option>';
		}
		return $out . '</select></div>';
	}
}
