<?php
/**
 * Shared base for the member widgets: every visible text is an editable
 * control (so each language version of a page carries its own words), plus
 * the accent colour and the status messages that come back in the URL.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Members;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

abstract class Base extends Widget_Base {

	/** [ id => [ label in the panel, default text ] ] */
	abstract protected function texts();

	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_style_depends() { return [ 'wakoo-members' ]; }
	public function get_script_depends() { return [ 'wakoo-members' ]; }

	/** The widget's texts plus the ones every member widget shares (file picker labels, so they follow the page's language). */
	protected function all_texts() {
		return $this->texts() + [
			'file_btn'  => [ __( 'Botón: elegir archivo', 'wakoo' ), __( 'Elegir archivo', 'wakoo' ) ],
			'file_none' => [ __( 'Texto: ningún archivo', 'wakoo' ), __( 'Ningún archivo elegido', 'wakoo' ) ],
		];
	}

	protected function texts_section() {
		$this->start_controls_section( 'sec_texts', [ 'label' => __( 'Textos', 'wakoo' ) ] );
		foreach ( $this->all_texts() as $id => $d ) {
			$long = mb_strlen( $d[1] ) > 60;
			$this->add_control( 'lbl_' . $id, [ 'label' => $d[0], 'type' => $long ? Controls_Manager::TEXTAREA : Controls_Manager::TEXT, 'default' => $d[1], 'label_block' => true ] );
		}
		$this->end_controls_section();
	}

	protected function style_section() {
		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'accent', [ 'label' => __( 'Color de acento', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}}' => '--wk-m-accent: {{VALUE}};' ] ] );
		$this->add_control( 'radius', [ 'label' => __( 'Redondez (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 40, 'selectors' => [ '{{WRAPPER}}' => '--wk-m-radius: {{VALUE}}px;' ] ] );
		$this->end_controls_section();
	}

	protected function t( $id ) {
		$v = $this->get_settings_for_display( 'lbl_' . $id );
		if ( null === $v || '' === $v ) {
			$all = $this->all_texts();
			$v   = $all[ $id ][1] ?? '';
		}
		return (string) $v;
	}

	/** Current page URL, used to come back after a form posts to admin-post.php. */
	protected function here() {
		global $wp;
		$url = home_url( add_query_arg( [], $wp->request ? trailingslashit( $wp->request ) : '/' ) );
		return remove_query_arg( [ 'wk_member', 'wk_err' ], $url );
	}

	/** Status coming back from a submit (?wk_member=…), drawn as a notice. */
	protected function notice( array $map ) {
		$st = isset( $_GET['wk_member'] ) ? sanitize_key( wp_unslash( $_GET['wk_member'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! $st || ! isset( $map[ $st ] ) ) {
			return '';
		}
		list( $kind, $text ) = $map[ $st ];
		return '<div class="wk-m-notice wk-m-notice--' . esc_attr( $kind ) . '" role="' . ( 'ok' === $kind ? 'status' : 'alert' ) . '">' . esc_html( $text ) . '</div>';
	}

	protected function field( $name, $label, $type = 'text', $value = '', $req = false, $extra = '' ) {
		$id  = 'wkm-' . $this->get_id() . '-' . sanitize_html_class( $name );
		$req = $req ? ' required aria-required="true"' : '';
		$lab = '<label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . ( $req ? ' <span aria-hidden="true">*</span>' : '' ) . '</label>';
		if ( 'textarea' === $type ) {
			$in = '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" rows="5"' . $req . $extra . '>' . esc_textarea( $value ) . '</textarea>';
		} elseif ( 'file' === $type ) {
			// Our own picker: the browser's native one speaks the browser's language, not the page's.
			$in = '<span class="wk-m-file"><input id="' . esc_attr( $id ) . '" class="wk-m-file__input" type="file" name="' . esc_attr( $name ) . '"' . $req . $extra . '>'
				. '<span class="wk-m-file__btn" aria-hidden="true">' . esc_html( $this->t( 'file_btn' ) ) . '</span>'
				. '<span class="wk-m-file__name" data-none="' . esc_attr( $this->t( 'file_none' ) ) . '">' . esc_html( $this->t( 'file_none' ) ) . '</span></span>';
		} else {
			$in = '<input id="' . esc_attr( $id ) . '" type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '"' . $req . $extra . '>';
		}
		return '<div class="wk-m-field">' . $lab . $in . '</div>';
	}

	protected function select( $name, $label, array $options, $value = '', $req = false ) {
		$id  = 'wkm-' . $this->get_id() . '-' . sanitize_html_class( $name );
		$out = '<div class="wk-m-field"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . ( $req ? ' <span aria-hidden="true">*</span>' : '' ) . '</label><select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '"' . ( $req ? ' required' : '' ) . '><option value="">—</option>';
		foreach ( $options as $o ) {
			$out .= '<option' . selected( $value, $o, false ) . '>' . esc_html( $o ) . '</option>';
		}
		return $out . '</select></div>';
	}

	/** Category names: the widget's own list, else the existing member categories. */
	protected function categories( $raw ) {
		$list = array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) $raw ) ) ) );
		if ( ! $list ) {
			$terms = get_terms( [ 'taxonomy' => Module::TAX, 'hide_empty' => false, 'fields' => 'names' ] );
			$list  = is_wp_error( $terms ) ? [] : $terms;
		}
		return $list;
	}
}
