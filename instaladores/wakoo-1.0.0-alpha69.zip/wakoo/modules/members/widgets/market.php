<?php
/**
 * "Marketplace de miembros (Wakoo)": products and services published by the
 * members, with search and category buttons. Contact goes straight to the
 * member (the site takes no part in the sale).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Members;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Market_Widget extends Base {

	public function get_name() { return 'wakoo-market'; }
	public function get_title() { return __( 'Marketplace de miembros (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-products'; }
	public function get_keywords() { return [ 'marketplace', 'mercado', 'anuncios', 'productos', 'servicios', 'miembros', 'wakoo' ]; }

	protected function texts() {
		return [
			'search'  => [ __( 'Buscador: marcador', 'wakoo' ), __( 'Buscar productos y servicios…', 'wakoo' ) ],
			'all'     => [ __( 'Botón «Todas»', 'wakoo' ), __( 'Todas', 'wakoo' ) ],
			'email'   => [ __( 'Botón: escribir', 'wakoo' ), __( 'Escribir al vendedor', 'wakoo' ) ],
			'call'    => [ __( 'Botón: llamar', 'wakoo' ), __( 'Llamar', 'wakoo' ) ],
			'profile' => [ __( 'Enlace: perfil', 'wakoo' ), __( 'Ver perfil', 'wakoo' ) ],
			'empty'   => [ __( 'Sin anuncios', 'wakoo' ), __( 'Pronto verás aquí los productos y servicios de los miembros.', 'wakoo' ) ],
			'none'    => [ __( 'Sin resultados', 'wakoo' ), __( 'No hay anuncios que coincidan.', 'wakoo' ) ],
			'demo'    => [ __( 'Etiqueta: anuncio de ejemplo', 'wakoo' ), __( 'Ejemplo', 'wakoo' ) ],
			'demo_cta' => [ __( 'Botón de los ejemplos', 'wakoo' ), __( 'Publica el tuyo', 'wakoo' ) ],
			'featured' => [ __( 'Etiqueta: destacado (servidor de anuncios)', 'wakoo' ), __( 'Destacado', 'wakoo' ) ],
			'open'     => [ __( 'Botón: ver anuncio', 'wakoo' ), __( 'Ver anuncio', 'wakoo' ) ],
			'seller'   => [ __( 'Ventana: publicado por', 'wakoo' ), __( 'Publicado por', 'wakoo' ) ],
			'demo_by'  => [ __( 'Ventana: autor de los ejemplos', 'wakoo' ), __( 'Anuncio de ejemplo de la comunidad', 'wakoo' ) ],
			'close'    => [ __( 'Ventana: cerrar', 'wakoo' ), __( 'Cerrar', 'wakoo' ) ],
			'photo'    => [ __( 'Ventana: foto', 'wakoo' ), __( 'Foto', 'wakoo' ) ],
			'prev'     => [ __( 'Páginas: anterior', 'wakoo' ), __( 'Anterior', 'wakoo' ) ],
			'next'     => [ __( 'Páginas: siguiente', 'wakoo' ), __( 'Siguiente', 'wakoo' ) ],
			'pages'    => [ __( 'Páginas: nombre', 'wakoo' ), __( 'Páginas', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_market', [ 'label' => __( 'Marketplace', 'wakoo' ) ] );
		$this->add_responsive_control( 'columns', [ 'label' => __( 'Columnas', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 6, 'default' => 3, 'tablet_default' => 2, 'mobile_default' => 1, 'selectors' => [ '{{WRAPPER}} .wk-m-dir__grid' => 'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));' ] ] );
		$this->add_control( 'max', [ 'label' => __( 'Máximo de anuncios', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 200, 'default' => 60 ] );
		$this->add_control( 'per_page', [ 'label' => __( 'Anuncios por página (0 = todos)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 60, 'default' => 0 ] );
		$this->add_control( 'search', [ 'label' => __( 'Mostrar buscador', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'filters', [ 'label' => __( 'Mostrar categorías', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();
		$this->texts_section();
		$this->style_section();
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$items = $this->featured( Board::query( Board::LISTING, '', min( 200, max( 1, (int) ( $s['max'] ?? 60 ) ) ) ) );
		$lab   = [ 'email' => $this->t( 'email' ), 'call' => $this->t( 'call' ), 'profile' => $this->t( 'profile' ) ];
		echo '<div class="wk-m wk-m-dir wk-m-market" id="wakoo-market"' . $this->pages_attr( $s ) . '>';
		if ( ! $items ) {
			echo '<p class="wk-m-empty">' . esc_html( $this->t( 'empty' ) ) . '</p></div>';
			return;
		}
		$cats  = [];
		$cards = '';
		foreach ( $items as $d ) {
			$m = $d['member'] ? Module::data( $d['member'] ) : null;
			if ( $d['category'] ) {
				$cats[ $d['category'] ] = true;
			}
			$img   = $d['image'] ? '<button type="button" class="wk-m-item__open wk-m-item__photo" aria-haspopup="dialog" aria-label="' . esc_attr( $this->t( 'open' ) . ': ' . $d['title'] ) . '">'
				. wp_get_attachment_image( $d['image'], 'medium_large', false, [ 'class' => 'wk-m-item__img', 'loading' => 'lazy', 'alt' => $d['title'] ] )
				. ( count( $d['gallery'] ) > 1 ? '<span class="wk-m-item__count" aria-hidden="true">' . count( $d['gallery'] ) . '</span>' : '' ) . '</button>' : '';
			$text  = mb_strtolower( wp_strip_all_tags( $d['title'] . ' ' . $d['text'] . ' ' . $d['category'] . ' ' . ( $m ? $m['name'] : '' ) ) );
			$feat  = ! empty( $d['featured_ad'] );
			$cards .= '<article class="wk-m-card wk-m-dir__item wk-m-item' . ( $feat ? ' wk-m-item--featured' : '' ) . '" data-cat="' . esc_attr( $d['category'] ) . '" data-text="' . esc_attr( $text ) . '"'
				. ( $feat ? ' data-wk-ad-view="' . (int) $d['featured_ad'] . '"' : '' ) . '>'
				. $img
				. '<div class="wk-m-item__head">' . ( $feat ? '<span class="wk-m-chip wk-m-chip--featured">' . esc_html( $this->t( 'featured' ) ) . '</span>' : '' ) . ( $d['demo'] ? '<span class="wk-m-chip wk-m-chip--demo">' . esc_html( $this->t( 'demo' ) ) . '</span>' : '' ) . ( $d['category'] ? '<span class="wk-m-chip">' . esc_html( $d['category'] ) . '</span>' : '' ) . ( $d['price'] ? '<strong class="wk-m-item__price">' . esc_html( $d['price'] ) . '</strong>' : '' ) . '</div>'
				. '<h3 class="wk-m-card__title"><button type="button" class="wk-m-item__open wk-m-item__name" aria-haspopup="dialog">' . esc_html( $d['title'] ) . '</button></h3>'
				. '<p class="wk-m-card__text">' . esc_html( wp_trim_words( $d['text'], 28, '…' ) ) . '</p>'
				. ( $m ? '<p class="wk-m-item__by">' . ( $m['logo'] ? wp_get_attachment_image( $m['logo'], [ 28, 28 ], false, [ 'alt' => '' ] ) : '' ) . esc_html( $m['name'] ) . '</p>' : '' )
				. '<div class="wk-m-item__actions">' . ( $d['demo'] ? Board::demo_link( $this->t( 'demo_cta' ) ) : Board::contact_links( $d, $lab ) ) . '</div>'
				. $this->popup( $d, $m, $lab ) . '</article>';
		}
		$this->tools( $s, $cats );
		echo '<div class="wk-m-dir__grid">' . $cards . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<p class="wk-m-empty wk-m-dir__none" hidden>' . esc_html( $this->t( 'none' ) ) . '</p>';
		$this->pager();
		echo '<dialog class="wk-m-pop" aria-label="' . esc_attr( $this->t( 'open' ) ) . '"><button type="button" class="wk-m-pop__close" aria-label="' . esc_attr( $this->t( 'close' ) ) . '">&times;</button><div class="wk-m-pop__in"></div></dialog></div>';
	}

	/** Popup content of one listing (a <template>, cloned into the widget's <dialog>): photos, title, text, price and seller. */
	private function popup( array $d, $m, array $lab ) {
		$thumbs = '';
		foreach ( $d['gallery'] as $i => $aid ) {
			$full = wp_get_attachment_image_url( $aid, 'large' );
			$thumbs .= '<button type="button" class="wk-m-pop__thumb' . ( 0 === $i ? ' is-on' : '' ) . '" data-full="' . esc_url( $full ) . '" aria-label="' . esc_attr( $this->t( 'photo' ) . ' ' . ( $i + 1 ) ) . '">'
				. wp_get_attachment_image( $aid, 'thumbnail', false, [ 'alt' => '', 'loading' => 'lazy' ] ) . '</button>';
		}
		$main = $d['gallery'] ? '<div class="wk-m-pop__photos"><img class="wk-m-pop__main" src="' . esc_url( wp_get_attachment_image_url( $d['gallery'][0], 'large' ) ) . '" alt="' . esc_attr( $d['title'] ) . '">'
			. ( count( $d['gallery'] ) > 1 ? '<div class="wk-m-pop__thumbs">' . $thumbs . '</div>' : '' ) . '</div>' : '';
		if ( $m ) {
			$who = '<a class="wk-m-pop__seller" href="' . esc_url( $m['url'] ) . '">' . ( $m['logo'] ? wp_get_attachment_image( $m['logo'], [ 40, 40 ], false, [ 'alt' => '' ] ) : '' ) . '<span>' . esc_html( $m['name'] ) . '</span></a>';
		} else {
			$who = '<span class="wk-m-pop__seller"><span>' . esc_html( $d['name'] ? $d['name'] : ( $d['demo'] ? $this->t( 'demo_by' ) : '' ) ) . '</span></span>';
		}
		return '<template class="wk-m-pop__tpl">' . $main . '<div class="wk-m-pop__body">'
			. '<div class="wk-m-item__head">' . ( $d['demo'] ? '<span class="wk-m-chip wk-m-chip--demo">' . esc_html( $this->t( 'demo' ) ) . '</span>' : '' ) . ( $d['category'] ? '<span class="wk-m-chip">' . esc_html( $d['category'] ) . '</span>' : '' ) . '</div>'
			. '<h2 class="wk-m-pop__title">' . esc_html( $d['title'] ) . '</h2>'
			. ( $d['price'] ? '<p class="wk-m-pop__price">' . esc_html( $d['price'] ) . '</p>' : '' )
			. '<div class="wk-m-pop__text">' . wp_kses_post( wpautop( esc_html( $d['text'] ) ) ) . '</div>'
			. '<div class="wk-m-pop__by"><small>' . esc_html( $this->t( 'seller' ) ) . '</small>' . $who . '</div>'
			. '<div class="wk-m-item__actions">' . ( $d['demo'] ? Board::demo_link( $this->t( 'demo_cta' ) ) : Board::contact_links( $d, $lab ) ) . '</div>'
			. '</div></template>';
	}

	/**
	 * The first positions can be taken by listings featured from the ad server (Anuncios Wakoo →
	 * «Destacado del marketplace»); the rest keep the newest first.
	 */
	private function featured( array $items ) {
		if ( ! class_exists( '\Wakoo\Modules\Ads\Module' ) ) {
			return $items;
		}
		$feat = [];
		foreach ( \Wakoo\Modules\Ads\Module::market_picks() as $pos => $pick ) {
			$it = Board::item( $pick[1] );
			if ( $it && 'publish' === $it['status'] ) {
				$it['featured_ad'] = $pick[0];
				$feat[ $pos ]      = $it;
			}
		}
		if ( ! $feat ) {
			return $items;
		}
		$ids   = wp_list_pluck( $feat, 'id' );
		$items = array_values( array_filter( $items, function ( $d ) use ( $ids ) { return ! in_array( $d['id'], $ids, true ); } ) );
		ksort( $feat );
		foreach ( $feat as $pos => $it ) {
			array_splice( $items, min( $pos - 1, count( $items ) ), 0, [ $it ] );
		}
		return $items;
	}

	/** Counts the views of featured listings (the ad server's script). */
	public function get_script_depends() {
		$deps = parent::get_script_depends();
		return wp_script_is( 'wakoo-ads', 'registered' ) ? array_merge( $deps, [ 'wakoo-ads' ] ) : $deps;
	}

	/** data-per-page on the root: the directory script shows that many cards per page with numbered pages. */
	protected function pages_attr( array $s ) {
		$per = max( 0, (int) ( $s['per_page'] ?? 0 ) );
		return $per ? ' data-per-page="' . $per . '"' : '';
	}

	protected function pager() {
		echo '<nav class="wk-m-dir__pages" aria-label="' . esc_attr( $this->t( 'pages' ) ) . '" data-prev="' . esc_attr( $this->t( 'prev' ) ) . '" data-next="' . esc_attr( $this->t( 'next' ) ) . '" hidden></nav>';
	}

	/** Search box and category buttons (the directory script filters the cards). */
	protected function tools( array $s, array $cats, array $labels = [] ) {
		$search  = 'yes' === ( $s['search'] ?? '' );
		$filters = 'yes' === ( $s['filters'] ?? '' ) && count( $cats ) > 1;
		if ( ! $search && ! $filters ) {
			return;
		}
		echo '<div class="wk-m-dir__tools">';
		if ( $search ) {
			echo '<input class="wk-m-dir__search" type="search" placeholder="' . esc_attr( $this->t( 'search' ) ) . '" aria-label="' . esc_attr( $this->t( 'search' ) ) . '">';
		}
		if ( $filters ) {
			ksort( $cats );
			echo '<div class="wk-m-dir__cats" role="group"><button type="button" class="wk-m-chip is-on" data-cat="" aria-pressed="true">' . esc_html( $this->t( 'all' ) ) . '</button>';
			foreach ( array_keys( $cats ) as $c ) {
				echo '<button type="button" class="wk-m-chip" data-cat="' . esc_attr( $c ) . '" aria-pressed="false">' . esc_html( $labels[ $c ] ?? $c ) . '</button>';
			}
			echo '</div>';
		}
		echo '</div>';
	}
}
