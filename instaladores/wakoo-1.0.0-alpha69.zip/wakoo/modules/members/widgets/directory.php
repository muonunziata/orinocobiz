<?php
/**
 * "Directorio de miembros (Wakoo)": approved members as cards, with a
 * search box and category buttons that filter in the browser.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Members;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Directory_Widget extends Base {

	public function get_name() { return 'wakoo-member-directory'; }
	public function get_title() { return __( 'Directorio de miembros (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-gallery-grid'; }
	public function get_keywords() { return [ 'miembro', 'member', 'directorio', 'negocios', 'listado', 'wakoo' ]; }

	protected function texts() {
		return [
			'search' => [ __( 'Buscador: marcador', 'wakoo' ), __( 'Buscar negocios…', 'wakoo' ) ],
			'all'    => [ __( 'Botón «Todas»', 'wakoo' ), __( 'Todas', 'wakoo' ) ],
			'view'   => [ __( 'Enlace: ver perfil', 'wakoo' ), __( 'Ver perfil', 'wakoo' ) ],
			'empty'  => [ __( 'Sin miembros todavía', 'wakoo' ), __( 'Pronto verás aquí a los primeros miembros.', 'wakoo' ) ],
			'none'   => [ __( 'Sin resultados', 'wakoo' ), __( 'No hay miembros que coincidan.', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_dir', [ 'label' => __( 'Directorio', 'wakoo' ) ] );
		$this->add_responsive_control( 'columns', [ 'label' => __( 'Columnas', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 6, 'default' => 3, 'tablet_default' => 2, 'mobile_default' => 1, 'selectors' => [ '{{WRAPPER}} .wk-m-dir__grid' => 'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));' ] ] );
		$this->add_control( 'max', [ 'label' => __( 'Máximo de miembros', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 300, 'default' => 60 ] );
		$this->add_control( 'category', [ 'label' => __( 'Solo esta categoría (opcional)', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$this->add_control( 'search', [ 'label' => __( 'Mostrar buscador', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'filters', [ 'label' => __( 'Mostrar categorías', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();
		$this->texts_section();
		$this->style_section();
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$args = [ 'post_type' => Module::CPT, 'post_status' => 'publish', 'posts_per_page' => min( 300, max( 1, (int) ( $s['max'] ?? 60 ) ) ), 'orderby' => 'title', 'order' => 'ASC', 'fields' => 'ids' ];
		if ( ! empty( $s['category'] ) ) {
			$args['tax_query'] = [ [ 'taxonomy' => Module::TAX, 'field' => 'name', 'terms' => sanitize_text_field( $s['category'] ) ] ]; // phpcs:ignore WordPress.DB.SlowDBQuery
		}
		$ids = get_posts( $args );
		echo '<div class="wk-m wk-m-dir">';
		if ( ! $ids ) {
			echo '<p class="wk-m-empty">' . esc_html( $this->t( 'empty' ) ) . '</p></div>';
			return;
		}
		$cards = [];
		$cats  = [];
		foreach ( $ids as $pid ) {
			$d = Module::data( $pid );
			if ( $d['category'] ) {
				$cats[ $d['category'] ] = true;
			}
			$logo    = $d['logo'] ? wp_get_attachment_image( $d['logo'], 'medium', false, [ 'class' => 'wk-m-card__logo', 'loading' => 'lazy', 'alt' => $d['name'] ] ) : '<span class="wk-m-card__logo wk-m-card__logo--empty" aria-hidden="true">' . esc_html( mb_substr( $d['name'], 0, 1 ) ) . '</span>';
			$summary = $d['tagline'] ?: wp_trim_words( $d['description'], 18, '…' );
			$text    = mb_strtolower( wp_strip_all_tags( $d['name'] . ' ' . $d['category'] . ' ' . $d['tagline'] . ' ' . $d['description'] . ' ' . $d['address'] ) );
			$cards[] = '<article class="wk-m-card wk-m-dir__item" data-cat="' . esc_attr( $d['category'] ) . '" data-text="' . esc_attr( $text ) . '">'
				. '<a class="wk-m-card__link" href="' . esc_url( $d['url'] ) . '">' . $logo . '</a>'
				. ( $d['category'] ? '<span class="wk-m-chip">' . esc_html( $d['category'] ) . '</span>' : '' )
				. '<h3 class="wk-m-card__title"><a href="' . esc_url( $d['url'] ) . '">' . esc_html( $d['name'] ) . '</a></h3>'
				. ( $summary ? '<p class="wk-m-card__text">' . esc_html( $summary ) . '</p>' : '' )
				. ( $d['address'] ? '<p class="wk-m-card__where">' . esc_html( $d['address'] ) . '</p>' : '' )
				. '<a class="wk-m-link" href="' . esc_url( $d['url'] ) . '">' . esc_html( $this->t( 'view' ) ) . ' →</a></article>';
		}
		if ( 'yes' === ( $s['search'] ?? '' ) || ( 'yes' === ( $s['filters'] ?? '' ) && count( $cats ) > 1 ) ) {
			echo '<div class="wk-m-dir__tools">';
			if ( 'yes' === ( $s['search'] ?? '' ) ) {
				echo '<input class="wk-m-dir__search" type="search" placeholder="' . esc_attr( $this->t( 'search' ) ) . '" aria-label="' . esc_attr( $this->t( 'search' ) ) . '">';
			}
			if ( 'yes' === ( $s['filters'] ?? '' ) && count( $cats ) > 1 ) {
				ksort( $cats );
				echo '<div class="wk-m-dir__cats" role="group"><button type="button" class="wk-m-chip is-on" data-cat="" aria-pressed="true">' . esc_html( $this->t( 'all' ) ) . '</button>';
				foreach ( array_keys( $cats ) as $c ) {
					echo '<button type="button" class="wk-m-chip" data-cat="' . esc_attr( $c ) . '" aria-pressed="false">' . esc_html( $c ) . '</button>';
				}
				echo '</div>';
			}
			echo '</div>';
		}
		echo '<div class="wk-m-dir__grid">' . implode( '', $cards ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<p class="wk-m-empty wk-m-dir__none" hidden>' . esc_html( $this->t( 'none' ) ) . '</p></div>';
	}
}
