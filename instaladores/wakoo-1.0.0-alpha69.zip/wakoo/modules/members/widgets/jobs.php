<?php
/**
 * "Bolsa de empleo (Wakoo)": job offers published by members and approved
 * job seekers, with search and Offers / Candidates buttons. Offers carry
 * JobPosting structured data (Google for Jobs).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Members;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Jobs_Widget extends Market_Widget {

	public function get_name() { return 'wakoo-jobs'; }
	public function get_title() { return __( 'Bolsa de empleo (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-person'; }
	public function get_keywords() { return [ 'empleo', 'trabajo', 'jobs', 'ofertas', 'candidatos', 'miembros', 'wakoo' ]; }

	protected function texts() {
		return [
			'search'        => [ __( 'Buscador: marcador', 'wakoo' ), __( 'Buscar puesto, empresa o habilidad…', 'wakoo' ) ],
			'all'           => [ __( 'Botón «Todo»', 'wakoo' ), __( 'Todo', 'wakoo' ) ],
			'offers'        => [ __( 'Botón: ofertas', 'wakoo' ), __( 'Ofertas de empleo', 'wakoo' ) ],
			'seekers'       => [ __( 'Botón: candidatos', 'wakoo' ), __( 'Personas que buscan trabajo', 'wakoo' ) ],
			'offer'         => [ __( 'Etiqueta: oferta', 'wakoo' ), __( 'Oferta', 'wakoo' ) ],
			'seeker'        => [ __( 'Etiqueta: candidato', 'wakoo' ), __( 'Busca trabajo', 'wakoo' ) ],
			'type_full'     => [ __( 'Jornada: completa', 'wakoo' ), __( 'Tiempo completo', 'wakoo' ) ],
			'type_part'     => [ __( 'Jornada: parcial', 'wakoo' ), __( 'Media jornada', 'wakoo' ) ],
			'type_contract' => [ __( 'Jornada: temporal', 'wakoo' ), __( 'Por obra o temporal', 'wakoo' ) ],
			'details'       => [ __( 'Enlace: detalles', 'wakoo' ), __( 'Ver detalles', 'wakoo' ) ],
			'apply'         => [ __( 'Botón: postular (enlace)', 'wakoo' ), __( 'Postular', 'wakoo' ) ],
			'email'         => [ __( 'Botón: postular por email', 'wakoo' ), __( 'Postular por email', 'wakoo' ) ],
			'contact'       => [ __( 'Botón: contactar candidato', 'wakoo' ), __( 'Contactar', 'wakoo' ) ],
			'cv'            => [ __( 'Enlace: currículum', 'wakoo' ), __( 'Ver currículum', 'wakoo' ) ],
			'call'          => [ __( 'Botón: llamar', 'wakoo' ), __( 'Llamar', 'wakoo' ) ],
			'profile'       => [ __( 'Enlace: empresa', 'wakoo' ), __( 'Ver la empresa', 'wakoo' ) ],
			'salary'        => [ __( 'Etiqueta: salario', 'wakoo' ), __( 'Salario', 'wakoo' ) ],
			'empty'         => [ __( 'Sin anuncios', 'wakoo' ), __( 'Aún no hay ofertas ni candidatos publicados.', 'wakoo' ) ],
			'none'          => [ __( 'Sin resultados', 'wakoo' ), __( 'No hay anuncios que coincidan.', 'wakoo' ) ],
			'demo'          => [ __( 'Etiqueta: oferta de ejemplo', 'wakoo' ), __( 'Ejemplo', 'wakoo' ) ],
			'demo_cta'      => [ __( 'Botón de los ejemplos', 'wakoo' ), __( 'Publica tu oferta', 'wakoo' ) ],
			'prev'          => [ __( 'Páginas: anterior', 'wakoo' ), __( 'Anterior', 'wakoo' ) ],
			'next'          => [ __( 'Páginas: siguiente', 'wakoo' ), __( 'Siguiente', 'wakoo' ) ],
			'pages'         => [ __( 'Páginas: nombre', 'wakoo' ), __( 'Páginas', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_jobs', [ 'label' => __( 'Bolsa de empleo', 'wakoo' ) ] );
		$this->add_responsive_control( 'columns', [ 'label' => __( 'Columnas', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 4, 'default' => 2, 'tablet_default' => 2, 'mobile_default' => 1, 'selectors' => [ '{{WRAPPER}} .wk-m-dir__grid' => 'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));' ] ] );
		$this->add_control( 'show', [ 'label' => __( 'Mostrar', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'both', 'options' => [ 'both' => __( 'Ofertas y candidatos', 'wakoo' ), 'offer' => __( 'Solo ofertas', 'wakoo' ), 'seeker' => __( 'Solo candidatos', 'wakoo' ) ] ] );
		$this->add_control( 'max', [ 'label' => __( 'Máximo por tipo', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 1, 'max' => 200, 'default' => 60 ] );
		$this->add_control( 'per_page', [ 'label' => __( 'Anuncios por página (0 = todos)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 60, 'default' => 9 ] );
		$this->add_control( 'search', [ 'label' => __( 'Mostrar buscador', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'filters', [ 'label' => __( 'Botones Ofertas / Candidatos', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'region', [ 'label' => __( 'Estado o provincia (datos para Google)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'description' => __( 'Para el JobPosting de Google Empleos, p. ej. FL.', 'wakoo' ) ] );
		$this->add_control( 'country', [ 'label' => __( 'País (código ISO, datos para Google)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'description' => __( 'p. ej. US', 'wakoo' ) ] );
		$this->end_controls_section();
		$this->texts_section();
		$this->style_section();
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$show  = $s['show'] ?? 'both';
		$max   = min( 200, max( 1, (int) ( $s['max'] ?? 60 ) ) );
		$items = array_merge( 'seeker' === $show ? [] : Board::query( Board::JOB, 'offer', $max ), 'offer' === $show ? [] : Board::query( Board::JOB, 'seeker', $max ) );
		usort( $items, function ( $a, $b ) { return $b['date'] <=> $a['date']; } ); // Newest first, offers and candidates together.
		$lab   = [];
		foreach ( array_keys( $this->texts() ) as $k ) {
			$lab[ $k ] = $this->t( $k );
		}
		echo '<div class="wk-m wk-m-dir wk-m-jobs" id="wakoo-jobs"' . $this->pages_attr( $s ) . '>';
		if ( ! $items ) {
			echo '<p class="wk-m-empty">' . esc_html( $this->t( 'empty' ) ) . '</p></div>';
			return;
		}
		$kinds = [];
		$cards = '';
		$ld    = [];
		foreach ( $items as $d ) {
			$offer = 'offer' === $d['kind'];
			$m     = $offer && $d['member'] ? Module::data( $d['member'] ) : null;
			$kinds[ $d['kind'] ] = true;
			$who   = $offer ? ( $m ? $m['name'] : '' ) : $d['name'];
			$meta  = array_filter( [ Board::job_type_label( $d['jobtype'], $lab ), $d['location'], $offer && $d['price'] ? $lab['salary'] . ': ' . $d['price'] : '', wp_date( get_option( 'date_format' ), $d['date'] ) ] );
			$text  = mb_strtolower( wp_strip_all_tags( $d['title'] . ' ' . $who . ' ' . $d['text'] . ' ' . $d['location'] ) );
			$links = $offer ? Board::contact_links( $d, [ 'apply' => $lab['apply'], 'email' => $lab['email'], 'call' => $lab['call'], 'profile' => $lab['profile'] ] )
				: Board::contact_links( $d, [ 'email' => $lab['contact'], 'call' => $lab['call'] ] ) . ( $d['file'] ? '<a class="wk-m-link" href="' . esc_url( wp_get_attachment_url( $d['file'] ) ) . '" target="_blank" rel="noopener">' . esc_html( $lab['cv'] ) . ' →</a>' : '' );
			if ( $d['demo'] ) { $links = Board::demo_link( $lab['demo_cta'] ); }
			$cards .= '<article class="wk-m-card wk-m-dir__item wk-m-job wk-m-job--' . esc_attr( $d['kind'] ) . '" data-cat="' . esc_attr( $d['kind'] ) . '" data-text="' . esc_attr( $text ) . '">'
				. '<div class="wk-m-item__head">' . ( $d['demo'] ? '<span class="wk-m-chip wk-m-chip--demo">' . esc_html( $lab['demo'] ) . '</span>' : '' ) . '<span class="wk-m-chip">' . esc_html( $lab[ $offer ? 'offer' : 'seeker' ] ) . '</span></div>'
				. '<h3 class="wk-m-card__title">' . esc_html( $d['title'] ) . '</h3>'
				. ( $who ? '<p class="wk-m-item__by">' . ( $m && $m['logo'] ? wp_get_attachment_image( $m['logo'], [ 28, 28 ], false, [ 'alt' => '' ] ) : '' ) . esc_html( $who ) . '</p>' : '' )
				. '<p class="wk-m-card__where">' . esc_html( implode( ' · ', $meta ) ) . '</p>'
				. '<details class="wk-m-job__more"><summary>' . esc_html( $lab['details'] ) . '</summary>' . wp_kses_post( wpautop( esc_html( $d['text'] ) ) ) . '</details>'
				. '<div class="wk-m-item__actions">' . $links . '</div></article>';
			if ( $offer && ! $d['demo'] ) { // Examples never go to Google Jobs.
				$ld[] = $this->job_posting( $d, $m, $s );
			}
		}
		$this->tools( $s, 'both' === $show ? $kinds : [], [ 'offer' => $lab['offers'], 'seeker' => $lab['seekers'] ] );
		echo '<div class="wk-m-dir__grid">' . $cards . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<p class="wk-m-empty wk-m-dir__none" hidden>' . esc_html( $this->t( 'none' ) ) . '</p>';
		$this->pager();
		echo '</div>';
		foreach ( $ld as $one ) {
			echo '<script type="application/ld+json">' . wp_json_encode( $one, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>';
		}
	}

	/** schema.org JobPosting for Google for Jobs. */
	private function job_posting( array $d, $m, array $s ) {
		$types = [ 'full' => 'FULL_TIME', 'part' => 'PART_TIME', 'contract' => 'CONTRACTOR' ];
		$job   = [
			'@context'       => 'https://schema.org',
			'@type'          => 'JobPosting',
			'title'          => $d['title'],
			'description'    => wpautop( esc_html( $d['text'] ) ),
			'datePosted'     => gmdate( 'Y-m-d', $d['date'] ),
			'employmentType' => $types[ $d['jobtype'] ] ?? 'FULL_TIME',
		];
		if ( $d['expires'] ) {
			$job['validThrough'] = $d['expires'] . 'T23:59:59';
		}
		if ( $m ) {
			$job['hiringOrganization'] = array_filter( [ '@type' => 'Organization', 'name' => $m['name'], 'sameAs' => $m['website'] ?: $m['url'], 'logo' => $m['logo'] ? wp_get_attachment_image_url( $m['logo'], 'full' ) : '' ] );
		}
		$addr = array_filter( [ '@type' => 'PostalAddress', 'addressLocality' => $d['location'], 'addressRegion' => (string) ( $s['region'] ?? '' ), 'addressCountry' => (string) ( $s['country'] ?? '' ) ] );
		if ( count( $addr ) > 1 ) {
			$job['jobLocation'] = [ '@type' => 'Place', 'address' => $addr ];
		}
		return $job;
	}
}
