<?php
/**
 * "Solicitud de membresía (Wakoo)": the public application form.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Members;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Apply_Widget extends Base {

	public function get_name() { return 'wakoo-member-apply'; }
	public function get_title() { return __( 'Solicitud de membresía (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-person'; }
	public function get_keywords() { return [ 'miembro', 'member', 'solicitud', 'registro', 'directorio', 'wakoo' ]; }

	protected function texts() {
		return [
			'name'        => [ __( 'Campo: negocio', 'wakoo' ), __( 'Nombre del negocio u organización', 'wakoo' ) ],
			'contact'     => [ __( 'Campo: contacto', 'wakoo' ), __( 'Persona de contacto', 'wakoo' ) ],
			'email'       => [ __( 'Campo: email', 'wakoo' ), __( 'Email', 'wakoo' ) ],
			'phone'       => [ __( 'Campo: teléfono', 'wakoo' ), __( 'Teléfono', 'wakoo' ) ],
			'website'     => [ __( 'Campo: web', 'wakoo' ), __( 'Web o red social', 'wakoo' ) ],
			'category'    => [ __( 'Campo: categoría', 'wakoo' ), __( 'Categoría', 'wakoo' ) ],
			'address'     => [ __( 'Campo: dirección', 'wakoo' ), __( 'Dirección', 'wakoo' ) ],
			'description' => [ __( 'Campo: descripción', 'wakoo' ), __( 'Cuéntanos qué ofreces', 'wakoo' ) ],
			'logo'        => [ __( 'Campo: logo', 'wakoo' ), __( 'Logo (opcional, JPG/PNG/WebP, máx. 5 MB)', 'wakoo' ) ],
			'consent'     => [ __( 'Casilla de privacidad', 'wakoo' ), __( 'Acepto la política de privacidad y que me contacten sobre mi solicitud.', 'wakoo' ) ],
			'button'      => [ __( 'Botón', 'wakoo' ), __( 'Enviar solicitud', 'wakoo' ) ],
			'required'    => [ __( 'Nota de obligatorios', 'wakoo' ), __( 'Los campos con * son obligatorios.', 'wakoo' ) ],
			'sent'        => [ __( 'Mensaje: enviada', 'wakoo' ), __( '¡Gracias! Hemos recibido tu solicitud. Te escribiremos por email cuando la revisemos.', 'wakoo' ) ],
			'invalid'     => [ __( 'Mensaje: faltan datos', 'wakoo' ), __( 'Revisa los campos obligatorios y vuelve a enviarla.', 'wakoo' ) ],
			'exists'      => [ __( 'Mensaje: ya es miembro', 'wakoo' ), __( 'Ese email ya tiene una membresía. Inicia sesión en tu cuenta.', 'wakoo' ) ],
			'limit'       => [ __( 'Mensaje: demasiados envíos', 'wakoo' ), __( 'Has enviado varias solicitudes seguidas. Inténtalo dentro de una hora.', 'wakoo' ) ],
			'error'       => [ __( 'Mensaje: error', 'wakoo' ), __( 'No se pudo enviar. Recarga la página e inténtalo de nuevo.', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_form', [ 'label' => __( 'Solicitud', 'wakoo' ) ] );
		$this->add_control( 'categories', [ 'label' => __( 'Categorías (una por línea)', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'description' => __( 'Vacío = las categorías de Miembros Wakoo.', 'wakoo' ) ] );
		$this->add_control( 'privacy_url', [ 'label' => __( 'Enlace a la política de privacidad', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$this->add_control( 'receipt_subject', [ 'label' => __( 'Email de acuse: asunto', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Hemos recibido tu solicitud', 'wakoo' ), 'label_block' => true ] );
		$this->add_control( 'receipt', [ 'label' => __( 'Email de acuse: texto', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'default' => __( 'Gracias por solicitar la membresía. Revisaremos tus datos y te responderemos por email.', 'wakoo' ), 'description' => __( 'Vacío = no se envía acuse.', 'wakoo' ) ] );
		$this->end_controls_section();
		$this->texts_section();
		$this->style_section();
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$key  = Module::register_form( [ 'receipt' => sanitize_textarea_field( $s['receipt'] ?? '' ), 'receipt_subject' => sanitize_text_field( $s['receipt_subject'] ?? '' ) ] );
		$cats = $this->categories( $s['categories'] ?? '' );
		$priv = ! empty( $s['privacy_url']['url'] ) ? $s['privacy_url']['url'] : '';
		$consent = esc_html( $this->t( 'consent' ) );
		if ( $priv ) {
			$consent = '<a href="' . esc_url( $priv ) . '" target="_blank" rel="noopener">' . $consent . '</a>';
		}
		echo '<div class="wk-m wk-m-apply" id="wakoo-member">';
		echo $this->notice( [ // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			'sent'    => [ 'ok', $this->t( 'sent' ) ],
			'invalid' => [ 'err', $this->t( 'invalid' ) ],
			'exists'  => [ 'err', $this->t( 'exists' ) ],
			'limit'   => [ 'err', $this->t( 'limit' ) ],
			'expired' => [ 'err', $this->t( 'error' ) ],
			'error'   => [ 'err', $this->t( 'error' ) ],
		] );
		echo '<form class="wk-m-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" enctype="multipart/form-data">';
		echo '<input type="hidden" name="action" value="wakoo_member_apply"><input type="hidden" name="back" value="' . esc_attr( $this->here() ) . '">';
		echo '<input type="hidden" name="wk_form" value="' . esc_attr( $key ) . '"><input type="hidden" name="wk_ts" value="' . (int) time() . '">';
		echo '<input type="hidden" name="_wknonce" value="' . esc_attr( wp_create_nonce( Module::NONCE ) ) . '">';
		echo '<div class="wk-m-hp" aria-hidden="true"><input type="text" name="wk_hp" tabindex="-1" autocomplete="off"></div>';
		echo '<div class="wk-m-grid">';
		echo $this->field( 'wk_name', $this->t( 'name' ), 'text', '', true, ' autocomplete="organization"' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $this->field( 'wk_contact', $this->t( 'contact' ), 'text', '', true, ' autocomplete="name"' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $this->field( 'wk_email', $this->t( 'email' ), 'email', '', true, ' autocomplete="email"' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $this->field( 'wk_phone', $this->t( 'phone' ), 'tel', '', false, ' autocomplete="tel"' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $cats ? $this->select( 'wk_category', $this->t( 'category' ), $cats, '', true ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $this->field( 'wk_website', $this->t( 'website' ), 'url', '', false, ' placeholder="https://"' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<div class="wk-m-wide">' . $this->field( 'wk_address', $this->t( 'address' ), 'text', '', true, ' autocomplete="street-address"' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<div class="wk-m-wide">' . $this->field( 'wk_description', $this->t( 'description' ), 'textarea', '', true, ' maxlength="3000"' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<div class="wk-m-wide">' . $this->field( 'wk_logo', $this->t( 'logo' ), 'file', '', false, ' accept="image/jpeg,image/png,image/webp"' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '</div>';
		echo '<label class="wk-m-check"><input type="checkbox" name="wk_consent" value="1" required> <span>' . $consent . '</span></label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<p class="wk-m-note">' . esc_html( $this->t( 'required' ) ) . '</p>';
		echo '<button type="submit" class="wk-m-btn">' . esc_html( $this->t( 'button' ) ) . '</button>';
		echo '</form></div>';
	}
}
