<?php
/**
 * "Microperfil (Wakoo)": the public page of one member — logo, name,
 * category, description, gallery with lightbox, Google Maps (loaded only
 * when the visitor asks) and contact details.
 *
 * Shows the profile being viewed; in the editor (or anywhere else) it shows
 * the member picked in "Miembro de ejemplo", or the latest one.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Members;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Profile_Widget extends Base {

	public function get_name() { return 'wakoo-member-profile'; }
	public function get_title() { return __( 'Microperfil (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-single-page'; }
	public function get_keywords() { return [ 'miembro', 'member', 'perfil', 'negocio', 'mapa', 'wakoo' ]; }
	public function get_style_depends() { return [ 'wakoo-members', 'wakoo-gallery' ]; }
	public function get_script_depends() { return [ 'wakoo-members', 'wakoo-gallery' ]; }

	protected function texts() {
		return [
			'about'   => [ __( 'Título: descripción', 'wakoo' ), __( 'Sobre nosotros', 'wakoo' ) ],
			'gallery' => [ __( 'Título: galería', 'wakoo' ), __( 'Galería', 'wakoo' ) ],
			'where'   => [ __( 'Título: ubicación', 'wakoo' ), __( 'Ubicación', 'wakoo' ) ],
			'contact' => [ __( 'Título: contacto', 'wakoo' ), __( 'Contacto', 'wakoo' ) ],
			'open'    => [ __( 'Enlace: abrir en Google Maps', 'wakoo' ), __( 'Ver en Google Maps', 'wakoo' ) ],
			'website' => [ __( 'Enlace: web', 'wakoo' ), __( 'Visitar la web', 'wakoo' ) ],
			'back'    => [ __( 'Enlace: volver', 'wakoo' ), __( '← Volver al directorio', 'wakoo' ) ],
			'missing' => [ __( 'Sin miembro que mostrar', 'wakoo' ), __( 'Aquí se verá el perfil del miembro.', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_profile', [ 'label' => __( 'Microperfil', 'wakoo' ) ] );
		$this->add_control( 'member', [ 'label' => __( 'Miembro de ejemplo (ID)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'description' => __( 'Solo para el editor y páginas que no son un perfil. En un perfil se muestra ese miembro.', 'wakoo' ) ] );
		$this->add_control( 'back_url', [ 'label' => __( 'Enlace «Volver al directorio»', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$this->end_controls_section();
		$this->texts_section();
		$this->style_section();
	}

	private function current() {
		if ( is_singular( Module::CPT ) ) {
			return get_queried_object_id();
		}
		$pick = (int) $this->get_settings_for_display( 'member' );
		if ( $pick && Module::CPT === get_post_type( $pick ) ) {
			return $pick;
		}
		$q = get_posts( [ 'post_type' => Module::CPT, 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids' ] );
		return $q ? (int) $q[0] : 0;
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$d = Module::data( $this->current() );
		echo '<div class="wk-m wk-m-profile">';
		if ( ! $d ) {
			echo '<p class="wk-m-empty">' . esc_html( $this->t( 'missing' ) ) . '</p></div>';
			return;
		}
		if ( ! empty( $s['back_url']['url'] ) ) {
			echo '<a class="wk-m-link wk-m-back" href="' . esc_url( $s['back_url']['url'] ) . '">' . esc_html( $this->t( 'back' ) ) . '</a>';
		}
		echo '<header class="wk-m-card wk-m-profile__head">';
		echo $d['logo'] ? wp_get_attachment_image( $d['logo'], 'medium', false, [ 'class' => 'wk-m-profile__logo', 'alt' => $d['name'] ] ) : '<span class="wk-m-profile__logo wk-m-card__logo--empty" aria-hidden="true">' . esc_html( mb_substr( $d['name'], 0, 1 ) ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<div class="wk-m-profile__id">' . ( $d['category'] ? '<span class="wk-m-chip">' . esc_html( $d['category'] ) . '</span>' : '' );
		echo '<h1 class="wk-m-profile__name">' . esc_html( $d['name'] ) . '</h1>';
		echo $d['tagline'] ? '<p class="wk-m-profile__tagline">' . esc_html( $d['tagline'] ) . '</p>' : '';
		echo '</div>';
		if ( $d['website'] ) {
			echo '<a class="wk-m-btn" href="' . esc_url( $d['website'] ) . '" target="_blank" rel="noopener">' . esc_html( $this->t( 'website' ) ) . '</a>';
		}
		echo '</header><div class="wk-m-profile__cols"><div class="wk-m-profile__main">';
		if ( $d['description'] ) {
			echo '<section class="wk-m-card"><h2>' . esc_html( $this->t( 'about' ) ) . '</h2>' . wp_kses_post( wpautop( $d['description'] ) ) . '</section>';
		}
		if ( $d['gallery'] ) {
			$gid = 'wkm-' . $d['id'];
			echo '<section class="wk-m-card"><h2>' . esc_html( $this->t( 'gallery' ) ) . '</h2><div class="wakoo-gallery wk-m-gallery" data-lightbox="yes">';
			foreach ( $d['gallery'] as $aid ) {
				$full = wp_get_attachment_image_url( $aid, 'large' );
				if ( $full ) {
					echo '<a class="wakoo-glightbox wk-m-gallery__item" href="' . esc_url( $full ) . '" data-gallery="' . esc_attr( $gid ) . '" data-type="image">' . wp_get_attachment_image( $aid, 'medium_large', false, [ 'loading' => 'lazy', 'alt' => $d['name'] ] ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
			}
			echo '</div></section>';
		}
		echo '</div><aside class="wk-m-profile__side">';
		$rows = [];
		if ( $d['phone'] ) { $rows[] = '<li><span class="wk-m-ico" aria-hidden="true">☎</span><a href="tel:' . esc_attr( preg_replace( '/[^0-9+]/', '', $d['phone'] ) ) . '">' . esc_html( $d['phone'] ) . '</a></li>'; }
		if ( $d['email'] ) { $rows[] = '<li><span class="wk-m-ico" aria-hidden="true">✉</span><a href="mailto:' . esc_attr( antispambot( $d['email'] ) ) . '">' . esc_html( antispambot( $d['email'] ) ) . '</a></li>'; }
		if ( $d['website'] ) { $rows[] = '<li><span class="wk-m-ico" aria-hidden="true">↗</span><a href="' . esc_url( $d['website'] ) . '" target="_blank" rel="noopener">' . esc_html( preg_replace( '#^https?://(www\.)?#', '', untrailingslashit( $d['website'] ) ) ) . '</a></li>'; }
		if ( $d['facebook'] ) { $rows[] = '<li><span class="wk-m-ico" aria-hidden="true">f</span><a href="' . esc_url( $d['facebook'] ) . '" target="_blank" rel="noopener">Facebook</a></li>'; }
		if ( $d['instagram'] ) { $rows[] = '<li><span class="wk-m-ico" aria-hidden="true">◎</span><a href="' . esc_url( $d['instagram'] ) . '" target="_blank" rel="noopener">Instagram</a></li>'; }
		if ( $rows ) {
			echo '<section class="wk-m-card"><h2>' . esc_html( $this->t( 'contact' ) ) . '</h2><ul class="wk-m-contact">' . implode( '', $rows ) . '</ul></section>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		if ( $d['address'] ) {
			// The map itself is Elementor's own Google Maps widget in the profile template (dynamic tag «Dato del miembro → Dirección»).
			echo '<section class="wk-m-card"><h2>' . esc_html( $this->t( 'where' ) ) . '</h2><p class="wk-m-profile__address">' . esc_html( $d['address'] ) . '</p>';
			echo '<a class="wk-m-link" href="' . esc_url( Module::maps_link( $d['address'] ) ) . '" target="_blank" rel="noopener">' . esc_html( $this->t( 'open' ) ) . ' →</a></section>';
		}
		echo '</aside></div></div>';
	}
}
