<?php
/**
 * "Dato del miembro" dynamic tag: any member field inside Elementor's own
 * widgets. Its main use is Elementor's native Google Maps widget (Location →
 * Dynamic → Dato del miembro → Dirección) in the profile template, so Wakoo
 * does not ship a map of its own. Also usable in headings, text, buttons…
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Members;

use Elementor\Core\DynamicTags\Tag;
use Elementor\Controls_Manager;
use Elementor\Modules\DynamicTags\Module as Tags;

defined( 'ABSPATH' ) || die();

class Member_Field_Tag extends Tag {

	public function get_name() { return 'wakoo-member-field'; }
	public function get_title() { return __( 'Dato del miembro', 'wakoo' ); }
	public function get_group() { return 'wakoo'; }
	public function get_categories() { return [ Tags::TEXT_CATEGORY, Tags::POST_META_CATEGORY ]; }

	protected function register_controls() {
		$this->add_control( 'field', [
			'label'   => __( 'Dato', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'address',
			'options' => [
				'name'      => __( 'Nombre', 'wakoo' ),
				'tagline'   => __( 'Lema', 'wakoo' ),
				'category'  => __( 'Categoría', 'wakoo' ),
				'address'   => __( 'Dirección', 'wakoo' ),
				'phone'     => __( 'Teléfono', 'wakoo' ),
				'email'     => __( 'Email público', 'wakoo' ),
				'website'   => __( 'Web', 'wakoo' ),
				'contact'   => __( 'Persona de contacto', 'wakoo' ),
			],
		] );
	}

	/** The profile being viewed; in the editor (or elsewhere) the latest approved member, as the Microperfil widget does. */
	public static function current_member() {
		if ( is_singular( Module::CPT ) ) {
			return get_queried_object_id();
		}
		$q = get_posts( [ 'post_type' => Module::CPT, 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids' ] );
		return $q ? (int) $q[0] : 0;
	}

	public function render() {
		$d = Module::data( self::current_member() );
		$f = (string) $this->get_settings( 'field' );
		echo $d && isset( $d[ $f ] ) ? esc_html( (string) $d[ $f ] ) : '';
	}
}
