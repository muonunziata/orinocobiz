<?php
/**
 * Wakoo Miembros: private chat between the site team and each member.
 *
 * One conversation per member profile. Messages are comments of type
 * `wakoo_msg` on the profile (no extra tables, works on any database),
 * hidden from every normal comment list, count and feed. `wk_from` meta says
 * who wrote it (admin / member); an optional image or PDF is an attachment.
 * Each side's "last seen" message id lives on the profile, which gives the
 * unread counts. The browser polls the REST API (every few seconds while the
 * chat is open); the other side gets an email at most every 15 minutes per
 * conversation.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Members;

defined( 'ABSPATH' ) || die();

class Chat {

	const TYPE     = 'wakoo_msg';
	const MAX_LEN  = 4000;
	const PER_MIN  = 20;     // Messages a user may send per minute.
	const MAIL_GAP = 900;    // Seconds between email alerts per conversation and side.

	public static function init() {
		add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
		add_action( 'pre_get_comments', [ __CLASS__, 'hide' ] );
		add_filter( 'wp_count_comments', [ __CLASS__, 'count_comments' ], 20, 2 );
		add_filter( 'comment_feed_where', [ __CLASS__, 'feed_where' ] );
	}

	/* ---------------------------------------------------------------- keep chat out of normal comments */

	private static function is_chat_query( $q ) {
		$t = (array) ( $q->query_vars['type'] ?? '' );
		return in_array( self::TYPE, $t, true );
	}

	public static function hide( $q ) {
		if ( ! self::is_chat_query( $q ) ) {
			$not   = (array) ( $q->query_vars['type__not_in'] ?? [] );
			$not[] = self::TYPE;
			$q->query_vars['type__not_in'] = array_unique( $not );
		}
	}

	/** Dashboard and Comments screen totals without the chat messages. */
	public static function count_comments( $stats, $post_id ) {
		if ( $post_id || ! empty( $stats->wakoo_chat_free ) ) {
			return $stats;
		}
		global $wpdb;
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT comment_approved, COUNT(*) AS n FROM {$wpdb->comments} WHERE comment_type != %s GROUP BY comment_approved", self::TYPE ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$out   = [ 'moderated' => 0, 'approved' => 0, 'spam' => 0, 'trash' => 0, 'post-trashed' => 0, 'total_comments' => 0, 'all' => 0 ];
		$map   = [ '0' => 'moderated', '1' => 'approved', 'spam' => 'spam', 'trash' => 'trash', 'post-trashed' => 'post-trashed' ];
		foreach ( (array) $rows as $r ) {
			$k = $map[ $r['comment_approved'] ] ?? null;
			if ( ! $k ) {
				continue;
			}
			$out[ $k ] = (int) $r['n'];
			if ( ! in_array( $k, [ 'spam', 'trash', 'post-trashed' ], true ) ) {
				$out['total_comments'] += (int) $r['n'];
				$out['all']            += (int) $r['n'];
			}
		}
		$o = (object) $out;
		$o->wakoo_chat_free = true;
		return $o;
	}

	public static function feed_where( $where ) {
		global $wpdb;
		return $where . $wpdb->prepare( ' AND comment_type != %s', self::TYPE );
	}

	/* ---------------------------------------------------------------- data */

	/** Messages of a conversation, oldest first; only those with id > $after. */
	public static function messages( $pid, $after = 0, $limit = 200 ) {
		$args = [ 'post_id' => (int) $pid, 'type' => self::TYPE, 'status' => 'approve', 'orderby' => 'comment_ID', 'order' => 'DESC', 'number' => $limit, 'no_found_rows' => true, 'update_comment_meta_cache' => true ];
		$list = get_comments( $args );
		$out  = [];
		foreach ( array_reverse( $list ) as $c ) {
			if ( (int) $c->comment_ID <= (int) $after ) {
				continue;
			}
			$aid   = (int) get_comment_meta( $c->comment_ID, 'wk_file', true );
			$file  = null;
			if ( $aid && get_post( $aid ) ) {
				$is_img = wp_attachment_is_image( $aid );
				$file   = [ 'url' => wp_get_attachment_url( $aid ), 'name' => get_the_title( $aid ), 'img' => $is_img ? wp_get_attachment_image_url( $aid, 'medium' ) : '' ];
			}
			$out[] = [
				'id'   => (int) $c->comment_ID,
				'from' => get_comment_meta( $c->comment_ID, 'wk_from', true ) === 'admin' ? 'admin' : 'member',
				'name' => $c->comment_author,
				'text' => $c->comment_content,
				'time' => mysql_to_rfc3339( $c->comment_date_gmt ),
				'file' => $file,
			];
		}
		return $out;
	}

	public static function last_id( $pid ) {
		$c = get_comments( [ 'post_id' => (int) $pid, 'type' => self::TYPE, 'number' => 1, 'orderby' => 'comment_ID', 'order' => 'DESC', 'fields' => 'ids', 'no_found_rows' => true ] );
		return $c ? (int) $c[0] : 0;
	}

	/** Messages written by the other side that $side has not seen yet. */
	public static function unread( $pid, $side ) {
		$seen  = (int) get_post_meta( $pid, '_wk_chat_seen_' . $side, true );
		$other = 'admin' === $side ? 'member' : 'admin';
		$ids   = get_comments( [ 'post_id' => (int) $pid, 'type' => self::TYPE, 'fields' => 'ids', 'no_found_rows' => true, 'meta_key' => 'wk_from', 'meta_value' => $other ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
		return count( array_filter( (array) $ids, function ( $id ) use ( $seen ) { return (int) $id > $seen; } ) );
	}

	/** Unread messages from members, over all conversations (for the admin menu bubble). */
	public static function admin_unread_total() {
		$total = 0;
		foreach ( self::conversations() as $c ) {
			$total += $c['unread'];
		}
		return $total;
	}

	/** Profiles with at least one message, newest activity first. */
	public static function conversations() {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT comment_post_ID AS pid, MAX(comment_ID) AS last FROM {$wpdb->comments} WHERE comment_type = %s AND comment_approved = '1' GROUP BY comment_post_ID ORDER BY last DESC LIMIT 300", self::TYPE ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$out  = [];
		foreach ( (array) $rows as $r ) {
			$c = get_comment( (int) $r['last'] );
			if ( ! $c || ! get_post( (int) $r['pid'] ) ) {
				continue;
			}
			$out[] = [ 'pid' => (int) $r['pid'], 'last' => $c, 'unread' => self::unread( (int) $r['pid'], 'admin' ) ];
		}
		return $out;
	}

	public static function mark_seen( $pid, $side, $id ) {
		if ( $id > (int) get_post_meta( $pid, '_wk_chat_seen_' . $side, true ) ) {
			update_post_meta( $pid, '_wk_chat_seen_' . $side, (int) $id );
		}
	}

	/** Adds a message; returns its id or WP_Error. */
	public static function add( $pid, $side, $text, $file_field = '' ) {
		$text = trim( sanitize_textarea_field( (string) $text ) );
		if ( mb_strlen( $text ) > self::MAX_LEN ) {
			$text = mb_substr( $text, 0, self::MAX_LEN );
		}
		$aid = 0;
		if ( $file_field ) {
			$aid = self::upload( $file_field, $pid );
			if ( is_wp_error( $aid ) ) {
				return $aid;
			}
		}
		if ( '' === $text && ! $aid ) {
			return new \WP_Error( 'empty', __( 'Escribe un mensaje.', 'wakoo' ) );
		}
		$u   = wp_get_current_user();
		$cid = wp_insert_comment( [
			'comment_post_ID'  => (int) $pid,
			'comment_type'     => self::TYPE,
			'comment_content'  => $text,
			'comment_approved' => 1,
			'user_id'          => $u->ID,
			'comment_author'   => 'admin' === $side ? get_bloginfo( 'name' ) : ( $u->display_name ?: $u->user_login ),
			'comment_author_email' => $u->user_email,
		] );
		if ( ! $cid ) {
			return new \WP_Error( 'save', __( 'No se pudo guardar el mensaje.', 'wakoo' ) );
		}
		add_comment_meta( $cid, 'wk_from', $side );
		if ( $aid ) {
			add_comment_meta( $cid, 'wk_file', $aid );
		}
		self::mark_seen( $pid, $side, $cid );
		self::notify( $pid, $side, $text );
		return (int) $cid;
	}

	/** Image (JPG/PNG/WebP/GIF) or PDF up to 5 MB, stored as an attachment of the profile. */
	private static function upload( $field, $pid ) {
		// phpcs:disable WordPress.Security.ValidatedSanitizedInput, WordPress.Security.NonceVerification -- REST nonce checked by core.
		if ( empty( $_FILES[ $field ]['name'] ) || UPLOAD_ERR_NO_FILE === (int) ( $_FILES[ $field ]['error'] ?? 4 ) ) {
			return 0;
		}
		$f = $_FILES[ $field ];
		// phpcs:enable
		if ( UPLOAD_ERR_OK !== (int) $f['error'] || $f['size'] > Module::MAX_IMG ) {
			return new \WP_Error( 'upload', __( 'El archivo no se pudo subir (máximo 5 MB).', 'wakoo' ) );
		}
		$mimes = [ 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'gif' => 'image/gif', 'pdf' => 'application/pdf' ];
		$check = wp_check_filetype_and_ext( $f['tmp_name'], $f['name'], $mimes );
		if ( empty( $check['type'] ) ) {
			return new \WP_Error( 'type', __( 'Solo se aceptan imágenes o PDF.', 'wakoo' ) );
		}
		if ( 0 === strpos( $check['type'], 'image/' ) && ! @getimagesize( $f['tmp_name'] ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return new \WP_Error( 'type', __( 'La imagen no es válida.', 'wakoo' ) );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$moved = wp_handle_upload( $f, [ 'test_form' => false, 'mimes' => $mimes ] );
		if ( isset( $moved['error'] ) ) {
			return new \WP_Error( 'upload', $moved['error'] );
		}
		$aid = wp_insert_attachment( [ 'post_mime_type' => $moved['type'], 'post_title' => sanitize_file_name( $f['name'] ), 'post_status' => 'inherit' ], $moved['file'], $pid );
		if ( is_wp_error( $aid ) ) {
			return $aid;
		}
		wp_update_attachment_metadata( $aid, wp_generate_attachment_metadata( $aid, $moved['file'] ) );
		update_post_meta( $aid, '_wk_chat_file', 1 ); // Never offered as a gallery image.
		return (int) $aid;
	}

	/** Email the other side, at most once every MAIL_GAP per conversation. */
	private static function notify( $pid, $side, $text ) {
		$to_side = 'admin' === $side ? 'member' : 'admin';
		$key     = '_wk_chat_mailed_' . $to_side;
		if ( time() - (int) get_post_meta( $pid, $key, true ) < self::MAIL_GAP ) {
			return;
		}
		$s    = Module::settings();
		$name = get_the_title( $pid );
		if ( 'admin' === $to_side ) {
			$to   = $s['notify'];
			$link = admin_url( 'admin.php?page=' . Module::MENU . '-chat&member=' . (int) $pid );
			/* translators: %s: member name */
			$subject = sprintf( __( 'Nuevo mensaje de %s', 'wakoo' ), $name );
		} else {
			$owner = get_userdata( (int) get_post_field( 'post_author', $pid ) );
			$to    = $owner ? $owner->user_email : '';
			$link  = $s['account'] ? get_permalink( $s['account'] ) . '#wakoo-chat' : home_url( '/' );
			/* translators: %s: site name */
			$subject = sprintf( __( 'Tienes un mensaje de %s · New message', 'wakoo' ), get_bloginfo( 'name' ) );
		}
		if ( ! is_email( $to ) ) {
			return;
		}
		update_post_meta( $pid, $key, time() );
		wp_mail( $to, $subject, wp_trim_words( $text, 40, '…' ) . "\n\n" . $link );
	}

	/* ---------------------------------------------------------------- REST */

	public static function routes() {
		register_rest_route( 'wakoo/v1', '/chat', [
			[ 'methods' => 'GET', 'callback' => [ __CLASS__, 'rest_get' ], 'permission_callback' => [ __CLASS__, 'can' ] ],
			[ 'methods' => 'POST', 'callback' => [ __CLASS__, 'rest_post' ], 'permission_callback' => [ __CLASS__, 'can' ] ],
		] );
	}

	/** Which side the current user speaks for in conversation $pid, or ''. */
	public static function side_for( $pid ) {
		if ( Module::CPT !== get_post_type( $pid ) ) {
			return '';
		}
		if ( current_user_can( 'manage_options' ) ) {
			return 'admin';
		}
		$own = Module::profile_of( get_current_user_id() );
		return ( $own && $own === (int) $pid && 'publish' === get_post_status( $pid ) ) ? 'member' : '';
	}

	public static function can( \WP_REST_Request $r ) {
		return is_user_logged_in() && '' !== self::side_for( (int) $r->get_param( 'member' ) );
	}

	public static function rest_get( \WP_REST_Request $r ) {
		$pid  = (int) $r->get_param( 'member' );
		$side = self::side_for( $pid );
		$msgs = self::messages( $pid, (int) $r->get_param( 'after' ) );
		if ( $msgs ) {
			self::mark_seen( $pid, $side, end( $msgs )['id'] );
		}
		return new \WP_REST_Response( [ 'messages' => $msgs, 'me' => $side ] );
	}

	public static function rest_post( \WP_REST_Request $r ) {
		$pid  = (int) $r->get_param( 'member' );
		$side = self::side_for( $pid );
		$key  = 'wk_chat_rate_' . get_current_user_id();
		$sent = (int) get_transient( $key );
		if ( $sent >= self::PER_MIN ) {
			return new \WP_Error( 'rate', __( 'Demasiados mensajes seguidos. Espera un minuto.', 'wakoo' ), [ 'status' => 429 ] );
		}
		set_transient( $key, $sent + 1, MINUTE_IN_SECONDS );
		$id = self::add( $pid, $side, (string) $r->get_param( 'text' ), ! empty( $_FILES['file'] ) ? 'file' : '' ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( is_wp_error( $id ) ) {
			return new \WP_Error( $id->get_error_code(), $id->get_error_message(), [ 'status' => 400 ] );
		}
		return new \WP_REST_Response( [ 'messages' => self::messages( $pid, (int) $r->get_param( 'after' ) ), 'me' => $side ] );
	}

	/* ---------------------------------------------------------------- UI shell shared by admin and front end */

	/** Markup the chat script fills in. $labels: texts shown in the browser. */
	public static function box( $pid, $side, array $labels, $title = '' ) {
		wp_enqueue_script( 'wakoo-members-chat' );
		wp_enqueue_style( 'wakoo-members-chat' );
		$cfg = [
			'api'    => esc_url_raw( rest_url( 'wakoo/v1/chat' ) ),
			'nonce'  => wp_create_nonce( 'wp_rest' ),
			'member' => (int) $pid,
			'me'     => $side,
			'labels' => $labels,
		];
		$out  = '<div class="wk-chat" id="wakoo-chat" data-config="' . esc_attr( wp_json_encode( $cfg ) ) . '">';
		$out .= $title ? '<div class="wk-chat__head">' . esc_html( $title ) . '</div>' : '';
		$out .= '<div class="wk-chat__list" role="log" aria-live="polite" aria-label="' . esc_attr( $labels['log'] ?? '' ) . '"><p class="wk-chat__empty">' . esc_html( $labels['loading'] ?? '' ) . '</p></div>';
		$out .= '<form class="wk-chat__form"><label class="screen-reader-text wk-sr" for="wk-chat-text-' . (int) $pid . '">' . esc_html( $labels['placeholder'] ?? '' ) . '</label>';
		$out .= '<textarea id="wk-chat-text-' . (int) $pid . '" rows="2" maxlength="' . self::MAX_LEN . '" placeholder="' . esc_attr( $labels['placeholder'] ?? '' ) . '"></textarea>';
		$out .= '<div class="wk-chat__actions"><label class="wk-chat__attach" title="' . esc_attr( $labels['attach'] ?? '' ) . '"><input type="file" accept="image/jpeg,image/png,image/webp,image/gif,application/pdf"><span aria-hidden="true">📎</span><span class="wk-sr">' . esc_html( $labels['attach'] ?? '' ) . '</span></label>';
		$out .= '<span class="wk-chat__file"></span><button type="submit" class="wk-chat__send">' . esc_html( $labels['send'] ?? '' ) . '</button></div>';
		$out .= '<p class="wk-chat__error" role="alert" hidden></p></form></div>';
		return $out;
	}

	/** Browser texts in the site language (the admin side; the member side takes them from the widget). */
	public static function admin_labels() {
		return [
			'loading'     => __( 'Cargando mensajes…', 'wakoo' ),
			'empty'       => __( 'Aún no hay mensajes. Escribe el primero.', 'wakoo' ),
			'placeholder' => __( 'Escribe un mensaje…', 'wakoo' ),
			'send'        => __( 'Enviar', 'wakoo' ),
			'attach'      => __( 'Adjuntar imagen o PDF', 'wakoo' ),
			'error'       => __( 'No se pudo enviar. Inténtalo de nuevo.', 'wakoo' ),
			'admin'       => get_bloginfo( 'name' ),
			'member'      => __( 'Miembro', 'wakoo' ),
			'log'         => __( 'Conversación', 'wakoo' ),
		];
	}

	public static function register_assets() {
		wp_register_script( 'wakoo-members-chat', WAKOO_MODULES_URL . 'members/assets/chat.js', [], WAKOO_VERSION, true );
		wp_register_style( 'wakoo-members-chat', WAKOO_MODULES_URL . 'members/assets/chat.css', [], WAKOO_VERSION );
	}
}
