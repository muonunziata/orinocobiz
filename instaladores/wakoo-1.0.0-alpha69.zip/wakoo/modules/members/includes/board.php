<?php
/**
 * Wakoo Miembros: marketplace and job board fed by the members themselves.
 *
 * - `wakoo_listing`: products and services a member publishes from "Mi cuenta"
 *   (photo, price, category). Live at once, expire after LISTING_DAYS.
 * - `wakoo_job`: job offers (kind "offer", published by members, expire after
 *   JOB_DAYS) and job seekers (kind "seeker", sent by anyone with the
 *   «Busco trabajo» widget, shown only after the team approves them).
 * Nobody pays or negotiates through the site: cards link to the member profile
 * or to the contact the author chose. A daily job takes expired items offline.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Members;

defined( 'ABSPATH' ) || die();

class Board {

	const LISTING      = 'wakoo_listing';
	const JOB          = 'wakoo_job';
	const MAX_PHOTOS   = 6; // Marketplace: main photo + 5 more.
	const LISTING_DAYS = 90;
	const JOB_DAYS     = 30;
	const MAX_LISTINGS = 20;  // Per member.
	const MAX_JOBS     = 10;  // Per member.
	const TYPES        = [ 'full', 'part', 'contract' ];

	public static function init() {
		add_action( 'init', [ __CLASS__, 'register' ] );
		add_action( 'admin_post_wakoo_board_save', [ __CLASS__, 'save' ] );
		add_action( 'admin_post_wakoo_board_delete', [ __CLASS__, 'delete' ] );
		add_action( 'admin_post_nopriv_wakoo_job_seeker', [ __CLASS__, 'seeker' ] );
		add_action( 'admin_post_wakoo_job_seeker', [ __CLASS__, 'seeker' ] );
		add_action( 'wakoo_board_expire', [ __CLASS__, 'expire' ] );
		add_action( 'init', [ __CLASS__, 'schedule' ], 30 );
	}

	public static function register() {
		$common = [ 'public' => false, 'show_ui' => true, 'show_in_menu' => Module::MENU, 'capability_type' => 'post', 'map_meta_cap' => true, 'rewrite' => false, 'query_var' => false ];
		register_post_type( self::LISTING, $common + [
			'labels'   => [ 'name' => __( 'Marketplace', 'wakoo' ), 'singular_name' => __( 'Anuncio del marketplace', 'wakoo' ), 'all_items' => __( 'Marketplace', 'wakoo' ), 'edit_item' => __( 'Editar anuncio', 'wakoo' ) ],
			'supports' => [ 'title', 'editor', 'thumbnail', 'author' ],
		] );
		register_post_type( self::JOB, $common + [
			'labels'   => [ 'name' => __( 'Empleo', 'wakoo' ), 'singular_name' => __( 'Oferta o candidatura', 'wakoo' ), 'all_items' => __( 'Empleo', 'wakoo' ), 'edit_item' => __( 'Editar oferta o candidatura', 'wakoo' ) ],
			'supports' => [ 'title', 'editor', 'author' ],
		] );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( 'wakoo_board_expire' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'wakoo_board_expire' );
		}
	}

	/* ---------------------------------------------------------------- data */

	public static function item( $id ) {
		$p = get_post( $id );
		if ( ! $p || ! in_array( $p->post_type, [ self::LISTING, self::JOB ], true ) ) {
			return null;
		}
		$m = function ( $k ) use ( $id ) { return (string) get_post_meta( $id, '_wk_b_' . $k, true ); };
		$d = [
			'id' => $p->ID, 'type' => $p->post_type, 'title' => get_the_title( $p ), 'text' => $p->post_content, 'status' => $p->post_status,
			'date' => get_post_time( 'U', true, $p ), 'expires' => $m( 'expires' ), 'member' => (int) $m( 'member' ),
			'price' => $m( 'price' ), 'category' => $m( 'category' ), 'kind' => $m( 'kind' ), 'jobtype' => $m( 'jobtype' ),
			'location' => $m( 'location' ), 'email' => $m( 'email' ), 'phone' => $m( 'phone' ), 'url' => $m( 'url' ), 'name' => $m( 'name' ),
			'image' => (int) get_post_thumbnail_id( $p ), 'file' => (int) $m( 'file' ),
			// Example listings (packs, demos): shown with an "Example" label and an invitation to publish, never as real offers.
			'demo'  => '1' === $m( 'demo' ),
		];
		// Main photo first, then the gallery; without a featured image the first gallery photo is the main one.
		$d['gallery'] = array_slice( array_values( array_unique( array_filter( array_merge( [ $d['image'] ], self::gallery( $id ) ) ) ) ), 0, self::MAX_PHOTOS );
		$d['image']   = $d['gallery'] ? $d['gallery'][0] : 0;
		return $d;
	}

	/** Listing photos: attachment ids (members' uploads) or { id, url } rows (packs). */
	private static function gallery( $id ) {
		$raw = get_post_meta( $id, '_wk_b_gallery', true );
		$ids = [];
		foreach ( is_array( $raw ) ? $raw : explode( ',', (string) $raw ) as $g ) {
			$aid = (int) ( is_array( $g ) ? ( $g['id'] ?? 0 ) : $g );
			if ( $aid && wp_attachment_is_image( $aid ) ) { $ids[] = $aid; }
		}
		return $ids;
	}

	/** Published items of one type (and kind), newest first. */
	public static function query( $type, $kind = '', $limit = 60, $member = 0 ) {
		$args = [ 'post_type' => $type, 'post_status' => 'publish', 'posts_per_page' => $limit, 'orderby' => 'date', 'order' => 'DESC', 'fields' => 'ids' ];
		$meta = [];
		if ( $kind ) {
			$meta[] = [ 'key' => '_wk_b_kind', 'value' => $kind ];
		}
		if ( $member ) {
			$meta[] = [ 'key' => '_wk_b_member', 'value' => (int) $member ];
		}
		if ( $meta ) {
			$args['meta_query'] = $meta; // phpcs:ignore WordPress.DB.SlowDBQuery
		}
		return array_filter( array_map( [ __CLASS__, 'item' ], get_posts( $args ) ) );
	}

	/** Items of the current member (any status) for "Mi cuenta". */
	public static function mine( $type ) {
		$ids = get_posts( [ 'post_type' => $type, 'post_status' => [ 'publish', 'draft', 'pending' ], 'author' => get_current_user_id(), 'posts_per_page' => 50, 'fields' => 'ids', 'orderby' => 'date', 'order' => 'DESC' ] );
		return array_filter( array_map( [ __CLASS__, 'item' ], $ids ) );
	}

	/** Takes expired listings and job offers offline (the author can publish them again). */
	public static function expire() {
		$today = current_time( 'Y-m-d' );
		$ids   = get_posts( [ 'post_type' => [ self::LISTING, self::JOB ], 'post_status' => 'publish', 'posts_per_page' => 500, 'fields' => 'ids', 'meta_query' => [ [ 'key' => '_wk_b_expires', 'value' => $today, 'compare' => '<', 'type' => 'DATE' ] ] ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
		foreach ( $ids as $id ) {
			wp_update_post( [ 'ID' => $id, 'post_status' => 'draft' ] );
			update_post_meta( $id, '_wk_b_expired', $today );
		}
	}

	private static function back( $url, $st, $anchor = 'wakoo-board' ) {
		wp_safe_redirect( add_query_arg( 'wk_member', $st, remove_query_arg( [ 'wk_member', 'wk_err' ], $url ? $url : home_url( '/' ) ) ) . '#' . $anchor );
		exit;
	}

	/* ---------------------------------------------------------------- member: publish / delete */

	public static function save() {
		$back = isset( $_POST['back'] ) ? esc_url_raw( wp_unslash( $_POST['back'] ) ) : wp_get_referer();
		if ( ! isset( $_POST['_wknonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wknonce'] ) ), 'wakoo_board_save' ) ) {
			self::back( $back, 'expired' );
		}
		$profile = Module::profile_of( get_current_user_id() );
		if ( ! $profile || 'publish' !== get_post_status( $profile ) ) {
			self::back( $back, 'denied' );
		}
		$in   = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized below.
		$type = 'job' === ( $in['wk_type'] ?? '' ) ? self::JOB : self::LISTING;
		$max  = self::JOB === $type ? self::MAX_JOBS : self::MAX_LISTINGS;
		if ( count( self::mine( $type ) ) >= $max ) {
			self::back( $back, 'board_limit' );
		}
		$title = mb_substr( sanitize_text_field( $in['wk_title'] ?? '' ), 0, 120 );
		$text  = mb_substr( sanitize_textarea_field( $in['wk_text'] ?? '' ), 0, 3000 );
		if ( '' === $title || '' === $text ) {
			self::back( $back, 'board_invalid' );
		}
		$pid = wp_insert_post( [ 'post_type' => $type, 'post_status' => 'publish', 'post_title' => $title, 'post_content' => $text, 'post_author' => get_current_user_id() ], true );
		if ( is_wp_error( $pid ) ) {
			self::back( $back, 'error' );
		}
		$days = self::JOB === $type ? self::JOB_DAYS : self::LISTING_DAYS;
		$meta = [ 'member' => $profile, 'expires' => gmdate( 'Y-m-d', strtotime( current_time( 'Y-m-d' ) . ' +' . $days . ' days' ) ) ];
		if ( self::JOB === $type ) {
			$meta += [
				'kind'     => 'offer',
				'jobtype'  => in_array( $in['wk_jobtype'] ?? '', self::TYPES, true ) ? $in['wk_jobtype'] : 'full',
				'location' => sanitize_text_field( $in['wk_location'] ?? '' ),
				'email'    => sanitize_email( $in['wk_email'] ?? '' ),
				'url'      => esc_url_raw( $in['wk_url'] ?? '' ),
				'price'    => mb_substr( sanitize_text_field( $in['wk_price'] ?? '' ), 0, 60 ), // Salary.
			];
		} else {
			$meta += [
				'price'    => mb_substr( sanitize_text_field( $in['wk_price'] ?? '' ), 0, 60 ),
				'category' => sanitize_text_field( $in['wk_category'] ?? '' ),
			];
			$img = Module::upload_image( 'wk_image', $profile );
			if ( $img && ! is_wp_error( $img ) ) {
				wp_update_post( [ 'ID' => $img, 'post_parent' => $pid ] );
				set_post_thumbnail( $pid, $img );
			}
			$gal = [];
			for ( $i = 0; $i < self::MAX_PHOTOS - 1; $i++ ) {
				$g = Module::upload_image( 'wk_gallery', $profile, $i );
				if ( $g && ! is_wp_error( $g ) ) {
					wp_update_post( [ 'ID' => $g, 'post_parent' => $pid ] );
					$gal[] = $g;
				}
			}
			if ( $gal ) { $meta['gallery'] = $gal; }
		}
		foreach ( $meta as $k => $v ) {
			update_post_meta( $pid, '_wk_b_' . $k, $v );
		}
		self::back( $back, 'board_saved' );
	}

	public static function delete() {
		$back = isset( $_POST['back'] ) ? esc_url_raw( wp_unslash( $_POST['back'] ) ) : wp_get_referer();
		$id   = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		if ( ! isset( $_POST['_wknonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wknonce'] ) ), 'wakoo_board_delete_' . $id ) ) {
			self::back( $back, 'expired' );
		}
		$p = get_post( $id );
		if ( ! $p || (int) $p->post_author !== get_current_user_id() || ! in_array( $p->post_type, [ self::LISTING, self::JOB ], true ) ) {
			self::back( $back, 'denied' );
		}
		$img = (int) get_post_thumbnail_id( $id );
		if ( $img && (int) get_post_field( 'post_parent', $img ) === $id ) {
			wp_delete_attachment( $img, true );
		}
		foreach ( (array) get_post_meta( $id, '_wk_b_gallery', true ) as $g ) {
			$g = (int) ( is_array( $g ) ? ( $g['id'] ?? 0 ) : $g );
			if ( $g && (int) get_post_field( 'post_parent', $g ) === $id ) { wp_delete_attachment( $g, true ); }
		}
		wp_delete_post( $id, true );
		self::back( $back, 'board_deleted' );
	}

	/* ---------------------------------------------------------------- public: job seekers */

	private static function visitor() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return 'wk_seek_' . substr( hash_hmac( 'sha256', $ip, wp_salt( 'nonce' ) ), 0, 20 );
	}

	public static function seeker() {
		$back = isset( $_POST['back'] ) ? esc_url_raw( wp_unslash( $_POST['back'] ) ) : wp_get_referer();
		if ( ! isset( $_POST['_wknonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wknonce'] ) ), 'wakoo_job_seeker' ) ) {
			self::back( $back, 'expired', 'wakoo-seeker' );
		}
		$ts = isset( $_POST['wk_ts'] ) ? (int) $_POST['wk_ts'] : 0;
		if ( ! empty( $_POST['wk_hp'] ) || ( $ts && time() - $ts < Module::MIN_FILL ) ) {
			self::back( $back, 'seeker_sent', 'wakoo-seeker' ); // Bots: pretend success.
		}
		$hits = (int) get_transient( self::visitor() );
		if ( $hits >= 3 ) {
			self::back( $back, 'limit', 'wakoo-seeker' );
		}
		$in = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized below.
		$v  = [
			'name'     => mb_substr( sanitize_text_field( $in['wk_name'] ?? '' ), 0, 80 ),
			'title'    => mb_substr( sanitize_text_field( $in['wk_title'] ?? '' ), 0, 120 ),
			'text'     => mb_substr( sanitize_textarea_field( $in['wk_text'] ?? '' ), 0, 3000 ),
			'email'    => sanitize_email( $in['wk_email'] ?? '' ),
			'phone'    => mb_substr( sanitize_text_field( $in['wk_phone'] ?? '' ), 0, 40 ),
			'location' => mb_substr( sanitize_text_field( $in['wk_location'] ?? '' ), 0, 80 ),
			'jobtype'  => in_array( $in['wk_jobtype'] ?? '', self::TYPES, true ) ? $in['wk_jobtype'] : 'full',
		];
		if ( '' === $v['name'] || '' === $v['title'] || '' === $v['text'] || ! is_email( $v['email'] ) || empty( $in['wk_consent'] ) ) {
			self::back( $back, 'seeker_invalid', 'wakoo-seeker' );
		}
		$pid = wp_insert_post( [ 'post_type' => self::JOB, 'post_status' => 'pending', 'post_title' => $v['title'], 'post_content' => $v['text'] ], true );
		if ( is_wp_error( $pid ) ) {
			self::back( $back, 'error', 'wakoo-seeker' );
		}
		foreach ( [ 'name', 'email', 'phone', 'location', 'jobtype' ] as $k ) {
			update_post_meta( $pid, '_wk_b_' . $k, $v[ $k ] );
		}
		update_post_meta( $pid, '_wk_b_kind', 'seeker' );
		update_post_meta( $pid, '_wk_b_expires', gmdate( 'Y-m-d', strtotime( current_time( 'Y-m-d' ) . ' +' . self::JOB_DAYS . ' days' ) ) );
		$cv = self::upload_pdf( 'wk_cv', $pid );
		if ( $cv && ! is_wp_error( $cv ) ) {
			update_post_meta( $pid, '_wk_b_file', $cv );
		}
		set_transient( self::visitor(), $hits + 1, HOUR_IN_SECONDS );
		/* translators: %s: job title */
		wp_mail( Module::settings()['notify'], sprintf( __( 'Nueva candidatura por revisar: %s', 'wakoo' ), $v['title'] ), $v['name'] . ' · ' . $v['email'] . "\n\n" . $v['text'] . "\n\n" . admin_url( 'edit.php?post_type=' . self::JOB . '&post_status=pending' ), [ 'Reply-To: ' . $v['email'] ] );
		self::back( $back, 'seeker_sent', 'wakoo-seeker' );
	}

	/** Optional résumé: PDF up to 5 MB, checked by content. */
	private static function upload_pdf( $field, $pid ) {
		// phpcs:disable WordPress.Security.ValidatedSanitizedInput, WordPress.Security.NonceVerification -- caller checked the nonce.
		if ( empty( $_FILES[ $field ]['name'] ) || UPLOAD_ERR_OK !== (int) ( $_FILES[ $field ]['error'] ?? 4 ) ) {
			return 0;
		}
		$f = $_FILES[ $field ];
		// phpcs:enable
		if ( $f['size'] > Module::MAX_IMG ) {
			return new \WP_Error( 'size', 'too big' );
		}
		$check = wp_check_filetype_and_ext( $f['tmp_name'], $f['name'], [ 'pdf' => 'application/pdf' ] );
		if ( 'application/pdf' !== $check['type'] ) {
			return new \WP_Error( 'type', 'pdf only' );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		$moved = wp_handle_upload( $f, [ 'test_form' => false, 'mimes' => [ 'pdf' => 'application/pdf' ] ] );
		if ( isset( $moved['error'] ) ) {
			return new \WP_Error( 'upload', $moved['error'] );
		}
		return (int) wp_insert_attachment( [ 'post_mime_type' => 'application/pdf', 'post_title' => sanitize_file_name( $f['name'] ), 'post_status' => 'inherit' ], $moved['file'], $pid );
	}

	/* ---------------------------------------------------------------- shared bits for the widgets */

	/** Example listing: a single "publish yours" link to the members' account page (or the application form). */
	public static function demo_link( $text ) {
		$o   = Module::settings();
		$url = ! empty( $o['account'] ) ? get_permalink( (int) $o['account'] ) : home_url( '/' );
		return '<a class="wk-m-btn" href="' . esc_url( $url ) . '">' . esc_html( $text ) . '</a>';
	}

	public static function contact_links( array $d, array $labels ) {
		$links = [];
		$m     = $d['member'] ? Module::data( $d['member'] ) : null;
		$email = $d['email'] ?: ( $m ? $m['email'] : '' );
		$phone = $d['phone'] ?: ( $m ? $m['phone'] : '' );
		if ( $d['url'] ) {
			$links[] = '<a class="wk-m-btn" href="' . esc_url( $d['url'] ) . '" target="_blank" rel="noopener nofollow">' . esc_html( $labels['apply'] ?? '' ) . '</a>';
		} elseif ( $email ) {
			$links[] = '<a class="wk-m-btn" href="mailto:' . esc_attr( antispambot( $email ) ) . '?subject=' . rawurlencode( $d['title'] ) . '">' . esc_html( $labels['email'] ?? '' ) . '</a>';
		}
		if ( $phone ) {
			$links[] = '<a class="wk-m-btn wk-m-btn--ghost" href="tel:' . esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ) . '">' . esc_html( $labels['call'] ?? $phone ) . '</a>';
		}
		if ( $m && 'publish' === $m['status'] ) {
			$links[] = '<a class="wk-m-link" href="' . esc_url( $m['url'] ) . '">' . esc_html( $labels['profile'] ?? '' ) . ' →</a>';
		}
		return implode( '', $links );
	}

	public static function job_type_label( $t, array $labels ) {
		return $labels[ 'type_' . $t ] ?? $t;
	}
}
