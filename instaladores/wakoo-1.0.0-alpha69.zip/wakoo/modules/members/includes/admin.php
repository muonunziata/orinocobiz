<?php
/**
 * Wakoo Miembros: the admin hub (Miembros Wakoo).
 *
 * Solicitudes (approve / reject with one click), Mensajes, the member list
 * with a "Datos del miembro" box, categories and settings (profile URL,
 * profile template, account page, notifications).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Members;

defined( 'ABSPATH' ) || die();

class Admin {

	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ], 9 ); // Before the post type adds its "Miembros" item, so "Solicitudes" comes first.
		add_action( 'admin_post_wakoo_member_decide', [ __CLASS__, 'decide' ] );
		add_action( 'admin_post_wakoo_members_settings', [ __CLASS__, 'save_settings' ] );
		add_action( 'add_meta_boxes_' . Module::CPT, [ __CLASS__, 'meta_box' ] );
		add_action( 'save_post_' . Module::CPT, [ __CLASS__, 'save_meta' ], 10, 2 );
		add_filter( 'manage_' . Module::CPT . '_posts_columns', [ __CLASS__, 'columns' ] );
		add_action( 'manage_' . Module::CPT . '_posts_custom_column', [ __CLASS__, 'column' ], 10, 2 );
		// Marketplace and job board.
		add_action( 'add_meta_boxes', [ __CLASS__, 'board_box' ] );
		add_filter( 'post_row_actions', [ __CLASS__, 'board_row_actions' ], 10, 2 );
		add_action( 'admin_post_wakoo_board_approve', [ __CLASS__, 'board_approve' ] );
		foreach ( [ Board::LISTING, Board::JOB ] as $t ) {
			add_filter( 'manage_' . $t . '_posts_columns', [ __CLASS__, 'board_columns' ] );
			add_action( 'manage_' . $t . '_posts_custom_column', [ __CLASS__, 'board_column' ], 10, 2 );
		}
	}

	public static function menu() {
		$pending = (int) wp_count_posts( Module::CPT )->pending;
		$unread  = current_user_can( 'manage_options' ) ? Chat::admin_unread_total() : 0;
		$bubble  = $pending ? ' <span class="awaiting-mod">' . $pending . '</span>' : '';
		$total   = $pending + $unread ? ' <span class="awaiting-mod">' . ( $pending + $unread ) . '</span>' : '';
		add_menu_page( __( 'Miembros Wakoo', 'wakoo' ), __( 'Miembros Wakoo', 'wakoo' ) . $total, 'manage_options', Module::MENU, [ __CLASS__, 'requests_page' ], 'dashicons-groups', 58 );
		add_submenu_page( Module::MENU, __( 'Solicitudes', 'wakoo' ), __( 'Solicitudes', 'wakoo' ) . $bubble, 'manage_options', Module::MENU, [ __CLASS__, 'requests_page' ] );
		add_submenu_page( Module::MENU, __( 'Mensajes con miembros', 'wakoo' ), __( 'Mensajes', 'wakoo' ) . ( $unread ? ' <span class="awaiting-mod">' . $unread . '</span>' : '' ), 'manage_options', Module::MENU . '-chat', [ __CLASS__, 'chat_page' ] );
		add_submenu_page( Module::MENU, __( 'Categorías', 'wakoo' ), __( 'Categorías', 'wakoo' ), 'manage_options', 'edit-tags.php?taxonomy=' . Module::TAX . '&post_type=' . Module::CPT );
		add_submenu_page( Module::MENU, __( 'Ajustes de miembros', 'wakoo' ), __( 'Ajustes', 'wakoo' ), 'manage_options', Module::MENU . '-settings', [ __CLASS__, 'settings_page' ] );
	}

	/* ---------------------------------------------------------------- marketplace y empleo */

	public static function board_box() {
		foreach ( [ Board::LISTING, Board::JOB ] as $t ) {
			add_meta_box( 'wakoo_board_data', __( 'Datos del anuncio', 'wakoo' ), [ __CLASS__, 'board_box_html' ], $t, 'side', 'high' );
		}
	}

	public static function board_box_html( $post ) {
		$d    = Board::item( $post->ID );
		$m    = $d['member'] ? Module::data( $d['member'] ) : null;
		$rows = [
			__( 'Tipo', 'wakoo' )      => Board::JOB === $d['type'] ? ( 'seeker' === $d['kind'] ? __( 'Busca trabajo', 'wakoo' ) : __( 'Oferta de empleo', 'wakoo' ) ) : __( 'Producto o servicio', 'wakoo' ),
			__( 'Miembro', 'wakoo' )   => $m ? $m['name'] : '',
			__( 'Nombre', 'wakoo' )    => $d['name'],
			__( 'Precio / salario', 'wakoo' ) => $d['price'],
			__( 'Categoría', 'wakoo' ) => $d['category'],
			__( 'Jornada', 'wakoo' )   => $d['jobtype'],
			__( 'Lugar', 'wakoo' )     => $d['location'],
			__( 'Email', 'wakoo' )     => $d['email'],
			__( 'Teléfono', 'wakoo' )  => $d['phone'],
			__( 'Enlace', 'wakoo' )    => $d['url'],
			__( 'Caduca', 'wakoo' )    => $d['expires'],
		];
		echo '<table class="widefat striped"><tbody>';
		foreach ( array_filter( $rows ) as $k => $v ) {
			echo '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
		}
		if ( $d['file'] ) {
			echo '<tr><th>' . esc_html__( 'Currículum', 'wakoo' ) . '</th><td><a href="' . esc_url( wp_get_attachment_url( $d['file'] ) ) . '" target="_blank">PDF</a></td></tr>';
		}
		echo '</tbody></table>';
		if ( 'pending' === $post->post_status ) {
			echo '<p><a class="button button-primary" href="' . esc_url( self::board_approve_url( $post->ID ) ) . '">' . esc_html__( 'Aprobar y publicar', 'wakoo' ) . '</a></p>';
		}
	}

	private static function board_approve_url( $id ) {
		return wp_nonce_url( admin_url( 'admin-post.php?action=wakoo_board_approve&id=' . (int) $id ), 'wakoo_board_approve_' . (int) $id );
	}

	public static function board_row_actions( $actions, $post ) {
		if ( in_array( $post->post_type, [ Board::LISTING, Board::JOB ], true ) && 'pending' === $post->post_status && current_user_can( 'edit_post', $post->ID ) ) {
			$actions = [ 'wk_approve' => '<a href="' . esc_url( self::board_approve_url( $post->ID ) ) . '">' . esc_html__( 'Aprobar y publicar', 'wakoo' ) . '</a>' ] + $actions;
		}
		return $actions;
	}

	public static function board_approve() {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		if ( ! current_user_can( 'edit_post', $id ) || ! check_admin_referer( 'wakoo_board_approve_' . $id ) ) {
			wp_die( esc_html__( 'No autorizado.', 'wakoo' ) );
		}
		wp_update_post( [ 'ID' => $id, 'post_status' => 'publish' ] );
		$email = (string) get_post_meta( $id, '_wk_b_email', true );
		if ( 'seeker' === get_post_meta( $id, '_wk_b_kind', true ) && is_email( $email ) ) {
			/* translators: %s: site name */
			wp_mail( $email, sprintf( __( 'Tu anuncio ya está publicado en %s', 'wakoo' ), get_bloginfo( 'name' ) ), __( "Hola:\n\nHemos publicado tu anuncio en la bolsa de empleo. Estará visible 30 días.\n\nYour listing is now live on the job board for 30 days.", 'wakoo' ) . "\n\n" . home_url( '/' ) );
		}
		wp_safe_redirect( admin_url( 'edit.php?post_type=' . get_post_type( $id ) . '&wk_approved=1' ) );
		exit;
	}

	public static function board_columns( $cols ) {
		$out = [];
		foreach ( $cols as $k => $v ) {
			$out[ $k ] = $v;
			if ( 'title' === $k ) {
				$out['wk_b_who']  = __( 'Miembro / persona', 'wakoo' );
				$out['wk_b_info'] = __( 'Datos', 'wakoo' );
				$out['wk_b_exp']  = __( 'Caduca', 'wakoo' );
			}
		}
		return $out;
	}

	public static function board_column( $col, $id ) {
		$d = Board::item( $id );
		if ( 'wk_b_who' === $col ) {
			echo esc_html( $d['member'] ? get_the_title( $d['member'] ) : $d['name'] );
		} elseif ( 'wk_b_info' === $col ) {
			echo esc_html( implode( ' · ', array_filter( [ 'seeker' === $d['kind'] ? __( 'Busca trabajo', 'wakoo' ) : ( 'offer' === $d['kind'] ? __( 'Oferta', 'wakoo' ) : '' ), $d['category'], $d['price'], $d['location'] ] ) ) );
		} elseif ( 'wk_b_exp' === $col ) {
			echo esc_html( $d['expires'] );
		}
	}

	/* ---------------------------------------------------------------- mensajes */

	public static function chat_url( $pid ) {
		return admin_url( 'admin.php?page=' . Module::MENU . '-chat&member=' . (int) $pid );
	}

	/** Inbox: conversations on the left (unread first in the badge), the open one on the right. */
	public static function chat_page() {
		$open  = isset( $_GET['member'] ) ? (int) $_GET['member'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$convs = Chat::conversations();
		if ( ! $open && $convs ) {
			$open = $convs[0]['pid'];
		}
		$active = get_posts( [ 'post_type' => Module::CPT, 'post_status' => 'publish', 'posts_per_page' => 300, 'orderby' => 'title', 'order' => 'ASC' ] );
		echo '<div class="wrap wk-inbox-wrap"><h1>' . esc_html__( 'Mensajes con miembros', 'wakoo' ) . '</h1><div class="wk-inbox">';
		echo '<nav class="wk-inbox__list" aria-label="' . esc_attr__( 'Conversaciones', 'wakoo' ) . '">';
		echo '<form method="get" class="wk-inbox__new"><input type="hidden" name="page" value="' . esc_attr( Module::MENU . '-chat' ) . '"><select name="member" onchange="this.form.submit()" aria-label="' . esc_attr__( 'Escribir a un miembro', 'wakoo' ) . '"><option value="">' . esc_html__( '+ Escribir a un miembro…', 'wakoo' ) . '</option>';
		foreach ( $active as $m ) {
			echo '<option value="' . (int) $m->ID . '">' . esc_html( $m->post_title ) . '</option>';
		}
		echo '</select></form>';
		if ( ! $convs ) {
			echo '<p class="wk-inbox__none">' . esc_html__( 'Todavía no hay conversaciones.', 'wakoo' ) . '</p>';
		}
		foreach ( $convs as $c ) {
			$logo = get_the_post_thumbnail( $c['pid'], [ 40, 40 ], [ 'class' => 'wk-inbox__logo' ] ) ?: '<span class="wk-inbox__logo wk-inbox__logo--empty">' . esc_html( mb_substr( get_the_title( $c['pid'] ), 0, 1 ) ) . '</span>';
			$who  = 'admin' === get_comment_meta( $c['last']->comment_ID, 'wk_from', true ) ? __( 'Tú: ', 'wakoo' ) : '';
			echo '<a class="wk-inbox__item' . ( $c['pid'] === $open ? ' is-open' : '' ) . ( $c['unread'] ? ' is-unread' : '' ) . '" href="' . esc_url( self::chat_url( $c['pid'] ) ) . '">' . $logo // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				. '<span class="wk-inbox__txt"><strong>' . esc_html( get_the_title( $c['pid'] ) ) . '</strong><span>' . esc_html( $who . wp_trim_words( $c['last']->comment_content ?: '📎', 9, '…' ) ) . '</span></span>'
				. ( $c['unread'] ? '<span class="awaiting-mod">' . (int) $c['unread'] . '</span>' : '<time>' . esc_html( human_time_diff( strtotime( $c['last']->comment_date_gmt . ' UTC' ) ) ) . '</time>' ) . '</a>';
		}
		echo '</nav><section class="wk-inbox__thread">';
		if ( $open && Module::CPT === get_post_type( $open ) ) {
			$d = Module::data( $open );
			echo '<header class="wk-inbox__head"><strong>' . esc_html( $d['name'] ) . '</strong> <span>' . esc_html( implode( ' · ', array_filter( [ $d['contact'], (string) get_post_meta( $open, '_wk_m_account', true ) ] ) ) ) . '</span>';
			echo ' <a href="' . esc_url( get_edit_post_link( $open ) ) . '">' . esc_html__( 'Ficha', 'wakoo' ) . '</a>';
			echo 'publish' === $d['status'] ? ' · <a href="' . esc_url( $d['url'] ) . '" target="_blank">' . esc_html__( 'Perfil público', 'wakoo' ) . '</a>' : ' · <em>' . esc_html__( 'El perfil no está publicado: el miembro no verá los mensajes hasta que se apruebe.', 'wakoo' ) . '</em>';
			echo '</header>';
			echo Chat::box( $open, 'admin', Chat::admin_labels() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} else {
			echo '<p class="wk-inbox__none">' . esc_html__( 'Elige una conversación o escribe a un miembro.', 'wakoo' ) . '</p>';
		}
		echo '</section></div></div>';
		echo '<style>.wk-inbox{display:grid;grid-template-columns:320px minmax(0,1fr);gap:16px;margin-top:14px;max-width:1200px}.wk-inbox__list,.wk-inbox__thread{background:#fff;border:1px solid #dcdcde;border-radius:10px;overflow:hidden}.wk-inbox__list{display:flex;flex-direction:column;max-height:75vh;overflow:auto}.wk-inbox__new{padding:10px;border-bottom:1px solid #f0f0f1}.wk-inbox__new select{width:100%;max-width:none}.wk-inbox__item{display:flex;gap:10px;align-items:center;padding:10px 12px;text-decoration:none;color:#1d2327;border-bottom:1px solid #f0f0f1}.wk-inbox__item:hover{background:#f6f7f7}.wk-inbox__item.is-open{background:#e7f4ef}.wk-inbox__item.is-unread strong{font-weight:800}.wk-inbox__logo{width:40px;height:40px;border-radius:10px;object-fit:contain;background:#f6f7f7;flex:0 0 40px;display:flex;align-items:center;justify-content:center;font-weight:700}.wk-inbox__txt{flex:1;min-width:0;display:flex;flex-direction:column}.wk-inbox__txt span{color:#646970;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.wk-inbox__item time{color:#8c8f94;font-size:11px}.wk-inbox__head{padding:12px 16px;border-bottom:1px solid #f0f0f1}.wk-inbox__head span{color:#646970}.wk-inbox__thread .wk-chat{border:0;border-radius:0;box-shadow:none}.wk-inbox__none{padding:16px;color:#646970}@media(max-width:900px){.wk-inbox{grid-template-columns:1fr}}</style>';
	}

	/* ---------------------------------------------------------------- solicitudes */

	private static function decide_url( $pid, $what ) {
		return wp_nonce_url( admin_url( 'admin-post.php?action=wakoo_member_decide&do=' . $what . '&id=' . (int) $pid ), 'wakoo_member_decide_' . (int) $pid );
	}

	public static function decide() {
		$pid = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		$do  = isset( $_GET['do'] ) ? sanitize_key( wp_unslash( $_GET['do'] ) ) : '';
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'wakoo_member_decide_' . $pid ) ) {
			wp_die( esc_html__( 'No autorizado.', 'wakoo' ) );
		}
		$msg = 'done';
		if ( 'approve' === $do ) {
			$r   = Module::approve( $pid );
			$msg = is_wp_error( $r ) ? 'error:' . $r->get_error_message() : 'approved';
		} elseif ( 'reject' === $do ) {
			Module::reject( $pid );
			$msg = 'rejected';
		} elseif ( 'suspend' === $do ) {
			Module::reject( $pid, false );
			$msg = 'suspended';
		}
		wp_safe_redirect( add_query_arg( [ 'page' => Module::MENU, 'wk_msg' => rawurlencode( $msg ) ], admin_url( 'admin.php' ) ) );
		exit;
	}

	private static function row( $pid ) {
		$d       = Module::data( $pid );
		$account = (string) get_post_meta( $pid, '_wk_m_account', true );
		$applied = (string) get_post_meta( $pid, '_wk_m_applied', true );
		$logo    = $d['logo'] ? wp_get_attachment_image( $d['logo'], [ 72, 72 ], false, [ 'style' => 'width:72px;height:72px;object-fit:contain;border-radius:10px;background:#fff;border:1px solid #ddd' ] ) : '<span class="dashicons dashicons-store" style="font-size:48px;width:72px;height:72px;color:#9aa"></span>';
		echo '<div class="wk-mreq">' . $logo . '<div class="wk-mreq__body">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<h3>' . esc_html( $d['name'] ) . ( $d['category'] ? ' <span class="wk-mreq__cat">' . esc_html( $d['category'] ) . '</span>' : '' ) . '</h3>';
		echo '<p class="wk-mreq__meta">' . esc_html( implode( ' · ', array_filter( [ $d['contact'], $account, $d['phone'], $d['address'] ] ) ) ) . '</p>';
		if ( $d['website'] ) {
			echo '<p class="wk-mreq__meta"><a href="' . esc_url( $d['website'] ) . '" target="_blank" rel="noopener">' . esc_html( $d['website'] ) . '</a></p>';
		}
		echo '<p>' . nl2br( esc_html( wp_trim_words( $d['description'], 80, '…' ) ) ) . '</p>';
		if ( $applied ) {
			/* translators: %s: date */
			echo '<p class="wk-mreq__meta">' . esc_html( sprintf( __( 'Solicitado el %s', 'wakoo' ), mysql2date( get_option( 'date_format' ) . ' H:i', $applied ) ) ) . '</p>';
		}
		echo '</div><div class="wk-mreq__actions">';
		if ( 'publish' === $d['status'] ) {
			echo '<a class="button" href="' . esc_url( $d['url'] ) . '" target="_blank">' . esc_html__( 'Ver perfil', 'wakoo' ) . '</a> ';
			$unread = Chat::unread( $pid, 'admin' );
			echo '<a class="button" href="' . esc_url( self::chat_url( $pid ) ) . '">' . esc_html__( 'Mensajes', 'wakoo' ) . ( $unread ? ' (' . (int) $unread . ')' : '' ) . '</a> ';
			echo '<a class="button" href="' . esc_url( self::decide_url( $pid, 'suspend' ) ) . '" onclick="return confirm(this.dataset.q)" data-q="' . esc_attr__( '¿Suspender este perfil? Dejará de verse en el sitio.', 'wakoo' ) . '">' . esc_html__( 'Suspender', 'wakoo' ) . '</a>';
		} else {
			echo '<a class="button button-primary" href="' . esc_url( self::decide_url( $pid, 'approve' ) ) . '">' . esc_html__( 'Aprobar', 'wakoo' ) . '</a> ';
			if ( 'pending' === $d['status'] ) {
				echo '<a class="button" href="' . esc_url( self::decide_url( $pid, 'reject' ) ) . '" onclick="return confirm(this.dataset.q)" data-q="' . esc_attr__( '¿Rechazar la solicitud? Se avisará por email.', 'wakoo' ) . '">' . esc_html__( 'Rechazar', 'wakoo' ) . '</a>';
			}
		}
		echo ' <a class="button-link" href="' . esc_url( get_edit_post_link( $pid ) ) . '">' . esc_html__( 'Editar', 'wakoo' ) . '</a></div></div>';
	}

	public static function requests_page() {
		$tab    = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'pending'; // phpcs:ignore WordPress.Security.NonceVerification
		$counts = wp_count_posts( Module::CPT );
		$tabs   = [
			'pending' => [ __( 'Pendientes', 'wakoo' ), 'pending', (int) $counts->pending ],
			'publish' => [ __( 'Miembros activos', 'wakoo' ), 'publish', (int) $counts->publish ],
			'draft'   => [ __( 'Rechazados o suspendidos', 'wakoo' ), 'draft', (int) $counts->draft ],
		];
		$tab = isset( $tabs[ $tab ] ) ? $tab : 'pending';
		echo '<div class="wrap"><h1>' . esc_html__( 'Miembros Wakoo', 'wakoo' ) . '</h1>';
		$msg = isset( $_GET['wk_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['wk_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$map = [
			'approved'  => __( 'Solicitud aprobada: se creó la cuenta y se envió el email de bienvenida.', 'wakoo' ),
			'rejected'  => __( 'Solicitud rechazada y avisada por email.', 'wakoo' ),
			'suspended' => __( 'Perfil suspendido: ya no se ve en el sitio.', 'wakoo' ),
		];
		if ( isset( $map[ $msg ] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $map[ $msg ] ) . '</p></div>';
		} elseif ( 0 === strpos( $msg, 'error:' ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html( substr( $msg, 6 ) ) . '</p></div>';
		}
		$s = Module::settings();
		if ( ! $s['template'] || ! $s['account'] ) {
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'Falta elegir la plantilla del perfil público o la página «Mi cuenta» de los miembros.', 'wakoo' ) . ' <a href="' . esc_url( admin_url( 'admin.php?page=' . Module::MENU . '-settings' ) ) . '">' . esc_html__( 'Ir a Ajustes', 'wakoo' ) . '</a></p></div>';
		}
		echo '<h2 class="nav-tab-wrapper">';
		foreach ( $tabs as $k => $t ) {
			echo '<a class="nav-tab' . ( $k === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=' . Module::MENU . '&tab=' . $k ) ) . '">' . esc_html( $t[0] ) . ' <span class="count">(' . (int) $t[2] . ')</span></a>';
		}
		echo '</h2>';
		$ids = get_posts( [ 'post_type' => Module::CPT, 'post_status' => $tabs[ $tab ][1], 'posts_per_page' => 100, 'orderby' => 'date', 'order' => 'pending' === $tab ? 'ASC' : 'DESC', 'fields' => 'ids' ] );
		if ( ! $ids ) {
			echo '<p class="wk-mempty">' . esc_html__( 'No hay nada aquí por ahora.', 'wakoo' ) . '</p>';
		}
		foreach ( $ids as $pid ) {
			self::row( $pid );
		}
		echo '</div>';
		echo '<style>.wk-mreq{display:flex;gap:18px;align-items:flex-start;background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:16px 18px;margin:14px 0;max-width:1100px}.wk-mreq__body{flex:1}.wk-mreq h3{margin:0 0 6px}.wk-mreq__cat{font-size:12px;font-weight:600;background:#e7f4ef;color:#155a49;border-radius:20px;padding:2px 9px;margin-left:6px}.wk-mreq__meta{color:#646970;margin:2px 0}.wk-mreq__actions{display:flex;flex-direction:column;gap:6px;align-items:flex-end;min-width:150px}.wk-mempty{font-size:14px;color:#646970;margin-top:20px}</style>';
	}

	/* ---------------------------------------------------------------- member edit screen */

	public static function meta_box() {
		add_meta_box( 'wakoo_member_data', __( 'Datos del miembro', 'wakoo' ), [ __CLASS__, 'meta_html' ], Module::CPT, 'normal', 'high' );
	}

	private static function labels() {
		return [
			'tagline'   => __( 'Lema (una línea)', 'wakoo' ),
			'contact'   => __( 'Persona de contacto', 'wakoo' ),
			'email'     => __( 'Email público', 'wakoo' ),
			'phone'     => __( 'Teléfono', 'wakoo' ),
			'website'   => __( 'Web', 'wakoo' ),
			'address'   => __( 'Dirección (para Google Maps)', 'wakoo' ),
			'facebook'  => __( 'Facebook (URL)', 'wakoo' ),
			'instagram' => __( 'Instagram (URL)', 'wakoo' ),
		];
	}

	public static function meta_html( $post ) {
		wp_nonce_field( 'wakoo_member_meta', '_wkmeta' );
		$d = Module::data( $post->ID );
		echo '<table class="form-table"><tbody>';
		echo '<tr><th>' . esc_html__( 'Email de la cuenta', 'wakoo' ) . '</th><td><code>' . esc_html( (string) get_post_meta( $post->ID, '_wk_m_account', true ) ) . '</code>';
		if ( 'pending' === $post->post_status ) {
			echo ' &nbsp; <a class="button button-primary" href="' . esc_url( self::decide_url( $post->ID, 'approve' ) ) . '">' . esc_html__( 'Aprobar solicitud', 'wakoo' ) . '</a>';
		}
		echo '</td></tr>';
		foreach ( self::labels() as $k => $label ) {
			echo '<tr><th><label for="wk_' . esc_attr( $k ) . '">' . esc_html( $label ) . '</label></th><td><input class="regular-text" type="text" id="wk_' . esc_attr( $k ) . '" name="wk_meta[' . esc_attr( $k ) . ']" value="' . esc_attr( $d[ $k ] ) . '"></td></tr>';
		}
		echo '<tr><th>' . esc_html__( 'Galería', 'wakoo' ) . '</th><td>';
		if ( ! $d['gallery'] ) {
			echo '<p class="description">' . esc_html__( 'El miembro sube sus fotos desde su cuenta.', 'wakoo' ) . '</p>';
		}
		foreach ( $d['gallery'] as $aid ) {
			echo '<label style="display:inline-block;margin:0 10px 10px 0;text-align:center">' . wp_get_attachment_image( $aid, [ 90, 90 ] ) . '<br><input type="checkbox" name="wk_remove[]" value="' . (int) $aid . '"> ' . esc_html__( 'Quitar', 'wakoo' ) . '</label>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</td></tr></tbody></table><p class="description">' . esc_html__( 'El logo es la «Imagen destacada»; la descripción es el contenido de la entrada.', 'wakoo' ) . '</p>';
	}

	public static function save_meta( $pid, $post ) {
		if ( ! isset( $_POST['_wkmeta'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wkmeta'] ) ), 'wakoo_member_meta' ) || ! current_user_can( 'edit_post', $pid ) ) {
			return;
		}
		$in = isset( $_POST['wk_meta'] ) ? (array) wp_unslash( $_POST['wk_meta'] ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		foreach ( array_keys( self::labels() ) as $k ) {
			if ( isset( $in[ $k ] ) ) {
				$val = in_array( $k, [ 'website', 'facebook', 'instagram' ], true ) ? esc_url_raw( $in[ $k ] ) : ( 'email' === $k ? sanitize_email( $in[ $k ] ) : sanitize_text_field( $in[ $k ] ) );
				update_post_meta( $pid, '_wk_m_' . $k, $val );
			}
		}
		$remove = array_map( 'intval', isset( $_POST['wk_remove'] ) ? (array) wp_unslash( $_POST['wk_remove'] ) : [] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( $remove ) {
			update_post_meta( $pid, '_wk_m_gallery', array_values( array_diff( array_map( 'intval', (array) get_post_meta( $pid, '_wk_m_gallery', true ) ), $remove ) ) );
		}
	}

	public static function columns( $cols ) {
		$out = [];
		foreach ( $cols as $k => $v ) {
			if ( 'title' === $k ) {
				$out['wk_logo'] = __( 'Logo', 'wakoo' );
			}
			$out[ $k ] = $v;
			if ( 'title' === $k ) {
				$out['wk_account'] = __( 'Cuenta', 'wakoo' );
			}
		}
		return $out;
	}

	public static function column( $col, $pid ) {
		if ( 'wk_logo' === $col ) {
			echo get_the_post_thumbnail( $pid, [ 44, 44 ], [ 'style' => 'width:44px;height:44px;object-fit:contain' ] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} elseif ( 'wk_account' === $col ) {
			echo esc_html( (string) get_post_meta( $pid, '_wk_m_account', true ) );
		}
	}

	/* ---------------------------------------------------------------- ajustes */

	public static function settings_page() {
		$s     = Module::settings();
		$tpls  = get_posts( [ 'post_type' => 'elementor_library', 'post_status' => 'publish', 'posts_per_page' => 200, 'orderby' => 'title', 'order' => 'ASC' ] );
		$pages = get_pages( [ 'post_status' => 'publish' ] );
		echo '<div class="wrap"><h1>' . esc_html__( 'Ajustes de miembros', 'wakoo' ) . '</h1>';
		if ( isset( $_GET['saved'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Ajustes guardados.', 'wakoo' ) . '</p></div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="wakoo_members_settings">';
		wp_nonce_field( 'wakoo_members_settings' );
		echo '<table class="form-table"><tbody>';
		echo '<tr><th><label for="wk_slug">' . esc_html__( 'Dirección de los perfiles', 'wakoo' ) . '</label></th><td><code>' . esc_html( home_url( '/' ) ) . '</code><input id="wk_slug" name="s[slug]" value="' . esc_attr( $s['slug'] ) . '" class="regular-text" style="width:160px"><code>/nombre-del-negocio/</code></td></tr>';
		echo '<tr><th><label for="wk_tpl">' . esc_html__( 'Plantilla del perfil público', 'wakoo' ) . '</label></th><td><select id="wk_tpl" name="s[template]"><option value="0">' . esc_html__( '— Diseño sencillo con el tema —', 'wakoo' ) . '</option>';
		foreach ( $tpls as $t ) {
			echo '<option value="' . (int) $t->ID . '"' . selected( (int) $s['template'], $t->ID, false ) . '>' . esc_html( $t->post_title ) . '</option>';
		}
		echo '</select><p class="description">' . esc_html__( 'Una plantilla guardada de Elementor/Wakoo con tu cabecera, el widget «Microperfil (Wakoo)» y tu pie.', 'wakoo' ) . '</p></td></tr>';
		echo '<tr><th><label for="wk_acc">' . esc_html__( 'Página «Mi cuenta»', 'wakoo' ) . '</label></th><td><select id="wk_acc" name="s[account]"><option value="0">—</option>';
		foreach ( $pages as $pg ) {
			echo '<option value="' . (int) $pg->ID . '"' . selected( (int) $s['account'], $pg->ID, false ) . '>' . esc_html( $pg->post_title . ' (/' . get_page_uri( $pg ) . '/)' ) . '</option>';
		}
		echo '</select><p class="description">' . esc_html__( 'La página con el widget «Mi cuenta de miembro (Wakoo)». Los miembros llegan aquí al iniciar sesión.', 'wakoo' ) . '</p></td></tr>';
		echo '<tr><th><label for="wk_notify">' . esc_html__( 'Avisar de nuevas solicitudes a', 'wakoo' ) . '</label></th><td><input id="wk_notify" type="email" name="s[notify]" value="' . esc_attr( $s['notify'] ) . '" class="regular-text"></td></tr>';
		echo '<tr><th><label for="wk_max">' . esc_html__( 'Fotos máximas por galería', 'wakoo' ) . '</label></th><td><input id="wk_max" type="number" min="1" max="40" name="s[max_gallery]" value="' . (int) $s['max_gallery'] . '"></td></tr>';
		echo '</tbody></table>';
		submit_button();
		echo '</form></div>';
	}

	public static function save_settings() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'wakoo_members_settings' ) ) {
			wp_die( esc_html__( 'No autorizado.', 'wakoo' ) );
		}
		$in  = isset( $_POST['s'] ) ? (array) wp_unslash( $_POST['s'] ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$new = [
			'slug'        => sanitize_title( $in['slug'] ?? '' ) ?: 'members',
			'template'    => (int) ( $in['template'] ?? 0 ),
			'account'     => (int) ( $in['account'] ?? 0 ),
			'notify'      => sanitize_email( $in['notify'] ?? '' ) ?: get_option( 'admin_email' ),
			'max_gallery' => min( 40, max( 1, (int) ( $in['max_gallery'] ?? 12 ) ) ),
		];
		update_option( Module::OPTION, $new ); // A new slug rebuilds the rewrite rules on the next request (Module::register).
		wp_safe_redirect( admin_url( 'admin.php?page=' . Module::MENU . '-settings&saved=1' ) );
		exit;
	}
}
