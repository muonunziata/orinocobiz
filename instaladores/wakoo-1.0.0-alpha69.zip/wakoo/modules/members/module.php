<?php
/**
 * Wakoo Miembros: member applications, approval and public micro-profiles.
 *
 * - Anyone can apply with the "Solicitud de membresía (Wakoo)" widget: the
 *   application is stored as a pending `wakoo_member` profile (honeypot, time
 *   trap and a per-visitor limit keep bots out) and the admin is emailed.
 * - The hub (Miembros Wakoo → Solicitudes) approves or rejects. Approving
 *   creates a WordPress user with the `wakoo_member` role, publishes the
 *   profile and emails a link to choose a password.
 * - Members edit their micro-profile (logo, gallery, description, contact,
 *   address → Google Maps) from the front end with "Mi cuenta de miembro";
 *   they never see wp-admin.
 * - Public widgets: member directory and micro-profile (with LocalBusiness
 *   JSON-LD). The single profile page can be drawn by a saved Elementor
 *   template (Miembros Wakoo → Ajustes), so it shares the site's header/footer.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Members;

defined( 'ABSPATH' ) || die();

class Module {

	const CPT       = 'wakoo_member';
	const TAX       = 'wakoo_member_cat';
	const ROLE      = 'wakoo_member';
	const OPTION    = 'wakoo_members';
	const NONCE     = 'wakoo_members';
	const MIN_FILL  = 3;           // Seconds: faster than this = bot.
	const MAX_IMG   = 5242880;     // 5 MB per image.
	const LIMIT     = 5;           // Applications per visitor per hour.
	const MENU      = 'wakoo-members';
	const META      = [ 'tagline', 'contact', 'email', 'phone', 'website', 'address', 'facebook', 'instagram' ];

	public static function init() {
		add_action( 'init', [ __CLASS__, 'register' ] );
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widgets' ] );
		add_action( 'elementor/dynamic_tags/register', [ __CLASS__, 'register_tag' ], 20 ); // After the "Wakoo" group exists.
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'assets' ] );
		add_action( 'elementor/frontend/after_register_styles', [ __CLASS__, 'styles' ] );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'styles' ], 5 );
		add_action( 'admin_post_nopriv_wakoo_member_apply', [ __CLASS__, 'apply' ] );
		add_action( 'admin_post_wakoo_member_apply', [ __CLASS__, 'apply' ] );
		add_action( 'admin_post_wakoo_member_save', [ __CLASS__, 'save_profile' ] );
		add_action( 'admin_init', [ __CLASS__, 'keep_members_out' ] );
		add_filter( 'show_admin_bar', [ __CLASS__, 'admin_bar' ] );
		add_filter( 'template_include', [ __CLASS__, 'template' ], 99 );
		add_action( 'wp_head', [ __CLASS__, 'json_ld' ], 20 );
		add_filter( 'login_redirect', [ __CLASS__, 'login_redirect' ], 10, 3 );
		// Live search (modules/search) can find approved members.
		add_filter( 'wakoo_search_types', function ( $t ) { $t[] = self::CPT; return $t; } );
		add_filter( 'wakoo_search_type_labels', function ( $l ) { $l[ self::CPT ] = __( 'Miembros', 'wakoo' ); return $l; } );
		add_filter( 'wakoo_search_neutral_types', function ( $t ) { $t[] = self::CPT; return $t; } ); // A profile is the same in every language.
		require_once __DIR__ . '/includes/chat.php';
		Chat::init();
		require_once __DIR__ . '/includes/board.php';
		// Packs can carry marketplace listings and job offers (e.g. examples) with their board fields.
		add_filter( 'wakoo_portable_types', function ( $t ) { return array_merge( $t, [ 'wakoo_listing', 'wakoo_job' ] ); } );
		add_filter( 'wakoo_portable_meta_prefixes', function ( $p ) { $p[] = '_wk_b_'; return $p; } );
		Board::init();
		add_action( 'init', [ Chat::class, 'register_assets' ] );
		if ( is_admin() ) {
			require_once __DIR__ . '/includes/admin.php';
			Admin::init();
		}
	}

	/* ---------------------------------------------------------------- data */

	public static function settings() {
		$o = get_option( self::OPTION, [] );
		return wp_parse_args( is_array( $o ) ? $o : [], [
			'slug'        => 'members',
			'template'    => 0,
			'account'     => 0,
			'notify'      => get_option( 'admin_email' ),
			'max_gallery' => 12,
		] );
	}

	public static function register() {
		$s = self::settings();
		register_post_type( self::CPT, [
			'labels'          => [
				'name'          => __( 'Miembros', 'wakoo' ),
				'singular_name' => __( 'Miembro', 'wakoo' ),
				'edit_item'     => __( 'Editar miembro', 'wakoo' ),
				'all_items'     => __( 'Miembros', 'wakoo' ),
				'search_items'  => __( 'Buscar miembros', 'wakoo' ),
			],
			'public'          => true,
			'show_ui'         => true,
			'show_in_menu'    => self::MENU,
			'has_archive'     => false,
			'rewrite'         => [ 'slug' => sanitize_title( $s['slug'] ) ?: 'members', 'with_front' => false ],
			'supports'        => [ 'title', 'editor', 'thumbnail', 'excerpt', 'author' ],
			'capability_type' => 'post',
			'capabilities'    => [ 'create_posts' => 'do_not_allow' ], // Profiles are born from applications.
			'map_meta_cap'    => true,
			'show_in_rest'    => false,
		] );
		register_taxonomy( self::TAX, self::CPT, [
			'labels'            => [ 'name' => __( 'Categorías de miembros', 'wakoo' ), 'singular_name' => __( 'Categoría', 'wakoo' ), 'menu_name' => __( 'Categorías', 'wakoo' ) ],
			'public'            => false,
			'show_ui'           => true,
			'show_admin_column' => true,
			'hierarchical'      => false,
			'rewrite'           => false,
		] );
		// First run or a new profile URL: rebuild the rewrite rules once.
		$slug = sanitize_title( $s['slug'] ) ?: 'members';
		if ( get_option( self::OPTION . '_rules' ) !== $slug ) {
			update_option( self::OPTION . '_rules', $slug );
			flush_rewrite_rules( false );
		}
		if ( ! get_role( self::ROLE ) ) {
			add_role( self::ROLE, __( 'Miembro (Wakoo)', 'wakoo' ), [ 'read' => true ] );
		}
	}

	public static function register_widgets( $wm ) {
		require_once __DIR__ . '/widgets/base.php';
		foreach ( [ 'apply', 'account', 'directory', 'profile', 'market', 'jobs', 'seeker' ] as $w ) {
			require_once __DIR__ . '/widgets/' . $w . '.php';
		}
		$wm->register( new Apply_Widget() );
		$wm->register( new Account_Widget() );
		$wm->register( new Directory_Widget() );
		$wm->register( new Profile_Widget() );
		$wm->register( new Market_Widget() );
		$wm->register( new Jobs_Widget() );
		$wm->register( new Seeker_Widget() );
	}

	public static function register_tag( $tags ) {
		// Same group as modules/dynamic-tags (registering it again is harmless if that module is there).
		\Elementor\Plugin::instance()->dynamic_tags->register_group( 'wakoo', [ 'title' => __( 'Wakoo', 'wakoo' ) ] );
		require_once __DIR__ . '/includes/tag.php';
		$tags->register( new Member_Field_Tag() );
	}

	public static function assets() {
		wp_register_script( 'wakoo-members', WAKOO_MODULES_URL . 'members/assets/members.js', [], WAKOO_VERSION, true );
	}

	public static function styles() {
		if ( ! wp_style_is( 'wakoo-members', 'registered' ) ) {
			wp_register_style( 'wakoo-members', WAKOO_MODULES_URL . 'members/assets/members.css', [], WAKOO_VERSION );
		}
	}

	/** Profile of a user (any status), or 0. */
	public static function profile_of( $user_id ) {
		$q = get_posts( [ 'post_type' => self::CPT, 'post_status' => [ 'publish', 'draft', 'pending' ], 'author' => (int) $user_id, 'posts_per_page' => 1, 'fields' => 'ids' ] );
		return $q ? (int) $q[0] : 0;
	}

	/** Everything a widget needs to draw a profile. */
	public static function data( $pid ) {
		$p = get_post( $pid );
		if ( ! $p || self::CPT !== $p->post_type ) {
			return null;
		}
		$d = [ 'id' => $p->ID, 'name' => get_the_title( $p ), 'description' => $p->post_content, 'url' => get_permalink( $p ), 'status' => $p->post_status ];
		foreach ( self::META as $k ) {
			$d[ $k ] = (string) get_post_meta( $p->ID, '_wk_m_' . $k, true );
		}
		$d['logo']     = (int) get_post_thumbnail_id( $p );
		$d['gallery']  = array_values( array_filter( array_map( 'intval', (array) get_post_meta( $p->ID, '_wk_m_gallery', true ) ) ) );
		$terms         = get_the_terms( $p, self::TAX );
		$d['category'] = $terms && ! is_wp_error( $terms ) ? $terms[0]->name : '';
		return $d;
	}

	public static function maps_link( $address ) {
		return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $address );
	}


	/* ---------------------------------------------------------------- applications */

	/** Called by the apply widget on render: its texts live server-side, looked up by key. */
	public static function register_form( array $conf ) {
		$key = substr( md5( wp_json_encode( $conf ) ), 0, 12 );
		$reg = get_option( self::OPTION . '_forms', [] );
		$reg = is_array( $reg ) ? $reg : [];
		if ( ( $reg[ $key ] ?? null ) !== $conf ) {
			$reg[ $key ] = $conf;
			update_option( self::OPTION . '_forms', array_slice( $reg, -50, null, true ), false );
		}
		return $key;
	}

	private static function back( $url, $args ) {
		$url = $url ? $url : home_url( '/' );
		wp_safe_redirect( add_query_arg( $args, remove_query_arg( [ 'wk_member', 'wk_err' ], $url ) ) . '#wakoo-member' );
		exit;
	}

	/** Visitor hash for rate limiting (no IP stored in clear). */
	private static function visitor() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return 'wk_mapply_' . substr( hash_hmac( 'sha256', $ip, wp_salt( 'nonce' ) ), 0, 20 );
	}

	public static function apply() {
		$back = isset( $_POST['back'] ) ? esc_url_raw( wp_unslash( $_POST['back'] ) ) : wp_get_referer();
		if ( ! isset( $_POST['_wknonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wknonce'] ) ), self::NONCE ) ) {
			self::back( $back, [ 'wk_member' => 'expired' ] );
		}
		// Bots: honeypot or implausibly fast → pretend success.
		$ts = isset( $_POST['wk_ts'] ) ? (int) $_POST['wk_ts'] : 0;
		if ( ! empty( $_POST['wk_hp'] ) || ( $ts && ( time() - $ts ) < self::MIN_FILL ) ) {
			self::back( $back, [ 'wk_member' => 'sent' ] );
		}
		$hits = (int) get_transient( self::visitor() );
		if ( $hits >= self::LIMIT ) {
			self::back( $back, [ 'wk_member' => 'limit' ] );
		}

		$in = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized field by field below.
		$v  = [
			'name'        => sanitize_text_field( $in['wk_name'] ?? '' ),
			'contact'     => sanitize_text_field( $in['wk_contact'] ?? '' ),
			'email'       => sanitize_email( $in['wk_email'] ?? '' ),
			'phone'       => sanitize_text_field( $in['wk_phone'] ?? '' ),
			'website'     => esc_url_raw( $in['wk_website'] ?? '' ),
			'address'     => sanitize_text_field( $in['wk_address'] ?? '' ),
			'category'    => sanitize_text_field( $in['wk_category'] ?? '' ),
			'description' => sanitize_textarea_field( $in['wk_description'] ?? '' ),
		];
		$err = [];
		foreach ( [ 'name', 'contact', 'email', 'address', 'description' ] as $k ) {
			if ( '' === $v[ $k ] ) { $err[] = $k; }
		}
		if ( $v['email'] && ! is_email( $v['email'] ) ) { $err[] = 'email'; }
		if ( empty( $in['wk_consent'] ) ) { $err[] = 'consent'; }
		if ( $err ) {
			self::back( $back, [ 'wk_member' => 'invalid', 'wk_err' => implode( ',', array_unique( $err ) ) ] );
		}
		$user = get_user_by( 'email', $v['email'] );
		if ( $user && self::profile_of( $user->ID ) ) {
			self::back( $back, [ 'wk_member' => 'exists' ] );
		}

		$pid = wp_insert_post( [
			'post_type'    => self::CPT,
			'post_status'  => 'pending',
			'post_title'   => $v['name'],
			'post_content' => $v['description'],
			'post_excerpt' => wp_trim_words( $v['description'], 30, '…' ),
		], true );
		if ( is_wp_error( $pid ) ) {
			self::back( $back, [ 'wk_member' => 'error' ] );
		}
		foreach ( [ 'contact', 'phone', 'website', 'address' ] as $k ) {
			update_post_meta( $pid, '_wk_m_' . $k, $v[ $k ] );
		}
		update_post_meta( $pid, '_wk_m_account', $v['email'] ); // Private: where the approval goes.
		update_post_meta( $pid, '_wk_m_applied', current_time( 'mysql' ) );
		if ( $v['category'] ) {
			wp_set_object_terms( $pid, $v['category'], self::TAX );
		}
		$logo = self::upload_image( 'wk_logo', $pid );
		if ( $logo && ! is_wp_error( $logo ) ) {
			set_post_thumbnail( $pid, $logo );
		}
		set_transient( self::visitor(), $hits + 1, HOUR_IN_SECONDS );

		$s = self::settings();
		/* translators: %s: business name */
		wp_mail( $s['notify'], sprintf( __( 'Nueva solicitud de membresía: %s', 'wakoo' ), $v['name'] ),
			sprintf( "%s\n%s · %s\n%s\n\n%s\n\n%s", $v['name'], $v['contact'], $v['email'], $v['address'], $v['description'], admin_url( 'admin.php?page=' . self::MENU ) ),
			[ 'Reply-To: ' . $v['email'] ] );
		$conf = self::form_conf( $in['wk_form'] ?? '' );
		if ( ! empty( $conf['receipt'] ) ) {
			wp_mail( $v['email'], $conf['receipt_subject'] ?: get_bloginfo( 'name' ), $conf['receipt'] . "\n\n" . home_url( '/' ) );
		}
		self::back( $back, [ 'wk_member' => 'sent' ] );
	}

	private static function form_conf( $key ) {
		$reg = (array) get_option( self::OPTION . '_forms', [] );
		$key = sanitize_key( $key );
		return isset( $reg[ $key ] ) && is_array( $reg[ $key ] ) ? $reg[ $key ] : [];
	}

	/**
	 * Stores one uploaded image as an attachment of $pid. Returns the attachment id,
	 * 0 when the field is empty, or WP_Error when the file is not a real image.
	 */
	public static function upload_image( $field, $pid, $index = null ) {
		// phpcs:disable WordPress.Security.ValidatedSanitizedInput, WordPress.Security.NonceVerification -- callers check the nonce.
		if ( empty( $_FILES[ $field ] ) ) {
			return 0;
		}
		$f = $_FILES[ $field ];
		if ( null !== $index ) {
			$f = [ 'name' => $f['name'][ $index ] ?? '', 'type' => $f['type'][ $index ] ?? '', 'tmp_name' => $f['tmp_name'][ $index ] ?? '', 'error' => $f['error'][ $index ] ?? UPLOAD_ERR_NO_FILE, 'size' => $f['size'][ $index ] ?? 0 ];
		}
		// phpcs:enable
		if ( empty( $f['name'] ) || UPLOAD_ERR_NO_FILE === (int) $f['error'] ) {
			return 0;
		}
		if ( UPLOAD_ERR_OK !== (int) $f['error'] || $f['size'] > self::MAX_IMG ) {
			return new \WP_Error( 'upload', __( 'La imagen no se pudo subir (máximo 5 MB).', 'wakoo' ) );
		}
		$mimes = [ 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'gif' => 'image/gif' ];
		$check = wp_check_filetype_and_ext( $f['tmp_name'], $f['name'], $mimes );
		if ( empty( $check['type'] ) || ! @getimagesize( $f['tmp_name'] ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return new \WP_Error( 'type', __( 'Solo se aceptan imágenes JPG, PNG, WebP o GIF.', 'wakoo' ) );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$moved = wp_handle_upload( $f, [ 'test_form' => false, 'mimes' => $mimes ] );
		if ( isset( $moved['error'] ) ) {
			return new \WP_Error( 'upload', $moved['error'] );
		}
		$aid = wp_insert_attachment( [ 'post_mime_type' => $moved['type'], 'post_title' => sanitize_file_name( pathinfo( $f['name'], PATHINFO_FILENAME ) ), 'post_status' => 'inherit', 'post_author' => (int) get_post_field( 'post_author', $pid ) ], $moved['file'], $pid );
		if ( is_wp_error( $aid ) ) {
			return $aid;
		}
		wp_update_attachment_metadata( $aid, wp_generate_attachment_metadata( $aid, $moved['file'] ) );
		update_post_meta( $aid, '_wp_attachment_image_alt', get_the_title( $pid ) );
		return (int) $aid;
	}

	/* ---------------------------------------------------------------- approval */

	/** Approves a pending profile: user account, published profile, welcome email. */
	public static function approve( $pid ) {
		$p = get_post( $pid );
		if ( ! $p || self::CPT !== $p->post_type ) {
			return new \WP_Error( 'missing', __( 'Solicitud no encontrada.', 'wakoo' ) );
		}
		$email = (string) get_post_meta( $pid, '_wk_m_account', true );
		$user  = $email ? get_user_by( 'email', $email ) : false;
		if ( ! $user ) {
			if ( ! is_email( $email ) ) {
				return new \WP_Error( 'email', __( 'La solicitud no tiene un email válido.', 'wakoo' ) );
			}
			$login = sanitize_user( current( explode( '@', $email ) ), true ) ?: 'member';
			$base  = $login;
			for ( $i = 2; username_exists( $login ); $i++ ) {
				$login = $base . $i;
			}
			$uid = wp_insert_user( [
				'user_login'   => $login,
				'user_email'   => $email,
				'user_pass'    => wp_generate_password( 24 ),
				'display_name' => (string) get_post_meta( $pid, '_wk_m_contact', true ) ?: $p->post_title,
				'role'         => self::ROLE,
			] );
			if ( is_wp_error( $uid ) ) {
				return $uid;
			}
			$user = get_user_by( 'id', $uid );
		} elseif ( ! user_can( $user, 'edit_posts' ) ) {
			$user->add_role( self::ROLE );
		}
		wp_update_post( [ 'ID' => $pid, 'post_status' => 'publish', 'post_author' => $user->ID ] );
		foreach ( (array) get_children( [ 'post_parent' => $pid, 'post_type' => 'attachment', 'fields' => 'ids' ] ) as $aid ) {
			wp_update_post( [ 'ID' => $aid, 'post_author' => $user->ID ] );
		}
		update_post_meta( $pid, '_wk_m_approved', current_time( 'mysql' ) );
		// Wakoo Idiomas: the profile speaks the language of the template that draws it.
		$tpl_lang = (string) get_post_meta( (int) self::settings()['template'], '_wakoo_lang', true );
		if ( $tpl_lang ) {
			update_post_meta( $pid, '_wakoo_lang', $tpl_lang );
		}
		delete_post_meta( $pid, '_wk_m_rejected' );

		$key  = get_password_reset_key( $user );
		$pass = is_wp_error( $key ) ? wp_lostpassword_url() : network_site_url( 'wp-login.php?action=rp&key=' . $key . '&login=' . rawurlencode( $user->user_login ), 'login' );
		$s    = self::settings();
		$acc  = $s['account'] ? get_permalink( $s['account'] ) : home_url( '/' );
		/* translators: %s: site name */
		$subject = sprintf( __( '¡Bienvenido a %s! Tu membresía está aprobada', 'wakoo' ), get_bloginfo( 'name' ) );
		$body    = sprintf(
			/* translators: 1: business name 2: user login 3: set-password link 4: account page 5: public profile */
			__( "Hola:\n\nHemos aprobado la membresía de %1\$s.\n\nTu usuario: %2\$s\nElige tu contraseña aquí: %3\$s\n\nDespués entra en tu cuenta para completar tu perfil (logo, galería, descripción y ubicación): %4\$s\n\nTu perfil público: %5\$s\n\nWelcome! Your membership has been approved. Use the links above to set your password and complete your profile.", 'wakoo' ),
			$p->post_title, $user->user_login, $pass, $acc, get_permalink( $pid )
		);
		wp_mail( $user->user_email, $subject, $body );
		return $user->ID;
	}

	public static function reject( $pid, $notify = true ) {
		$p = get_post( $pid );
		if ( ! $p || self::CPT !== $p->post_type ) {
			return;
		}
		wp_update_post( [ 'ID' => $pid, 'post_status' => 'draft' ] );
		update_post_meta( $pid, '_wk_m_rejected', current_time( 'mysql' ) );
		$email = (string) get_post_meta( $pid, '_wk_m_account', true );
		if ( $notify && is_email( $email ) ) {
			/* translators: %s: site name */
			wp_mail( $email, sprintf( __( 'Tu solicitud en %s', 'wakoo' ), get_bloginfo( 'name' ) ),
				__( "Hola:\n\nGracias por tu interés. Por ahora no podemos aprobar tu solicitud de membresía. Si crees que es un error, responde a este email.\n\nThank you for your interest. We cannot approve your membership application at this time.", 'wakoo' ) );
		}
	}

	/* ---------------------------------------------------------------- member editing (front end) */

	public static function save_profile() {
		$back = isset( $_POST['back'] ) ? esc_url_raw( wp_unslash( $_POST['back'] ) ) : wp_get_referer();
		if ( ! isset( $_POST['_wknonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wknonce'] ) ), self::NONCE . '_save' ) ) {
			self::back( $back, [ 'wk_member' => 'expired' ] );
		}
		$pid = self::profile_of( get_current_user_id() );
		if ( ! $pid || ! current_user_can( 'read' ) ) {
			self::back( $back, [ 'wk_member' => 'denied' ] );
		}
		$in   = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized field by field below.
		$name = sanitize_text_field( $in['wk_name'] ?? '' );
		$desc = sanitize_textarea_field( $in['wk_description'] ?? '' );
		$upd  = [ 'ID' => $pid, 'post_content' => $desc, 'post_excerpt' => wp_trim_words( $desc, 30, '…' ) ];
		if ( '' !== $name ) {
			$upd['post_title'] = $name;
		}
		wp_update_post( $upd );
		$clean = [
			'tagline' => 'sanitize_text_field', 'contact' => 'sanitize_text_field', 'email' => 'sanitize_email', 'phone' => 'sanitize_text_field',
			'website' => 'esc_url_raw', 'address' => 'sanitize_text_field', 'facebook' => 'esc_url_raw', 'instagram' => 'esc_url_raw',
		];
		foreach ( $clean as $k => $fn ) {
			if ( isset( $in[ 'wk_' . $k ] ) ) {
				update_post_meta( $pid, '_wk_m_' . $k, call_user_func( $fn, $in[ 'wk_' . $k ] ) );
			}
		}
		if ( isset( $in['wk_category'] ) ) {
			$cat = sanitize_text_field( $in['wk_category'] );
			wp_set_object_terms( $pid, '' === $cat ? [] : $cat, self::TAX );
		}
		$errors = 0;
		$logo   = self::upload_image( 'wk_logo', $pid );
		if ( is_wp_error( $logo ) ) {
			$errors++;
		} elseif ( $logo ) {
			$old = get_post_thumbnail_id( $pid );
			set_post_thumbnail( $pid, $logo );
			if ( $old && (int) get_post_field( 'post_parent', $old ) === $pid ) {
				wp_delete_attachment( $old, true );
			}
		}
		// Gallery: remove the ticked images (only this profile's own uploads), then add the new ones.
		$gallery = array_map( 'intval', (array) get_post_meta( $pid, '_wk_m_gallery', true ) );
		$remove  = array_map( 'intval', (array) ( $in['wk_remove'] ?? [] ) );
		foreach ( array_intersect( $gallery, $remove ) as $aid ) {
			if ( (int) get_post_field( 'post_parent', $aid ) === $pid ) {
				wp_delete_attachment( $aid, true );
			}
		}
		$gallery = array_values( array_diff( $gallery, $remove ) );
		$max     = max( 1, (int) self::settings()['max_gallery'] );
		$count   = isset( $_FILES['wk_gallery']['name'] ) && is_array( $_FILES['wk_gallery']['name'] ) ? count( $_FILES['wk_gallery']['name'] ) : 0; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		for ( $i = 0; $i < $count && count( $gallery ) < $max; $i++ ) {
			$aid = self::upload_image( 'wk_gallery', $pid, $i );
			if ( is_wp_error( $aid ) ) {
				$errors++;
			} elseif ( $aid ) {
				$gallery[] = $aid;
			}
		}
		update_post_meta( $pid, '_wk_m_gallery', $gallery );
		self::back( $back, [ 'wk_member' => $errors ? 'saved_errors' : 'saved' ] );
	}

	/** Members (and only members) stay out of wp-admin; admin-ajax / admin-post keep working. */
	public static function keep_members_out() {
		if ( wp_doing_ajax() || ! is_user_logged_in() || current_user_can( 'edit_posts' ) ) {
			return;
		}
		$u = wp_get_current_user();
		if ( in_array( self::ROLE, (array) $u->roles, true ) && 'admin-post.php' !== ( $GLOBALS['pagenow'] ?? '' ) ) {
			$s = self::settings();
			wp_safe_redirect( $s['account'] ? get_permalink( $s['account'] ) : home_url( '/' ) );
			exit;
		}
	}

	public static function admin_bar( $show ) {
		if ( is_user_logged_in() && ! current_user_can( 'edit_posts' ) && in_array( self::ROLE, (array) wp_get_current_user()->roles, true ) ) {
			return false;
		}
		return $show;
	}

	public static function login_redirect( $to, $requested, $user ) {
		if ( $user instanceof \WP_User && in_array( self::ROLE, (array) $user->roles, true ) && ! $user->has_cap( 'edit_posts' ) ) {
			$s = self::settings();
			if ( $s['account'] && ( ! $requested || false !== strpos( $requested, 'wp-admin' ) ) ) {
				return get_permalink( $s['account'] );
			}
		}
		return $to;
	}

	/* ---------------------------------------------------------------- public profile */

	/** A single profile is drawn by the chosen Elementor template (header, profile widget, footer). */
	public static function template( $file ) {
		if ( ! is_singular( self::CPT ) ) {
			return $file;
		}
		$tpl = (int) self::settings()['template'];
		return __DIR__ . '/templates/' . ( ( $tpl && 'publish' === get_post_status( $tpl ) ) ? 'canvas.php' : 'single.php' );
	}

	public static function json_ld() {
		if ( ! is_singular( self::CPT ) ) {
			return;
		}
		$d = self::data( get_queried_object_id() );
		if ( ! $d ) {
			return;
		}
		$ld = [ '@context' => 'https://schema.org', '@type' => 'LocalBusiness', 'name' => $d['name'], 'url' => $d['url'], 'description' => wp_strip_all_tags( $d['tagline'] ?: $d['description'] ) ];
		if ( $d['logo'] ) { $ld['image'] = wp_get_attachment_image_url( $d['logo'], 'full' ); }
		if ( $d['phone'] ) { $ld['telephone'] = $d['phone']; }
		if ( $d['email'] ) { $ld['email'] = $d['email']; }
		if ( $d['address'] ) { $ld['address'] = [ '@type' => 'PostalAddress', 'streetAddress' => $d['address'] ]; }
		$same = array_values( array_filter( [ $d['website'], $d['facebook'], $d['instagram'] ] ) );
		if ( $same ) { $ld['sameAs'] = $same; }
		echo '<script type="application/ld+json">' . wp_json_encode( $ld, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
	}
}

Module::init();
