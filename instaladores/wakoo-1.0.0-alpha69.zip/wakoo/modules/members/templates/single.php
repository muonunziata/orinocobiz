<?php
/**
 * Single member profile without a chosen template: the theme's header and
 * footer around the "Microperfil (Wakoo)" widget.
 *
 * @package Wakoo
 */

defined( 'ABSPATH' ) || die();

get_header();
echo '<main id="content" class="wk-m-single">';
if ( class_exists( '\Elementor\Plugin' ) ) {
	$wakoo_el = \Elementor\Plugin::$instance->elements_manager->create_element_instance( [ 'id' => 'wkmprof', 'elType' => 'widget', 'widgetType' => 'wakoo-member-profile', 'settings' => [] ] );
	if ( $wakoo_el ) {
		\Elementor\Plugin::$instance->frontend->enqueue_styles();
		$wakoo_el->print_element();
	}
}
echo '</main>';
get_footer();
