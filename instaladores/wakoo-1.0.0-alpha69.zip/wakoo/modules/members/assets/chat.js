( function () {
	'use strict';

	var FAST = 8000, SLOW = 45000; // Poll while the tab is visible / hidden.

	function el( tag, cls, text ) {
		var e = document.createElement( tag );
		if ( cls ) { e.className = cls; }
		if ( text != null ) { e.textContent = text; }
		return e;
	}

	function chat( box ) {
		if ( box.dataset.wakooInit ) { return; }
		box.dataset.wakooInit = '1';
		var cfg = {};
		try { cfg = JSON.parse( box.dataset.config || '{}' ); } catch ( e ) { return; }
		var L = cfg.labels || {}, list = box.querySelector( '.wk-chat__list' ), form = box.querySelector( '.wk-chat__form' ),
			text = form.querySelector( 'textarea' ), file = form.querySelector( 'input[type=file]' ), fileName = form.querySelector( '.wk-chat__file' ),
			send = form.querySelector( '.wk-chat__send' ), err = form.querySelector( '.wk-chat__error' ),
			last = 0, timer = null, busy = false, lang = document.documentElement.lang || undefined;

		function url( extra ) {
			return cfg.api + ( cfg.api.indexOf( '?' ) > -1 ? '&' : '?' ) + 'member=' + cfg.member + '&after=' + last + ( extra || '' );
		}

		function who( m ) {
			if ( m.from === 'admin' ) { return L.admin || m.name; }
			return cfg.me === 'member' ? ( L.member || m.name ) : m.name;
		}

		function bubble( m ) {
			var b = el( 'div', 'wk-chat__msg ' + ( m.from === cfg.me ? 'is-mine' : 'is-theirs' ) );
			var head = el( 'div', 'wk-chat__meta' );
			head.appendChild( el( 'strong', '', who( m ) ) );
			var t = el( 'time', '', new Date( m.time ).toLocaleString( lang, { dateStyle: 'short', timeStyle: 'short' } ) );
			t.dateTime = m.time;
			head.appendChild( t );
			b.appendChild( head );
			if ( m.text ) { b.appendChild( el( 'p', 'wk-chat__text', m.text ) ); }
			if ( m.file && m.file.url ) {
				var a = el( 'a', 'wk-chat__fileLink' );
				a.href = m.file.url; a.target = '_blank'; a.rel = 'noopener';
				if ( m.file.img ) {
					var i = el( 'img' ); i.src = m.file.img; i.alt = m.file.name || ''; a.appendChild( i );
					// Images grow the list after it was scrolled: keep it pinned to the newest message.
					i.addEventListener( 'load', function () { if ( '1' === list.dataset.stick ) { list.scrollTop = list.scrollHeight; } } );
				} else {
					a.textContent = '📄 ' + ( m.file.name || 'PDF' );
				}
				b.appendChild( a );
			}
			return b;
		}

		function add( msgs ) {
			if ( ! msgs || ! msgs.length ) {
				if ( ! last ) { list.innerHTML = ''; list.appendChild( el( 'p', 'wk-chat__empty', L.empty ) ); }
				return;
			}
			var atBottom = list.scrollHeight - list.scrollTop - list.clientHeight < 80, first = ! last;
			if ( first ) { list.innerHTML = ''; }
			msgs.forEach( function ( m ) {
				if ( m.id > last ) { list.appendChild( bubble( m ) ); last = m.id; }
			} );
			var stick = first || atBottom || msgs.some( function ( m ) { return m.from === cfg.me; } );
			list.dataset.stick = stick ? '1' : '0';
			if ( stick ) { list.scrollTop = list.scrollHeight; }
		}

		function request( opts ) {
			opts = opts || {};
			opts.credentials = 'same-origin';
			opts.headers = { 'X-WP-Nonce': cfg.nonce };
			return fetch( opts.url, opts ).then( function ( r ) {
				return r.json().then( function ( j ) { if ( ! r.ok ) { throw j; } return j; } );
			} );
		}

		function poll() {
			clearTimeout( timer );
			if ( busy ) { timer = setTimeout( poll, FAST ); return; }
			request( { url: url() } ).then( function ( j ) { add( j.messages ); } ).catch( function () {} ).then( function () {
				timer = setTimeout( poll, document.hidden ? SLOW : FAST );
			} );
		}

		function showErr( msg ) {
			err.textContent = msg || L.error || '';
			err.hidden = ! msg && ! L.error;
		}

		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			if ( busy || ( ! text.value.trim() && ! ( file.files && file.files.length ) ) ) { return; }
			busy = true; send.disabled = true; err.hidden = true;
			var fd = new FormData();
			fd.append( 'member', cfg.member );
			fd.append( 'after', last );
			fd.append( 'text', text.value );
			if ( file.files && file.files[ 0 ] ) { fd.append( 'file', file.files[ 0 ] ); }
			request( { url: cfg.api, method: 'POST', body: fd } ).then( function ( j ) {
				text.value = ''; file.value = ''; fileName.textContent = '';
				add( j.messages );
			} ).catch( function ( j ) {
				showErr( j && j.message ? j.message : L.error );
			} ).then( function () { busy = false; send.disabled = false; text.focus(); } );
		} );
		text.addEventListener( 'keydown', function ( e ) {
			if ( 'Enter' === e.key && ! e.shiftKey && ! e.isComposing ) { e.preventDefault(); form.requestSubmit ? form.requestSubmit() : form.dispatchEvent( new Event( 'submit' ) ); }
		} );
		file.addEventListener( 'change', function () {
			fileName.textContent = file.files && file.files[ 0 ] ? file.files[ 0 ].name : '';
		} );
		document.addEventListener( 'visibilitychange', function () { if ( ! document.hidden ) { poll(); } } );
		poll();
	}

	function boot() { document.querySelectorAll( '.wk-chat[data-config]' ).forEach( chat ); }
	if ( 'loading' === document.readyState ) { document.addEventListener( 'DOMContentLoaded', boot ); } else { boot(); }
}() );
