( function () {
	'use strict';

	/** Directory: search box + category buttons, filtered in the browser. */
	function directory( root ) {
		if ( root.dataset.wakooInit ) { return; }
		root.dataset.wakooInit = '1';
		var input = root.querySelector( '.wk-m-dir__search' ),
			chips = root.querySelectorAll( '.wk-m-dir__cats .wk-m-chip' ),
			items = root.querySelectorAll( '.wk-m-dir__item' ),
			none = root.querySelector( '.wk-m-dir__none' ),
			pager = root.querySelector( '.wk-m-dir__pages' ),
			per = parseInt( root.dataset.perPage || '0', 10 ),
			page = 1,
			cat = '';

		// Filter, then show one page of the matching cards.
		function apply( reset ) {
			var q = input ? input.value.trim().toLowerCase() : '', match = [];
			if ( reset ) { page = 1; }
			items.forEach( function ( it ) {
				if ( ( ! cat || it.dataset.cat === cat ) && ( ! q || it.dataset.text.indexOf( q ) !== -1 ) ) { match.push( it ); } else { it.hidden = true; }
			} );
			var pages = per ? Math.max( 1, Math.ceil( match.length / per ) ) : 1;
			page = Math.min( page, pages );
			match.forEach( function ( it, i ) { it.hidden = per ? ( i < ( page - 1 ) * per || i >= page * per ) : false; } );
			if ( none ) { none.hidden = match.length > 0; }
			paginate( pages );
		}
		function paginate( pages ) {
			if ( ! pager ) { return; }
			pager.hidden = pages < 2;
			pager.textContent = '';
			if ( pages < 2 ) { return; }
			function btn( label, to, cls, current ) {
				var b = document.createElement( 'button' );
				b.type = 'button';
				b.className = 'wk-m-page ' + ( cls || '' );
				b.textContent = label;
				if ( current ) { b.setAttribute( 'aria-current', 'page' ); }
				if ( to < 1 || to > pages ) { b.disabled = true; }
				b.addEventListener( 'click', function () { page = to; apply( false ); root.scrollIntoView( { block: 'start', behavior: 'smooth' } ); } );
				pager.appendChild( b );
			}
			btn( '← ' + pager.dataset.prev, page - 1, 'wk-m-page--prev' );
			for ( var i = 1; i <= pages; i++ ) { btn( String( i ), i, '', i === page ); }
			btn( pager.dataset.next + ' →', page + 1, 'wk-m-page--next' );
		}
		if ( input ) { input.addEventListener( 'input', function () { apply( true ); } ); }
		chips.forEach( function ( c ) {
			c.addEventListener( 'click', function () {
				cat = c.dataset.cat || '';
				chips.forEach( function ( o ) {
					var on = o === c;
					o.classList.toggle( 'is-on', on );
					o.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
				} );
				apply( true );
			} );
		} );
		if ( per ) { apply( true ); }

		// Listing popup: the card's <template> goes into the widget's <dialog>.
		var pop = root.querySelector( '.wk-m-pop' );
		if ( ! pop ) { return; }
		var box = pop.querySelector( '.wk-m-pop__in' );
		function close() { if ( pop.close ) { pop.close(); } else { pop.removeAttribute( 'open' ); } }
		root.addEventListener( 'click', function ( e ) {
			var open = e.target.closest( '.wk-m-item__open' );
			if ( ! open || ! root.contains( open ) ) { return; }
			var tpl = open.closest( '.wk-m-item' ).querySelector( '.wk-m-pop__tpl' );
			if ( ! tpl ) { return; }
			box.textContent = '';
			box.appendChild( tpl.content.cloneNode( true ) );
			if ( pop.showModal ) { pop.showModal(); } else { pop.setAttribute( 'open', '' ); }
		} );
		pop.addEventListener( 'click', function ( e ) {
			if ( e.target === pop || e.target.closest( '.wk-m-pop__close' ) ) { close(); return; }
			var th = e.target.closest( '.wk-m-pop__thumb' );
			if ( ! th ) { return; }
			box.querySelector( '.wk-m-pop__main' ).src = th.dataset.full;
			box.querySelectorAll( '.wk-m-pop__thumb' ).forEach( function ( t ) { t.classList.toggle( 'is-on', t === th ); } );
		} );
	}

	/** File pickers: show the chosen file name(s) in the page's language. */
	document.addEventListener( 'change', function ( e ) {
		var input = e.target;
		if ( ! input.classList || ! input.classList.contains( 'wk-m-file__input' ) ) { return; }
		var name = input.parentNode.querySelector( '.wk-m-file__name' );
		if ( ! name ) { return; }
		var files = Array.prototype.map.call( input.files || [], function ( f ) { return f.name; } );
		name.textContent = files.length ? files.join( ', ' ) : name.dataset.none;
	} );

	function boot( scope ) {
		( scope || document ).querySelectorAll( '.wk-m-dir' ).forEach( directory );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', function () { boot(); } );
	} else {
		boot();
	}
	if ( window.jQuery ) {
		jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend && elementorFrontend.hooks ) {
				[ 'wakoo-member-directory', 'wakoo-member-profile' ].forEach( function ( n ) {
					elementorFrontend.hooks.addAction( 'frontend/element_ready/' + n + '.default', function ( $el ) { boot( $el[ 0 ] ); } );
				} );
			}
		} );
	}
}() );
