( function () {
	'use strict';

	if ( ! window.Lenis ) { return; }
	// Never hijack scrolling inside the Elementor editor.
	if ( document.body && document.body.classList.contains( 'elementor-editor-active' ) ) { return; }
	// Respect the visitor's reduced-motion preference.
	if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) { return; }

	var LenisCtor = window.Lenis;
	if ( LenisCtor && LenisCtor.default ) { LenisCtor = LenisCtor.default; }

	var lenis;
	try {
		lenis = new LenisCtor( {
			duration: 1.1,
			smoothWheel: true,
			easing: function ( t ) { return Math.min( 1, 1.001 - Math.pow( 2, -10 * t ) ); },
			// Boxes with their own scrollbar (panels, sheets, chats, menus…) keep the wheel: Lenis would scroll the page instead.
			prevent: function ( node ) {
				if ( ! node || 1 !== node.nodeType || node === document.body || node === document.documentElement ) { return false; }
				var cs = window.getComputedStyle( node );
				return ( /(auto|scroll|overlay)/.test( cs.overflowY ) && node.scrollHeight > node.clientHeight + 1 ) ||
					( /(auto|scroll|overlay)/.test( cs.overflowX ) && node.scrollWidth > node.clientWidth + 1 );
			},
		} );
	} catch ( e ) {
		return;
	}
	window.wakooLenis = lenis;

	function raf( time ) {
		lenis.raf( time );
		requestAnimationFrame( raf );
	}
	requestAnimationFrame( raf );

	// Eased anchor-link jumps.
	document.addEventListener( 'click', function ( e ) {
		var a = e.target.closest ? e.target.closest( 'a[href*="#"]' ) : null;
		if ( ! a ) { return; }
		var href = a.getAttribute( 'href' ) || '';
		var hash = href.indexOf( '#' ) >= 0 ? href.slice( href.indexOf( '#' ) ) : '';
		if ( hash.length < 2 ) { return; }
		// Only handle same-page anchors.
		if ( href.indexOf( '#' ) > 0 && a.pathname !== window.location.pathname ) { return; }
		var target;
		try { target = document.querySelector( hash ); } catch ( err ) { return; }
		if ( ! target ) { return; }
		e.preventDefault();
		lenis.scrollTo( target, { offset: 0 } );
	} );
}() );
