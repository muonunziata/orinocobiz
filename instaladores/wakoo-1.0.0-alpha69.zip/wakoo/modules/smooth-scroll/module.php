<?php
/**
 * Wakoo: site-wide smooth scroll.
 *
 * Adds momentum/eased scrolling to the whole site with Lenis (MIT, bundled in
 * vendor/ with CREDITS.txt). On by default and switchable from Wakoo → Scroll
 * suave. Runs only on the front end (never inside the Elementor editor) and is
 * disabled automatically when the visitor prefers reduced motion. No GSAP.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Smooth_Scroll;

defined( 'ABSPATH' ) || die();

class Module {

	const OPTION = 'wakoo_smooth_on';

	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ], 20 );
		add_action( 'admin_init', [ __CLASS__, 'settings' ] );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue' ], 20 );
	}

	public static function enabled() {
		$on = ( '0' !== get_option( self::OPTION, '1' ) );
		return (bool) apply_filters( 'wakoo_smooth_scroll_enabled', $on );
	}

	public static function enqueue() {
		if ( ! self::enabled() ) {
			return;
		}
		wp_enqueue_style( 'wakoo-smooth', WAKOO_MODULES_URL . 'smooth-scroll/assets/smooth.css', [], WAKOO_VERSION );
		wp_enqueue_script( 'wakoo-lenis', WAKOO_MODULES_URL . 'smooth-scroll/vendor/lenis.min.js', [], '1.1.13', true );
		wp_enqueue_script( 'wakoo-smooth', WAKOO_MODULES_URL . 'smooth-scroll/assets/smooth.js', [ 'wakoo-lenis' ], WAKOO_VERSION, true );
	}

	public static function menu() {
		add_submenu_page( 'wakoo-seo', __( 'Scroll suave', 'wakoo' ), __( 'Scroll suave', 'wakoo' ), 'manage_options', 'wakoo-smooth', [ __CLASS__, 'page' ] );
	}

	public static function settings() {
		register_setting( 'wakoo_smooth_group', self::OPTION, [
			'type'              => 'string',
			'sanitize_callback' => function ( $v ) { return $v ? '1' : '0'; },
			'default'           => '1',
		] );
	}

	public static function page() {
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Scroll suave de Wakoo', 'wakoo' ); ?></h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'wakoo_smooth_group' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Desplazamiento suave', 'wakoo' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="<?php echo esc_attr( self::OPTION ); ?>" value="1" <?php checked( self::enabled() ); ?>>
								<?php esc_html_e( 'Activar el scroll suave en todo el sitio', 'wakoo' ); ?>
							</label>
							<p class="description"><?php esc_html_e( 'Añade un desplazamiento con inercia a toda la web y suaviza los enlaces de anclaje. No se aplica dentro del editor y se desactiva solo si el visitante prefiere menos movimiento.', 'wakoo' ); ?></p>
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}
}

Module::init();
