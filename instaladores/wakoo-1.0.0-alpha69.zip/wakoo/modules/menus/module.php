<?php
/**
 * Wakoo Menus: a mega-menu and off-canvas menu widget, built on a normal
 * WordPress menu (own code — Happy's nav widget stays as is).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Menus;

defined( 'ABSPATH' ) || die();

class Module {

	public static function init() {
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'assets' ] );
	}

	public static function register_widget( $wm ) {
		require_once __DIR__ . '/widget.php';
		$wm->register( new Widget() );
	}

	public static function assets() {
		wp_register_script( 'wakoo-menus', WAKOO_MODULES_URL . 'menus/assets/menus.js', [], WAKOO_VERSION, true );
		wp_register_style( 'wakoo-menus', WAKOO_MODULES_URL . 'menus/assets/menus.css', [], WAKOO_VERSION );
	}

	/** Menus available for the widget control. */
	public static function menu_options() {
		$out = [ '' => __( '— Selecciona un menú —', 'wakoo' ) ];
		foreach ( wp_get_nav_menus() as $m ) {
			$out[ $m->term_id ] = $m->name;
		}
		return $out;
	}

	/** Build a nested tree from a menu and render it as <ul>. */
	public static function render_tree( $menu_id, $mega = false ) {
		$items = $menu_id ? wp_get_nav_menu_items( $menu_id ) : [];
		if ( ! $items ) {
			return '';
		}
		$by_parent = [];
		foreach ( $items as $it ) {
			$by_parent[ (int) $it->menu_item_parent ][] = $it;
		}
		return self::render_level( $by_parent, 0, $mega, 0 );
	}

	private static function render_level( $by_parent, $parent, $mega, $depth ) {
		if ( empty( $by_parent[ $parent ] ) ) {
			return '';
		}
		$sub_class = 0 === $depth ? 'wakoo-menu__sub' : 'wakoo-menu__sub wakoo-menu__sub--nested';
		$ul_class  = 0 === $depth ? 'wakoo-menu__list' : $sub_class;
		$html = '<ul class="' . esc_attr( $ul_class ) . '">';
		foreach ( $by_parent[ $parent ] as $it ) {
			$children = ! empty( $by_parent[ (int) $it->ID ] );
			$li = 'wakoo-menu__item';
			if ( $children ) {
				$li .= ' has-children';
				if ( $mega && 0 === $depth ) {
					$li .= ' is-mega';
				}
			}
			$url   = esc_url( $it->url );
			$title = esc_html( $it->title );
			$html .= '<li class="' . esc_attr( $li ) . '">';
			$html .= '<a href="' . $url . '"><span>' . $title . '</span>';
			if ( $children ) {
				$html .= '<i class="wakoo-menu__caret" aria-hidden="true"></i>';
			}
			$html .= '</a>';
			if ( $children ) {
				$wrap_open  = ( $mega && 0 === $depth ) ? '<div class="wakoo-menu__mega"><div class="wakoo-menu__mega-inner">' : '';
				$wrap_close = ( $mega && 0 === $depth ) ? '</div></div>' : '';
				$html .= $wrap_open . self::render_level( $by_parent, (int) $it->ID, $mega, $depth + 1 ) . $wrap_close;
			}
			$html .= '</li>';
		}
		$html .= '</ul>';
		return $html;
	}
}

Module::init();
