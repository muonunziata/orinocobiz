( function () {
	'use strict';

	function horiz( nav ) {
		if ( nav.dataset.wakooInit ) { return; }
		nav.dataset.wakooInit = '1';
		var bp = parseInt( nav.getAttribute( 'data-bp' ) || '1024', 10 );
		function apply() {
			if ( window.innerWidth <= bp ) { nav.classList.add( 'is-collapsible' ); }
			else { nav.classList.remove( 'is-collapsible', 'is-open' ); }
		}
		apply();
		window.addEventListener( 'resize', apply );

		var burger = nav.querySelector( '.wakoo-menu__burger' );
		if ( burger ) {
			burger.addEventListener( 'click', function () {
				var open = nav.classList.toggle( 'is-open' );
				burger.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
			} );
		}
		// click to toggle submenus (touch / collapsed)
		nav.querySelectorAll( '.wakoo-menu__item.has-children > a' ).forEach( function ( a ) {
			a.addEventListener( 'click', function ( e ) {
				var collapsed = nav.classList.contains( 'is-collapsible' );
				var touch = window.matchMedia( '(hover: none)' ).matches;
				if ( collapsed || touch ) {
					var li = a.parentNode;
					if ( ! li.classList.contains( 'is-open' ) ) { e.preventDefault(); }
					li.classList.toggle( 'is-open' );
				}
			} );
		} );
	}

	function offcanvas( oc ) {
		if ( oc.dataset.wakooInit ) { return; }
		oc.dataset.wakooInit = '1';
		var toggle = oc.querySelector( '.wakoo-oc__toggle' );
		var closeB = oc.querySelector( '.wakoo-oc__close' );
		var overlay = oc.querySelector( '.wakoo-oc__overlay' );
		function set( open ) {
			oc.classList.toggle( 'is-open', open );
			if ( toggle ) { toggle.setAttribute( 'aria-expanded', open ? 'true' : 'false' ); }
			document.documentElement.style.overflow = open ? 'hidden' : '';
		}
		if ( toggle ) { toggle.addEventListener( 'click', function () { set( ! oc.classList.contains( 'is-open' ) ); } ); }
		if ( closeB ) { closeB.addEventListener( 'click', function () { set( false ); } ); }
		if ( overlay ) { overlay.addEventListener( 'click', function () { set( false ); } ); }
		document.addEventListener( 'keydown', function ( e ) { if ( 'Escape' === e.key ) { set( false ); } } );
		oc.querySelectorAll( '.wakoo-menu__item.has-children > a' ).forEach( function ( a ) {
			a.addEventListener( 'click', function ( e ) {
				var li = a.parentNode;
				if ( ! li.classList.contains( 'is-open' ) ) { e.preventDefault(); }
				li.classList.toggle( 'is-open' );
			} );
		} );
	}

	function boot( scope ) {
		( scope || document ).querySelectorAll( '.wakoo-menu--horizontal' ).forEach( horiz );
		( scope || document ).querySelectorAll( '.wakoo-oc' ).forEach( offcanvas );
	}
	if ( 'loading' === document.readyState ) { document.addEventListener( 'DOMContentLoaded', function () { boot(); } ); }
	else { boot(); }
	if ( window.jQuery ) {
		jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend ) {
				[ 'wakoo-menu.default' ].forEach( function () {} );
				elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-menu.default', function ( $s ) { boot( $s[ 0 ] ); } );
			}
		} );
	}
}() );
