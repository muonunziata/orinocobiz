<?php
/**
 * Wakoo Mega / Off-canvas menu widget.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Menus;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Widget extends Widget_Base {

	public function get_name() { return 'wakoo-menu'; }
	public function get_title() { return __( 'Mega menú / Off-canvas (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-nav-menu'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'menu', 'mega', 'offcanvas', 'nav', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-menus' ]; }
	public function get_style_depends() { return [ 'wakoo-menus' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec', [ 'label' => __( 'Menú', 'wakoo' ) ] );

		$this->add_control( 'menu', [
			'label'   => __( 'Menú de WordPress', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'options' => Module::menu_options(),
			'default' => '',
			'description' => __( 'Crea tus menús en Apariencia → Menús.', 'wakoo' ),
		] );

		$this->add_control( 'mode', [
			'label'   => __( 'Modo', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'horizontal',
			'options' => [
				'horizontal' => __( 'Horizontal', 'wakoo' ),
				'offcanvas'  => __( 'Off-canvas (hamburguesa)', 'wakoo' ),
			],
		] );

		$this->add_control( 'mega', [
			'label'        => __( 'Submenús como megamenú (ancho completo)', 'wakoo' ),
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default'      => '',
			'condition'    => [ 'mode' => 'horizontal' ],
		] );

		$this->add_control( 'breakpoint', [
			'label'   => __( 'Hamburguesa por debajo de (px)', 'wakoo' ),
			'type'    => Controls_Manager::NUMBER,
			'default' => 1024,
			'condition' => [ 'mode' => 'horizontal' ],
		] );

		$this->add_control( 'toggle_label', [
			'label'   => __( 'Texto del botón (off-canvas)', 'wakoo' ),
			'type'    => Controls_Manager::TEXT,
			'default' => __( 'Menú', 'wakoo' ),
			'condition' => [ 'mode' => 'offcanvas' ],
		] );

		$this->end_controls_section();

		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'txt', [
			'label' => __( 'Color del texto', 'wakoo' ), 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .wakoo-menu__list > .wakoo-menu__item > a' => 'color: {{VALUE}};', '{{WRAPPER}} .wakoo-oc__toggle' => 'color: {{VALUE}};' ],
		] );
		$this->add_control( 'accent', [
			'label' => __( 'Color de acento', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#6C5CE7',
			'selectors' => [ '{{WRAPPER}} .wakoo-menu' => '--wakoo-accent: {{VALUE}};' ],
		] );
		$this->end_controls_section();
	}

	protected function render() {
		$s  = $this->get_settings_for_display();
		$id = (int) $s['menu'];
		if ( ! $id ) {
			if ( current_user_can( 'edit_posts' ) ) {
				echo '<div class="wakoo-menu__notice">' . esc_html__( 'Selecciona un menú de WordPress.', 'wakoo' ) . '</div>';
			}
			return;
		}

		if ( 'offcanvas' === $s['mode'] ) {
			$tree = Module::render_tree( $id, false );
			printf(
				'<div class="wakoo-oc"><button class="wakoo-oc__toggle" aria-expanded="false"><i class="wakoo-oc__bars"></i><span>%s</span></button>' .
				'<div class="wakoo-oc__overlay"></div>' .
				'<nav class="wakoo-oc__panel wakoo-menu wakoo-menu--vertical" aria-label="%s"><button class="wakoo-oc__close" aria-label="Cerrar">&times;</button>%s</nav></div>',
				esc_html( $s['toggle_label'] ),
				esc_attr__( 'Menú', 'wakoo' ),
				$tree // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			);
			return;
		}

		$mega = ( 'yes' === ( $s['mega'] ?? '' ) );
		$bp   = (int) ( $s['breakpoint'] ?? 1024 );
		$tree = Module::render_tree( $id, $mega );
		printf(
			'<nav class="wakoo-menu wakoo-menu--horizontal%1$s" style="--wakoo-bp:%2$dpx" data-bp="%2$d">' .
			'<button class="wakoo-menu__burger" aria-expanded="false" aria-label="%3$s"><i></i></button>%4$s</nav>',
			$mega ? ' is-mega' : '',
			$bp,
			esc_attr__( 'Abrir menú', 'wakoo' ),
			$tree // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		);
	}
}
