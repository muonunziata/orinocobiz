<?php
/**
 * Wakoo: live search.
 *
 * A search box that filters the site's content as you type, with fuzzy matching
 * (tolerates typos) powered by Fuse.js (Apache-2.0, bundled in vendor/ with
 * CREDITS.txt). The searchable index (title + excerpt + url of published
 * content) is built server-side on demand and cached, then filtered in the
 * browser so results appear instantly. No GSAP.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Search;

defined( 'ABSPATH' ) || die();

class Module {

	const ALLOWED = [ 'post', 'page', 'product' ];

	/** Searchable post types: the built-in ones plus those Wakoo modules add with the `wakoo_search_types` filter. */
	public static function allowed() {
		return array_values( array_unique( array_merge( self::ALLOWED, array_map( 'sanitize_key', (array) apply_filters( 'wakoo_search_types', [] ) ) ) ) );
	}

	public static function init() {
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'assets' ] );
		add_action( 'elementor/frontend/after_register_styles', [ __CLASS__, 'styles' ] );
		add_action( 'wp_ajax_wakoo_search_index', [ __CLASS__, 'ajax_index' ] );
		add_action( 'wp_ajax_nopriv_wakoo_search_index', [ __CLASS__, 'ajax_index' ] );
		add_action( 'save_post', [ __CLASS__, 'bump' ] );
		add_action( 'deleted_post', [ __CLASS__, 'bump' ] );
		add_action( 'trashed_post', [ __CLASS__, 'bump' ] );
	}

	public static function register_widget( $wm ) {
		require_once __DIR__ . '/widget.php';
		$wm->register( new Widget() );
	}

	public static function assets() {
		wp_register_script( 'wakoo-fuse', WAKOO_MODULES_URL . 'search/vendor/fuse.min.js', [], '7.0.0', true );
		wp_register_script( 'wakoo-search', WAKOO_MODULES_URL . 'search/assets/search.js', [ 'wakoo-fuse' ], WAKOO_VERSION, true );
		wp_localize_script( 'wakoo-search', 'WakooSearch', [
			'ajax'  => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'wakoo_search' ),
		] );
	}

	public static function styles() {
		wp_register_style( 'wakoo-search', WAKOO_MODULES_URL . 'search/assets/search.css', [], WAKOO_VERSION );
	}

	/** Cada vez que cambia el contenido se invalida el índice (el número va dentro de la clave de caché). */
	public static function bump() {
		update_option( 'wakoo_search_ver', (int) get_option( 'wakoo_search_ver', 1 ) + 1, false );
	}

	/** A language configured in Wakoo Idiomas (old codes such as "zh" are mapped), or '' when there is no language layer. */
	private static function lang( $code ) {
		if ( '' === $code || ! class_exists( '\Wakoo\Modules\Idiomas\Module' ) ) {
			return '';
		}
		return \Wakoo\Modules\Idiomas\Module::normalize( $code );
	}

	public static function ajax_index() {
		check_ajax_referer( 'wakoo_search', 'nonce' );

		$types = isset( $_REQUEST['types'] ) ? (array) $_REQUEST['types'] : [ 'post', 'page' ];
		$types = array_values( array_intersect( array_map( 'sanitize_key', $types ), self::allowed() ) );
		if ( empty( $types ) ) {
			$types = [ 'post', 'page' ];
		}
		$types  = array_values( array_filter( $types, 'post_type_exists' ) );
		$thumbs = ! empty( $_REQUEST['thumbs'] ) && '0' !== $_REQUEST['thumbs'];
		$lang   = self::lang( isset( $_REQUEST['lang'] ) ? sanitize_key( wp_unslash( $_REQUEST['lang'] ) ) : '' );

		$cache_key = 'wakoo_search_idx_' . md5( implode( ',', $types ) . '|' . get_locale() . '|' . $lang . '|' . ( $thumbs ? 1 : 0 ) . '|' . (int) get_option( 'wakoo_search_ver', 1 ) );
		$cached = get_transient( $cache_key );
		if ( false !== $cached ) {
			wp_send_json_success( $cached );
		}

		$args = [
			'post_type'              => $types,
			'post_status'            => 'publish',
			'has_password'           => false,
			'posts_per_page'         => 500,
			'no_found_rows'          => true,
			'ignore_sticky_posts'    => true,
			'update_post_meta_cache' => $thumbs,
			'update_post_term_cache' => false,
		];
		if ( $lang ) {
			// Only the page's language, plus content that has no language (member profiles, older pages).
			// Old codes that mean the same language (e.g. "zh" for "zh-tw") count too.
			$codes = array_values( array_unique( array_merge( [ $lang ], array_keys( \Wakoo\Modules\Idiomas\Module::ALIASES, $lang, true ) ) ) );
			$args['meta_query'] = [ // phpcs:ignore WordPress.DB.SlowDBQuery
				'relation' => 'OR',
				[ 'key' => '_wakoo_lang', 'compare' => 'NOT EXISTS' ],
				[ 'key' => '_wakoo_lang', 'value' => '' ],
				[ 'key' => '_wakoo_lang', 'value' => $codes, 'compare' => 'IN' ],
			];
		}
		// Types that belong to every language (filter `wakoo_search_neutral_types`, e.g. member profiles) skip the language filter.
		$neutral = $lang ? array_values( array_intersect( $types, (array) apply_filters( 'wakoo_search_neutral_types', [] ) ) ) : [];
		$posts   = [];
		$rest    = array_values( array_diff( $types, $neutral ) );
		if ( $rest ) {
			$args['post_type'] = $rest;
			$posts = ( new \WP_Query( $args ) )->posts;
		}
		if ( $neutral ) {
			$args['post_type'] = $neutral;
			unset( $args['meta_query'] );
			$posts = array_merge( $posts, ( new \WP_Query( $args ) )->posts );
		}
		$q = (object) [ 'posts' => $posts ];

		$index = [];
		foreach ( $q->posts as $p ) {
			$excerpt = has_excerpt( $p ) ? get_the_excerpt( $p ) : wp_strip_all_tags( strip_shortcodes( $p->post_content ) );
			$row = [
				't' => html_entity_decode( get_the_title( $p ), ENT_QUOTES ),
				'u' => get_permalink( $p ),
				'e' => wp_trim_words( $excerpt, 28, '' ),
				'y' => $p->post_type,
			];
			if ( $thumbs ) {
				$img = get_the_post_thumbnail_url( $p, 'thumbnail' );
				if ( $img ) { $row['i'] = $img; }
			}
			$index[] = $row;
		}
		wp_reset_postdata();

		set_transient( $cache_key, $index, HOUR_IN_SECONDS );
		wp_send_json_success( $index );
	}
}

Module::init();
