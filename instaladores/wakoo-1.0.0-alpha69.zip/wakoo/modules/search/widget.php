<?php
/**
 * Wakoo live-search widget: inline combobox and/or command palette (Ctrl/Cmd + K).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Search;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

defined( 'ABSPATH' ) || die();

class Widget extends Widget_Base {

	public function get_name() { return 'wakoo-search'; }
	public function get_title() { return __( 'Búsqueda en vivo (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-search'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'search', 'busqueda', 'buscar', 'live', 'paleta', 'ctrl k', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-search' ]; }
	public function get_style_depends() { return [ 'wakoo-search' ]; }

	/** Textos configurables: clave => [ etiqueta del control, valor por defecto ]. */
	private static function labels() {
		return [
			'placeholder' => [ __( 'Texto de ejemplo del buscador', 'wakoo' ), __( 'Buscar…', 'wakoo' ) ],
			'btn'         => [ __( 'Texto del botón de la paleta', 'wakoo' ), __( 'Buscar', 'wakoo' ) ],
			'recent'      => [ __( 'Título «Búsquedas recientes»', 'wakoo' ), __( 'Búsquedas recientes', 'wakoo' ) ],
			'clear'       => [ __( 'Botón «Borrar historial»', 'wakoo' ), __( 'Borrar', 'wakoo' ) ],
			'suggest'     => [ __( 'Título «Sugerencias»', 'wakoo' ), __( 'Prueba con', 'wakoo' ) ],
			'none_t'      => [ __( 'Sin resultados: título (usa {q})', 'wakoo' ), __( 'Sin resultados para «{q}»', 'wakoo' ) ],
			'none_d'      => [ __( 'Sin resultados: ayuda', 'wakoo' ), __( 'Revisa la ortografía o prueba con una palabra más general.', 'wakoo' ) ],
			'links'       => [ __( 'Título de los enlaces rápidos', 'wakoo' ), __( 'Quizá te interese', 'wakoo' ) ],
			'count'       => [ __( 'Contador (usa {n})', 'wakoo' ), __( '{n} resultados', 'wakoo' ) ],
			'hint'        => [ __( 'Ayuda de teclado', 'wakoo' ), __( '↑↓ para moverte · Enter para abrir · Esc para cerrar', 'wakoo' ) ],
			'close'       => [ __( 'Cerrar', 'wakoo' ), __( 'Cerrar', 'wakoo' ) ],
			'loading'     => [ __( 'Cargando…', 'wakoo' ), __( 'Cargando…', 'wakoo' ) ],
			'aria'        => [ __( 'Etiqueta accesible del buscador', 'wakoo' ), __( 'Buscar en el sitio', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec', [ 'label' => __( 'Qué buscar', 'wakoo' ) ] );
		$options = [ 'post' => __( 'Entradas', 'wakoo' ), 'page' => __( 'Páginas', 'wakoo' ) ];
		if ( post_type_exists( 'product' ) ) { $options['product'] = __( 'Productos (WooCommerce)', 'wakoo' ); }
		// Other searchable types added by Wakoo modules: [ post type => label ].
		$options = array_merge( $options, array_intersect_key( (array) apply_filters( 'wakoo_search_type_labels', [] ), array_flip( Module::allowed() ) ) );
		$this->add_control( 'types', [ 'label' => __( 'Buscar en', 'wakoo' ), 'type' => Controls_Manager::SELECT2, 'multiple' => true, 'options' => $options, 'default' => [ 'post', 'page' ] ] );
		$this->add_control( 'max', [ 'label' => __( 'Máx. resultados', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 8, 'min' => 1, 'max' => 30 ] );
		$this->add_control( 'thumbs', [ 'label' => __( 'Mostrar miniatura', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'group', [ 'label' => __( 'Agrupar por tipo', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_look', [ 'label' => __( 'Aspecto y comportamiento', 'wakoo' ) ] );
		$this->add_control( 'mode', [ 'label' => __( 'Mostrar como', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'box', 'options' => [
			'box'     => __( 'Cuadro de búsqueda con lista desplegable', 'wakoo' ),
			'button'  => __( 'Botón que abre la paleta de búsqueda', 'wakoo' ),
			'both'    => __( 'Cuadro y paleta (Ctrl/Cmd + K)', 'wakoo' ),
		] ] );
		$this->add_control( 'hotkey', [ 'label' => __( 'Atajo Ctrl/Cmd + K (y «/»)', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'condition' => [ 'mode!' => 'box' ] ] );
		$this->add_control( 'history', [ 'label' => __( 'Recordar búsquedas recientes (solo en el navegador del visitante)', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'suggestions', [ 'label' => __( 'Sugerencias (separadas por coma)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'label_block' => true, 'default' => '', 'description' => __( 'Se muestran al abrir el buscador vacío.', 'wakoo' ) ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_links', [ 'label' => __( 'Enlaces rápidos (sin resultados)', 'wakoo' ) ] );
		$rep = new Repeater();
		$rep->add_control( 'label', [ 'label' => __( 'Texto', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Contacto', 'wakoo' ), 'label_block' => true ] );
		$rep->add_control( 'url', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL, 'label_block' => true ] );
		$this->add_control( 'quick_links', [ 'label' => __( 'Enlaces', 'wakoo' ), 'type' => Controls_Manager::REPEATER, 'fields' => $rep->get_controls(), 'title_field' => '{{{ label }}}', 'default' => [] ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_text', [ 'label' => __( 'Textos', 'wakoo' ) ] );
		foreach ( self::labels() as $id => $d ) {
			$this->add_control( 'lbl_' . $id, [ 'label' => $d[0], 'type' => Controls_Manager::TEXT, 'label_block' => true, 'default' => $d[1] ] );
		}
		$this->end_controls_section();

		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'accent', [ 'label' => __( 'Color de acento', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}}' => '--wk-s-accent: {{VALUE}};' ] ] );
		$this->add_control( 'width', [ 'label' => __( 'Ancho máximo (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 160, 'max' => 1200, 'selectors' => [ '{{WRAPPER}} .wakoo-search' => 'max-width: {{VALUE}}px;' ] ] );
		$this->add_control( 'radius', [ 'label' => __( 'Redondez (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 40, 'selectors' => [ '{{WRAPPER}}' => '--wk-s-radius: {{VALUE}}px;' ] ] );
		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$types = ! empty( $s['types'] ) ? (array) $s['types'] : [ 'post', 'page' ];
		$types = array_values( array_intersect( array_map( 'sanitize_key', $types ), Module::allowed() ) );
		if ( empty( $types ) ) { $types = [ 'post', 'page' ]; }
		$types = array_values( array_filter( $types, 'post_type_exists' ) );
		$mode  = in_array( $s['mode'] ?? 'box', [ 'box', 'button', 'both' ], true ) ? $s['mode'] : 'box';
		$yes   = static function ( $k, $d = true ) use ( $s ) { return isset( $s[ $k ] ) ? 'yes' === $s[ $k ] : $d; };

		$t = [];
		foreach ( self::labels() as $id => $d ) { $t[ $id ] = isset( $s[ 'lbl_' . $id ] ) ? (string) $s[ 'lbl_' . $id ] : $d[1]; }
		$names = [];
		foreach ( $types as $ty ) { $o = get_post_type_object( $ty ); $names[ $ty ] = $o ? $o->labels->name : $ty; }
		$links = [];
		foreach ( (array) ( $s['quick_links'] ?? [] ) as $l ) {
			$u = esc_url_raw( $l['url']['url'] ?? '', [ 'http', 'https' ] );
			if ( $u && ! empty( $l['label'] ) ) { $links[] = [ sanitize_text_field( $l['label'] ), $u ]; }
		}
		$sug = array_slice( array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'trim', explode( ',', (string) ( $s['suggestions'] ?? '' ) ) ) ) ) ), 0, 8 );
		$cfg = [
			'types' => implode( ',', $types ), 'max' => max( 1, min( 30, (int) ( $s['max'] ?? 8 ) ) ), 'thumbs' => $yes( 'thumbs' ) ? 1 : 0, 'group' => $yes( 'group' ) ? 1 : 0,
			'history' => $yes( 'history' ) ? 1 : 0, 'hotkey' => ( 'box' !== $mode && $yes( 'hotkey' ) ) ? 1 : 0, 'mode' => $mode, 't' => $t, 'names' => $names, 'links' => $links, 'sug' => $sug,
		];
		printf( '<div class="wakoo-search-wrap" data-wakoo-search="%s">', esc_attr( wp_json_encode( $cfg ) ) );
		// Elementos que el JS completa; el campo ya viene en el HTML para que se vea sin esperar.
		if ( 'button' !== $mode ) {
			printf(
				'<div class="wakoo-search" data-types="%s" data-max="%d"><div class="wakoo-search__box"><span class="wakoo-search__icon" aria-hidden="true"></span><input type="search" class="wakoo-search__input" placeholder="%s" autocomplete="off" aria-label="%s"></div></div>',
				esc_attr( implode( ',', $types ) ), (int) $cfg['max'], esc_attr( $t['placeholder'] ), esc_attr( $t['aria'] )
			);
		}
		if ( 'box' !== $mode ) {
			printf( '<button type="button" class="wakoo-search__btn" aria-haspopup="dialog"><span class="wakoo-search__icon" aria-hidden="true"></span><span>%s</span>%s</button>', esc_html( $t['btn'] ), $cfg['hotkey'] ? '<kbd aria-hidden="true">Ctrl K</kbd>' : '' );
		}
		echo '</div>';
	}
}
