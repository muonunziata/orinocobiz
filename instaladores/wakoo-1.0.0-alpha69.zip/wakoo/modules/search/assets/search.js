/*! Wakoo live search: ARIA combobox + command palette (Ctrl/Cmd+K). Original code (GPL-2.0-or-later); fuzzy matching by Fuse.js (Apache-2.0).
 * Interaction patterns follow the W3C WAI-ARIA Authoring Practices "Combobox with listbox popup" and the usual command-palette conventions. */
( function () {
	'use strict';
	var D = document, uid = 0, indexes = {}, palette = null;
	var KEY = 'wakoo_search_recent';

	function h( tag, attrs, kids ) {
		var n = D.createElement( tag );
		Object.keys( attrs || {} ).forEach( function ( k ) {
			var v = attrs[ k ];
			if ( null === v || undefined === v || false === v ) { return; }
			if ( 'class' === k ) { n.className = v; } else if ( 'text' === k ) { n.textContent = v; } else { n.setAttribute( k, true === v ? '' : v ); }
		} );
		( kids || [] ).forEach( function ( c ) { if ( c ) { n.appendChild( 'string' === typeof c ? D.createTextNode( c ) : c ); } } );
		return n;
	}
	function esc( s ) { return String( s ).replace( /[.*+?^${}()|[\]\\]/g, '\\$&' ); }
	function safeUrl( u ) { return /^(https?:\/\/|\/)/i.test( String( u || '' ) ) ? u : '#'; }
	function lsGet() { try { return JSON.parse( window.localStorage.getItem( KEY ) || '[]' ) || []; } catch ( e ) { return []; } }
	function lsSet( a ) { try { window.localStorage.setItem( KEY, JSON.stringify( a ) ); } catch ( e ) {} }
	function reduced() { return window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches; }

	/** Writes text into el wrapping the query words in <mark> (text nodes only, never HTML). */
	function marked( el, text, q ) {
		el.textContent = '';
		text = String( text || '' );
		var toks = String( q || '' ).toLowerCase().split( /\s+/ ).filter( function ( t ) { return t.length > 1; } );
		if ( ! toks.length ) { el.appendChild( D.createTextNode( text ) ); return el; }
		var re = new RegExp( '(' + toks.map( esc ).join( '|' ) + ')', 'ig' ), last = 0, m;
		while ( ( m = re.exec( text ) ) ) {
			if ( ! m[ 0 ].length ) { re.lastIndex++; continue; }
			if ( m.index > last ) { el.appendChild( D.createTextNode( text.slice( last, m.index ) ) ); }
			el.appendChild( h( 'mark', { text: m[ 0 ] } ) );
			last = m.index + m[ 0 ].length;
		}
		if ( last < text.length ) { el.appendChild( D.createTextNode( text.slice( last ) ) ); }
		return el;
	}

	/** Index of the site's content (one request per type set and page; the server caches it). */
	function loadIndex( C ) {
		// Wakoo Idiomas marks each page's language: only that language is searched (plus content without one).
		var lang = document.documentElement.getAttribute( 'data-wakoo-lang' ) || '';
		var k = C.types + '|' + C.thumbs + '|' + lang;
		if ( indexes[ k ] ) { return indexes[ k ]; }
		indexes[ k ] = new Promise( function ( resolve, reject ) {
			if ( ! window.WakooSearch || ! window.Fuse ) { reject(); return; }
			var body = new URLSearchParams();
			body.set( 'action', 'wakoo_search_index' );
			body.set( 'nonce', window.WakooSearch.nonce );
			body.set( 'thumbs', C.thumbs ? '1' : '0' );
			if ( lang ) { body.set( 'lang', lang ); }
			C.types.split( ',' ).forEach( function ( t ) { body.append( 'types[]', t ); } );
			fetch( window.WakooSearch.ajax, { method: 'POST', credentials: 'same-origin', body: body } )
				.then( function ( r ) { return r.json(); } )
				.then( function ( j ) {
					if ( ! j || ! j.success ) { reject(); return; }
					resolve( new window.Fuse( j.data, { keys: [ { name: 't', weight: 0.7 }, { name: 'e', weight: 0.3 } ], threshold: 0.4, ignoreLocation: true, minMatchCharLength: 2 } ) );
				} ).catch( reject );
		} );
		indexes[ k ].catch( function () { delete indexes[ k ]; } );
		return indexes[ k ];
	}

	/**
	 * Search interface bound to an input and a listbox container: results, recent searches, suggestions,
	 * grouping, thumbnails and the keyboard model of an ARIA combobox.
	 */
	function Ui( C, input, popup, onPick, live ) {
		var id = 'wks-s' + ( ++uid ), listId = id + '-list', opts = [], active = -1, fuse = null, q = '';
		var list = h( 'div', { class: 'wakoo-search__list', role: 'listbox', id: listId, 'aria-label': C.t.aria } );
		var status = live || h( 'div', { class: 'wakoo-search__sr', role: 'status', 'aria-live': 'polite' } );
		popup.appendChild( list );
		if ( ! live ) { popup.appendChild( status ); }
		input.setAttribute( 'role', 'combobox' );
		input.setAttribute( 'aria-autocomplete', 'list' );
		input.setAttribute( 'aria-expanded', 'false' );
		input.setAttribute( 'aria-controls', listId );

		function setActive( i, scroll ) {
			if ( active > -1 && opts[ active ] ) { opts[ active ].el.classList.remove( 'is-active' ); opts[ active ].el.setAttribute( 'aria-selected', 'false' ); }
			active = i;
			if ( i > -1 && opts[ i ] ) {
				opts[ i ].el.classList.add( 'is-active' ); opts[ i ].el.setAttribute( 'aria-selected', 'true' );
				input.setAttribute( 'aria-activedescendant', opts[ i ].el.id );
				if ( scroll !== false && opts[ i ].el.scrollIntoView ) { opts[ i ].el.scrollIntoView( { block: 'nearest' } ); }
			} else { input.removeAttribute( 'aria-activedescendant' ); }
		}
		function open() { popup.hidden = false; input.setAttribute( 'aria-expanded', 'true' ); }
		function close() { popup.hidden = true; input.setAttribute( 'aria-expanded', 'false' ); setActive( -1 ); }
		function addOpt( parent, el, act ) { el.id = id + '-o' + opts.length; el.setAttribute( 'role', 'option' ); el.setAttribute( 'aria-selected', 'false' ); var i = opts.length; opts.push( { el: el, act: act } ); el.addEventListener( 'mousemove', function () { if ( active !== i ) { setActive( i, false ); } } ); el.addEventListener( 'click', function ( e ) { e.preventDefault(); act(); } ); parent.appendChild( el ); }
		function heading( text, extra ) { var hd = h( 'div', { class: 'wakoo-search__group', role: 'presentation' }, [ h( 'span', { text: text } ) ] ); if ( extra ) { hd.appendChild( extra ); } list.appendChild( hd ); return hd; }

		function saveRecent( term ) {
			if ( ! C.history ) { return; }
			term = term.trim(); if ( term.length < 2 ) { return; }
			var a = lsGet().filter( function ( x ) { return x.toLowerCase() !== term.toLowerCase(); } ); a.unshift( term ); lsSet( a.slice( 0, 5 ) );
		}

		function renderEmpty() {
			list.textContent = ''; opts = []; active = -1;
			var rec = C.history ? lsGet() : [], sug = C.sug || [];
			if ( ! rec.length && ! sug.length ) { close(); status.textContent = ''; return; }
			if ( rec.length ) {
				var clr = h( 'button', { type: 'button', class: 'wakoo-search__clear', text: C.t.clear, tabindex: '-1' } );
				clr.addEventListener( 'click', function ( e ) { e.preventDefault(); lsSet( [] ); renderEmpty(); input.focus(); } );
				heading( C.t.recent, clr );
				rec.forEach( function ( term ) {
					addOpt( list, h( 'a', { class: 'wakoo-search__opt wakoo-search__opt--term', href: '#' }, [ h( 'span', { class: 'wakoo-search__ico', 'aria-hidden': 'true', text: '↺' } ), h( 'span', { class: 'wakoo-search__t', text: term } ) ] ), function () { input.value = term; run(); input.focus(); } );
				} );
			}
			if ( sug.length ) {
				heading( C.t.suggest );
				sug.forEach( function ( term ) {
					addOpt( list, h( 'a', { class: 'wakoo-search__opt wakoo-search__opt--term', href: '#' }, [ h( 'span', { class: 'wakoo-search__ico', 'aria-hidden': 'true', text: '↗' } ), h( 'span', { class: 'wakoo-search__t', text: term } ) ] ), function () { input.value = term; run(); input.focus(); } );
				} );
			}
			open(); status.textContent = '';
		}

		function resultOpt( hit, term ) {
			var it = hit.item, img = ( C.thumbs && it.i ) ? h( 'img', { class: 'wakoo-search__thumb', src: it.i, alt: '', loading: 'lazy', decoding: 'async' } ) : h( 'span', { class: 'wakoo-search__thumb wakoo-search__thumb--ph', 'aria-hidden': 'true', text: ( it.t || '?' ).charAt( 0 ).toUpperCase() } );
			var body = h( 'span', { class: 'wakoo-search__body' }, [ marked( h( 'span', { class: 'wakoo-search__hit-title' } ), it.t, term ) ] );
			if ( it.e ) { body.appendChild( marked( h( 'span', { class: 'wakoo-search__hit-excerpt' } ), it.e, term ) ); }
			return h( 'a', { class: 'wakoo-search__hit', href: safeUrl( it.u ) }, [ img, body ] );
		}

		function renderHits( hits, term ) {
			list.textContent = ''; opts = []; active = -1;
			if ( ! hits.length ) {
				var box = h( 'div', { class: 'wakoo-search__empty', role: 'presentation' }, [ h( 'strong', { text: String( C.t.none_t ).replace( '{q}', term ) } ), h( 'span', { text: C.t.none_d } ) ] );
				list.appendChild( box );
				if ( C.links && C.links.length ) {
					heading( C.t.links );
					C.links.forEach( function ( l ) { addOpt( list, h( 'a', { class: 'wakoo-search__opt wakoo-search__opt--link', href: safeUrl( l[ 1 ] ) }, [ h( 'span', { class: 'wakoo-search__ico', 'aria-hidden': 'true', text: '→' } ), h( 'span', { class: 'wakoo-search__t', text: l[ 0 ] } ) ] ), function () { location.href = safeUrl( l[ 1 ] ); } ); } );
				} else if ( C.sug && C.sug.length ) {
					heading( C.t.suggest );
					C.sug.forEach( function ( s ) { addOpt( list, h( 'a', { class: 'wakoo-search__opt wakoo-search__opt--term', href: '#' }, [ h( 'span', { class: 'wakoo-search__ico', 'aria-hidden': 'true', text: '↗' } ), h( 'span', { class: 'wakoo-search__t', text: s } ) ] ), function () { input.value = s; run(); input.focus(); } ); } );
				}
				status.textContent = String( C.t.none_t ).replace( '{q}', term );
				open(); return;
			}
			var groups = [], seen = {};
			hits.forEach( function ( x ) { var ty = x.item.y || ''; if ( ! seen[ ty ] ) { seen[ ty ] = { ty: ty, hits: [] }; groups.push( seen[ ty ] ); } seen[ ty ].hits.push( x ); } );
			groups.forEach( function ( g ) {
				var wrap = list;
				if ( C.group && groups.length > 1 ) { var gid = id + '-g' + g.ty; var hd = heading( C.names[ g.ty ] || g.ty ); hd.id = gid; wrap = h( 'div', { role: 'group', 'aria-labelledby': gid } ); list.appendChild( wrap ); }
				g.hits.forEach( function ( x ) { var el = resultOpt( x, term ); addOpt( wrap, el, function () { saveRecent( term ); location.href = el.getAttribute( 'href' ); } ); } );
			} );
			status.textContent = String( C.t.count ).replace( '{n}', hits.length );
			open();
		}

		function run() {
			q = input.value.trim();
			if ( q.length < 2 ) { renderEmpty(); return; }
			if ( ! fuse ) {
				status.textContent = C.t.loading;
				loadIndex( C ).then( function ( f ) { fuse = f; if ( input.value.trim() === q ) { run(); } } ).catch( function () {} );
				return;
			}
			renderHits( fuse.search( q, { limit: C.max } ), q );
		}

		input.addEventListener( 'focus', function () { loadIndex( C ).then( function ( f ) { fuse = f; } ).catch( function () {} ); if ( ! input.value.trim() ) { renderEmpty(); } } );
		input.addEventListener( 'input', run );
		input.addEventListener( 'keydown', function ( e ) {
			var n = opts.length;
			if ( 'ArrowDown' === e.key ) { e.preventDefault(); if ( popup.hidden ) { run(); } if ( n ) { setActive( active + 1 >= n ? 0 : active + 1 ); } }
			else if ( 'ArrowUp' === e.key ) { e.preventDefault(); if ( n ) { setActive( active <= 0 ? n - 1 : active - 1 ); } }
			else if ( 'Home' === e.key && active > -1 ) { e.preventDefault(); setActive( 0 ); }
			else if ( 'End' === e.key && active > -1 ) { e.preventDefault(); setActive( n - 1 ); }
			else if ( 'Enter' === e.key ) {
				if ( active > -1 && opts[ active ] ) { e.preventDefault(); opts[ active ].act(); }
				else if ( n && q.length > 1 && opts[ 0 ] && opts[ 0 ].el.classList.contains( 'wakoo-search__hit' ) ) { e.preventDefault(); opts[ 0 ].act(); }
			}
			else if ( 'Escape' === e.key ) {
				if ( input.value ) { e.preventDefault(); e.stopPropagation(); input.value = ''; run(); } else { close(); }
			}
			else if ( 'Tab' === e.key && ! popup.dataset.keep ) { close(); }
		} );
		return { run: run, close: close, open: open, list: list, focusFirst: function () { setActive( 0 ); }, refresh: function () { if ( input.value.trim().length < 2 ) { renderEmpty(); } else { run(); } } };
	}

	/* ---------------------------------------------------------------- inline combobox */
	function mountBox( wrap, C ) {
		var box = wrap.querySelector( '.wakoo-search' );
		if ( ! box ) { return; }
		var input = box.querySelector( '.wakoo-search__input' );
		var popup = h( 'div', { class: 'wakoo-search__results', hidden: true } );
		box.appendChild( popup );
		var ui = Ui( C, input, popup, null );
		D.addEventListener( 'click', function ( e ) { if ( ! box.contains( e.target ) ) { ui.close(); } } );
	}

	/* ---------------------------------------------------------------- palette (one per page) */
	function openPalette( C, opener ) {
		if ( ! palette ) {
			var ov = h( 'div', { class: 'wakoo-search-pal', hidden: true } );
			var dlg = h( 'div', { class: 'wakoo-search-pal__dlg', role: 'dialog', 'aria-modal': 'true', 'aria-label': C.t.aria } );
			var input = h( 'input', { type: 'search', class: 'wakoo-search__input', placeholder: C.t.placeholder, autocomplete: 'off', 'aria-label': C.t.aria } );
			var popup = h( 'div', { class: 'wakoo-search-pal__pop' } ); popup.dataset.keep = '1';
			var x = h( 'button', { type: 'button', class: 'wakoo-search-pal__x', 'aria-label': C.t.close, text: '×' } );
			var hint = h( 'p', { class: 'wakoo-search-pal__hint', text: C.t.hint } );
			dlg.appendChild( h( 'div', { class: 'wakoo-search-pal__bar' }, [ h( 'span', { class: 'wakoo-search__icon', 'aria-hidden': 'true' } ), input, x ] ) );
			dlg.appendChild( popup ); dlg.appendChild( hint ); ov.appendChild( dlg ); D.body.appendChild( ov );
			var ui = Ui( C, input, popup, null );
			palette = { ov: ov, input: input, ui: ui, opener: null };
			function shut() { ov.hidden = true; D.documentElement.classList.remove( 'wakoo-search-lock' ); ui.close(); if ( palette.opener && D.body.contains( palette.opener ) ) { palette.opener.focus(); } }
			palette.shut = shut;
			x.addEventListener( 'click', shut );
			ov.addEventListener( 'mousedown', function ( e ) { if ( e.target === ov ) { shut(); } } );
			ov.addEventListener( 'keydown', function ( e ) {
				if ( 'Escape' === e.key && ! input.value ) { e.preventDefault(); shut(); return; }
				if ( 'Tab' === e.key ) {
					var f = [ input, x ].concat( [].slice.call( popup.querySelectorAll( 'button.wakoo-search__clear' ) ) );
					var a = D.activeElement, i = f.indexOf( a );
					if ( e.shiftKey ) { f[ ( i <= 0 ? f.length : i ) - 1 ].focus(); } else { f[ ( i + 1 ) % f.length ].focus(); }
					e.preventDefault();
				}
			} );
		}
		palette.opener = opener || D.activeElement;
		palette.ov.hidden = false;
		D.documentElement.classList.add( 'wakoo-search-lock' );
		palette.input.focus();
		palette.ui.refresh();
	}

	function setup( wrap ) {
		if ( wrap.dataset.wakooSearchInit ) { return; }
		wrap.dataset.wakooSearchInit = '1';
		var C = {};
		try { C = JSON.parse( wrap.getAttribute( 'data-wakoo-search' ) || '{}' ); } catch ( e ) { return; }
		C.t = C.t || {}; C.names = C.names || {};
		mountBox( wrap, C );
		var btn = wrap.querySelector( '.wakoo-search__btn' );
		if ( btn ) { btn.addEventListener( 'click', function () { openPalette( C, btn ); } ); }
		if ( C.hotkey ) {
			D.addEventListener( 'keydown', function ( e ) {
				var tag = ( e.target && e.target.tagName ) || '';
				var typing = /^(INPUT|TEXTAREA|SELECT)$/.test( tag ) || ( e.target && e.target.isContentEditable );
				if ( ( ( e.ctrlKey || e.metaKey ) && 'k' === ( e.key || '' ).toLowerCase() ) || ( '/' === e.key && ! typing && ! e.ctrlKey && ! e.metaKey && ! e.altKey ) ) {
					e.preventDefault();
					if ( palette && ! palette.ov.hidden ) { return; }
					openPalette( C, D.activeElement );
				}
			} );
		}
	}

	function boot( scope ) { ( scope || D ).querySelectorAll( '.wakoo-search-wrap' ).forEach( setup ); }

	if ( 'loading' === D.readyState ) { D.addEventListener( 'DOMContentLoaded', function () { boot(); } ); } else { boot(); }
	if ( window.jQuery ) {
		jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend && elementorFrontend.hooks ) {
				elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-search.default', function ( $s ) { boot( $s[ 0 ] ); } );
			}
		} );
	}
}() );
