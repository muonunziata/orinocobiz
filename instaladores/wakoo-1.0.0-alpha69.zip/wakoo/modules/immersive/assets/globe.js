/* Wakoo · Globo 3D (COBE). One loop per globe; pauses off screen; drag to turn. */
(function () {
	'use strict';
	var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	function angles(lat, lng) {
		return [Math.PI - ((lng * Math.PI) / 180 - Math.PI / 2), (lat * Math.PI) / 180];
	}

	function boot(root) {
		if (!root || root.dataset.wakooInit || !window.WakooCobe) { return; }
		root.dataset.wakooInit = '1';
		var cfg = {};
		try { cfg = JSON.parse(root.getAttribute('data-wakoo-globe') || '{}'); } catch (e) { return; }
		var canvas = root.querySelector('canvas');
		var dpr = Math.min(window.devicePixelRatio || 1, 2);
		var size = Math.max(160, canvas.offsetWidth || 400);
		var a = angles(cfg.lat || 0, cfg.lng || 0);
		var phi0 = a[0], theta = Math.max(-0.6, Math.min(0.6, a[1] * 0.8)), drag = 0, start = null, t = 0, visible = true, raf = 0;
		var markers = (cfg.markers || []).map(function (m) {
			return { location: m.location, size: m.size, color: m.main ? cfg.accent : undefined };
		});
		var globe;
		try {
			globe = window.WakooCobe(canvas, {
				devicePixelRatio: dpr, width: size * dpr, height: size * dpr, phi: phi0, theta: theta,
				dark: cfg.dark ? 1 : 0, diffuse: 1.2, mapSamples: 16000, mapBrightness: cfg.dark ? 5 : 8,
				baseColor: cfg.base, markerColor: cfg.mark, glowColor: cfg.glow, arcColor: cfg.accent,
				arcWidth: 0.6, arcHeight: 0.25, markers: markers, arcs: cfg.arcs || [], opacity: 0.95
			});
		} catch (e) { root.classList.add('is-nogl'); return; }
		root.classList.add('is-ready');
		function frame() {
			raf = 0;
			if (!visible) { return; }
			if (!reduce && cfg.spin > 0 && start === null) { t += 0.002 * cfg.spin; }
			var swing = (cfg.swing || 0) * Math.PI / 180;
			var phi = phi0 + drag + (swing ? Math.sin(t) * swing / 2 : 0);
			globe.update({ phi: phi, theta: theta });
			if (!reduce || start !== null) { raf = requestAnimationFrame(frame); }
		}
		frame();
		var io = 'IntersectionObserver' in window ? new IntersectionObserver(function (es) {
			visible = es[0].isIntersecting;
			if (visible && !raf) { raf = requestAnimationFrame(frame); }
		}) : null;
		if (io) { io.observe(root); }
		canvas.addEventListener('pointerdown', function (e) { start = [e.clientX, drag]; canvas.setPointerCapture(e.pointerId); canvas.style.cursor = 'grabbing'; if (!raf) { raf = requestAnimationFrame(frame); } });
		canvas.addEventListener('pointermove', function (e) { if (start) { drag = start[1] + (e.clientX - start[0]) / 160; } });
		var end = function () { start = null; canvas.style.cursor = ''; };
		canvas.addEventListener('pointerup', end);
		canvas.addEventListener('pointercancel', end);
		window.addEventListener('resize', function () {
			var s = Math.max(160, canvas.offsetWidth || size);
			if (Math.abs(s - size) > 4) { size = s; globe.update({ width: s * dpr, height: s * dpr }); if (!raf) { raf = requestAnimationFrame(frame); } }
		});
	}

	function all(ctx) { (ctx || document).querySelectorAll('[data-wakoo-globe]').forEach(boot); }
	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', function () { all(); }); } else { all(); }
	window.addEventListener('elementor/frontend/init', function () {
		if (window.elementorFrontend && elementorFrontend.hooks) {
			elementorFrontend.hooks.addAction('frontend/element_ready/wakoo-globe.default', function ($s) { all($s[0]); });
		}
	});
})();
