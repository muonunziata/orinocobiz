/* Wakoo · Fondo topográfico: animated contour lines (value noise + marching squares), own code. */
(function () {
	'use strict';
	var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	var inEditor = document.body && document.body.classList.contains('elementor-editor-active');

	// Smooth 3D value noise (x, y, time) on a hashed lattice.
	var P = new Uint8Array(512);
	(function () { var p = [], i, j, s = 1337; for (i = 0; i < 256; i++) { p[i] = i; } for (i = 255; i > 0; i--) { s = (s * 16807) % 2147483647; j = s % (i + 1); var t = p[i]; p[i] = p[j]; p[j] = t; } for (i = 0; i < 512; i++) { P[i] = p[i & 255]; } })();
	function fade(t) { return t * t * t * (t * (t * 6 - 15) + 10); }
	function h(x, y, z) { return P[P[P[x & 255] + (y & 255)] + (z & 255)] / 255; }
	function noise(x, y, z) {
		var xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z), xf = x - xi, yf = y - yi, zf = z - zi, u = fade(xf), v = fade(yf), w = fade(zf);
		function l(a, b, t) { return a + t * (b - a); }
		return l(l(l(h(xi, yi, zi), h(xi + 1, yi, zi), u), l(h(xi, yi + 1, zi), h(xi + 1, yi + 1, zi), u), v),
			l(l(h(xi, yi, zi + 1), h(xi + 1, yi, zi + 1), u), l(h(xi, yi + 1, zi + 1), h(xi + 1, yi + 1, zi + 1), u), v), w);
	}
	function field(x, y, z) { return noise(x, y, z) * 0.65 + noise(x * 2.1 + 5, y * 2.1 + 9, z * 1.3) * 0.35; }

	function boot(el) {
		if (el.dataset.wakooTopoInit) { return; }
		el.dataset.wakooTopoInit = '1';
		var cfg = {};
		try { cfg = JSON.parse(el.getAttribute('data-wakoo-topo') || '{}'); } catch (e) { return; }
		var cv = document.createElement('canvas');
		cv.className = 'wk-topo';
		cv.setAttribute('aria-hidden', 'true');
		el.classList.add('wk-has-topo');
		el.insertBefore(cv, el.firstChild);
		var ctx = cv.getContext('2d');
		var W = 0, H = 0, dpr = Math.min(window.devicePixelRatio || 1, 1.5), cell = 14, z = Math.random() * 10, mx = -1, my = -1, visible = true, last = 0, raf = 0;
		function size() { var r = el.getBoundingClientRect(); W = Math.max(1, r.width); H = Math.max(1, r.height); cv.width = W * dpr; cv.height = H * dpr; cv.style.width = W + 'px'; cv.style.height = H + 'px'; cell = W < 700 ? 18 : 14; }
		function draw() {
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			ctx.clearRect(0, 0, W, H);
			if (cfg.grid) {
				ctx.globalAlpha = cfg.alpha * 0.35; ctx.strokeStyle = cfg.color; ctx.lineWidth = 0.5; ctx.beginPath();
				for (var gx = 0; gx < W; gx += 80) { ctx.moveTo(gx + 0.5, 0); ctx.lineTo(gx + 0.5, H); }
				for (var gy = 0; gy < H; gy += 80) { ctx.moveTo(0, gy + 0.5); ctx.lineTo(W, gy + 0.5); }
				ctx.stroke();
			}
			var cols = Math.ceil(W / cell) + 1, rows = Math.ceil(H / cell) + 1, sc = 0.0042, v = new Float32Array(cols * rows), i, j;
			for (j = 0; j < rows; j++) {
				for (i = 0; i < cols; i++) {
					var x = i * cell, y = j * cell, f = field(x * sc, y * sc, z);
					if (mx >= 0) { var d = Math.hypot(x - mx, y - my); f += Math.max(0, 1 - d / 220) * 0.12; }
					v[j * cols + i] = f;
				}
			}
			ctx.strokeStyle = cfg.color; ctx.lineWidth = 1;
			for (var k = 1; k <= cfg.levels; k++) {
				var th = 0.15 + (k / (cfg.levels + 1)) * 0.7;
				ctx.globalAlpha = cfg.alpha * (k % 4 === 0 ? 1 : 0.55);
				ctx.beginPath();
				for (j = 0; j < rows - 1; j++) {
					for (i = 0; i < cols - 1; i++) {
						var a = v[j * cols + i], b = v[j * cols + i + 1], c = v[(j + 1) * cols + i + 1], dd = v[(j + 1) * cols + i];
						var idx = (a > th ? 8 : 0) | (b > th ? 4 : 0) | (c > th ? 2 : 0) | (dd > th ? 1 : 0);
						if (idx === 0 || idx === 15) { continue; }
						var x0 = i * cell, y0 = j * cell;
						var T = [x0 + cell * (th - a) / (b - a), y0], R = [x0 + cell, y0 + cell * (th - b) / (c - b)], B = [x0 + cell * (th - dd) / (c - dd), y0 + cell], L = [x0, y0 + cell * (th - a) / (dd - a)];
						var segs = { 1: [L, B], 2: [B, R], 3: [L, R], 4: [T, R], 5: [L, T, B, R], 6: [T, B], 7: [L, T], 8: [L, T], 9: [T, B], 10: [L, B, T, R], 11: [T, R], 12: [L, R], 13: [B, R], 14: [L, B] }[idx];
						for (var s = 0; s < segs.length; s += 2) { ctx.moveTo(segs[s][0], segs[s][1]); ctx.lineTo(segs[s + 1][0], segs[s + 1][1]); }
					}
				}
				ctx.stroke();
			}
			ctx.globalAlpha = 1;
		}
		function loop(ts) {
			raf = 0;
			if (!visible) { return; }
			if (ts - last > 66) { last = ts; z += 0.0016 * cfg.speed; draw(); }
			raf = requestAnimationFrame(loop);
		}
		size(); draw();
		var still = reduce || inEditor || !cfg.speed;
		if (!still) {
			if ('IntersectionObserver' in window) {
				new IntersectionObserver(function (es) { visible = es[0].isIntersecting; if (visible && !raf) { raf = requestAnimationFrame(loop); } }).observe(el);
			}
			raf = requestAnimationFrame(loop);
			if (cfg.mouse && window.matchMedia('(pointer:fine)').matches) {
				el.addEventListener('pointermove', function (e) { var r = el.getBoundingClientRect(); mx = e.clientX - r.left; my = e.clientY - r.top; });
				el.addEventListener('pointerleave', function () { mx = my = -1; });
			}
		}
		var rt;
		window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(function () { size(); draw(); }, 150); });
	}

	function all() { document.querySelectorAll('[data-wakoo-topo]').forEach(boot); }
	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', all); } else { all(); }
})();
