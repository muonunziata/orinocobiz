<?php
/**
 * Wakoo Inmersivo: technological effects that stay sober (built for institutional sites).
 *
 * - Widget «Globo 3D (Wakoo)»: WebGL globe (COBE, MIT, ~13 KB, bundled) with markers,
 *   optional arcs, auto-rotation, drag to turn, legend in HTML (readable and accessible).
 * - Container extension «Fondo topográfico (Wakoo)» (Advanced tab): animated contour lines
 *   drawn on a canvas behind the container's content, own code (noise + marching squares),
 *   paused when off screen, static with «reduce motion», never in the editor's way.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Immersive;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Module {

	public static function init() {
		add_action( 'elementor/widgets/register', [ __CLASS__, 'widgets' ] );
		add_action( 'elementor/element/container/section_layout/after_section_end', [ __CLASS__, 'controls' ], 21, 2 );
		add_action( 'elementor/frontend/container/before_render', [ __CLASS__, 'before_render' ] );
		add_action( 'elementor/frontend/after_register_scripts', function () {
			$u = WAKOO_MODULES_URL . 'immersive/';
			wp_register_script( 'wakoo-cobe', $u . 'vendor/cobe.js', [], '2.0.1', true );
			wp_register_script( 'wakoo-globe', $u . 'assets/globe.js', [ 'wakoo-cobe' ], WAKOO_VERSION, true );
			wp_register_script( 'wakoo-topo', $u . 'assets/topo.js', [], WAKOO_VERSION, true );
		} );
		add_action( 'elementor/frontend/after_register_styles', function () {
			wp_register_style( 'wakoo-immersive', WAKOO_MODULES_URL . 'immersive/assets/immersive.css', [], WAKOO_VERSION );
		} );
	}

	public static function widgets( $wm ) {
		require_once __DIR__ . '/widget-globe.php';
		$wm->register( new Globe() );
	}

	public static function controls( $el, $args ) {
		$el->start_controls_section( 'wakoo_topo_section', [ 'label' => __( 'Fondo topográfico (Wakoo)', 'wakoo' ), 'tab' => Controls_Manager::TAB_ADVANCED ] );
		$el->add_control( 'wakoo_topo', [
			'label' => __( 'Curvas de nivel animadas', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => '',
			'description' => __( 'Dibuja curvas de nivel que se mueven despacio detrás del contenido. Se detiene fuera de pantalla y queda fija si el visitante prefiere menos movimiento.', 'wakoo' ),
		] );
		$on = [ 'wakoo_topo' => 'yes' ];
		$el->add_control( 'wakoo_topo_color', [ 'label' => __( 'Color de las líneas', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#C5A15B', 'condition' => $on ] );
		$el->add_control( 'wakoo_topo_alpha', [ 'label' => __( 'Opacidad (%)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 5, 'max' => 100, 'default' => 28, 'condition' => $on ] );
		$el->add_control( 'wakoo_topo_levels', [ 'label' => __( 'Número de curvas', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 4, 'max' => 24, 'default' => 12, 'condition' => $on ] );
		$el->add_control( 'wakoo_topo_speed', [ 'label' => __( 'Velocidad (0 = quieto)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0, 'max' => 10, 'step' => 0.5, 'default' => 2, 'condition' => $on ] );
		$el->add_control( 'wakoo_topo_mouse', [ 'label' => __( 'Reaccionar al ratón', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes', 'condition' => $on ] );
		$el->add_control( 'wakoo_topo_grid', [ 'label' => __( 'Retícula técnica', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => '', 'description' => __( 'Añade una retícula fina de coordenadas.', 'wakoo' ), 'condition' => $on ] );
		$el->end_controls_section();
	}

	public static function before_render( $el ) {
		$s = $el->get_settings_for_display();
		if ( 'yes' !== ( $s['wakoo_topo'] ?? '' ) ) { return; }
		$cfg = [
			'color'  => sanitize_hex_color( $s['wakoo_topo_color'] ?? '' ) ?: '#C5A15B',
			'alpha'  => min( 100, max( 5, (int) ( $s['wakoo_topo_alpha'] ?? 28 ) ) ) / 100,
			'levels' => min( 24, max( 4, (int) ( $s['wakoo_topo_levels'] ?? 12 ) ) ),
			'speed'  => min( 10, max( 0, (float) ( $s['wakoo_topo_speed'] ?? 2 ) ) ),
			'mouse'  => 'yes' === ( $s['wakoo_topo_mouse'] ?? '' ),
			'grid'   => 'yes' === ( $s['wakoo_topo_grid'] ?? '' ),
		];
		$el->add_render_attribute( '_wrapper', 'data-wakoo-topo', wp_json_encode( $cfg ) );
		wp_enqueue_script( 'wakoo-topo' );
		wp_enqueue_style( 'wakoo-immersive' );
	}
}

Module::init();
