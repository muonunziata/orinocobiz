<?php
/**
 * Wakoo Custom Code: custom CSS and JavaScript, global or per page.
 *
 * - Global CSS, header JS and footer JS from a settings page (Wakoo → Código).
 * - Per-page CSS and JS from a meta box on pages and posts.
 *
 * Editing is restricted to users who can use unfiltered_html (administrators on
 * a single site), since custom code is powerful. Output is printed verbatim —
 * CSS inside <style>, JS inside <script> — as the author intends.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Custom_Code;

defined( 'ABSPATH' ) || die();

class Module {

	const OPTION    = 'wakoo_custom_code';
	const P_CSS     = '_wakoo_css';
	const P_JS      = '_wakoo_js';
	const NONCE     = 'wakoo_code_box';

	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ], 30 );
		add_action( 'admin_init', [ __CLASS__, 'settings' ] );
		add_action( 'add_meta_boxes', [ __CLASS__, 'meta_box' ] );
		add_action( 'save_post', [ __CLASS__, 'save_meta' ] );

		add_action( 'wp_head', [ __CLASS__, 'head' ], 99 );
		add_action( 'wp_footer', [ __CLASS__, 'footer' ], 99 );
	}

	private static function can_edit() {
		return current_user_can( 'unfiltered_html' ) || current_user_can( 'manage_options' );
	}

	public static function opts() {
		return wp_parse_args( (array) get_option( self::OPTION, [] ), [
			'css' => '', 'js_head' => '', 'js_footer' => '',
		] );
	}

	/* ---- global settings ---- */

	public static function menu() {
		add_submenu_page( 'wakoo-seo', __( 'Código personalizado', 'wakoo' ), __( 'Código', 'wakoo' ), 'unfiltered_html', 'wakoo-code', [ __CLASS__, 'page' ] );
	}

	public static function settings() {
		register_setting( 'wakoo_code_group', self::OPTION, [ __CLASS__, 'sanitize' ] );
	}

	public static function sanitize( $in ) {
		if ( ! self::can_edit() ) {
			return self::opts();
		}
		$in = (array) $in;
		return [
			'css'       => (string) ( $in['css'] ?? '' ),
			'js_head'   => (string) ( $in['js_head'] ?? '' ),
			'js_footer' => (string) ( $in['js_footer'] ?? '' ),
		];
	}

	public static function page() {
		if ( ! self::can_edit() ) {
			return;
		}
		$o = self::opts();
		$ta = function ( $k, $v, $label, $hint ) {
			echo '<tr><th scope="row"><label>' . esc_html( $label ) . '</label><p class="description">' . esc_html( $hint ) . '</p></th>';
			echo '<td><textarea name="' . esc_attr( Module::OPTION . '[' . $k . ']' ) . '" rows="8" style="width:100%;font-family:monospace" spellcheck="false">' . esc_textarea( $v ) . '</textarea></td></tr>';
		};
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Código personalizado (global)', 'wakoo' ); ?></h1>
			<p><?php esc_html_e( 'Se aplica en todo el sitio. No incluyas las etiquetas <style> o <script>, Wakoo las añade.', 'wakoo' ); ?></p>
			<form method="post" action="options.php">
				<?php settings_fields( 'wakoo_code_group' ); ?>
				<table class="form-table" role="presentation">
					<?php
					$ta( 'css', $o['css'], __( 'CSS global', 'wakoo' ), __( 'Reglas CSS para todas las páginas.', 'wakoo' ) );
					$ta( 'js_head', $o['js_head'], __( 'JS en la cabecera', 'wakoo' ), __( 'Se ejecuta pronto, en <head>.', 'wakoo' ) );
					$ta( 'js_footer', $o['js_footer'], __( 'JS en el pie', 'wakoo' ), __( 'Se ejecuta al final (recomendado).', 'wakoo' ) );
					?>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}

	/* ---- per-post box ---- */

	public static function meta_box() {
		if ( ! self::can_edit() ) {
			return;
		}
		foreach ( [ 'post', 'page' ] as $pt ) {
			add_meta_box( 'wakoo_code_box', __( 'Código de esta página (Wakoo)', 'wakoo' ), [ __CLASS__, 'box_html' ], $pt, 'normal', 'low' );
		}
	}

	public static function box_html( $post ) {
		wp_nonce_field( self::NONCE, self::NONCE );
		$css = get_post_meta( $post->ID, self::P_CSS, true );
		$js  = get_post_meta( $post->ID, self::P_JS, true );
		echo '<p><strong>' . esc_html__( 'CSS (solo esta página)', 'wakoo' ) . '</strong></p>';
		echo '<textarea name="wakoo_page_css" rows="6" style="width:100%;font-family:monospace" spellcheck="false">' . esc_textarea( $css ) . '</textarea>';
		echo '<p><strong>' . esc_html__( 'JavaScript (solo esta página, en el pie)', 'wakoo' ) . '</strong></p>';
		echo '<textarea name="wakoo_page_js" rows="6" style="width:100%;font-family:monospace" spellcheck="false">' . esc_textarea( $js ) . '</textarea>';
		echo '<p class="description">' . esc_html__( 'Sin etiquetas <style> o <script>.', 'wakoo' ) . '</p>';
	}

	public static function save_meta( $pid ) {
		if ( ! isset( $_POST[ self::NONCE ] ) || ! wp_verify_nonce( sanitize_key( $_POST[ self::NONCE ] ), self::NONCE ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $pid ) || ! self::can_edit() ) {
			return;
		}
		if ( isset( $_POST['wakoo_page_css'] ) ) {
			update_post_meta( $pid, self::P_CSS, (string) wp_unslash( $_POST['wakoo_page_css'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		}
		if ( isset( $_POST['wakoo_page_js'] ) ) {
			update_post_meta( $pid, self::P_JS, (string) wp_unslash( $_POST['wakoo_page_js'] ) ); // phpcs:ignore
		}
	}

	/* ---- frontend output ---- */

	public static function head() {
		$o = self::opts();
		if ( trim( $o['css'] ) !== '' ) {
			echo "\n<style id=\"wakoo-global-css\">\n" . $o['css'] . "\n</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		if ( is_singular() ) {
			$css = (string) get_post_meta( get_queried_object_id(), self::P_CSS, true );
			if ( trim( $css ) !== '' ) {
				echo "\n<style id=\"wakoo-page-css\">\n" . $css . "\n</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		}
		if ( trim( $o['js_head'] ) !== '' ) {
			echo "\n<script id=\"wakoo-global-js-head\">\n" . $o['js_head'] . "\n</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	public static function footer() {
		$o = self::opts();
		if ( trim( $o['js_footer'] ) !== '' ) {
			echo "\n<script id=\"wakoo-global-js-footer\">\n" . $o['js_footer'] . "\n</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		if ( is_singular() ) {
			$js = (string) get_post_meta( get_queried_object_id(), self::P_JS, true );
			if ( trim( $js ) !== '' ) {
				echo "\n<script id=\"wakoo-page-js\">\n" . $js . "\n</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		}
	}
}

Module::init();
