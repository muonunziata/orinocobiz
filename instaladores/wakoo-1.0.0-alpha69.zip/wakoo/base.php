<?php
/**
 * Plugin base class
 *
 * @package Wakoo
 */
namespace Wakoo\Elementor;

use Elementor\Controls_Manager;
use Elementor\Elements_Manager;

use \Wakoo\Elementor\Classes as Wakoo_Classes; // Code from autoloader

defined( 'ABSPATH' ) || die();

class Base {

	private static $instance = null;

	public $appsero = null;

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'init', [ $this, 'i18n' ] );
		$this->run_autoload();
	}

	public function init() {
		Wakoo_Classes\Extensions_Manager::register_extension_filters();

		$this->include_files();

		// Register custom category
		add_action( 'elementor/elements/categories_registered', [ $this, 'add_category' ] );

		// Register custom controls
		add_action( 'elementor/controls/register', [ $this, 'register_controls' ] );

		add_action( 'init', [ $this, 'include_on_init' ] );


		do_action( 'wakoo_loaded' );
	}

	public function i18n() { // Code from autoloader
		load_plugin_textdomain( 'wakoo', false, dirname( plugin_basename( WAKOO__FILE__ ) ) . '/i18n/' );
	}


	public static function hook_manager() {

		/* Ajax_Handler */

		add_action( 'wp_ajax_wk_post_tab_action', [ Wakoo_Classes\Ajax_Handler::class, 'post_tab' ] );
		add_action( 'wp_ajax_nopriv_wk_post_tab_action', [ Wakoo_Classes\Ajax_Handler::class, 'post_tab' ] );


		/* Icons_Manager */
		add_filter( 'elementor/icons_manager/additional_tabs', [ Wakoo_Classes\Icons_Manager::class, 'add_happy_icons_tab' ] );

		/* Widgets_Manager */
		// legacy support hook
		if( defined('WAKOO_PRO_VERSION') && WAKOO_PRO_VERSION <= '2.7.0' ) {
			add_action( 'elementor/widgets/widgets_registered', [ Wakoo_Classes\Widgets_Manager::class, 'register'] );
		}
		// original hook for register widgets
		add_action('elementor/widgets/register', [ Wakoo_Classes\Widgets_Manager::class, 'register'] );
		add_action('elementor/frontend/before_render', [ Wakoo_Classes\Widgets_Manager::class, 'add_global_widget_render_attributes'] );

		/* Assets_Manager */
		// Frontend scripts
		add_action('wp_enqueue_scripts', [Wakoo_Classes\Assets_Manager::class, 'frontend_register']);
		add_action('wp_enqueue_scripts', [Wakoo_Classes\Assets_Manager::class, 'frontend_enqueue'], 100);
		add_action('elementor/css-file/post/enqueue', [Wakoo_Classes\Assets_Manager::class, 'frontend_enqueue_exceptions']);
		// Edit and preview enqueue
		add_action('elementor/preview/enqueue_styles', [Wakoo_Classes\Assets_Manager::class, 'enqueue_preview_styles']);
		add_action('elementor/preview/enqueue_scripts', [Wakoo_Classes\Assets_Manager::class, 'enqueue_preview_scripts']);
		// Enqueue editor & editorv2 scripts
		add_action('elementor/editor/after_enqueue_scripts', [Wakoo_Classes\Assets_Manager::class, 'editor_enqueue']);
		// Paragraph toolbar registration
		add_filter('elementor/editor/localize_settings', [Wakoo_Classes\Assets_Manager::class, 'add_inline_editing_intermediate_toolbar']);
		if (wk_has_pro() && version_compare(WAKOO_PRO_VERSION, '1.9.0', '<=')) {
			$callback = ['\Wakoo_Pro\Assets_Manager', 'frontend_register'];
			remove_action('wp_enqueue_scripts', $callback);
			add_action('wp_enqueue_scripts', $callback, 0);
		}

		/* Cache_Manager */
		add_action( 'elementor/editor/after_save', [ Wakoo_Classes\Cache_Manager::class, 'cache_widgets' ], 10, 2 );
		add_action( 'after_delete_post', [ Wakoo_Classes\Cache_Manager::class, 'delete_cache' ] );

		/* WPML_Manager */
		add_filter( 'wpml_elementor_widgets_to_translate', [ Wakoo_Classes\WPML_Manager::class, 'add_widgets_to_translate' ] );
		add_action( 'wpml_translation_job_saved', [ Wakoo_Classes\WPML_Manager::class, 'on_translation_job_saved' ], 10, 3 );

		/* Api_Handler */
		if(get_option('wakoo_wizard_cache')){
            delete_option('wakoo_wizard_cache');
        }
        add_action('rest_api_init', [Wakoo_Classes\Api_Handler::class, 'wk_wizard_routes']);
        if(!get_option('wakoo-elementor-x98237938759348573')) {
            delete_option('wakoo_wizard_cache_key');
            update_option('wakoo-elementor-x98237938759348573',1);
        }

		if ( is_admin() ) {
			/* Dashboard */
			add_action( 'admin_menu', [ Wakoo_Classes\Dashboard::class, 'add_menu' ], 21 );
			add_action( 'admin_menu', [ Wakoo_Classes\Dashboard::class, 'update_menu_items' ], 99 );
			add_action( 'admin_enqueue_scripts', [ Wakoo_Classes\Dashboard::class, 'enqueue_scripts' ] );
			add_action( 'wp_ajax_wk_save_dashboard', [ Wakoo_Classes\Dashboard::class, 'save_data' ] );
			add_action( 'admin_init', [ Wakoo_Classes\Dashboard::class, 'activation_redirect' ] );
			add_filter( 'plugin_action_links_' . plugin_basename( WAKOO__FILE__ ), [ Wakoo_Classes\Dashboard::class, 'add_action_links' ] );
			add_action( 'wakoo_save_dashboard_data', [ Wakoo_Classes\Dashboard::class, 'save_widgets_data' ], 1);
			add_action( 'wakoo_save_dashboard_data', [ Wakoo_Classes\Dashboard::class, 'save_features_data' ] );
			add_action( 'wakoo_save_dashboard_data', [ Wakoo_Classes\Dashboard::class, 'save_extensions_data' ] );
			add_action( 'wakoo_save_dashboard_data', [ Wakoo_Classes\Dashboard::class, 'save_credentials_data' ] );
			add_action( 'wakoo_save_dashboard_data', [ Wakoo_Classes\Dashboard::class, 'disable_unused_widget' ], 10);
			add_action( 'in_admin_header', [ Wakoo_Classes\Dashboard::class, 'remove_all_notices' ], PHP_INT_MAX );

			/* Attention_Seeker */

			/* Select2_Handler */
			add_action( 'wp_ajax_wk_process_dynamic_select', [ Wakoo_Classes\Select2_Handler::class, 'process_request' ] );

			/* Dashboard_Widgets */
		}

		if ( is_user_logged_in() ) {
			/* Library_Manager */

			/* Review */

			/* Notice */
			if ( ! ( in_array( 'wakoo-pro/wakoo-pro.php', (array) get_option( 'active_plugins', [] ), true ) ) ) {
			}

			/* Admin_Bar */
			if ( wk_is_adminbar_menu_enabled() ) {
				add_action( 'admin_bar_menu', [Wakoo_Classes\Admin_Bar::class, 'add_toolbar_items'], 500 );
				add_action( 'wp_enqueue_scripts', [Wakoo_Classes\Admin_Bar::class, 'enqueue_assets'] );
				add_action( 'admin_enqueue_scripts', [Wakoo_Classes\Admin_Bar::class, 'enqueue_assets'] );
				add_action( 'wp_ajax_wk_clear_cache', [Wakoo_Classes\Admin_Bar::class, 'clear_cache' ] );
			}

			/* Clone_Handler */
			if ( wk_is_happy_clone_enabled() ) {
				add_action( 'admin_action_wk_duplicate_thing', [ Wakoo_Classes\Clone_Handler::class, 'duplicate_thing' ] );
				add_filter( 'post_row_actions', [ Wakoo_Classes\Clone_Handler::class, 'add_row_actions' ], 10, 2 );
				add_filter( 'page_row_actions', [ Wakoo_Classes\Clone_Handler::class, 'add_row_actions' ], 10, 2 );
			}
		}

	}

	public function include_files() {

		self::hook_manager();
		
		Wakoo_Classes\Theme_Builder::instance();

		if ( is_admin() ) {
			Wakoo_Classes\Updater::init();
		}
	}

	public function include_on_init() {
		Wakoo_Classes\Condition_Manager::instance();
		Wakoo_Classes\Extensions_Manager::init();
	}

	/**
	 * Add custom category.
	 *
	 * @param $elements_manager
	 */
	public function add_category( Elements_Manager $elements_manager ) {
		$elements_manager->add_category(
			'wakoo_category',
			[
				'title' => __( 'Wakoo', 'wakoo' ),
				'icon' => 'far fa-smile',
			]
		);
	}

	/**
	 * Register controls
	 *
	 * @param Controls_Manager $controls_Manager
	 */
	public function register_controls( Controls_Manager $controls_Manager ) {
		if ( ! class_exists( __NAMESPACE__ . '\Extensions\Foreground_Overlay' ) || wk_is_foreground_overlay_enabled() ) {
			$Foreground = __NAMESPACE__ . '\Controls\Group_Control_Foreground';
			$controls_Manager->add_group_control( $Foreground::get_type(), new $Foreground() );
		}

		$Select2 = __NAMESPACE__ . '\Controls\Select2';
		wk_elementor()->controls_manager->register( new $Select2() );

		$Widget_List = __NAMESPACE__ . '\Controls\Widget_List';
		wk_elementor()->controls_manager->register( new $Widget_List() );

		$Text_Stroke = __NAMESPACE__ . '\Controls\Group_Control_Text_Stroke';
		$controls_Manager->add_group_control( $Text_Stroke::get_type(), new $Text_Stroke() );
	}

	protected static function init_classes_aliases() {
		return [
			'Widgets_Manager' => [
				'Wakoo\Elementor\Classes\Widgets_Manager', 'Wakoo\Elementor\Widgets_Manager',
			],
			'Widgets_Cache' => [
				'Wakoo\Elementor\Classes\Widgets_Cache', 'Wakoo\Elementor\Widgets_Cache',
			],
			'Assets_Cache' => [
				'Wakoo\Elementor\Classes\Assets_Cache', 'Wakoo\Elementor\Assets_Cache',
			]
		];
	}

	public static function get_class_name($class_str) {
		$last_slash_pos = strrpos($class_str, '\\');
		if ($last_slash_pos !== false) {
			$class_name = substr($class_str, $last_slash_pos + 1);
		} else {
			$class_name = $class_str; // Fallback if no backslash exists
		}
		return $class_name;
	}

	protected function autoload( $class_name ) {
		if ( 0 !== strpos( $class_name, __NAMESPACE__ ) ) {
			return;
		}

		$relative_class_name = self::get_class_name( $class_name );

		$file_name = strtolower(
			str_replace(
				[ __NAMESPACE__ . '\\', '_', '\\' ], // replace namespace, underscrore & backslash
				[ '', '-', '/' ],
				$class_name
			)
		);

		//For Classes folder class load
		if ( 0 === strpos( $class_name, 'Wakoo\Elementor\Classes\\' ) ) {
			$file = WAKOO_DIR_PATH . '/' . $file_name . '.php';
			if ( ! class_exists( $class_name ) && is_readable( $file ) ) {
				include_once $file;
			}
		}

		//For Controls folder class load
		if ( 0 === strpos( $class_name, 'Wakoo\Elementor\Controls\\' ) ) {
			$file = WAKOO_DIR_PATH . '/' . $file_name . '.php';
			if ( ! class_exists( $class_name ) && is_readable( $file ) ) {
				include_once $file;
			}
		}

		//For Extensions folder class load
		if ( 0 === strpos( $class_name, 'Wakoo\Elementor\Extensions\\' ) ) {
			$file = WAKOO_DIR_PATH . '/' . $file_name . '.php';
			if ( ! class_exists( $class_name ) && is_readable( $file ) ) {
				include_once $file;
			}
		}

		//For Traits folder class load
		if ( 0 === strpos( $class_name, 'Wakoo\Elementor\Traits\\' ) ) {
			$file = WAKOO_DIR_PATH . '/' . $file_name . '.php';
			if ( is_readable( $file ) ) {
				include_once $file;
			}
		}

		//For Widget class load
		if ( 0 === strpos( $class_name, __NAMESPACE__ . '\Widget\\' ) ) {
			$file = WAKOO_DIR_PATH . '/' . str_replace( 'widget', 'widgets', $file_name ) . '/widget.php';
			if ( ! class_exists( $class_name ) && is_readable( $file ) ) {
				include_once $file;
			}
		}

		//For WPML class load
		if ( 0 === strpos( $class_name, 'Wakoo\Elementor\Wpml') ) {
			$file = WAKOO_DIR_PATH . '/' . $file_name . '.php';
			if ( ! class_exists( $class_name ) && is_readable( $file ) ) {
				include_once $file;
			}
		}

		//For class aliases
		if ( array_key_exists( $relative_class_name, self::init_classes_aliases() ) ) {
			$aliases = self::init_classes_aliases();
			class_alias( $aliases[ $relative_class_name ][0], $aliases[ $relative_class_name ][1] );
		}

	}

	public function run_autoload() {
		spl_autoload_register( [ $this, 'autoload' ] );
	}
}
