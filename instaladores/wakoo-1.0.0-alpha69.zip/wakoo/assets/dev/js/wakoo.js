; function haObserveTarget ( target, callback, options = {} ) {
	const observer = new IntersectionObserver( ( entries, observer ) => {
		entries.forEach( entry => {
			if ( entry.isIntersecting ) {
				callback( entry );
			}
		} );
	}, options );

	observer.observe( target );
}
( function ( $ ) {
	'use strict';

	var $window = $( window );

	$.fn.getHappySettings = function () {
		return this.data( 'wakoo-settings' );
	};

	function debounce ( func, wait, immediate ) {
		var timeout;
		return function () {
			var context = this, args = arguments;
			var later = function () {
				timeout = null;
				if ( !immediate ) func.apply( context, args );
			};
			var callNow = immediate && !timeout;
			clearTimeout( timeout );
			timeout = setTimeout( later, wait );
			if ( callNow ) func.apply( context, args );
		};
	}

	function initFilterNav ( $scope, filterFn ) {
		var $filterNav = $scope.find( '.hajs-filter' ),
			defaultFilter = $filterNav.data( 'default-filter' );

		if ( $filterNav.length ) {
			$filterNav.on( 'click.onFilterNav', 'button', function ( event ) {
				event.stopPropagation();

				var $current = $( this );
				$current
					.addClass( 'wk-filter__item--active' )
					.siblings()
					.removeClass( 'wk-filter__item--active' );
				filterFn( $current.data( 'filter' ) );
			} );

			$filterNav.find( '[data-filter="' + defaultFilter + '"]' ).click();
		}
	}

	/**
	 * Initialize magnific lighbox gallery
	 *
	 * @param {$element, selector, isEnabled, key} settings
	 */
	function initPopupGallery ( settings ) {
		settings.$element.on( 'click', settings.selector, function ( event ) {
			event.preventDefault();
		} );

		if ( !$.fn.magnificPopup ) {
			return;
		}

		if ( !settings.isEnabled ) {
			$.magnificPopup.close();
			return;
		}

		var windowWidth = $( window ).width(),
			mobileWidth = elementorFrontendConfig.breakpoints.md,
			tabletWidth = elementorFrontendConfig.breakpoints.lg;

		settings.$element.find( settings.selector ).magnificPopup( {
			key: settings.key,
			type: 'image',
			image: {
				titleSrc: function ( item ) {
					return item.el.attr( 'title' ) ? item.el.attr( 'title' ) : item.el.find( 'img' ).attr( 'alt' );
				}
			},
			gallery: {
				enabled: true,
				preload: [ 1, 2 ]
			},
			zoom: {
				enabled: true,
				duration: 300,
				easing: 'ease-in-out',
				opener: function ( openerElement ) {
					return openerElement.is( 'img' ) ? openerElement : openerElement.find( 'img' );
				}
			},
			disableOn: function () {
				if ( settings.disableOnMobile && windowWidth < mobileWidth ) {
					return false;
				}

				if ( settings.disableOnTablet && windowWidth >= mobileWidth && windowWidth < tabletWidth ) {
					return false;
				}

				return true;
			}
		} );
	}

	var HandleImageCompare = function ( $scope ) {
		var $item = $scope.find( '.hajs-image-comparison' ),
			settings = $item.getHappySettings(),
			fieldMap = {
				on_hover: 'move_slider_on_hover',
				on_swipe: 'move_with_handle_only',
				on_click: 'click_to_move'
			};

		settings[ fieldMap[ settings.move_handle || 'on_swipe' ] ] = true;
		delete settings.move_handle;

		$item.imagesLoaded().done( function () {
			$item.twentytwenty( settings );

			var t = setTimeout( function () {
				$window.trigger( 'resize.twentytwenty' );
				clearTimeout( t );
			}, 400 );
		} );
	};

	// Trigger change for nested widgets
	function triggerChange(el) {
		$window.trigger('ha:nested:change', [ el ]);
	}
	$(document).on(
		'click',
		'.e-n-tab-title, .e-n-accordion-item-title',
		function () {
			triggerChange(this);
		}
	);

	function observeNested() {
		var observer = new MutationObserver(function (mutations) {
			mutations.forEach(function (mutation) {
				if (
					mutation.type === 'attributes' &&
					(mutation.attributeName === 'class' ||
						mutation.attributeName === 'aria-expanded')
				) {
					triggerChange(mutation.target);
				}
			});
		});

		document.querySelectorAll(
			'.e-n-tabs, .e-n-accordion'
		).forEach(function (el) {
			observer.observe(el, {
				attributes: true,
				subtree: true
			});
		});
	};

	$window.on( 'elementor/frontend/init', function () {
		// Call the handlers for the justified widget
		observeNested();

		var ModuleHandler = elementorModules.frontend.handlers.Base;

		var SliderBase = ModuleHandler.extend( {
			bindEvents: function () {
				this.removeArrows();
				this.run();
			},

			removeArrows: function () {
				var _this = this;

				this.elements.$container.on( 'init', function () {
					_this.elements.$container.siblings().hide();
				} );
			},

			getDefaultSettings: function () {
				return {
					autoplay: true,
					arrows: false,
					checkVisible: false,
					container: '.hajs-slick',
					dots: false,
					infinite: true,
					rows: 0,
					slidesToShow: 1,
					prevArrow: $( '<div />' ).append( this.findElement( '.slick-prev' ).clone().show() ).html(),
					nextArrow: $( '<div />' ).append( this.findElement( '.slick-next' ).clone().show() ).html()
				};
			},

			getDefaultElements: function () {
				return {
					$container: this.findElement( this.getSettings( 'container' ) )
				};
			},

			onElementChange: debounce( function () {
				this.elements.$container.slick( 'unslick' );
				this.run();
			}, 200 ),

			getSlickSettings: function () {
				var $rtl = ( $( 'html[dir="rtl"]' ).length == 1 || $( 'body' ).hasClass( 'rtl' ) );
				if ( 'yes' == this.getElementSettings( 'vertical' ) ) {
					$rtl = false; // for vertical direction rtl is off
				}

				// Determine if the widget has the 'wk-slider' class
				var isHaSlider = this.$element.hasClass( 'wk-slider' );

				// Generate the settings object
				var settings = {
					fade: isHaSlider
						? this.getElementSettings( 'slides_transition' ) === 'fade'
						: this.getElementSettings( 'slides_transition' ) === 'fade' &&
						parseInt( this.getElementSettings( 'slides_to_show' ) ) === 1,
					infinite: !!this.getElementSettings( 'loop' ),
					autoplay: !!this.getElementSettings( 'autoplay' ),
					autoplaySpeed: this.getElementSettings( 'autoplay_speed' ),
					speed: this.getElementSettings( 'animation_speed' ),
					centerMode: !!this.getElementSettings( 'center' ),
					vertical: !!this.getElementSettings( 'vertical' ),
					// slidesToScroll: 1,
					rtl: $rtl,
				};

				switch ( this.getElementSettings( 'navigation' ) ) {
					case 'arrow':
						settings.arrows = true;
						break;
					case 'dots':
						settings.dots = true;
						break;
					case 'both':
						settings.arrows = true;
						settings.dots = true;
						break;
				}

				var slides_to_scroll = !!this.getElementSettings( 'slides_to_scroll' );
				settings.slidesToShow = parseInt( this.getElementSettings( 'slides_to_show' ) ) || 1;
				settings.slidesToScroll = slides_to_scroll ? ( parseInt( this.getElementSettings( 'slides_to_show' ) ) || 1 ) : 1;
				settings.responsive = [
					{
						breakpoint: elementorFrontend.config.breakpoints.lg,
						settings: {
							slidesToShow: ( parseInt( this.getElementSettings( 'slides_to_show_tablet' ) ) || settings.slidesToShow ),
							slidesToScroll: slides_to_scroll ? ( parseInt( this.getElementSettings( 'slides_to_show_tablet' ) ) || settings.slidesToShow ) : 1,
						}
					},
					{
						breakpoint: elementorFrontend.config.breakpoints.md,
						settings: {
							slidesToShow: ( parseInt( this.getElementSettings( 'slides_to_show_mobile' ) ) || parseInt( this.getElementSettings( 'slides_to_show_tablet' ) ) ) || settings.slidesToShow,
							slidesToScroll: slides_to_scroll ? ( ( parseInt( this.getElementSettings( 'slides_to_show_mobile' ) ) || parseInt( this.getElementSettings( 'slides_to_show_tablet' ) ) ) || settings.slidesToShow ) : 1,
						}
					}
				];

				return $.extend( {}, this.getSettings(), settings );
			},

			run: function () {
				this.elements.$container.slick( this.getSlickSettings() );
			}
		} );

		var NumberHandler = function ( $scope ) {
			haObserveTarget( $scope[ 0 ], function () {
				var $number = $scope.find( '.wk-number-text' );
				$number.numerator( $number.data( 'animation' ) );
			} );
		};

		var SkillHandler = function ( $scope ) {
			haObserveTarget( $scope[ 0 ], function () {
				$scope.find( '.wk-skill-level' ).each( function () {
					var $current = $( this ),
						$lt = $current.find( '.wk-skill-level-text' ),
						lv = $current.data( 'level' );

					$current.animate( {
						width: lv + '%'
					}, 500 );
					$lt.numerator( {
						toValue: lv + '%',
						duration: 1300,
						onStep: function () {
							$lt.append( '%' );
						}
					} );
				} );
			} );
		};

		var ImageGrid = ModuleHandler.extend( {
			onInit: function () {
				ModuleHandler.prototype.onInit.apply( this, arguments );
				this.run();
				this.runFilter();

				$window.on( 'resize', debounce( this.run.bind( this ), 100 ) );
				// Trigger layout on nested change
				$window.on('ha:nested:change', debounce(this.run.bind(this), 100));
			},

			getLayoutMode: function () {
				var layout = this.getElementSettings( 'layout' );
				return ( layout === 'even' ? 'masonry' : layout );
			},

			getDefaultSettings: function () {
				return {
					itemSelector: '.wk-image-grid__item',
					percentPosition: true,
					layoutMode: this.getLayoutMode(),
				};
			},

			getDefaultElements: function () {
				return {
					$container: this.findElement( '.hajs-isotope' )
				};
			},

			getLightBoxSettings: function () {
				return {
					key: 'imagegrid',
					$element: this.$element,
					selector: '.wk-js-lightbox',
					isEnabled: !!this.getElementSettings( 'enable_popup' ),
					disableOnTablet: !!this.getElementSettings( 'disable_lightbox_on_tablet' ),
					disableOnMobile: !!this.getElementSettings( 'disable_lightbox_on_mobile' )
				};
			},

			runFilter: function () {
				var self = this,
					lbSettings = this.getLightBoxSettings();

				initFilterNav( this.$element, function ( filter ) {
					self.elements.$container.isotope( {
						filter: filter
					} );

					if ( filter !== '*' ) {
						lbSettings.selector = filter;
					}

					initPopupGallery( lbSettings );
				} );
			},

			onElementChange: function ( changedProp ) {
				if ( [ 'layout', 'image_height', 'columns', 'image_margin', 'enable_popup' ].indexOf( changedProp ) !== -1 ) {
					this.run();
				}
			},

			run: function () {
				var self = this;

				self.elements
					.$container
					.isotope( self.getDefaultSettings() )
					.imagesLoaded().progress( function () {
						self.elements.$container.isotope( 'layout' );
					} );

				initPopupGallery( self.getLightBoxSettings() );
			}
		} );

		var JustifiedGrid = ModuleHandler.extend( {
			onInit: function () {
				ModuleHandler.prototype.onInit.apply( this, arguments );
				this.run();
				this.runFilter();

				$window.on( 'resize', debounce( this.run.bind( this ), 100 ) );
				// Trigger layout on nested change
				$window.on('ha:nested:change', debounce(this.run.bind(this), 100));
			},

			getDefaultSettings: function () {
				var $defaultSettings = {
					rowHeight: +this.getElementSettings( 'row_height.size' ) || 150,
					lastRow: this.getElementSettings( 'last_row' ),
					margins: +this.getElementSettings( 'margins.size' ),
					captions: !!this.getElementSettings( 'show_caption' )
				};

				var $maxRowHeight = {};
				if ( 'yes' == this.getElementSettings( 'max_row_height' ) ) {
					$maxRowHeight = {
						maxRowHeight: +this.getElementSettings( 'row_height.size' ) || 150,
					};
				}

				return $.extend( $defaultSettings, $maxRowHeight );
			},

			getDefaultElements: function () {
				return {
					$container: this.findElement( '.hajs-justified-grid' )
				};
			},

			getLightBoxSettings: function () {
				return {
					key: 'justifiedgallery',
					$element: this.$element,
					selector: '.wk-js-lightbox',
					isEnabled: !!this.getElementSettings( 'enable_popup' ),
					disableOnTablet: !!this.getElementSettings( 'disable_lightbox_on_tablet' ),
					disableOnMobile: !!this.getElementSettings( 'disable_lightbox_on_mobile' )
				};
			},

			runFilter: function () {
				var self = this,
					lbSettings = this.getLightBoxSettings(),
					settings = {
						lastRow: this.getElementSettings( 'last_row' )
					};

				initFilterNav( self.$element, function ( filter ) {
					if ( filter !== '*' ) {
						settings.lastRow = 'nojustify';
						lbSettings.selector = filter;
					}

					settings.filter = filter;
					self.elements.$container.justifiedGallery( settings );

					initPopupGallery( lbSettings );
				} );
			},

			onElementChange: function ( changedProp ) {
				if ( [ 'row_height', 'max_row_height', 'last_row', 'margins', 'show_caption', 'enable_popup' ].indexOf( changedProp ) !== -1 ) {
					this.run();
				}
			},

			run: function () {
				this.elements
					.$container
					.justifiedGallery( this.getDefaultSettings() );

				initPopupGallery( this.getLightBoxSettings() );
			}
		} );

		// NewsTicker
		var NewsTicker = ModuleHandler.extend( {

			onInit: function () {
				ModuleHandler.prototype.onInit.apply( this, arguments );
				this.wrapper = this.$element.find( '.wk-news-ticker-wrapper' );
				this.run();
			},
			onElementChange: function ( changed_prop ) {
				if ( changed_prop === 'item_space' || changed_prop === 'title_typography_font_size' ) {
					this.run();
				}
			},
			run: function () {
				if ( 0 == this.wrapper.length ) {
					return;
				}
				var wrapper_height = this.wrapper.innerHeight(),
					wrapper_width = this.wrapper.innerWidth(),
					container = this.wrapper.find( '.wk-news-ticker-container' ),
					single_item = container.find( '.wk-news-ticker-item' ),
					scroll_direction = this.wrapper.data( 'scroll-direction' ),
					scroll = "scroll" + scroll_direction + parseInt( wrapper_height ) + parseInt( wrapper_width ),
					duration = this.wrapper.data( 'duration' ),
					direction = 'normal',
					all_title_width = 10;

				var start = { 'transform': 'translateX(0' + wrapper_width + 'px)' },
					end = { 'transform': 'translateX(-101%)' };
				if ( 'right' === scroll_direction ) {
					direction = 'reverse';
				}
				single_item.each( function () {
					all_title_width += $( this ).outerWidth( true );
				} );
				container.css( { 'width': all_title_width, 'display': 'flex' } );
				$.keyframe.define( [ {
					name: scroll,
					'0%': start,
					'100%': end,
				} ] );
				container.playKeyframe( {
					name: scroll,
					duration: duration.toString() + "ms",
					timingFunction: 'linear',
					delay: '0s',
					iterationCount: 'infinite',
					direction: direction,
					fillMode: 'none',
					complete: function () {
					}
				} );
			}
		} );

		// Fun factor
		var FunFactor = function ( $scope ) {
			haObserveTarget( $scope[ 0 ], function () {
				var $fun_factor = $scope.find( '.wk-fun-factor__content-number' );
				$fun_factor.numerator( $fun_factor.data( 'animation' ) );
			} );
		};

		var BarChart = function ( $scope ) {
			haObserveTarget( $scope[ 0 ], function () {
				var $container = $scope.find( '.wk-bar-chart-container' ),
					$chart_canvas = $scope.find( '#wk-bar-chart' ),
					settings = $container.data( 'settings' );

				if ( $container.length ) {
					new Chart( $chart_canvas, settings );
				}
			} );
		};

		//PostTab
		var PostTab = ModuleHandler.extend( {

			onInit: function () {
				ModuleHandler.prototype.onInit.apply( this, arguments );
				this.wrapper = this.$element.find( '.wk-post-tab' );
				this.run();
			},
			run: function () {
				var filter_wrap = this.wrapper.find( '.wk-post-tab-filter' ),
					filter = filter_wrap.find( 'li' ),
					event = this.wrapper.data( 'event' ),
					args = this.wrapper.data( 'query-args' );

				filter.on( event, debounce( function ( e ) {
					e.preventDefault();

					var $self = $( this ),
						term_id = $self.data( "term" ),
						$wrapper = $self.closest( ".wk-post-tab" ),
						content = $wrapper.find( '.wk-post-tab-content' ),
						loading = content.find( '.wk-post-tab-loading' ),
						tab_item = content.find( '.wk-post-tab-item-wrapper' ),
						$content_exist = false;

					if ( 0 === loading.length ) {
						filter.removeClass( 'active' );
						tab_item.removeClass( 'active' );
						$self.addClass( 'active' );

						tab_item.each( function () {
							var $self = $( this ),
								$content_id = $self.data( "term" );
							if ( term_id === $content_id ) {
								$self.addClass( 'active' );
								$content_exist = true;
							}
						} );

						if ( false === $content_exist ) {
							$.ajax( {
								url: WakooLocalize.ajax_url,
								type: 'POST',
								data: {
									action: "wk_post_tab_action",
									security: WakooLocalize.nonce,
									post_tab_query: args,
									term_id: term_id,
								},
								beforeSend: function () {
									content.append( '<span class="wk-post-tab-loading"><i class="eicon-spinner eicon-animation-spin"></i></span>' );
								},
								success: function ( response ) {
									content.find( '.wk-post-tab-loading' ).remove();
									content.append( response );
								},
								error: function ( error ) {
								}
							} );

						}
					}

				}, 200 ) );
			}
		} );


		var DataTable = function ( $scope ) {
			var columnTH = $scope.find( '.wk-table__head-column-cell' );
			var rowTR = $scope.find( '.wk-table__body-row' );

			// Step 1: Handle rowspan by inserting placeholder cells ("nullval")
			rowTR.each( function ( i, tr ) {
				var cells = $( tr ).find( '.wk-table__body-row-cell' );

				cells.each( function ( index, cell ) {
					var $cell = $( cell );
					var rowspan = parseInt( $cell.attr( "rowspan" ), 10 );

					if ( rowspan > 1 ) {
						for ( var j = i + 1; j < i + rowspan && j < rowTR.length; j++ ) {
							var targetRow = $( rowTR ).eq( j );
							var targetCell = targetRow.children().eq( index );

							$( '<td class="wk-table__body-row-cell test">nullval</td>' )
								.insertBefore( targetCell );
						}
					}
				} );
			} );

			// Step 2: Add header labels or remove placeholder cells
			rowTR.each( function ( i, tr ) {
				var cells = $( tr ).find( '.wk-table__body-row-cell' );

				cells.each( function ( index, cell ) {
					var $cell = $( cell );
					var cellContent = $cell.html();

					if ( cellContent.indexOf( "nullval" ) === -1 ) {
						var headerContent = columnTH.eq( index ).html();
						$cell.prepend( '<div class="wk-table__head-column-cell">' + headerContent + '</div>' );
					} else {
						$cell.remove();
					}
				} );
			} );
		};

		//Threesixty Rotation
		var Threesixty_Rotation = function ( $scope ) {
			var wk_circlr = $scope.find( '.wk-threesixty-rotation-inner' );
			var cls = wk_circlr.data( 'selector' );
			var autoplay = wk_circlr.data( 'autoplay' );
			var glass_on = $scope.find( '.wk-threesixty-rotation-magnify' );
			var t360 = $scope.find( '.wk-threesixty-rotation-360img' );
			var zoom = glass_on.data( 'zoom' );

			var playb = $scope.find( '.wk-threesixty-rotation-play' );

			var crl = circlr( cls, {
				play: true,
			} );

			if ( 'on' === autoplay ) {
				var autoplay_btn = $scope.find( '.wk-threesixty-rotation-autoplay' );
				autoplay_btn.on( 'click', function ( el ) {
					el.preventDefault();
					crl.play();
					t360.remove();
				} );
				setTimeout( function () {
					autoplay_btn.trigger( 'click' );
					autoplay_btn.remove();
				}, 1000 );
			} else {
				playb.on( 'click', function ( el ) {
					el.preventDefault();
					var $self = $( this );
					var $i = $self.find( 'i' );
					if ( $i.hasClass( 'hm-play-button' ) ) {
						$i.removeClass( 'hm-play-button' );
						$i.addClass( 'hm-stop' );
						crl.play();
					} else {
						$i.removeClass( 'hm-stop' );
						$i.addClass( 'hm-play-button' );
						crl.stop();
					}
					t360.remove();
				} );
			}

			glass_on.on( 'click', function ( el ) {
				var img_block = $scope.find( 'img' );
				img_block.each( function () {
					var style = $( this ).attr( 'style' );
					if ( -1 !== style.indexOf( "block" ) ) {
						WakooSimplaMagnify( $( this )[ 0 ], zoom );
						glass_on.css( 'display', 'none' );
						t360.remove();
					}
				} );
			} );

			$( document ).on( 'click', function ( e ) {
				var t = $( e.target );
				var magnifier = $scope.find( '.wk-img-magnifier-glass' );
				var i = glass_on.find( 'i' );
				if ( magnifier.length && t[ 0 ] !== i[ 0 ] ) {
					magnifier.remove();
					glass_on.removeAttr( 'style' );
				}
				if ( t[ 0 ] === wk_circlr[ 0 ] ) {
					t360.remove();
				}
			} );

			wk_circlr.on( 'mouseup mousedown touchstart touchend', function ( e ) {
				t360.remove();
			} );

		};

		//Event Calendar
		var Event_Calendar = function ( $scope ) {
			var calendarEl = $scope.find( '.wk-ec' );
			var popup = $scope.find( '.wk-ec-popup-wrapper' );
			var popupClose = $scope.find( ".wk-ec-popup-close" );
			// var events = calendarEl.data('events');
			var initialview = calendarEl.data( 'initialview' );
			var firstday = calendarEl.data( 'firstday' );
			var locale = calendarEl.data( 'locale' );
			var showPopup = calendarEl.data( 'show-popup' );
			var allday_text = calendarEl.data( 'allday-text' );
			var time_format = calendarEl.data( 'time-format' );

			var ECjson = window[ 'HaECjson' + $scope.data( 'id' ) ];
			var events = ECjson;

			if ( 'undefined' == typeof events ) {
				return;
			}

			var option = {
				stickyHeaderDates: false,
				locale: locale,
				headerToolbar: {
					left: "prev,next today",
					center: "title",
					right: "dayGridMonth,timeGridWeek,timeGridDay,listMonth"
				},
				initialView: initialview,
				firstDay: firstday,
				eventTimeFormat: { // like '7pm'
					hour: 'numeric',
					minute: '2-digit',
					meridiem: 'short'
				},
				events: events,

				height: 'auto',

				eventClick: function ( info ) {

					if ( 'yes' == showPopup ) {

						info.jsEvent.preventDefault(); // don't let the browser navigate

						function getTheDate ( timeString ) {
							return new Date( timeString );
						}

						function timeFormat ( date, time_format = 'g:i a' ) {
							// Parse the input time
							var hours = date.getHours();
							var minutes = date.getMinutes();

							var date = new Date();
							date.setHours( hours );
							date.setMinutes( minutes );

							var options = {};
							if ( time_format.includes( 'H' ) ) {
								options.hour = '2-digit';
								options.hour12 = false;
							} else {
								options.hour = 'numeric';
								options.hour12 = true;
								if ( time_format.includes( 'a' ) || time_format.includes( 'A' ) ) {
									options.hour = 'numeric';
								}
							}
							options.minute = '2-digit';

							var formattedTime = new Intl.DateTimeFormat( 'en-US', options ).format( date );

							if ( time_format.includes( 'a' ) ) {
								formattedTime = formattedTime.toLowerCase();
							}

							return formattedTime;
						}

						var todayDateString = info.view.calendar.currentData.currentDate.toString(),
							allDay = info.event.allDay,
							title = info.event.title,
							startDate = info.event.startStr,
							endDate = info.event.endStr,
							guest = info.event.extendedProps.guest,
							location = info.event.extendedProps.location,
							description = info.event.extendedProps.description,
							detailsUrl = info.event.url,
							imageUrl = info.event.extendedProps.image;

						var titleWrap = popup.find( '.wk-ec-event-title' ),
							timeWrap = popup.find( '.wk-ec-event-time-wrap' ),
							guestWrap = popup.find( '.wk-ec-event-guest-wrap' ),
							locationWrap = popup.find( '.wk-ec-event-location-wrap' ),
							descWrap = popup.find( '.wk-ec-popup-desc' ),
							detailsWrap = popup.find( '.wk-ec-popup-readmore-link' ),
							imageWrap = popup.find( '.wk-ec-popup-image' );

						// display none
						imageWrap.css( 'display', 'none' );
						titleWrap.css( 'display', 'none' );
						timeWrap.css( 'display', 'none' );
						guestWrap.css( 'display', 'none' );
						locationWrap.css( 'display', 'none' );
						descWrap.css( 'display', 'none' );
						detailsWrap.css( 'display', 'none' );

						popup.addClass( "wk-ec-popup-ready" );

						// image markup
						if ( imageUrl ) {
							imageWrap.removeAttr( "style" );
							imageWrap.find( 'img' ).attr( "src", imageUrl );
							imageWrap.find( 'img' ).attr( "alt", title );
						}

						// title markup
						if ( title ) {
							titleWrap.removeAttr( "style" );
							titleWrap.text( title );
						}

						// guest markup
						if ( guest ) {
							guestWrap.removeAttr( "style" );
							guestWrap.find( 'span.wk-ec-event-guest' ).text( guest );
						}

						// location markup
						if ( location ) {
							locationWrap.removeAttr( "style" );
							locationWrap.find( 'span.wk-ec-event-location' ).text( location );
						}

						// description markup
						if ( description ) {
							descWrap.removeAttr( "style" );
							descWrap.html( description );
						}

						// time markup
						if ( allDay !== true ) {
							timeWrap.removeAttr( "style" );
							startDate = Date.parse( getTheDate( startDate ) );
							endDate = Date.parse( getTheDate( endDate ) );
							var startTimeText = timeFormat( getTheDate( startDate ), time_format );
							var endTimeText = 'Invalid Data';
							if ( startDate < endDate ) {
								endTimeText = timeFormat( getTheDate( endDate ), time_format );
							}
							timeWrap.find( 'span.wk-ec-event-time' ).text( startTimeText + ' - ' + endTimeText );
						} else {
							timeWrap.removeAttr( "style" );
							timeWrap.find( 'span.wk-ec-event-time' ).text( allday_text );
						}

						// read more markup
						if ( detailsUrl ) {
							detailsWrap.removeAttr( "style" );
							detailsWrap.attr( "href", detailsUrl );
							if ( "on" === info.event.extendedProps.external ) {
								detailsWrap.attr( "target", "_blank" );
							}
							if ( "on" === info.event.extendedProps.nofollow ) {
								detailsWrap.attr( "rel", "nofollow" );
							}
						}
					} else {

						if ( info.event.url && info.event.extendedProps.external ) {
							info.jsEvent.preventDefault();

							var id = $scope.data( 'id' ),
								anchor = document.createElement( 'a' ),
								anchorReal,
								timeout;

							anchor.id = 'wakoo-even-calender-link-' + id;
							anchor.href = info.event.url;
							anchor.target = info.event.extendedProps.external ? '_blank' : '_self';
							anchor.rel = info.event.extendedProps.nofollow ? 'nofollow noreferer' : '';
							anchor.style.display = 'none';

							document.body.appendChild( anchor );

							anchorReal = document.getElementById( anchor.id );
							anchorReal.click();

							timeout = setTimeout( function () {
								document.body.removeChild( anchorReal );
								clearTimeout( timeout );
							} );

							return false;
						}

					}
				},
				dateClick: function ( arg ) {
					itemDate = arg.date.toUTCString();
				}
			};

			var calendar = new FullCalendar.Calendar( calendarEl[ 0 ], option );
			calendar.render();

			$scope.find( ".wk-ec-popup-wrapper" ).on( "click", function ( e ) {
				e.stopPropagation();

				if ( e.target === e.currentTarget || e.target == popupClose[ 0 ] || e.target == popupClose.find( ".eicon-editor-close" )[ 0 ] ) {
					popup.addClass( "wk-ec-popup-removing" ).removeClass( "wk-ec-popup-ready" );
				}
			} );

		};

		//Image Accordion
		var Image_Accordion = function ( $scope ) {
			$scope.on( 'click', '.wk-ia-item', function () {
				if ( ! $scope.hasClass( 'wk-image-accordion-click' ) ) {
					return;
				}

				var $this = $( this );

				if ( $this.hasClass( 'active' ) ) {
					return;
				}

				$scope.find( '.wk-ia-item' ).removeClass( 'active' );
				$this.addClass( 'active' );
			} );

			$scope.on( 'mouseenter', '.wk-ia-item', function () {
				if ( ! $scope.hasClass( 'wk-image-accordion-hover' ) ) {
					return;
				}

				var $this = $( this );

				if ( $this.hasClass( 'active' ) ) {
					return;
				}

				$scope.find( '.wk-ia-item' ).removeClass( 'active' );
				$this.addClass( 'active' );
			} );

		$scope.on( 'mouseleave', '.wk-ia-gallery-wrap', function () {
			if ( ! $scope.hasClass( 'wk-image-accordion-hover' ) ) {
				return;
			}

			var $activeOnLoad = $scope.find( '.wk-ia-item.wk-ia-active-on-load' );

			if ( $activeOnLoad.length ) {
				return;
			}

			$scope.find( '.wk-ia-item' ).removeClass( 'active' );
			$activeOnLoad.addClass( 'active' );
		} );
		};

		//Content Switcher
		var Content_Switcher = function ( $scope ) {
			var parent = $scope.find( '.wk-content-switcher-wrapper' ),
				designType = parent.data( 'design-type' );

			if ( designType == 'button' ) {
				var buttons = parent.find( '.wk-cs-button' ),
					contents = parent.find( '.wk-cs-content-section' );
				buttons.each( function ( inx, btn ) {
					$( this ).on( 'click', function ( e ) {
						e.preventDefault();
						if ( $( this ).hasClass( 'active' ) ) {
							return;
						} else {
							buttons.removeClass( 'active' );
							$( this ).addClass( 'active' );

							contents.removeClass( 'active' );
							var contentId = $( this ).data( 'content-id' );
							parent.find( '#' + contentId ).addClass( 'active' );
						}
					} );
				} );

			} else {
				var toggleSwitch = parent.find( '.wk-cs-switch.wk-input-label' ),
					input = parent.find( 'input.wk-cs-toggle-switch' ),
					primarySwitcher = parent.find( '.wk-cs-switch.primary' ),
					secondarySwitcher = parent.find( '.wk-cs-switch.secondary' ),
					primaryContent = parent.find( '.wk-cs-content-section.primary' ),
					secondaryContent = parent.find( '.wk-cs-content-section.secondary' );

				toggleSwitch.on( 'click', function ( e ) {

					if ( input.is( ':checked' ) ) {
						primarySwitcher.removeClass( 'active' );
						primaryContent.removeClass( 'active' );
						secondarySwitcher.addClass( 'active' );
						secondaryContent.addClass( 'active' );
					} else {
						secondarySwitcher.removeClass( 'active' );
						secondaryContent.removeClass( 'active' );
						primarySwitcher.addClass( 'active' );
						primaryContent.addClass( 'active' );
					}
				} );

			}

		};

		//Team Member
		var Team_Member = function ( $scope ) {
			var btn = $scope.find( '.wk-btn' );
			var lightBox = $scope.find( '.wk-member-lightbox' );
			if ( lightBox.length > 0 ) {

				var close = lightBox.find( '.wk-member-lightbox-close' );

				btn.on( 'click', function () {
					lightBox.addClass( 'wk-member-lightbox-show' );
				} );

				lightBox.on( 'click', function ( e ) {
					if ( lightBox.hasClass( 'wk-member-lightbox-show' ) ) {
						if ( e.target == lightBox[ 0 ] ) {
							lightBox.removeClass( 'wk-member-lightbox-show' );
						}
						else if ( e.target == close[ 0 ] ) {
							lightBox.removeClass( 'wk-member-lightbox-show' );
						}
						else if ( e.target == close.find( 'i.eicon-editor-close' )[ 0 ] ) {
							lightBox.removeClass( 'wk-member-lightbox-show' );
						}
					}
				} );
			}
		};

		//Creative Button
		var Creative_Button = function ( $scope ) {
			var btn_wrap = $scope.find( '.wk-creative-btn-wrap' );
			var magnetic = btn_wrap.data( 'magnetic' );
			var btn = btn_wrap.find( 'a.wk-creative-btn' );
			if ( 'yes' == magnetic ) {
				btn_wrap.on( 'mousemove', function ( e ) {
					var x = e.pageX - ( btn_wrap.offset().left + ( btn_wrap.outerWidth() / 2 ) );
					var y = e.pageY - ( btn_wrap.offset().top + ( btn_wrap.outerHeight() / 2 ) );
					btn.css( "transform", "translate(" + x * 0.3 + "px, " + y * 0.5 + "px)" );
				} );
				btn_wrap.on( 'mouseout', function ( e ) {
					btn.css( "transform", "translate(0px, 0px)" );
				} );
			}
			//For expandable button style only
			var expandable = $scope.find( '.wk-eft--expandable' );
			var text = expandable.find( '.text' );
			if ( expandable.length > 0 && text.length > 0 ) {
				text[ 0 ].addEventListener( "transitionend", function () {
					if ( text[ 0 ].style.width ) {
						text[ 0 ].style.width = "auto";
					}
				} );
				expandable[ 0 ].addEventListener( "mouseenter", function ( e ) {
					e.currentTarget.classList.add( 'hover' );
					text[ 0 ].style.width = "auto";
					var predicted_answer = text[ 0 ].offsetWidth;
					text[ 0 ].style.width = "0";
					window.getComputedStyle( text[ 0 ] ).transform;
					text[ 0 ].style.width = "".concat( predicted_answer, "px" );

				} );
				expandable[ 0 ].addEventListener( "mouseleave", function ( e ) {
					e.currentTarget.classList.remove( 'hover' );
					text[ 0 ].style.width = "".concat( text[ 0 ].offsetWidth, "px" );
					window.getComputedStyle( text[ 0 ] ).transform;
					text[ 0 ].style.width = "";
				} );
			}
		};

		var PDF_View = function ( $scope ) {
			var $id = $scope.data( 'id' );
			var $settings = $scope.find( ".viewer-" + $id ).data( 'pdf-settings' );
			var options = {
				width: $settings.width,
				height: $settings.height,
				page: $settings.page_number
			};
			PDFObject.embed( $settings.pdf_url, "#" + $settings.unique_id, options );
		};

		var Comparison_Table = function ( $scope ) {
			var $table = $scope.find( '.wk-comparison-table-wrapper' );
			var $table_head = $scope.find( '.wk-comparison-table__head' );
			var $sticky_header = $table_head.data( 'sticky-header' );
			var $section_height = $scope.height();
			var $table_height = $table.innerHeight();
			var $tableOffsetTop = $table.offset().top;

			if ( $sticky_header === 'yes' ) {
				$window.scroll( function () {

					var offset = $( this ).scrollTop();

					if ( offset >= $tableOffsetTop ) {
						$table_head.addClass( 'table-sticky' );

					} else if ( offset > $table_height ) {
						$table_head.removeClass( 'table-sticky' );
					}
				} );
			}
		};

		// Slider
		elementorFrontend.hooks.addAction(
			'frontend/element_ready/wk-slider.default',
			function ( $scope ) {
				elementorFrontend.elementsHandler.addHandler( SliderBase, {
					$element: $scope
				} );
			}
		);

		// Carousel
		elementorFrontend.hooks.addAction(
			'frontend/element_ready/wk-carousel.default',
			function ( $scope ) {
				elementorFrontend.elementsHandler.addHandler( SliderBase, {
					$element: $scope
				} );
			}
		);

		//Horizontal Timeline
		elementorFrontend.hooks.addAction(
			'frontend/element_ready/wk-horizontal-timeline.default',
			function ( $scope ) {
				elementorFrontend.elementsHandler.addHandler( SliderBase, {
					$element: $scope,
					autoplay: false,
					container: '.wk-horizontal-timeline-wrapper',
					navigation: 'arrow',
					arrows: true,
				} );
				var img_wrap = $scope.find( ".wk-horizontal-timeline-image" );
				var magnific_popup = img_wrap.data( "mfp-src" );

				if ( undefined !== magnific_popup ) {
					img_wrap.magnificPopup( {
						type: "image",
						gallery: {
							enabled: true
						}
					} );
				}
			}
		);

		// elementorFrontend.hooks.addAction(
		// 	'frontend/element_ready/wk-mailchimp.default',
		// 	function ($scope) {
		// 		elementorFrontend.elementsHandler.addHandler(MailChimp, {
		// 			$element: $scope,
		// 		});
		// 	}
		// );

		$( 'body' ).on( 'click.onWrapperLink', '[data-wk-element-link]', function () {
			var $wrapper = $( this ),
				data = $wrapper.data( 'wk-element-link' ),
				id = $wrapper.data( 'id' ),
				anchor = document.createElement( 'a' ),
				anchorReal,
				timeout;

			anchor.id = 'wakoo-wrapper-link-' + id;
			anchor.href = data.url;
			anchor.target = data.is_external ? '_blank' : '_self';
			anchor.rel = data.nofollow ? 'nofollow noreferer' : '';
			anchor.style.display = 'none';

			document.body.appendChild( anchor );

			anchorReal = document.getElementById( anchor.id );
			anchorReal.click();

			timeout = setTimeout( function () {
				document.body.removeChild( anchorReal );
				clearTimeout( timeout );
			} );
		} );

		// Background overlay extension
		var BackgroundOverlay = function ( $scope ) {
			$scope.hasClass( 'elementor-element-edit-mode' ) && $scope.addClass( 'wk-has-bg-overlay' );
		};

		var fnHanlders = {
			'wk-image-compare.default': HandleImageCompare,
			'wk-number.default': NumberHandler,
			'wk-skills.default': SkillHandler,
			'wk-fun-factor.default': FunFactor,
			'wk-bar-chart.default': BarChart,
			'wk-threesixty-rotation.default': Threesixty_Rotation,
			'wk-data-table.default': DataTable,
			// 'widget'                        : BackgroundOverlay,
			'section': BackgroundOverlay,
			'column': BackgroundOverlay,
			'wk-event-calendar.default': Event_Calendar,
			'wk-image-accordion.default': Image_Accordion,
			'wk-content-switcher.default': Content_Switcher,
			'wk-member.default': Team_Member,
			'wk-creative-button.default': Creative_Button,
			'wk-pdf-view.default': PDF_View,
			'wk-comparison-table.default': Comparison_Table
		};

		$.each( fnHanlders, function ( widgetName, handlerFn ) {
			elementorFrontend.hooks.addAction( 'frontend/element_ready/' + widgetName, handlerFn );
		} );

		var classHandlers = {
			'wk-image-grid.default': ImageGrid,
			'wk-justified-gallery.default': JustifiedGrid,
			'wk-news-ticker.default': NewsTicker,
			'wk-post-tab.default': PostTab
		};

		$.each( classHandlers, function ( widgetName, handlerClass ) {
			elementorFrontend.hooks.addAction( 'frontend/element_ready/' + widgetName, function ( $scope ) {
				elementorFrontend.elementsHandler.addHandler( handlerClass, { $element: $scope } );
			} );
		} );

		//nav menu
		let NavigationMenu = function __init ( $scope ) {
			var navMenu = $scope.find( '.wk-nav-menu' );

			//for tablet only
			if ( jQuery( window ).width() < 1025 && jQuery( window ).width() > 767 ) {
				let indicator = navMenu.find( '.wk-submenu-indicator-wrap' );
				indicator.on( 'click', function ( e ) {
					e.preventDefault();
					let $parentEl = $( this ).parent( 'li.menu-item-has-children' );
					if ( $parentEl ) {
						$parentEl.children( 'ul.sub-menu' ).slideToggle();
					}
				} );
			}

			var humBurgerBtn = navMenu.find( '.wk-menu-toggler' );

			humBurgerBtn.on( 'click', function ( e ) {

				var humberger = $( this ).data( 'humberger' );
				var $pel = navMenu.find( 'ul.menu' );

				if ( 'open' == humberger ) {

					$( '.wk-menu-open-icon' ).addClass( 'hide-icon' );
					$( '.wk-menu-close-icon' ).removeClass( 'hide-icon' );
					$( '.wk-menu-close-icon' ).addClass( 'show-icon' );
					$pel.slideDown();

				} else {

					$( '.wk-menu-close-icon' ).addClass( 'hide-icon' );
					$( '.wk-menu-open-icon' ).removeClass( 'hide-icon' );
					$( '.wk-menu-open-icon' ).addClass( 'show-icon' );
					$pel.slideUp();
				}

			} );

			function burgerClsAdd () {

				if ( jQuery( window ).width() < 768 ) {

					navMenu.removeClass( 'wk-navigation-menu-wrapper' );
					navMenu.addClass( 'wk-navigation-burger-menu' );

					var humBurgerSubMenuBtn = navMenu.find( '.wk-submenu-indicator-wrap' );

					humBurgerSubMenuBtn.on( 'click', function ( e ) {
						e.preventDefault();
						let $parentEl = $( this ).parent( 'li.menu-item-has-children' );
						if ( $parentEl ) {
							$parentEl.children( 'ul.sub-menu' ).slideToggle();
						}
					} );

				} else {
					navMenu.addClass( 'wk-navigation-menu-wrapper' );
					navMenu.removeClass( 'wk-navigation-burger-menu' );
					navMenu.find( 'ul.menu' ).removeAttr( 'style' );
					navMenu.find( 'ul.sub-menu' ).removeAttr( 'style' );
				}

			}

			burgerClsAdd();

			$window.on( 'resize', debounce( burgerClsAdd, 100 ) );

		};

		elementorFrontend.hooks.addAction( "frontend/element_ready/wk-navigation-menu.default", NavigationMenu );


		var AgeGate = function ( $scope, $ ) {

			if ( elementorFrontend.isEditMode() ) {
				localStorage.removeItem( "wk-age-gate-expire-time" );
				if ( $scope.find( '.wk-age-gate-wrapper' ).length ) {
					var editor_mood = $scope.find( '.wk-age-gate-wrapper' ).data( 'editor_mood' );
					if ( 'no' == editor_mood ) {
						$scope.find( '.wk-age-gate-wrapper' ).hide();
					}
				}
			} else if ( !elementorFrontend.isEditMode() ) {
				var container = $scope.find( '.wk-age-gate-wrapper' ),
					cookies_time = container.data( 'age_gate_cookies_time' ),
					exd = localStorage.getItem( "wk-age-gate-expire-time" );
				//container.closest("body").find("header").css("display","none");
				container.closest( "body" ).css( "overflow", "hidden" );
				var cdate = new Date();
				var endDate = new Date();
				endDate.setDate( cdate.getDate() + cookies_time );

				$( "body,html,document" ).scrollTop( $scope.offset().top );
				var t = setTimeout( () => {
					$( "body,html,document" ).scrollTop( $( "body" ).offset().top );
					clearTimeout( t );
				}, 1000 );

				if ( exd != '' && exd != undefined && ( new Date( cdate ) <= new Date( exd ) ) ) {
					$( '.wk-age-gate-wrapper' ).hide();
					container.closest( "body" ).css( "overflow", "" );
				} else if ( exd != '' && exd != undefined && ( new Date( cdate ) > new Date( exd ) ) ) {
					localStorage.removeItem( "wk-age-gate-expire-time" );
					$( '.wk-age-gate-wrapper' ).show();
				} else {
					$( '.wk-age-gate-wrapper' ).show();
				}

				/*confirm-age*/
				if ( $scope.find( '.wk-age-gate-wrapper.wk-age-gate-confirm-age' ).length ) {

					$( ".wk-age-gate-confirm-age-btn" ).on( "click", function () {
						localStorage.setItem( "wk-age-gate-expire-time", endDate );
						$( this ).closest( ".wk-age-gate-wrapper" ).hide();
						//$(this).closest("body").find("header").css("display","block");
						$( this ).closest( "body" ).css( "overflow", "" );
					} );
				}

				/*confirm-dob*/
				if ( $scope.find( '.wk-age-gate-wrapper.wk-age-gate-confirm-dob' ).length ) {

					$( ".wk-age-gate-confirm-dob-btn" ).on( "click", function () {
						var birthYear = new Date( Date.parse( $( this ).closest( '.wk-age-gate-form-body' ).find( '.wk-age-gate-date-input' ).val() ) ),
							agebirth = birthYear.getFullYear(),
							currentYear = cdate.getFullYear(),
							userage = currentYear - agebirth,
							agelimit = $( this ).closest( '.wk-age-gate-wrapper' ).data( "userbirth" );
						if ( userage < agelimit ) {
							$( this ).closest( '.wk-age-gate-boxes' ).find( '.wk-age-gate-warning-msg' ).show();
						} else {
							localStorage.setItem( "wk-age-gate-expire-time", endDate );
							$( this ).closest( '.wk-age-gate-wrapper' ).hide();
							//$(this).closest("body").find("header").css("display","block");
							$( this ).closest( "body" ).css( "overflow", "" );
						}
					} );
				}

				/*confirm-by-boolean*/
				if ( $scope.find( '.wk-age-gate-wrapper.wk-age-gate-confirm-by-boolean' ).length ) {
					$( ".wk-age-gate-wrapper .wk-age-gate-confirm-yes-btn" ).on( "click", function () {
						localStorage.setItem( "wk-age-gate-expire-time", endDate );
						$( this ).closest( '.wk-age-gate-wrapper' ).hide();
						//$(this).closest("body").find("header").css("display","block");
						$( this ).closest( "body" ).css( "overflow", "" );
					} );
					$( ".wk-age-gate-wrapper .wk-age-gate-confirm-no-btn" ).on( "click", function () {
						$( this ).closest( '.wk-age-gate-boxes' ).find( '.wk-age-gate-warning-msg' ).show();
					} );
				}
			}
		};

		elementorFrontend.hooks.addAction( "frontend/element_ready/wk-age-gate.default", AgeGate );


		var LiquidHoverImage = ModuleHandler.extend( {
			onInit: function () {
				ModuleHandler.prototype.onInit.apply( this, arguments );
				this.run();

				// $window.on('resize', debounce(this.run.bind(this), 100));
			},

			onElementChange: debounce( function ( changedProp ) {
				let $keys = [
					'width',
					'title_typography_typography',
					'title_typography_font_size',
					'title_typography_line_height',
					'title_typography_font_weight',
					'sub_title_typography_typography',
					'sub_title_typography_font_size',
					'sub_title_typography_line_height',
					'sub_title_typography_font_weight'

				];
				if ( $keys.indexOf( changedProp ) !== -1 ) {
					this.run();
				}
			}, 300 ),

			run: function () {
				var self = this,
					settings = JSON.parse( self.$element.find( '.wk-lhi-image-area' ).attr( "data-settings" ) ),
					liquidImage = self.$element.find( '.wk-lhi-image' ),
					title = self.$element.find( '.wk-lhi-title h2' ),
					sub_title = self.$element.find( '.wk-lhi-title p' ),
					canvas = self.$element.find( 'canvas' ),
					style = settings.hover_style,
					hover_effect = settings.plugin_url + 'liquid-hover-image/' + settings.hover_effect;

				if ( 'custom' == settings.hover_effect ) {
					hover_effect = settings.custom_effect ? settings.custom_effect : '';
				}

				if ( canvas ) { canvas.remove(); }
				var myAnimation = new hoverEffect( {
					parent: liquidImage[ 0 ],
					intensity: settings.intensity,
					image1: settings.first_image,
					image2: settings.second_image,
					displacementImage: hover_effect,
					imagesRatio: liquidImage.height() / liquidImage.width(),
					angle1: ( settings.angle - 45 ) * ( Math.PI / 180 ) * ( -1 ),
					angle2: ( settings.angle - 45 ) * ( Math.PI / 180 ) * ( -1 ),
					speedIn: settings.speed,
					speedOut: settings.speed,
				} );

				/* if title or subtitle enable */
				if ( 'style-1' == style && ( title.length || sub_title.length ) ) {
					var style_direction = settings.style_1_direction;

					if ( title.length ) {
						title[ 0 ].innerHTML = title[ 0 ].textContent.replace( /\S/g, "<span class='letter'>$&</span>" );
					}

					if ( sub_title.length ) {
						sub_title.addClass( "letter" );
					}

					var HoverTranslateX = [ 0, 0 ],
						HoverOutTranslateX = [ 0, 0 ],
						HoverTranslateY = [ 0, 0 ],
						HoverOutTranslateY = [ 0, 0 ];
					function HoverOutDelay ( el, i, a ) {
						return 'right' == style_direction ? ( ( a - i ) * 40 ) : ( 40 * i );
					};

					if ( 'left' == style_direction ) {
						HoverTranslateX = [ 80, 0 ],
							HoverOutTranslateX = [ 0, -80 ];
					} else if ( 'right' == style_direction ) {
						HoverTranslateX = [ 0, 80 ],
							HoverOutTranslateX = [ 80, 200 ];
					} else if ( 'up' == style_direction ) {
						HoverTranslateY = [ 80, 0 ],
							HoverOutTranslateY = [ 0, -80 ];
					} else if ( 'down' == style_direction ) {
						HoverTranslateY = [ -80, 0 ],
							HoverOutTranslateY = [ 0, 80 ];
					}

					self.$element.hover(
						function () {
							anime.timeline( { loop: false } )
								.add( {
									targets: '.elementor-element-' + self.getID() + ' .wk-lhi-title .letter',
									translateX: HoverTranslateX,
									translateY: HoverTranslateY,
									translateZ: 0,
									opacity: [ 0, 1 ],
									easing: "easeOutExpo",
									duration: 800,
									delay: ( el, i ) => 40 * i
								} );
						},

						function () {
							anime.timeline( { loop: false } )
								.add( {
									targets: '.elementor-element-' + self.getID() + ' .wk-lhi-title .letter',
									translateX: HoverOutTranslateX,
									translateY: HoverOutTranslateY,
									opacity: [ 1, 0 ],
									// easing: "easeInExpo",
									duration: 850,
									delay: function ( el, i, a ) {
										return HoverOutDelay( el, i, a );
									}
								} );
						}
					);
				}

				if ( 'style-2' == style && ( title.length || sub_title.length ) ) {

					if ( title.length ) {
						var height = title.find( '.normal' ).outerHeight();
						title.height( height );
					}

					if ( sub_title.length ) {
						var height = sub_title.find( '.normal' ).outerHeight();
						sub_title.height( height );
					}

					self.$element.hover(
						function () {
							title.addClass( 'play' );
							sub_title.addClass( 'play' );
						},
						function () {
							title.removeClass( 'play' );
							sub_title.removeClass( 'play' );
						}
					);
				}

				if ( 'style-5' == style && ( title.length || sub_title.length ) ) {

					if ( title.length ) {
						var height = title.find( '.normal' ).outerHeight();
						title.attr( 'style', '--wk-lhi-style-5-height:' + height + 'px' );
					}
				}

			}
		} );

		elementorFrontend.hooks.addAction( 'frontend/element_ready/wk-liquid-hover-image.default', function ( $scope ) {
			elementorFrontend.elementsHandler.addHandler( LiquidHoverImage, { $element: $scope } );
		} );

		/* ---- Wakoo native text split / scroll helpers (no GSAP, no SplitType) ---- */
		var wkScrollProgress = function ( el, startVp, endVp ) {
			// 0 when the element's top crosses startVp (fraction of viewport height), 1 when its bottom crosses endVp.
			var r = el.getBoundingClientRect(), vh = window.innerHeight || 1;
			var start = r.top - vh * startVp, end = r.bottom - vh * endVp;
			var total = start - end;
			return total <= 0 ? ( start <= 0 ? 1 : 0 ) : Math.min( 1, Math.max( 0, start / total ) );
		};

		var wkOnScroll = function ( fn ) {
			var queued = false;
			var tick = function () { queued = false; fn(); };
			var handler = function () { if ( ! queued ) { queued = true; window.requestAnimationFrame( tick ); } };
			window.addEventListener( 'scroll', handler, { passive: true } );
			window.addEventListener( 'resize', handler );
			handler();
			return function () {
				window.removeEventListener( 'scroll', handler );
				window.removeEventListener( 'resize', handler );
			};
		};

		var wkSplit = function ( el, withChars ) {
			if ( el.dataset.wkSplitText === undefined ) { el.dataset.wkSplitText = el.textContent; }
			var text = el.dataset.wkSplitText.replace( /\s+/g, ' ' ).trim();
			el.textContent = '';
			var words = text.split( ' ' ), spans = [];
			words.forEach( function ( w, i ) {
				var s = document.createElement( 'span' );
				s.className = 'word';
				s.style.display = 'inline-block';
				if ( withChars ) {
					Array.from( w ).forEach( function ( c ) {
						var cs = document.createElement( 'span' );
						cs.className = 'char';
						cs.style.display = 'inline-block';
						cs.textContent = c;
						s.appendChild( cs );
					} );
				} else {
					s.textContent = w;
				}
				el.appendChild( s );
				if ( i < words.length - 1 ) { el.appendChild( document.createTextNode( ' ' ) ); }
				spans.push( s );
			} );
			// Group words into lines by their vertical position.
			var lines = [], lastTop = null, cur = null;
			spans.forEach( function ( s ) {
				var top = s.offsetTop;
				if ( lastTop === null || Math.abs( top - lastTop ) > 2 ) { cur = []; lines.push( cur ); lastTop = top; }
				cur.push( s );
			} );
			el.textContent = '';
			lines.forEach( function ( ws ) {
				var line = document.createElement( 'span' );
				line.className = 'line';
				line.style.display = 'block';
				ws.forEach( function ( s, i ) {
					line.appendChild( s );
					if ( i < ws.length - 1 ) { line.appendChild( document.createTextNode( ' ' ) ); }
				} );
				el.appendChild( line );
			} );
		};

		var TextScroll = ModuleHandler.extend( {
			onInit: function () {
				ModuleHandler.prototype.onInit.apply( this, arguments );
				this.run();
			},

			onElementChange: debounce( function ( changedProp ) {
				if ( [ 'text_scroll_type' ].indexOf( changedProp ) !== -1 ) { this.run(); }
			}, 300 ),

			run: function () {
				var self = this, el = this.$element.find( '.wk-split-lines' )[ 0 ];
				if ( ! el ) { return; }
				if ( this._off ) { this._off(); this._off = null; }
				var type = this.getElementSettings( 'text_scroll_type' );
				var highlight = 'horizontal_line_highlight' === type;
				var masked = 'horizontal_line_mask' === type || 'vertical_line_mask' === type;
				wkSplit( el, highlight );
				var lines = Array.prototype.slice.call( el.querySelectorAll( '.line' ) );

				if ( masked ) {
					var horizontal = 'horizontal_line_mask' === type;
					lines.forEach( function ( line ) {
						var mask = document.createElement( 'div' );
						mask.className = 'wk-line-mask';
						line.appendChild( mask );
						line.classList.add( 'mask-active' );
					} );
					this._off = wkOnScroll( function () {
						lines.forEach( function ( line ) {
							var m = line.querySelector( '.wk-line-mask' );
							var p = wkScrollProgress( line, 1, 0.5 );
							if ( horizontal ) { m.style.width = ( 100 - p * 100 ) + '%'; } else { m.style.height = ( 100 - p * 100 ) + '%'; }
						} );
					} );
				} else if ( highlight ) {
					var chars = Array.prototype.slice.call( el.querySelectorAll( '.char' ) );
					this._off = wkOnScroll( function () {
						var p = wkScrollProgress( el, 0.6, 0.5 );
						var n = chars.length, k = p * n;
						chars.forEach( function ( c, i ) {
							var o = Math.min( 1, Math.max( 0, k - i ) );
							c.style.opacity = 0.2 + o * 0.8;
						} );
					} );
				} else {
					this._off = wkOnScroll( function () {
						lines.forEach( function ( line ) {
							var r = line.getBoundingClientRect();
							line.classList.toggle( 'highlight', r.top <= window.innerHeight * 0.5 );
						} );
					} );
				}
			}
		} );

		elementorFrontend.hooks.addAction( 'frontend/element_ready/wk-text-scroll.default', function ( $scope ) {
			elementorFrontend.elementsHandler.addHandler( TextScroll, { $element: $scope } );
		} );

		/* ---- SVG Draw: stroke-dash animation with the Web Animations API ---- */
		var haSvgDrawHandler = ModuleHandler.extend( {
			onInit: function () {
				ModuleHandler.prototype.onInit.apply( this, arguments );
				this.run();
			},

			run: function () {
				var $scope = this.$element;
				$scope.find( 'title' ).remove();
				if ( ! $scope.hasClass( 'wk-svg-animated-yes' ) ) { return; }

				var s = this.getElementSettings(),
					action = s.scroll_action,
					root = $scope[ 0 ],
					reverse = $scope.hasClass( 'wk-svg-animation-rev-yes' ),
					together = $scope.hasClass( 'wk-svg-sync-together-yes' ),
					paths = Array.prototype.slice.call( root.querySelectorAll( 'path, circle, rect, ellipse, polyline, polygon, line' ) ),
					dur = ( parseFloat( s.frames ) || 1 ) * 1000,
					point = reverse ? ( s.animate_end_point && s.animate_end_point.size ) : ( s.animate_start_point && s.animate_start_point.size ),
					hidden = Math.min( 100, Math.max( 0, parseFloat( point ) || 0 ) ) / 100,
					loop = 'automatic' === action || 'hover' === action ? !! s.loop : false,
					yoyo = !! s.yoyo,
					anims = [];

				paths.forEach( function ( p, i ) {
					var len = 0;
					try { len = p.getTotalLength(); } catch ( e ) { return; }
					if ( ! len ) { return; }
					p.setAttribute( 'fill', 'transparent' );
					p.style.strokeDasharray = len;
					var from = reverse ? 0 : len * ( 1 - hidden ), to = reverse ? len * hidden : 0;
					p.style.strokeDashoffset = from;
					var delay = together ? 0 : ( i / Math.max( 1, paths.length ) ) * dur * 0.5;
					var a = p.animate( [ { strokeDashoffset: from }, { strokeDashoffset: to } ], {
						duration: dur, delay: delay, fill: 'both', easing: 'ease-in-out',
						iterations: loop ? Infinity : 1, direction: yoyo && loop ? 'alternate' : 'normal'
					} );
					a.pause();
					p.dataset.wkLen = len;
					anims.push( a );
				} );
				if ( ! anims.length ) { return; }

				var finish = function () {
					if ( 'yes' === s.svg_fill ) {
						setTimeout( function () {
							paths.forEach( function ( p ) {
								p.style.transition = 'fill .6s, stroke .6s';
								p.style.fill = s.svg_color || '';
								if ( s.svg_stroke ) { p.style.stroke = s.svg_stroke; }
							} );
						}, dur );
					}
				};
				var playAll = function () { anims.forEach( function ( a ) { a.play(); } ); finish(); };

				if ( 'hover' === action ) {
					var svg = root.querySelector( 'svg' ) || root;
					svg.addEventListener( 'mouseenter', playAll );
					svg.addEventListener( 'mouseleave', function () { anims.forEach( function ( a ) { a.pause(); } ); } );
				} else if ( 'viewport' === action ) {
					wkOnScroll( function () {
						var p = wkScrollProgress( root, ( s.animate_offset && s.animate_offset.size ? s.animate_offset.size : 50 ) / 100, 0 );
						anims.forEach( function ( a ) {
							var t = a.effect.getComputedTiming();
							a.currentTime = p * ( t.endTime - 0 );
						} );
						if ( p >= 1 ) { finish(); }
					} );
				} else {
					var trig = s.animate_trigger && 'custom' !== s.animate_trigger ? s.animate_trigger : ( ( s.animate_offset && s.animate_offset.size ) || 50 ) + '%';
					var frac = /%$/.test( trig ) ? parseFloat( trig ) / 100 : ( 'top' === trig ? 0.1 : 'bottom' === trig ? 0.9 : 0.5 );
					var done = false;
					var io = new IntersectionObserver( function ( es ) {
						es.forEach( function ( e ) {
							if ( e.isIntersecting && ! done ) { done = true; playAll(); if ( ! s.anim_rev ) { io.disconnect(); } }
						} );
					}, { rootMargin: '0px 0px -' + Math.round( ( 1 - frac ) * 50 ) + '% 0px' } );
					io.observe( root );
				}
			}
		} );

		elementorFrontend.hooks.addAction( 'frontend/element_ready/wk-svg-draw.default', function ( $scope ) {
			elementorFrontend.elementsHandler.addHandler( haSvgDrawHandler, { $element: $scope } );
		} );

	} );

}( jQuery ) );
