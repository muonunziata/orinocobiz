( function ( $ ) {
	"use strict";

	window.haHasIconLibrary = function () {
		return elementor.helpers && elementor.helpers.renderIcon;
	};

	window.haGetFeatureLabel = function ( text ) {
		var div = document.createElement( "DIV" );

		div.innerHTML = text;
		text = div.textContent || div.innerText || text;

		return text.length > 20 ? text.substring( 0, 20 ) + "..." : text;
	};

	window.haGetTranslated = function ( stringKey, templateArgs ) {
		return elementorCommon.translate(
			stringKey,
			null,
			templateArgs,
			WakooEditor.i18n
		);
	};

	window.haGetButtonWithIcon = function ( view, args ) {
		var buttonMarkup = [],
			settings = {},
			btnIconHTML,
			btnMigrated,
			btnIcon,
			buttonBefore,
			buttonAfter;

		args = args || {};
		args = _.defaults( args, {
			oldIcon: "button_icon",
			iconPos: "button_icon_position",
			newIcon: "button_selected_icon",
			text: "button_text",
			link: "button_link",
			class: "wk-btn wk-btn--link",
			textClass: "wk-btn-text",
		} );

		if ( !_.isObject( view ) ) {
			return;
		}

		settings = view.model.attributes.settings.toJSON();

		var buttonText = !_.isUndefined( settings[ args.text ] )
			? settings[ args.text ]
			: "",
			hasOldIcon =
				!_.isUndefined( settings[ args.oldIcon ] ) && settings[ args.oldIcon ]
					? true
					: false,
			hasNewIcon =
				!_.isUndefined( settings[ args.newIcon ] ) &&
					_.isObject( settings[ args.newIcon ] ) &&
					settings[ args.newIcon ].value
					? true
					: false;

		if ( !buttonText && !hasNewIcon && !hasOldIcon ) {
			return;
		}

		if ( haHasIconLibrary() ) {
			( btnIconHTML = elementor.helpers.renderIcon(
				view,
				settings[ args.newIcon ],
				{
					"aria-hidden": true,
					class: "wk-btn-icon",
				},
				"i",
				"object"
			) ),
				( btnMigrated = elementor.helpers.isIconMigrated(
					settings,
					args.newIcon
				) );
		}

		view.addInlineEditingAttributes( args.text, "none" );
		view.addRenderAttribute( args.text, "class", args.textClass );

		view.addRenderAttribute( "button", "class", args.class );
		view.addRenderAttribute( "button", "href", settings[ args.link ].url );

		if ( hasNewIcon || hasOldIcon ) {
			if (
				haHasIconLibrary() &&
				btnIconHTML &&
				btnIconHTML.rendered &&
				( !hasOldIcon || btnMigrated )
			) {
				if ( settings[ args.newIcon ].library === "svg" ) {
					btnIcon =
						'<span class="wk-btn-icon wk-btn-icon--svg">' +
						btnIconHTML.value +
						"</span>";
				} else {
					btnIcon = btnIconHTML.value;
				}
			} else if ( hasOldIcon ) {
				btnIcon =
					'<i class="wk-btn-icon ' +
					args.oldIcon +
					'" aria-hidden="true"></i>';
			}
		}

		if ( buttonText && !hasNewIcon && !hasOldIcon ) {
			buttonMarkup = [
				"<a " + view.getRenderAttributeString( "button" ) + ">",
				"<span " + view.getRenderAttributeString( args.text ) + ">",
				buttonText,
				"</span>",
				"</a>",
			];
		} else if ( !buttonText && ( hasNewIcon || hasOldIcon ) ) {
			buttonMarkup = [
				"<a " + view.getRenderAttributeString( "button" ) + ">",
				btnIcon,
				"</a>",
			];
		} else if ( buttonText && ( hasNewIcon || hasOldIcon ) ) {
			if ( settings[ args.iconPos ] === "before" ) {
				view.addRenderAttribute(
					"button",
					"class",
					"wk-btn--icon-before"
				);
				buttonBefore = btnIcon;
				buttonAfter =
					"<span " +
					view.getRenderAttributeString( args.text ) +
					">" +
					buttonText +
					"</span>";
			} else {
				view.addRenderAttribute(
					"button",
					"class",
					"wk-btn--icon-after"
				);
				buttonAfter = btnIcon;
				buttonBefore =
					"<span " +
					view.getRenderAttributeString( args.text ) +
					">" +
					buttonText +
					"</span>";
			}
			buttonMarkup = [
				"<a " + view.getRenderAttributeString( "button" ) + ">",
				buttonBefore,
				buttonAfter,
				"</a>",
			];
		}

		return buttonMarkup.join( "" );
	};

	var registerDarkModeStylesheet = function () {
		var darkModeLinkID = "wakoo-editor-dark-css",
			$darkModeLink = $( "#" + darkModeLinkID );

		if ( !$darkModeLink.length ) {
			$darkModeLink = $( "<link>", {
				id: darkModeLinkID,
				rel: "stylesheet",
				href: WakooEditor.dark_stylesheet_url,
			} );
		}

		elementor.settings.editorPreferences.model.on(
			"change:ui_theme",
			function ( model, newValue ) {
				if ( "light" === newValue ) {
					$darkModeLink.remove();
					return;
				}

				$darkModeLink
					.attr(
						"media",
						"auto" === newValue
							? "(prefers-color-scheme: dark)"
							: ""
					)
					.appendTo( elementorCommon.elements.$body );
			}
		);
	};

	elementor.on( "panel:init", function () {
		$( "#elementor-panel-elements-search-input" ).on(
			"keyup",
			_.debounce( function () {
				$( "#elementor-panel-elements" )
					.find( ".hm" )
					.parents( ".elementor-element" )
					.addClass( "is-wk-widget" );
			}, 100 )
		);

		function scrollToTop ( newValue ) {
			// $e.run( 'document/save/update' ).then( _.debounce( function () {
			// 	elementor.reloadPreview();
			// }, 1500));

			var changeItem = Object.entries( this.model.changed )[ 0 ];
			var settings = this.getSettings().settings; //get saved value
			var attributes = this.model.attributes;
			var stt_data = {
				'check': 'sttMessage',
				'changeValue': newValue,
				'changeItem': changeItem
			};

			if ( 'wk_scroll_to_top_single_disable' != changeItem[ 0 ] ) {
				var data = {
					'enable_global_stt': attributes.wk_scroll_to_top_global,
					'media_type': attributes.wk_scroll_to_top_media_type,
					'icon': attributes.wk_scroll_to_top_button_icon,
					'image': attributes.wk_scroll_to_top_button_image,
					'text': attributes.wk_scroll_to_top_button_text,
				};
				stt_data = Object.assign( stt_data, data );
			} else {
				$e.run( 'document/save/update' ).then( _.debounce( function () {
					elementor.reloadPreview();
				}, 1500 ) );
			}

			$( "#elementor-preview-iframe" )[ 0 ].contentWindow.postMessage( stt_data );
		}

		var changeHandler = [ "wk_scroll_to_top_global", "wk_scroll_to_top_media_type", "wk_scroll_to_top_button_icon", "wk_scroll_to_top_button_image", "wk_scroll_to_top_button_text", "wk_scroll_to_top_single_disable" ];

		$.each( changeHandler, function ( index, value ) {
			elementor.settings.page.addChangeCallback( value, scrollToTop );
		} );

		// Reading Progress Bar
		function readingProgressBarHandaler ( settingsValue ) {
			let changeItem = Object.entries( this.model.changed )[ 0 ];
			let settings = this.getSettings().settings;
			let attributes = this.model.attributes;

			let rpb_data = {
				'check': 'rpbMessage',
				'changeValue': settingsValue,
				'changeItem': changeItem
			};

			if ( 'wk_rpb_enable' != changeItem[ 0 ] ) {
				let data = {
					'wk_rpb_enable': attributes.wk_rpb_enable,
					'wk_rpb_apply_globally': attributes.wk_rpb_apply_globally,
					'wk_rpb_type': attributes.wk_rpb_type,
					'wk_rpb_horizontal_position': attributes.wk_rpb_horizontal_position,
					'wk_rpb_vertical_position': attributes.wk_rpb_vertical_position,
					'wk_rpb_single_disable': attributes.wk_rpb_single_disable,
					'wk_rpb_single_enable': attributes.wk_rpb_single_enable,
				};
				rpb_data = Object.assign( rpb_data, data );
			}

			if ( 'wk_rpb_single_enable' == changeItem[ 0 ] || 'wk_rpb_single_disable' == changeItem[ 0 ] ) {
				$e.run( 'document/save/update' ).then( _.debounce( function () {
					elementor.reloadPreview();
				}, 1500 ) );
			}

			$( "#elementor-preview-iframe" )[ 0 ].contentWindow.postMessage( rpb_data );

		};

		let HmRPBHandler = [
			'wk_rpb_enable',
			'wk_rpb_apply_globally',
			'wk_rpb_type',
			'wk_rpb_horizontal_position',
			'wk_rpb_vertical_position',
			'wk_rpb_single_disable',
			'wk_rpb_single_enable',
		];
		// Handle reading progress bar
		$.each( HmRPBHandler, function ( index, value ) {
			elementor.settings.page.addChangeCallback( value, readingProgressBarHandaler );
		} );

		// Custom Mouse Cursor
		function cmcInitialHandaler ( settingsValue ) {
			let changeItem = Object.entries( this.model.changed )[ 0 ];
			let settings = this.getSettings().settings;
			let attributes = this.model.attributes;

			let cmcInitData = {
				'check': 'cmcInitMessage',
				'changeValue': settingsValue,
				'changeItem': changeItem
			};

			if ( 'wk_cmc_init_switcher' != changeItem[ 0 ] ) {
				let data = {
					'wk_cmc_init_switcher': attributes.wk_cmc_init_switcher,
					'wk_cmc_init_enable_lazy_move': attributes.wk_cmc_init_enable_lazy_move,
				};
				cmcInitData = Object.assign( cmcInitData, data );
			}

			$( "#elementor-preview-iframe" )[ 0 ].contentWindow.postMessage( cmcInitData );

		};

		let cmcInitialControlsHandler = [
			'wk_cmc_init_switcher',
			'wk_cmc_init_enable_lazy_move',
		];

		$.each( cmcInitialControlsHandler, function ( index, value ) {
			elementor.settings.page.addChangeCallback( value, cmcInitialHandaler );
		} );


		/**
		 * Register grid layer shortcut
		 */
		if ( typeof $e !== "undefined" || $e !== null ) {
			var option = {
				callback: function () {
					var wk_grid =
						elementor.settings.page.model.attributes.wk_grid;
					if ( "" === wk_grid ) {
						elementor.settings.page.model.setExternalChange(
							"wk_grid",
							"yes"
						);
					} else if ( "yes" === wk_grid ) {
						elementor.settings.page.model.setExternalChange(
							"wk_grid",
							""
						);
					}
				},
			};

			$e.shortcuts.register( "ctrl+shift+g", option );
			$e.shortcuts.register( "cmd+shift+g", option );
		}

		registerDarkModeStylesheet();
	} );

	/**
	 * Add pro widgets placeholder
	 */
	if ( typeof elementor !== 'undefined' && elementor.hooks ) {
		elementor.hooks.addFilter(
			"panel/elements/regionViews",
			function ( regionViews ) {
				if (
					WakooEditor.hasPro ||
					_.isEmpty( WakooEditor.placeholder_widgets )
				) {
					return regionViews;
				}

				var CATEGORY_NAME = "wakoo_pro",
					elementsView = regionViews.elements.view,
					categoriesView = regionViews.categories.view,
					elementsCollection = regionViews.elements.options.collection,
					categoriesCollection =
						regionViews.categories.options.collection,
					proWidgets = [],
					ElementView,
					freeCategoryIndex;

				_.each(
					WakooEditor.placeholder_widgets,
					function ( widget, name ) {
						elementsCollection.add( {
							name: "wk-" + name,
							title: widget.title,
							icon: widget.icon,
							categories: [ CATEGORY_NAME ],
							editable: false,
						} );
					}
				);

				elementsCollection.each( function ( element ) {
					if ( element.get( "categories" )[ 0 ] === CATEGORY_NAME ) {
						proWidgets.push( element );
					}
				} );

				freeCategoryIndex = categoriesCollection.findIndex( {
					name: "wakoo_category",
				} );

				if ( freeCategoryIndex ) {

					categoriesCollection.add(
						{
							name: "wakoo_pro_category",
							title: "Wakoo Pro",
							icon: "hm hm-wakoo",
							defaultActive: false,
							sort: true,
							hideIfEmpty: true,
							items: proWidgets,
							promotion: false
						},
						{
							at: freeCategoryIndex + 1,
						}
					);
				}

				ElementView = {
					className: function () {
						var className =
							this.constructor.__super__.className.call( this );
						if ( !this.isEditable() && this.isHappyWidget() ) {
							className += " wk-element--promotion";
						}

						return className;
					},

					isHappyWidget: function () {
						const widgetName = this.model.get( "name" );
						return widgetName != undefined && widgetName.indexOf( "wk-" ) === 0;
					},

					onMouseDown: function () {
						if ( !this.isHappyWidget() ) {
							this.constructor.__super__.onMouseDown.call( this );
							return;
						}

						elementor.promotion.showDialog( {
							title: haGetTranslated(
								"promotionDialogHeader",
								[ this.model.get( "title" ) ]
							),
							content: haGetTranslated( "promotionDialogMessage", [
								this.model.get( "title" ),
							] ),
							targetElement: this.el,
							position: {
								blockStart: '-7'
							},
							actionButton: {
								url: "",
								text: WakooEditor.i18n.promotionDialogBtnTxt,
								classes: [ 'elementor-button', 'wk-btn--promotion', 'go-pro' ]
							},
						} );
					},
				};

				regionViews.elements.view = elementsView.extend( {
					childView: elementsView.prototype.childView.extend( ElementView ),
				} );

				regionViews.categories.view = categoriesView.extend( {
					childView: categoriesView.prototype.childView.extend( {
						childView:
							categoriesView.prototype.childView.prototype.childView.extend(
								ElementView
							),
					} ),
				} );

				return regionViews;
			}
		);
	}

	// Widget List controller view
	var WidgetList = elementor.modules.controls.Select2.extend( {
		onBeforeRender: function () {
			if ( this.container && ( this.container.type === "section" || this.container.type === "container" ) ) {
				var widgetsConfig =
					elementor.widgetsCache || elementor.config.widgets,
					widgets = {};

				if ( this.container.type === "section" ) {
					this.container.children.forEach( function ( column ) {

						var $widgets =
							column.view.$childViewContainer.children(
								"[data-widget_type]"
							);

						$widgets.each( function ( index, widget ) {
							var name = $( widget ).data( "widget_type" ),
								name = name.slice( 0, name.lastIndexOf( "." ) ),
								config = !_.isUndefined( widgetsConfig[ name ] )
									? widgetsConfig[ name ]
									: false;

							if ( config ) {
								widgets[ config.widget_type ] =
									config.title + " (" + config.widget_type + ")";
							}
						} );
					} );
				};

				if ( this.container.type === "container" ) {
					var $has_widget = false;
					this.container.children.some( function ( column ) {
						if ( column.view.children.length == 0 ) {
							$has_widget = ( column.view.children.length == 0 );
						}
						return ( column.view.children.length == 0 );
					} );
					this.container.children.forEach( function ( column ) {
						let $widgets = column.view.$el.data( "element_type" ) == 'widget' ? column.view.$el : column.view.$el.find( 'div[data-element_type="widget"]' );


						$widgets.each( function ( index, widget ) {

							if ( $( widget ).data( "element_type" ) == 'widget' ) {
								var name = $( widget ).data( "widget_type" ),
									name = name.slice( 0, name.lastIndexOf( "." ) ),
									config = !_.isUndefined( widgetsConfig[ name ] )
										? widgetsConfig[ name ]
										: false;

								if ( config ) {
									widgets[ config.widget_type ] =
										config.title + " (" + config.widget_type + ")";
								}
							}
						} );
					} );
				};

				this.model.set( "options", widgets );
			}
		},
	} );

	elementor.addControlView( "widget-list", WidgetList );

	var AdvancedSelect2 = elementor.modules.controls.BaseData.extend( {
		getSelect2Placeholder: function () {
			return (
				this.ui.select.children( 'option:first[value=""]' ).text() ||
				this.model.get( "placeholder" )
			);
		},

		getDependencyArgs: function () {
			var self = this,
				args = self.model.get( "dynamic_params" );

			if ( !_.isObject( args ) ) {
				args = {};
			}
			if (
				args.control_dependency &&
				_.isObject( args.control_dependency )
			) {
				_.each( args.control_dependency, function ( prop, key ) {
					args[ key ] = self.container.settings.get( prop );
				} );
			}

			return args;
		},

		getSelect2DefaultOptions: function () {
			var _this = this;

			return {
				allowClear: true,
				placeholder: this.getSelect2Placeholder(),
				dir: elementorCommon.config.isRTL ? "rtl" : "ltr",
				minimumInputLength: 1,
				ajax: {
					url: ajaxurl,
					dataType: "json",
					method: "POST",
					delay: 250,
					data: function ( params ) {
						var defaults = {
							nonce: WakooEditor.editor_nonce,
							action: "wk_process_dynamic_select",
							object_type: "post",
							query_term: params.term,
						};
						return $.extend(
							defaults,
							_this.model.get( "dynamic_params" ),
							_this.getDependencyArgs()
						);
					},

					processResults: function ( response ) {
						if ( !response.success || response.data.length === 0 ) {
							return {
								results: [
									{
										id: -1,
										text: "No results found",
										disabled: true,
									},
								],
							};
						}

						var data = [];

						_.each( response.data, function ( title, id ) {
							data.push( {
								id: id,
								text: title,
							} );
						} );

						return {
							results: data,
						};
					},

					cache: true,
				},
			};
		},

		getSelect2Options: function () {
			return $.extend(
				this.getSelect2DefaultOptions(),
				this.model.get( "select2options" )
			);
		},

		addLoadingSpinner: function () {
			this.$el
				.find( ".elementor-control-title" )
				.after(
					'<span class="elementor-control-spinner">&nbsp;<i class="eicon-spinner eicon-animation-spin"></i>&nbsp;</span>'
				);
		},

		onBeforeRender: function () {
			if ( this.isRendered ) {
				return;
			}

			var _this = this,
				savedValues = this.getControlValue();

			if ( _.isEmpty( savedValues ) ) {
				return;
			}

			if ( !_.isArray( savedValues ) ) {
				savedValues = [ savedValues ];
			}

			var defaults = {
				nonce: WakooEditor.editor_nonce,
				action: "wk_process_dynamic_select",
				object_type: "post",
				saved_values: savedValues,
			};

			$.ajax( {
				url: ajaxurl,
				type: "POST",
				data: $.extend(
					defaults,
					_this.model.get( "dynamic_params" ),
					_this.getDependencyArgs()
				),
				beforeSend: _this.addLoadingSpinner.bind( this ),
				success: function ( response ) {
					if ( response.success && response.data.length !== 0 ) {
						// Prefix an extra space to maintain order and backward compatibility
						var ids = ( ids = _.keys( response.data ).map( function (
							id
						) {
							return " " + $.trim( id );
						} ) );

						_this.container.settings.set(
							_this.model.get( "name" ),
							ids
						);
						_this.model.set( "options", response.data );
						_this.render();
					}
				},
			} );
		},

		applySavedValue: function () {
			elementor.modules.controls.BaseData.prototype.applySavedValue.apply(
				this,
				arguments
			);

			var select2Instance = this.ui.select.data( "select2" );

			if ( !select2Instance ) {
				this.ui.select.select2( this.getSelect2Options() );

				if ( this.model.get( "sortable" ) ) {
					this.initSortable();
				}
			} else {
				this.ui.select.trigger( "change" );
			}
		},

		initSortable: function () {
			var $sortable = this.$el.find( "ul.select2-selection__rendered" ),
				_this = this;

			$sortable.sortable( {
				containment: "parent",

				update: function () {
					_this._orderSortedOption( $sortable );

					_this.container.settings.setExternalChange(
						_this.model.get( "name" ),
						_this.ui.select.val()
					);

					_this.model.set( "options", _this.ui.select.val() );
				},
			} );
		},

		_orderSortedOption: function ( $sortable ) {
			var _this = this;

			$sortable.children( "li[title]" ).each( function ( i, obj ) {
				var $elment = _this.ui.select
					.children( "option" )
					.filter( function () {
						return $( this ).html() == obj.title;
					} );

				_this._moveOptionToEnd( $elment );
			} );
		},

		_moveOptionToEnd: function ( $elment ) {
			var $parent = $elment.parent();

			$elment.detach();
			$parent.append( $elment );
		},

		onBeforeDestroy: function () {
			// We always destroy the select2 instance because there are cases where the DOM element's data cache
			// itself has been destroyed but the select2 instance on it still exists
			this.ui.select.select2( "destroy" );
			this.$el.remove();
		},
	} );

	elementor.addControlView( "wk_advanced_select2", AdvancedSelect2 );


	// For Background Parallax
	var WakooBGParallax = function ( panel, model, view ) {
		var $haBgParallax = panel.$el.find(".elementor-control.elementor-control-section_wk_bg_parallax");
		if ( sessionStorage.getItem( 'WakooBGParallaxChangeApply' ) && $haBgParallax.length > 0 ) {
			$haBgParallax.trigger( "click" );
		}
		elementor.channels.editor.on("section:activated", function ( event, panel ) {
			if ( event == "section_wk_bg_parallax" ) {
				sessionStorage.removeItem( 'WakooBGParallaxChangeApply' );
				panel.$el.find(".elementor-update-preview-button.elementor-button").on("click", function( event ) {
					const widgetId = model.id;
					// console.log(widgetId);
					sessionStorage.setItem( 'WakooBGParallaxChangeApply', widgetId );
				});
			}
		});
	};
	elementor.hooks.addAction( "panel/open_editor/section", WakooBGParallax );
	elementor.hooks.addAction( "panel/open_editor/container", WakooBGParallax );

} )( jQuery );
