<?php

/**
 * Content Switcher widget class
 *
 * @package Wakoo
 */

namespace Wakoo\Elementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Repeater;

defined( 'ABSPATH' ) || die();

class Content_Switcher extends Base {

	/**
	 * Get widget title.
	 *
	 * @since 2.24.2
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Content Switcher', 'wakoo' );
	}

	public function get_custom_help_url() {
		// return '';
	}

	/**
	 * Get widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'hm hm-switcher';
	}

	public function get_keywords() {
		return ['content', 'switcher', 'toggle'];
	}

	public function select_elementor_page( $type ) {
		$args  = [
			'tax_query'      => [
				[
					'taxonomy' => 'elementor_library_type',
					'field'    => 'slug',
					'terms'    => $type,
				],
			],
			'post_type'      => 'elementor_library',
			'posts_per_page' => -1,
		];
		$query = new \WP_Query( $args );

		$posts = $query->posts;
		foreach ( $posts as $post ) {
			$items[ $post->ID ] = $post->post_title;
		}

		if ( empty( $items ) ) {
			$items = [];
		}

		return $items;
	}

	/**
	 * Register widget content controls
	 */
	protected function register_content_controls() {
		$this->__switcher_content_controls();
		$this->__settings_content_controls();
	}

	protected function __switcher_content_controls() {

		$this->start_controls_section(
			'_section_content',
			[
				'label' => __( 'Content Switcher', 'wakoo' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'select_design',
			[
				'label'   => __( 'Choose Design', 'wakoo' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'round'    => __( 'Round', 'wakoo' ),
					'round-2'  => __( 'Round 2', 'wakoo' ),
					'square'   => __( 'Square', 'wakoo' ),
					'square-2' => __( 'Square 2', 'wakoo' ),
					'button'   => __( 'Button', 'wakoo' ),
					'lightswitch' => __( 'Interruptor de luz (vertical)', 'wakoo' ),
				],
				'default' => 'round',
			]
		);

		$this->add_control(
			'design_warning_message',
			[
				'raw'             => '<strong>' . esc_html__( 'Please note!', 'wakoo' ) . '</strong> ' . esc_html__( 'This design requires only two items. Only the first two items will be used.', 'wakoo' ),
				'type'            => Controls_Manager::RAW_HTML,
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
				'render_type'     => 'ui',
				'condition'       => [
					'select_design' => ['round', 'round-2', 'square', 'square-2', 'lightswitch'],
				],
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'   => __( 'Title', 'wakoo' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Content', 'wakoo' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'content_type',
			[
				'label'   => __( 'Type', 'wakoo' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'plain_content' => __( 'Plain/ HTML Text', 'wakoo' ),
					'saved_section' => __( 'Saved Section', 'wakoo' ),
					'saved_container' => __( 'Saved Container', 'wakoo' ),
					'saved_page'    => __( 'Saved Page', 'wakoo' ),
					'image'         => __( 'Imagen', 'wakoo' ),
					'video'         => __( 'Vídeo propio', 'wakoo' ),
					'audio'         => __( 'Audio propio', 'wakoo' ),
				],
				'default' => 'plain_content',
			]
		);
		$repeater->add_control(
			'media_image',
			[
				'label'     => __( 'Imagen', 'wakoo' ),
				'type'      => Controls_Manager::MEDIA,
				'condition' => [ 'content_type' => 'image' ],
			]
		);
		$repeater->add_control(
			'media_video',
			[
				'label'       => __( 'Archivo de vídeo (biblioteca de medios)', 'wakoo' ),
				'type'        => Controls_Manager::MEDIA,
				'media_types' => [ 'video' ],
				'condition'   => [ 'content_type' => 'video' ],
			]
		);
		$repeater->add_control(
			'media_poster',
			[
				'label'       => __( 'Portada del vídeo (se carga primero)', 'wakoo' ),
				'type'        => Controls_Manager::MEDIA,
				'condition'   => [ 'content_type' => 'video' ],
			]
		);
		$repeater->add_control(
			'media_audio',
			[
				'label'       => __( 'Archivo de audio (biblioteca de medios)', 'wakoo' ),
				'type'        => Controls_Manager::MEDIA,
				'media_types' => [ 'audio' ],
				'condition'   => [ 'content_type' => 'audio' ],
			]
		);
		$repeater->add_control(
			'media_caption',
			[
				'label'       => __( 'Pie de la imagen, vídeo o audio', 'wakoo' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'condition'   => [ 'content_type' => [ 'image', 'video', 'audio' ] ],
			]
		);
		$repeater->add_control(
			'plain_content',
			[
				'label'       => __( 'Plain/ HTML Text', 'wakoo' ),
				'type'        => Controls_Manager::TEXTAREA,
				'description' => wk_get_allowed_html_desc( 'intermediate' ),
				'rows'        => 20,
				'condition'   => [
					'content_type' => 'plain_content',
				],
				'dynamic'     => [
					'active' => true,
				],
				'default'     => __( 'Add some content here.', 'wakoo' ),
			]
		);

		$saved_sections = ['0' => __( '--- Select Section ---', 'wakoo' )];
		$saved_sections = $saved_sections + $this->select_elementor_page( 'section' );

		$repeater->add_control(
			'saved_section',
			[
				'label'     => __( 'Sections', 'wakoo' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $saved_sections,
				'default'   => '0',
				'condition' => [
					'content_type' => 'saved_section',
				],
			]
		);

		$saved_container = ['0' => __( '--- Select Container ---', 'wakoo' )];
		$saved_container = $saved_container + $this->select_elementor_page( 'container' );

		$repeater->add_control(
			'saved_container',
			[
				'label'     => __( 'Container', 'wakoo' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $saved_container,
				'default'   => '0',
				'condition' => [
					'content_type' => 'saved_container',
				],
			]
		);

		$saved_page = ['0' => __( '--- Select Page ---', 'wakoo' )];
		$saved_page = $saved_page + $this->select_elementor_page( 'page' );

		$repeater->add_control(
			'saved_pages',
			[
				'label'     => __( 'Pages', 'wakoo' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $saved_page,
				'default'   => '0',
				'condition' => [
					'content_type' => 'saved_page',
				],
			]
		);

		$repeater->add_control(
			'icon',
			[
				'label' => __( 'Icon', 'wakoo' ),
				'type'  => Controls_Manager::ICONS,
			]
		);

		$repeater->add_control(
			'icon_align',
			[
				'label'   => __( 'Icon Position', 'wakoo' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'left'  => __( 'Left', 'wakoo' ),
					'right' => __( 'Right', 'wakoo' ),
				],
			]
		);

		$repeater->add_control(
			'active',
			[
				'label'        => __( 'Active', 'wakoo' ),
				'type'         => Controls_Manager::SWITCHER,
				'description'  => __( 'Active on Load', 'wakoo' ),
				'label_on'     => __( 'Yes', 'wakoo' ),
				'label_off'    => __( 'No', 'wakoo' ),
				'return_value' => 'yes',
				'default'      => 'no',
			]
		);

		$this->add_control(
			'content_list',
			[
				'label'         => __( 'Contents', 'wakoo' ),
				'type'          => Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'prevent_empty' => true,
				'default'       => [
					[
						'title'         => __( 'Primary', 'wakoo' ),
						'content_type'  => 'plain_content',
						'plain_content' => __( 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.' ),
						'active'        => 'yes',
					],
					[
						'title'         => __( 'Secondary', 'wakoo' ),
						'content_type'  => 'plain_content',
						'plain_content' => __( 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', 'wakoo' ),
					],
					[
						'title'         => __( 'Others', 'wakoo' ),
						'content_type'  => 'plain_content',
						'plain_content' => __( 'Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', 'wakoo' ),
					],
				],
				'title_field'   => '{{{ title }}}',
			]
		);

		$this->end_controls_section();
	}

	protected function __settings_content_controls() {

		$this->start_controls_section(
			'_section_display_settings',
			[
				'label' => __( 'Display Settings', 'wakoo' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'apply_site',
			[
				'label'        => __( 'Aplicar al sitio (primer estado = modo diurno, segundo = modo nocturno)', 'wakoo' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Sí', 'wakoo' ),
				'label_off'    => __( 'No', 'wakoo' ),
				'return_value' => 'yes',
				'default'      => '',
				'description'  => __( 'Con el diseño «Interruptor de luz» encendido es día y apagado es noche. La elección se recuerda y se comparte con el widget Modo nocturno.', 'wakoo' ),
			]
		);

		$this->add_responsive_control(
			'switch_direction',
			[
				'label'   => __( 'Switch Direction', 'wakoo' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'horizontal' => [
						'title' => __( 'Horizontal', 'wakoo' ),
						'icon'  => 'eicon-navigation-horizontal',
					],
					'vertical'   => [
						'title' => __( 'Vertical', 'wakoo' ),
						'icon'  => 'eicon-navigation-vertical',
					],
					// 'row' => [
					// 	'title' => __('Horizontal', 'wakoo'),
					// 	'icon'  => 'eicon-navigation-horizontal',
					// ],
					// 'column' => [
					// 	'title' => __('Vertical', 'wakoo'),
					// 	'icon'  => 'eicon-navigation-vertical',
					// ],
				],
				// 'selectors' => [
				// 	'{{WRAPPER}} .wk-cs-switch-container .wk-cs-switch-wrapper' => 'flex-direction : {{VALUE}}',
				// ],
				'default' => 'horizontal',
				'toggle'  => false,
			]
		);

		// $this->add_responsive_control(
		// 	'switch_direction_class_1',
		// 	[
		// 		'type' => \Elementor\Controls_Manager::HIDDEN,
		// 		'default' => 'horizontal',
		// 		'condition' => [
		// 			'switch_direction' => 'row'
		// 		],
		// 	]
		// );

		// $this->add_responsive_control(
		// 	'switch_direction_class_2',
		// 	[
		// 		'type' => \Elementor\Controls_Manager::HIDDEN,
		// 		'default' => 'vertical',
		// 		'condition' => [
		// 			'switch_direction' => 'column'
		// 		],
		// 	]
		// );

		$this->add_responsive_control(
			'switch_align',
			[
				'label'     => __( 'Switch Alignment', 'wakoo' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => __( 'Left', 'wakoo' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center'     => [
						'title' => __( 'Center', 'wakoo' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end'   => [
						'title' => __( 'Right', 'wakoo' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .wk-cs-switch-container' => 'justify-content : {{VALUE}}',
				],
				'default'   => 'center',
				'toggle'    => true,
			]
		);

		$this->add_responsive_control(
			'space_between',
			[
				'label'       => __( 'Space', 'wakoo' ),
				'description' => __( 'Set Space between switcher and content section', 'wakoo' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => ['px', '%'],
				'range'       => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 5,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'     => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors'   => [
					'{{WRAPPER}} .wk-cs-switch-container' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'anim_duration',
			[
				'label'       => __( 'Animation Speed', 'wakoo' ),
				'type'        => Controls_Manager::NUMBER,
				'description' => __( 'Set Animation Duration in Millisecond', 'wakoo' ),
				'min'         => 100,
				'max'         => 3000,
				'step'        => 100,
				'default'     => 400,
				'selectors'   => [
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-slider:before' => 'transition-duration: {{VALUE}}ms',
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button' => 'transition-duration: {{VALUE}}ms',
					'{{WRAPPER}} .wk-cs-content-wrapper .wk-cs-content-section' => 'transition: transform calc( {{VALUE}}ms / 2 ) ease-in;',
					'{{WRAPPER}} .wk-cs-content-wrapper .wk-cs-content-section' => 'transition: transform calc( {{VALUE}}ms / 2 ) ease-out;',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register widget style controls
	 */
	protected function register_style_controls() {
		$this->__switch_style_controls();
		$this->__switcher_control_style_controls();
		$this->__switch_bar_style_controls();
		$this->__content_style_controls();
	}

	protected function __switch_style_controls() {

		$this->start_controls_section(
			'_section_style_switch',
			[
				'label' => __( 'Switch', 'wakoo' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'           => 'typography',
				'fields_options' => [
					'typography'  => ['default' => 'yes'],
					'font_family' => [
						'default' => 'Arial',
					],
					'font_weight' => [
						'default' => 'Bold',
					],
				],
				'selector'       => '{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button span, {{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-switch, {{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button',

			]
		);

		$this->add_responsive_control(
			'icon_spacing',
			[
				'label'      => __( 'Icon Spacing', 'wakoo' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors'  => [
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button.wk-cs-icon-left .wk-cs-icon-wrapper' => 'margin-right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button.wk-cs-icon-right .wk-cs-icon-wrapper' => 'margin-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-switch.wk-cs-icon-left .wk-cs-icon-wrapper' => 'margin-right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-switch.wk-cs-icon-right .wk-cs-icon-wrapper' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'label_spacing',
			[
				'label'      => __( 'Title Spacing', 'wakoo' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors'  => [
					'{{WRAPPER}} .wk-cs-switch-wrapper.horizontal .wk-cs-switch.primary' => 'margin-right: {{SIZE}}{{UNIT}}; margin-bottom: unset;',
					'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .wk-cs-switch-wrapper.widescreen-horizontal .wk-cs-switch.primary' => 'margin-right: {{SIZE}}{{UNIT}}; margin-bottom: unset;',
					'body[data-elementor-device-mode="desktop"] {{WRAPPER}} .wk-cs-switch-wrapper.desktop-horizontal .wk-cs-switch.primary' => 'margin-right: {{SIZE}}{{UNIT}}; margin-bottom: unset;',
					'body[data-elementor-device-mode="laptop"] {{WRAPPER}} .wk-cs-switch-wrapper.laptop-horizontal .wk-cs-switch.primary' => 'margin-right: {{SIZE}}{{UNIT}}; margin-bottom: unset;',
					'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .wk-cs-switch-wrapper.tablet-extra-horizontal .wk-cs-switch.primary' => 'margin-right: {{SIZE}}{{UNIT}}; margin-bottom: unset;',
					'body[data-elementor-device-mode="tablet"] {{WRAPPER}} .wk-cs-switch-wrapper.tablet-horizontal .wk-cs-switch.primary' => 'margin-right: {{SIZE}}{{UNIT}}; margin-bottom: unset;',
					'body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .wk-cs-switch-wrapper.mobile-extra-horizontal .wk-cs-switch.primary' => 'margin-right: {{SIZE}}{{UNIT}}; margin-bottom: unset;',
					'body[data-elementor-device-mode="mobile"] {{WRAPPER}} .wk-cs-switch-wrapper.mobile-horizontal .wk-cs-switch.primary' => 'margin-right: {{SIZE}}{{UNIT}}; margin-bottom: unset;',

					'{{WRAPPER}} .wk-cs-switch-wrapper.horizontal .wk-cs-switch.secondary' => 'margin-left: {{SIZE}}{{UNIT}}; margin-top: unset;',
					'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .wk-cs-switch-wrapper.widescreen-horizontal .wk-cs-switch.secondary' => 'margin-left: {{SIZE}}{{UNIT}}; margin-top: unset;',
					'body[data-elementor-device-mode="desktop"] {{WRAPPER}} .wk-cs-switch-wrapper.desktop-horizontal .wk-cs-switch.secondary' => 'margin-left: {{SIZE}}{{UNIT}}; margin-top: unset;',
					'body[data-elementor-device-mode="laptop"] {{WRAPPER}} .wk-cs-switch-wrapper.laptop-horizontal .wk-cs-switch.secondary' => 'margin-left: {{SIZE}}{{UNIT}}; margin-top: unset;',
					'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .wk-cs-switch-wrapper.tablet-extra-horizontal .wk-cs-switch.secondary' => 'margin-left: {{SIZE}}{{UNIT}}; margin-top: unset;',
					'body[data-elementor-device-mode="tablet"] {{WRAPPER}} .wk-cs-switch-wrapper.tablet-horizontal .wk-cs-switch.secondary' => 'margin-left: {{SIZE}}{{UNIT}}; margin-top: unset;',
					'body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .wk-cs-switch-wrapper.mobile-extra-horizontal .wk-cs-switch.secondary' => 'margin-left: {{SIZE}}{{UNIT}}; margin-top: unset;',
					'body[data-elementor-device-mode="mobile"] {{WRAPPER}} .wk-cs-switch-wrapper.mobile-horizontal .wk-cs-switch.secondary' => 'margin-left: {{SIZE}}{{UNIT}}; margin-top: unset;',

					'{{WRAPPER}} .wk-cs-switch-wrapper.horizontal .wk-cs-switch.primary' => 'margin-bottom: {{SIZE}}{{UNIT}}; margin-right: unset;',
					'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .wk-cs-switch-wrapper.widescreen-vertical .wk-cs-switch.primary' => 'margin-bottom: {{SIZE}}{{UNIT}}; margin-right: unset;',
					'body[data-elementor-device-mode="desktop"] {{WRAPPER}} .wk-cs-switch-wrapper.desktop-vertical .wk-cs-switch.primary' => 'margin-bottom: {{SIZE}}{{UNIT}}; margin-right: unset;',
					'body[data-elementor-device-mode="laptop"] {{WRAPPER}} .wk-cs-switch-wrapper.laptop-vertical .wk-cs-switch.primary' => 'margin-bottom: {{SIZE}}{{UNIT}}; margin-right: unset;',
					'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .wk-cs-switch-wrapper.tablet-extra-vertical .wk-cs-switch.primary' => 'margin-bottom: {{SIZE}}{{UNIT}}; margin-right: unset;',
					'body[data-elementor-device-mode="tablet"] {{WRAPPER}} .wk-cs-switch-wrapper.tablet-vertical .wk-cs-switch.primary' => 'margin-bottom: {{SIZE}}{{UNIT}}; margin-right: unset;',
					'body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .wk-cs-switch-wrapper.mobile-extra-vertical .wk-cs-switch.primary' => 'margin-bottom: {{SIZE}}{{UNIT}}; margin-right: unset;',
					'body[data-elementor-device-mode="mobile"] {{WRAPPER}} .wk-cs-switch-wrapper.mobile-vertical .wk-cs-switch.primary' => 'margin-bottom: {{SIZE}}{{UNIT}}; margin-right: unset;',

					'{{WRAPPER}} .wk-cs-switch-wrapper.vertical .wk-cs-switch.secondary' => 'margin-top: {{SIZE}}{{UNIT}}; margin-left: unset;',
					'body[data-elementor-device-mode="widescreen"] {{WRAPPER}} .wk-cs-switch-wrapper.widescreen-vertical .wk-cs-switch.secondary' => 'margin-top: {{SIZE}}{{UNIT}}; margin-left: unset;',
					'body[data-elementor-device-mode="desktop"] {{WRAPPER}} .wk-cs-switch-wrapper.desktop-vertical .wk-cs-switch.secondary' => 'margin-top: {{SIZE}}{{UNIT}}; margin-left: unset;',
					'body[data-elementor-device-mode="laptop"] {{WRAPPER}} .wk-cs-switch-wrapper.laptop-vertical .wk-cs-switch.secondary' => 'margin-top: {{SIZE}}{{UNIT}}; margin-left: unset;',
					'body[data-elementor-device-mode="tablet_extra"] {{WRAPPER}} .wk-cs-switch-wrapper.tablet-extra-vertical .wk-cs-switch.secondary' => 'margin-top: {{SIZE}}{{UNIT}}; margin-left: unset;',
					'body[data-elementor-device-mode="tablet"] {{WRAPPER}} .wk-cs-switch-wrapper.tablet-vertical .wk-cs-switch.secondary' => 'margin-top: {{SIZE}}{{UNIT}}; margin-left: unset;',
					'body[data-elementor-device-mode="mobile_extra"] {{WRAPPER}} .wk-cs-switch-wrapper.mobile-extra-vertical .wk-cs-switch.secondary' => 'margin-top: {{SIZE}}{{UNIT}}; margin-left: unset;',
					'body[data-elementor-device-mode="mobile"] {{WRAPPER}} .wk-cs-switch-wrapper.mobile-vertical .wk-cs-switch.secondary' => 'margin-top: {{SIZE}}{{UNIT}}; margin-left: unset;',
				],
				'condition'  => [
					'select_design' => ['round', 'round-2', 'square', 'square-2'],
				],
			]
		);

		$this->start_controls_tabs(
			'label_tabs'
		);

		$this->start_controls_tab(
			'label_style_normal',
			[
				'label' => __( 'Normal', 'wakoo' ),
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => __( 'Title Color', 'wakoo' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-switch span' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => __( 'Icon Color', 'wakoo' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button div > i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-switch div > i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button div > svg' => 'fill: {{VALUE}}',
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-switch div > svg' => 'fill: {{VALUE}}',

				],
			]
		);

		$this->add_control(
			'title_bg_color',
			[
				'label'     => __( 'Background Color', 'wakoo' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'select_design' => ['button'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'title_border_normal',
				'label'     => __( 'Border', 'wakoo' ),
				'selector'  => '{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button',
				'condition' => [
					'select_design' => ['button'],
				],
			]
		);

		$this->add_control(
			'button_border_radius',
			[
				'label'      => __( 'Border Radius', 'wakoo' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'default'    => [
					'top'      => '30',
					'right'    => '30',
					'bottom'   => '30',
					'left'     => '30',
					'unit'     => 'px',
					'isLinked' => 'true',
				],
				'selectors'  => [
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'select_design' => ['button'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'title_box_shadow',
				'label'     => __( 'Box Shadow', 'wakoo' ),
				'selector'  => '{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button',
				'condition' => [
					'select_design' => ['button'],
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'label_style_active',
			[
				'label' => __( 'Active', 'wakoo' ),
			]
		);

		$this->add_control(
			'title_color_active',
			[
				'label'     => __( 'Title Color', 'wakoo' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button.active span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-switch.active span' => 'color: {{VALUE}}',

				],
			]
		);

		$this->add_control(
			'icon_color_active',
			[
				'label'     => __( 'Icon Color', 'wakoo' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button.active i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-switch.active i' => 'color: {{VALUE}}',
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button.active svg' => 'fill: {{VALUE}}',
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-switch.active svg' => 'fill: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'title_bg_color_active',
			[
				'label'     => __( 'Background Color', 'wakoo' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button.active' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'select_design' => ['button'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'title_border_active',
				'label'     => __( 'Border', 'wakoo' ),
				'selector'  => '{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button.active',
				'condition' => [
					'select_design' => ['button'],
				],
			]
		);

		$this->add_control(
			'button_border_radius_active',
			[
				'label'      => __( 'Border Radius', 'wakoo' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'default'    => [
					'top'      => '30',
					'right'    => '30',
					'bottom'   => '30',
					'left'     => '30',
					'unit'     => 'px',
					'isLinked' => 'true',
				],
				'selectors'  => [
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'select_design' => ['button'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'title_box_shadow_active',
				'label'     => __( 'Box Shadow', 'wakoo' ),
				'selector'  => '{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button.active',
				'condition' => [
					'select_design' => ['button'],
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'button_padding',
			[
				'label'      => __( 'Padding', 'wakoo' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'default'    => [
					'top'      => '10',
					'right'    => '20',
					'bottom'   => '10',
					'left'     => '20',
					'unit'     => 'px',
					'isLinked' => '',
				],
				'selectors'  => [
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'select_design' => ['button'],
				],
				'separator'  => 'before',
			]
		);

		$this->add_responsive_control(
			'button_margin',
			[
				'label'      => __( 'Margin', 'wakoo' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'default'    => [
					'top'      => '5',
					'right'    => '5',
					'bottom'   => '5',
					'left'     => '5',
					'unit'     => 'px',
					'isLinked' => 'true',
				],
				'selectors'  => [
					'{{WRAPPER}} .wk-cs-switch-wrapper .wk-cs-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'select_design' => ['button'],
				],
			]
		);

		$this->add_control(
			'box_style',
			[
				'label'     => __( 'Box Style', 'wakoo' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'select_design' => ['button'],
				],
			]
		);

		$this->add_control(
			'title_box_bg_color',
			[
				'label'     => __( 'Box Color', 'wakoo' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#FFF',
				'selectors' => [
					'{{WRAPPER}} .wk-cs-switch-wrapper' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'select_design' => ['button'],
				],
			]
		);

		$this->add_responsive_control(
			'box_padding',
			[
				'label'      => __( 'Box Padding', 'wakoo' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'default'    => [
					'top'      => '5',
					'right'    => '5',
					'bottom'   => '5',
					'left'     => '5',
					'unit'     => 'px',
					'isLinked' => 'true',
				],
				'selectors'  => [
					'{{WRAPPER}} .wk-cs-switch-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'select_design' => ['button'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'box_border',
				'label'     => __( 'Border', 'wakoo' ),
				'selector'  => '{{WRAPPER}} .wk-cs-switch-wrapper',
				'condition' => [
					'select_design' => ['button'],
				],
			]
		);

		$this->add_control(
			'box_border_radius',
			[
				'label'      => __( 'Border Radius', 'wakoo' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'default'    => [
					'top'      => '50',
					'right'    => '50',
					'bottom'   => '50',
					'left'     => '50',
					'unit'     => 'px',
					'isLinked' => 'true',
				],
				'selectors'  => [
					'{{WRAPPER}} .wk-cs-switch-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'select_design' => ['button'],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'box_box_shadow',
				'label'    => __( 'Box Shadow', 'wakoo' ),
				'selector' => '{{WRAPPER}} .wk-cs-switch-wrapper',
			]
		);

		$this->end_controls_section();
	}

	protected function __switcher_control_style_controls() {

		$this->start_controls_section(
			'_section_style_switcher_control',
			[
				'label'     => __( 'Switcher Control', 'wakoo' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'select_design' => ['round', 'round-2', 'square', 'square-2'],
				],
			]
		);

		$this->add_control(
			'switch_style_size',
			[
				'label'      => __( 'Switch Size (px)', 'wakoo' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', '%'],
				'range'      => [
					'px' => [
						'min'  => 1,
						'max'  => 200,
						'step' => 1,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 12,
				],
				'selectors'  => [
					'{{WRAPPER}} .wk-cs-switch-container .wk-cs-switch.wk-input-label' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs(
			'switch_style_tabs'
		);

		$this->start_controls_tab(
			'switch_style_normal_tab',
			[
				'label' => __( 'Normal', 'wakoo' ),
			]
		);

		$this->add_control(
			'switch_color',
			[
				'label'     => __( 'Color', 'wakoo' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-input-label .wk-cs-slider:before' => 'background-color : {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'switch_background_color',
			[
				'label'     => __( 'Background Color', 'wakoo' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-input-label .wk-cs-slider' => 'background-color : {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'switch_style_active_tab',
			[
				'label' => __( 'Active', 'wakoo' ),
			]
		);

		$this->add_control(
			'switch_color_active',
			[
				'label'     => __( 'Color', 'wakoo' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-input-label input:checked+.wk-cs-slider:before' => 'background-color : {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'switch_background_color_active',
			[
				'label'     => __( 'Background Color', 'wakoo' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-input-label input:checked+.wk-cs-slider' => 'background-color : {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function __switch_bar_style_controls() {

		$this->start_controls_section(
			'_section_style_switch_bar',
			[
				'label' => __( 'Switch Bar', 'wakoo' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'title_section_padding',
			[
				'label'      => __( 'Section Padding', 'wakoo' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .wk-content-switcher-wrapper .wk-cs-switch-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'title_section_bg_color',
				'label'    => __( 'Background', 'wakoo' ),
				'types'    => ['classic', 'gradient'],
				'selector' => '{{WRAPPER}} .wk-content-switcher-wrapper .wk-cs-switch-container',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'title_section_border',
				'label'    => __( 'Border', 'wakoo' ),
				'selector' => '{{WRAPPER}} .wk-content-switcher-wrapper .wk-cs-switch-container',
			]
		);

		$this->add_control(
			'title_section_border_radius',
			[
				'label'      => __( 'Border Radius', 'wakoo' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .wk-content-switcher-wrapper .wk-cs-switch-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'title_section_shadow',
				'label'    => __( 'Box Shadow', 'wakoo' ),
				'selector' => '{{WRAPPER}} .wk-content-switcher-wrapper .wk-cs-switch-container',
			]
		);

		$this->end_controls_section();
	}

	protected function __content_style_controls() {

		$this->start_controls_section(
			'_section_style_content',
			[
				'label' => __( 'Content', 'wakoo' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'content_padding',
			[
				'label'      => __( 'Padding', 'wakoo' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', 'em', '%'],
				'selectors'  => [
					'{{WRAPPER}} .wk-content-switcher-wrapper .wk-cs-content-container .wk-cs-content-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'           => 'content_typography',
				'fields_options' => [
					'typography'  => [
						'default' => 'yes',
					],
					'font_family' => [
						'default' => 'Arial',
					],
					'font_weight' => [
						'default' => '600',
					],
				],
				'selector'       => '{{WRAPPER}} .wk-content-switcher-wrapper .wk-cs-content-section',
			]
		);

		$this->add_control(
			'content_color',
			[
				'label'     => __( 'Color', 'wakoo' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-cs-content-container .wk-cs-content-wrapper .wk-cs-content-section' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'content_box_bg_color',
				'label'    => __( 'Background', 'wakoo' ),
				'types'    => ['classic', 'gradient', 'video'],
				'selector' => '{{WRAPPER}} .wk-content-switcher-wrapper .wk-cs-content-container .wk-cs-content-wrapper',
			]
		);

		$this->add_control(
			'contetn_box_alignment',
			[
				'label'     => __( 'Alignment', 'wakoo' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => __( 'Left', 'wakoo' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'wakoo' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => __( 'Right', 'wakoo' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'center',
				'selectors' => [
					'{{WRAPPER}} .wk-content-switcher-wrapper' => 'text-align: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'content_box',
				'label'    => __( 'Border', 'wakoo' ),
				'selector' => '{{WRAPPER}} .wk-content-switcher-wrapper .wk-cs-content-container .wk-cs-content-wrapper',

			]
		);
		$this->add_control(
			'content_border_radius',
			[
				'label'      => __( 'Border Radius', 'wakoo' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .wk-content-switcher-wrapper .wk-cs-content-container .wk-cs-content-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'content_box_shadow',
				'label'    => __( 'Box Shadow', 'wakoo' ),
				'selector' => '{{WRAPPER}} .wk-content-switcher-wrapper .wk-cs-content-container .wk-cs-content-wrapper',

			]
		);

		$this->end_controls_section();
	}

	public function get_script_depends() { return [ 'wakoo-theme' ]; }

	public function get_style_depends() { return [ 'wakoo-theme' ]; }

	/** Prints the content of one state: text, saved template, or own image/video/audio. Empty states show a hint in the editor only. */
	protected function render_item_content( $item ) {
		$type = isset( $item['content_type'] ) ? $item['content_type'] : 'plain_content';
		ob_start();
		if ( 'plain_content' === $type ) {
			echo wk_kses_intermediate( isset( $item['plain_content'] ) ? $item['plain_content'] : '' ); // phpcs:ignore
		} elseif ( in_array( $type, [ 'saved_section', 'saved_container', 'saved_page' ], true ) ) {
			$key = 'saved_page' === $type ? 'saved_pages' : $type;
			$id  = isset( $item[ $key ] ) ? (int) $item[ $key ] : 0;
			if ( $id && 'publish' === get_post_status( $id ) ) {
				$id = apply_filters( 'wpml_object_id', $id, 'elementor_library' );
				echo wk_elementor()->frontend->get_builder_content_for_display( $id ); // phpcs:ignore
			}
		} elseif ( 'image' === $type && ! empty( $item['media_image']['url'] ) ) {
			$alt = ! empty( $item['media_caption'] ) ? $item['media_caption'] : '';
			echo '<figure class="wk-cs-media"><img src="' . esc_url( $item['media_image']['url'] ) . '" alt="' . esc_attr( $alt ) . '" loading="lazy" decoding="async">';
			if ( $alt ) { echo '<figcaption>' . esc_html( $alt ) . '</figcaption>'; }
			echo '</figure>';
		} elseif ( 'video' === $type && ! empty( $item['media_video']['url'] ) ) {
			$poster = ! empty( $item['media_poster']['url'] ) ? ' poster="' . esc_url( $item['media_poster']['url'] ) . '"' : '';
			echo '<figure class="wk-cs-media"><video controls preload="none" playsinline' . $poster . '><source src="' . esc_url( $item['media_video']['url'] ) . '"></video>'; // phpcs:ignore
			if ( ! empty( $item['media_caption'] ) ) { echo '<figcaption>' . esc_html( $item['media_caption'] ) . '</figcaption>'; }
			echo '</figure>';
		} elseif ( 'audio' === $type && ! empty( $item['media_audio']['url'] ) ) {
			echo '<figure class="wk-cs-media"><audio controls preload="none" src="' . esc_url( $item['media_audio']['url'] ) . '"></audio>';
			if ( ! empty( $item['media_caption'] ) ) { echo '<figcaption>' . esc_html( $item['media_caption'] ) . '</figcaption>'; }
			echo '</figure>';
		}
		$out = ob_get_clean();
		if ( '' === trim( $out ) ) {
			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode() ) {
				echo '<div class="wk-cs-empty">' . esc_html__( 'Este estado está vacío. Añade texto, una plantilla, una imagen, un vídeo o un audio.', 'wakoo' ) . '</div>';
			}
			return;
		}
		echo $out; // phpcs:ignore
	}

	protected function render() {
		$settings  = $this->get_settings_for_display();
		$primary   = ( isset( $settings['content_list'][0] ) ? $settings['content_list'][0] : '' );
		$secondary = ( isset( $settings['content_list'][1] ) ? $settings['content_list'][1] : '' );

		$class_for_direction  = (!empty($settings['switch_direction_widescreen']))? 'widescreen-' . $settings['switch_direction_widescreen']: '';
		$class_for_direction .= (!empty($settings['switch_direction']))? ' desktop-' . $settings['switch_direction']: '';
		$class_for_direction .= (!empty($settings['switch_direction']))? ' ' . $settings['switch_direction']: '';
		$class_for_direction .= (!empty($settings['switch_direction_laptop']))? ' laptop-' . $settings['switch_direction_laptop']: '';
		$class_for_direction .= (!empty($settings['switch_direction_tablet_extra']))? ' tablet-extra-' . $settings['switch_direction_tablet_extra']: '';
		$class_for_direction .= (!empty($settings['switch_direction_tablet']))? ' tablet-' . $settings['switch_direction_tablet']: '';
		$class_for_direction .= (!empty($settings['switch_direction_mobile_extra']))? ' mobile-extra-' . $settings['switch_direction_mobile_extra']: '';
		$class_for_direction .= (!empty($settings['switch_direction_mobile']))? ' mobile-' . $settings['switch_direction_mobile']: '';

		?>
		<div class="wk-content-switcher-wrapper wk-cs-design-<?php echo esc_attr( $settings['select_design'] ); ?>"<?php echo ( 'yes' === $settings['apply_site'] ) ? ' data-wk-theme-site="1"' : ''; ?> data-design-type="<?php echo esc_attr( $settings['select_design'] ); ?>">
			<div class="wk-cs-switch-container">
				<div class="wk-cs-switch-wrapper <?php echo esc_attr($class_for_direction); ?>">
					<?php if ( $settings['select_design'] == 'button' ) : ?>
						<?php foreach ( $settings['content_list'] as $i => $item ) : ?>
							<button class="wk-cs-button <?php echo esc_attr( ( $item['active'] == 'yes' ) ? 'active' : '' ); ?> wk-cs-icon-<?php echo esc_attr( $item['icon_align'] ); ?>" data-content-id="<?php echo esc_attr( $item['_id'] ); ?>">
								<?php if ( ! empty( $item['icon']['value'] ) ) : ?>
									<div class="wk-cs-icon-wrapper"><?php wk_render_icon( $item, null, 'icon' ); ?></div>
								<?php endif; ?>
								<span><?php echo esc_html( $item['title'] ); ?></span>
							</button>
						<?php endforeach; ?>
						<?php
					else :
						?>
						<div class="wk-cs-switch primary <?php echo esc_attr( ( $primary['active'] == 'yes' ) ? 'active' : '' ); ?> wk-cs-icon-<?php echo esc_attr( $primary['icon_align'] ); ?>" data-content-id="<?php echo esc_attr( $primary['_id'] ); ?>">
							<?php if ( ! empty( $primary['icon']['value'] ) ) : ?>
								<div class="wk-cs-icon-wrapper"><?php wk_render_icon( $primary, null, 'icon' ); ?></div>
							<?php endif; ?>
							<span><?php echo esc_html( $primary['title'] ); ?></span>
						</div>

						<label class="wk-cs-switch wk-input-label">
							<input class="wk-cs-toggle-switch" type="checkbox" <?php echo esc_attr( ( $secondary['active'] == 'yes' ) ? 'checked' : '' ); ?>>
							<span class="wk-cs-slider wk-cs-<?php echo esc_attr( $settings['select_design'] ); ?>"></span>
						</label>

						<div class="wk-cs-switch secondary <?php echo esc_attr( ( $secondary['active'] == 'yes' ) ? 'active' : '' ); ?> wk-cs-icon-<?php echo esc_attr( $secondary['icon_align'] ); ?>" data-content-id="<?php echo esc_attr( $secondary['_id'] ); ?>">
							<?php if ( ! empty( $secondary['icon']['value'] ) ) : ?>
								<div class="wk-cs-icon-wrapper"><?php wk_render_icon( $secondary, null, 'icon' ); ?></div>
							<?php endif; ?>
							<span><?php echo esc_html( $secondary['title'] ); ?></span>
						</div>

					<?php endif; ?>
				</div>
			</div>
			<div class="wk-cs-content-container">
				<div class="wk-cs-content-wrapper <?php echo esc_attr( $class_for_direction ); ?>">
					<?php if ( $settings['select_design'] == 'button' ) : ?>
						<?php foreach ( $settings['content_list'] as $i => $item ) : ?>
							<div id="<?php echo esc_attr( $item['_id'] ); ?>" class="wk-cs-content-section <?php echo esc_attr( ( $item['active'] == 'yes' ) ? 'active' : '' ); ?>">
								<?php $this->render_item_content( $item ); ?>
							</div>
						<?php endforeach; ?>
						<?php
					else :
						?>
						<div id="<?php echo esc_attr( $primary['_id'] ); ?>" class="wk-cs-content-section primary <?php echo esc_attr( ( $primary['active'] == 'yes' ) ? 'active' : '' ); ?>">
							<?php $this->render_item_content( $primary ); ?>
						</div>

						<div id="<?php echo esc_attr( $secondary['_id'] ); ?>" class="wk-cs-content-section secondary <?php echo esc_attr( ( $secondary['active'] == 'yes' ) ? 'active' : '' ); ?>">
							<?php $this->render_item_content( $secondary ); ?>
						</div>

					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}
}
