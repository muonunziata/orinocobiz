<?php
/**
 * Social Icons widget class
 *
 * @package Wakoo
 */

namespace Wakoo\Elementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Border;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

defined('ABSPATH') || die();

class Social_Icons extends Base {

	/**
	 * Get widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __('Social Icons', 'wakoo');
	}

	/**
	 * Get widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon() {
		return 'hm hm-bond2';
	}

	public function get_keywords() {
		return ['social', 'icons', 'media', 'facebook', 'fb', 'twitter', 'linkedin'];
	}

	protected function is_dynamic_content(): bool {
		return false;
	}

	/**
     * Register widget content controls
     */
	protected function register_content_controls() {

		$this->start_controls_section(
			'_section_wk_social_icons_contents',
			[
				'label' => __('Icon', 'wakoo'),
				'tab'   => Controls_Manager::TAB_CONTENT
			]
		);
		$repeater = new Repeater();

		$repeater->add_control(
			'wk_social_icon',
			[
				'label'       => __('Icon', 'wakoo'),
				'type'        => Controls_Manager::ICONS,
				'label_block' => false,
				'default'     => [
					'value'   => 'fab fa-wordpress',
					'library' => 'fa-brands',
				],
				'skin' => 'inline',
				'exclude_inline_options' => ['svg'],
				'recommended' => [
					'fa-brands' => [
						'android',
						'apple',
						'behance',
						'bitbucket',
						'codepen',
						'delicious',
						'deviantart',
						'digg',
						'dribbble',
						'wakoo',
						'facebook',
						'flickr',
						'foursquare',
						'free-code-camp',
						'github',
						'gitlab',
						'globe',
						'google-plus',
						'houzz',
						'instagram',
						'jsfiddle',
						'linkedin',
						'medium',
						'meetup',
						'mixcloud',
						'odnoklassniki',
						'pinterest',
						'product-hunt',
						'reddit',
						'shopping-cart',
						'skype',
						'slideshare',
						'snapchat',
						'soundcloud',
						'spotify',
						'stack-overflow',
						'steam',
						'stumbleupon',
						'telegram',
						'thumb-tack',
						'tripadvisor',
						'tumblr',
						'twitch',
						'twitter',
						'viber',
						'vimeo',
						'vk',
						'weibo',
						'weixin',
						'whatsapp',
						'wordpress',
						'xing',
						'yelp',
						'youtube',
						'500px',
					],
				],
			]
		);

		$repeater->add_control(
			'wk_social_link',
			[
				'label'       => __('Link', 'wakoo'),
				'type'        => Controls_Manager::URL,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'default' => [
					'url' => '#'
				],
				'placeholder' => __('https://your-social-link.com', 'wakoo'),
			]
		);


		// repeater icon text field
		$repeater->add_control(
			'wk_enable_text',
			[
				'label'          => __('Enable Text', 'wakoo'),
				'type'           => Controls_Manager::SWITCHER,
				'label_on'       => __('Yes', 'wakoo'),
				'label_off'      => __('No', 'wakoo'),
				'return_value'   => 'yes',
				'style_transfer' => true,
				'separator'      => 'before'
			]
		);

		$repeater->add_control(
			'wk_social_icon_title',
			[
				'label'     => __('Social Name', 'wakoo'),
				'type'      => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'condition' => [
					'wk_enable_text' => 'yes'
				],
			]
		);

		$repeater->add_control(
			'customize',
			[
				'label'          => __('Want To Customize?', 'wakoo'),
				'type'           => Controls_Manager::SWITCHER,
				'label_on'       => __('Yes', 'wakoo'),
				'label_off'      => __('No', 'wakoo'),
				'return_value'   => 'yes',
				'style_transfer' => true,
				'separator'      => 'before'
			]
		);

		$repeater->start_controls_tabs(
			'_tab_social_icon_colors',
			[
				'condition' => ['customize' => 'yes']
			]
		);
		$repeater->start_controls_tab(
			'_tab_wk_social_icon_normal',
			[
				'label' => __('Normal', 'wakoo'),
			]
		);

		$repeater->add_control(
			'wk_social_icon_color',
			[
				'label' => __('Color', 'wakoo'),
				'type'  => Controls_Manager::COLOR,

				'selectors'      => [
					'{{WRAPPER}} .wk-social-icons-wrapper > {{CURRENT_ITEM}}.wk-social-icon' => 'color: {{VALUE}};',
					'{{WRAPPER}} .wk-social-icons-wrapper > {{CURRENT_ITEM}}.wk-social-icon svg' => 'fill: {{VALUE}};',
				],
				'condition'      => ['customize' => 'yes'],
				'style_transfer' => true,
			]
		);
		$repeater->add_control(
			'wk_social_icon_bg_color',
			[
				'label' => __('Background Color', 'wakoo'),
				'type'  => Controls_Manager::COLOR,

				'selectors'      => [
					'{{WRAPPER}} .wk-social-icons-wrapper > {{CURRENT_ITEM}}.wk-social-icon' => 'background-color: {{VALUE}};',
				],
				'condition'      => ['customize' => 'yes'],
				'style_transfer' => true,
			]
		);

		$repeater->add_control(
			'social_icon_border_color',
			[
				'label'          => __('Border Color', 'wakoo'),
				'type'           => Controls_Manager::COLOR,
				'condition'      => ['customize' => 'yes'],
				'style_transfer' => true,
				'selectors'      => [
					'{{WRAPPER}} .wk-social-icons-wrapper {{CURRENT_ITEM}}' => 'border-color: {{VALUE}};',
				]
			]
		);

		$repeater->end_controls_tab();

		$repeater->start_controls_tab(
			'_tab_social_icon_hover',
			[
				'label' => __('Hover', 'wakoo'),
			]
		);

		$repeater->add_control(
			'wk_social_icon_hover_color',
			[
				'label'          => __('Color', 'wakoo'),
				'type'           => Controls_Manager::COLOR,
				'selectors'      => [
					'{{WRAPPER}} .wk-social-icons-wrapper > {{CURRENT_ITEM}}.wk-social-icon:hover'     => 'color: {{VALUE}};',
					'{{WRAPPER}} .wk-social-icons-wrapper > {{CURRENT_ITEM}}.wk-social-icon:hover svg'     => 'fill: {{VALUE}};',
				],
				'condition'      => ['customize' => 'yes'],
				'style_transfer' => true,
			]
		);
		$repeater->add_control(
			'wk_social_icon_hover_bg_color',
			[
				'label'          => __('Background Color', 'wakoo'),
				'type'           => Controls_Manager::COLOR,
				'selectors'      => [
					'{{WRAPPER}} .wk-social-icons-wrapper > {{CURRENT_ITEM}}.wk-social-icon:hover' => 'background-color: {{VALUE}};',
				],
				'condition'      => ['customize' => 'yes'],
				'style_transfer' => true,
			]
		);
		$repeater->add_control(
			'social_icon_hover_border_color',
			[
				'label'          => __('Border Color', 'wakoo'),
				'type'           => Controls_Manager::COLOR,
				'condition'      => ['customize' => 'yes'],
				'style_transfer' => true,
				'selectors'      => [
					'{{WRAPPER}} .wk-social-icons-wrapper {{CURRENT_ITEM}}.wk-social-icon:hover' => 'border-color: {{VALUE}};',
				]
			]
		);

		$repeater->end_controls_tab();
		$repeater->end_controls_tabs();

		$this->add_control(
			'wk_social_icon_list',
			[
				'label'       => __('Social Icons', 'wakoo'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'wk_social_icon' => [
							'value'   => 'fab fa-facebook',
							'library' => 'fa-brands',
						],
						'wk_social_link' => [
							'url' => '#'
						],
					],
					[
						'wk_social_icon' => [
							'value'   => 'fab fa-twitter',
							'library' => 'fa-brands',
						],
						'wk_social_link' => [
							'url' => '#'
						],
					],
					[
						'wk_social_icon' => [
							'value'   => 'fab fa-linkedin',
							'library' => 'fa-brands',
						],
						'wk_social_link' => [
							'url' => '#'
						],
					],
				],
				'title_field' => '<# print(elementor.helpers.getSocialNetworkNameFromIcon( wk_social_icon ) || wk_social_icon_title); #>',
			]
		);

		$this->add_control(
			'social_media_separator',
			[
				'label'        => __('Show Separator', 'wakoo'),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'separator_type',
			[
				'label'        => __('Type', 'wakoo'),
				'type'         => Controls_Manager::SELECT,
				'options'      => [
					'stroke' => __('Stroke', 'wakoo'),
					'custom' => __('Custom', 'wakoo'),
				],
				'default'      => 'stroke',
				'condition'    => [
					'social_media_separator' => 'yes'
				],
				'prefix_class' => 'wk-separator--',
				'render_type'  => 'template',
			]
		);

		$this->add_control(
			'default_separator',
			[
				'label'       => __('Stroke Size', 'wakoo'),
				'type'        => Controls_Manager::SLIDER,
				'condition'   => [
					'social_media_separator' => 'yes',
					'separator_type'         => 'stroke'
				],
				'size_units'  => ['px', 'em'],
				'selectors'   => [
					'{{WRAPPER}}.wk-separator--stroke .wk-social-icon-separator' => 'width: {{SIZE}}{{UNIT}} !important;',
				],
				'render_type' => 'template'
			]
		);

		$this->add_control(
			'separator_color',
			[
				'label'     => __('Color', 'wakoo'),
				'type'      => Controls_Manager::COLOR,
				'condition' => [
					'social_media_separator' => 'yes',
					'separator_type'         => 'stroke'
				],
				'selectors' => [
					'{{WRAPPER}}.wk-separator--stroke .wk-social-icon-separator' => 'background: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'custom_separator',
			[
				'label'       => __('Custom Character', 'wakoo'),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'condition'   => [
					'social_media_separator' => 'yes',
					'separator_type'         => 'custom'
				],
				'render_type' => 'template'
			]
		);


		$this->add_responsive_control(
			'wk_social_icon_align',
			[
				'label'       => __('Alignment', 'wakoo'),
				'type'        => Controls_Manager::CHOOSE,
				'options'     => [
					'left'   => [
						'title' => __('Left', 'wakoo'),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __('Center', 'wakoo'),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => __('Right', 'wakoo'),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'     => 'center',
				'selectors'   => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
				'separator'   => 'before',
				'render_type' => 'ui'
			]
		);

		$this->add_control(
			'sticky_options',
			[
				'label'        => __('Enable Sticky', 'wakoo'),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'separator'    => 'before',
			]
		);

		$this->end_controls_section();
	}

	/**
     * Register widget style controls
     */
	protected function register_style_controls() {
		$this->__common_style_controls();
		$this->__icon_style_controls();
		$this->__social_name_style_controls();
		$this->__separator_style_controls();
	}

	protected function __common_style_controls() {

		$this->start_controls_section(
			'_section_common_style',
			[
				'label' => __('Common', 'wakoo'),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);

		$this->start_controls_tabs('_tab_social_icons_colors');

		$this->start_controls_tab(
			'_tab_normal_social_color',
			[
				'label' => __('Normal', 'wakoo'),
			]
		);

		$this->add_control(
			'social_icons_color',
			[
				'label' => __('Color', 'wakoo'),
				'type'  => Controls_Manager::COLOR,

				'selectors'      => [
					'{{WRAPPER}} .wk-social-icons-wrapper > .wk-social-icon'       => 'color: {{VALUE}};',
					'{{WRAPPER}} .wk-social-icons-wrapper > .wk-social-icon svg'   => 'fill: {{VALUE}};',
					'{{WRAPPER}}.wk-separator--stroke .wk-social-icon-separator'   => 'background: {{VALUE}};',
					'{{WRAPPER}}.wk-separator--custom .wk-social-icon-separator'   => 'color: {{VALUE}};',
				],
				'style_transfer' => true,
			]
		);
		$this->add_control(
			'social_icons_bg_color',
			[
				'label' => __('Background Color', 'wakoo'),
				'type'  => Controls_Manager::COLOR,

				'selectors'      => [
					'{{WRAPPER}} .wk-social-icons-wrapper .wk-social-icon' => 'background-color: {{VALUE}};',
				],
				'style_transfer' => true,
			]
		);

		$this->add_control(
			'social_icon_common_border_color',
			[
				'label'     => __('Border Color', 'wakoo'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-social-icons-wrapper .wk-social-icon' => 'border-color: {{VALUE}};',
				]
			]
		);

		$this->end_controls_tab();
		$this->start_controls_tab(
			'_tab_social_icons_hover',
			[
				'label' => __('Hover', 'wakoo'),
			]
		);

		$this->add_control(
			'social_icons_hover_color',
			[
				'label'          => __('Color', 'wakoo'),
				'type'           => Controls_Manager::COLOR,
				'selectors'      => [
					'{{WRAPPER}} .wk-social-icons-wrapper > .wk-social-icon:hover'     => 'color: {{VALUE}};',
					'{{WRAPPER}} .wk-social-icons-wrapper > .wk-social-icon:hover svg'   => 'fill: {{VALUE}};',
					'{{WRAPPER}}.wk-separator--stroke .wk-social-icon-separator'       => 'background: {{VALUE}};',
					'{{WRAPPER}}.wk-separator--custom .wk-social-icon-separator'       => 'color: {{VALUE}};',
				],
				'style_transfer' => true,
			]
		);
		$this->add_control(
			'social_icons_hover_bg_color',
			[
				'label'          => __('Background Color', 'wakoo'),
				'type'           => Controls_Manager::COLOR,
				'selectors'      => [
					'{{WRAPPER}} .wk-social-icon:hover' => 'background-color: {{VALUE}};',
				],
				'style_transfer' => true,
			]
		);

		$this->add_control(
			'social_icon_common_hover_border_color',
			[
				'label'     => __('Border Color', 'wakoo'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-social-icons-wrapper .wk-social-icon:hover' => 'border-color: {{VALUE}};',
				]
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_responsive_control(
			'wk_social_icon_global_padding',
			[
				'label'          => __('Padding', 'wakoo'),
				'type'           => Controls_Manager::DIMENSIONS,
				'selectors'      => [
					'{{WRAPPER}} .wk-social-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'size_units'     => ['px', 'em'],
				'default'        => [
					'unit' => 'px',
				],
				'tablet_default' => [
					'unit' => 'px',
				],
				'mobile_default' => [
					'unit' => 'px',
				],
				'range'          => [
					'px' => [
						'min' => 20,
						'max' => 300
					],
					'em' => [
						'min' => 0,
						'max' => 5,
					],
				],
			]
		);

		$icon_spacing = is_rtl() ? 'margin-left: {{SIZE}}{{UNIT}};' : 'margin-right: {{SIZE}}{{UNIT}};';

		$this->add_responsive_control(
			'wk_social_icon_spacing',
			[
				'label'     => __('Social Spacing', 'wakoo'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .wk-social-icon:not(:last-child)' => $icon_spacing,
					'{{WRAPPER}} .wk-social-icon-separator'        => $icon_spacing,
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'image_border',
				'selector'  => '{{WRAPPER}} .wk-social-icon',
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'wk_social_icon_border_radius',
			[
				'label'      => __('Border Radius', 'wakoo'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors'  => [
					'{{WRAPPER}} .wk-social-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icons_box_shadow',
				//'selector'      => '{{WRAPPER}} .wk-social-icon, {{WRAPPER}} .wk-social-icon-separator',
				'selector' => '{{WRAPPER}} .wk-social-icon',
			]
		);

		$this->end_controls_section();
	}

	protected function __icon_style_controls() {

		$this->start_controls_section(
			'_section_style_wk_icon',
			[
				'label' => __('Icon', 'wakoo'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'wk_social_icon_size',
			[
				'label'     => __('Size', 'wakoo'),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 20,
						'max' => 300,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .wk-social-icon.wk-social-icon--network'   => 'font-size: {{SIZE}}{{UNIT}};',
					// '{{WRAPPER}} .wk-social-icon.wk-social-icon--network i'   => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'wk_social_icon_padding',
			[
				'label'          => __('Padding', 'wakoo'),
				'type'           => Controls_Manager::SLIDER,
				'selectors'      => [
					'{{WRAPPER}} .wk-social-icon.wk-social-icon--network' => 'padding: {{SIZE}}{{UNIT}};',
				],
				'default'        => [
					'unit' => 'em',
				],
				'tablet_default' => [
					'unit' => 'em',
				],
				'mobile_default' => [
					'unit' => 'em',
				],
				'range'          => [
					'em' => [
						'min' => 0,
						'max' => 5,
					],
				],
			]
		);

		$this->add_control(
			'hover_animation',
			[
				'label'   => __('Hover Animation', 'wakoo'),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'none'                   => __('None', 'wakoo'),
					'2d-transition'          => __('2D Animation', 'wakoo'),
					'background-transition'  => __('Background Animation', 'wakoo'),
					'shadow-glow-transition' => __('Shadow and Glow Animation', 'wakoo'),
				]
			]
		);

		$this->add_control(
			'hover_2d_css_animation',
			[
				'label'     => __('Animation', 'wakoo'),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'hvr-grow'                   => __('Grow', 'wakoo'),
					'hvr-shrink'                 => __('Shrink', 'wakoo'),
					'hvr-pulse'                  => __('Pulse', 'wakoo'),
					'hvr-pulse-grow'             => __('Pulse Grow', 'wakoo'),
					'hvr-pulse-shrink'           => __('Pulse Shrink', 'wakoo'),
					'hvr-push'                   => __('Push', 'wakoo'),
					'hvr-pop'                    => __('Pop', 'wakoo'),
					'hvr-bounce-in'              => __('Bounce In', 'wakoo'),
					'hvr-bounce-out'             => __('Bounce Out', 'wakoo'),
					'hvr-rotate'                 => __('Rotate', 'wakoo'),
					'hvr-grow-rotate'            => __('Grow Rotate', 'wakoo'),
					'hvr-float'                  => __('Float', 'wakoo'),
					'hvr-sink'                   => __('Sink', 'wakoo'),
					'hvr-bob'                    => __('Bob', 'wakoo'),
					'hvr-hang'                   => __('Hang', 'wakoo'),
					'hvr-wobble-vertical'        => __('Wobble Vertical', 'wakoo'),
					'hvr-wobble-horizontal'      => __('Wobble Horizontal', 'wakoo'),
					'hvr-wobble-to-bottom-right' => __('Wobble To Bottom Right', 'wakoo'),
					'hvr-wobble-to-top-right'    => __('Wobble To Top Right', 'wakoo'),
					'hvr-buzz'                   => __('Buzz', 'wakoo'),
					'hvr-buzz-out'               => __('Buzz Out', 'wakoo'),
				],
				'condition' => [
					'hover_animation' => '2d-transition'
				]
			]
		);

		$this->add_control(
			'hover_background_css_animation',
			[
				'label'     => __('Animation', 'wakoo'),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'hvr-fade'                   => __('Fade', 'wakoo'),
					'hvr-back-pulse'             => __('Back Pulse', 'wakoo'),
					'hvr-sweep-to-right'         => __('Sweep To Right', 'wakoo'),
					'hvr-sweep-to-left'          => __('Sweep To Left', 'wakoo'),
					'hvr-sweep-to-bottom'        => __('Sweep To Bottom', 'wakoo'),
					'hvr-sweep-to-top'           => __('Sweep To Top', 'wakoo'),
					'hvr-bounce-to-right'        => __('Bounce To Right', 'wakoo'),
					'hvr-bounce-to-left'         => __('Bounce To Left', 'wakoo'),
					'hvr-bounce-to-bottom'       => __('Bounce To Bottom', 'wakoo'),
					'hvr-bounce-to-top'          => __('Bounce To Top', 'wakoo'),
					'hvr-radial-out'             => __('Radial Out', 'wakoo'),
					'hvr-radial-in'              => __('Radial In', 'wakoo'),
					'hvr-rectangle-in'           => __('Rectangle In', 'wakoo'),
					'hvr-rectangle-out'          => __('Rectangle Out', 'wakoo'),
					'hvr-shutter-in-horizontal'  => __('Shutter In Horizontal', 'wakoo'),
					'hvr-shutter-out-horizontal' => __('Shutter Out Horizontal', 'wakoo'),
					'hvr-shutter-in-vertical'    => __('Shutter In Vertical', 'wakoo'),
					'hvr-shutter-out-vertical'   => __('Shutter Out Vertical', 'wakoo'),
				],
				'condition' => [
					'hover_animation' => 'background-transition'
				]
			]

		);

		$this->add_control(
			'hover_shadow_glow_css_animation',
			[
				'label'     => __('Animation', 'wakoo'),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'hvr-glow'              => __('Glow', 'wakoo'),
					'hvr-shadow'            => __('Shadow', 'wakoo'),
					'hvr-grow-shadow'       => __('Grow Shadow', 'wakoo'),
					'hvr-box-shadow-outset' => __('Box Shadow Outset', 'wakoo'),
					'hvr-box-shadow-inset'  => __('Box Shadow Inset', 'wakoo'),
					'hvr-float-shadow'      => __('Float Shadow', 'wakoo'),
					'hvr-shadow-radial'     => __('Shadow Radial', 'wakoo'),
				],
				'condition' => [
					'hover_animation' => 'shadow-glow-transition'
				]
			]

		);

		$this->end_controls_section();
	}

	protected function __social_name_style_controls() {

		$this->start_controls_section(
			'_section_style_custom_label',
			[
				'label' => __('Social Name', 'wakoo'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'custom_label_typography',
				'label'    => __('Typography', 'wakoo'),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector' => '{{WRAPPER}} .wk-social-icon-label'
			]

		);

		$this->add_control(
			'social_name_spacing',
			[
				'label'     => __('Spacing', 'wakoo'),
				'type'      => Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .wk-social-icon:not(.elementor-social-icon-label) .wk-social-icon-label' => 'margin-left: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function __separator_style_controls() {

		$this->start_controls_section(
			'_section_social_icon_separator',
			[
				'label' => __('Separator', 'wakoo'),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'custom_separator_color',
			[
				'label'     => __('Color', 'wakoo'),
				'type'      => Controls_Manager::COLOR,
				'condition' => [
					'social_media_separator' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}}.wk-separator--stroke .wk-social-icon-separator' => 'background: {{VALUE}} !important;',
					'{{WRAPPER}}.wk-separator--custom .wk-social-icon-separator' => 'color: {{VALUE}} !important;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'wk_icon_separator_typography',
				'label'    => __('Typography', 'wakoo'),
				'selector' => '{{WRAPPER}} .wk-social-icon-separator',
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings      = $this->get_settings_for_display();
		$social_list   = $settings['wk_social_icon_list'];
		$sticky_option = $settings['sticky_options'];
		$sticky_class  = '';
		if ('yes' === $sticky_option) {
			$sticky_class = 'wk-social-icon-sticky';
		}

		$enable_separator  = $settings['social_media_separator'];
		$separator_type    = $settings['separator_type'];
		$custom_separators = $settings['custom_separator'];
		$separators        = $custom_separators ? $custom_separators : '';

		$hover_css_animation = '';

		if (!empty($settings['hover_animation'])) {

			if ($settings['hover_2d_css_animation']) {
				$hover_css_animation = $settings['hover_2d_css_animation'];
			}

			if ($settings['hover_background_css_animation']) {
				$hover_css_animation = $settings['hover_background_css_animation'];
			}

			if ($settings['hover_shadow_glow_css_animation']) {
				$hover_css_animation = $settings['hover_shadow_glow_css_animation'];
			}
		}
		?>
		<div class="wk-social-icons-wrapper <?php echo $sticky_class; ?>">
			<?php
			foreach ($social_list as $key => $icons) {
				$icon         = $icons['wk_social_icon']['value'];
				$social_title = esc_html($icons['wk_social_icon_title']);
				$link_attr    = 'link_' . $key;

				if (!empty($icons['wk_social_icon'])) {
					$social_name = str_replace(['fa fa-', 'fab fa-', 'far fa-', 'hm hm-', ' '], '', $icon);
				}

				$this->add_link_attributes( $link_attr, $icons['wk_social_link'] );

				$this->add_render_attribute($link_attr, 'class', [
					'wk-social-icon',
					'elementor-repeater-item-' . $icons['_id'] . ' ' . $hover_css_animation,
					'elementor-social-icon-' . ($icon ? $social_name : 'label'),
				]);

				if (!empty($icon)) {
					$this->add_render_attribute($link_attr, 'class', 'wk-social-icon--network');
				} else {
					$this->add_render_attribute($link_attr, 'class', 'wk-social-icon--custom-label');
				}
				?>
				<a <?php echo $this->get_render_attribute_string($link_attr); ?>>
					<?php
					Icons_Manager::render_icon($icons['wk_social_icon']);
					// Icons_Manager::render_icon( $icons['new_social_icons'], [ 'aria-hidden' => 'true' ] );
					if (!empty($social_title) && '' != $social_title) {
						echo "<span class='wk-social-icon-label'>" . $social_title . "</span>";
					}

					?>
				</a>
				<?php
				if ('yes' === $enable_separator) {
					echo "<span class='wk-social-icon-separator'> " . $separators . " </span>";
				}
			}
			?>
		</div>
		<?php
	}
}
