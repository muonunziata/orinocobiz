<?php

/**
 * Image grid widget class
 *
 * @package Wakoo
 */

namespace Wakoo\Elementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use Elementor\Utils;

defined('ABSPATH') || die();

class Image_Hover_Effect extends Base {

	/**
	 * Default filter is the global filter
	 * and can be overriden from settings
	 *
	 * @var string
	 */

	public function get_title() {
		return __('Image Hover Effect', 'wakoo');
	}

	/**
	 * Get widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'hm hm-cursor-hover-click';
	}

	public function get_keywords() {
		return ['hover', 'image', 'effect'];
	}

	protected function is_dynamic_content(): bool {
		return false;
	}

	/**
     * Register widget content controls
     */
	protected function register_content_controls() {

		$this->start_controls_section(
			'_section_image_content',
			[
				'label' => __('Image Content', 'wakoo'),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'hover_image',
			[
				'label' => __('Image', 'wakoo'),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'dynamic' => [
					'active' => true
				],
			]
		);

		$this->add_control(
			'hover_image_alt_tag',
			[
				'label' => __('Image ALT Tag', 'wakoo'),
				'type' => Controls_Manager::TEXT,
				'default' => __('Image hover effect image', 'wakoo'),
				'placeholder' => __('Type here image alt tag value', 'wakoo'),
				'dynamic' => ['active' => true,],
			]
		);

		$this->add_control(
			'hover_title',
			[
				'label' => __('Title', 'wakoo'),
				'type' => Controls_Manager::TEXTAREA,
				'description' => wk_get_allowed_html_desc( 'intermediate' ),
				'rows' => 3,
				'default' => __('Wakoo <span>Addons</span>', 'wakoo'),
				'placeholder' => __('Type your title here', 'wakoo'),
				'dynamic' => ['active' => true],
			]
		);

		$this->add_control(
			'title_tag',
			[
				'label' => __( 'Title HTML Tag', 'wakoo' ),
				'type' => Controls_Manager::SELECT,
				// 'separator' => 'before',
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'h2',
			]
		);

		$this->add_control(
			'hover_description',
			[
				'label' => __('Description', 'wakoo'),
				'type' => Controls_Manager::TEXTAREA,
				'rows' => 10,
				'default' => __('Best Elementor Addons', 'wakoo'),
				'placeholder' => __('Type your description here', 'wakoo'),
				'condition' => [
					'hover_effect!' => 'wk-effect-honey',
				],
				'dynamic' => ['active' => true],
			]
		);

		$this->add_control(
			'hover_link',
			[
				'label' => __('Link URL', 'wakoo'),
				'type' => Controls_Manager::URL,
				'placeholder' => __('https://your-link.com', 'wakoo'),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
				'dynamic' => ['active' => true],
			]
		);

		$this->add_control(
			'hover_effect',
			[
				'label' => __('Hover Effect', 'wakoo'),
				'type' => Controls_Manager::SELECT2,
				'options' => [
					'wk-effect-apollo'  => __('Apollo', 'wakoo'),
					'wk-effect-bubba'  => __('Bubba', 'wakoo'),
					'wk-effect-chico'  => __('Chico', 'wakoo'),
					'wk-effect-dexter'  => __('Dexter', 'wakoo'),
					'wk-effect-duke'  => __('Duke', 'wakoo'),
					'wk-effect-goliath'  => __('Goliath', 'wakoo'),
					'wk-effect-honey'  => __('Honey', 'wakoo'),
					'wk-effect-jazz'  => __('Jazz', 'wakoo'),
					'wk-effect-layla'  => __('Layla', 'wakoo'),
					'wk-effect-lexi'  => __('Lexi', 'wakoo'),
					'wk-effect-lily'  => __('Lily', 'wakoo'),
					'wk-effect-marley'  => __('Marley', 'wakoo'),
					'wk-effect-milo'  => __('Milo', 'wakoo'),
					'wk-effect-ming'  => __('Ming', 'wakoo'),
					'wk-effect-moses'  => __('Moses', 'wakoo'),
					'wk-effect-oscar'  => __('Oscar', 'wakoo'),
					'wk-effect-romeo'  => __('Romeo', 'wakoo'),
					'wk-effect-roxy'  => __('Roxy', 'wakoo'),
					'wk-effect-ruby'  => __('Ruby', 'wakoo'),
					'wk-effect-sadie'  => __('Sadie', 'wakoo'),
					'wk-effect-sarah'  => __('Sarah', 'wakoo'),
				],
				'default' => 'wk-effect-apollo',
			]
		);

		$this->end_controls_section();
	}

	/**
     * Register widget style controls
     */
	protected function register_style_controls() {
		$this->__common_style_controls();
		$this->__overlay_style_controls();
	}

	protected function __common_style_controls() {

		$this->start_controls_section(
			'_section_common_style',
			[
				'label' => __('Common', 'wakoo'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'hover_container_height_width_control',
			[
				'label' => __('Container Max Width?', 'wakoo'),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __('Yes', 'wakoo'),
				'label_off' => __('No', 'wakoo'),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_responsive_control(
			'hover_width',
			[
				'label' => __('Width', 'wakoo'),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1200,
						'step' => 5,
					],
				],
				'devices' => ['desktop', 'tablet', 'mobile'],
				'desktop_default' => [
					'size' => 480,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 480,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 300,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .wk-ihe-wrapper' => 'width: {{SIZE}}{{UNIT}}; height: calc({{SIZE}}{{UNIT}}/1.34);',
				],
				'condition' => [
					'hover_container_height_width_control' => 'yes'
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'hover_border',
				'label' => __('Border', 'wakoo'),
				'selector' => '{{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig',
			]
		);

		$this->add_control(
			'hover_border_radius',
			[
				'label' => __('Border Radius', 'wakoo'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors' => [
					'{{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typo',
				'label' => __('Title Typography', 'wakoo'),
				'selector' => '{{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig .wk-ihe-title',
				'fields_options' => [
					'typography' => ['default' => 'yes'],
					'font_family' => [
						'default' => 'Arial',
					],
				],
			]
		);


		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'description_typo',
				'label' => __('Description Typography', 'wakoo'),
				'selector' => '{{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig .wk-ihe-desc',
				'fields_options' => [
					'typography' => ['default' => 'yes'],
					'font_family' => [
						'default' => 'Arial',
					],
				],
			]
		);

		$this->start_controls_tabs('_tabs_style');

		$this->start_controls_tab(
			'_tab_normal',
			[
				'label' => __('Normal', 'wakoo'),
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __('Title Color', 'wakoo'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig .wk-ihe-title' => 'color: {{VALUE}}; border-color: {{VALUE}};',
					'{{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig .wk-ihe-title::before' => '--wk-ihe-title-before-color: {{VALUE}};',
					'{{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig .wk-ihe-title::after' => '--wk-ihe-title-after-color: {{VALUE}};',
					'{{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig .wk-ihe-caption::before' => '--wk-ihe-fig-before-color: {{VALUE}};',
					'{{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig .wk-ihe-caption::after' => '--wk-ihe-fig-after-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'description_color',
			[
				'label' => __('Description Color', 'wakoo'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig .wk-ihe-desc' => 'color: {{VALUE}}; --wk-ihe-desc-border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'_tab_hover',
			[
				'label' => __('Hover', 'wakoo'),
			]
		);

		$this->add_control(
			'title_hover_color',
			[
				'label' => __('Title Color', 'wakoo'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig:hover .wk-ihe-title' => 'color: {{VALUE}}; border-color: {{VALUE}};',
					'{{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig:hover .wk-ihe-title::before' => '--wk-ihe-title-before-color: {{VALUE}};',
					'{{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig:hover .wk-ihe-title::after' => '-wk-ihe-title-after-color: {{VALUE}};',
					'{{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig:hover .wk-ihe-caption::before' => '--wk-ihe-fig-before-color: {{VALUE}};',
					'{{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig:hover .wk-ihe-caption::after' => '--wk-ihe-fig-after-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'description_hover_color',
			[
				'label' => __('Description Color', 'wakoo'),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig:hover .wk-ihe-desc' => 'color: {{VALUE}}; --wk-ihe-desc-border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function __overlay_style_controls() {

		$this->start_controls_section(
			'_section_overlay_style',
			[
				'label' => __('Background Overlay', 'wakoo'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs('_tabs_overlay_style');
		$this->start_controls_tab(
			'_tab_overlay_normal',
			[
				'label' => __('Normal', 'wakoo'),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'hover_overlay_normal',
				'label' => __('Background', 'wakoo'),
				'show_label' => true,
				'types' => ['classic', 'gradient'],
				'exclude' => [
					'classic' => 'image'
				],
				'selector' => '{{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig, {{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig.wk-effect-sadie .wk-ihe-caption::before',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'_tab_overlay_hover',
			[
				'label' => __('Hover', 'wakoo'),
			]
		);


		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'hover_overlay_hover',
				'label' => __('Background', 'wakoo'),
				'show_label' => true,
				'types' => ['classic', 'gradient'],
				'exclude' => [
					'classic' => 'image'
				],
				'selector' => '{{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig:hover, {{WRAPPER}} .wk-ihe-wrapper .wk-ihe-fig.wk-effect-sadie:hover .wk-ihe-caption::before',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$url_target = $settings['hover_link']['is_external'] ? ' target="_blank"' : '';
		$url_nofollow = $settings['hover_link']['nofollow'] ? ' rel="nofollow"' : '';
?>
		<div class="wk-ihe-wrapper grid">
			<figure class="wk-ihe-fig <?php echo esc_attr($settings['hover_effect']); ?>">
				<img class="wk-ihe-img" src="<?php echo esc_url($settings['hover_image']['url']); ?>" alt="<?php echo esc_attr($settings['hover_image_alt_tag']); ?>" />
				<figcaption class="wk-ihe-caption">
					<?php if ($settings['hover_effect'] == 'wk-effect-lily') : ?>
						<div>
						<?php endif; ?>
						<?php
						printf( '<%1$s class="wk-ihe-title">%2$s</%1$s>',
							wk_escape_tags( $settings['title_tag'], 'h2' ),
							wk_kses_intermediate($settings['hover_title'])
						);
						?>
						<?php if ($settings['hover_effect'] != 'wk-effect-honey') : ?>
							<p class="wk-ihe-desc"><?php echo wk_kses_intermediate($settings['hover_description']); ?></p>
						<?php endif; ?>
						<?php if ($settings['hover_effect'] == 'wk-effect-lily') : ?>
						</div>
					<?php endif; ?>
					<?php if ($settings['hover_link']['url'] != '') : ?>
						<a href="<?php echo esc_url($settings['hover_link']['url']); ?>" <?php echo esc_attr($url_target . $url_nofollow); ?>></a>
					<?php endif; ?>
				</figcaption>
			</figure>
		</div>
<?php
	}
}
