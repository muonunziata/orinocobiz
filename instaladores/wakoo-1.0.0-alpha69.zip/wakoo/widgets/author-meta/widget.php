<?php
/**
 * Author Meta widget class
 *
 * @package Wakoo
 */
namespace Wakoo\Elementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

defined( 'ABSPATH' ) || die();

class Author_Meta extends Base {

	/**
	 * Get widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Author Meta', 'wakoo' );
	}

	public function get_custom_help_url() {
		return '';
	}

	/**
	 * Get widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'hm hm-tb-author-meta';
	}

	public function get_keywords() {
		return [ 'author', 'author_meta', 'author info' ];
	}

	public function get_categories() {
        return [ 'wakoo_category', 'wakoo_theme_builder' ];
    }

	/**
     * Register widget content controls
     */
	protected function register_content_controls() {
		$this->__author_content_controls();

	}

	protected function __author_content_controls() {
		$this->start_controls_section(
			'_section_author_meta',
			[
				'label' => __( 'Author Meta', 'wakoo' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_author',
			[
				'label'        => __( 'Show Author Name', 'wakoo' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);


		$this->add_control(
			'author_meta_tag',
			[
				'label' => __( 'Author Name Tag', 'wakoo' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'h1'  => [
						'title' => __( 'H1', 'wakoo' ),
						'icon' => 'eicon-editor-h1'
					],
					'h2'  => [
						'title' => __( 'H2', 'wakoo' ),
						'icon' => 'eicon-editor-h2'
					],
					'h3'  => [
						'title' => __( 'H3', 'wakoo' ),
						'icon' => 'eicon-editor-h3'
					],
					'h4'  => [
						'title' => __( 'H4', 'wakoo' ),
						'icon' => 'eicon-editor-h4'
					],
					'h5'  => [
						'title' => __( 'H5', 'wakoo' ),
						'icon' => 'eicon-editor-h5'
					],
					'h6'  => [
						'title' => __( 'H6', 'wakoo' ),
						'icon' => 'eicon-editor-h6'
					]
				],
				'default' => 'h4',
				'toggle' => false,
				'condition'=>[
					'show_author' => 'yes',
				]
			]
		);

		$this->add_control(
			'show_avatar',
			[
				'label'        => __( 'Show Avatar', 'wakoo' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'show_bio',
			[
				'label'        => __( 'Show Short Bio', 'wakoo' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'show_archive_btn',
			[
				'label'        => __( 'Show Archive Button', 'wakoo' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'author_link_to',
			[
				'label' => __( 'Link', 'wakoo' ),
				'type'  => Controls_Manager::SELECT,
				'options' => [
					''              => __( 'None', 'wakoo' ),
					'website'       => __( 'Website', 'wakoo' ),
					'admin_archive' => __( 'Admin Posts', 'wakoo' ),
				],
				'description'       => __( 'Link for the Author Name and Image', 'wakoo' ),
			]
		);

		$this->add_control(
			'avatar_size',
			[
				'label' => __( 'Avatar Size', 'wakoo' ),
				'type' => Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 500,
				'step' => 1,
				'default' => 96,
			]
		);

		$this->add_control(
			'avatar_image_position',
			[
				'label'   => __( 'Avatar Image Position', 'wakoo' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'wakoo' ),
						'icon'  => 'eicon-h-align-left',
					],
					'right' => [
						'title' => __( 'Right', 'wakoo' ),
						'icon'  => 'eicon-h-align-right',
					],
					'top' => [
						'title' => __( 'Top', 'wakoo' ),
						'icon'  => 'eicon-v-align-top',
					],
					'bottom' => [
						'title' => __( 'Bottom', 'wakoo' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'default'     => 'left',
			]
		);

        $this->end_controls_section();
	}

	/**
	 * Register styles related controls
	 */
	protected function register_style_controls() {
		$this->__author_style_controls();
		$this->__avatar_style_controls();
		$this->__author_short_bio_controls();
		$this->__author_button_style_controls();
	}


	protected function __author_style_controls() {

        $this->start_controls_section(
            '_section_style_text',
            [
                'label' => __( 'Author Name', 'wakoo' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'author_color',
			[
				'label' => esc_html__( 'Color', 'wakoo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-author-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'author_typography',
				'label' => __( 'Typography', 'wakoo' ),
				'selector' => '{{WRAPPER}} .wk-author-title',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
				],
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'author_text_shadow',
				'selector' => '{{WRAPPER}} .wk-author-title',
			]
		);


        $this->end_controls_section();
	}

	protected function __author_short_bio_controls() {

        $this->start_controls_section(
            '_section_style_short_bio',
            [
                'label' => __( 'Short Bio', 'wakoo' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'bio_color',
			[
				'label' => esc_html__( 'Color', 'wakoo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-desc p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'bio_typography',
				'label' => __( 'Typography', 'wakoo' ),
				'selector' => '{{WRAPPER}} .wk-desc p',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
				],
			]
		);


        $this->end_controls_section();
	}

	protected function __avatar_style_controls() {

        $this->start_controls_section(
            '_section_avatar_style',
            [
                'label' => __( 'Avatar', 'wakoo' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'avatar_vertical_lign',
			[
				'label'   => __( 'Vertical Align', 'wakoo' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => __( 'Top', 'wakoo' ),
						'icon'  => 'eicon-v-align-top',
					],
					'center' => [
						'title' => __( 'Middle', 'wakoo' ),
						'icon'  => 'eicon-v-align-middle',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .wk-avatar' => 'align-self:{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'avatar_width',
			[
				'label' => __( 'Wdth', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 250,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 96,
				],
				'selectors' => [
					'{{WRAPPER}} .wk-avatar img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// $this->add_responsive_control(
		// 	'avatar_margin',
		// 	[
		// 		'label' => __( 'Avatar Margin', 'wakoo' ),
		// 		'type' => Controls_Manager::DIMENSIONS,
		// 		'size_units' => [ 'px', '%' ],
		// 		'selectors' => [
		// 			'{{WRAPPER}} .wk-avatar' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
		// 		],
		// 	]
		// );

        $this->add_responsive_control(
			'avatar_padding',
			[
				'label' => __( 'Padding', 'wakoo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .wk-avatar' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'avatar_border',
				'label' => __( 'Border', 'wakoo' ),
				'selector' => '{{WRAPPER}} .wk-avatar img',
			]
		);

		$this->add_control(
			'avatar_radius',
			[
				'label' => __( 'Border Radius', 'wakoo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'default' => [
					'top' => '50',
					'right' => '50',
					'bottom' => '50',
					'left' => '50',
					'unit' => '%',
				],
				'selectors' => [
					'{{WRAPPER}} .wk-avatar img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();
	}

	protected function __author_button_style_controls() {

        $this->start_controls_section(
            '_section_style_button',
            [
                'label' => __( 'Button', 'wakoo' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_responsive_control(
			'author_info_button_padding',
			[
				'label' => __( 'Padding', 'wakoo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'separator' => 'before',
				'size_units' => [ 'px', '%' ],
				'default' => [
					'top' => '7',
					'right' => '15',
					'bottom' => '7',
					'left' => '15',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .wk-author-posts' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'author_info_button_hover_typography',
				'label' => __( 'Typography', 'wakoo' ),
				'selector' => '{{WRAPPER}} .wk-author-posts',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'author_info_button_border',
				'selector' => '{{WRAPPER}} .wk-desc .wk-author-posts',
			]
		);

		$this->add_control(
			'author_info_button_border_radius',
			[
				'label' => __('Border Radius', 'wakoo'),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .wk-desc .wk-author-posts' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs(
            'author_info_button_active_tabs'
        );

		$this->start_controls_tab(
            'author_info_button_normal_tab',
            [
                'label'    => __('Normal', 'wakoo')
            ]
        );

        $this->add_control(
			'author_info_button_text_color',
			[
				'label' => esc_html__( 'Color', 'wakoo' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#555555',
				'selectors' => [
					'{{WRAPPER}} .wk-author-posts-btn' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'author_info_button_background',
                'label' => __('Background', 'wakoo'),
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .wk-author-posts-btn',
            ]
        );

		$this->end_controls_tab();

		$this->start_controls_tab(
            'author_info_button_hover_tab',
            [
                'label'    => __('Hover', 'wakoo')
            ]
        );

		$this->add_control(
			'author_info_button_hover_text_color',
			[
				'label' => esc_html__( 'Color', 'wakoo' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#555555',
				'selectors' => [
					'{{WRAPPER}} .wk-author-posts-btn:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'author_info_button_hover_background',
                'label' => __('Background', 'wakoo'),
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .wk-author-posts-btn:hover',
            ]
        );

		$this->add_control(
			'author_info_button_border_color_hover',
			[
				'label' => esc_html__( 'Border Color', 'wakoo' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#555555',
				'selectors' => [
					'{{WRAPPER}} .wk-author-posts-btn:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

        $this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		// $user_id = get_the_author_meta( 'ID' );
		// $avatar = get_avatar($user_id, $settings['avatar_size']);
		// $display_name = get_the_author_meta( 'display_name' );
		// $bio = get_the_author_meta( 'description' );
		$user_id = get_post_field( 'post_author', get_the_ID() );
		$avatar = get_avatar($user_id, $settings['avatar_size']);
		$display_name = get_the_author_meta( 'display_name', $user_id );
		$bio = get_the_author_meta( 'description', $user_id );

		$post_url = get_author_posts_url( $user_id );
		$user_url =  get_the_author_meta( 'user_url', $user_id );

		$this->add_render_attribute('author', 'class', 'wk-author');
		$this->add_render_attribute('avatar', 'class', 'wk-avatar');
		if( $settings['avatar_image_position'] && 'yes' === $settings['show_avatar']){
			$this->add_render_attribute('author', 'class', 'avatar-position-' . $settings['avatar_image_position']);
		}

		if( $settings['show_author'] ){
			$this->add_render_attribute('author-title', 'class', 'wk-author-title');
		}

		?>

		<div <?php $this->print_render_attribute_string('author'); ?>>
			<?php if('yes' === $settings['show_avatar']) : ?>
				<div <?php $this->print_render_attribute_string('avatar'); ?>>
					<?php echo $avatar; ?>
				</div>
			<?php endif; ?>

			<div class="wk-desc">
				<?php
				if('yes' === $settings['show_author']){
					printf('<%1$s %2$s>%3$s</%1$s>',
					wk_escape_tags($settings['author_meta_tag']),
					$this->get_render_attribute_string('author-title'),
					esc_html($display_name)
				);
				}
				if('yes' === $settings['show_bio']){
					printf('<p>%1$s</p>', esc_html($bio));
				}

				if( 'yes' == $settings['show_archive_btn'] ) { ?>
					<a class="wk-author-posts wk-author-posts-btn" href="<?php echo esc_url( $post_url ); ?>">All Posts</a>
				<?php }
				?>
			</div>
		</div>


		<?php
	}
}
