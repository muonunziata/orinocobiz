<?php
/**
 * Taxonomy List widget class
 *
 * @package Wakoo
 */

namespace Wakoo\Elementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Elementor\Utils;
use Wakoo\Elementor\Controls\Select2;

defined( 'ABSPATH' ) || die();

class Taxonomy_List extends Base {

	/**
	 * Get widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'Taxonomy List', 'wakoo' );
	}

	public function get_custom_help_url() {
		return '';
	}

	/**
	 * Get widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon() {
		return 'hm hm-clip-board';
	}

	public function get_keywords() {
		return [ 'taxonomies', 'taxonomy', 'taxonomy-list', 'category', 'category-list', 'list' ];
	}

	/**
	 * Get a list of Taxonomy
	 *
	 * @return array
	 */
	public static function get_taxonomies( $taxonomy_type = '' ) {
		$list = [];
		if ( $taxonomy_type ) {
			$tax = wk_get_taxonomies( [ 'public' => true, "object_type" => [ $taxonomy_type ] ], 'object', true );
			$list[$taxonomy_type] = count( $tax ) !== 0 ? $tax : '';
		} else {
			$list = wk_get_taxonomies( [ 'public' => true ], 'object', true );
		}
		return $list;
	}

	/**
     * Register widget content controls
     */
	protected function register_content_controls() {
		$this->__list_content_controls();
		$this->__settings_content_controls();
	}

	protected function __list_content_controls() {

		$this->start_controls_section(
			'_section_taxonomy_list',
			[
				'label' => __( 'List', 'wakoo' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'taxonomy_type',
			[
				'label' => __( 'Source', 'wakoo' ),
				'type' => Controls_Manager::SELECT,
				'options' => $this->get_taxonomies(),
				'default' => key( $this->get_taxonomies() ),
			]
		);

		$repeater = [];

		foreach ( $this->get_taxonomies() as $key => $value ) {

			$repeater[$key] = new Repeater();

			$repeater[$key]->add_control(
				'title',
				[
					'label' => __( 'Custom Title', 'wakoo' ),
					'type' => Controls_Manager::TEXT,
					'label_block' => true,
					'placeholder' => __( 'Customize Title', 'wakoo' ),
					'dynamic' => [
						'active' => true,
					],
				]
			);

			$repeater[$key]->add_control(
				'individual_icon',
				[
					'label' => __( 'Icon', 'wakoo' ),
					'type' => Controls_Manager::CHOOSE,
					'description' => __( 'If you want to use individual icon disable common icon.', 'wakoo' ),
					'options' => [
						'icon' => [
							'title' => __( 'Icon', 'wakoo' ),
							'icon' => 'eicon-star',
						],
						'image' => [
							'title' => __( 'Image', 'wakoo' ),
							'icon' => 'eicon-image',
						],
					],
					'toggle' => true,
					//'default' => 'icon',
				]
			);

			$repeater[$key]->add_control(
				'icon',
				[
					'label' => __( 'Icon', 'wakoo' ),
					'show_label' => false,
					'type' => Controls_Manager::ICONS,
					'default' => [
						'value' => 'far fa-check-circle',
						'library' => 'reguler'
					],
					'condition' => [
						'individual_icon' => 'icon',
					]
				]
			);

			$repeater[$key]->add_control(
				'image',
				[
					'label' => __( 'Image', 'wakoo' ),
					'show_label' => false,
					'type' => Controls_Manager::MEDIA,
					'default' => [
						'url' => Utils::get_placeholder_image_src(),
					],
					'dynamic' => [
						'active' => true,
					],
					'condition' => [
						'individual_icon' => 'image',
					]
				]
			);

			$repeater[$key]->add_control(
				'tax_id',
				[
					'label' => __( 'Select ', 'wakoo' ) . $value,
					'label_block' => true,
					'type' => Select2::TYPE,
					'multiple' => false,
					'placeholder' => 'Search ' . $value,
					'dynamic_params' => [
						'term_taxonomy' => $key,
						'object_type'   => 'term'
					],
				]
			);

			$this->add_control(
				'selected_list_' . $key,
				[
					'label' => '',
					'type' => Controls_Manager::REPEATER,
					'fields' => $repeater[$key]->get_controls(),
					'title_field' => '{{ title }}',
					'condition' => [
						'taxonomy_type' => $key
					],
				]
			);
		}

		$this->end_controls_section();
	}

	protected function __settings_content_controls() {

		$this->start_controls_section(
			'_section_settings',
			[
				'label' => __( 'Settings', 'wakoo' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'view',
			[
				'label' => __( 'Layout', 'wakoo' ),
				'label_block' => false,
				'type' => Controls_Manager::CHOOSE,
				'default' => 'list',
				'options' => [
					'list' => [
						'title' => __( 'List', 'wakoo' ),
						'icon' => 'eicon-editor-list-ul',
					],
					'inline' => [
						'title' => __( 'Inline', 'wakoo' ),
						'icon' => 'eicon-ellipsis-h',
					],
				],
				'style_transfer' => true,
			]
		);

		$this->add_control(
			'title_tag',
			[
				'label' => __( 'Title HTML Tag', 'wakoo' ),
				'type' => Controls_Manager::SELECT,
				// 'separator' => 'before',
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'h2',
			]
		);

		$this->add_control(
			'common_icon_enable',
			[
				'label' => __( 'Common icon enable?', 'wakoo' ),
				'description' => __( 'Common icon will overwrite all individual icon.', 'wakoo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'common_icon',
			[
				'label' => __( 'Common Icon', 'wakoo' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'icon' => [
						'title' => __( 'Icon', 'wakoo' ),
						'icon' => 'eicon-star',
					],
					'image' => [
						'title' => __( 'Image', 'wakoo' ),
						'icon' => 'eicon-image',
					],
				],
				'condition' => [
					'common_icon_enable' => 'yes',
				],
				'toggle' => false,
				'default' => 'icon',
			]
		);

		$this->add_control(
			'icon',
			[
				'label' => __( 'Icon', 'wakoo' ),
				'description' => __( 'Common icon will overwrite individual icon.', 'wakoo' ),
				'show_label' => false,
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'far fa-check-circle',
					'library' => 'reguler'
				],
				'condition' => [
					'common_icon_enable' => 'yes',
					'common_icon' => 'icon',
				]
			]
		);

		$this->add_control(
			'image',
			[
				'label' => __( 'Image', 'wakoo' ),
				'description' => __( 'Common icon will overwrite individual icon.', 'wakoo' ),
				'show_label' => false,
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'dynamic' => [
					'active' => true,
				],
				'condition' => [
					'common_icon_enable' => 'yes',
					'common_icon' => 'image',
				]
			]
		);

		$this->add_control(
			'item_counter_enable',
			[
				'label' => __( 'Item Counter Enable?', 'wakoo' ),
				'description' => __( 'Enable item counter for each taxonomy item.', 'wakoo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

		$this->add_control(
			'item_counter_align',
			[
				'label' => __( 'Item Counter Align', 'wakoo' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'center' => [
						'title' => __( 'Center', 'wakoo' ),
						'icon' => 'eicon-h-align-center',
					],
					'stretch' => [
						'title' => __( 'Stretch', 'wakoo' ),
						'icon' => 'eicon-h-align-stretch',
					],
				],
				'toggle' => true,
				'selectors_dictionary' => [
					// 'center' => 'margin-left: 0px',
					'center' => '',
					'stretch' => 'margin-left: auto;',
				],
				'selectors' => [
					'{{WRAPPER}} .wk-taxonomy-list .wk-taxonomy-list-item a span.wk-taxonomy-list-count' => '{{VALUE}};',
				],
				'condition' => [
					'item_counter_enable' => 'yes',
					'view' => 'list',
				]
			]
		);

		$this->add_control(
			'item_counter_align_note',
			[
				'type' => Controls_Manager::NOTICE,
				'notice_type' => 'info',
				'dismissible' => false,
				'content' => __( 'Selecting Item Counter Align "Stretch" will make default alignment unusable.', 'wakoo' ),
				'condition' => [
					'item_counter_enable' => 'yes',
					'view' => 'list',
					'item_counter_align' => 'stretch',
				]
			]
		);

		$this->add_control(
			'item_align',
			[
				'label' => __( 'Alignment', 'wakoo' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'wakoo' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'wakoo' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'wakoo' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'toggle' => true,
				'selectors_dictionary' => [
					'left' => 'justify-content: flex-start',
					'center' => 'justify-content: center',
					'right' => 'justify-content: flex-end',
				],
				'selectors' => [
					'{{WRAPPER}} .wk-taxonomy-list .wk-taxonomy-list-item a' => '{{VALUE}};',
					'{{WRAPPER}} .wk-taxonomy-list.wk-taxonomy-list-inline' => '{{VALUE}};'
				],
				// 'condition' => [
				// 	'view' => 'list',
				// ]
			]
		);

		$this->end_controls_section();
	}

	/**
     * Register widget style controls
     */
	protected function register_style_controls() {
		$this->__list_style_controls();
		$this->__title_style_controls();
		$this->__icon_image_style_controls();
		$this->__counter_style_controls();
	}

	protected function __list_style_controls() {

		$this->start_controls_section(
			'_section_taxonomy_list_style',
			[
				'label' => __( 'List', 'wakoo' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'list_item_common',
			[
				'label' => __( 'Common', 'wakoo' ),
				'type' => Controls_Manager::HEADING,
			]
		);

		$this->add_responsive_control(
			'list_item_margin',
			[
				'label' => __( 'Margin', 'wakoo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .wk-taxonomy-list .wk-taxonomy-list-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_responsive_control(
			'list_item_padding',
			[
				'label' => __( 'Padding', 'wakoo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .wk-taxonomy-list .wk-taxonomy-list-item a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'list_item_background',
				'label' => __( 'Background', 'wakoo' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .wk-taxonomy-list .wk-taxonomy-list-item',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'list_item_box_shadow',
				'label' => __( 'Box Shadow', 'wakoo' ),
				'selector' => '{{WRAPPER}} .wk-taxonomy-list .wk-taxonomy-list-item',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'list_item_border',
				'label' => __( 'Border', 'wakoo' ),
				'selector' => '{{WRAPPER}} .wk-taxonomy-list .wk-taxonomy-list-item',
			]
		);

		$this->add_responsive_control(
			'list_item_border_radius',
			[
				'label' => __( 'Border Radius', 'wakoo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .wk-taxonomy-list .wk-taxonomy-list-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_control(
			'advance_style',
			[
				'label' => __( 'Advance Style', 'wakoo' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'On', 'wakoo' ),
				'label_off' => __( 'Off', 'wakoo' ),
				'return_value' => 'yes',
				'default' => '',
			]
		);

		$this->add_responsive_control(
			'list_item_first',
			[
				'label' => __( 'First Item', 'wakoo' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'advance_style' => 'yes',
				]
			]
		);

		$this->add_responsive_control(
			'list_item_first_child_margin',
			[
				'label' => __( 'Margin', 'wakoo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .wk-taxonomy-list .wk-taxonomy-list-item:first-child' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'advance_style' => 'yes',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'list_item_first_child_border',
				'label' => __( 'Border', 'wakoo' ),
				'selector' => '{{WRAPPER}} .wk-taxonomy-list .wk-taxonomy-list-item:first-child',
				'condition' => [
					'advance_style' => 'yes',
				]
			]
		);

		$this->add_responsive_control(
			'list_item_last',
			[
				'label' => __( 'Last Item', 'wakoo' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'advance_style' => 'yes',
				]
			]
		);

		$this->add_responsive_control(
			'list_item_last_child_margin',
			[
				'label' => __( 'Margin', 'wakoo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .wk-taxonomy-list .wk-taxonomy-list-item:last-child' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'advance_style' => 'yes',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'list_item_last_child_border',
				'label' => __( 'Border', 'wakoo' ),
				'selector' => '{{WRAPPER}} .wk-taxonomy-list .wk-taxonomy-list-item:last-child',
				'condition' => [
					'advance_style' => 'yes',
				]
			]
		);

		$this->end_controls_section();
	}

	protected function __title_style_controls() {

		$this->start_controls_section(
			'_section_taxonomy_list_title_style',
			[
				'label' => __( 'Title', 'wakoo' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __( 'Typography', 'wakoo' ),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
				],
				'selector' => '{{WRAPPER}} .wk-taxonomy-list-title, {{WRAPPER}} .wk-taxonomy-list-count',
			]
		);

		$this->start_controls_tabs( 'title_tabs' );
		$this->start_controls_tab(
			'title_normal_tab',
			[
				'label' => __( 'Normal', 'wakoo' ),
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => __( 'Color', 'wakoo' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#000000',
				'selectors' => [
					'{{WRAPPER}} .wk-taxonomy-list-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .wk-taxonomy-list-count' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'title_hover_tab',
			[
				'label' => __( 'Hover', 'wakoo' ),
			]
		);

		$this->add_control(
			'title_hvr_color',
			[
				'label' => __( 'Color', 'wakoo' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .wk-taxonomy-list .wk-taxonomy-list-item a:hover .wk-taxonomy-list-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .wk-taxonomy-list .wk-taxonomy-list-item a:hover .wk-taxonomy-list-count' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function __icon_image_style_controls() {

		$this->start_controls_section(
			'_section_icon_style',
			[
				'label' => __( 'Icon & Image', 'wakoo' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label' => __( 'Icon Color', 'wakoo' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#000000',
				'selectors' => [
					'{{WRAPPER}} span.wk-taxonomy-list-icon' => 'color: {{VALUE}};',
					'{{WRAPPER}} span.wk-taxonomy-list-icon svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label' => __( 'Icon Size', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} span.wk-taxonomy-list-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_line_height',
			[
				'label' => __( 'Icon Line Height', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} span.wk-taxonomy-list-icon' => 'line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_width',
			[
				'label' => __( 'Image Width', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .wk-taxonomy-list-image img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name' => 'image_css_filter',
				'selector' => '{{WRAPPER}} .wk-taxonomy-list-image img',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'image_boder',
				'label' => __( 'Border', 'wakoo' ),
				'selector' => '{{WRAPPER}} .wk-taxonomy-list-item a img',
			]
		);

		$this->add_responsive_control(
			'image_boder_radius',
			[
				'label' => __( 'Border Radius', 'wakoo' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .wk-taxonomy-list-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_margin_right',
			[
				'label' => __( 'Margin Right', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} span.wk-taxonomy-list-icon' => 'margin-right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} span.wk-taxonomy-list-image' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function __counter_style_controls() {

		$this->start_controls_section(
			'_section_counter_style',
			[
				'label' => __( 'Counter', 'wakoo' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'item_counter_enable' => 'yes',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'counter_typography',
				'label' => __( 'Typography', 'wakoo' ),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
				],
				'selector' => '{{WRAPPER}} .wk-taxonomy-list-item span.wk-taxonomy-list-count',
			]
		);

		$this->add_control(
			'counter_color',
			[
				'label' => __( 'Color', 'wakoo' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .wk-taxonomy-list-item span.wk-taxonomy-list-count' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'counter_hvr_color',
			[
				'label' => __( 'Hover Color', 'wakoo' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					// '{{WRAPPER}} .wk-taxonomy-list-item span.wk-taxonomy-list-count' => 'color: {{VALUE}};',
					'{{WRAPPER}} .wk-taxonomy-list .wk-taxonomy-list-item a:hover span.wk-taxonomy-list-count' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'counter_space_between',
			[
				'label' => __( 'Space Between', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} span.wk-taxonomy-list-count' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		if ( !$settings['taxonomy_type'] ) return;
		$customize_title = [];
		$ids = [];
		$lists = $settings['selected_list_' . $settings['taxonomy_type']];
		if ( !empty( $lists ) ) {
			foreach ( $lists as $index => $value ) {
				//trim function to remove extra space before taxonomy ID
				if( is_array($value['tax_id']) ){
					$tax_id = ! empty($value['tax_id'][0]) ? trim($value['tax_id'][0]) : '';
				}else{
					$tax_id = ! empty($value['tax_id']) ? trim($value['tax_id']) : '';
				}
				$ids[] = $tax_id;
				if ( $value['title'] ){
					$customize_title[$tax_id] = $value['title'];
				}
			}
		}
		$terms = [];
		if ( count( $ids ) !== 0 ) {
			$args = [
				'taxonomy' => $settings['taxonomy_type'],
				'hide_empty' => true,
				'include' => $ids,
				'orderby' => 'include',
			];
			$terms = get_terms( $args );
		}
		$loop_count = count($terms) - 1;
		$this->add_render_attribute( 'wrapper', 'class', [ 'wk-taxonomy-list-wrapper' ] );
		$this->add_render_attribute( 'wrapper-inner', 'class', [ 'wk-taxonomy-list' ] );
		if ( 'inline' === $settings['view'] ) {
			$this->add_render_attribute( 'wrapper-inner', 'class', [ 'wk-taxonomy-list-inline' ] );
		}
		$this->add_render_attribute( 'item', 'class', [ 'wk-taxonomy-list-item' ] );

		// error_log( print_r( $lists , 1 ) );

		if ( count( $terms ) !== 0 && count( $lists ) !== 0 ) :?>
			<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
				<ul <?php $this->print_render_attribute_string( 'wrapper-inner' ); ?> >
				<?php foreach ( $lists as $index => $value ):
					if ( !$value['tax_id'] ) continue; ?>
					<li <?php $this->print_render_attribute_string( 'item' ); ?>>
						<a href="<?php echo esc_url( get_term_link( $terms[$index]->term_id ) ); ?>">
							<?php
							$icon_settings = 'yes' === $settings['common_icon_enable'] && !empty( $settings['common_icon'] ) ? $settings['common_icon'] : $value['individual_icon'];

							$icon = 'yes' === $settings['common_icon_enable'] && !empty( $settings['icon'] ) ? $settings['icon'] : (isset($value['icon'])? $value['icon']: '');

							$image_url = 'yes' === $settings['common_icon_enable'] && !empty( $settings['image']['url'] ) ? $settings['image']['url'] : (isset($value['image']['url'])? $value['image']['url']: '') ;
							?>
							<?php if ( $icon_settings ) :
								echo '<span class="wk-taxonomy-list-' . esc_attr( $icon_settings ) . '">';
								if ( 'icon' === $icon_settings && !empty( $icon ) ) :
									Icons_Manager::render_icon( $icon, [ 'aria-hidden' => 'true' ] );
								elseif ( 'image' === $icon_settings && !empty( $image_url ) ) :
									echo '<img src="' . esc_url( $image_url ) . '">';
								endif;
								echo '</span>';
							endif; ?>
							<?php
							//Term Title
							$title = $terms[$index]->name;
							if ( array_key_exists( $terms[$index]->term_id, $customize_title ) ) {
								$title = $customize_title[$terms[$index]->term_id];
							}
							// $title = "{$title} ({$terms[$index]->count})";
							if ( $title ) {
								printf( '<%1$s %2$s>%3$s</%1$s>',
									wk_escape_tags( $settings['title_tag'], 'h2' ),
									'class="wk-taxonomy-list-title"',
									esc_html( $title )
								);
								if( 'yes' === $settings['item_counter_enable'] ) {
									printf( '<span %s>(%s)</span>',
										'class="wk-taxonomy-list-count"',
										esc_html( $terms[$index]->count )
									);
								}
							}
							?>
						</a>
					</li>
					<?php if ( $loop_count === $index ) break; ?>
				<?php endforeach; ?>
				</ul>
			</div>
		<?php
		else:
			printf( '%1$s %2$s %3$s',
				__( 'No ', 'wakoo' ),
				esc_html( str_replace( '_', ' ', $settings['taxonomy_type'] ) ),
				__( 'found', 'wakoo' )
			);
		endif;
	}
}
