<?php
namespace Wakoo\Elementor\Extensions;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Core\Kits\Documents\Tabs\Tab_Base;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class Scroll_To_Top_Kit_Setings extends Tab_Base {

	public function get_id() {
		return 'wk-scroll-to-top-kit-settings';
	}

	public function get_title() {
		return __( 'Scroll to Top', 'wakoo' ) . '<span style="margin: 0 15px 0 0;display: inline-block;float: right;">' . wk_get_section_icon() . '</spna>';
	}

	public function get_icon() {
		return 'hm hm-scroll-top';
	}

	public function get_help_url() {
		return '';
	}

	public function get_group() {
		return 'settings';
	}

	protected function register_tab_controls() {
		$this->start_controls_section(
			'wk_scroll_to_top_kit_section',
			[
				'tab'   => 'wk-scroll-to-top-kit-settings',
				'label' => __( 'Scroll to Top', 'wakoo' ),
			]
		);

		$this->add_control(
			'wk_scroll_to_top_global',
			[
				'type'      => Controls_Manager::SWITCHER,
				'label'     => __( 'Enable Scroll To Top', 'wakoo' ),
				'default'   => '',
				'label_on'  => __( 'Show', 'wakoo' ),
				'label_off' => __( 'Hide', 'wakoo' ),
			]
		);

		// TODO: For Pro 3.6.0, convert this to the breakpoints utility method introduced in core 3.5.0.
		$breakpoints    = wk_elementor()->breakpoints->get_active_breakpoints();
		$device_default = [];
		foreach ( $breakpoints as $breakpoint_key => $breakpoint ) {
			$device_default[ $breakpoint_key . '_default' ] = 'yes';
		}
		$device_default['desktop_default'] = 'yes';
		$this->add_responsive_control(
			'wk_scroll_to_top_responsive_visibility',
			array_merge(
				[
					'type'                 => Controls_Manager::SWITCHER,
					'label'                => __( 'Responsive Visibility', 'wakoo' ),
					'default'              => 'yes',
					'return_value'         => 'yes',
					'label_on'             => __( 'Show', 'wakoo' ),
					'label_off'            => __( 'Hide', 'wakoo' ),
					'selectors_dictionary' => [
						''    => 'visibility: hidden; opacity: 0;',
						'yes' => 'visibility: visible; opacity: 1;',
					],
					'selectors'            => [
						'body[data-elementor-device-mode="widescreen"] .wk-scroll-to-top-wrap,
						body[data-elementor-device-mode="widescreen"] .wk-scroll-to-top-wrap.edit-mode,
						body[data-elementor-device-mode="widescreen"] .wk-scroll-to-top-wrap.single-page-off' => '{{VALUE}}',

						'body[data-elementor-device-mode="desktop"] .wk-scroll-to-top-wrap,
						body[data-elementor-device-mode="desktop"] .wk-scroll-to-top-wrap.edit-mode,
						body[data-elementor-device-mode="desktop"] .wk-scroll-to-top-wrap.single-page-off' => '{{VALUE}}',

						'body[data-elementor-device-mode="laptop"] .wk-scroll-to-top-wrap,
						body[data-elementor-device-mode="laptop"] .wk-scroll-to-top-wrap.edit-mode,
						body[data-elementor-device-mode="laptop"] .wk-scroll-to-top-wrap.single-page-off' => '{{VALUE}}',

						'body[data-elementor-device-mode="tablet_extra"] .wk-scroll-to-top-wrap,
						body[data-elementor-device-mode="tablet_extra"] .wk-scroll-to-top-wrap.edit-mode,
						body[data-elementor-device-mode="tablet_extra"] .wk-scroll-to-top-wrap.single-page-off' => '{{VALUE}}',

						'body[data-elementor-device-mode="tablet"] .wk-scroll-to-top-wrap,
						body[data-elementor-device-mode="tablet"] .wk-scroll-to-top-wrap.edit-mode,
						body[data-elementor-device-mode="tablet"] .wk-scroll-to-top-wrap.single-page-off' => '{{VALUE}}',

						'body[data-elementor-device-mode="mobile_extra"] .wk-scroll-to-top-wrap,
						body[data-elementor-device-mode="mobile_extra"] .wk-scroll-to-top-wrap.edit-mode,
						body[data-elementor-device-mode="mobile_extra"] .wk-scroll-to-top-wrap.single-page-off' => '{{VALUE}}',

						'body[data-elementor-device-mode="mobile"] .wk-scroll-to-top-wrap,
						body[data-elementor-device-mode="mobile"] .wk-scroll-to-top-wrap.edit-mode,
						body[data-elementor-device-mode="mobile"] .wk-scroll-to-top-wrap.single-page-off' => '{{VALUE}}',
					],
					'condition'            => [
						'wk_scroll_to_top_global' => 'yes',
					],
				],
				$device_default
			)
		);

		$this->add_control(
			'wk_scroll_to_top_position_text',
			[
				'label'       => esc_html__( 'Position', 'wakoo' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'bottom-right',
				'label_block' => false,
				'options'     => [
					'bottom-left'  => esc_html__( 'Bottom Left', 'wakoo' ),
					'bottom-right' => esc_html__( 'Bottom Right', 'wakoo' ),
				],
				'separator'   => 'before',
				'condition'   => [
					'wk_scroll_to_top_global' => 'yes',
				],
			]
		);

		$this->add_control(
			'wk_scroll_to_top_position_bottom',
			[
				'label'      => __( 'Bottom', 'wakoo' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', 'em', '%'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'em' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'%'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'.wk-scroll-to-top-wrap .wk-scroll-to-top-button' => 'bottom: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'wk_scroll_to_top_global' => 'yes',
				],
			]
		);

		$this->add_control(
			'wk_scroll_to_top_position_left',
			[
				'label'      => __( 'Left', 'wakoo' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', 'em', '%'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'em' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'%'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'.wk-scroll-to-top-button' => 'left: 15px',
					'.wk-scroll-to-top-wrap .wk-scroll-to-top-button' => 'left: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'wk_scroll_to_top_global'        => 'yes',
					'wk_scroll_to_top_position_text' => 'bottom-left',
				],
			]
		);

		$this->add_control(
			'wk_scroll_to_top_position_right',
			[
				'label'      => __( 'Right', 'wakoo' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px', 'em', '%'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'em' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'%'  => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'.wk-scroll-to-top-wrap .wk-scroll-to-top-button' => 'right: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'wk_scroll_to_top_global'        => 'yes',
					'wk_scroll_to_top_position_text' => 'bottom-right',
				],
			]
		);

		$this->add_control(
			'wk_scroll_to_top_button_width',
			[
				'label'      => __( 'Width', 'wakoo' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
				],
				'selectors'  => [
					'.wk-scroll-to-top-wrap .wk-scroll-to-top-button' => 'width: {{SIZE}}{{UNIT}};',
				],
				'separator'  => 'before',
				'condition'  => [
					'wk_scroll_to_top_global' => 'yes',
				],
			]
		);

		$this->add_control(
			'wk_scroll_to_top_button_height',
			[
				'label'      => __( 'Height', 'wakoo' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
				],
				'selectors'  => [
					'.wk-scroll-to-top-wrap .wk-scroll-to-top-button' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'wk_scroll_to_top_global' => 'yes',
				],
			]
		);

		$this->add_control(
			'wk_scroll_to_top_z_index',
			[
				'label'      => __( 'Z Index', 'wakoo' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 9999,
						'step' => 10,
					],
				],
				'selectors'  => [
					'.wk-scroll-to-top-wrap .wk-scroll-to-top-button' => 'z-index: {{SIZE}}',
				],
				'condition'  => [
					'wk_scroll_to_top_global' => 'yes',
				],
			]
		);

		$this->add_control(
			'wk_scroll_to_top_button_opacity',
			[
				'label'     => __( 'Opacity', 'wakoo' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'.wk-scroll-to-top-wrap .wk-scroll-to-top-button' => 'opacity: {{SIZE}};',
				],
				'condition' => [
					'wk_scroll_to_top_global' => 'yes',
				],
			]
		);

		$this->add_control(
			'wk_scroll_to_top_media_type',
			[
				'label'          => __( 'Media Type', 'wakoo' ),
				'type'           => Controls_Manager::CHOOSE,
				'label_block'    => false,
				'options'        => [
					'icon'  => [
						'title' => __( 'Icon', 'wakoo' ),
						'icon'  => 'eicon-star',
					],
					'image' => [
						'title' => __( 'Image', 'wakoo' ),
						'icon'  => 'eicon-image',
					],
					'text'  => [
						'title' => __( 'Text', 'wakoo' ),
						'icon'  => 'eicon-animation-text',
					],
				],
				'default'        => 'icon',
				'separator'      => 'before',
				'toggle'         => false,
				'style_transfer' => true,
				'condition'      => [
					'wk_scroll_to_top_global' => 'yes',
				],
			]
		);

		$this->add_control(
			'wk_scroll_to_top_button_icon',
			[
				'label'      => esc_html__( 'Icon', 'wakoo' ),
				'type'       => Controls_Manager::ICONS,
				'show_label' => false,
				'default'    => [
					'value'   => 'fas fa-chevron-up',
					'library' => 'fa-solid',
				],
				'condition'  => [
					'wk_scroll_to_top_global'     => 'yes',
					'wk_scroll_to_top_media_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'wk_scroll_to_top_button_image',
			[
				'label'      => __( 'Image', 'wakoo' ),
				'type'       => Controls_Manager::MEDIA,
				'show_label' => false,
				'dynamic'    => [
					'active' => true,
				],
				'condition'  => [
					'wk_scroll_to_top_global'     => 'yes',
					'wk_scroll_to_top_media_type' => 'image',
				],
			]
		);

		$this->add_control(
			'wk_scroll_to_top_button_text',
			[
				'label'       => __( 'Text', 'wakoo' ),
				'type'        => Controls_Manager::TEXT,
				'show_label'  => false,
				'label_block' => true,
				'default'     => 'Top',
				'condition'   => [
					'wk_scroll_to_top_global'     => 'yes',
					'wk_scroll_to_top_media_type' => 'text',
				],
			]
		);

		$this->add_control(
			'wk_scroll_to_top_button_icon_size',
			[
				'label'      => __( 'Size', 'wakoo' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'.wk-scroll-to-top-wrap .wk-scroll-to-top-button i' => 'font-size: {{SIZE}}{{UNIT}};',
					'.wk-scroll-to-top-wrap .wk-scroll-to-top-button img' => 'height: {{SIZE}}{{UNIT}};width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'wk_scroll_to_top_global'      => 'yes',
					'wk_scroll_to_top_media_type!' => 'text',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'wk_scroll_to_top_button_text_typo',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector'  => '.wk-scroll-to-top-wrap .wk-scroll-to-top-button span',
				'condition' => [
					'wk_scroll_to_top_global'     => 'yes',
					'wk_scroll_to_top_media_type' => 'text',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'wk_scroll_to_top_button_border',
				'exclude'   => ['color'], //remove border color
				'selector'  => '{{WRAPPER}} .wk-scroll-to-top-wrap .wk-scroll-to-top-button',
				'condition' => [
					'wk_scroll_to_top_global' => 'yes',
				],
			]
		);

		$this->start_controls_tabs(
			'wk_scroll_to_top_tabs',
			[
				'separator' => 'before',
				'condition' => [
					'wk_scroll_to_top_global' => 'yes',
				],
			]
		);

		$this->start_controls_tab(
			'wk_scroll_to_top_tab_normal',
			[
				'label'     => __( 'Normal', 'wakoo' ),
				'condition' => [
					'wk_scroll_to_top_global' => 'yes',
				],
			]
		);

		$this->add_control(
			'wk_scroll_to_top_button_icon_color',
			[
				'label'     => __( 'Color', 'wakoo' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'.wk-scroll-to-top-wrap .wk-scroll-to-top-button i' => 'color: {{VALUE}}',
					'.wk-scroll-to-top-wrap .wk-scroll-to-top-button span' => 'color: {{VALUE}}',
				],
				'condition' => [
					'wk_scroll_to_top_global'      => 'yes',
					'wk_scroll_to_top_media_type!' => 'image',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'wk_scroll_to_top_button_bg_color',
				'types'     => [ 'classic', 'gradient' ],
				'exclude'   => [ 'image' ],
				'selector'  => '.wk-scroll-to-top-wrap .wk-scroll-to-top-button',
				'condition' => [
					'wk_scroll_to_top_global' => 'yes',
				],
			]
		);

		$this->add_control(
			'wk_scroll_to_top_button_border_color',
			[
				'label'     => __( 'Border Color', 'wakoo' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'.wk-scroll-to-top-wrap .wk-scroll-to-top-button' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'wk_scroll_to_top_global' => 'yes',
					'wk_scroll_to_top_button_border_border!' => '',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'wk_scroll_to_top_tab_hover',
			[
				'label'     => __( 'Hover', 'wakoo' ),
				'condition' => [
					'wk_scroll_to_top_global' => 'yes',
				],
			]
		);

		$this->add_control(
			'wk_scroll_to_top_button_icon_hvr_color',
			[
				'label'     => __( 'Color', 'wakoo' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'.wk-scroll-to-top-wrap .wk-scroll-to-top-button:hover i' => 'color: {{VALUE}}',
					'.wk-scroll-to-top-wrap .wk-scroll-to-top-button:hover span' => 'color: {{VALUE}}',
				],
				'condition' => [
					'wk_scroll_to_top_global'      => 'yes',
					'wk_scroll_to_top_media_type!' => 'image',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'wk_scroll_to_top_button_bg_hvr_color',
				'types'     => [ 'classic', 'gradient' ],
				'exclude'   => [ 'image' ],
				'selector'  => '.wk-scroll-to-top-wrap .wk-scroll-to-top-button:hover',
				'condition' => [
					'wk_scroll_to_top_global' => 'yes',
				],
			]
		);

		$this->add_control(
			'wk_scroll_to_top_button_hvr_border_color',
			[
				'label'     => __( 'Border Color', 'wakoo' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'.wk-scroll-to-top-wrap .wk-scroll-to-top-button:hover' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'wk_scroll_to_top_global' => 'yes',
					'wk_scroll_to_top_button_border_border!' => '',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control(
			'wk_scroll_to_top_button_border_radius',
			[
				'label'      => __( 'Border Radius', 'wakoo' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px'],
				'selectors'  => [
					'.wk-scroll-to-top-wrap .wk-scroll-to-top-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator'  => 'before',
				'condition'  => [
					'wk_scroll_to_top_global' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'wk_scroll_to_top_button_box_shadow',
				'exclude'   => [
					'box_shadow_position',
				],
				'selector'  => '.wk-scroll-to-top-wrap .wk-scroll-to-top-button',
				'condition' => [
					'wk_scroll_to_top_global' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}
}
