<?php

namespace Wakoo\Elementor\Extensions;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

defined('ABSPATH') || die();

class Liquid_Glass {

	private static $instance = null;

	public static function instance() {
		if (is_null(self::$instance)) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function init() {
		add_action('elementor/frontend/before_register_scripts', [$this, 'register_scripts']);
		add_action('elementor/frontend/before_register_styles', [$this, 'register_styles']);
		add_action('elementor/preview/enqueue_scripts', [$this, 'enqueue_preview_scripts']);

		add_action('elementor/element/section/section_advanced/after_section_end', [$this, 'register_controls'], 10);
		add_action('elementor/element/column/section_advanced/after_section_end', [$this, 'register_controls'], 10);
		add_action('elementor/element/common/_section_style/after_section_end', [$this, 'register_controls'], 10);

		if (defined('ELEMENTOR_VERSION') && wk_elementor()->experiments->is_feature_active('container')) {
			add_action('elementor/element/container/section_layout/after_section_end', [$this, 'register_controls'], 10);
		}
	}

	public function register_scripts() {
		$suffix = wk_is_script_debug_enabled() ? '.' : '.min.';

		wp_register_script(
			'wakoo-liquid-glass',
			WAKOO_ASSETS . 'js/liquid-glass' . $suffix . 'js',
			['jquery', 'wakoo'],
			WAKOO_VERSION,
			true
		);
	}

	public function register_styles() {
		$suffix = wk_is_script_debug_enabled() ? '.' : '.min.';

		wp_register_style(
			'wakoo-liquid-glass',
			WAKOO_ASSETS . 'css/widgets/liquid-glass.min.css',
			[],
			WAKOO_VERSION
		);
	}

	public function enqueue_preview_scripts() {
		wp_enqueue_script('wakoo-liquid-glass');
	}

	public function register_controls($element) {

		$tab = Controls_Manager::TAB_ADVANCED;
		if ('common' === $element->get_name()) {
			$tab = Controls_Manager::TAB_ADVANCED;
		}

		$element->start_controls_section(
			'_wk_liquid_glass_section',
			[
				'label' => esc_html__('Liquid Glass', 'wakoo-pro') . wk_get_section_icon(),
				'tab'   => $tab,
			]
		);

		$this->add_content_controls($element);
		$this->add_style_controls($element);

		$element->end_controls_section();
	}

	public function add_content_controls($element) {

		$element->add_control(
			'wk_lg_switcher',
			[
				'label'        => __('Enable Liquid Glass', 'wakoo-pro'),
				'type'         => Controls_Manager::SWITCHER,
				'prefix_class' => 'wk-lg-',
				'render_type'  => 'template',
				'style_transfer' => false,
				'assets' => [
					'scripts' => [
						[
							'name' => 'wakoo-liquid-glass',
							'conditions' => [
								'terms' => [
									[
										'name' => 'wk_lg_switcher',
										'operator' => '===',
										'value' => 'yes',
									],
								],
							],
						],
					],
					'styles' => [
						[
							'name' => 'wakoo-liquid-glass',
							'conditions' => [
								'terms' => [
									[
										'name' => 'wk_lg_switcher',
										'operator' => '===',
										'value' => 'yes',
									],
								],
							],
						],
					],
				],
			]
		);

		$element->add_control(
			'wk_lg_preset',
			[
				'label'       => __('Effect Preset', 'wakoo-pro'),
				'description' => __('Tip: Use a semi-transparent background to see the effect clearly.', 'wakoo-pro'),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'abyss-glass',
				'options' => [
					'abyss-glass'       => __('Abyss Glass', 'wakoo-pro'),
					'aqua-warp'         => __('Aqua Warp', 'wakoo-pro'),
					'bubble-glass'      => __('Bubble Glass', 'wakoo-pro'),
					'bubble-lens'       => __('Bubble Lens', 'wakoo-pro'),
					'cascade-ripple'    => __('Cascade Ripple', 'wakoo-pro'),
					'diamond-dust'      => __('Diamond Dust', 'wakoo-pro'),
					'drop-water'        => __('Drop Water', 'wakoo-pro'),
					'distorted-prism'   => __('Distorted Prism', 'wakoo-pro'),
					'fine-crystal'      => __('Fine Crystal', 'wakoo-pro'),
					'frozen-glass'      => __('Frozen Glass', 'wakoo-pro'),
					'gentle-wave'       => __('Gentle Wave', 'wakoo-pro'),
					'glass-fiber'       => __('Glass Fiber', 'wakoo-pro'),
					'holographic-glass' => __('Holographic Glass', 'wakoo-pro'),
					'ice-crystal'       => __('Ice Crystal', 'wakoo-pro'),
					'jelly-blob'        => __('Jelly Blob', 'wakoo-pro'),
					'jelly-surface'     => __('Jelly Surface', 'wakoo-pro'),
					'lateral-surge'     => __('Lateral Surge', 'wakoo-pro'),
					'lava-flow'         => __('Lava Flow', 'wakoo-pro'),
					'liquid-lens'       => __('Liquid Lens', 'wakoo-pro'),
					'macos-glass'       => __('macOS Glass', 'wakoo-pro'),
					'magnifier-lens'    => __('Magnifier Lens', 'wakoo-pro'),
					'melted-glass'      => __('Melted Glass', 'wakoo-pro'),
					'micro-frost'       => __('Micro Frost', 'wakoo-pro'),
					'ocean-current'     => __('Ocean Current', 'wakoo-pro'),
					'prism-cut'         => __('Prism Cut', 'wakoo-pro'),
					'rain-streak'       => __('Rain Streak', 'wakoo-pro'),
					'tempest-glass'     => __('Tempest Glass', 'wakoo-pro'),
					'thai-frost'        => __('Thai Frost', 'wakoo-pro'),
					'thai-frost-2'      => __('Thai Frost 2', 'wakoo-pro'),
					'turbulent-warp'    => __('Turbulent Warp', 'wakoo-pro'),
					'ultra-lens'        => __('Ultra Lens', 'wakoo-pro'),
					'viscous-gel'       => __('Viscous Gel', 'wakoo-pro'),
					'wavy-water'        => __('Wavy Water', 'wakoo-pro'),
					'custom'            => __('Custom', 'wakoo-pro'),
				],
				'prefix_class' => 'wk-lg-',
				'render_type'  => 'template',
				'style_transfer' => true,
				'condition'    => [
					'wk_lg_switcher' => 'yes',
				],
			]
		);

		$element->add_control(
			'wk_lg_frequency_x',
			[
				'label' => __('Frequency X', 'wakoo-pro'),
				'type' => Controls_Manager::NUMBER,
				'default' => 0.006,
				'step' => 0.001,
				'render_type' => 'template',
				'selectors' => [
					'{{WRAPPER}}' => '--wk-lg-frequency-x: {{VALUE}};',
				],
				'condition' => [
					'wk_lg_switcher' => 'yes',
					'wk_lg_preset' => 'custom',
				],
			]
		);

		$element->add_control(
			'wk_lg_frequency_y',
			[
				'label' => __('Frequency Y', 'wakoo-pro'),
				'type' => Controls_Manager::NUMBER,
				'default' => 0.006,
				'step' => 0.001,
				'render_type' => 'template',
				'selectors' => [
					'{{WRAPPER}}' => '--wk-lg-frequency-y: {{VALUE}};',
				],
				'condition' => [
					'wk_lg_switcher' => 'yes',
					'wk_lg_preset' => 'custom',
				],
			]
		);

		$element->add_control(
			'wk_lg_scale',
			[
				'label' => __('Distortion Scale', 'wakoo-pro'),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 80,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'render_type' => 'template',
				'selectors' => [
					'{{WRAPPER}}' => '--wk-lg-scale: {{SIZE}};',
				],
				'condition' => [
					'wk_lg_switcher' => 'yes',
					'wk_lg_preset' => 'custom',
				],
			]
		);

		$element->add_control(
			'wk_lg_octaves',
			[
				'label' => __('Noise Octaves', 'wakoo-pro'),
				'type' => Controls_Manager::NUMBER,
				'default' => 2,
				'min' => 1,
				'max' => 10,
				'render_type' => 'template',
				'selectors' => [
					'{{WRAPPER}}' => '--wk-lg-octaves: {{VALUE}};',
				],
				'condition' => [
					'wk_lg_switcher' => 'yes',
					'wk_lg_preset' => 'custom',
				],
			]
		);

		$element->add_control(
			'wk_lg_seed',
			[
				'label' => __('Random Seed', 'wakoo-pro'),
				'type' => Controls_Manager::NUMBER,
				'default' => 92,
				'min' => 1,
				'max' => 9999,
				'render_type' => 'template',
				'selectors' => [
					'{{WRAPPER}}' => '--wk-lg-seed: {{VALUE}};',
				],
				'condition' => [
					'wk_lg_switcher' => 'yes',
					'wk_lg_preset' => 'custom',
				],
			]
		);

		$element->add_control(
			'wk_lg_x_channel',
			[
				'label' => __('X Channel', 'wakoo-pro'),
				'type' => Controls_Manager::SELECT,
				'default' => 'R',
				'options' => [
					'R' => 'Red',
					'G' => 'Green',
					'B' => 'Blue',
					'A' => 'Alpha',
				],
				'render_type' => 'template',
				'selectors' => [
					'{{WRAPPER}}' => '--wk-lg-x-channel: {{VALUE}};',
				],
				'condition' => [
					'wk_lg_switcher' => 'yes',
					'wk_lg_preset' => 'custom',
				],
			]
		);

		$element->add_control(
			'wk_lg_y_channel',
			[
				'label' => __('Y Channel', 'wakoo-pro'),
				'type' => Controls_Manager::SELECT,
				'default' => 'G',
				'options' => [
					'R' => 'Red',
					'G' => 'Green',
					'B' => 'Blue',
					'A' => 'Alpha',
				],
				'render_type' => 'template',
				'selectors' => [
					'{{WRAPPER}}' => '--wk-lg-y-channel: {{VALUE}};',
				],
				'condition' => [
					'wk_lg_switcher' => 'yes',
					'wk_lg_preset' => 'custom',
				],
			]
		);

		$element->add_control(
			'wk_lg_std_deviation',
			[
				'label' => __('Blur Standard Deviation', 'wakoo-pro'),
				'description' => __('Controls the Gaussian blur applied to the noise before displacement.', 'wakoo-pro'),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 2,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 20,
						'step' => 0.1,
					],
				],
				'render_type' => 'template',
				'selectors' => [
					'{{WRAPPER}}' => '--wk-lg-std-deviation: {{SIZE}};',
				],
				'condition' => [
					'wk_lg_switcher' => 'yes',
					'wk_lg_preset' => 'custom',
				],
			]
		);
	}

	public function add_style_controls($element) {

		$element->add_control(
			'wk_lg_blur',
			[
				'label'       => __('Blur Strength', 'wakoo-pro'),
				'description' => __('Leave empty to use the default value of the selected preset.', 'wakoo-pro'),
				'type'        => Controls_Manager::SLIDER,
				'range'       => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'selectors'   => [
					'{{WRAPPER}}' => '--wk-lg-blur: {{SIZE}}{{UNIT}};',
				],
				'condition'   => [
					'wk_lg_switcher' => 'yes',
				],
			]
		);

		$element->add_control(
			'wk_lg_shadow',
			[
				'label'       => __('Shadow', 'wakoo-pro'),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'soft-glow',
				'options'     => [
					'none'         => __('None', 'wakoo-pro'),
					'soft-glow'    => __('Soft Glow', 'wakoo-pro'),
					'warm-glow'    => __('Warm Glow', 'wakoo-pro'),
					'bright-glow'  => __('Bright Glow', 'wakoo-pro'),
					'wide-bloom'   => __('Wide Bloom', 'wakoo-pro'),
					'deep-bloom'   => __('Deep Bloom', 'wakoo-pro'),
					'top-light'    => __('Top Light', 'wakoo-pro'),
					'bottom-light' => __('Bottom Light', 'wakoo-pro'),
					'top-fade'     => __('Top Fade', 'wakoo-pro'),
					'bottom-fade'  => __('Bottom Fade', 'wakoo-pro'),
					'top-edge'     => __('Top Edge', 'wakoo-pro'),
					'rim-light'    => __('Rim Light', 'wakoo-pro'),
					'inner-shadow' => __('Inner Shadow', 'wakoo-pro'),
					'spotlight'    => __('Spotlight', 'wakoo-pro'),
					'frost-edge'   => __('Frost Edge', 'wakoo-pro'),
					'vignette'     => __('Vignette', 'wakoo-pro'),
					'customs'       => __('Custom Shadow', 'wakoo-pro'),
				],
				'prefix_class' => 'wk-lg-',
				'condition'    => [
					'wk_lg_switcher' => 'yes',
				],
				'selectors_dictionary' => [
					'none'         => '',
					'soft-glow'    => 'box-shadow: 0 0 15px 0 rgba(255, 255, 255, 0.6) inset;',
					'warm-glow'    => 'box-shadow: 0 0 20px 0 rgba(255, 255, 255, 0.65) inset;',
					'bright-glow'  => 'box-shadow: 0 0 15px 0 rgba(255, 255, 255, 0.7) inset;',
					'wide-bloom'   => 'box-shadow: 0 0 30px 1px rgba(255, 255, 255, 0.7) inset;',
					'deep-bloom'   => 'box-shadow: 0 0 40px 5px rgba(255, 255, 255, 0.6) inset;',
					'top-light'    => 'box-shadow: 0 20px 15px -5px rgba(255, 255, 255, 0.5) inset;',
					'bottom-light' => 'box-shadow: 0 -20px 25px -15px rgba(255, 255, 255, 0.5) inset;',
					'top-fade'     => 'box-shadow: 0 10px 25px -10px rgba(255, 255, 255, 0.4) inset;',
					'bottom-fade'  => 'box-shadow: 0 -10px 20px -5px rgba(255, 255, 255, 0.55) inset;',
					'top-edge'     => 'box-shadow: 0 15px 15px -10px rgba(255, 255, 255, 0.45) inset;',
					'rim-light'    => 'box-shadow: 0 0 10px 0 rgba(255, 255, 255, 0.8) inset, 0 0 2px 0 rgba(255, 255, 255, 0.9) inset;',
					'inner-shadow' => 'box-shadow: inset 0 2px 8px 0 rgba(0, 0, 0, 0.15), inset 0 0 12px 0 rgba(255, 255, 255, 0.3);',
					'spotlight'    => 'box-shadow: 0 -5px 30px -10px rgba(255, 255, 255, 0.7) inset;',
					'frost-edge'   => 'box-shadow: 0 0 6px 0 rgba(255, 255, 255, 0.9) inset, 0 0 20px -5px rgba(200, 220, 255, 0.4) inset;',
					'vignette'     => 'box-shadow: inset 0 0 50px 10px rgba(0, 0, 0, 0.08);',
					'customs'       => '',
				],
				'selectors' => [
					'{{WRAPPER}}' => '{{VALUE}};',
				],
				'style_transfer' => true,
			]
		);
		$element->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'wk_lg_shadow_custom',
				'label'     => __('Custom Shadow', 'wakoo-pro'),
				'fields_options' => [
					'box_shadow' => [
						'default' => [
							'color'      => 'rgba(255, 255, 255, 0.5)',
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 15,
							'spread'     => 0,
							'position'   => 'inset',
						],
					],
				],
				'condition' => [
					'wk_lg_switcher' => 'yes',
					'wk_lg_shadow'   => 'customs',
				],
				'selector' => '{{WRAPPER}}',
			]
		);

		$element->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'wk_lg_border',
				'label'    => __('Border', 'wakoo-pro'),
				'selector' => '{{WRAPPER}}',
				'condition' => [
					'wk_lg_switcher' => 'yes',
				],
			]
		);

		$element->add_responsive_control(
			'wk_lg_border_radius',
			[
				'label'      => __('Border Radius', 'wakoo-pro'),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%', 'em'],
				'selectors'  => [
					'{{WRAPPER}}' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'wk_lg_switcher' => 'yes',
				],
			]
		);

		
	}
}
