<?php
namespace Wakoo\Elementor\Extensions;

use Elementor\Controls_Manager;
use Elementor\Element_Base;
use Elementor\Shapes;

defined( 'ABSPATH' ) || die();

class Shape_Divider {

	private static $instance = null;

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		 return self::$instance;
	}

	public static function update_shape_list( Element_Base $element ) {
		$default_shapes = [];
		$wakoo_shapes_top = [];
		$wakoo_shapes_bottom = [];
		$shapes = Shapes::get_shapes();
		$has_visual_control = false;

		if ( array_key_exists('mountains', $shapes ) && array_key_exists( 'image', $shapes['mountains'] ) ) {
			$has_visual_control = true;
		}

		if ( false == $has_visual_control ) {

			foreach ( $shapes as $shape_name => $shape_props ) {
				if ( ! isset( $shape_props['wk_shape'] ) ) {
					$default_shapes[ $shape_name ] = $shape_props['title'];
				} elseif ( ! isset( $shape_props['wk_shape_bottom'] ) ){
					$wakoo_shapes_top[ $shape_name ] = $shape_props['title'];
				} else {
					$wakoo_shapes_bottom[ $shape_name ] = $shape_props['title'];
				}
			}

			$element->update_control(
				'shape_divider_top',
				[
					'type' => Controls_Manager::SELECT,
					'groups' => [
						[
							'label' => __( 'Disable', 'wakoo' ),
							'options' => [
								'' => __( 'None', 'wakoo' ),
							],
						],
						[
							'label' => __( 'Default Shapes', 'wakoo' ),
							'options' => $default_shapes,
						],
						[
							'label' => __( 'Wakoo Shapes', 'wakoo' ),
							'options' => $wakoo_shapes_top,
						],
					],
				]
			);

			$element->update_control(
				'shape_divider_bottom',
				[
					'type' => Controls_Manager::SELECT,
					'groups' => [
						[
							'label' => __( 'Disable', 'wakoo' ),
							'options' => [
								'' => __( 'None', 'wakoo' ),
							],
						],
						[
							'label' => __( 'Default Shapes', 'wakoo' ),
							'options' => $default_shapes,
						],
						[
							'label' => __( 'Wakoo Shapes', 'wakoo' ),
							'options' => array_merge( $wakoo_shapes_top, $wakoo_shapes_bottom ),
						],
					],
				]
			);
		}
	}

	/**
	 * Undocumented function
	 *
	 * @param array $shape_list
	 * @return void
	 */
	public static function additional_shape_divider( $shape_list ) {
		$wakoo_shapes = [
			'abstract-web' => [
				'title' => _x( 'Abstract Web', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/abstract-web.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/abstract-web.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/abstract-web.svg',
				'has_flip' => true,
				'has_negative' => false,
				'wk_shape' => true,
			],
			'crossline' => [
				'title' => _x( 'Crossline', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/crossline.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/crossline.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/crossline.svg',
				'has_flip' => true,
				'has_negative' => false,
				'wk_shape' => true,
			],
			'droplet' => [
				'title' => _x( 'Droplet', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/droplet.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/droplet.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/droplet.svg',
				'has_flip' => true,
				'has_negative' => true,
				'wk_shape' => true,
			],
			'flame' => [
				'title' => _x( 'Flame', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/flame.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/flame.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/flame.svg',
				'has_flip' => true,
				'has_negative' => false,
				'wk_shape' => true,
			],
			'frame' => [
				'title' => _x( 'Frame', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/frame.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/frame.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/frame.svg',
				'has_flip' => true,
				'has_negative' => true,
				'wk_shape' => true,
			],
			'half-circle' => [
				'title' => _x( 'Half Circle', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/half-circle.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/half-circle.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/half-circle.svg',
				'has_flip' => true,
				'has_negative' => true,
				'wk_shape' => true,
			],
			'multi-cloud' => [
				'title' => _x( 'Multi Cloud', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/multi-cloud.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/multi-cloud.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/multi-cloud.svg',
				'has_flip' => true,
				'has_negative' => false,
				'wk_shape' => true,
			],
			'multi-wave' => [
				'title' => _x( 'Multi Wave', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/multi-wave.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/multi-wave.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/multi-wave.svg',
				'has_flip' => true,
				'has_negative' => false,
				'wk_shape' => true,
			],
			'smooth-zigzag' => [
				'title' => _x( 'Smooth Zigzag', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/smooth-zigzag.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/smooth-zigzag.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/smooth-zigzag.svg',
				'has_flip' => true,
				'has_negative' => false,
				'wk_shape' => true,
			],
			'splash' => [
				'title' => _x( 'Splash', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/splash.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/splash.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/splash.svg',
				'has_flip' => true,
				'has_negative' => true,
				'wk_shape' => true,
			],
			'splash2' => [
				'title' => _x( 'Splash 2', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/splash2.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/splash2.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/splash2.svg',
				'has_flip' => true,
				'has_negative' => true,
				'wk_shape' => true,
			],
			'torn-paper' => [
				'title' => _x( 'Torn Paper', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/torn-paper.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/torn-paper.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/torn-paper.svg',
				'has_flip' => true,
				'has_negative' => false,
				'wk_shape' => true,
			],
			'brush' => [
				'title' => _x( 'Brush', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/brush.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/brush.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/brush.svg',
				'has_flip' => true,
				'has_negative' => true,
				'wk_shape' => true,
			],
			'sports' => [
				'title' => _x( 'Sports', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/sports.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/sports.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/sports.svg',
				'has_flip' => true,
				'has_negative' => false,
				'wk_shape' => true,
				'wk_shape_bottom' => true,
			],
			'landscape' => [
				'title' => _x( 'Landscape', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/landscape.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/landscape.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/landscape.svg',
				'has_flip' => true,
				'has_negative' => false,
				'wk_shape' => true,
				'wk_shape_bottom' => true,
			],
			'nature' => [
				'title' => _x( 'Nature', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/nature.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/nature.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/nature.svg',
				'has_flip' => true,
				'has_negative' => false,
				'wk_shape' => true,
				'wk_shape_bottom' => true,
			],
			'desert' => [
				'title' => _x( 'Desert', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/desert.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/desert.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/desert.svg',
				'has_flip' => true,
				'has_negative' => false,
				'wk_shape' => true,
				'wk_shape_bottom' => true,
			],
			'under-water' => [
				'title' => _x( 'Under Water', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/under-water.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/under-water.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/under-water.svg',
				'has_flip' => true,
				'has_negative' => false,
				'wk_shape' => true,
				'wk_shape_bottom' => true,
			],
			'cityscape-layer' => [
				'title' => _x( 'Cityscape Layer', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/cityscape-layer.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/cityscape-layer.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/cityscape-layer.svg',
				'has_flip' => true,
				'has_negative' => false,
				'wk_shape' => true,
				'wk_shape_bottom' => true,
			],
			'drop' => [
				'title' => _x( 'Drop', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/drop.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/drop.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/drop.svg',
				'has_flip' => true,
				'has_negative' => false,
				'wk_shape' => true,
			],
			'mosque' => [
				'title' => _x( 'Mosque', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/mosque.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/mosque.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/mosque.svg',
				'has_flip' => true,
				'has_negative' => false,
				'wk_shape' => true,
			],
			'christmas' => [
				'title' => _x( 'Christmas', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/christmas.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/christmas.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/christmas.svg',
				'has_flip' => true,
				'has_negative' => true,
				'wk_shape' => true,
			],
			'christmas2' => [
				'title' => _x( 'Christmas 2', 'Shapes', 'wakoo' ),
				'path' => WAKOO_DIR_PATH . 'assets/imgs/shape-divider/christmas2.svg',
				'url' => WAKOO_ASSETS . 'imgs/shape-divider/christmas2.svg',
				'image' => WAKOO_ASSETS . 'imgs/shape-divider/christmas2.svg',
				'has_flip' => true,
				'has_negative' => true,
				'wk_shape' => true,
			]
		];

		/*
		 * svg path should contain elementor class to show in editor mode
		*/
		return array_merge( $wakoo_shapes, $shape_list );
	}
}
