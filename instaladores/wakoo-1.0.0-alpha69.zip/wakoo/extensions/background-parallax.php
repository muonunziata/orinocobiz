<?php

namespace Wakoo\Elementor\Extensions;

// Elementor Classes.
use Elementor\Controls_Manager;
use Elementor\Control_Media;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Typography;

defined('ABSPATH') || die();

class Background_Parallax {

	/**
	 * @var mixed
	 */
	private static $instance = null;

	/**
	 * @var mixed
	 */
	private $load_script = null;

	public static function instance() {
		if (is_null(self::$instance)) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public function init() {

		add_action( 'elementor/frontend/before_register_scripts', [ $this, 'register_scripts' ] );
		add_action( 'elementor/frontend/before_register_styles', [ $this, 'register_styles' ] );
		add_action( 'elementor/preview/enqueue_scripts', [ $this, 'enqueue_preview_scripts' ] );

		add_action('elementor/element/section/section_layout/after_section_end', [ $this, 'register_controls' ], 10);
		add_action('elementor/element/container/section_layout/after_section_end', [ $this, 'register_controls' ], 10);

		add_action( 'elementor/frontend/section/before_render', [ $this, 'before_render' ], 10, 1 );
		add_action( 'elementor/frontend/container/before_render', [ $this, 'before_render' ], 10, 1 );

		add_action( 'elementor/section/print_template', array( $this, 'editor_template_print' ), 10, 2 );
		add_action( 'elementor/container/print_template', array( $this, 'editor_template_print' ), 10, 2 );
	}

	public function register_scripts() {
		$suffix = wk_is_script_debug_enabled() ? '.' : '.min.';

		wp_register_script(
			'jarallax-js',
			WAKOO_ASSETS . 'vendor/jarallax/jarallax.min.js',
			null,
			WAKOO_VERSION,
			true
		);

		wp_register_script(
			'wakoo-background-parallax',
			WAKOO_ASSETS . 'js/background-parallax' . $suffix . 'js',
			[ 'jquery', 'wakoo' ],
			WAKOO_VERSION,
			true
		);

	}

	public function register_styles() {
		wp_register_style(
			'jarallax-css',
			WAKOO_ASSETS . 'vendor/jarallax/jarallax.min.css',
			[],
			WAKOO_VERSION
		);
	}

	public function enqueue_preview_scripts() {
		wp_enqueue_style( 'jarallax-css' );
		wp_enqueue_script( 'jarallax-js' );
		wp_enqueue_script( 'wakoo-background-parallax' );
	}

	/**
	 * Register Parallax controls.
	 */
	public function register_controls( $element ) {

		$element->start_controls_section(
			'section_wk_bg_parallax',
			[
				'label' => ( __( 'Background Parallax', 'wakoo') ) . wk_get_section_icon(),
				'tab'   => Controls_Manager::TAB_LAYOUT,
			]
		);

		$element->add_control(
			'wk_bg_parallax_switcher',
			[
				'label'        => __( 'Enable BG Parallax', 'wakoo' ),
				'type'         => Controls_Manager::SWITCHER,
				'prefix_class' => 'wk-bg-parallax-',
				'render_type'  => 'template',
				'style_transfer' => false,
				'frontend_available' => true,
				'assets' => [
					'scripts' => [
						[
							'name' => 'jarallax-js',
							'conditions' => [
								'terms' => [
									[
										'name' => 'wk_bg_parallax_switcher',
										'operator' => '===',
										'value' => 'yes',
									],
								],
							],
						],
						[
							'name' => 'wakoo-background-parallax',
							'conditions' => [
								'terms' => [
									[
										'name' => 'wk_bg_parallax_switcher',
										'operator' => '===',
										'value' => 'yes',
									],
								],
							],
						]
					],
					'styles' => [
						[
							'name' => 'jarallax-css',
							'conditions' => [
								'terms' => [
									[
										'name' => 'wk_bg_parallax_switcher',
										'operator' => '===',
										'value' => 'yes',
									]
								]
							]
						]
					]
				],
			]
		);

		$element->add_control(
			'wk_bg_parallax_update',
			[
				'label' => __( 'Apply Button', 'wakoo' ),
				'show_label' => false,
				'type'  => Controls_Manager::RAW_HTML,
				'raw' => '<div class="elementor-update-preview" style="margin: 0 0 8px 0"><div class="elementor-update-preview-title">' . __( 'Update changes to the page', 'wakoo' ) . '</div><div class="elementor-update-preview-button-wrapper"><button class="elementor-update-preview-button elementor-button elementor-button-success" style="background-image: linear-gradient(90deg, #e2498a 0%, #562dd4 100%);">' . __( 'Apply', 'wakoo' ) . '</button></div></div>',
                'condition' => [
                    'wk_bg_parallax_switcher' => 'yes',
                ],
			]
		);

		$element->add_control(
			'wk_bg_parallax_type',
			[
				'label'       => __( 'Type', 'wakoo' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => [
					'scroll'         => __( 'Scroll', 'wakoo' ),
					'scroll-opacity' => __( 'Scroll with opacity', 'wakoo' ),
					'opacity'        => __( 'Opacity', 'wakoo' ),
					'scale'          => __( 'Scale', 'wakoo' ),
					'scale-opacity'  => __( 'Scale with opacity', 'wakoo' ),
					'automove'       => __( 'Auto Moving', 'wakoo' ),
				],
				'label_block' => 'true',
				'render_type' => 'template',
				'condition'   => [
					'wk_bg_parallax_switcher' => 'yes'
				],
				'frontend_available' => true,
			]
		);

		$element->add_control(
			'wk_bg_parallax_automove_direction',
			[
				'label'              => __( 'Direction', 'wakoo' ),
				'type'               => Controls_Manager::SELECT,
				'options'            => [
					'left'   => __( 'Left to Right', 'wakoo' ),
					'right'  => __( 'Right to Left', 'wakoo' ),
					'top'    => __( 'Top to Bottom', 'wakoo' ),
					'bottom' => __( 'Bottom to Top', 'wakoo' )
				],
				'default'            => 'left',
				'condition'          => [
					'wk_bg_parallax_switcher' => 'yes',
					'wk_bg_parallax_type'     => 'automove'
				],
				'frontend_available' => true
			]
		);

		$element->add_control(
			'wk_bg_parallax_speed',
			[
				'label'     => __( 'Speed', 'wakoo' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => -1,
						'max'  => 2,
						'step' => 0.1
					]
				],
				'condition' => [
					'wk_bg_parallax_switcher' => 'yes',
					'wk_bg_parallax_type!'    => 'automove'
				],
				'frontend_available' => true,
			]
		);

		$element->add_control(
			'wk_bg_parallax_automove_speed',
			[
				'label'              => __( 'Speed', 'wakoo' ),
				'type'               => Controls_Manager::NUMBER,
				'default'            => 3,
				'min'                => 0,
				'max'                => 150,
				'description'        => __( 'Set the speed of background movement, default: 3', 'wakoo' ),
				'condition'          => [
					'wk_bg_parallax_switcher' => 'yes',
					'wk_bg_parallax_type'     => 'automove'
				],
				'frontend_available' => true
			]
		);

		$element->add_control(
			'wk_bg_parallax_enable_on_android',
			[
				'label'     => __( 'Enable on Android', 'wakoo' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => [
					'wk_bg_parallax_switcher' => 'yes',
					'wk_bg_parallax_type!'    => 'automove'
				],
				'frontend_available' => true,
			]
		);

		$element->add_control(
			'wk_bg_parallax_enable_on_ios',
			[
				'label'     => __( 'Enable on iOS', 'wakoo' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => [
					'wk_bg_parallax_switcher' => 'yes',
					'wk_bg_parallax_type!'    => 'automove'
				],
				'frontend_available' => true,
			]
		);

		$element->end_controls_section();
	}

	/**
	 * Render Parallax output on the frontend.
	 */
	public function before_render( $element ) {
		$settings = $element->get_settings_for_display();
		$is_enable = 'yes' === $element->get_settings( 'wk_bg_parallax_switcher' ) ? true : false;
		$bg_parallax_settings = [
			'type' => isset( $settings['wk_bg_parallax_type'] ) ? $settings['wk_bg_parallax_type'] : ''
		];

		if ( isset( $settings['wk_bg_parallax_type'] ) && '' !== $settings['wk_bg_parallax_type'] && $is_enable ) {
			if ( 'automove' !== $bg_parallax_settings['type'] ) {
				$element->add_render_attribute( '_wrapper', 'class', 'wk-bg-parallax-wrap-hide' );
				$speed = ( isset( $settings['wk_bg_parallax_speed']['size'] ) && ! empty( $settings['wk_bg_parallax_speed']['size'] ) ) ? $settings['wk_bg_parallax_speed']['size'] : 0.5;
				$bg_parallax_settings['speed'] = $speed;
				$bg_parallax_settings['android'] ='yes' === $settings['wk_bg_parallax_enable_on_android'] ? 0 : 1;
				$bg_parallax_settings['ios'] = 'yes' === $settings['wk_bg_parallax_enable_on_ios'] ? 0 : 1;
				$bg_parallax_settings['size'] = isset( $settings['background_size'] ) ? $settings['background_size'] : 'cover';
				$bg_parallax_settings['repeat'] = isset( $settings['background_repeat'] ) ? $settings['background_repeat'] : 'no-repeat';

			} elseif ( 'automove' === $bg_parallax_settings['type'] ) {
				$bg_parallax_settings['speed'] = ! empty( $settings['wk_bg_parallax_automove_speed'] ) ? $settings['wk_bg_parallax_automove_speed'] : 3;
				$bg_parallax_settings['direction'] = ! empty( $settings['wk_bg_parallax_automove_direction'] ) ? $settings['wk_bg_parallax_automove_direction'] : 'left';

			}
			$element->add_render_attribute( '_wrapper', 'data-wk-bg-parallax', wp_json_encode( $bg_parallax_settings ) );

		}
	}

	public function editor_template_print( $template, $widget ) {

		if ( ! $template && 'widget' === $widget->get_type() ) {
			return;
		}

		$old_template = $template;
		ob_start();
		?>
		<#
		var isEnabled = 'yes' == settings.wk_bg_parallax_switcher ? true : false;
		if( isEnabled ) {
			var parallaxSettings = {};
			parallaxSettings.type = ( "undefined" !== typeof settings.wk_bg_parallax_type  && settings.wk_bg_parallax_type ) ? settings.wk_bg_parallax_type: '';
			if ( "undefined" !== typeof parallaxSettings.type && "automove" !== parallaxSettings.type ) {
				parallaxSettings.speed    = "" !== settings.wk_bg_parallax_speed.size ? settings.wk_bg_parallax_speed.size : 0.5;
				parallaxSettings.android  = "yes" === settings.wk_bg_parallax_enable_on_android ? 0 : 1;
				parallaxSettings.ios      = "yes" === settings.wk_bg_parallax_enable_on_ios ? 0 : 1;
				parallaxSettings.size     = settings.background_size;
				parallaxSettings.position = settings.background_position;
				parallaxSettings.repeat   = settings.background_repeat;
			} else {
				parallaxSettings.speed     = "" !== settings.wk_bg_parallax_automove_speed ? settings.wk_bg_parallax_automove_speed : 3 ;
				parallaxSettings.direction = "" !== settings.wk_bg_parallax_automove_direction ? settings.wk_bg_parallax_automove_direction : 'left';
			}

			view.addRenderAttribute( 'wk_bg_parallax_data', {
				'id': 'wk-bg-parallax-' + view.getID(),
				'data-wk-bg-parallax': JSON.stringify( parallaxSettings )
			});

		#>
			<div {{{ view.getRenderAttributeString( 'wk_bg_parallax_data' ) }}}></div>
		<# } #>
		<?php

		$parallax_content = ob_get_contents();
		ob_end_clean();
		$template = $parallax_content . $old_template;
		return $template;
	}
}
