<?php
namespace Wakoo\Elementor\Extensions;

use Elementor\Element_Base;
use Elementor\Controls_Manager;
use Wakoo\Elementor\Controls\Widget_List;

defined( 'ABSPATH' ) || die();

class Equal_Height {

	static $should_script_enqueue = false;

	private static $instance = null;

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		 return self::$instance;
	}

	public static function enqueue_preview_scripts() {
		wp_enqueue_script( 'jquery-match-height' );
		wp_enqueue_script( 'wakoo-equal-height' );
	}


	public static function register_scripts() {
		$suffix = wk_is_script_debug_enabled() ? '.' : '.min.';
		// Equal Height
		wp_register_script(
			'wakoo-equal-height',
			WAKOO_ASSETS . 'js/extension-equal-height' . $suffix . 'js',
			// [ 'elementor-frontend' ],
			[ 'jquery' ],
			WAKOO_VERSION,
			true
		);
	}

	public static function register( Element_Base $element ) {
		$element->start_controls_section(
			'_section_wk_eqh',
			[
				'label' => __( 'Equal Height', 'wakoo' ) . wk_get_section_icon(),
				'tab' => Controls_Manager::TAB_ADVANCED,
			]
		);

		$element->add_control(
			'_wk_eqh_enable',
			[
				'label'        => __( 'Enable', 'wakoo' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => false,
				'return_value' => 'yes',
				'render_type'  => 'ui',
				'assets' => [
					'scripts' => [
						[
							'name' => 'jquery-match-height',
							'conditions' => [
								'terms' => [
									[
										'name' => '_wk_eqh_enable',
										'operator' => '===',
										'value' => 'yes',
									],
								],
							],
						],
						[
							'name' => 'wakoo-equal-height',
							'conditions' => [
								'terms' => [
									[
										'name' => '_wk_eqh_enable',
										'operator' => '===',
										'value' => 'yes',
									],
								],
							],
						],
					],
				],
				'frontend_available' => true,
			]
		);

		$element->add_control(
			'_wk_eqh_to',
			[
				'label' => __( 'Apply To', 'wakoo' ),
				'type'  => Controls_Manager::SELECT,
				'options' => [
					'widget'   => __( 'Widgets', 'wakoo' ),
				],
				'default' => 'widget',
				'condition' => [
					'_wk_eqh_enable' => 'yes',
				],
				'render_type'  => 'ui',
				'frontend_available' => true,
			]
		);

		$element->add_control(
			'_wk_eqh_widget',
			[
				'label' => __( 'Select Widgets', 'wakoo' ),
				'label_block' => true,
				'description' => __( 'You can select multiple widgets from the dropdown and these widgets are only from the current selected section.', 'wakoo' ),
				'type' => Widget_List::TYPE,
				'multiple' => true,
				'condition' => [
					'_wk_eqh_enable' => 'yes',
					'_wk_eqh_to' => 'widget'
				],
				'render_type' => 'ui',
				'frontend_available' => true,
			]
		);

		$element->add_control(
			'_wk_eqh_disable_on_tablet',
			[
				'label'        => __( 'Disable On Tablet', 'wakoo' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'return_value' => 'yes',
				'render_type'  => 'ui',
				'frontend_available' => true,
				'condition' => [
					'_wk_eqh_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'_wk_eqh_disable_on_mobile',
			[
				'label'        => __( 'Disable On Mobile', 'wakoo' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'render_type'  => 'ui',
				'frontend_available' => true,
				'condition' => [
					'_wk_eqh_enable' => 'yes',
				],
			]
		);

		$element->end_controls_section();
	}
}
