<?php
/**
 * CSS Transform extension class.
 *
 * @package Wakoo
 */
namespace Wakoo\Elementor\Extensions;

use Elementor\Element_Base;
use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class CSS_Transform {

	private static $instance = null;

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		 return self::$instance;
	}

	public static function register( Element_Base $element ) {
		$element->start_controls_section(
			'_section_css_transform',
			[
				'label' => __( 'CSS Transform', 'wakoo' ) . wk_get_section_icon(),
				'tab' => Controls_Manager::TAB_ADVANCED,
			]
		);

		$element->add_control(
			'wk_transform_fx',
			[
				'label' => __( 'Enable', 'wakoo' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'prefix_class' => 'wk-css-transform-',
			]
		);

		$element->start_controls_tabs(
			'_tabs_wk_transform',
			[
				'condition' => [
					'wk_transform_fx' => 'yes',
				],
			]
		);

		$element->start_controls_tab(
			'_tabs_wk_transform_normal',
			[
				'label' => __( 'Normal', 'wakoo' ),
				'condition' => [
					'wk_transform_fx' => 'yes',
				],
			]
		);

		$element->add_control(
			'wk_transform_fx_translate_toggle',
			[
				'label' => __( 'Translate', 'wakoo' ),
				'type' => Controls_Manager::POPOVER_TOGGLE,
				'return_value' => 'yes',
				'condition' => [
					'wk_transform_fx' => 'yes',
				],
			]
		);

		$element->start_popover();

		$element->add_responsive_control(
			'wk_transform_fx_translate_x',
			[
				'label' => __( 'Translate X', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
					]
				],
				'condition' => [
					'wk_transform_fx_translate_toggle' => 'yes',
					'wk_transform_fx' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-translate-x: {{SIZE}}px;'
				],
			]
		);

		$element->add_responsive_control(
			'wk_transform_fx_translate_y',
			[
				'label' => __( 'Translate Y', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
					]
				],
				'condition' => [
					'wk_transform_fx_translate_toggle' => 'yes',
					'wk_transform_fx' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-translate-y: {{SIZE}}px;'
				],
			]
		);

		$element->end_popover();

		$element->add_control(
			'wk_transform_fx_rotate_toggle',
			[
				'label' => __( 'Rotate', 'wakoo' ),
				'type' => Controls_Manager::POPOVER_TOGGLE,
				'condition' => [
					'wk_transform_fx' => 'yes',
				],
			]
		);

		$element->start_popover();

		$element->add_control(
			'wk_transform_fx_rotate_mode',
			[
				'label' => __( 'Mode', 'wakoo' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'compact' => [
						'title' => __( 'Compact', 'wakoo' ),
						'icon' => 'eicon-plus-circle',
					],
					'loose' => [
						'title' => __( 'Loose', 'wakoo' ),
						'icon' => 'eicon-minus-circle',
					],
				],
				'default' => 'loose',
				'toggle' => false
			]
		);

		$element->add_control(
			'wk_transform_fx_rotate_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$element->add_responsive_control(
			'wk_transform_fx_rotate_x',
			[
				'label' => __( 'Rotate X', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => -180,
						'max' => 180,
					]
				],
				'condition' => [
					'wk_transform_fx_rotate_toggle' => 'yes',
					'wk_transform_fx' => 'yes',
					'wk_transform_fx_rotate_mode' => 'loose'
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-rotate-x: {{SIZE}}deg;'
				],
			]
		);

		$element->add_responsive_control(
			'wk_transform_fx_rotate_y',
			[
				'label' => __( 'Rotate Y', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => -180,
						'max' => 180,
					]
				],
				'condition' => [
					'wk_transform_fx_rotate_toggle' => 'yes',
					'wk_transform_fx' => 'yes',
					'wk_transform_fx_rotate_mode' => 'loose'
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-rotate-y: {{SIZE}}deg;'
				],
			]
		);

		$element->add_responsive_control(
			'wk_transform_fx_rotate_z',
			[
				'label' => __( 'Rotate (Z)', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => -180,
						'max' => 180,
					]
				],
				'condition' => [
					'wk_transform_fx_rotate_toggle' => 'yes',
					'wk_transform_fx' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-rotate-z: {{SIZE}}deg;'
				],
			]
		);

		$element->end_popover();

		$element->add_control(
			'wk_transform_fx_scale_toggle',
			[
				'label' => __( 'Scale', 'wakoo' ),
				'type' => Controls_Manager::POPOVER_TOGGLE,
				'return_value' => 'yes',
				'condition' => [
					'wk_transform_fx' => 'yes',
				],
			]
		);

		$element->start_popover();

		$element->add_control(
			'wk_transform_fx_scale_mode',
			[
				'label' => __( 'Mode', 'wakoo' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'compact' => [
						'title' => __( 'Compact', 'wakoo' ),
						'icon' => 'eicon-plus-circle',
					],
					'loose' => [
						'title' => __( 'Loose', 'wakoo' ),
						'icon' => 'eicon-minus-circle',
					],
				],
				'default' => 'loose',
				'toggle' => false
			]
		);

		$element->add_control(
			'wk_transform_fx_scale_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$element->add_responsive_control(
			'wk_transform_fx_scale_x',
			[
				'label' => __( 'Scale (X)', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'default' => [
					'size' => 1
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 5,
						'step' => .1
					]
				],
				'condition' => [
					'wk_transform_fx_scale_toggle' => 'yes',
					'wk_transform_fx' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-scale-x: {{SIZE}}; --wk-tfx-scale-y: {{SIZE}};'
				],
			]
		);

		$element->add_responsive_control(
			'wk_transform_fx_scale_y',
			[
				'label' => __( 'Scale Y', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'default' => [
					'size' => 1
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 5,
						'step' => .1
					]
				],
				'condition' => [
					'wk_transform_fx_scale_toggle' => 'yes',
					'wk_transform_fx' => 'yes',
					'wk_transform_fx_scale_mode' => 'loose',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-scale-y: {{SIZE}};'
				],
			]
		);

		$element->end_popover();

		$element->add_control(
			'wk_transform_fx_skew_toggle',
			[
				'label' => __( 'Skew', 'wakoo' ),
				'type' => Controls_Manager::POPOVER_TOGGLE,
				'return_value' => 'yes',
				'condition' => [
					'wk_transform_fx' => 'yes',
				],
			]
		);

		$element->start_popover();

		$element->add_responsive_control(
			'wk_transform_fx_skew_x',
			[
				'label' => __( 'Skew X', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['deg'],
				'range' => [
					'px' => [
						'min' => -180,
						'max' => 180,
					]
				],
				'condition' => [
					'wk_transform_fx_skew_toggle' => 'yes',
					'wk_transform_fx' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-skew-x: {{SIZE}}deg;'
				],
			]
		);

		$element->add_responsive_control(
			'wk_transform_fx_skew_y',
			[
				'label' => __( 'Skew Y', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['deg'],
				'range' => [
					'px' => [
						'min' => -180,
						'max' => 180,
					]
				],
				'condition' => [
					'wk_transform_fx_skew_toggle' => 'yes',
					'wk_transform_fx' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-skew-y: {{SIZE}}deg;'
				],
			]
		);

		$element->end_popover();

		$element->end_controls_tab();

		$element->start_controls_tab(
            '_tabs_wk_transform_hover',
            [
				'label' => __( 'Hover', 'wakoo' ),
				'condition' => [
					'wk_transform_fx' => 'yes',
				],
            ]
		);

		$element->add_control(
			'wk_transform_fx_translate_toggle_hover',
			[
				'label' => __( 'Translate', 'wakoo' ),
				'type' => Controls_Manager::POPOVER_TOGGLE,
				'return_value' => 'yes',
				'condition' => [
					'wk_transform_fx' => 'yes',
				],
			]
		);

		$element->start_popover();

		$element->add_responsive_control(
			'wk_transform_fx_translate_x_hover',
			[
				'label' => __( 'Translate X', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
					]
				],
				'condition' => [
					'wk_transform_fx_translate_toggle_hover' => 'yes',
					'wk_transform_fx' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-translate-x-hover: {{SIZE}}px;'
				],
			]
		);

		$element->add_responsive_control(
			'wk_transform_fx_translate_y_hover',
			[
				'label' => __( 'Translate Y', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
					]
				],
				'condition' => [
					'wk_transform_fx_translate_toggle_hover' => 'yes',
					'wk_transform_fx' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-translate-y-hover: {{SIZE}}px;'
				],
			]
		);

		$element->end_popover();

		$element->add_control(
			'wk_transform_fx_rotate_toggle_hover',
			[
				'label' => __( 'Rotate', 'wakoo' ),
				'type' => Controls_Manager::POPOVER_TOGGLE,
				'condition' => [
					'wk_transform_fx' => 'yes',
				],
			]
		);

		$element->start_popover();

		$element->add_control(
			'wk_transform_fx_rotate_mode_hover',
			[
				'label' => __( 'Mode', 'wakoo' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'compact' => [
						'title' => __( 'Compact', 'wakoo' ),
						'icon' => 'eicon-plus-circle',
					],
					'loose' => [
						'title' => __( 'Loose', 'wakoo' ),
						'icon' => 'eicon-minus-circle',
					],
				],
				'default' => 'loose',
				'toggle' => false
			]
		);

		$element->add_control(
			'wk_transform_fx_rotate_hr_hover',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$element->add_responsive_control(
			'wk_transform_fx_rotate_x_hover',
			[
				'label' => __( 'Rotate X', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => -180,
						'max' => 180,
					]
				],
				'condition' => [
					'wk_transform_fx_rotate_toggle_hover' => 'yes',
					'wk_transform_fx' => 'yes',
					'wk_transform_fx_rotate_mode_hover' => 'loose'
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-rotate-x-hover: {{SIZE}}deg;'
				],
			]
		);

		$element->add_responsive_control(
			'wk_transform_fx_rotate_y_hover',
			[
				'label' => __( 'Rotate Y', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => -180,
						'max' => 180,
					]
				],
				'condition' => [
					'wk_transform_fx_rotate_toggle_hover' => 'yes',
					'wk_transform_fx' => 'yes',
					'wk_transform_fx_rotate_mode_hover' => 'loose'
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-rotate-y-hover: {{SIZE}}deg;'
				],
			]
		);

		$element->add_responsive_control(
			'wk_transform_fx_rotate_z_hover',
			[
				'label' => __( 'Rotate (Z)', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => -180,
						'max' => 180,
					]
				],
				'condition' => [
					'wk_transform_fx_rotate_toggle_hover' => 'yes',
					'wk_transform_fx' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-rotate-z-hover: {{SIZE}}deg;'
				],
			]
		);

		$element->end_popover();

		$element->add_control(
			'wk_transform_fx_scale_toggle_hover',
			[
				'label' => __( 'Scale', 'wakoo' ),
				'type' => Controls_Manager::POPOVER_TOGGLE,
				'return_value' => 'yes',
				'condition' => [
					'wk_transform_fx' => 'yes',
				],
			]
		);

		$element->start_popover();

		$element->add_control(
			'wk_transform_fx_scale_mode_hover',
			[
				'label' => __( 'Mode', 'wakoo' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'compact' => [
						'title' => __( 'Compact', 'wakoo' ),
						'icon' => 'eicon-plus-circle',
					],
					'loose' => [
						'title' => __( 'Loose', 'wakoo' ),
						'icon' => 'eicon-minus-circle',
					],
				],
				'default' => 'loose',
				'toggle' => false
			]
		);

		$element->add_control(
			'wk_transform_fx_scale_hr_hover',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$element->add_responsive_control(
			'wk_transform_fx_scale_x_hover',
			[
				'label' => __( 'Scale (X)', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'default' => [
					'size' => 1
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 5,
						'step' => .1
					]
				],
				'condition' => [
					'wk_transform_fx_scale_toggle_hover' => 'yes',
					'wk_transform_fx' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-scale-x-hover: {{SIZE}}; --wk-tfx-scale-y-hover: {{SIZE}};'
				],
			]
		);

		$element->add_responsive_control(
			'wk_transform_fx_scale_y_hover',
			[
				'label' => __( 'Scale Y', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'default' => [
					'size' => 1
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 5,
						'step' => .1
					]
				],
				'condition' => [
					'wk_transform_fx_scale_toggle_hover' => 'yes',
					'wk_transform_fx' => 'yes',
					'wk_transform_fx_scale_mode_hover' => 'loose',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-scale-y-hover: {{SIZE}};'
				],
			]
		);

		$element->end_popover();

		$element->add_control(
			'wk_transform_fx_skew_toggle_hover',
			[
				'label' => __( 'Skew', 'wakoo' ),
				'type' => Controls_Manager::POPOVER_TOGGLE,
				'return_value' => 'yes',
				'condition' => [
					'wk_transform_fx' => 'yes',
				],
			]
		);

		$element->start_popover();

		$element->add_responsive_control(
			'wk_transform_fx_skew_x_hover',
			[
				'label' => __( 'Skew X', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['deg'],
				'range' => [
					'px' => [
						'min' => -180,
						'max' => 180,
					]
				],
				'condition' => [
					'wk_transform_fx_skew_toggle_hover' => 'yes',
					'wk_transform_fx' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-skew-x-hover: {{SIZE}}deg;'
				],
			]
		);

		$element->add_responsive_control(
			'wk_transform_fx_skew_y_hover',
			[
				'label' => __( 'Skew Y', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['deg'],
				'range' => [
					'px' => [
						'min' => -180,
						'max' => 180,
					]
				],
				'condition' => [
					'wk_transform_fx_skew_toggle_hover' => 'yes',
					'wk_transform_fx' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-skew-y-hover: {{SIZE}}deg;'
				],
			]
		);

		$element->end_popover();

		$element->add_control(
			'wk_transform_fx_transition_duration',
			[
				'label' => __( 'Transition Duration', 'wakoo' ),
				'type' => Controls_Manager::SLIDER,
				'separator' => 'before',
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 3,
						'step' => .1,
					]
				],
				'condition' => [
					'wk_transform_fx' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--wk-tfx-transition-duration: {{SIZE}}s;'
				],
			]
		);

		$element->end_controls_tab();

		$element->end_controls_tabs();

		$element->end_controls_section();
	}
}
