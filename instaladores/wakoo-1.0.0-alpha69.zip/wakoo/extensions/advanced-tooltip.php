<?php

namespace Wakoo\Elementor\Extensions;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Border;

defined('ABSPATH') || die();

class Advanced_Tooltip {

	private static $instance = null;

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		 return self::$instance;
	}

    public static function enqueue_preview_scripts() {
		wp_enqueue_script('wakoo-advanced-tooltip');
    }

    /**
     * Set should_script_enqueue based extension settings
     *
     * @param Element_Base $section
     * @return void
     */
    public static function register_scripts() {
		$suffix = wk_is_script_debug_enabled() ? '.' : '.min.';
		// Advanced Tooltip
		wp_register_script(
			'wakoo-advanced-tooltip',
			WAKOO_ASSETS . 'js/extension-advanced-tooltip' . $suffix . 'js',
			[ 'jquery' ],
			WAKOO_VERSION,
			true
		);
    }

    public static function add_controls_section($element) {

        $element->start_controls_section(
            '_section_wk_advanced_tooltip',
            [
                'label' => __('Wakoo Tooltip', 'wakoo') . wk_get_section_icon(),
                'tab'   => Controls_Manager::TAB_ADVANCED,
            ]
        );

        $element->add_control(
            'wk_advanced_tooltip_enable',
            [
                'label'       => __('Enable Wakoo Tooltip?', 'wakoo'),
                'type'        => Controls_Manager::SWITCHER,
                'label_on' => __('On', 'wakoo'),
                'label_off' => __('Off', 'wakoo'),
                'return_value' => 'enable',
                'prefix_class' => 'wk-advanced-tooltip-',
                'default' => '',
				'assets' => [
					'scripts' => [
						[
							'name' => 'wakoo-advanced-tooltip',
							'conditions' => [
								'terms' => [
									[
										'name' => 'wk_advanced_tooltip_enable',
										'operator' => '===',
										'value' => 'enable',
									],
								],
							],
						]
					],
				],
                'frontend_available' => true,
            ]
        );

        $element->start_controls_tabs('wk_tooltip_tabs');

        $element->start_controls_tab('wk_tooltip_settings', [
            'label' => __('Settings', 'wakoo'),
            'condition' => [
                'wk_advanced_tooltip_enable!' => '',
            ],
        ]);

        $element->add_control(
            'wk_advanced_tooltip_content',
            [
                'label' => __('Content', 'wakoo'),
                'type'      => Controls_Manager::TEXTAREA,
                'description' => wk_get_allowed_html_desc('intermediate'),
                'rows' => 5,
                'default' => __('I am a tooltip', 'wakoo'),
                'dynamic' => ['active' => true],
                'frontend_available' => true,
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                ],
            ]
        );

        $element->add_responsive_control(
            'wk_advanced_tooltip_position',
            [
                'label' => __('Position', 'wakoo'),
                'type' => Controls_Manager::SELECT,
                'default' => 'top',
                'options' => [
                    'top' => __('Top', 'wakoo'),
                    'bottom' => __('Bottom', 'wakoo'),
                    'left' => __('Left', 'wakoo'),
                    'right' => __('Right', 'wakoo'),
                ],
                'frontend_available' => true,
                'prefix_class' => 'wk-advanced-tooltip%s-',
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                ],
            ]
        );

        $element->add_control(
            'wk_advanced_tooltip_animation',
            [
                'label' => __('Animation', 'wakoo'),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => __('None', 'wakoo'),
                    'wk_fadeIn' => __('fadeIn', 'wakoo'),
                    'wk_zoomIn' => __('zoomIn', 'wakoo'),
                    'wk_rollIn' => __('rollIn', 'wakoo'),
                    'wk_bounce' => __('bounce', 'wakoo'),
                    'wk_slideInDown' => __('slideInDown', 'wakoo'),
                    'wk_slideInLeft' => __('slideInLeft', 'wakoo'),
                    'wk_slideInRight' => __('slideInRight', 'wakoo'),
                    'wk_slideInUp' => __('slideInUp', 'wakoo'),
                ],
                'frontend_available' => true,
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                ],
            ]
        );

        $element->add_control(
            'wk_advanced_tooltip_duration',
            [
                'label' => __('Animation Duration (ms)', 'wakoo'),
                'type' => Controls_Manager::NUMBER,
                'min' => 100,
                'max' => 5000,
                'step' => 50,
                'default' => 1000,
                'frontend_available' => true,
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                ],
            ]
        );

        $element->add_control(
            'wk_advanced_tooltip_arrow',
            [
                'label' => __('Arrow', 'wakoo'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'wakoo'),
                'label_off' => __('Hide', 'wakoo'),
                'return_value' => 'true',
                'default' => 'true',
                'frontend_available' => true,
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                ],
            ]
        );


        $element->add_control(
            'wk_advanced_tooltip_arrow_notice',
            [
                'raw' => '<strong>' . esc_html__('Please note!', 'wakoo') . '</strong> ' . esc_html__('By toggling Arrow to "HIDE" you get access to more background control.', 'wakoo'),
                'type' => Controls_Manager::RAW_HTML,
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
                'render_type' => 'ui',
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                    'wk_advanced_tooltip_arrow' => 'true',
                ],
            ]
        );

        $element->add_control(
            'wk_advanced_tooltip_trigger',
            [
                'label' => __('Trigger', 'wakoo'),
                'type' => Controls_Manager::SELECT,
                'default' => 'hover',
                'options' => [
                    'click' => __('Click', 'wakoo'),
                    'hover' => __('Hover', 'wakoo'),
                ],
                'frontend_available' => true,
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                ],
            ]
        );

        $element->add_responsive_control(
            'wk_advanced_tooltip_distance',
            [
                'label' => __('Distance', 'wakoo'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => '0',
                ],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}.wk-advanced-tooltip-enable .wk-advanced-tooltip-content' => '--wk-tooltip-arrow-distance: {{SIZE}}{{UNIT}};',
                    // '{{WRAPPER}}.wk-advanced-tooltip-enable .wk-advanced-tooltip-content' => '--wk-tooltip-arrow-distance: {{SIZE}}{{UNIT}};',
                    // '{{WRAPPER}}.wk-advanced-tooltip-enable .wk-advanced-tooltip-content' => '--wk-tooltip-arrow-distance: {{SIZE}}{{UNIT}};',
                    // '{{WRAPPER}}.wk-advanced-tooltip-enable .wk-advanced-tooltip-content' => '--wk-tooltip-arrow-distance: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                ],
            ]
        );

        $element->add_responsive_control(
            'wk_advanced_tooltip_align',
            [
                'label' => __('Text Alignment', 'wakoo'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'wakoo'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'wakoo'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'wakoo'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .wk-advanced-tooltip-content' => 'text-align: {{VALUE}};'
                ],
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                ],
            ]
        );

        $element->end_controls_tab();

        $element->start_controls_tab('wk_advanced_tooltip_styles', [
            'label' => __('Styles', 'wakoo'),
            'condition' => [
                'wk_advanced_tooltip_enable!' => '',
            ],
        ]);

        $element->add_responsive_control(
            'wk_advanced_tooltip_width',
            [
                'label' => __('Width', 'wakoo'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => '120',
                ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 800,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wk-advanced-tooltip-content' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                ],
            ]
        );

        $element->add_responsive_control(
            'wk_advanced_tooltip_arrow_size',
            [
                'label' => __('Tooltip Arrow Size (px)', 'wakoo'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => '5',
                ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wk-advanced-tooltip-content::after' => 'border-width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                    'wk_advanced_tooltip_arrow' => 'true',
                ],
            ]
        );

        $element->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'wk_advanced_tooltip_typography',
                'separator' => 'after',
                'fields_options' => [
                    'typography' => [
                        'default' => 'yes'
                    ],
                    'font_family' => [
                        'default' => 'Nunito',
                    ],
                    'font_weight' => [
                        'default' => '500', // 100, 200, 300, 400, 500, 600, 700, 800, 900, normal, bold
                    ],
                    'font_size' => [
                        'default' => [
                            'unit' => 'px', // px, em, rem, vh
                            'size' => '14', // any number
                        ],
                    ],
                ],
                'selector' => '{{WRAPPER}} .wk-advanced-tooltip-content',
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                ],
            ]
        );

        $element->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'wk_advanced_tooltip_title_section_bg_color',
                'label'    => __('Background', 'wakoo'),
                'types'    => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .wk-advanced-tooltip-content',
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                    'wk_advanced_tooltip_arrow!' => 'true',
                ],
            ]
        );

        $element->add_control(
            'wk_advanced_tooltip_background_color',
            [
                'label' => __('Background Color', 'wakoo'),
                'type' => Controls_Manager::COLOR,
                'default' => '#000000',
                'selectors' => [
                    '{{WRAPPER}} .wk-advanced-tooltip-content' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .wk-advanced-tooltip-content::after' => '--wk-tooltip-arrow-color: {{VALUE}}',
                ],
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                    'wk_advanced_tooltip_arrow' => 'true',
                ],
            ]
        );

        $element->add_control(
            'wk_advanced_tooltip_color',
            [
                'label' => __('Text Color', 'wakoo'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .wk-advanced-tooltip-content' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                ],
            ]
        );

        $element->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'wk_advanced_tooltip_border',
                'label' => __('Border', 'wakoo'),
                'selector' => '{{WRAPPER}} .wk-advanced-tooltip-content',
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                    'wk_advanced_tooltip_arrow!' => 'true',
                ],
            ]
        );

        $element->add_responsive_control(
            'wk_advanced_tooltip_border_radius',
            [
                'label' => __('Border Radius', 'wakoo'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .wk-advanced-tooltip-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                ],
            ]
        );

        $element->add_responsive_control(
            'wk_advanced_tooltip_padding',
            [
                'label' => __('Padding', 'wakoo'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .wk-advanced-tooltip-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                ],
            ]
        );

        $element->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'wk_advanced_tooltip_box_shadow',
                'selector' => '{{WRAPPER}} .wk-advanced-tooltip-content',
                'separator' => '',
                'condition' => [
                    'wk_advanced_tooltip_enable!' => '',
                ],
            ]
        );

        $element->end_controls_tab();

        $element->end_controls_tabs();

        $element->end_controls_section();
    }
}
