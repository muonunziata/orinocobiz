<?php
/**
 * Image Stack Group integration
 */
namespace Wakoo\Elementor\Wpml;

defined( 'ABSPATH' ) || die();

class Image_Stack_Group_Images extends \WPML_Elementor_Module_With_Items  {

	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'images';
	}

	/**
	 * @return array
	 */
	public function get_fields() {
		return [
			'tooltip',
			'link' => ['url'],
		];
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_title( $field ) {
		switch ( $field ) {
			case 'tooltip':
				return __( 'Image Stack Group: Tooltip', 'wakoo' );
			case 'url':
				return __( 'Image Stack Group: Link', 'wakoo' );
			default:
				return '';
		}
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'tooltip':
				return 'LINE';
			case 'url':
				return 'LINK';
			default:
				return '';
		}
	}
}
