<?php
/**
 * Image Accordion integration
 */
namespace Wakoo\Elementor\Wpml;

defined( 'ABSPATH' ) || die();
use Wakoo\Elementor\Classes\WPML_Module_With_Items;
class Image_Accordion extends WPML_Module_With_Items  {

	/**
	 * @return string
	 */
	public function get_items_field() {
		return 'accordion_items';
	}

	/**
	 * @return array
	 */
	public function get_fields() {
		return [
			'label',
			'title',
			'description',
			'button_label',
			'button_url' => ['url'],
			'link_url' => ['url'],
		];
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_title( $field ) {
		switch ( $field ) {
			case 'label':
				return __( 'Image Accordion: Label', 'wakoo' );
			case 'title':
				return __( 'Image Accordion: Title', 'wakoo' );
			case 'description':
				return __( 'Image Accordion: Description', 'wakoo' );
			case 'button_label':
				return __( 'Image Accordion: Button Label', 'wakoo' );
			case 'button_url':
				return __( 'Image Accordion: Button URL', 'wakoo' );
			case 'link_url':
				return __( 'Image Accordion: Link URL', 'wakoo' );
			default:
				return '';
		}
	}

	/**
	 * @param string $field
	 *
	 * @return string
	 */
	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'label':
				return 'LINE';
			case 'title':
				return 'AREA';
			case 'description':
				return 'AREA';
			case 'button_label':
				return 'LINE';
			case 'button_url':
				return 'LINK';
			case 'link_url':
				return 'LINK';
			default:
				return '';
		}
	}
}
