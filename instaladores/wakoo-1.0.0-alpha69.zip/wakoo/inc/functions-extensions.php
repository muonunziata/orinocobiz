<?php

/**
 * Filters function defination
 *
 * @package Wakoo
 * @since 2.13.0
 * @author Leevio
 *
 */
defined('ABSPATH') || die();

if (! function_exists('wk_is_adminbar_menu_enabled')) {
	/**
	 * Check if Adminbar is enabled
	 *
	 * @return bool
	 */
	function wk_is_adminbar_menu_enabled() {
		return apply_filters('wakoo/extensions/adminbar_menu', true);
	}
}

if (! function_exists('wk_is_background_overlay_enabled')) {
	/**
	 * Check if Background Overlay is enabled
	 *
	 * @return bool
	 */
	function wk_is_background_overlay_enabled() {
		return apply_filters('wakoo/extensions/background_overlay', true);
	}
}

if (! function_exists('wk_is_css_transform_enabled')) {
	/**
	 * Check if CSS Transform is enabled
	 *
	 * @return bool
	 */
	function wk_is_css_transform_enabled() {
		return apply_filters('wakoo/extensions/css_transform', true);
	}
}

if (! function_exists('wk_is_floating_effects_enabled')) {
	/**
	 * Check if Floating Effects is enabled
	 *
	 * @return bool
	 */
	function wk_is_floating_effects_enabled() {
		return apply_filters('wakoo/extensions/floating_effects', true);
	}
}

if (! function_exists('wk_is_grid_layer_enabled')) {
	/**
	 * Check if Grid Layer is enabled
	 *
	 * @return bool
	 */
	function wk_is_grid_layer_enabled() {
		return apply_filters('wakoo/extensions/grid_layer', true);
	}
}

if (! function_exists('wk_is_wrapper_link_enabled')) {
	/**
	 * Check if Wrapper Link is enabled
	 *
	 * @return bool
	 */
	function wk_is_wrapper_link_enabled() {
		return apply_filters('wakoo/extensions/wrapper_link', true);
	}
}

if (! function_exists('wk_is_happy_clone_enabled')) {
	/**
	 * Check if Wakoo Clone is enabled
	 *
	 * @return bool
	 */
	function wk_is_happy_clone_enabled() {
		return apply_filters('wakoo/extensions/wakoo_clone', true);
	}
}

if (! function_exists('wk_is_on_demand_cache_enabled')) {
	/**
	 * Check if On Demand Cache is enabled
	 *
	 * @return bool
	 */
	function wk_is_on_demand_cache_enabled() {
		return apply_filters('wakoo/extensions/on_demand_cache', true);
	}
}

if (! function_exists('wk_is_equal_height_enabled')) {
	/**
	 * Check if equal height is enabled
	 *
	 * @return bool
	 */
	function wk_is_equal_height_enabled() {
		return apply_filters('wakoo/extensions/equal_height', true);
	}
}


if (! function_exists('wk_is_shape_divider_enabled')) {
	/**
	 * Check if Wakoo Shape Divider is enabled
	 *
	 * @return bool
	 */
	function wk_is_shape_divider_enabled() {
		return apply_filters('wakoo/extensions/shape_divider', true);
	}
}

if (! function_exists('wk_is_liquid_glass_enabled')) {
	/**
	 * Check if Liquid Glass is enabled
	 *
	 * @return bool
	 */
	function wk_is_liquid_glass_enabled() {
		return apply_filters( 'wakoo/extensions/liquid_glass', true );
	}
}

if (! function_exists('wk_is_background_hover_effect_enabled')) {
	/**
	 * Check if Background Hover Effect is enabled
	 *
	 * @return bool
	 */
	function wk_is_background_hover_effect_enabled() {
		return apply_filters( 'wakoo/extensions/background_hover_effect', true );
	}
}

if (! function_exists('wk_is_foreground_overlay_enabled')) {
	/**
	 * Check if Foreground Overlay is enabled
	 *
	 * @return bool
	 */
	function wk_is_foreground_overlay_enabled() {
		return apply_filters( 'wakoo/extensions/foreground_overlay', true );
	}
}

if (! function_exists('wk_is_button_fixed_size_enabled')) {
	/**
	 * Check if Button Fixed Size is enabled
	 *
	 * @return bool
	 */
	function wk_is_button_fixed_size_enabled() {
		return apply_filters( 'wakoo/extensions/button_fixed_size', true );
	}
}

if (! function_exists('wk_is_widget_background_overlay_enabled')) {
	/**
	 * Check if Widget Background Overlay is enabled
	 *
	 * @return bool
	 */
	function wk_is_widget_background_overlay_enabled() {
		return apply_filters( 'wakoo/extensions/widget_background_overlay', true );
	}
}

if (! function_exists('wk_is_text_stroke_enabled')) {
	/**
	 * Check if Text Stroke is enabled
	 *
	 * @return bool
	 */
	function wk_is_text_stroke_enabled() {
		return apply_filters( 'wakoo/extensions/text_stroke', true );
	}
}

if (! function_exists('wk_is_scroll_flow_enabled')) {
	/**
	 * Check if Scroll Flow is enabled
	 *
	 * @return bool
	 */
	function wk_is_scroll_flow_enabled() {
		return apply_filters( 'wakoo/extensions/scroll_flow', true );
	}
}
