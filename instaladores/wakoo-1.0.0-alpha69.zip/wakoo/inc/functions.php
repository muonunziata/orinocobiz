<?php

/**
 * Helper functions
 *
 * @package Wakoo
 */
defined('ABSPATH') || die();

/**
 * Call a shortcode function by tag name.
 *
 * @since  1.0.0
 *
 * @param string $tag     The shortcode whose function to call.
 * @param array  $atts    The attributes to pass to the shortcode function. Optional.
 * @param array  $content The shortcode's content. Default is null (none).
 *
 * @return string|bool False on failure, the result of the shortcode on success.
 */
function wk_do_shortcode($tag, array $atts = [], $content = null) {
	global $shortcode_tags;
	if (!isset($shortcode_tags[$tag])) {
		return false;
	}
	return call_user_func($shortcode_tags[$tag], $atts, $content, $tag);
}

/**
 * Sanitize html class string
 *
 * @param $class
 * @return string
 */
function wk_sanitize_html_class_param($class) {
	$classes   = !empty($class) ? explode(' ', $class) : [];
	$sanitized = [];
	if (!empty($classes)) {
		$sanitized = array_map(function ($cls) {
			return sanitize_html_class($cls);
		}, $classes);
	}
	return implode(' ', $sanitized);
}

function wk_is_script_debug_enabled() {
	return (defined('SCRIPT_DEBUG') && SCRIPT_DEBUG);
}

/**
 * @param $settings
 * @param array $field_map
 */

function wk_prepare_data_prop_settings(&$settings, $field_map = []) {
	$data = [];
	foreach ($field_map as $key => $data_key) {
		$setting_value                          = wk_get_setting_value($settings, $key);
		list($data_field_key, $data_field_type) = explode('.', $data_key);
		$validator                              = $data_field_type . 'val';

		if (is_callable($validator)) {
			$val = call_user_func($validator, $setting_value);
		} else {
			$val = $setting_value;
		}
		$data[$data_field_key] = $val;
	}
	return wp_json_encode($data);
}

/**
 * @param $settings
 * @param $keys
 * @return mixed
 */
function wk_get_setting_value(&$settings, $keys) {
	if (!is_array($keys)) {
		$keys = explode('.', $keys);
	}
	if (is_array($settings[$keys[0]])) {
		return wk_get_setting_value($settings[$keys[0]], array_slice($keys, 1));
	}
	return $settings[$keys[0]];
}

function wk_is_localhost() {
	return isset($_SERVER['REMOTE_ADDR']) && in_array($_SERVER['REMOTE_ADDR'], ['127.0.0.1', '::1']);
}

function wk_get_css_cursors() {
	return [
		'default'      => __('Default', 'wakoo'),
		'alias'        => __('Alias', 'wakoo'),
		'all-scroll'   => __('All scroll', 'wakoo'),
		'auto'         => __('Auto', 'wakoo'),
		'cell'         => __('Cell', 'wakoo'),
		'context-menu' => __('Context menu', 'wakoo'),
		'col-resize'   => __('Col-resize', 'wakoo'),
		'copy'         => __('Copy', 'wakoo'),
		'crosshair'    => __('Crosshair', 'wakoo'),
		'e-resize'     => __('E-resize', 'wakoo'),
		'ew-resize'    => __('EW-resize', 'wakoo'),
		'grab'         => __('Grab', 'wakoo'),
		'grabbing'     => __('Grabbing', 'wakoo'),
		'help'         => __('Help', 'wakoo'),
		'move'         => __('Move', 'wakoo'),
		'n-resize'     => __('N-resize', 'wakoo'),
		'ne-resize'    => __('NE-resize', 'wakoo'),
		'nesw-resize'  => __('NESW-resize', 'wakoo'),
		'ns-resize'    => __('NS-resize', 'wakoo'),
		'nw-resize'    => __('NW-resize', 'wakoo'),
		'nwse-resize'  => __('NWSE-resize', 'wakoo'),
		'no-drop'      => __('No-drop', 'wakoo'),
		'not-allowed'  => __('Not-allowed', 'wakoo'),
		'pointer'      => __('Pointer', 'wakoo'),
		'progress'     => __('Progress', 'wakoo'),
		'row-resize'   => __('Row-resize', 'wakoo'),
		's-resize'     => __('S-resize', 'wakoo'),
		'se-resize'    => __('SE-resize', 'wakoo'),
		'sw-resize'    => __('SW-resize', 'wakoo'),
		'text'         => __('Text', 'wakoo'),
		'url'          => __('URL', 'wakoo'),
		'w-resize'     => __('W-resize', 'wakoo'),
		'wait'         => __('Wait', 'wakoo'),
		'zoom-in'      => __('Zoom-in', 'wakoo'),
		'zoom-out'     => __('Zoom-out', 'wakoo'),
		'none'         => __('None', 'wakoo'),
	];
}

function wk_get_css_blend_modes() {
	return [
		'normal'      => __('Normal', 'wakoo'),
		'multiply'    => __('Multiply', 'wakoo'),
		'screen'      => __('Screen', 'wakoo'),
		'overlay'     => __('Overlay', 'wakoo'),
		'darken'      => __('Darken', 'wakoo'),
		'lighten'     => __('Lighten', 'wakoo'),
		'color-dodge' => __('Color Dodge', 'wakoo'),
		'color-burn'  => __('Color Burn', 'wakoo'),
		'saturation'  => __('Saturation', 'wakoo'),
		'difference'  => __('Difference', 'wakoo'),
		'exclusion'   => __('Exclusion', 'wakoo'),
		'hue'         => __('Hue', 'wakoo'),
		'color'       => __('Color', 'wakoo'),
		'luminosity'  => __('Luminosity', 'wakoo'),
	];
}

/**
 * Check elementor version
 *
 * @param string $version
 * @param string $operator
 * @return bool
 */
function wk_is_elementor_version($operator = '<', $version = '2.6.0') {
	return defined('ELEMENTOR_VERSION') && version_compare(ELEMENTOR_VERSION, $version, $operator);
}

/**
 * Render icon html with backward compatibility
 *
 * @param array $settings
 * @param string $old_icon_id
 * @param string $new_icon_id
 * @param array $attributes
 */
/**
 * @param array $settings
 * @param $old_icon_id
 * @param $new_icon_id
 * @param array $attributes
 */
function wk_render_icon( $settings = [], $old_icon_id = 'icon', $new_icon_id = 'selected_icon', $attributes = [] ) {
    // Function is modified by tanvir jonny to support wakoo-icons and wakoo-icons-svg library
    // Check if its already migrated
    $migrated = isset( $settings['__fa4_migrated'][$new_icon_id] );
    // Check if its a new widget without previously selected icon using the old Icon control
	$old_icon_id = is_string($old_icon_id) ? $old_icon_id : '';
	$is_new = empty($old_icon_id) || empty($settings[$old_icon_id] ?? '');
    if ( isset( $settings[$new_icon_id]['value'] ) && is_string( $settings[$new_icon_id]['value'] ) ) {
        if ( preg_match( '/\bhm-[\w-]+/', $settings[$new_icon_id]['value'] ) ) {
            if ( $settings[$new_icon_id]['library'] !== "wakoo-icons" ) {
                $settings[$new_icon_id]['library'] = "wakoo-icons";
            }
        }
    }

    if ( wk_is_elementor_version( '>=', '2.6.0' ) && ( $is_new || $migrated ) ) {
        \Elementor\Icons_Manager::render_icon( $settings[$new_icon_id], $attributes );

    } else {
        if ( empty( $attributes['class'] ) ) {
            $attributes['class'] = $settings[$old_icon_id];
        } else {
            if ( is_array( $attributes['class'] ) ) {
                $attributes['class'][] = $settings[$old_icon_id];
            } else {
                $attributes['class'] .= ' ' . $settings[$old_icon_id];
            }
        }

        printf( '<i %s></i>', \Elementor\Utils::render_html_attributes( $attributes ) );
    }
}

/**
 * List of wakoo icons
 *
 * @return array
 */
function wk_get_happy_icons() {
	return \Wakoo\Elementor\Classes\Icons_Manager::get_happy_icons();
}

/**
 * Get elementor instance
 *
 * @return \Elementor\Plugin
 */
function wk_elementor() {
	return \Elementor\Plugin::instance();
}

/**
 * Escaped title html tags
 *
 * @param string $tag input string of title tag
 * @return string $default default tag will be return during no matches
 */

function wk_escape_tags($tag, $default = 'span', $extra = []) {

	$supports = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'div', 'span', 'p'];

	$supports = array_merge($supports, $extra);

	if (!in_array($tag, $supports, true)) {
		return $default;
	}

	return $tag;
}

/**
 * Get a list of all the allowed html tags.
 *
 * @param string $level Allowed levels are basic and intermediate
 * @return array
 */
function wk_get_allowed_html_tags($level = 'basic') {
	$allowed_html = [
		'b'      => [
			'class' => [],
			'id'    => [],
			'style' => [],
		],
		'i'      => [
			'class' => [],
			'id'    => [],
			'style' => [],
		],
		'u'      => [
			'class' => [],
			'id'    => [],
			'style' => [],
		],
		's'      => [
			'class' => [],
			'id'    => [],
			'style' => [],
		],
		'br'     => [
			'class' => [],
			'id'    => [],
			'style' => [],
		],
		'em'     => [
			'class' => [],
			'id'    => [],
			'style' => [],
		],
		'del'    => [
			'class' => [],
			'id'    => [],
			'style' => [],
		],
		'ins'    => [
			'class' => [],
			'id'    => [],
			'style' => [],
		],
		'sub'    => [
			'class' => [],
			'id'    => [],
			'style' => [],
		],
		'sup'    => [
			'class' => [],
			'id'    => [],
			'style' => [],
		],
		'code'   => [
			'class' => [],
			'id'    => [],
			'style' => [],
		],
		'mark'   => [
			'class' => [],
			'id'    => [],
			'style' => [],
		],
		'small'  => [
			'class' => [],
			'id'    => [],
			'style' => [],
		],
		'strike' => [
			'class' => [],
			'id'    => [],
			'style' => [],
		],
		'abbr'   => [
			'title' => [],
			'class' => [],
			'id'    => [],
			'style' => [],
		],
		'span'   => [
			'class' => [],
			'id'    => [],
			'style' => [],
		],
		'strong' => [
			'class' => [],
			'id'    => [],
			'style' => [],
		],
	];

	if ('intermediate' === $level || 'all' === $level) {
		$tags = [
			'a'       => [
				'href'  => [],
				'title' => [],
				'class' => [],
				'id'    => [],
				'style' => [],
			],
			'q'       => [
				'cite'  => [],
				'class' => [],
				'id'    => [],
				'style' => [],
			],
			'img'     => [
				'src'    => [],
				'alt'    => [],
				'height' => [],
				'width'  => [],
				'class'  => [],
				'id'     => [],
				'style'  => [],
			],
			'dfn'     => [
				'title' => [],
				'class' => [],
				'id'    => [],
				'style' => [],
			],
			'time'    => [
				'datetime' => [],
				'class'    => [],
				'id'       => [],
				'style'    => [],
			],
			'cite'    => [
				'title' => [],
				'class' => [],
				'id'    => [],
				'style' => [],
			],
			'acronym' => [
				'title' => [],
				'class' => [],
				'id'    => [],
				'style' => [],
			],
			'hr'      => [
				'class' => [],
				'id'    => [],
				'style' => [],
			],
		];

		$allowed_html = array_merge($allowed_html, $tags);
	}

	return $allowed_html;
}

/**
 * Strip all the tags except allowed html tags
 *
 * The name is based on inline editing toolbar name
 *
 * @param string $string
 * @return string
 */
function wk_kses_intermediate($string = '') {
	return wp_kses($string, wk_get_allowed_html_tags('intermediate'));
}

/**
 * Strip all the tags except allowed html tags
 *
 * The name is based on inline editing toolbar name
 *
 * @param string $string
 * @return string
 */
function wk_kses_basic($string = '') {
	return wp_kses($string, wk_get_allowed_html_tags('basic'));
}

/**
 * Get a translatable string with allowed html tags.
 *
 * @param string $level Allowed levels are basic and intermediate
 * @return string
 */
function wk_get_allowed_html_desc($level = 'basic') {
	if (!in_array($level, ['basic', 'intermediate'])) {
		$level = 'basic';
	}

	$tags_str = '<' . implode('>,<', array_keys(wk_get_allowed_html_tags($level))) . '>';
	return sprintf(__('This input field has support for the following HTML tags: %1$s', 'wakoo'), '<code>' . esc_html($tags_str) . '</code>');
}

function wk_has_pro() {
	return defined('WAKOO_PRO_VERSION');
}

/**
 * Safely apply filters by swallowing errors thrown by broken callbacks
 * (e.g. pro plugin is active but its code is missing or outdated),
 * so the page never turns blank because of a dead callback.
 *
 * @param string $tag
 * @param mixed ...$args
 * @return mixed
 */
function wk_safe_apply_filters( $tag, ...$args ) {
	try {
		return apply_filters( $tag, ...$args );
	} catch ( \Throwable $e ) {
		error_log( sprintf( '[Wakoo] Filter "%s" failed: %s in %s:%d', $tag, $e->getMessage(), $e->getFile(), $e->getLine() ) );
		return isset( $args[0] ) ? $args[0] : null;
	}
}

/**
 * Safely do action by swallowing errors thrown by broken callbacks
 *
 * @param string $tag
 * @param mixed ...$args
 * @return void
 */
function wk_safe_do_action( $tag, ...$args ) {
	try {
		do_action( $tag, ...$args );
	} catch ( \Throwable $e ) {
		error_log( sprintf( '[Wakoo] Action "%s" failed: %s in %s:%d', $tag, $e->getMessage(), $e->getFile(), $e->getLine() ) );
	}
}

function wk_get_b64_icon() {
	// Plain WordPress dashicon: no image, so it never overlaps other menu items.
	return 'dashicons-layout';
}

/**
 * @param $suffix
 */
function wk_get_dashboard_link($suffix = '#home') {
	return add_query_arg(['page' => 'wakoo' . $suffix], admin_url('admin.php'));
}

/**
 * @param $suffix
 */
function wk_get_setup_wizard_link() {
	return add_query_arg(['page' => 'wakoo-setup-wizard'], admin_url('admin.php'));
}

/**
 * @return mixed
 */
function wk_get_current_user_display_name() {
	$user = wp_get_current_user();
	$name = 'user';
	if ($user->exists() && $user->display_name) {
		$name = $user->display_name;
	}
	return $name;
}

/**
 * Get All Post Types
 * @param array $args
 * @param array $diff_key
 * @return array|string[]|WP_Post_Type[]
 */
function wk_get_post_types($args = [], $diff_key = []) {
	$default = [
		'public'            => true,
		'show_in_nav_menus' => true,
	];
	$args       = array_merge($default, $args);
	$post_types = get_post_types($args, 'objects');
	$post_types = wp_list_pluck($post_types, 'label', 'name');

	if (!empty($diff_key)) {
		$post_types = array_diff_key($post_types, $diff_key);
	}
	return $post_types;
}

/**
 * Get All Taxonomies
 * @param array $args
 * @param string $output
 * @param bool $list
 * @param array $diff_key
 * @return array|string[]|WP_Taxonomy[]
 */
function wk_get_taxonomies($args = [], $output = 'object', $list = true, $diff_key = []) {

	$taxonomies = get_taxonomies($args, $output);
	if ('object' === $output && $list) {
		$taxonomies = wp_list_pluck($taxonomies, 'label', 'name');
	}

	if (!empty($diff_key)) {
		$taxonomies = array_diff_key($taxonomies, $diff_key);
	}

	return $taxonomies;
}

if (!function_exists('wk_get_section_icon')) {
	/**
	 * Get wakoo addons icon for panel section heading
	 *
	 * @return string
	 */
	function wk_get_section_icon() {
		return '<i style="float: right" class="hm hm-wakoo wk-section-icon"></i>';
	}
}

/**
 * Render icon html with backward compatibility
 *
 * @param array $settings
 * @param string $old_icon_id
 * @param string $new_icon_id
 * @param array $attributes
 */
function wk_render_button_icon($settings = [], $old_icon_id = 'icon', $new_icon_id = 'selected_icon', $attributes = []) {
	// Check if its already migrated
	$migrated = isset($settings['__fa4_migrated'][$new_icon_id]);
	// Check if its a new widget without previously selected icon using the old Icon control
	$is_new = empty($settings[$old_icon_id]);

	$attributes['aria-hidden'] = 'true';
	$is_svg                    = (isset($settings[$new_icon_id], $settings[$new_icon_id]['library']) && 'svg' === $settings[$new_icon_id]['library']);

	if (wk_is_elementor_version('>=', '2.6.0') && ($is_new || $migrated)) {
		if ($is_svg) {
			echo '<span class="wk-btn-icon wk-btn-icon--svg">';
		}
		\Elementor\Icons_Manager::render_icon($settings[$new_icon_id], $attributes);
		if ($is_svg) {
			echo '</span>';
		}
	} else {
		if (empty($attributes['class'])) {
			$attributes['class'] = $settings[$old_icon_id];
		} else {
			if (is_array($attributes['class'])) {
				$attributes['class'][] = $settings[$old_icon_id];
			} else {
				$attributes['class'] .= ' ' . $settings[$old_icon_id];
			}
		}
		printf('<i %s></i>', \Elementor\Utils::render_html_attributes($attributes));
	}
}

/**
 * Get database settings of a widget by widget id and element
 *
 * @param array $elements
 * @param string $widget_id
 * @param array $value
 */

function wk_get_ele_widget_element_settings($elements, $widget_id) {

	if (is_array($elements)) {
		foreach ($elements as $d) {
			if ($d && !empty($d['id']) && $d['id'] == $widget_id) {
				return $d;
			}
			if ($d && !empty($d['elements']) && is_array($d['elements'])) {
				$value = wk_get_ele_widget_element_settings($d['elements'], $widget_id);
				if ($value) {
					return $value;
				}
			}
		}
	}

	return false;
}

/**
 * Get database settings of a widget by widget id and post id
 *
 * @param number $post_id
 * @param string $widget_id
 * @param array
 */

function wk_get_ele_widget_settings($post_id, $widget_id) {

	$elementor_data = @json_decode(get_post_meta($post_id, '_elementor_data', true), true);

	if ($elementor_data) {
		$element = wk_get_ele_widget_element_settings($elementor_data, $widget_id);
		return isset($element['settings']) ? $element['settings'] : '';
	}

	return false;
}

/**
 * get credentials function
 *
 * @param string $key
 *
 * @return void
 * @since 1.0.0
 */
function wk_get_credentials($key = '') {
	if (!class_exists('Wakoo\Elementor\Classes\Credentials_Manager')) {
		include_once(WAKOO_DIR_PATH . 'classes/credentials-manager.php');
	}
	$creds = \Wakoo\Elementor\Classes\Credentials_Manager::get_saved_credentials();
	if (!empty($key)) {
		return isset($creds[$key]) ? $creds[$key] : esc_html__('invalid key', 'wakoo');
	}
	return $creds;
}

/**
 * Get plugin missing notice
 *
 * @param string $plugin
 * @return void
 */
function wk_show_plugin_missing_alert($plugin) {
	if (current_user_can('activate_plugins') && $plugin) {
		printf(
			'<div %s>%s</div>',
			'style="margin: 1rem;padding: 1rem 1.25rem;border-left: 5px solid #f5c848;color: #856404;background-color: #fff3cd;"',
			$plugin . __(' is missing! Please install and activate ', 'wakoo') . $plugin . '.'
		);
	}
}

/**
 * Get inactive wakoo feature list
 *
 * @return array
 */
function wk_get_inactive_features() {
	return get_option('wakoo_inactive_features', []);
}

/**
 * Get inactive wakoo extension list
 *
 * @return array
 */
function wk_get_inactive_extensions() {
	return get_option('wakoo_inactive_extensions', []);
}

/**
 * Get post date link
 *
 * @param int $post_id
 * @return string
 */
function wk_get_date_link($post_id = null) {
	if (empty($post_id)) {
		$post_id = get_the_ID();
	}

	$year = get_the_date('Y', $post_id);
	$month = get_the_time('m', $post_id);
	$day = get_the_time('d', $post_id);
	$url = get_day_link($year, $month, $day);

	return $url;
}

/**
 * Get post excerpt by length
 *
 * @param integer $length
 * @return string
 */
function wk_get_excerpt($post_id = null, $length = 15) {
	if (empty($post_id)) {
		$post_id = get_the_ID();
	}

	return wp_trim_words(get_the_excerpt($post_id), $length);
}

function wk_sanitize_array_recursively($array) {

	foreach ($array as $key => &$value) {
		if (is_array($value)) {
			$value = wk_sanitize_array_recursively($value);
		} else {
			$value = sanitize_text_field($value);
		}
	}

	return $array;
}
