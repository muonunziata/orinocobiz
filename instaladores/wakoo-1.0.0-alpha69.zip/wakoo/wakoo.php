<?php

/**
 * Plugin Name: Wakoo
 * Description: Widgets, Theme Builder, popups, forms and design extensions for the Elementor editor.
 * Version: 1.0.0
 * Author: Wakoo
 * Text Domain: wakoo
 * Domain Path: /i18n/
 * Requires Plugins: elementor
 * Requires PHP: 8.1
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 *
 * Wakoo is a fork of Happy Elementor Addons 3.50.1 (Copyright 2019 Leevio, GPLv2 or later).
 */

/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Copyright 2019 Leevio <http://leevio.com>
*/

defined('ABSPATH') || die();


if ( defined( 'WAKOO_DEV' ) && true == WAKOO_DEV ) {
	define('WAKOO_VERSION', '1.0.0' . time() );
} else {
	define( 'WAKOO_VERSION', '1.0.0' );
}
define('WAKOO__FILE__', __FILE__);
define('WAKOO_DIR_PATH', plugin_dir_path(WAKOO__FILE__));
define('WAKOO_DIR_URL', plugin_dir_url(WAKOO__FILE__));
define('WAKOO_ASSETS', trailingslashit(WAKOO_DIR_URL . 'assets'));
define('WAKOO_REDIRECTION_FLAG', 'wakoo_do_activation_direct');
define('WAKOO_WIZARD_REDIRECTION_FLAG', 'wakoo_do_wizard_direct');

define('WAKOO_MINIMUM_ELEMENTOR_VERSION', '3.7.0');
define('WAKOO_MINIMUM_PHP_VERSION', '8.1');

/**
 * The journey of a thousand miles starts here.
 *
 * @return void Some voids are not really void, you have to explore to figure out why not!
 */
function wk_let_the_journey_begin() {
    require(WAKOO_DIR_PATH . 'inc/functions.php');
	include_once( WAKOO_DIR_PATH . 'inc/functions-extensions.php' );

    // Check for required PHP version
	if (version_compare(PHP_VERSION, WAKOO_MINIMUM_PHP_VERSION, '<')) {
		add_action('admin_notices', 'wk_required_php_version_missing_notice');
		return;
	}

    // Check if Elementor installed and activated
	if (!did_action('elementor/loaded')) {
		add_action('admin_notices', 'wk_elementor_missing_notice');
		return;
	}

    // Check for required Elementor version
	if (!version_compare(ELEMENTOR_VERSION, WAKOO_MINIMUM_ELEMENTOR_VERSION, '>=')) {
		add_action('admin_notices', 'wk_required_elementor_version_missing_notice');
		return;
	}

    require WAKOO_DIR_PATH . 'base.php';
    \Wakoo\Elementor\Base::instance()->init();
}

add_action('plugins_loaded', 'wk_let_the_journey_begin');

require_once WAKOO_DIR_PATH . 'modules/loader.php';

/**
 * Admin notice for required php version
 *
 * @return void
 */
function wk_required_php_version_missing_notice() {
    $notice = sprintf(
        /* translators: 1: Plugin name 2: PHP 3: Required PHP version */
        esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'wakoo'),
        '<strong>' . esc_html__('Wakoo', 'wakoo') . '</strong>',
        '<strong>' . esc_html__('PHP', 'wakoo') . '</strong>',
        WAKOO_MINIMUM_PHP_VERSION
    );

    printf('<div class="notice notice-warning is-dismissible"><p style="padding: 13px 0">%1$s</p></div>', $notice);
}

/**
 * Admin notice for elementor if missing
 *
 * @return void
 */
function wk_elementor_missing_notice() {

    if (file_exists(WP_PLUGIN_DIR . '/elementor/elementor.php')) {
        $notice_title = __('Activate Elementor', 'wakoo');
        $notice_url = wp_nonce_url('plugins.php?action=activate&plugin=elementor/elementor.php&plugin_status=all&paged=1', 'activate-plugin_elementor/elementor.php');
    } else {
        $notice_title = __('Install Elementor', 'wakoo');
        $notice_url = wp_nonce_url(self_admin_url('update.php?action=install-plugin&plugin=elementor'), 'install-plugin_elementor');
    }

    $notice = wk_kses_intermediate(sprintf(
        /* translators: 1: Plugin name 2: Elementor 3: Elementor installation link */
        __('%1$s requires %2$s to be installed and activated to function properly. %3$s', 'wakoo'),
        '<strong>' . __('Wakoo', 'wakoo') . '</strong>',
        '<strong>' . __('Elementor', 'wakoo') . '</strong>',
        '<a href="' . esc_url($notice_url) . '">' . $notice_title . '</a>'
    ));

    printf('<div class="notice notice-warning is-dismissible"><p style="padding: 13px 0">%1$s</p></div>', $notice);
}

/**
 * Admin notice for required elementor version
 *
 * @return void
 */
function wk_required_elementor_version_missing_notice() {

    $notice_title = __('Update Elementor', 'wakoo');
    $notice_url = wp_nonce_url(self_admin_url('update.php?action=upgrade-plugin&plugin=elementor/elementor.php'), 'upgrade-plugin_elementor/elementor.php');

    $notice = sprintf(
        /* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
        esc_html__('"%1$s" requires "%2$s" version %4$s or greater. %3$s', 'wakoo'),
        '<strong>' . esc_html__('Wakoo', 'wakoo') . '</strong>',
        '<strong>' . esc_html__('Elementor', 'wakoo') . '</strong>',
        '<a href="' . esc_url($notice_url) . '">' . $notice_title . '</a>',
        WAKOO_MINIMUM_ELEMENTOR_VERSION
    );

    printf('<div class="notice notice-warning is-dismissible"><p style="padding: 13px 0">%1$s</p></div>', $notice);
}

/**
 * Register actions that should run on activation
 *
 * @return void
 */
function wk_register_activation_hook() {
    add_option(WAKOO_REDIRECTION_FLAG, true);

    // add plugin activation time
    $get_activation_time = strtotime("now");
    add_option('wakoo_activation_time', $get_activation_time);

    if (!get_option(WAKOO_WIZARD_REDIRECTION_FLAG, false)) {
    }
}

register_activation_hook(WAKOO__FILE__, 'wk_register_activation_hook');
