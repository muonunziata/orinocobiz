<?php
/**
 * Dashboard manager
 *
 * Package: Wakoo
 * @since 2.0.0
 */
namespace Wakoo\Elementor\Classes;

defined( 'ABSPATH' ) || die();

class Dashboard {

    const PAGE_SLUG = 'wakoo';

    const WIZARD_PAGE_SLUG = 'wakoo-setup-wizard';

    const LICENSE_PAGE_SLUG = 'wakoo-license';

    const WIDGETS_NONCE = 'wk_save_dashboard';

    const WIZARD_NONCE = 'wp_rest';

    static $menu_slug = '';

    public static $catwise_widget_map = [];
    public static $catwise_free_widget_map = [];

    static $wizard_slug = '';

    public static function is_page() {
        return ( isset( $_GET['page'] ) && ( sanitize_text_field($_GET['page']) === self::PAGE_SLUG || sanitize_text_field($_GET['page']) === self::LICENSE_PAGE_SLUG ) );
    }

    public static function remove_all_notices() {
        if ( self::is_page() ) {
            remove_all_actions( 'admin_notices' );
            remove_all_actions( 'all_admin_notices' );
        }
    }

    public static function activation_redirect() {
        // Only for an admin opening a dashboard screen: never on admin-post.php (front forms) or AJAX.
        if ( wp_doing_ajax() || ( isset( $GLOBALS['pagenow'] ) && 'admin-post.php' === $GLOBALS['pagenow'] ) || ! current_user_can( 'manage_options' ) ) {
            return;
        }
        if ( get_option( WAKOO_REDIRECTION_FLAG, false ) ) {
			delete_option( WAKOO_REDIRECTION_FLAG );
			exit( esc_url( wp_safe_redirect( wk_get_dashboard_link() ) ) );
		}

		if ( get_option( WAKOO_WIZARD_REDIRECTION_FLAG, false ) == 'initiate' ) {
			update_option( WAKOO_WIZARD_REDIRECTION_FLAG, 'running' );
			exit( esc_url( wp_safe_redirect( wk_get_setup_wizard_link() ) ) );
		}
    }

    public static function add_action_links( $links ) {
        if ( ! current_user_can( 'manage_options' ) ) {
            return $links;
        }

        $links = array_merge( [
            sprintf( '<a href="%s">%s</a>',
                wk_get_dashboard_link(),
                esc_html__( 'Settings', 'wakoo' )
            )
        ], $links );
        if ( ! wk_has_pro() ) {
            $links = array_merge( $links, [
                sprintf( '<a target="_blank" style="color:#e2498a; font-weight: bold;" href="%s">%s</a>',
                    '',
                    esc_html__( 'Get Pro', 'wakoo' )
                )
            ] );
        }
        return $links;
    }

    public static function save_data() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        if ( ! check_ajax_referer( self::WIDGETS_NONCE, 'nonce' ) ) {
            wp_send_json_error();
        }
        $posted_data = ! empty( $_POST['data'] ) ? $_POST['data'] : '';
        $data = [];
        parse_str( $posted_data, $data );
        $data = wk_sanitize_array_recursively( $data );

        wk_safe_do_action( 'wakoo_save_dashboard_data', $data );

        wp_send_json_success();
    }

    public static function save_widgets_data( $data ) {
        $widgets = ! empty( $data['widgets'] ) ? $data['widgets'] : [];
        $inactive_widgets = array_values( array_diff( array_keys( self::get_real_widgets_map() ), $widgets ) );
        Widgets_Manager::save_inactive_widgets( $inactive_widgets );
    }

    public static function save_features_data( $data ) {
        $features = ! empty( $data['features'] ) ? $data['features'] : [];

        /* Check whether Pro is available and allow to disable pro features */
        $widgets_map = self::get_real_features_map();
        if ( wk_has_pro() ) {
            $widgets_map = array_merge( $widgets_map, Extensions_Manager::get_pro_features_map() );
        }

        $inactive_features = array_values( array_diff( array_keys( $widgets_map ), $features ) );

        /* Always on features can not be disabled */
        $always_on_features = Extensions_Manager::get_always_on_features();
        if ( ! empty( $always_on_features ) ) {
            $inactive_features = array_values( array_diff( $inactive_features, $always_on_features ) );
        }

        Extensions_Manager::save_inactive_features( $inactive_features );
    }

    public static function save_extensions_data( $data ) {
        $extensions = ! empty( $data['extensions'] ) ? $data['extensions'] : [];

        /* Check whether Pro is available and allow to disable pro extensions */
        $extensions_map = self::get_real_extensions_map();
        if ( wk_has_pro() ) {
            $extensions_map = array_merge( $extensions_map, Extensions_Manager::get_pro_extensions_map() );
        }

        $inactive_extensions = array_values( array_diff( array_keys( $extensions_map ), $extensions ) );

        Extensions_Manager::save_inactive_extensions( $inactive_extensions );
    }

    public static function save_credentials_data( $data ) {
        $credentials = ! empty( $data['credentials'] ) ? $data['credentials'] : [];
        Credentials_Manager::save_credentials( $credentials );
    }

    public static function disable_unused_widget( $data ) {
        $disable_unused_widgets = ( ( ! empty( $data['disable-unused-widgets'] ) ) && ( 'true' == $data['disable-unused-widgets'] ) ) ? true : false;

		if( $disable_unused_widgets ){
			$inactive_widgets = \Wakoo\Elementor\Widgets_Manager::get_inactive_widgets();
			$unuse_widget = self::get_un_usage();
			$disable = array_unique(array_merge( $inactive_widgets, $unuse_widget ));
            Widgets_Manager::save_inactive_widgets( $disable );
		}
    }

    public static function enqueue_scripts( $hook ) {
        // css for dashboard widget
		$screen = \get_current_screen();
		if($screen->id == 'dashboard') {
			wp_enqueue_style(
				'wakoo-wp-dashboard',
				WAKOO_ASSETS . 'admin/css/wp-dashboard.min.css',
				null,
				WAKOO_VERSION
			);
		}

        if ( self::$wizard_slug == $hook && current_user_can( 'manage_options' ) ) {
            wp_enqueue_style(
                'wakoo-wizard',
                WAKOO_ASSETS . 'admin/css/wizard.min.css',
                null,
                WAKOO_VERSION
            );

            wp_enqueue_script(
                'vue-js-3',
                WAKOO_ASSETS . 'vendor/vue3/vue.global.prod.js',
                null,
                '3',
                true
            );

            wp_register_script(
                'wakoo-wizard',
                WAKOO_ASSETS . 'admin/js/wizard.min.js',
                [ 'jquery', 'vue-js-3' ],
                WAKOO_VERSION,
                true
            );

            wp_localize_script(
                'wakoo-wizard',
                'WakooWizard',
                [
                    'nonce'   => wp_create_nonce( self::WIZARD_NONCE ),
                    'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                    'apiBase' => get_rest_url( null, 'wakoo/v1' ),
                    'haAdmin' => admin_url( 'admin.php?page=wakoo#pro' ),
                ]
            );

            wp_enqueue_script( 'wakoo-wizard' );
        }

        if ( self::$menu_slug !== $hook || ! current_user_can( 'manage_options' ) ) {
            return;
        }

        wp_enqueue_style(
            'wakoo-icons',
            WAKOO_ASSETS . 'fonts/style.min.css',
            null,
            WAKOO_VERSION
        );

        wp_enqueue_style(
            'huge-icons',
            WAKOO_ASSETS . 'fonts/huge-icons/huge-icons.min.css',
            null,
            WAKOO_VERSION
        );

        wp_enqueue_style(
            'google-nunito-font',
            WAKOO_ASSETS . 'fonts/nunito/stylesheet.css',
            null,
            WAKOO_VERSION
        );

        wp_enqueue_style(
            'wakoo-dashboard',
            WAKOO_ASSETS . 'admin/css/dashboard.min.css',
            null,
            WAKOO_VERSION
        );

        /**
         * Magnific popup
         */
        wp_enqueue_style(
            'magnific-popup',
            WAKOO_ASSETS . 'vendor/magnific-popup/magnific-popup.css',
            null,
            WAKOO_VERSION
        );

        wp_enqueue_script(
            'jquery-magnific-popup',
            WAKOO_ASSETS . 'vendor/magnific-popup/jquery.magnific-popup.min.js',
            null,
            WAKOO_VERSION,
            true
        );

        wp_enqueue_script(
            'wakoo-dashboard',
            WAKOO_ASSETS . 'admin/js/dashboard.min.js',
            [ 'jquery' ],
            WAKOO_VERSION,
            true
        );

        wp_localize_script(
            'wakoo-dashboard',
            'WakooDashboard',
            [
                'nonce' => wp_create_nonce( self::WIDGETS_NONCE ),
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'action' => self::WIDGETS_NONCE,
                'saveChangesLabel' => esc_html__( 'Save Changes', 'wakoo' ),
                'savedLabel' => esc_html__( 'Changes Saved', 'wakoo' ),
            ]
        );
    }

    private static function get_real_widgets_map() {
        $widgets_map = Widgets_Manager::get_widgets_map();
        unset( $widgets_map[ Widgets_Manager::get_base_widget_key() ] );
        return $widgets_map;
    }

    public static function get_widgets() {
        $widgets_map = self::get_real_widgets_map();

        if ( ! wk_has_pro() ) {
            $widgets_map = array_merge( $widgets_map, Widgets_Manager::get_pro_widget_map() );
        }
        elseif( wk_has_pro() && version_compare( WAKOO_PRO_VERSION, '2.1.0', '<=' ) ) {
			$widgets_map = array_merge( $widgets_map, Widgets_Manager::get_pro_widget_map() );
		}

        uksort( $widgets_map, [ __CLASS__, 'sort_widgets' ] );
        return $widgets_map;
    }


	public static function get_widget_map_catwise() {
		$widgets = self::get_widgets();
		array_walk($widgets, function($item, $key){
			$item["cat"] = isset($item["cat"]) ? $item["cat"] : 'general'; // this code will be remove after next 2 release
		    self::$catwise_widget_map[$item["cat"]][$key] = [
		        'demo' => isset($item["demo"])? $item["demo"]: '',
		        'title' => $item["title"],
		        'icon' => $item["icon"],
		        'is_pro' => isset($item["is_pro"])? $item["is_pro"]: false,
		    	];
			}
		);

		return self::$catwise_widget_map;
	}

    public static function get_free_widget_map_catwise() {
		$widgets = self::get_real_widgets_map();
		array_walk($widgets, function($item, $key){
		    self::$catwise_free_widget_map[$item["cat"]][$key] = [
		        'demo' => isset($item["demo"])? $item["demo"]: '',
		        'title' => $item["title"],
		        'icon' => $item["icon"],
		        'is_pro' => isset($item["is_pro"])? $item["is_pro"]: false,
		    ];
		});
		return self::$catwise_free_widget_map;
	}

    private static function get_real_features_map() {
        $widgets_map = Extensions_Manager::get_features_map();
        return $widgets_map;
    }

    private static function get_real_extensions_map() {
        return Extensions_Manager::get_extensions_map();
    }

    public static function get_features() {
        $widgets_map = self::get_real_features_map();

        $widgets_map = array_merge( $widgets_map, Extensions_Manager::get_pro_features_map() );

        uksort( $widgets_map, [ __CLASS__, 'sort_widgets' ] );
        return $widgets_map;
    }


    public static function get_extensions() {
        $extensions_map = self::get_real_extensions_map();

        $extensions_map = array_merge( $extensions_map, Extensions_Manager::get_pro_extensions_map() );

        uksort( $extensions_map, [ __CLASS__, 'sort_widgets' ] );
        return $extensions_map;
    }

    public static function get_credentials() {

        $credentail_map = Credentials_Manager::get_credentials_map();

        $credentail_map = array_merge( $credentail_map, Credentials_Manager::get_pro_credentials_map() );

        return $credentail_map;
    }

    public static function sort_widgets( $k1, $k2 ) {
        return strcasecmp( $k1, $k2 );
    }

    public static function add_menu() {
        self::$menu_slug = add_menu_page(
            __( 'Wakoo Dashboard', 'wakoo' ),
            __( 'Wakoo', 'wakoo' ),
            'manage_options',
            self::PAGE_SLUG,
            [ __CLASS__, 'render_main' ],
            wk_get_b64_icon(),
            58.5
        );

		if ( 1 != get_option( WAKOO_WIZARD_REDIRECTION_FLAG, false ) ) {
			self::$wizard_slug =  add_menu_page(
				__( 'Setup Wizard', 'wakoo' ),
				__( 'Setup Wizard', 'wakoo' ),
				'manage_options',
				self::WIZARD_PAGE_SLUG,
				[ __CLASS__, 'wizard_page_wrapper'],
				'',
				null
			);
		}

        $tabs = self::get_tabs();
        if ( is_array( $tabs ) ) {
            foreach ( $tabs as $key => $data ) {
                if ( empty( $data['renderer'] ) || ! is_callable( $data['renderer'] ) ) {
                    continue;
                }

                add_submenu_page(
                    self::PAGE_SLUG,
                    sprintf( __( '%s - Wakoo', 'wakoo' ), $data['title'] ),
                    $data['title'],
                    'manage_options',
                    self::PAGE_SLUG . '#' . $key,
                    [ __CLASS__, 'render_main' ]
                );
            }
        }
    }

    public static function update_menu_items() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        global $submenu;
        $menu = $submenu[ self::PAGE_SLUG ];
        array_shift( $menu );
        $submenu[ self::PAGE_SLUG ] = $menu;
    }

	public static function get_raw_usage( $format = 'raw' ) {
		/** @var Module $module */

		$module = \Elementor\Modules\Usage\Module::instance();
		$usage = PHP_EOL;
		$widgets_list = [];
		if( wk_has_pro() ){
			$all_widgets = self::get_widgets();
		}else{
			$all_widgets = Widgets_Manager::get_local_widgets_map();
		}
        if(is_array($module->get_formatted_usage( $format ))||is_object($module->get_formatted_usage( $format ))){
            foreach ( $module->get_formatted_usage( $format ) as $doc_type => $data ) {
                $usage .= "\t{$data['title']} : " . $data['count'] . PHP_EOL;

                if(is_array($data['elements'])||is_object($data['elements'])){
                    foreach ( $data['elements'] as $element => $count ) {
                        $usage .= "\t\t{$element} : {$count}" . PHP_EOL;
                        $is_happy_widget = strpos( $element , "wk-") !== false;
                        $widget_key = str_replace('wk-','',$element);

                        if( $is_happy_widget && array_key_exists( $widget_key, $all_widgets ) ) {

                            $widgets_list[ $widget_key ] = $count;
                        }
                    }
                }
            }
        }
		return $widgets_list;
	}

	public static function get_un_usage() {
		if( wk_has_pro() ){
			$all_widgets = self::get_widgets();
		}else{
			$all_widgets = Widgets_Manager::get_local_widgets_map();
		}
		$used_widgets = self::get_raw_usage();
		$get_diff = array_diff( array_keys( $all_widgets ), array_keys( $used_widgets ) );
		// return $get_diff;
		return array_values($get_diff);
	}

    public static function get_tabs() {
        $tabs = [
            'home' => [
                'title' => esc_html__( 'Home', 'wakoo' ),
                'renderer' => [ __CLASS__, 'render_home' ],
            ],
            'widgets' => [
                'title' => esc_html__( 'Widgets', 'wakoo' ),
                'renderer' => [ __CLASS__, 'render_widgets' ],
            ],
            'features' => [
                'title' => esc_html__( 'Features', 'wakoo' ),
                'renderer' => [ __CLASS__, 'render_features' ],
            ],
            'extensions' => [
                'title' => esc_html__( 'Extension', 'wakoo' ),
                'renderer' => [ __CLASS__, 'render_extensions' ],
            ],
            'credentials' => [
                'title' => esc_html__( 'Credentials', 'wakoo' ),
                'renderer' => [ __CLASS__, 'render_credentials' ],
            ],
            'analytics' => [
                'title' => esc_html__( 'Analytics', 'wakoo' ),
                'renderer' => [ __CLASS__, 'render_analytics' ],
            ],
        ];

        return wk_safe_apply_filters( 'wakoo_dashboard_get_tabs', $tabs );
    }

    private static function load_template( $template ) {
        $file = WAKOO_DIR_PATH . 'templates/admin/dashboard-' . $template . '.php';
        if ( is_readable( $file ) ) {
            include( $file );
        }
    }

    private static function load_wizard_template( $template ) {
        $file = WAKOO_DIR_PATH . 'templates/wizard/wizard-' . $template . '.php';
        if ( is_readable( $file ) ) {
            include( $file );
        }
    }

    public static function render_main() {
        self::load_template( 'main' );
    }

    public static function render_home() {
        self::load_template( 'home' );
    }

    public static function render_widgets() {
        self::load_template( 'widgets' );
    }

    public static function render_features() {
        self::load_template( 'features' );
    }

    public static function render_extensions() {
        self::load_template( 'extensions' );
    }


    public static function render_credentials() {
        self::load_template( 'credentials' );
    }

    public static function render_analytics() {
        self::load_template( 'analytics' );
    }

    public static function render_pro() {
        self::load_template( 'pro' );
    }

    /**
	 * Set up a div for the app to render into.
	 */
	public static function wizard_page_wrapper() {
		?>
		<div class="wrap" id="wk-setup-wizard">
            <div id="loader-wrap" v-if="!loaded">
                <div class="loader">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
			<div id="wizard-root" :class="{ visible: loaded }">
                <div class="wk-setup-wizard__header">
                    <div class="wk-stepper">
                        <div class="wk-stepper__steps">
                            <wk-step
                                v-for="(step, index) in steps"
                                :active="currentPage"
                                :complete="step.isComplete"
                                :step="step.key"
                                :title="step.name"
                                :index="index+1"
                                @set-tab="setTab">
                            </wk-step>
                        </div>
                    </div>
                </div>
                <div class="wk-setup-wizard__container">
                    <div class="wk-setup-wizard__container_content">
                        <div class="wk-step-content wk-step-welcome welcome-step-bg" v-if="currentPage == 'welcome'">
                            <?php self::load_wizard_template( 'welcome' ); ?>
                        </div>
                        <div class="wk-step-content wk-step-widgets" v-if="currentPage == 'widgets'">
                            <?php self::load_wizard_template( 'widgets' ); ?>
                        </div>
                        <div class="wk-step-content wk-step-features" v-if="currentPage == 'features'">
                            <?php self::load_wizard_template( 'features' ); ?>
                        </div>
                        <div class="wk-step-content wk-step-bepro" v-if="currentPage == 'bepro'">
                            <?php self::load_wizard_template( 'bepro' ); ?>
                        </div>
                        <div class="wk-step-content wk-step-contribute" v-if="currentPage == 'contribute'">
                            <?php self::load_wizard_template( 'contribute' ); ?>
                        </div>
                        <div class="wk-step-content wk-step-congrats congrats-step-bg" v-if="currentPage == 'congrats'">
                            <?php self::load_wizard_template( 'congrats' ); ?>
                        </div>
                    </div>
                </div>
            </div>
		</div>
		<?php
	}
}
