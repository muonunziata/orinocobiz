<?php

if(!function_exists( 'hfe_render_header' )){
    function hfe_render_header(){
        global $wk__template_ids;
        if($wk__template_ids[0] == null){
            return;
        }

        do_action('wakoo/template/before_header');
        echo '<div class="ekit-template-content-markup ekit-template-content-header">';
            echo \Wakoo\Elementor\Classes\Theme_Builder::render_builder_data($wk__template_ids[0]);
        echo '</div>';
        do_action('wakoo/template/after_header');
    }
}

if(!function_exists( 'get_hfe_header_id' )){
    function get_hfe_header_id(){
        global $wk__template_ids;
        return $wk__template_ids[0];
    }
}

if(!function_exists( 'hfe_render_footer' )){
    function hfe_render_footer(){
        global $wk__template_ids;
        if($wk__template_ids[1] == null){
            return;
        }

        do_action('wakoo/template/before_header');
        echo '<div class="ekit-template-content-markup ekit-template-content-header">';
            echo \Wakoo\Elementor\Classes\Theme_Builder::render_builder_data($wk__template_ids[1]);
        echo '</div>';
        do_action('wakoo/template/after_header');
    }
}

if(!function_exists( 'get_hfe_footer_id' )){
    function get_hfe_footer_id(){
        global $wk__template_ids;
        return $wk__template_ids[1];
    }
}
