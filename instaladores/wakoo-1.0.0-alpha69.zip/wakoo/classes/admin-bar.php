<?php
namespace Wakoo\Elementor\Classes;

defined( 'ABSPATH' ) || die();

class Admin_Bar {

	public static function clear_cache() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! check_ajax_referer( 'wk_clear_cache', 'nonce' ) ) {
			wp_send_json_error();
		}

		$type = isset( $_POST['type'] ) ? sanitize_text_field($_POST['type']) : '';
		$post_id = isset( $_POST['post_id'] ) ? absint($_POST['post_id']) : 0;
		$assets_cache = new Assets_Cache( $post_id );
		if ( $type === 'page' ) {
			$assets_cache->delete();
		} elseif ( $type === 'all' ) {
			$assets_cache->delete_all();
		}
		wp_send_json_success();
	}

	public static function enqueue_assets() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		wp_enqueue_style(
			'wakoo-admin',
			WAKOO_ASSETS . 'admin/css/admin.min.css',
			null,
			WAKOO_VERSION
		);

		wp_enqueue_script(
			'wakoo-admin',
			WAKOO_ASSETS . 'admin/js/admin.min.js',
			['jquery'],
			WAKOO_VERSION,
			true
		);
		// wp_enqueue_style('select2');

		// wp_enqueue_script( 'select2' );

		wp_enqueue_script(
			'micromodal',
			WAKOO_ASSETS . 'vendor/micromodal/micromodal.min.js',
			[],
			WAKOO_VERSION,
			true
		);

		wp_enqueue_style(
			'select2',
			WAKOO_ASSETS . 'vendor/select2/select2.min.css',
			null,
			WAKOO_VERSION
		);

		wp_enqueue_script(
			'select2',
			WAKOO_ASSETS . 'vendor/select2/select2.min.js',
			['jquery'],
			WAKOO_VERSION,
			true
		);

		wp_enqueue_script( 'wp-api' );

		wp_enqueue_script(
			'alpine',
			WAKOO_ASSETS . 'vendor/alpinejs/alpine.min.js',
			[],
			WAKOO_VERSION,
			true
		);

		wp_localize_script(
			'wakoo-admin',
			'WakooAdmin',
			[
				'nonce'    => wp_create_nonce( 'wk_clear_cache' ),
				'post_id'  => get_queried_object_id(),
				'ajax_url' => admin_url( 'admin-ajax.php' ),
			]
		);
	}

	public static function add_toolbar_items( \WP_Admin_Bar $admin_bar ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$icon = '<i class="dashicons dashicons-update-alt"></i> ';

		$admin_bar->add_menu( [
			'id'    => 'wakoo',
			'title' => '<span class="ab-icon dashicons dashicons-layout" style="font-family:dashicons;margin-top:2px"></span><span class="ab-label">' . esc_html__( 'Wakoo', 'wakoo' ) . '</span>',
			'href'  => wk_get_dashboard_link(),
			'meta'  => [
				'title' => __( 'Wakoo', 'wakoo' ),
			]
		] );

		if ( is_singular() ) {
			$admin_bar->add_menu( [
				'id'     => 'wk-clear-page-cache',
				'parent' => 'wakoo',
				'title'  => $icon . __( 'Page: Renew On Demand Assets', 'wakoo' ),
				'href'   => '#',
				'meta'   => [
					'class' => 'hajs-clear-cache wk-clear-page-cache',
				]
			] );
		}

		$admin_bar->add_menu( [
			'id'     => 'wk-clear-all-cache',
			'parent' => 'wakoo',
			'title'  => $icon . __( 'Global: Renew On Demand Assets', 'wakoo' ),
			'href'   => '#',
			'meta'   => [
				'class' => 'hajs-clear-cache wk-clear-all-cache',
			]
		] );
	}
}
