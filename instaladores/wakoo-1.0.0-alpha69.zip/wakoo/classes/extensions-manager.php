<?php
namespace Wakoo\Elementor\Classes;

defined( 'ABSPATH' ) || die();

use Wakoo\Elementor\Extensions as Features;

class Extensions_Manager {
	const FEATURES_DB_KEY = 'wakoo_inactive_features';

	const EXTENSIONS_DB_KEY = 'wakoo_inactive_extensions';

	/**
	 * Initialize
	 */
	public static function init() {
		self::register_extension_filters();

		if ( wk_is_button_fixed_size_enabled() ) {
			add_action( 'elementor/element/button/section_style/after_section_start', [ Features\Fixed_Size_Button::class, 'add_button_controls' ] );
		}

		$inactive_features = self::get_inactive_features();
		$always_on_features = self::get_always_on_features();

		foreach ( self::get_local_features_map() as $feature_key => $data ) {
			if ( in_array( $feature_key, $always_on_features, true ) || ! in_array( $feature_key, $inactive_features ) ) {
				self::enable_feature( $feature_key );
			}
		}

		foreach ( self::get_pro_features_map() as $feature_key => $data ) {
			if ( ! in_array( $feature_key, $always_on_features, true ) && in_array( $feature_key, $inactive_features ) ) {
				self::disable_pro_feature( $feature_key );
			}
		}

		$inactive_extensions = self::get_inactive_extensions();

		foreach ( self::get_local_extensions_map() as $extension_key => $data ) {
			if ( ! in_array( $extension_key, $inactive_extensions ) ) {
				self::enable_extension( $extension_key );
			}
		}

		foreach ( self::get_pro_extensions_map() as $extension_key => $data ) {
			if ( in_array( $extension_key, $inactive_extensions ) ) {
				self::disable_pro_extension( $extension_key );
			}
		}
	}

	public static function get_extensions_map() {
		$extensions_map = self::get_local_extensions_map();

		return wk_safe_apply_filters( 'wakoo_get_extensions_map', $extensions_map );
	}

	public static function get_inactive_extensions() {
		return get_option( self::EXTENSIONS_DB_KEY, [] );
	}

	public static function save_inactive_extensions( $extensions = [] ) {
		update_option( self::EXTENSIONS_DB_KEY, $extensions );
	}

	/**
	 * Register "disable" filters for inactive extensions.
	 *
	 * This must run before any extension is checked via wk_is_*_enabled()
	 * so the filters are in place regardless of the hook order.
	 */
	public static function register_extension_filters() {
		foreach ( self::get_inactive_extensions() as $extension_key ) {
			self::disable_extension( $extension_key );
		}
	}

	/**
	 * Get the pro extensions map for dashboard only
	 *
	 * @return array
	 */
	public static function get_pro_extensions_map() { return [];

		$pro_extensions_map = [
            'image-masking'=> [
                'title'  => __( 'Image Masking', 'wakoo-pro' ),
                'icon'   => 'hm hm-image-masking',
                'demo'   => '',
                'is_pro' => true
            ],
            
        ];
		return wk_safe_apply_filters( 'wakoo_get_pro_extensions_map', $pro_extensions_map );
	}

	/**
	 * Get the list of features that are always on and can not be disabled.
	 *
	 * Features marked with `always_on => true` are excluded from the inactive
	 * list both while running and while saving dashboard settings.
	 *
	 * @return array
	 */
	public static function get_always_on_features() {
		$always_on_features = [];

		foreach ( self::get_local_features_map() as $feature_key => $data ) {
			if ( ! empty( $data['always_on'] ) ) {
				$always_on_features[] = $feature_key;
			}
		}

		foreach ( self::get_pro_features_map() as $feature_key => $data ) {
			if ( ! empty( $data['always_on'] ) ) {
				$always_on_features[] = $feature_key;
			}
		}

		return array_values( array_unique( $always_on_features ) );
	}

	/**
	 * Get the free extensions map
	 *
	 * @return array
	 */
	public static function get_local_extensions_map() {
		return [
			'background-hover-effect' => [
				'title' => __( 'Background Hover Effect', 'wakoo' ),
				'icon' => 'hm hm-scroll-top',
				'demo' => '',
				'is_pro' => false,
			],
			'foreground-overlay' => [
				'title' => __( 'Foreground Overlay', 'wakoo' ),
				'icon' => 'hm hm-flip-card2',
				'demo' => '',
				'is_pro' => false,
			],
			'button-fixed-size' => [
				'title' => __( 'Fixed Size Button', 'wakoo' ),
				'icon' => 'hm hm-fixed-size-button',
				'demo' => '',
				'is_pro' => false,
			],
			'widget-background-overlay' => [
				'title' => __( 'Widget Background Overlay', 'wakoo' ),
				'icon' => 'hm hm-file-rotate',
				'demo' => '',
				'is_pro' => false,
			],
			'text-stroke' => [
				'title' => __( 'Text Stroke', 'wakoo' ),
				'icon' => 'hm hm-text-outline',
				'demo' => '',
				'is_pro' => false,
			],
		];
	}

	public static function get_features_map() {
		$features_map = [];

		$local_features_map = self::get_local_features_map();
		$features_map = array_merge( $features_map, $local_features_map );

		return wk_safe_apply_filters( 'wakoo_get_features_map', $features_map );
	}

	public static function get_inactive_features() {
		return get_option( self::FEATURES_DB_KEY, [] );
	}

	public static function save_inactive_features( $features = [] ) {
		update_option( self::FEATURES_DB_KEY, $features );
	}

	/**
	 * Get the pro features map for dashboard only
	 *
	 * @return array
	 */
	public static function get_pro_features_map() { return [];
		$pro_features_map = [
			'display-conditions' => [
				'title' => __( 'Display Condition', 'wakoo' ),
				'icon' => 'hm hm-display-condition',
				'demo' => '',
				'is_pro' => true,
			],
			'live-copy' => [
				'title' => __( 'Live Copy', 'wakoo-pro' ),
				'icon' => 'hm hm-copy',
				'demo' => '',
				'is_pro' => true,
				'always_on' => true,
			],
			'wakoo-particle-effects' => [
				'title' => __( 'Wakoo Particle Effects', 'wakoo' ),
				'icon' => 'hm hm-spark',
				'demo' => '',
				'is_pro' => true,
			],
			'wakoo-preset' => [
				'title' => __( 'Preset', 'wakoo' ),
				'icon' => 'hm hm-color-card',
				'demo' => '',
				'is_pro' => true,
			],
			'global-badge' => [
				'title' => __( 'Global Badge', 'wakoo' ),
				'icon' => 'hm hm-global-badge',
				'demo' => '',
				'is_pro' => true,
			],

			// Pro feature placeholders
			'horizontal-scroll' => [
				'title' => __( 'Horizontal Scroll', 'wakoo-pro' ),
				'icon' => 'huge huge-horizonal-scroll-point-round',
				'demo' => '',
				'is_pro' => true,
			],
			'infinite-marquee' => [
				'title' => __( 'Marquee', 'wakoo-pro' ),
				'icon' => 'huge huge-infinity-02',
				'demo' => '',
				'is_pro' => true,
			],
			'global-animation' => [
                'title'  => __( 'Animation', 'wakoo-pro' ),
                'icon'   => 'hm hm-alien',
                'demo'   => '',
                'is_pro' => true
            ],
			'sticky-pin-element' => [
				'title'  => __( 'Sticky Pin Element', 'wakoo-pro' ),
				'icon'   => 'hm hm-sticky',
				'demo'   => '',
				'is_pro' => true
			],
			'multi-layer-parallax' => [
				'title' => __( 'Multi Layer Parallax', 'wakoo-pro' ),
				'icon' => 'huge huge-layers-02',
				'demo' => '',
				'is_pro' => true,
			],
			'wakoo-image-trails' => [
				'title' => __( 'Image Trails', 'wakoo-pro' ),
				'icon' => 'hm hm-media-all',
				'demo' => '',
				'is_pro' => true,
			]
		];

		return wk_safe_apply_filters( 'wakoo_get_pro_features_map', $pro_features_map );
	}

	/**
	 * Get the free features map
	 *
	 * @return array
	 */
	public static function get_local_features_map() {
		return [
			'background-overlay' => [
				'title' => __( 'Background Overlay', 'wakoo' ),
				'icon' => 'hm hm-layer',
				'demo' => '',
				'is_pro' => false,
			],
			'foreground-overlay' => [
				'title' => __( 'Foreground Overlay', 'wakoo' ),
				'icon' => 'hm hm-layer',
				'is_pro' => false,
			],
			'grid-layer' => [
				'title' => __( 'Grid Layer', 'wakoo' ),
				'icon' => 'hm hm-grid',
				'demo' => '',
				'is_pro' => false,
			],
			'floating-effects' => [
				'title' => __( 'Floating Effects', 'wakoo' ),
				'icon' => 'hm hm-weather-flood',
				'demo' => '',
				'is_pro' => false,
			],
			'wrapper-link' => [
				'title' => __( 'Wrapper Link', 'wakoo' ),
				'icon' => 'hm hm-section-link',
				'demo' => '',
				'is_pro' => false,
			],
			'css-transform' => [
				'title' => __( 'CSS Transform', 'wakoo' ),
				'icon' => 'hm hm-3d-rotate',
				'demo' => '',
				'is_pro' => false,
			],
			'equal-height' => [
				'title' => __( 'Equal Height Column', 'wakoo' ),
				'icon' => 'hm hm-grid-layout',
				'demo' => '',
				'is_pro' => false,
			],
			'shape-divider' => [
				'title' => __( 'Shape Divider', 'wakoo' ),
				'icon' => 'hm hm-map',
				'demo' => '',
				'is_pro' => false,
			],
			'column-extended' => [
				'title' => __( 'Column Order & Extension', 'wakoo' ),
				'icon' => 'hm hm-flip-card2',
				'demo' => '',
				'is_pro' => false,
			],
			'advanced-tooltip' => [
				'title' => __( 'Wakoo Tooltip', 'wakoo' ),
				'icon' => 'hm hm-comment-square',
				'demo' => '',
				'is_pro' => false,
			],
			'text-stroke' => [
				'title' => __( 'Text Stroke', 'wakoo' ),
				'icon' => 'hm hm-text-outline',
				'demo' => '',
				'is_pro' => false,
			],
			'scroll-to-top' => [
				'title' => __( 'Scroll To Top', 'wakoo' ),
				'icon' => 'hm hm-scroll-top',
				// 'demo' => '',
				'is_pro' => false,
			],
			'reading-progress-bar' => [
				'title' => __( 'Reading Progress Bar', 'wakoo' ),
				'icon' => 'hm hm-reading-glass-alt',
				'demo' => '',
				'is_pro' => false,
			],
			'custom-js' => [
				'title' => __( 'Custom JS', 'wakoo' ),
				'icon' => 'huge huge-code',
				// 'demo' => '',
				'is_pro' => false,
			],
			'background-parallax' => [
				'title' => __( 'Background Parallax', 'wakoo' ),
				'icon' => 'huge huge-web-design-02',
				'demo' => '',
				'is_pro' => false,
			],
			'liquid-glass' => [
				'title' => __( 'Liquid Glass', 'wakoo-pro' ),
				'icon' => 'hm hm-reading-glass',
				'demo' => '',
				'is_pro' => false,
			],
			'container-hover-text-color' => [
				'title' => __( 'Background Hover Effect', 'wakoo' ),
				'icon' => 'hm hm-cursor-hover-click',
				'is_pro' => false,
			],
		];
	}

	protected static function enable_feature( $feature_key ) {

		switch ($feature_key) {
			case 'background-overlay':
				if ( wk_is_widget_background_overlay_enabled() ) {
					add_action( 'elementor/element/common/_section_background/after_section_end', [Features\Background_Overlay::class, 'add_section'] );
				}
				break;

			case 'foreground-overlay':
				add_action( 'elementor/element/container/section_background_overlay/after_section_end', [Features\Foreground_Overlay::class, 'add_section'] );
				add_action( 'elementor/frontend/before_render', [Features\Foreground_Overlay::class, 'before_render'], 1 );
				add_action( 'elementor/frontend/before_register_scripts', [Features\Foreground_Overlay::class, 'register_scripts'] );
				add_action( 'elementor/preview/enqueue_scripts', [Features\Foreground_Overlay::class, 'preview_enqueue_scripts'] );
				add_action( 'elementor/preview/enqueue_styles', [Features\Foreground_Overlay::class, 'preview_enqueue_styles'] );
				break;

			case 'grid-layer':
				add_action('elementor/documents/register_controls', [Features\Grid_Layer::class, 'add_controls_section'] , 1 , 1 );
				break;

			case 'floating-effects':
				add_action( 'elementor/element/common/_section_style/after_section_end', [ Features\Floating_Effects::class, 'register' ], 1 );
				add_action( 'elementor/frontend/before_register_scripts', [ Features\Floating_Effects::class, 'register_scripts' ] );
				add_action( 'elementor/preview/enqueue_scripts', [ Features\Floating_Effects::class, 'preview_enqueue_scripts' ] );
				break;

			case 'wrapper-link':
				add_action( 'elementor/element/container/section_layout/after_section_end', [ Features\Wrapper_Link::class, 'add_controls_section' ], 1 );
				add_action( 'elementor/element/column/section_advanced/after_section_end', [ Features\Wrapper_Link::class, 'add_controls_section' ], 1 );
				add_action( 'elementor/element/section/section_advanced/after_section_end', [ Features\Wrapper_Link::class, 'add_controls_section' ], 1 );
				add_action( 'elementor/element/common/_section_style/after_section_end', [ Features\Wrapper_Link::class, 'add_controls_section' ], 1 );
				add_action( 'elementor/frontend/before_render', [ Features\Wrapper_Link::class, 'before_section_render' ], 1 );
				break;

			case 'css-transform':
				add_action( 'elementor/element/common/_section_style/after_section_end', [ Features\CSS_Transform::class, 'register' ], 1 );
				break;

			case 'equal-height':
				add_action( 'elementor/element/container/section_layout/after_section_end', [ Features\Equal_Height::class, 'register' ], 1 );
				add_action( 'elementor/element/section/section_advanced/after_section_end', [ Features\Equal_Height::class, 'register' ], 1 );
				add_action( 'elementor/frontend/before_register_scripts', [ Features\Equal_Height::class, 'register_scripts' ] );
				add_action( 'elementor/preview/enqueue_scripts', [ Features\Equal_Height::class, 'enqueue_preview_scripts' ] );
				break;

			case 'shape-divider':
				add_filter( 'elementor/shapes/additional_shapes', [Features\Shape_Divider::class, 'additional_shape_divider'] );
				add_action( 'elementor/element/section/section_shape_divider/before_section_end', [Features\Shape_Divider::class, 'update_shape_list'] );
				add_action( 'elementor/element/container/section_shape_divider/before_section_end', [Features\Shape_Divider::class, 'update_shape_list'] );
				break;

			case 'column-extended':
				add_action( 'elementor/element/column/layout/before_section_end', [ Features\Column_Extended::class, 'add_controls' ] );
				break;

			case 'advanced-tooltip':
				add_action('elementor/element/common/_section_style/after_section_end', [Features\Advanced_Tooltip::class, 'add_controls_section'], 1);
				add_action( 'elementor/frontend/before_register_scripts', [ Features\Advanced_Tooltip::class, 'register_scripts' ] );
				add_action( 'elementor/preview/enqueue_scripts', [ Features\Advanced_Tooltip::class, 'enqueue_preview_scripts' ] );
				break;

			case 'text-stroke':
				if( ! in_array( 'text-stroke', wk_get_inactive_features() ) && wk_is_text_stroke_enabled() ) {
					add_action( 'elementor/element/heading/section_title_style/before_section_end', [ Features\Text_Stroke::class, 'add_text_stroke' ] );
					add_action( 'elementor/element/theme-page-title/section_title_style/before_section_end', [ Features\Text_Stroke::class, 'add_text_stroke' ] );
					add_action( 'elementor/element/theme-site-title/section_title_style/before_section_end', [ Features\Text_Stroke::class, 'add_text_stroke' ] );
					add_action( 'elementor/element/theme-post-title/section_title_style/before_section_end', [ Features\Text_Stroke::class, 'add_text_stroke' ] );
					add_action( 'elementor/element/woocommerce-product-title/section_title_style/before_section_end', [ Features\Text_Stroke::class, 'add_text_stroke' ] );
					add_action( 'elementor/element/animated-headline/section_style_text/before_section_end', [ Features\Text_Stroke::class, 'add_text_stroke' ] );
					add_action( 'elementor/element/wk-gradient-heading/_section_style_title/before_section_end', [ Features\Text_Stroke::class, 'add_text_stroke' ] );
				}
				break;

			// case 'custom-js':
			// 	add_action( 'elementor/documents/register_controls', [Features\Custom_Js::class, 'scroll_to_top_controls'], 10 );
			// 	add_action( 'wp_footer', [Features\Custom_Js::class, 'render_scroll_to_top_html'] );
			// 	break;

			case 'scroll-to-top':
			case 'reading-progress-bar':
			case 'custom-js':
			case 'background-parallax':
			case 'liquid-glass':
			case 'container-hover-text-color':
				$cls_name = ucwords( str_replace( '-', ' ', $feature_key ) ); //remove ' - ' & uc first later
				$cls_name = '\Wakoo\Elementor\Extensions\\' . str_replace( ' ', '_', $cls_name );
				$cls_name::instance()->init();
				break;
		}
	}

	protected static function disable_pro_feature( $feature_key ) {
		switch ($feature_key) {
			case 'display-conditions':
				add_filter( 'wakoo/extensions/display_condition', '__return_false' );
				break;

			case 'wakoo-particle-effects':
				add_filter( 'wakoo/extensions/wakoo_particle_effects', '__return_false' );
				break;

			case 'global-badge':
				add_filter( 'wakoo/extensions/wakoo_global_badge', '__return_false' );
				break;

			// case 'wakoo-preset':
			// 	add_filter( 'wakoo/extensions/wakoo_preset', '__return_false' );
			// 	break;
		}
	}

	protected static function enable_extension( $extension_key ) {
		switch ( $extension_key ) {
			default:
				do_action( 'wakoo/enable_extension', $extension_key );
				break;
		}
	}

	protected static function disable_extension( $extension_key ) {
		$filter_key = str_replace( '-', '_', $extension_key );
		add_filter( 'wakoo/extensions/' . $filter_key, '__return_false' );
	}

	protected static function disable_pro_extension( $extension_key ) {
		$filter_key = str_replace( '-', '_', $extension_key );
		add_filter( 'wakoo/extensions/' . $filter_key, '__return_false' );
	}
}
