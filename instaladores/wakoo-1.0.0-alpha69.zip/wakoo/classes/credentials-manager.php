<?php

namespace Wakoo\Elementor\Classes;

defined('ABSPATH') || die();

class Credentials_Manager {
	const CREDENTIALS_DB_KEY = 'wakoo_credentials';

	public static function get_credentials_map() {
		$credentials_map = [];

		$local_credentials_map = self::get_local_credentials_map();
		$credentials_map = array_merge($credentials_map, $local_credentials_map);

		return wk_safe_apply_filters('wakoo_get_credentials_map', $credentials_map);
	}

	public static function get_saved_credentials() {
		return get_option(self::CREDENTIALS_DB_KEY, []);
	}

	public static function save_credentials($credentials = []) {
		update_option(self::CREDENTIALS_DB_KEY, $credentials);
	}

	/**
	 * Get the pro credentials map for dashboard only
	 *
	 * @return array
	 */
	public static function get_pro_credentials_map() {
		return [
			'advanced_data_table' => [
				'title' => __('Advanced Data Table', 'wakoo'),
				'icon' => 'hm hm-data-table',
				'fiels' => [
					[
						'label' => esc_html__('Google API Key. ', 'wakoo'),
						'type' => 'text',
						'name' => 'api_key',
						'help' => [
							'instruction' => esc_html__('Get API Key', 'wakoo'),
							'link' => 'https://console.developers.google.com/'
						],
					],
					[
						'label' => esc_html__('Google Sheet ID. ', 'wakoo'),
						'type' => 'text',
						'name' => 'sheet_id',
						'help' => [],
					],
					[
						'label' => esc_html__('Google Sheets Range. Ex: A1:D5 ', 'wakoo'),
						'type' => 'text',
						'name' => 'sheet_range',
						'help' => [],
					],
				],
				'is_pro' => true,
			],
			'facebook_feed' => [
				'title' => __('Facebook Feed', 'wakoo'),
				'icon' => 'hm hm-facebook',
				'fiels' => [
					[
						'label' => esc_html__('Page ID. ', 'wakoo'),
						'type' => 'text',
						'name' => 'page_id',
						'help' => [
							'instruction' => esc_html__('Get Page ID', 'wakoo'),
							'link' => 'https://developers.facebook.com/apps/'
						],
					],
					[
						'label' => esc_html__('Access Token. ', 'wakoo'),
						'type' => 'text',
						'name' => 'access_token',
						'help' => [
							'instruction' => esc_html__('Get Access Token.', 'wakoo'),
							'link' => 'https://developers.facebook.com/apps/'
						],
					],
				],
				'is_pro' => true,
			],
			'instagram' => [
				'title' => __('Instagram', 'wakoo'),
				'icon' => 'hm hm-instagram',
				'fiels' => [
					[
						'label' => esc_html__('Access Token. ', 'wakoo'),
						'type' => 'text',
						'name' => 'access_token',
						'help' => [
							'instruction' => esc_html__('Get Access Token', 'wakoo'),
							'link' => 'https://developers.facebook.com/docs/instagram-basic-display-api/getting-started'
						],
					],
				],
				'is_pro' => true,
			],
		];
	}

	/**
	 * Get the free credentials map
	 *
	 * @return array
	 */
	public static function get_local_credentials_map() {
		return [
		];
	}
}

