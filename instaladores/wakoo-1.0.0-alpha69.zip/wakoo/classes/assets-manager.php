<?php

namespace Wakoo\Elementor\Classes;

use Elementor\Core\Files\CSS\Post as Post_CSS;
use Elementor\Core\Settings\Manager as SettingsManager;

defined('ABSPATH') || die();

class Assets_Manager {

	/**
	 * Register inline editing paragraph toolbar
	 *
	 * @param array $config
	 * @return array
	 */
	public static function add_inline_editing_intermediate_toolbar($config) {
		if (!isset($config['inlineEditing'])) {
			return $config;
		}

		$tools = [
			'bold',
			'underline',
			'italic',
			'createlink',
		];

		if (isset($config['inlineEditing']['toolbar'])) {
			$config['inlineEditing']['toolbar']['intermediate'] = $tools;
		} else {
			$config['inlineEditing'] = [
				'toolbar' => [
					'intermediate' => $tools,
				],
			];
		}

		return $config;
	}

	/**
	 * Register frontend assets.
	 *
	 * Frontend assets handler will be used in widgets map
	 * to load widgets assets on demand.
	 *
	 * @return void
	 */
	public static function frontend_register() {
		$suffix = wk_is_script_debug_enabled() ? '.' : '.min.';

		wp_register_style(
			'wakoo-icons',
			WAKOO_ASSETS . 'fonts/style.min.css',
			null,
			WAKOO_VERSION
		);
		
		// Image comparasion
		wp_register_style(
			'twentytwenty',
			WAKOO_ASSETS . 'vendor/twentytwenty/css/twentytwenty.css',
			null,
			WAKOO_VERSION
		);

		wp_register_script(
			'wk-whatsapp-button',
			WAKOO_ASSETS . 'js/whatsapp-button'.$suffix.'js',
			['jquery'],
			WAKOO_VERSION,
			true
		);

		wp_register_script(
			'jquery-event-move',
			WAKOO_ASSETS . 'vendor/twentytwenty/js/jquery.event.move.js',
			['jquery'],
			WAKOO_VERSION,
			true
		);

		wp_register_script(
			'jquery-twentytwenty',
			WAKOO_ASSETS . 'vendor/twentytwenty/js/jquery.twentytwenty.js',
			['jquery-event-move'],
			WAKOO_VERSION,
			true
		);

		// Justified Grid
		wp_register_style(
			'justifiedGallery',
			WAKOO_ASSETS . 'vendor/justifiedGallery/css/justifiedGallery.min.css',
			null,
			WAKOO_VERSION
		);

		wp_register_script(
			'jquery-justifiedGallery',
			WAKOO_ASSETS . 'vendor/justifiedGallery/js/jquery.justifiedGallery.min.js',
			['jquery'],
			WAKOO_VERSION,
			true
		);

		// Carousel and Slider
		wp_register_style(
			'slick',
			WAKOO_ASSETS . 'vendor/slick/slick.css',
			null,
			WAKOO_VERSION
		);

		wp_register_style(
			'slick-theme',
			WAKOO_ASSETS . 'vendor/slick/slick-theme.css',
			null,
			WAKOO_VERSION
		);

		wp_register_script(
			'jquery-slick',
			WAKOO_ASSETS . 'vendor/slick/slick.min.js',
			['jquery'],
			WAKOO_VERSION,
			true
		);

		// Masonry grid
		wp_register_script(
			'jquery-isotope',
			WAKOO_ASSETS . 'vendor/jquery.isotope.js',
			['jquery'],
			WAKOO_VERSION,
			true
		);

		// Number animation
		wp_register_script(
			'jquery-numerator',
			WAKOO_ASSETS . 'vendor/jquery-numerator/jquery-numerator.min.js',
			['jquery'],
			WAKOO_VERSION,
			true
		);

		// Magnific popup
		wp_register_style(
			'magnific-popup',
			WAKOO_ASSETS . 'vendor/magnific-popup/magnific-popup.css',
			null,
			WAKOO_VERSION
		);

		wp_register_script(
			'jquery-magnific-popup',
			WAKOO_ASSETS . 'vendor/magnific-popup/jquery.magnific-popup.min.js',
			null,
			WAKOO_VERSION,
			true
		);

		// keyframes
		wp_register_script(
			'jquery-keyframes',
			WAKOO_ASSETS . 'vendor/keyframes/jquery.keyframes.min.js',
			['jquery'],
			WAKOO_VERSION,
			true
		);

		// Chart.js
		wp_register_script(
			'chart-js',
			WAKOO_ASSETS . 'vendor/chart/chart.min.js',
			['jquery'],
			WAKOO_VERSION,
			true
		);

		// Threesixty Rotation js
		wp_register_script(
			'circlr',
			WAKOO_ASSETS . 'vendor/threesixty-rotation/circlr.min.js',
			['jquery'],
			WAKOO_VERSION,
			true
		);

		// wakoo magnify js
		wp_register_script(
			'wk-simple-magnify',
			WAKOO_ASSETS . 'vendor/threesixty-rotation/wakoo-simple-magnify.js',
			['jquery'],
			WAKOO_VERSION,
			true
		);

		// fullcalendar js
		wp_register_script(
			'wk-fullcalendar',
			WAKOO_ASSETS . 'vendor/fullcalendar/fullcalendar.min.js',
			['jquery'],
			WAKOO_VERSION,
			true
		);

		// fullcalendar language js
		wp_register_script(
			'wk-fullcalendar-locales',
			WAKOO_ASSETS . 'vendor/fullcalendar/locales-all.min.js',
			['jquery'],
			WAKOO_VERSION,
			true
		);

		// fullcalendar css
		wp_register_style(
			'wk-fullcalendar',
			WAKOO_ASSETS . 'vendor/fullcalendar/fullcalendar.min.css',
			null,
			WAKOO_VERSION
		);

		// Hover css
		wp_register_style(
			'hover-css',
			WAKOO_ASSETS . 'vendor/hover-css/hover-css.css',
			null,
			WAKOO_VERSION
		);

		// Sharer JS
		wp_register_script(
			'sharer-js',
			WAKOO_ASSETS . 'vendor/sharer-js/sharer.min.js',
			['jquery'],
			WAKOO_VERSION,
			true
		);


		// Wakoo addons PDF JS
		wp_register_script(
			'pdf-js',
			WAKOO_ASSETS . 'vendor/pdfobject/pdfobject.min.js',
			[],
			WAKOO_VERSION,
			false
		);

		// dom-purify js to sanitize text
		wp_register_script(
			'dom-purify',
			WAKOO_ASSETS . 'vendor/dom-purify/purify.min.js',
			[],
			'3.1.6',
			false
		);

		// three js
		wp_register_script(
			'three',
			WAKOO_ASSETS . 'vendor/three.min.js',
			[],
			WAKOO_VERSION,
			false
		);

		// native tween shim for hover-effect (original Wakoo code)
		wp_register_script(
			'wk-tween',
			WAKOO_ASSETS . 'vendor/wk-tween.js',
			[],
			WAKOO_VERSION,
			false
		);

		// hover-effect js
		wp_register_script(
			'hover-effect',
			WAKOO_ASSETS . 'vendor/hover-effect.umd.js',
			['three', 'wk-tween'],
			WAKOO_VERSION,
			false
		);

		// Anime js
		wp_register_script(
			'anime',
			WAKOO_ASSETS . 'vendor/anime/lib/anime.min.js',
			[],
			WAKOO_VERSION,
			true
		);

		// Match Height
		wp_register_script(
			'jquery-match-height',
			WAKOO_ASSETS . 'vendor/jquery-match-height/jquery.matchHeight-min.js',
			[],
			WAKOO_VERSION,
			true
		);

		// imagesloaded.pkgd.min.js
		wp_register_script(
			'imagesloaded',
			WAKOO_ASSETS . 'vendor/imagesloaded.pkgd.min.js',
			['jquery'],
			WAKOO_VERSION,
			true
		);
		
		// Main assets
		wp_register_style(
			'wakoo',
			WAKOO_ASSETS . 'css/main' . $suffix . 'css',
			['elementor-frontend'],
			WAKOO_VERSION
		);

		// Wakoo addons script
		wp_register_script(
			'wakoo',
			WAKOO_ASSETS . 'js/wakoo' . $suffix . 'js',
			['jquery'],
			WAKOO_VERSION,
			true
		);

		//Localize scripts
		wp_localize_script(
			'wakoo',
			'WakooLocalize',
			[
				'ajax_url' => admin_url('admin-ajax.php'),
				'nonce'    => wp_create_nonce('wakoo_nonce'),
				'pdf_js_lib' => WAKOO_ASSETS . 'vendor/pdfjs/lib'
			]
		);
	}

	/**
	 * Handle exception cases where regular enqueue won't work
	 *
	 * @param Post_CSS $file
	 *
	 * @return void
	 */
	public static function frontend_enqueue_exceptions(Post_CSS $file) {
		$post_id = $file->get_post_id();

		if (get_queried_object_id() === $post_id) {
			return;
		}

		$template_type = get_post_meta($post_id, '_elementor_template_type', true);

		if ($template_type === 'kit') {
			return;
		}

		self::enqueue($post_id);
	}

	/**
	 * Enqueue fontend assets
	 *
	 * @return void
	 */
	public static function frontend_enqueue() {
		if (!is_singular()) {
			return;
		}

		wp_enqueue_script( 'dom-purify' );

		self::enqueue(get_the_ID());
	}

	/**
	 * Just enqueue the assets
	 *
	 * It just processes the assets from cache if avilable
	 * otherwise raw assets
	 *
	 * @param int $post_id
	 *
	 * @return void
	 */
	public static function enqueue($post_id) {
		if (Cache_Manager::should_enqueue($post_id)) {
			Cache_Manager::enqueue($post_id);
		}

		if (Cache_Manager::should_enqueue_raw($post_id)) {
			Cache_Manager::enqueue_raw($post_id);
		}
	}

	public static function get_dark_stylesheet_url() {
		return WAKOO_ASSETS . 'admin/css/editor-dark.min.css';
	}

	public static function enqueue_dark_stylesheet() {
		$theme = SettingsManager::get_settings_managers('editorPreferences')->get_model()->get_settings('ui_theme');

		if ('light' !== $theme) {
			$media_queries = 'all';

			if ('auto' === $theme) {
				$media_queries = '(prefers-color-scheme: dark)';
			}

			wp_enqueue_style(
				'wakoo-editor-dark',
				self::get_dark_stylesheet_url(),
				[
					'elementor-editor',
				],
				WAKOO_VERSION,
				$media_queries
			);
		}
	}

	/**
	 * Enqueue preview scripts.
	 *
	 * Loads vendor scripts that are handled conditionally on the frontend
	 * so widgets still render correctly inside the editor preview.
	 *
	 * @return void
	 */
	public static function enqueue_preview_scripts() {
	}

	/**
	 * Enqueue editor assets
	 *
	 * @return void
	 */
	public static function editor_enqueue() {

		$suffix = wk_is_script_debug_enabled() ? '.' : '.min.';

		wp_enqueue_style(
			'wakoo-icons',
			WAKOO_ASSETS . 'fonts/style.min.css',
			null,
			WAKOO_VERSION
		);

		wp_enqueue_style(
			'wakoo-editor',
			WAKOO_ASSETS . 'admin/css/editor'.$suffix.'css',
			null,
			WAKOO_VERSION
		);

		wp_enqueue_script(
			'wakoo-editor',
			WAKOO_ASSETS . 'admin/js/editor'.$suffix.'js',
			['elementor-editor', 'jquery'],
			WAKOO_VERSION,
			true
		);

		Library_Manager::enqueue_assets();

		/**
		 * Make sure to enqueue this at the end
		 * otherwise it may not work properly
		 */
		self::enqueue_dark_stylesheet();

		$localize_data = [
			'placeholder_widgets' => [],
			'hasPro'                  => wk_has_pro(),
			'editor_nonce'            => wp_create_nonce('wk_editor_nonce'),
			'dark_stylesheet_url'     => self::get_dark_stylesheet_url(),
			'i18n' => [
				'promotionDialogHeader'     => esc_html__('%s Widget', 'wakoo'),
				'promotionDialogMessage'    => esc_html__('Use %s widget with other exclusive pro widgets and 100% unique features to extend your toolbox and build sites faster and better.', 'wakoo'),
				'promotionDialogBtnTxt'    => esc_html__('Upgrade Now', 'wakoo'),
				'templatesEmptyTitle'       => esc_html__('No Templates Found', 'wakoo'),
				'templatesEmptyMessage'     => esc_html__('Try different category or sync for new templates.', 'wakoo'),
				'templatesNoResultsTitle'   => esc_html__('No Results Found', 'wakoo'),
				'templatesNoResultsMessage' => esc_html__('Please make sure your search is spelled correctly or try a different words.', 'wakoo'),
			],
		];

		if (!wk_has_pro() && wk_is_elementor_version('>=', '2.9.0')) {
			$localize_data['placeholder_widgets'] = Widgets_Manager::get_pro_widget_map();
		}

		wp_localize_script(
			'wakoo-editor',
			'WakooEditor',
			$localize_data
		);
	}

	/**
	 * Enqueue stylesheets only for preview window
	 * editing mode basically.
	 *
	 * @return void
	 */
	public static function enqueue_preview_styles() {
		$data = '
		.elementor-add-section[data-view=choose-action] .elementor-add-new-section {
			display: inline-flex !important;
			flex-wrap: wrap;
			align-items: center;
			justify-content: center;
		}
		.elementor-add-section-drag-title{
			flex-basis: 100%;
		}
		.elementor-add-new-section .elementor-add-wk-button {
			background-color: #5636d1;
			margin-left: 5px;
			font-size: 20px;
			color: #fff;
			display: flex;
			align-items: center;
			justify-content: center;
		}
		';
		wp_add_inline_style('wakoo', $data);
	}

}
