<?php

namespace Wakoo\Elementor\Classes;

use Elementor\Element_Base;
// use Wakoo\Elementor\Classes\Dashboard;

defined('ABSPATH') || die();

class Widgets_Manager {

	const WIDGETS_DB_KEY = 'wakoo_inactive_widgets';
	// public static $catwise_widget_map = [];

	public static function add_global_widget_render_attributes(Element_Base $widget) {
		if ($widget->get_name() === 'global' && method_exists($widget, 'get_original_element_instance')) {
			$original_instance = $widget->get_original_element_instance();
			if (method_exists($original_instance, 'get_html_wrapper_class') && strpos($original_instance->get_data('widgetType'), 'wk-') !== false) {
				$widget->add_render_attribute('_wrapper', [
					'class' => $original_instance->get_html_wrapper_class(),
				]);
			}
		}
	}

	public static function get_inactive_widgets() {
		return get_option(self::WIDGETS_DB_KEY, []);
	}

	public static function save_inactive_widgets($widgets = []) {
		update_option(self::WIDGETS_DB_KEY, $widgets);
	}

	public static function get_widgets_map() {
		$widgets_map = [
			self::get_base_widget_key() => [
				'css'    => ['common'],
				'js'     => [],
				'vendor' => [
					'js'  => [],
					'css' => ['wakoo-icons', 'font-awesome'],
				],
			],
		];

		$local_widgets_map = self::get_local_widgets_map();
		$widgets_map       = array_merge($widgets_map, $local_widgets_map);

		// This will be remove after march/2022 pro relese
		// $pro_widget_map = array_replace_recursive(self::get_pro_widget_map(), apply_filters( 'wakoo_get_widgets_map', [] ));

		// This will be used after march/2022 pro relese
		// $pro_widget_map = apply_filters( 'wakoo_get_widgets_map', self::get_pro_widget_map() );

		// return array_merge($widgets_map, $pro_widget_map);
		return wk_safe_apply_filters('wakoo_get_widgets_map', $widgets_map);
	}

	/**
	 * Get the pro widgets map for dashboard only
	 *
	 * @return array
	 */
	public static function get_pro_widget_map() { return [];
		return [
			'accordion'                 => [
				'cat'    => 'general',
				'title'  => __('Advanced Accordion', 'wakoo'),
				'icon'   => 'hm hm-accordion-vertical',
				'is_pro' => true,
				'demo'      => '',
			],
			'advanced-comparison-table'    => [
				'cat'       => 'creative',
				'title'     => __('Advanced Comparison Table', 'wakoo'),
				'icon'      => 'hm hm-link-box',
				'is_pro' => true,
				'demo'      => '',
			],
			'advanced-data-table'       => [
				'cat'    => 'general',
				'title'  => __('Advanced Data Table', 'wakoo'),
				'icon'   => 'hm hm-data-table',
				'is_pro' => true,
				'demo'      => '',
			],
			'advanced-flip-box'         => [
				'cat'    => 'creative',
				'title'  => __('Advanced Flip Box', 'wakoo'),
				'icon'   => 'hm hm-flip-card1',
				'is_pro' => true,
				'demo'      => '',
			],
			'advanced-heading'          => [
				'cat'    => 'general',
				'title'  => __('Advanced Heading', 'wakoo'),
				'icon'   => 'hm hm-advanced-heading',
				'is_pro' => true,
				'demo'      => '',
			],
			'advanced-pricing-table'    => [
				'cat'    => 'marketing',
				'title'  => __('Advanced Pricing Table', 'wakoo'),
				'icon'   => 'hm hm-file-cabinet',
				'is_pro' => true,
				'demo'      => '',
			],
			'advanced-search' => [
				'cat'    => 'general',
				'title'  => __('Advanced Search', 'wakoo'),
				'icon'   => 'hm hm-search',
				'is_pro' => true,
				'demo'   => '',
			],
			'advanced-slider'           => [
				'cat'    => 'slider-&-carousel',
				'title'  => __('Advanced Slider', 'wakoo'),
				'icon'   => 'hm hm-slider',
				'is_pro' => true,
				'demo'      => '',
			],
			'advanced-tabs'             => [
				'cat'    => 'general',
				'title'  => __('Advanced Tabs', 'wakoo'),
				'icon'   => 'hm hm-tab',
				'is_pro' => true,
				'demo'      => '',
			],
			'animated-text'             => [
				'cat'    => 'creative',
				'title'  => __('Animated Text', 'wakoo'),
				'icon'   => 'hm hm-text-animation',
				'is_pro' => true,
				'demo'      => '',
			],
			'author-list'               => [
				'cat'    => 'post',
				'title'  => __('Author List', 'wakoo'),
				'icon'   => 'hm hm-user-male',
				'is_pro' => true,
				'demo'      => '',
			],
			'breadcrumbs'               => [
				'cat'    => 'general',
				'title'  => __('Breadcrumbs', 'wakoo'),
				'icon'   => 'hm hm-breadcrumbs',
				'is_pro' => true,
				'demo'      => '',
			],
			'business-hour'             => [
				'cat'    => 'general',
				'title'  => __('Business Hour', 'wakoo'),
				'icon'   => 'hm hm-hand-watch',
				'is_pro' => true,
				'demo'      => '',
			],
			'countdown'                 => [
				'cat'    => 'general',
				'title'  => __('Countdown', 'wakoo'),
				'icon'   => 'hm hm-refresh-time',
				'is_pro' => true,
				'demo'      => '',
			],
			'creative-slider' => [
				'cat' => 'slider-&-carousel',
				'title' => __('Creative Slider', 'wakoo'),
				'icon' => 'hm hm-slider',
				'is_pro' => true,
				'demo'      => '',
			],
			'edd-cart' => [
				'cat' => 'easy-digital-downloads',
				'title' => __('EDD Cart', 'wakoo'),
				'icon' => 'hm hm-cart',
				'is_pro' => true,
				'demo'      => '',
			],
			'edd-category-carousel'     => [
				'cat'    => 'Easy Digital Downloads',
				'title'  => __('EDD Category Carousel', 'wakoo'),
				'icon'   => 'hm hm-Category-Carousel',
				'is_pro' => true,
				'demo'      => '',
			],
			'edd-category-grid'         => [
				'cat'    => 'Easy Digital Downloads',
				'title'  => __('EDD Category Grid', 'wakoo'),
				'icon'   => 'hm hm-Category-Carousel',
				'is_pro' => true,
				'demo'      => '',
			],
			'edd-checkout' => [
				'cat' => 'easy-digital-downloads',
				'title' => __('EDD Checkout', 'wakoo'),
				'icon' => 'hm hm-checkout-2',
				'is_pro' => true,
				'demo'      => '',
			],
			'edd-download' => [
				'cat' => 'easy-digital-downloads',
				'title' => __('EDD Download', 'wakoo'),
				'icon' => 'hm hm-Download-circle',
				'is_pro' => true,
				'demo'      => '',
			],
			'edd-login' => [
				'cat' => 'easy-digital-downloads',
				'title' => __('EDD Login', 'wakoo'),
				'icon' => 'hm hm-checkout-2',
				'is_pro' => true,
				'demo'      => '',
			],
			'edd-product-carousel'      => [
				'cat'    => 'Easy Digital Downloads',
				'title'  => __('EDD Product Carousel', 'wakoo'),
				'icon'   => 'hm hm-Product-Carousel',
				'is_pro' => true,
				'demo'      => '',
			],
			'edd-product-grid'          => [
				'cat'    => 'Easy Digital Downloads',
				'title'  => __('EDD Product Grid', 'wakoo'),
				'icon'   => 'hm hm-product-grid',
				'is_pro' => true,
				'demo'      => '',
			],
			'edd-purchase' => [
				'cat' => 'easy-digital-downloads',
				'title' => __('EDD Purchase', 'wakoo'),
				'icon' => 'hm hm-user-plus',
				'is_pro' => true,
				'demo'      => '',
			],
			'edd-register' => [
				'cat' => 'easy-digital-downloads',
				'title' => __('EDD Register', 'wakoo'),
				'icon' => 'hm hm-user-plus',
				'is_pro' => true,
				'demo'      => '',
			],
			'edd-single-product'        => [
				'cat'    => 'Easy Digital Downloads',
				'title'  => __('EDD Single Product', 'wakoo'),
				'icon'   => 'hm hm-Category-Carousel',
				'is_pro' => true,
				'demo'      => '',
			],
			'facebook-feed'             => [
				'cat'    => 'social-media',
				'title'  => __('Facebook Feed', 'wakoo'),
				'icon'   => 'hm hm-facebook',
				'is_pro' => true,
				'demo'      => '',
			],
			'feature-list'              => [
				'cat'    => 'general',
				'title'  => __('Feature List', 'wakoo'),
				'icon'   => 'hm hm-list-2',
				'is_pro' => true,
				'demo'      => '',
			],
			'featured-post' => [
				'cat'    => 'post',
				'title'  => __('Featured Post', 'wakoo'),
				'icon'   => 'hm hm-tb-post-info',
				'is_pro' => true,
				'demo'   => '',
			],
			'google-map'                => [
				'cat'    => 'general',
				'title'  => __('Advanced Google Map', 'wakoo'),
				'icon'   => 'hm hm-map-marker',
				'is_pro' => true,
				'demo'      => '',
			],
			'wakoo-loop-grid' => [
				'cat'    => 'post',
				'title'  => __('Wakoo Loop Grid', 'wakoo'),
				'icon'   => 'hm hm-loop-grid-content-slider',
				'is_pro' => true,
				'demo'   => '',
			],
			'wakoo-nested-hover-list' => [
				'cat'       => 'general',
				'title'     => __('Hover Accordion', 'wakoo-pro'),
				'icon'      => 'hm hm-list',
				'demo'      => '',
				'is_pro' => true,
			],
			'hotspots'                  => [
				'cat'    => 'creative',
				'title'  => __('Hotspots', 'wakoo'),
				'icon'   => 'hm hm-accordion-vertical',
				'is_pro' => true,
				'demo'      => '',
			],
			'hover-box'                 => [
				'cat'    => 'creative',
				'title'  => __('Hover Box', 'wakoo'),
				'icon'   => 'hm hm-finger-point',
				'is_pro' => true,
				'demo'      => '',
			],
			'image-scroller'            => [
				'cat'    => 'creative',
				'title'  => __('Single Image Scroll', 'wakoo'),
				'icon'   => 'hm hm-image-scroll',
				'is_pro' => true,
				'demo'      => '',
			],
			'image-swap' => [
				'cat' => 'general',
				'title' => __( 'Image Swap', 'wakoo' ),
				'icon' => 'hm hm-image-scroll',
				'is_pro' => true,
				'demo'      => '',
			],
			'instagram-feed'            => [
				'cat'    => 'social-media',
				'title'  => __('Instagram Feed', 'wakoo'),
				'icon'   => 'hm hm-instagram',
				'is_pro' => true,
				'demo'      => '',
			],
			'line-chart'                => [
				'cat'    => 'chart',
				'title'  => __('Line Chart', 'wakoo'),
				'icon'   => 'hm hm-line-graph-pointed',
				'is_pro' => true,
				'demo'      => '',
			],
			'list-group'                => [
				'cat'    => 'general',
				'title'  => __('List Group', 'wakoo'),
				'icon'   => 'hm hm-list-group',
				'is_pro' => true,
				'demo'      => '',
			],
			'logo-carousel'             => [
				'cat'    => 'slider-&-carousel',
				'title'  => __('Logo Carousel', 'wakoo'),
				'icon'   => 'hm hm-logo-carousel',
				'is_pro' => true,
				'demo'      => '',
			],
			'loop-tab' => [
				'cat' => 'creative',
				'title' => __('Loop Tab', 'wakoo'),
				'icon' => 'hm hm-edd-my-account-tab',
				'is_pro' => true,
				'demo'      => '',
			],
			'metro-grid' => [
				'cat' => 'general',
				'title' => __('Metro Grid', 'wakoo'),
				'icon' => 'hm hm-metro-grid-text-outline',
				'is_pro' => true,
				'demo'      => '',
			],
			'mini-cart'                 => [
				'cat'    => 'woocommerce',
				'title'  => __('Mini Cart', 'wakoo'),
				'icon'   => 'hm hm-mini-cart',
				'is_pro' => true,
				'demo'      => '',
			],
			'modal-popup'               => [
				'cat'    => 'general',
				'title'  => __('Modal Popup', 'wakoo'),
				'icon'   => 'hm hm-popup',
				'is_pro' => true,
				'demo'      => '',
			],
			'multi-scroll' => [
				'title' => __( 'Multi Scroll', 'wakoo' ),
				'icon' => 'hm hm-multi-page-scroll',
				'is_pro' => true,
				'demo'      => '',
			],
			'nav-menu'                  => [
				'cat'    => 'general',
				'title'  => __('Wakoo Menu', 'wakoo'),
				'icon'   => 'hm hm-mega-menu',
				'is_pro' => true,
				'demo'      => '',
			],
			'off-canvas'                => [
				'cat'    => 'creative',
				'title'  => __('Off Canvas', 'wakoo'),
				'icon'   => 'hm hm-offcanvas-menu',
				'is_pro' => true,
				'demo'      => '',
			],
			'one-page-nav'              => [
				'cat'    => 'creative',
				'title'  => __('One Page Nav', 'wakoo'),
				'icon'   => 'hm hm-dot-navigation',
				'is_pro' => true,
				'demo'      => '',
			],
			'pie-chart'                 => [
				'cat'    => 'chart',
				'title'  => __('Pie & Doughnut Chart', 'wakoo'),
				'icon'   => 'hm hm-graph-pie',
				'is_pro' => true,
				'demo'      => '',
			],
			'polar-chart'               => [
				'cat'    => 'chart',
				'title'  => __('Polar area Chart', 'wakoo'),
				'icon'   => 'hm hm-graph-pie',
				'is_pro' => true,
				'demo'      => '',
			],
			'post-carousel'             => [
				'cat'    => 'post',
				'title'  => __('Post Carousel', 'wakoo'),
				'icon'   => 'hm hm-graph-pie',
				'is_pro' => true,
				'demo'      => '',
			],
			'post-grid-new'                 => [
				'cat'    => 'post',
				'title'  => __('Post Grid', 'wakoo'),
				'icon'   => 'hm hm-post-grid',
				'is_pro' => true,
				'demo'      => '',
			],
			'post-tiles'                => [
				'cat'    => 'post',
				'title'  => __('Post Tiles', 'wakoo'),
				'icon'   => 'hm hm-article',
				'is_pro' => true,
				'demo'      => '',
			],
			'price-menu'                => [
				'cat'    => 'marketing',
				'title'  => __('Price Menu', 'wakoo'),
				'icon'   => 'hm hm-menu-price',
				'is_pro' => true,
				'demo'      => '',
			],
			'product-carousel-new'          => [
				'cat'    => 'woocommerce',
				'title'  => __('Product Carousel', 'wakoo'),
				'icon'   => 'hm hm-Product-Carousel',
				'is_pro' => true,
				'demo'      => '',
			],
			'product-category-carousel-new' => [
				'cat'    => 'woocommerce',
				'title'  => __('Product Category Carousel', 'wakoo'),
				'icon'   => 'hm hm-Category-Carousel',
				'is_pro' => true,
				'demo'      => '',
			],
			'product-category-grid-new'     => [
				'cat'    => 'woocommerce',
				'title'  => __('Product Category Grid', 'wakoo'),
				'icon'   => 'hm hm-Category-Carousel',
				'is_pro' => true,
				'demo'      => '',
			],
			'product-grid-new'              => [
				'cat'    => 'woocommerce',
				'title'  => __('Product Grid', 'wakoo'),
				'icon'   => 'hm hm-Product-Grid',
				'is_pro' => true,
				'demo'      => '',
			],
			'promo-box'                 => [
				'cat'    => 'marketing',
				'title'  => __('Promo Box', 'wakoo'),
				'icon'   => 'hm hm-promo',
				'is_pro' => true,
				'demo'      => '',
			],
			'radar-chart'               => [
				'cat'    => 'chart',
				'title'  => __('Radar Chart', 'wakoo'),
				'icon'   => 'hm hm-graph-pie',
				'is_pro' => true,
				'demo'      => '',
			],
			'remote-carousel' => [
				'cat' => 'slider-&-carousel',
				'title' => __('Remote Carousel', 'wakoo'),
				'icon' => 'hm hm-remote_carousel',
				'is_pro' => true,
				'demo'      => '',
			],
			'scroll-sequence' => [
				'cat'    => 'creative',
				'title'  => __('Scroll Sequence', 'wakoo'),
				'icon'   => 'hm hm-magic-scroll',
				'is_pro' => true,
				'demo'   => '',
			],
			'scroll-tabs' => [
				'cat'    => 'creative',
				'title'  => __('Scroll Tabs', 'wakoo'),
				'icon'   => 'hm hm-up-down',
				'is_pro' => true,
				'demo'   => '',
			],
			'scrolling-image'           => [
				'cat'    => 'creative',
				'title'  => __('Scrolling Image', 'wakoo'),
				'icon'   => 'hm hm-scrolling-image',
				'is_pro' => true,
				'demo'      => '',
			],
			'shipping-bar' => [
				'cat' => 'woocommerce',
				'title' => __('Shipping Bar', 'wakoo'),
				'icon' => 'hm hm-shipping-address',
				'is_pro' => true,
				'demo'      => '',
			],
			'single-product-new'            => [
				'cat'    => 'woocommerce',
				'title'  => __('Single Product', 'wakoo'),
				'icon'   => 'hm hm-Category-Carousel',
				'is_pro' => true,
				'demo'      => '',
			],
			'smart-post-list'           => [
				'cat'    => 'post',
				'title'  => __('Smart Post List', 'wakoo'),
				'icon'   => 'hm hm-post-list',
				'is_pro' => true,
				'demo'      => '',
			],
			'source-code'               => [
				'cat'    => 'general',
				'title'  => __('Source Code', 'wakoo'),
				'icon'   => 'hm hm-code-browser',
				'is_pro' => true,
				'demo'      => '',
			],
			'stacked-card' => [
				'cat' => 'creative',
				'title' => __('Stacked Card', 'wakoo'),
				'icon' => 'hm hm-photo-stack',
				'demo'      => '',
				'is_pro' => true,
			],
			'sticky-video'              => [
				'cat'    => 'general',
				'title'  => __('Sticky Video', 'wakoo'),
				'icon'   => 'hm hm-sticky-video',
				'is_pro' => true,
				'demo'      => '',
			],
			'super-button' => [
				'cat'    => 'creative',
				'title'  => __('Super Button', 'wakoo'),
				'icon'   => 'hm hm-fixed-size-button',
				'is_pro' => true,
				'demo'   => '',
			],
			'svg-morphing' => [
				'cat' => 'creative',
				'title' => __('SVG Morphing', 'wakoo'),
				'icon' => 'hm hm-hexa',
				'demo'      => '',
				'is_pro' => true,
			],
			'table-of-contents' => [
				'cat' => 'general',
				'title' => __('Table of Contents', 'wakoo'),
				'icon' => 'hm hm-list-2',
				'is_pro' => true,
				'demo'      => '',
			],
			'team-carousel'             => [
				'cat'    => 'slider-&-carousel',
				'title'  => __('Team Carousel', 'wakoo'),
				'icon'   => 'hm hm-team-carousel',
				'is_pro' => true,
				'demo'      => '',
			],
			'team-hover-grid' => [
				'cat' => 'creative',
				'title' => __('Team Hover Grid', 'wakoo-pro'),
				'icon' => 'hm hm-User-Circle',
				'demo'      => '',
				'is_pro' => true,
			],
			'testimonial-carousel'      => [
				'cat'    => 'slider-&-carousel',
				'title'  => __('Testimonial Carousel', 'wakoo'),
				'icon'   => 'hm hm-testimonial-carousel',
				'is_pro' => true,
				'demo'      => '',
			],
			'timeline'                  => [
				'cat'    => 'general',
				'title'  => __('Timeline', 'wakoo'),
				'icon'   => 'hm hm-timeline',
				'is_pro' => true,
				'demo'      => '',
			],
			'title-tips' => [
				'cat' => 'general',
				'title' => __('Title Tips', 'wakoo'),
				'icon' => 'hm hm-title-tips-vector-path',
				'is_pro' => true,
				'demo'      => '',
			],
			'toggle'                    => [
				'cat'    => 'general',
				'title'  => __('Advanced Toggle', 'wakoo'),
				'icon'   => 'hm hm-accordion-vertical',
				'is_pro' => true,
				'demo'      => '',
			],
			'twitter-carousel'          => [
				'cat'    => 'social-media',
				'title'  => __('X Feed Carousel', 'wakoo'),
				'icon'   => 'hm hm-twitter',
				'is_pro' => true,
				'demo'      => '',
			],
			'unfold'                    => [
				'cat'    => 'general',
				'title'  => __('Unfold', 'wakoo'),
				'icon'   => 'hm hm-unfold-paper',
				'is_pro' => true,
				'demo'      => '',
			],
			'visual-tabs' => [
				'cat'       => 'general',
				'title'     => __('Visual Tabs', 'wakoo-pro'),
				'icon'      => 'hm hm-cta',
				'demo'      => '',
				'is_pro'    => true,	
			],
			'wc-cart'                   => [
				'cat'    => 'woocommerce',
				'title'  => __('WooCommerce Cart', 'wakoo'),
				'icon'   => 'hm hm-cart',
				'is_pro' => true,
				'demo'      => '',
			],
			'wc-checkout'               => [
				'cat'    => 'woocommerce',
				'title'  => __('WooCommerce Checkout', 'wakoo'),
				'icon'   => 'hm hm-cart',
				'is_pro' => true,
				'demo'      => '',
			],
];
	}

	/**
	 * Get the free widgets map
	 *
	 * @return array
	 */
	public static function get_local_widgets_map() {
		// All the widgets are listed below with respective map

		return [
			'infobox'             => [
				'cat'       => 'general',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Info Box', 'wakoo'),
				'icon'      => 'hm hm-info',
				'css'       => ['btn', 'infobox'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'card'                => [
				'cat'       => 'creative',
				'is_active' => false,
				'demo'      => '',
				'title'     => __('Card', 'wakoo'),
				'icon'      => 'hm hm-card',
				'css'       => ['btn', 'badge', 'card'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'icon-box'            => [
				'cat'       => 'general',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Icon Box', 'wakoo'),
				'icon'      => 'hm hm-icon-box',
				'css'       => ['badge', 'icon-box'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'member'              => [
				'cat'       => 'general',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Team Member', 'wakoo'),
				'icon'      => 'hm hm-team-member',
				'css'       => ['btn', 'member'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'review'              => [
				'cat'       => 'general',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Review', 'wakoo'),
				'icon'      => 'hm hm-review',
				'css'       => ['review'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'image-compare'       => [
				'cat'       => 'general',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Image Compare', 'wakoo'),
				'icon'      => 'hm hm-image-compare',
				'css'       => ['image-comparison'],
				'js'        => [],
				'vendor'    => [
					'css' => ['twentytwenty'],
					'js'  => ['jquery-event-move', 'jquery-twentytwenty', 'imagesloaded'],
				],
			],
			'justified-gallery'   => [
				'cat'       => 'creative',
				'is_active' => false,
				'demo'      => '',
				'title'     => __('Justified Grid', 'wakoo'),
				'icon'      => 'hm hm-brick-wall',
				'css'       => ['justified-gallery', 'gallery-filter'],
				'js'        => [],
				'vendor'    => [
					'css' => ['justifiedGallery', 'magnific-popup'],
					'js'  => ['jquery-justifiedGallery', 'jquery-magnific-popup'],
				],
			],
			'image-grid'          => [
				'cat'       => 'general',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Image Grid', 'wakoo'),
				'icon'      => 'hm hm-grid-even',
				'css'       => ['image-grid', 'gallery-filter'],
				'js'        => [],
				'vendor'    => [
					'css' => ['magnific-popup'],
					'js'  => ['jquery-isotope', 'jquery-magnific-popup', 'imagesloaded'],
				],
			],
			'slider'              => [
				'cat'       => 'slider-&-carousel',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Slider', 'wakoo'),
				'icon'      => 'hm hm-image-slider',
				'css'       => ['slider-carousel'],
				'js'        => [],
				'vendor'    => [
					'css' => ['slick', 'slick-theme'],
					'js'  => ['jquery-slick'],
				],
			],
			'carousel'            => [
				'cat'       => 'slider-&-carousel',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Image Carousel', 'wakoo'),
				'icon'      => 'hm hm-carousal',
				'css'       => ['slider-carousel'],
				'js'        => [],
				'vendor'    => [
					'css' => ['slick', 'slick-theme'],
					'js'  => ['jquery-slick'],
				],
			],
			'skills'              => [
				'cat'       => 'general',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Skill Bars', 'wakoo'),
				'icon'      => 'hm hm-progress-bar',
				'css'       => ['skills'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => ['jquery-numerator'],
				],
			],
			'gradient-heading'    => [
				'cat'       => 'creative',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Gradient Heading', 'wakoo'),
				'icon'      => 'hm hm-drag',
				'css'       => ['gradient-heading'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'logo-grid'           => [
				'cat'       => 'general',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Logo Grid', 'wakoo'),
				'icon'      => 'hm hm-logo-grid',
				'css'       => ['logo-grid'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'dual-button'         => [
				'cat'       => 'general',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Dual Button', 'wakoo'),
				'icon'      => 'hm hm-accordion-horizontal',
				'css'       => ['dual-btn'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'testimonial'         => [
				'cat'       => 'general',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Testimonial', 'wakoo'),
				'icon'      => 'hm hm-testimonial',
				'css'       => ['testimonial'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'number'              => [
				'cat'       => 'creative',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Number', 'wakoo'),
				'icon'      => 'hm hm-madel',
				'css'       => ['number'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => ['jquery-numerator'],
				],
			],
			'flip-box'            => [
				'cat'       => 'creative',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Flip Box', 'wakoo'),
				'icon'      => 'hm hm-flip-card1',
				'css'       => ['flip-box'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'pricing-table'       => [
				'cat'       => 'marketing',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Pricing Table', 'wakoo'),
				'icon'      => 'hm hm-file-cabinet',
				'css'       => ['pricing-table'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'step-flow'           => [
				'cat'       => 'general',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Step Flow', 'wakoo'),
				'icon'      => 'hm hm-step-flow',
				'css'       => ['steps-flow'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'news-ticker'         => [
				'cat'       => 'general',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('News Ticker', 'wakoo'),
				'icon'      => 'hm hm-slider',
				'css'       => ['news-ticker'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => ['jquery-keyframes'],
				],
			],
			'fun-factor'          => [
				'cat'       => 'creative',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Fun Factor', 'wakoo'),
				'icon'      => 'hm hm-slider',
				'css'       => ['fun-factor'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => ['jquery-numerator'],
				],
			],
			'bar-chart'           => [
				'cat'       => 'chart',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Bar Chart', 'wakoo'),
				'icon'      => 'hm hm-graph-bar',
				'css'       => ['chart'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => ['chart-js'],
				],
			],
			'social-icons'        => [
				'cat'       => 'social-media',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Social Icons', 'wakoo'),
				'icon'      => 'hm hm-bond2',
				'css'       => ['social-icons'],
				'js'        => [],
				'vendor'    => [
					'css' => ['hover-css'],
					'js'  => [],
				],
			],
			'post-list'           => [
				'cat'       => 'post',
				'is_active' => true,
				'title'     => __('Post List', 'wakoo'),
				'icon'      => 'hm hm-post-list',
				'css'       => ['post-list'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'post-tab'            => [
				'cat'       => 'post',
				'is_active' => true,
				'title'     => __('Post Tab', 'wakoo'),
				'icon'      => 'hm hm-post-tab',
				'css'       => ['post-tab'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'taxonomy-list'       => [
				'cat'       => 'post',
				'is_active' => true,
				'title'     => __('Taxonomy List', 'wakoo'),
				'icon'      => 'hm hm-clip-board',
				'css'       => ['taxonomy-list'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'threesixty-rotation' => [
				'cat'       => 'general',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('360° Rotation', 'wakoo'),
				'icon'      => 'hm hm-3d-rotate',
				'css'       => ['threesixty-rotation'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => ['circlr', 'wk-simple-magnify'],
				],
			],
			'data-table'          => [
				'cat'       => 'general',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Data Table', 'wakoo'),
				'icon'      => 'hm hm-data-table',
				'css'       => ['data-table'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'horizontal-timeline' => [
				'cat'       => 'general',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Horizontal Timeline', 'wakoo'),
				'icon'      => 'hm hm-timeline',
				'css'       => ['horizontal-timeline'],
				'js'        => [],
				'vendor'    => [
					'css' => ['slick', 'slick-theme', 'magnific-popup'],
					'js'  => ['jquery-slick', 'jquery-magnific-popup'],
				],
			],
			'social-share'        => [
				'cat'       => 'social-media',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Social Share', 'wakoo'),
				'icon'      => 'hm hm-share',
				'css'       => ['social-share'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => ['sharer-js'],
				],
			],
			'image-hover-effect'  => [
				'cat'       => 'creative',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Image Hover Effect', 'wakoo'),
				'icon'      => 'hm hm-cursor-hover-click',
				'css'       => ['image-hover-effect'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'event-calendar'      => [
				'cat'       => 'general',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Event Calendar', 'wakoo'),
				'icon'      => 'hm hm-event-calendar',
				'css'       => ['event-calendar'],
				'js'        => [],
				'vendor'    => [
					'css' => ['wk-fullcalendar'],
					'js'  => ['wk-fullcalendar', 'wk-fullcalendar-locales'],
				],
			],
			'link-hover'          => [
				'cat'       => 'creative',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Animated Link', 'wakoo'),
				'icon'      => 'hm hm-animated-link',
				'css'       => ['link-hover'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'image-accordion'     => [
				'cat'       => 'general',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Image Accordion', 'wakoo'),
				'icon'      => 'hm hm-slider-image',
				'css'       => ['image-accordion'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'content-switcher'    => [
				'cat'       => 'general',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Content Switcher', 'wakoo'),
				'icon'      => 'hm hm-switcher',
				'css'       => ['content-switcher'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'image-stack-group'   => [
				'cat'       => 'creative',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Image Stack Group', 'wakoo'),
				'icon'      => 'hm hm-lens',
				'css'       => ['circle-image-group'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'creative-button'     => [
				'cat'       => 'creative',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Creative Button', 'wakoo'),
				'icon'      => 'hm hm-motion-button',
				'css'       => ['creative-button'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'pdf-view'            => [
				'cat'       => 'creative',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('PDF View', 'wakoo'),
				'icon'      => 'hm hm-pdf2',
				'css'       => ['pdf'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => ['pdf-js'],
				],
			],
			'comparison-table'    => [
				'cat'       => 'creative',
				'is_active' => true,
				'demo' => 	'',
				'title'     => __('Comparison Table', 'wakoo'),
				'icon'      => 'hm hm-scale',
				'css'       => ['comparison-table'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'photo-stack'         => [
				'cat'       => 'creative',
				'is_active' => true,
				'demo'      => '',
				'title'     => __('Photo Stack', 'wakoo'),
				'icon'      => 'hm hm-lens',
				'css'       => ['photo-stack'],
				'js'        => [],
				'vendor'    => [
					'css' => [],
					'js'  => [],
				],
			],
			'page-title' => [
				'cat' => 'theme-builder',
				'is_active' => false,
				'demo' => '',
				'title' => __('Page Title', 'wakoo'),
				'icon' => 'hm hm-tb-page-title',
				'css' => [''],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'post-title' => [
				'cat' => 'theme-builder',
				'is_active' => true,
				'demo' => '',
				'title' => __('Post Title', 'wakoo'),
				'icon' => 'hm hm-tb-page-title',
				'css' => [''],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'post-content' => [
				'cat' => 'theme-builder',
				'is_active' => true,
				'demo' => '',
				'title' => __('Post Content', 'wakoo'),
				'icon' => 'hm hm-tb-post-content',
				'css' => [''],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'post-excerpt' => [
				'cat' => 'theme-builder',
				'is_active' => false,
				'demo' => '',
				'title' => __('Post Excerpt', 'wakoo'),
				'icon' => 'hm hm-tb-post-excerpt',
				'css' => [''],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'site-logo' => [
				'cat' => 'theme-builder',
				'is_active' => true,
				'demo' => '',
				'title' => __('Site Logo', 'wakoo'),
				'icon' => 'hm hm-tb-site-logo',
				'css' => [''],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'site-title' => [
				'cat' => 'theme-builder',
				'is_active' => true,
				'demo' => '',
				'title' => __('Site Title', 'wakoo'),
				'icon' => 'hm hm-tb-site-title',
				'css' => ['site-title'],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'site-tagline' => [
				'cat' => 'theme-builder',
				'is_active' => false,
				'demo' => '',
				'title' => __('Site Tagline', 'wakoo'),
				'icon' => 'hm hm-tag',
				'css' => ['site-tagline'],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'author-meta' => [
				'cat' => 'theme-builder',
				'is_active' => true,
				'demo' => '',
				'title' => __('Author Meta', 'wakoo'),
				'icon' => 'hm hm-tb-author-meta',
				'css' => ['author'],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'post-info' => [
				'cat' => 'theme-builder',
				'is_active' => true,
				'title' => __('Post Meta', 'wakoo'),
				'icon' => 'hm hm-tb-post-info',
				'css' => ['post-info'],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'archive-title' => [
				'cat' => 'theme-builder',
				'is_active' => true,
				'demo' => '',
				'title' => __('Archive Title', 'wakoo'),
				'icon' => 'hm hm-tb-archieve-title',
				'css' => [''],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'archive-posts' => [
				'cat' => 'theme-builder',
				'is_active' => true,
				'demo' => '',
				'title' => __('Archive Posts', 'wakoo'),
				'icon' => 'hm hm-tb-archieve-content',
				'css' => ['archive-posts'],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'post-comments' => [
				'cat' => 'theme-builder',
				'is_active' => true,
				'demo' => '',
				'title' => __('Post Comments', 'wakoo'),
				'icon' => 'hm hm-comment-square',
				'css' => [''],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'post-navigation' => [
				'cat' => 'theme-builder',
				'is_active' => true,
				'demo' => '',
				'title' => __('Post Navigation', 'wakoo'),
				'icon' => 'hm hm-breadcrumbs',
				'css' => ['post-navigation'],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'post-featured-image' => [
				'cat' => 'theme-builder',
				'is_active' => true,
				'title' => __('Post featured image', 'wakoo'),
				'icon' => 'hm hm-tb-featured-image',
				'css' => [''],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'navigation-menu' => [
				'cat' => 'theme-builder',
				'is_active' => true,
				'demo' => '',
				'title' => __('Nav Menu', 'wakoo'),
				'icon' => 'hm hm-clip-board',
				'css' => ['navigation-menu'],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'age-gate' => [
				'cat' => 'general',
				'is_active' => true,
				'demo' => '',
				'title' => __('Age Gate', 'wakoo'),
				'icon' => 'hm hm-age-gate',
				'css' => ['age-gate'],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'lightbox' => [
				'cat' => 'general',
				'is_active' => true,
				'demo' => '',
				'title' => __('Lightbox', 'wakoo'),
				'icon' => 'hm hm-video-gallery',
				'css' => ['lightbox'],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'liquid-hover-image' => [
				'cat' => 'general',
				'is_active' => true,
				'demo' => '',
				'title' => __('Liquid Hover Image', 'wakoo'),
				'icon' => 'hm hm-liquid-hover-image',
				'css' => ['liquid-hover-image'],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => ['three','hover-effect','anime'],
				],
			],
			'text-scroll' => [
				'cat' => 'creative',
				'is_active' => true,
				'demo' => '',
				'title' => __('Text Scroll', 'wakoo'),
				'icon' => 'hm hm-mouse-scroll-v',
				'css' => ['text-scroll'],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'svg-draw' => [
				'cat' => 'creative',
				'is_active' => true,
				'demo' => '',
				'title' => __('SVG Line Draw', 'wakoo'),
				'icon' => 'hm hm-pen',
				'css' => [''],
				'js' => [],
				'vendor' => [
					'css' => [],
					'js' => [],
				],
			],
			'whatsapp-button' => [
				'cat'       => 'social-media',
				'is_active' => true,
				'demo'      => '',
				'title'     => __( 'WhatsApp Button', 'wakoo' ),
				'icon'      => 'hm hm-circular-chat',
				'css'       => [ 'whatsapp-button' ],
				'js'        => [],
				'vendor'    => [
					'css' => [ 'font-awesome' ],
					'js'  => [],
				],
			],
		];
	}

	public static function get_base_widget_key() {
		return apply_filters('wakoo_get_base_widget_key', '_wakoo_base');
	}

	public static function get_default_active_widget() {
		$default_active = array_filter(self::get_local_widgets_map(), function ($var) {
			return $var['is_active'] == true;
		});
		return array_keys($default_active);
	}

	/**
	 * Init Widgets
	 *
	 * Include widgets files and register them
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public static function register( $widgets_manager = null) {
		include_once WAKOO_DIR_PATH . 'base/widget-base.php';

		$inactive_widgets = self::get_inactive_widgets();

		foreach (self::get_local_widgets_map() as $widget_key => $data) {
			if (!in_array($widget_key, $inactive_widgets)) {
				self::register_widget($widget_key, $widgets_manager);
			}
		}

		/**
		 * After widgets registered.
		 *
		 * Fires after Wakoo widgets are registered.
		 *
		 * @since 3.8.0
		 *
		 * @param Widgets_Manager $widgets_manager The widgets manager.
		 */
		do_action('wakoo/widgets/register', $widgets_manager);
	}

	protected static function register_widget($widget_key, $widgets_manager = null) {
		$widget_file = WAKOO_DIR_PATH . 'widgets/' . $widget_key . '/widget.php';

		if (is_readable($widget_file)) {

			// include_once $widget_file;

			$widget_class = '\Wakoo\Elementor\Widget\\' . str_replace('-', '_', $widget_key);
			if (class_exists($widget_class)) {
				$widgets_manager->register(new $widget_class());
			}
		}
	}

}
