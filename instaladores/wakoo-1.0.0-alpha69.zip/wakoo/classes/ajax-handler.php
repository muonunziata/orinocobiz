<?php

namespace Wakoo\Elementor\Classes;

defined('ABSPATH') || die();

class Ajax_Handler {


	/**
	 * Post Tab Ajax call
	 */
	public static function post_tab() {

		$security = check_ajax_referer( 'wakoo_nonce', 'security' );

		if ( true == $security ) :
			$settings   = wk_sanitize_array_recursively($_POST['post_tab_query']);
			$post_type  = $settings['post_type'];
			$taxonomy   = $settings['taxonomy'];
			$item_limit = $settings['item_limit'];
			$excerpt    = $settings['excerpt'];
			$title_tag  = $settings['title_tag'];
			$term_id    = absint($_POST['term_id']);
			$orderby    = $settings['orderby'];
			$order      = $settings['order'];

			$args = [
				'post_status'      => 'publish',
				'post_type'        => $post_type,
				'posts_per_page'   => $item_limit,
				'orderby'          => $orderby,
				'order'            => $order,
				'suppress_filters' => false,
				'tax_query'        => [
					[
						'taxonomy' => $taxonomy,
						'field'    => 'term_id',
						'terms'    => $term_id,
					],
				],
			];

			$posts = get_posts( $args );

			if ( count( $posts ) !== 0 ) :
				?>
				<div class="wk-post-tab-item-wrapper active" data-term="<?php echo esc_attr( $term_id ); ?>">
					<?php foreach ( $posts as $post ) : ?>
						<div class="wk-post-tab-item">
							<div class="wk-post-tab-item-inner">
								<?php if ( has_post_thumbnail( $post->ID ) ) : ?>
									<a href="<?php echo esc_url( get_the_permalink( $post->ID ) ); ?>" class="wk-post-tab-thumb">
										<?php echo get_the_post_thumbnail( $post->ID, 'full' ); ?>
									</a>
								<?php endif; ?>
								<?php
									printf(
										'<%1$s class="wk-post-tab-title"><a href="%2$s">%3$s</a></%1$s>',
										wk_escape_tags( $title_tag, 'h2' ),
										esc_url( get_the_permalink( $post->ID ) ),
										esc_html( $post->post_title )
									);
								?>
								<?php if ( ( 'yes' == $settings['show_user_meta'] ) || ( 'yes' == $settings['show_date_meta'] ) ) : ?>
									<div class="wk-post-tab-meta">
										<?php if ( 'yes' == $settings['show_user_meta'] ) : ?>
											<span class="wk-post-tab-meta-author">
												<i class="fa fa-user-o"></i>
												<a href="<?php echo esc_url( get_author_posts_url( $post->post_author ) ); ?>"><?php echo esc_html( get_the_author_meta( 'display_name', $post->post_author ) ); ?></a>
											</span>
										<?php endif; ?>
										<?php if ( 'yes' == $settings['show_date_meta'] ) : ?>
											<?php
											$archive_year  = get_the_time( 'Y', $post->ID );
											$archive_month = get_the_time( 'm', $post->ID );
											$archive_day   = get_the_time( 'd', $post->ID );
											?>
											<span class="wk-post-tab-meta-date">
												<i class="fa fa-calendar-o"></i>
												<a href="<?php echo esc_url( get_day_link( $archive_year, $archive_month, $archive_day ) ); ?>"><?php echo get_the_date( get_option( 'date_format' ), $post->ID ); ?></a>
											</span>
										<?php endif; ?>
									</div>
								<?php endif; ?>
								<?php if ( 'yes' === $excerpt && ! empty( $post->post_excerpt ) ) : ?>
									<div class="wk-post-tab-excerpt">
										<p><?php echo esc_html( $post->post_excerpt ); ?></p>
									</div>
								<?php endif; ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
				<?php

			endif;
		endif;
		wp_die();
	}

}
