<?php
/**
 * Dashboard home tab template
 */
defined( 'ABSPATH' ) || die();
?>
<div class="wk-dashboard-panel">
	<div class="wk-home-banner" style="padding:40px 48px;text-align:left;height:auto;min-height:0">
		<h2 style="float:none;padding:0;margin:0 0 14px;color:#fff;font-size:30px"><?php esc_html_e( 'Welcome to Wakoo', 'wakoo' ); ?></h2>
		<p style="position:relative;z-index:1;max-width:760px;margin:0 0 10px;color:#fff;font-size:15px;line-height:1.6"><?php esc_html_e( 'Wakoo adds widgets, a Theme Builder and design extensions to the Elementor editor. Use the tabs above to turn widgets and features on or off.', 'wakoo' ); ?></p>
		<p style="position:relative;z-index:1;max-width:760px;margin:0 0 10px;color:#fff;font-size:15px;line-height:1.6"><?php esc_html_e( 'Wakoo is free software (GPLv2 or later) based on Happy Elementor Addons by Leevio.', 'happy-elementor-addons' ); ?></p>
		<p style="position:relative;z-index:1;margin:16px 0 0"><a class="button button-primary button-hero" href="<?php echo esc_url( admin_url( 'admin.php?page=wakoo-traductor' ) ); ?>"><?php esc_html_e( 'Traductor', 'wakoo' ); ?></a></p>
	</div>
	<?php if ( class_exists( '\Wakoo\Modules\AdminMenu\Module' ) ) { \Wakoo\Modules\AdminMenu\Module::render(); } ?>
</div>
