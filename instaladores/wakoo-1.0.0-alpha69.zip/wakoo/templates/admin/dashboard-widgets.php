<?php
/**
 * Dashboard widgets tab template
 */

defined( 'ABSPATH' ) || die();

$widgets = self::get_widgets();
$catwise_widgets = self::get_widget_map_catwise();
$inactive_widgets = \Wakoo\Elementor\Classes\Widgets_Manager::get_inactive_widgets();
$gsap_widgets = [];

$total_widgets_count = count( $widgets );

if ( ! wk_has_pro() && ! empty( $total_widgets_count ) ) {
	$total_widgets_count = ( $total_widgets_count - 2 );
}

?>
<div class="wk-dashboard-panel">
    <div class="wk-dashboard-panel__header">
        <div class="wk-dashboard-panel__header-content">
            <h2><?php esc_html_e( 'Wakoo Widgets', 'wakoo' ); ?></h2>
            <p class="f16"><?php printf( esc_html__( 'Here is the list of our all %s widgets. You can enable or disable widgets from here to optimize loading speed and Elementor editor experience. %sAfter enabling or disabling any widget make sure to click the Save Changes button.%s', 'wakoo' ), $total_widgets_count, '<strong>', '</strong>' ); ?></p>

            <div class="wk-action-list">
                <button type="button" class="wk-action--btn" data-filter="*"><?php esc_html_e( 'All', 'wakoo' ); ?></button>
                <button type="button" class="wk-action--btn" data-filter="free"><?php esc_html_e( 'Free', 'wakoo' ); ?></button>
                <button type="button" class="wk-action--btn" data-filter="pro"><?php esc_html_e( 'Pro', 'wakoo' ); ?></button>
                <span class="wk-action--divider">|</span>
                <button type="button" class="wk-action--btn" data-action="enable"><?php esc_html_e( 'Enable All', 'wakoo' ); ?></button>
                <button type="button" class="wk-action--btn" data-action="disable"><?php esc_html_e( 'Disable All', 'wakoo' ); ?></button>
                <span class="wk-search-action--btn"><input type="search" id="wk-widget-search" value="" name="wk-widget-search" placeholder="<?php esc_html_e( 'Search', 'wakoo' ); ?>"></span>
            </div>
        </div>
    </div>

    <div class="wk-dashboard-widgets wk-dashboard-widgets--tab">
        <?php if ( ! empty( $gsap_widgets ) ) : ?>
            <h2 style="width: 100%; margin-left: 10px;"><?php esc_html_e( 'GSAP Widgets', 'wakoo' ); ?></h2>
            <?php foreach ( $gsap_widgets as $widget_key => $widget_data ) :
                $is_pro = ! empty( $widget_data['is_pro'] );
                $is_placeholder = $is_pro && ! wk_has_pro();
                $class_attr = 'wk-dashboard-widgets__item' . ( $is_pro ? ' item--is-pro' : '' ) . ( $is_placeholder ? ' item--is-placeholder' : '' );
                $checked = ! in_array( $widget_key, $inactive_widgets, true ) ? 'checked="checked"' : '';
                if ( $is_placeholder ) { $checked = 'disabled="disabled"'; }
                ?>
                <div class="<?php echo esc_attr( $class_attr ); ?>" data-title="<?php echo esc_attr( $widget_data['title'] ); ?>">
                    <?php if ( $is_pro ) : ?><span class="wk-dashboard-widgets__item-badge"><?php esc_html_e( 'Pro', 'wakoo' ); ?></span><?php endif; ?>
                    <span class="wk-dashboard-widgets__item-icon"><i class="<?php echo esc_attr( $widget_data['icon'] ); ?>"></i></span>
                    <h3 class="wk-dashboard-widgets__item-title"><label for="wk-widget-<?php echo esc_attr( $widget_key ); ?>"><?php echo esc_html( $widget_data['title'] ); ?></label></h3>
                    <div class="wk-dashboard-widgets__item-toggle wk-toggle">
                        <input id="wk-widget-<?php echo esc_attr( $widget_key ); ?>" <?php echo $checked; ?> type="checkbox" class="wk-toggle__check wk-widget" name="widgets[]" value="<?php echo esc_attr( $widget_key ); ?>">
                        <b class="wk-toggle__switch"></b><b class="wk-toggle__track"></b>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        <?php
		if( $catwise_widgets ):
			foreach( $catwise_widgets as $cat => $widgets) :
				if( $widgets ):
					printf('<h2 %s>%s %s</h2>',
						"style='width: 100%; margin-left: 10px;'",
						ucwords(str_replace('-', ' ', $cat)),
						__( 'Widgets', 'wakoo' )
					);
					foreach ( $widgets as $widget_key => $widget_data ) :
						if ( isset( $gsap_widgets[ $widget_key ] ) ) { continue; }
						$title = isset( $widget_data['title'] ) ? $widget_data['title'] : '';
						$icon = isset( $widget_data['icon'] ) ? $widget_data['icon'] : '';
						$is_pro = isset( $widget_data['is_pro'] ) && $widget_data['is_pro'] ? true : false;
						$demo_url = isset( $widget_data['demo'] ) && $widget_data['demo'] ? $widget_data['demo'] : '';
						$is_placeholder = $is_pro && ! wk_has_pro();
						$class_attr = 'wk-dashboard-widgets__item';

						if ( $is_pro ) {
							$class_attr .= ' item--is-pro';
						}

						$checked = '';

						if ( ! in_array( $widget_key, $inactive_widgets ) ) {
							$checked = 'checked="checked"';
						}

						if ( $is_placeholder ) {
							$class_attr .= ' item--is-placeholder';
							$checked = 'disabled="disabled"';
						}
						?>
						<div class="<?php echo $class_attr; ?>" data-title="<?php echo esc_attr( $title ); ?>">
							<?php if ( $is_pro ) : ?>
								<span class="wk-dashboard-widgets__item-badge"><?php esc_html_e( 'Pro', 'wakoo' ); ?></span>
							<?php endif; ?>
							<span class="wk-dashboard-widgets__item-icon"><i class="<?php echo $icon; ?>"></i></span>
							<h3 class="wk-dashboard-widgets__item-title">
								<label for="wk-widget-<?php echo $widget_key; ?>" <?php echo $is_placeholder ? 'data-tooltip="Get pro"' : ''; ?>><?php echo $title; ?></label>
								<?php if ( $demo_url ) : ?>
									<a href="<?php echo esc_url( $demo_url ); ?>" target="_blank" rel="noopener" data-tooltip="<?php esc_attr_e( 'Click to view demo / docs', 'wakoo' ); ?>" class="wk-dashboard-widgets__item-preview"><i aria-hidden="true" class="eicon-device-desktop"></i></a>
								<?php endif; ?>
							</h3>
							<div class="wk-dashboard-widgets__item-toggle wk-toggle">
								<input id="wk-widget-<?php echo $widget_key; ?>" <?php echo $checked; ?> type="checkbox" class="wk-toggle__check wk-widget" name="widgets[]" value="<?php echo $widget_key; ?>">
								<b class="wk-toggle__switch"></b>
								<b class="wk-toggle__track"></b>
							</div>
						</div>
					<?php
					endforeach;
				endif;
			endforeach;
		endif;
        ?>
    </div>

    <div class="wk-dashboard-panel__footer">
        <button disabled class="wk-dashboard-btn wk-dashboard-btn--save" type="submit"><?php esc_html_e( 'Save Settings', 'wakoo' ); ?></button>
    </div>
</div>
