<?php
/**
 * Dashboard features tab template
 */

defined( 'ABSPATH' ) || die();

$features = self::get_features();
$inactive_features = \Wakoo\Elementor\Classes\Extensions_Manager::get_inactive_features();
$always_on_features = \Wakoo\Elementor\Classes\Extensions_Manager::get_always_on_features();
$has_pro = wk_has_pro();

$total_features_count = count( $features );

$always_on_group_keys = [];
$gsap_group_keys = [];
$general_group_keys = [];

foreach ( $features as $feature_key => $feature_data ) {
	$is_always_on = in_array( $feature_key, $always_on_features, true );

	if ( in_array( $feature_key, $gsap_group_keys, true ) ) {
		continue;
	} elseif ( $is_always_on ) {
		$always_on_group_keys[] = $feature_key;
	} else {
		$general_group_keys[] = $feature_key;
	}
}
?>
<div class="wk-dashboard-panel">
    <div class="wk-dashboard-panel__header">
        <div class="wk-dashboard-panel__header-content">
            <h2><?php esc_html_e( 'Wakoo Features', 'wakoo' ); ?></h2>
            <p class="f16"><?php printf( esc_html__( 'Here is the list of our all %s features. You can enable or disable features from here to optimize loading speed and Elementor editor experience. %sAfter enabling or disabling any feature make sure to click the Save Changes button.%s', 'wakoo' ), $total_features_count, '<strong>', '</strong>' ); ?></p>

            <div class="wk-action-list">
                <button type="button" class="wk-action--btn" data-filter="*"><?php esc_html_e( 'All', 'wakoo' ); ?></button>
                <button type="button" class="wk-action--btn" data-filter="free"><?php esc_html_e( 'Free', 'wakoo' ); ?></button>
                <button type="button" class="wk-action--btn" data-filter="pro"><?php esc_html_e( 'Pro', 'wakoo' ); ?></button>
                <span class="wk-action--divider">|</span>
                <button type="button" class="wk-action--btn" data-action="enable_feature"><?php esc_html_e( 'Enable All', 'wakoo' ); ?></button>
                <button type="button" class="wk-action--btn" data-action="disable_feature"><?php esc_html_e( 'Disable All', 'wakoo' ); ?></button>
            </div>
        </div>
    </div>

    <div class="wk-dashboard-widgets wk-dashboard-widgets--tab">
        <?php if ( ! empty( $gsap_group_keys ) ) : ?>
            <h2 style="width: 100%; margin-left: 10px;"><?php esc_html_e( 'GSAP Features', 'wakoo' ); ?></h2>
            <?php foreach ( array_unique( $gsap_group_keys ) as $feature_key ) :
                $feature_data = $features[ $feature_key ];
                $title = isset( $feature_data['title'] ) ? $feature_data['title'] : '';
                $icon = isset( $feature_data['icon'] ) ? $feature_data['icon'] : '';
                $is_pro = ! empty( $feature_data['is_pro'] );
                $is_placeholder = $is_pro && ! $has_pro;
                $class_attr = 'wk-dashboard-widgets__item' . ( $is_pro ? ' item--is-pro' : '' ) . ( $is_placeholder ? ' item--is-placeholder' : '' );
                $checked = ! in_array( $feature_key, $inactive_features, true ) ? 'checked="checked"' : '';
                if ( $is_placeholder ) { $checked = 'disabled="disabled"'; }
                ?>
                <div class="<?php echo esc_attr( $class_attr ); ?>">
                    <?php if ( $is_pro ) : ?><span class="wk-dashboard-widgets__item-badge"><?php esc_html_e( 'Pro', 'wakoo' ); ?></span><?php endif; ?>
                    <span class="wk-dashboard-widgets__item-icon"><i class="<?php echo esc_attr( $icon ); ?>"></i></span>
                    <h3 class="wk-dashboard-widgets__item-title"><label for="wk-widget-<?php echo esc_attr( $feature_key ); ?>"><?php echo esc_html( $title ); ?></label></h3>
                    <div class="wk-dashboard-widgets__item-toggle wk-toggle">
                        <input id="wk-widget-<?php echo esc_attr( $feature_key ); ?>" <?php echo $checked; ?> type="checkbox" class="wk-toggle__check wk-feature" name="features[]" value="<?php echo esc_attr( $feature_key ); ?>">
                        <b class="wk-toggle__switch"></b><b class="wk-toggle__track"></b>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        <?php if ( ! empty( $general_group_keys ) ) : ?>
            <h2 style="width: 100%; margin-left: 10px;"><?php esc_html_e( 'General Features', 'wakoo' ); ?></h2>
            <?php foreach ( $general_group_keys as $feature_key ) :
                $feature_data = $features[ $feature_key ];
                $title = isset( $feature_data['title'] ) ? $feature_data['title'] : '';
                $icon = isset( $feature_data['icon'] ) ? $feature_data['icon'] : '';
                $is_pro = isset( $feature_data['is_pro'] ) && $feature_data['is_pro'] ? true : false;
                $demo_url = isset( $feature_data['demo'] ) && $feature_data['demo'] ? $feature_data['demo'] : '';
                $is_placeholder = $is_pro && ! $has_pro;
                $class_attr = 'wk-dashboard-widgets__item';

                if ( $is_pro ) {
                    $class_attr .= ' item--is-pro';
                }

                $checked = '';

                if ( ! in_array( $feature_key, $inactive_features ) ) {
                    $checked = 'checked="checked"';
                }

                if ( $is_placeholder ) {
                    $class_attr .= ' item--is-placeholder';
                    $checked = 'disabled="disabled"';
                }
                ?>
                <div class="<?php echo $class_attr; ?>">
                    <?php if ( $is_pro ) : ?>
                        <span class="wk-dashboard-widgets__item-badge"><?php esc_html_e( 'Pro', 'wakoo' ); ?></span>
                    <?php endif; ?>
                    <span class="wk-dashboard-widgets__item-icon"><i class="<?php echo $icon; ?>"></i></span>
                    <h3 class="wk-dashboard-widgets__item-title">
                        <label for="wk-widget-<?php echo $feature_key; ?>" <?php echo $is_placeholder ? 'data-tooltip="Get pro"' : ''; ?>><?php echo $title; ?></label>
                        <?php if ( $demo_url ) : ?>
                            <a href="<?php echo esc_url( $demo_url ); ?>" target="_blank" rel="noopener" data-tooltip="<?php esc_attr_e( 'Click to view demo / docs', 'wakoo' ); ?>" class="wk-dashboard-widgets__item-preview"><i aria-hidden="true" class="eicon-device-desktop"></i></a>
                        <?php endif; ?>
                    </h3>
                    <div class="wk-dashboard-widgets__item-toggle wk-toggle">
                        <input id="wk-widget-<?php echo $feature_key; ?>" <?php echo $checked; ?> type="checkbox" class="wk-toggle__check wk-feature" name="features[]" value="<?php echo $feature_key; ?>">
                        <b class="wk-toggle__switch"></b>
                        <b class="wk-toggle__track"></b>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <?php if ( ! empty( $always_on_group_keys ) ) : ?>
            <h2 style="width: 100%; margin-left: 10px;"><?php esc_html_e( 'Always On', 'wakoo' ); ?></h2>
            <?php foreach ( $always_on_group_keys as $feature_key ) :
                $feature_data = $features[ $feature_key ];
                $title = isset( $feature_data['title'] ) ? $feature_data['title'] : '';
                $icon = isset( $feature_data['icon'] ) ? $feature_data['icon'] : '';
                $is_pro = isset( $feature_data['is_pro'] ) && $feature_data['is_pro'] ? true : false;
                $demo_url = isset( $feature_data['demo'] ) && $feature_data['demo'] ? $feature_data['demo'] : '';
                $is_placeholder = $is_pro && ! $has_pro;
                $class_attr = 'wk-dashboard-widgets__item item--is-always-on';

                if ( $is_pro ) {
                    $class_attr .= ' item--is-pro';
                }

                if ( $is_placeholder ) {
                    $class_attr .= ' item--is-placeholder';
                }
                ?>
                <div class="<?php echo $class_attr; ?>">
                    <?php if ( $is_pro ) : ?>
                        <span class="wk-dashboard-widgets__item-badge"><?php esc_html_e( 'Pro', 'wakoo' ); ?></span>
                    <?php endif; ?>
                    <span class="wk-dashboard-widgets__item-icon"><i class="<?php echo $icon; ?>"></i></span>
                    <h3 class="wk-dashboard-widgets__item-title">
                        <label for="wk-widget-<?php echo $feature_key; ?>" <?php echo $is_placeholder ? 'data-tooltip="Get pro"' : ''; ?>><?php echo $title; ?></label>
                        <?php if ( $demo_url ) : ?>
                            <a href="<?php echo esc_url( $demo_url ); ?>" target="_blank" rel="noopener" data-tooltip="<?php esc_attr_e( 'Click to view demo / docs', 'wakoo' ); ?>" class="wk-dashboard-widgets__item-preview"><i aria-hidden="true" class="eicon-device-desktop"></i></a>
                        <?php endif; ?>
                    </h3>
                    <div class="wk-dashboard-widgets__item-toggle wk-toggle">
                        <?php if ( $is_placeholder ) : ?>
                            <input id="wk-widget-<?php echo $feature_key; ?>" type="checkbox" class="wk-toggle__check wk-feature" disabled="disabled">
                        <?php else : ?>
                            <input type="hidden" name="features[]" value="<?php echo $feature_key; ?>">
                            <input id="wk-widget-<?php echo $feature_key; ?>" checked="checked" type="checkbox" class="wk-toggle__check" disabled="disabled">
                        <?php endif; ?>
                        <b class="wk-toggle__switch"></b>
                        <b class="wk-toggle__track"></b>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div class="wk-dashboard-panel__footer">
        <button disabled class="wk-dashboard-btn wk-dashboard-btn--save" type="submit"><?php esc_html_e( 'Save Settings', 'wakoo' ); ?></button>
    </div>
</div>
