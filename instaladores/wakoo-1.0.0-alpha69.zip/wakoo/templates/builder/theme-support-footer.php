<?php do_action('wakoo/template/before_footer'); ?>
<div class="ekit-template-content-markup ekit-template-content-footer ekit-template-content-theme-support">
<?php
	// $template = \Wakoo\Elementor\Classes\Theme_Builder::template_ids();
	// echo \Wakoo\Elementor\Classes\Theme_Builder::render_builder_data($template[1]);
	echo \Wakoo\Elementor\Classes\Theme_Builder::instance()->render_builder_data_location('footer');
?>
</div>
<?php do_action('wakoo/template/after_footer'); ?>
<?php wp_footer(); ?>
</body>
</html>
