<div class="inner-content">
    <img src="<?php echo WAKOO_ASSETS; ?>imgs/wizard/congrats.svg" alt="" style="max-height:300px; width: 100%">
    <h2 class="congrats-info">You have completed your setup for Wakoo…</h2>
    <div class="details">Add more creativity to your design with Wakoo 😃</div>
    <wk-nav
    prev=""
    next=""
    done="done"
    @set-tab="setTab"
    ></wk-nav>

    <div class="quick-links">
        <a href="https://www.facebook.com/groups/WakooCommunity" target="_blank">Join our Official Facebook Group</a>
        <a href="" target="_blank">Bookmark our support ticket creation page</a>
        <a href="https://www.youtube.com/channel/UC1-e7ewkKB1Dao1U90QFQFA/featured/?sub_confirmation=1" target="_blank">Subscribe to our Youtube Channel</a>
    </div>
</div>