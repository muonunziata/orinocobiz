<?php
namespace Wakoo\Modules\Suite\Widgets;

use Wakoo\Modules\Suite\Base;

defined( 'ABSPATH' ) || die();

/**
 * 20. Banner de cookies propio: categorías, guarda la elección en una cookie propia y activa los scripts bloqueados.
 *
 * Each choice is also kept server-side as proof of consent (GDPR art. 7.1): a random consent ID
 * (also in the visitor's cookie, shown in the preferences window), time, notice version, the
 * categories accepted or refused, the page and an anonymous visitor hash (no IP, no account).
 * Records live in the private post type `wakoo_consent`, are listed and exported to CSV in
 * Wakoo SEO → Consentimientos, and are deleted after the retention period (13 months by default).
 *
 * Optional (alpha77): a "terms" checkbox that must be ticked before any choice closes the notice
 * (the record keeps it), a language selector (Wakoo Idiomas) so the first-visit notice can also ask
 * for the language, and a veil that dims the page until the visitor chooses.
 */
class Cookies extends Base {

	const LOG    = 'wakoo_consent';
	const RETAIN = 395; // Days a record is kept.

	/** Private log of consent records (no admin UI of its own: see the Consentimientos page). */
	public static function boot() {
		register_post_type( self::LOG, [ 'public' => false, 'show_ui' => false, 'rewrite' => false, 'query_var' => false, 'supports' => [ 'title' ] ] );
		add_action( 'admin_menu', [ __CLASS__, 'admin_menu' ], 40 );
		add_action( 'admin_post_wakoo_consent_csv', [ __CLASS__, 'export_csv' ] );
		add_action( 'wakoo_consent_purge', [ __CLASS__, 'purge' ] );
		if ( ! wp_next_scheduled( 'wakoo_consent_purge' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'wakoo_consent_purge' );
		}
	}

	public static function routes() {
		\Wakoo\Modules\Suite\Sec::route( 'consent', 'POST', [ __CLASS__, 'rest_log' ] );
	}

	/** Stores one choice. Anonymous on purpose: pages are cached, so there is no nonce. */
	public static function rest_log( \WP_REST_Request $r ) {
		$sec = '\Wakoo\Modules\Suite\Sec';
		if ( ! $sec::rate( 'consent', 30, HOUR_IN_SECONDS ) ) {
			return $sec::err( 'rate', 429 );
		}
		$id = strtolower( (string) $r->get_param( 'id' ) );
		if ( ! preg_match( '/^[a-f0-9]{32}$/', $id ) ) {
			return $sec::err( 'id' );
		}
		$in   = (array) $r->get_param( 'c' );
		$cats = [];
		foreach ( array_keys( self::cats() ) as $k ) {
			if ( array_key_exists( $k, $in ) ) {
				$cats[ $k ] = ! empty( $in[ $k ] );
			}
		}
		$path = (string) wp_parse_url( esc_url_raw( (string) $r->get_param( 'url' ) ), PHP_URL_PATH );
		$rec  = [
			'id'      => $id,
			'time'    => gmdate( 'c' ),
			'version' => $sec::int( $r->get_param( 'v' ), 1, 9999 ),
			'choices' => $cats,
			'action'  => in_array( $r->get_param( 'a' ), [ 'accept', 'reject', 'save' ], true ) ? $r->get_param( 'a' ) : 'save',
			'terms'   => null === $r->get_param( 'tc' ) ? null : ! empty( $r->get_param( 'tc' ) ),
			'page'    => mb_substr( $path, 0, 200 ),
			'visitor' => $sec::visitor(),
			'agent'   => isset( $_SERVER['HTTP_USER_AGENT'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 0, 160 ) : '',
		];
		$pid = wp_insert_post( [ 'post_type' => self::LOG, 'post_status' => 'publish', 'post_title' => $id, 'post_content' => wp_slash( wp_json_encode( $rec, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) ) ], true );
		return is_wp_error( $pid ) ? $sec::err( 'save', 500 ) : $sec::ok();
	}

	public static function purge() {
		$old = get_posts( [ 'post_type' => self::LOG, 'post_status' => 'any', 'fields' => 'ids', 'posts_per_page' => 500, 'date_query' => [ [ 'before' => self::RETAIN . ' days ago' ] ] ] );
		foreach ( $old as $id ) {
			wp_delete_post( $id, true );
		}
	}

	public static function admin_menu() {
		add_submenu_page( 'wakoo-seo', __( 'Registro de consentimientos', 'wakoo' ), __( 'Consentimientos', 'wakoo' ), 'manage_options', 'wakoo-consent', [ __CLASS__, 'admin_page' ] );
	}

	private static function records( $search = '', $limit = 200 ) {
		$args = [ 'post_type' => self::LOG, 'post_status' => 'publish', 'posts_per_page' => $limit, 'orderby' => 'date', 'order' => 'DESC' ];
		if ( $search ) {
			$args['title'] = $search;
		}
		$out = [];
		foreach ( get_posts( $args ) as $p ) {
			$rec = json_decode( $p->post_content, true );
			if ( is_array( $rec ) ) {
				$out[] = $rec;
			}
		}
		return $out;
	}

	public static function admin_page() {
		$q     = isset( $_GET['wk_cid'] ) ? strtolower( preg_replace( '/[^a-f0-9]/i', '', sanitize_text_field( wp_unslash( $_GET['wk_cid'] ) ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$list  = self::records( $q );
		$count = (int) wp_count_posts( self::LOG )->publish;
		echo '<div class="wrap"><h1>' . esc_html__( 'Registro de consentimientos', 'wakoo' ) . '</h1>';
		/* translators: 1: number of records, 2: days kept */
		echo '<p>' . esc_html( sprintf( __( '%1$d elecciones guardadas. Cada registro se borra solo a los %2$d días. No se guarda la IP: solo un identificador anónimo del visitante.', 'wakoo' ), $count, self::RETAIN ) ) . '</p>';
		echo '<form method="get" style="margin:12px 0"><input type="hidden" name="page" value="wakoo-consent"><input type="search" name="wk_cid" value="' . esc_attr( $q ) . '" placeholder="' . esc_attr__( 'ID de consentimiento', 'wakoo' ) . '" class="regular-text"> ';
		submit_button( __( 'Buscar', 'wakoo' ), 'secondary', '', false );
		echo ' <a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wakoo_consent_csv' ), 'wakoo_consent_csv' ) ) . '">' . esc_html__( 'Exportar CSV', 'wakoo' ) . '</a></form>';
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Fecha (UTC)', 'wakoo' ) . '</th><th>ID</th><th>' . esc_html__( 'Acción', 'wakoo' ) . '</th><th>' . esc_html__( 'Categorías', 'wakoo' ) . '</th><th>' . esc_html__( 'Términos', 'wakoo' ) . '</th><th>' . esc_html__( 'Versión', 'wakoo' ) . '</th><th>' . esc_html__( 'Página', 'wakoo' ) . '</th></tr></thead><tbody>';
		foreach ( $list as $r ) {
			$cats = [];
			foreach ( (array) ( $r['choices'] ?? [] ) as $k => $v ) {
				$cats[] = $k . ( $v ? ' ✓' : ' ✗' );
			}
			echo '<tr><td>' . esc_html( str_replace( [ 'T', '+00:00' ], [ ' ', '' ], (string) ( $r['time'] ?? '' ) ) ) . '</td><td><code>' . esc_html( $r['id'] ?? '' ) . '</code></td><td>' . esc_html( $r['action'] ?? '' ) . '</td><td>' . esc_html( implode( ' · ', $cats ) ) . '</td><td>' . ( isset( $r['terms'] ) ? ( $r['terms'] ? '✓' : '✗' ) : '' ) . '</td><td>' . (int) ( $r['version'] ?? 0 ) . '</td><td>' . esc_html( $r['page'] ?? '' ) . '</td></tr>';
		}
		if ( ! $list ) {
			echo '<tr><td colspan="7">' . esc_html__( 'Sin registros.', 'wakoo' ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	}

	public static function export_csv() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'wakoo_consent_csv' ) ) {
			wp_die( esc_html__( 'No autorizado.', 'wakoo' ) );
		}
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="wakoo-consentimientos-' . gmdate( 'Y-m-d' ) . '.csv"' );
		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, [ 'time_utc', 'consent_id', 'action', 'version', 'analytics', 'marketing', 'preferences', 'terms', 'page', 'visitor_hash', 'user_agent' ] );
		foreach ( self::records( '', 20000 ) as $r ) {
			$c = (array) ( $r['choices'] ?? [] );
			$b = function ( $k ) use ( $c ) { return array_key_exists( $k, $c ) ? ( $c[ $k ] ? 'yes' : 'no' ) : ''; };
			fputcsv( $out, [ $r['time'] ?? '', $r['id'] ?? '', $r['action'] ?? '', $r['version'] ?? '', $b( 'analytics' ), $b( 'marketing' ), $b( 'preferences' ), isset( $r['terms'] ) ? ( $r['terms'] ? 'yes' : 'no' ) : '', $r['page'] ?? '', $r['visitor'] ?? '', $r['agent'] ?? '' ] );
		}
		fclose( $out );
		exit;
	}

	public function slug() { return 'cookies'; }
	public function label() { return __( 'Consentimiento de cookies', 'wakoo' ); }
	public function cat() { return 'interact'; }
	public function icon() { return 'eicon-lock-user'; }
	public function words() { return [ 'cookies', 'rgpd', 'gdpr', 'consentimiento', 'privacidad' ]; }

	private static function cats() {
		return [
			'analytics'   => [ __( 'Analítica', 'wakoo' ), __( 'Nos ayudan a entender cómo se usa el sitio para mejorarlo (visitas, páginas más vistas).', 'wakoo' ) ],
			'marketing'   => [ __( 'Marketing', 'wakoo' ), __( 'Permiten mostrar publicidad o contenidos relevantes para ti en otros sitios.', 'wakoo' ) ],
			'preferences' => [ __( 'Preferencias', 'wakoo' ), __( 'Recuerdan tus ajustes, como el idioma o la región.', 'wakoo' ) ],
		];
	}

	protected function sections() {
		$cats = [];
		foreach ( self::cats() as $k => $c ) {
			$cats[ 'on_' . $k ]   = [ 't' => 'switch', 'l' => sprintf( __( 'Categoría: %s', 'wakoo' ), $c[0] ), 'd' => 'yes' ];
			$cats[ 'lab_' . $k ]  = [ 't' => 'text', 'l' => __( 'Nombre', 'wakoo' ), 'd' => $c[0], 'c' => [ 'on_' . $k => 'yes' ] ];
			$cats[ 'desc_' . $k ] = [ 't' => 'textarea', 'l' => __( 'Descripción', 'wakoo' ), 'd' => $c[1], 'rows' => 2, 'c' => [ 'on_' . $k => 'yes' ] ];
		}
		return [
			[ 'id' => 'sec_txt', 'label' => __( 'Textos del aviso', 'wakoo' ), 'controls' => [
				'title'  => [ 't' => 'text', 'l' => __( 'Título', 'wakoo' ), 'd' => __( 'Usamos cookies', 'wakoo' ) ],
				'text'   => [ 't' => 'textarea', 'l' => __( 'Texto', 'wakoo' ), 'd' => __( 'Usamos cookies propias necesarias y, con tu permiso, cookies de analítica, marketing y preferencias. Puedes aceptarlas, rechazarlas o elegir.', 'wakoo' ), 'rows' => 4 ],
				'accept' => [ 't' => 'text', 'l' => __( 'Botón aceptar todo', 'wakoo' ), 'd' => __( 'Aceptar todo', 'wakoo' ) ],
				'reject' => [ 't' => 'text', 'l' => __( 'Botón rechazar', 'wakoo' ), 'd' => __( 'Rechazar', 'wakoo' ) ],
				'custom' => [ 't' => 'text', 'l' => __( 'Botón personalizar', 'wakoo' ), 'd' => __( 'Personalizar', 'wakoo' ) ],
				'policy' => [ 't' => 'url', 'l' => __( 'Enlace a la política de cookies', 'wakoo' ) ],
				'policy_l' => [ 't' => 'text', 'l' => __( 'Texto del enlace', 'wakoo' ), 'd' => __( 'Política de cookies', 'wakoo' ) ],
				'langs'   => [ 't' => 'switch', 'l' => __( 'Selector de idioma en el aviso', 'wakoo' ), 'd' => '' ],
				'langs_l' => [ 't' => 'text', 'l' => __( 'Texto sobre el selector', 'wakoo' ), 'd' => __( 'Idioma', 'wakoo' ), 'c' => [ 'langs' => 'yes' ] ],
				'terms_on' => [ 't' => 'switch', 'l' => __( 'Pedir que acepte los términos', 'wakoo' ), 'd' => '' ],
				'terms_txt' => [ 't' => 'text', 'l' => __( 'Texto de la casilla', 'wakoo' ), 'd' => __( 'He leído y acepto los', 'wakoo' ), 'c' => [ 'terms_on' => 'yes' ] ],
				'terms'   => [ 't' => 'url', 'l' => __( 'Enlace a los términos', 'wakoo' ), 'c' => [ 'terms_on' => 'yes' ] ],
				'terms_l' => [ 't' => 'text', 'l' => __( 'Texto del enlace a los términos', 'wakoo' ), 'd' => __( 'Términos y condiciones', 'wakoo' ), 'c' => [ 'terms_on' => 'yes' ] ],
				'privacy' => [ 't' => 'url', 'l' => __( 'Enlace a la política de privacidad', 'wakoo' ), 'c' => [ 'terms_on' => 'yes' ] ],
				'privacy_y' => [ 't' => 'text', 'l' => __( 'Palabra entre los dos enlaces', 'wakoo' ), 'd' => __( 'y la', 'wakoo' ), 'c' => [ 'terms_on' => 'yes' ] ],
				'privacy_l' => [ 't' => 'text', 'l' => __( 'Texto del enlace a la privacidad', 'wakoo' ), 'd' => __( 'Política de privacidad', 'wakoo' ), 'c' => [ 'terms_on' => 'yes' ] ],
				'terms_err' => [ 't' => 'text', 'l' => __( 'Aviso si no marca la casilla', 'wakoo' ), 'd' => __( 'Para continuar, marca la casilla de los términos.', 'wakoo' ), 'c' => [ 'terms_on' => 'yes' ] ],
			] ],
			[ 'id' => 'sec_cats', 'label' => __( 'Categorías', 'wakoo' ), 'controls' => [
				'mtitle' => [ 't' => 'text', 'l' => __( 'Título de la ventana de ajustes', 'wakoo' ), 'd' => __( 'Preferencias de cookies', 'wakoo' ) ],
				'nec_l'  => [ 't' => 'text', 'l' => __( 'Necesarias: nombre', 'wakoo' ), 'd' => __( 'Necesarias', 'wakoo' ) ],
				'nec_d'  => [ 't' => 'textarea', 'l' => __( 'Necesarias: descripción', 'wakoo' ), 'd' => __( 'Imprescindibles para que el sitio funcione. Siempre activas.', 'wakoo' ), 'rows' => 2 ],
				'save'   => [ 't' => 'text', 'l' => __( 'Botón guardar selección', 'wakoo' ), 'd' => __( 'Guardar selección', 'wakoo' ) ],
				'close'  => [ 't' => 'text', 'l' => __( 'Texto de cerrar', 'wakoo' ), 'd' => __( 'Cerrar', 'wakoo' ) ],
				'id_l'   => [ 't' => 'text', 'l' => __( 'Texto «ID de consentimiento»', 'wakoo' ), 'd' => __( 'Tu ID de consentimiento', 'wakoo' ) ],
			] + $cats ],
			[ 'id' => 'sec_opts', 'label' => __( 'Opciones', 'wakoo' ), 'controls' => [
				'pos'    => [ 't' => 'select', 'l' => __( 'Posición', 'wakoo' ), 'd' => 'bar', 'o' => [ 'bar' => __( 'Barra inferior', 'wakoo' ), 'box' => __( 'Caja abajo a la izquierda', 'wakoo' ), 'center' => __( 'Centrado', 'wakoo' ) ] ],
				'days'   => [ 't' => 'number', 'l' => __( 'Duración de la elección (días)', 'wakoo' ), 'd' => 180, 'min' => 1, 'max' => 395 ],
				'ver'    => [ 't' => 'number', 'l' => __( 'Versión (súbela para volver a preguntar a todos)', 'wakoo' ), 'd' => 1, 'min' => 1 ],
				'veil'   => [ 't' => 'switch', 'l' => __( 'Oscurecer la página hasta que elija', 'wakoo' ), 'd' => '' ],
				'float'  => [ 't' => 'switch', 'l' => __( 'Botón flotante para reabrir las preferencias', 'wakoo' ), 'd' => 'yes' ],
				'float_l' => [ 't' => 'text', 'l' => __( 'Texto del botón flotante', 'wakoo' ), 'd' => __( 'Cookies', 'wakoo' ), 'c' => [ 'float' => 'yes' ] ],
				'note'   => [ 't' => 'note', 'l' => __( 'Coloca este widget en el pie global para que funcione en todo el sitio. Cualquier enlace o botón con la clase "wakoo-open-cookies" reabre las preferencias. Para bloquear un script hasta el consentimiento usa: &lt;script type="text/plain" data-wakoo-consent="analytics" src="…"&gt;.', 'wakoo' ) ],
			] ],
		];
	}

	protected function draw( array $s ) {
		$edit = \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode();
		$on   = [];
		$cats = self::cats();
		foreach ( $cats as $k => $c ) { if ( 'yes' === ( $s[ 'on_' . $k ] ?? 'yes' ) ) { $on[] = $k; } }
		$terms = 'yes' === ( $s['terms_on'] ?? '' );
		$this->open( [ 'days' => max( 1, min( 395, (int) $s['days'] ) ), 'ver' => max( 1, (int) $s['ver'] ), 'cats' => $on, 'edit' => (bool) $edit, 'terms' => $terms ], 'wks-ck--' . esc_attr( $s['pos'] ) . ( $edit ? ' is-edit' : '' ) );
		$id = 'wks-ck-' . esc_attr( $this->get_id() );
		if ( 'yes' === ( $s['veil'] ?? '' ) ) {
			echo '<div class="wks-ck__veil" hidden></div>';
		}
		// Banner.
		echo '<div class="wks-ck__bar" role="dialog" aria-labelledby="' . $id . '-t" aria-describedby="' . $id . '-d" hidden' . ( $edit ? '' : '' ) . '>';
		if ( 'yes' === ( $s['langs'] ?? '' ) && class_exists( '\Wakoo\Modules\Idiomas\Module' ) ) {
			\Wakoo\Modules\Idiomas\Module::style();
			echo '<div class="wks-ck__langs">' . ( '' !== (string) $s['langs_l'] ? '<span class="wks-ck__langs-l">' . esc_html( $s['langs_l'] ) . '</span>' : '' ) . \Wakoo\Modules\Idiomas\Module::render( 'codes', (string) $s['langs_l'] ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in render().
		}
		echo '<div class="wks-ck__txt"><b id="' . $id . '-t" class="wks-ck__title">' . esc_html( $s['title'] ) . '</b><p id="' . $id . '-d">' . esc_html( $s['text'] );
		if ( ! empty( $s['policy']['url'] ) ) { echo ' <a href="' . esc_url( $s['policy']['url'] ) . '"' . ( ! empty( $s['policy']['is_external'] ) ? ' target="_blank" rel="noopener noreferrer"' : '' ) . '>' . esc_html( $s['policy_l'] ) . '</a>'; }
		echo '</p>';
		if ( $terms ) {
			$a = function ( $l, $t ) {
				return empty( $l['url'] ) ? esc_html( $t ) : '<a href="' . esc_url( $l['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $t ) . '</a>';
			};
			echo '<label class="wks-ck__terms"><input type="checkbox" data-ck-terms> <span>' . esc_html( $s['terms_txt'] ) . ' ' . $a( $s['terms'] ?? [], $s['terms_l'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			if ( ! empty( $s['privacy']['url'] ) ) {
				echo ' ' . esc_html( $s['privacy_y'] ) . ' ' . $a( $s['privacy'], $s['privacy_l'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</span></label><p class="wks-ck__err" role="alert" hidden>' . esc_html( $s['terms_err'] ) . '</p>';
		}
		echo '</div><div class="wks-ck__btns">';
		echo '<button type="button" class="wks-btn" data-ck="accept">' . esc_html( $s['accept'] ) . '</button>';
		echo '<button type="button" class="wks-btn wks-btn--ghost" data-ck="reject">' . esc_html( $s['reject'] ) . '</button>';
		echo '<button type="button" class="wks-btn wks-btn--ghost" data-ck="custom">' . esc_html( $s['custom'] ) . '</button>';
		echo '</div></div>';
		// Preferences modal.
		echo '<div class="wks-ck__modal" hidden><div class="wks-ck__back" data-ck="close"></div><div class="wks-ck__dlg" role="dialog" aria-modal="true" aria-labelledby="' . $id . '-mt" tabindex="-1">';
		echo '<h3 id="' . $id . '-mt">' . esc_html( $s['mtitle'] ) . '</h3><div class="wks-ck__list">';
		echo '<div class="wks-ck__cat"><label><input type="checkbox" checked disabled> <b>' . esc_html( $s['nec_l'] ) . '</b></label><p>' . esc_html( $s['nec_d'] ) . '</p></div>';
		foreach ( $cats as $k => $c ) {
			if ( ! in_array( $k, $on, true ) ) { continue; }
			echo '<div class="wks-ck__cat"><label><input type="checkbox" data-cat="' . esc_attr( $k ) . '"> <b>' . esc_html( $s[ 'lab_' . $k ] ) . '</b></label><p>' . esc_html( $s[ 'desc_' . $k ] ) . '</p></div>';
		}
		echo '</div><p class="wks-ck__id" hidden>' . esc_html( $s['id_l'] ?? __( 'Tu ID de consentimiento', 'wakoo' ) ) . ': <code></code></p><div class="wks-ck__btns"><button type="button" class="wks-btn" data-ck="save">' . esc_html( $s['save'] ) . '</button>';
		echo '<button type="button" class="wks-btn wks-btn--ghost" data-ck="accept">' . esc_html( $s['accept'] ) . '</button>';
		echo '<button type="button" class="wks-btn wks-btn--ghost" data-ck="close">' . esc_html( $s['close'] ) . '</button></div></div></div>';
		if ( 'yes' === $s['float'] ) {
			echo '<button type="button" class="wakoo-open-cookies wks-ck__float" hidden>' . esc_html( $s['float_l'] ) . '</button>';
		}
		$this->close();
	}
}
