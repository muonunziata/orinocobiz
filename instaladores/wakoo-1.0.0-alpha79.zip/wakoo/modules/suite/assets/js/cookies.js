( function () {
	'use strict';
	var w = window, d = document, NAME = 'wakoo_consent', ALL = [ 'analytics', 'marketing', 'preferences' ];
	var state = null, cfgG = null, listeners = false, opener = null, api = null;

	function readCookie() {
		var m = d.cookie.match( new RegExp( '(?:^|; )' + NAME + '=([^;]*)' ) );
		if ( ! m ) { return null; }
		try { return JSON.parse( decodeURIComponent( m[ 1 ] ) ); } catch ( e ) { return null; }
	}
	function read() {
		var c = readCookie();
		if ( ! c ) { try { c = JSON.parse( w.localStorage.getItem( NAME ) || 'null' ); } catch ( e ) { c = null; } }
		return c && 'object' === typeof c && c.c ? c : null;
	}
	function write( rec, days ) {
		var v = encodeURIComponent( JSON.stringify( rec ) );
		d.cookie = NAME + '=' + v + '; max-age=' + ( days * 86400 ) + '; path=/; SameSite=Lax' + ( 'https:' === location.protocol ? '; Secure' : '' );
		try { w.localStorage.setItem( NAME, JSON.stringify( rec ) ); } catch ( e ) {}
	}

	/** Public API available as soon as the script loads (put this widget in the global footer). */
	var API = w.WakooConsent = {
		has: function ( cat ) { return 'necessary' === cat || !! ( state && state.c && state.c[ cat ] ); },
		get: function () { var o = { necessary: true }; ALL.forEach( function ( k ) { o[ k ] = API.has( k ); } ); return o; },
		open: function () { if ( opener ) { opener(); } },
		set: function ( c ) { if ( cfgG ) { commit( c, 'save' ); } }
	};

	/** Re-creates every blocked <script type="text/plain" data-wakoo-consent="cat"> whose category is now allowed. */
	function activate() {
		d.querySelectorAll( 'script[type="text/plain"][data-wakoo-consent]' ).forEach( function ( s ) {
			if ( s.getAttribute( 'data-wakoo-done' ) || ! API.has( s.getAttribute( 'data-wakoo-consent' ) ) ) { return; }
			s.setAttribute( 'data-wakoo-done', '1' );
			var n = d.createElement( 'script' );
			[].forEach.call( s.attributes, function ( a ) {
				if ( 'type' === a.name || 'data-wakoo-done' === a.name ) { return; }
				n.setAttribute( a.name, a.value );
			} );
			if ( s.src ) { n.async = false; } else { n.text = s.text; }
			s.parentNode.insertBefore( n, s.nextSibling );
		} );
	}
	function announce() {
		activate();
		var ev;
		try { ev = new CustomEvent( 'wakoo:consent', { detail: API.get() } ); } catch ( e ) { ev = d.createEvent( 'CustomEvent' ); ev.initCustomEvent( 'wakoo:consent', false, false, API.get() ); }
		w.dispatchEvent( ev );
		d.dispatchEvent( new CustomEvent( 'wakoo:consent', { detail: API.get() } ) );
	}
	/** Random consent ID (kept in the cookie and in the server-side record of each choice). */
	function newId() {
		var b = new Uint8Array( 16 );
		( w.crypto || w.msCrypto ).getRandomValues( b );
		return Array.prototype.map.call( b, function ( x ) { return ( '0' + x.toString( 16 ) ).slice( -2 ); } ).join( '' );
	}
	function commit( choice, action, terms ) {
		var before = state && state.c ? state.c : {}, rec = { v: cfgG.ver, c: {}, t: Math.floor( Date.now() / 1000 ), id: ( state && state.id ) || newId() }, revoked = false;
		if ( cfgG.terms ) { rec.tc = !! ( terms || ( state && state.tc ) ); }
		cfgG.cats.forEach( function ( k ) { rec.c[ k ] = !! choice[ k ]; if ( before[ k ] && ! rec.c[ k ] ) { revoked = true; } } );
		state = rec; write( rec, cfgG.days );
		// Proof of consent: one server-side record per choice (Wakoo SEO → Consentimientos).
		if ( api ) { api( 'consent', { data: { id: rec.id, v: rec.v, c: rec.c, a: action || 'save', tc: cfgG.terms ? ( rec.tc ? 1 : 0 ) : null, url: location.pathname } } ).catch( function () {} ); }
		announce();
		return revoked;
	}

	// Run activation for any previous choice even before the widget mounts (scripts are in the page already).
	state = read();
	if ( state ) { activate(); }

	WakooSuiteApi.define( 'cookies', function ( root, cfg, S ) {
		cfgG = cfg;
		api = S && S.api ? S.api : null;
		var bar = root.querySelector( '.wks-ck__bar' ), modal = root.querySelector( '.wks-ck__modal' ), dlg = root.querySelector( '.wks-ck__dlg' ), flt = root.querySelector( '.wks-ck__float' );
		var veil = root.querySelector( '.wks-ck__veil' ), tbox = root.querySelector( '[data-ck-terms]' ), terr = root.querySelector( '.wks-ck__err' );
		if ( cfg.edit || d.body.classList.contains( 'elementor-editor-active' ) ) { bar.hidden = false; return; }
		if ( root.parentNode !== d.body ) {
			// The Style tab sets --wks-* on the widget wrapper: keep them on the root before it leaves the wrapper.
			var cs = w.getComputedStyle( root );
			[ '--wks-accent', '--wks-text', '--wks-bg', '--wks-radius', '--wks-line' ].forEach( function ( v ) {
				var x = cs.getPropertyValue( v );
				if ( x && x.trim() ) { root.style.setProperty( v, x.trim() ); }
			} );
			root.classList.add( 'wks-ck--moved' ); d.body.appendChild( root ); // escapes transformed ancestors so "fixed" stays fixed
		}
		var last = null;

		// With the terms checkbox, a choice made before it existed (no "tc") asks again.
		function valid() { return state && state.v === cfg.ver && ( ! cfg.terms || !! state.tc ); }
		function show() { bar.hidden = valid(); if ( veil ) { veil.hidden = bar.hidden; } if ( flt ) { flt.hidden = ! valid(); } }
		function termsOk() {
			if ( ! cfg.terms || ( state && state.tc ) || ( tbox && tbox.checked ) ) { return true; }
			// Every choice needs the terms first: point at the box (from the preferences window too).
			closeModal(); bar.hidden = false; if ( veil ) { veil.hidden = false; }
			if ( terr ) { terr.hidden = false; }
			if ( tbox ) { tbox.focus(); tbox.parentNode.classList.add( 'is-err' ); }
			return false;
		}
		function sync() {
			modal.querySelectorAll( 'input[data-cat]' ).forEach( function ( i ) { i.checked = API.has( i.getAttribute( 'data-cat' ) ); } );
			var idBox = modal.querySelector( '.wks-ck__id' );
			if ( idBox ) { idBox.hidden = ! ( state && state.id ); idBox.querySelector( 'code' ).textContent = state && state.id ? state.id : ''; }
		}
		function openModal() {
			last = d.activeElement; sync(); modal.hidden = false; dlg.focus();
		}
		function closeModal() { modal.hidden = true; if ( last && last.focus && d.body.contains( last ) ) { last.focus(); } }
		opener = function () { openModal(); };
		function done( choice, action ) {
			if ( ! termsOk() ) { return; }
			var revoked = commit( choice, action, tbox && tbox.checked );
			bar.hidden = true; modal.hidden = true; if ( veil ) { veil.hidden = true; } if ( flt ) { flt.hidden = false; }
			if ( revoked ) { w.location.reload(); } // scripts already running cannot be unloaded
		}
		function all( v ) { var o = {}; cfg.cats.forEach( function ( k ) { o[ k ] = v; } ); return o; }

		if ( tbox ) {
			tbox.addEventListener( 'change', function () { if ( tbox.checked ) { if ( terr ) { terr.hidden = true; } tbox.parentNode.classList.remove( 'is-err' ); } } );
		}
		root.addEventListener( 'click', function ( e ) {
			var b = e.target.closest( '[data-ck]' );
			if ( ! b ) { return; }
			var a = b.getAttribute( 'data-ck' );
			if ( 'accept' === a ) { done( all( true ), 'accept' ); } else if ( 'reject' === a ) { done( all( false ), 'reject' ); } else if ( 'custom' === a ) { openModal(); } else if ( 'close' === a ) { closeModal(); } else if ( 'save' === a ) {
				var o = all( false );
				modal.querySelectorAll( 'input[data-cat]' ).forEach( function ( i ) { o[ i.getAttribute( 'data-cat' ) ] = i.checked; } );
				done( o, 'save' );
			}
		} );
		modal.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key ) { closeModal(); return; }
			if ( 'Tab' !== e.key ) { return; }
			var f = [].filter.call( dlg.querySelectorAll( 'button, input:not([disabled])' ), function ( x ) { return ! x.disabled; } );
			if ( ! f.length ) { return; }
			var first = f[ 0 ], lastEl = f[ f.length - 1 ];
			if ( e.shiftKey && ( d.activeElement === first || d.activeElement === dlg ) ) { lastEl.focus(); e.preventDefault(); } else if ( ! e.shiftKey && d.activeElement === lastEl ) { first.focus(); e.preventDefault(); }
		} );
		if ( ! listeners ) {
			listeners = true;
			d.addEventListener( 'click', function ( e ) {
				var t = e.target.closest && e.target.closest( '.wakoo-open-cookies' );
				if ( t ) { e.preventDefault(); API.open(); }
			} );
		}
		show();
		if ( state && ! valid() ) { state = null; }
	} );
}() );
