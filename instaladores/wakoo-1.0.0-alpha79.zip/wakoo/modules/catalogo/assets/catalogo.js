( function () {
	'use strict';
	// Lowercase, without accents, so «respiración» is found with «respiracion».
	function norm( s ) {
		return String( s || '' ).toLowerCase().normalize( 'NFD' ).replace( /[̀-ͯ]/g, '' );
	}
	function each( list, fn ) { Array.prototype.forEach.call( list, fn ); }

	var dlg = null;
	function sheet( root, card, cfg ) {
		var tpl = document.getElementById( 'wakoo-cat-' + card.getAttribute( 'data-sheet' ) );
		if ( ! tpl ) { return; }
		if ( ! dlg ) {
			dlg = document.createElement( 'dialog' );
			dlg.className = 'wakoo-cat__dlg';
			dlg.addEventListener( 'click', function ( e ) { if ( e.target === dlg || e.target.closest( '[data-close]' ) ) { dlg.close(); } } );
			dlg.addEventListener( 'close', function () { if ( dlg._from ) { dlg._from.focus(); } } );
			document.body.appendChild( dlg );
		}
		// The sheet lives outside the widget: carry over its colours and radius.
		var cs = getComputedStyle( root );
		[ '--wk-cat', '--wk-cat-2', '--wk-cat-bg', '--wk-cat-r' ].forEach( function ( v ) { dlg.style.setProperty( v, cs.getPropertyValue( v ) ); } );
		var box = document.createElement( 'div' );
		box.className = 'wakoo-cat__fi';
		box.innerHTML = '<button type="button" class="wakoo-cat__x" data-close aria-label=""><span aria-hidden="true">×</span></button>';
		box.firstChild.setAttribute( 'aria-label', cfg.close || 'Cerrar' );
		box.appendChild( tpl.content.cloneNode( true ) );
		dlg.innerHTML = '';
		dlg.appendChild( box );
		dlg._from = card;
		if ( dlg.showModal ) { dlg.showModal(); } else { dlg.setAttribute( 'open', '' ); }
	}

	function init( root ) {
		if ( root.dataset.wakooInit ) { return; }
		root.dataset.wakooInit = '1';
		var cfg = {};
		try { cfg = JSON.parse( root.getAttribute( 'data-cfg' ) || '{}' ); } catch ( e ) {}
		var q = root.querySelector( '.wakoo-cat__search input' ), chips = root.querySelector( '.wakoo-cat__chips' );
		var n = root.querySelector( '.wakoo-cat__n' ), empty = root.querySelector( '.wakoo-cat__empty' ), cat = '';
		var cards = root.querySelectorAll( '.wakoo-cat__c' );
		each( cards, function ( c ) {
			var tpl = c.getAttribute( 'data-sheet' ) ? document.getElementById( 'wakoo-cat-' + c.getAttribute( 'data-sheet' ) ) : null;
			c._q = norm( c.textContent + ' ' + c.getAttribute( 'data-q' ) + ' ' + ( tpl ? tpl.content.textContent : '' ) );
		} );
		function filter() {
			var words = norm( q ? q.value : '' ).split( /\s+/ ).filter( Boolean ), total = 0;
			each( cards, function ( c ) {
				var ok = ( ! cat || cat === c.getAttribute( 'data-cat' ) ) && words.every( function ( w ) { return c._q.indexOf( w ) >= 0; } );
				c.hidden = ! ok;
				if ( ok ) { total++; }
			} );
			each( root.querySelectorAll( '.wakoo-cat__sec' ), function ( s ) { s.hidden = ! s.querySelector( '.wakoo-cat__c:not([hidden])' ); } );
			if ( n ) { n.textContent = String( cfg.count || '{n}' ).replace( '{n}', total ); }
			if ( empty ) { empty.hidden = total > 0; }
		}
		if ( q ) { q.addEventListener( 'input', filter ); }
		if ( chips ) {
			chips.addEventListener( 'click', function ( e ) {
				var b = e.target.closest( 'button[data-cat]' );
				if ( ! b ) { return; }
				cat = b.getAttribute( 'data-cat' );
				each( chips.children, function ( x ) { var on = x === b; x.classList.toggle( 'is-on', on ); x.setAttribute( 'aria-pressed', on ? 'true' : 'false' ); } );
				filter();
			} );
		}
		root.addEventListener( 'click', function ( e ) {
			var c = e.target.closest( '.wakoo-cat__c[data-sheet]' );
			if ( c ) { sheet( root, c, cfg ); }
		} );
	}
	function boot( scope ) {
		( scope && scope.querySelectorAll ? scope : document ).querySelectorAll( '.wakoo-cat' ).forEach( init );
	}
	if ( 'loading' === document.readyState ) { document.addEventListener( 'DOMContentLoaded', function () { boot( document ); } ); } else { boot( document ); }
	if ( window.jQuery ) {
		window.jQuery( window ).on( 'elementor/frontend/init', function () {
			if ( window.elementorFrontend && window.elementorFrontend.hooks ) {
				window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wakoo-catalogo.default', function ( $s ) { boot( $s[ 0 ] ); } );
			}
		} );
	}
} )();
