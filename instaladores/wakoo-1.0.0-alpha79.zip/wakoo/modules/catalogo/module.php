<?php
/**
 * Wakoo Catálogo: searchable card catalogue grouped by category, each card opens a detail sheet. Native, no libs.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Catalogo;

defined( 'ABSPATH' ) || die();

class Module {

	public static function init() {
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widget' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'scripts' ] );
		add_action( 'elementor/frontend/after_register_styles', [ __CLASS__, 'styles' ] );
	}

	public static function register_widget( $wm ) {
		require_once __DIR__ . '/widget.php';
		$wm->register( new Widget() );
	}

	public static function scripts() {
		wp_register_script( 'wakoo-catalogo', WAKOO_MODULES_URL . 'catalogo/assets/catalogo.js', [], WAKOO_VERSION, true );
	}

	public static function styles() {
		wp_register_style( 'wakoo-catalogo', WAKOO_MODULES_URL . 'catalogo/assets/catalogo.css', [], WAKOO_VERSION );
	}
}

Module::init();
