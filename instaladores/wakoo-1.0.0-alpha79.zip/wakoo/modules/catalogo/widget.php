<?php
/**
 * Wakoo Catálogo widget: cards with image, grouped by category, with search, category chips and a detail sheet.
 * Good for courses, workshops, services, menus or a product line. Categories come from the items; the
 * optional «Categorías» list only adds an icon and a description to them.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Catalogo;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Utils;

defined( 'ABSPATH' ) || die();

class Widget extends Widget_Base {

	public function get_name() { return 'wakoo-catalogo'; }
	public function get_title() { return __( 'Catálogo con buscador (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-gallery-grid'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'catalogo', 'buscador', 'filtro', 'categorias', 'cursos', 'talleres', 'servicios', 'fichas', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-catalogo' ]; }
	public function get_style_depends() { return [ 'wakoo-catalogo', 'elementor-icons-fa-solid' ]; }

	protected function register_controls() {

		$this->start_controls_section( 'sec_items', [ 'label' => __( 'Elementos', 'wakoo' ) ] );
		$r = new Repeater();
		$r->start_controls_tabs( 'tabs' );
		$r->start_controls_tab( 'tab_card', [ 'label' => __( 'Tarjeta', 'wakoo' ) ] );
		$r->add_control( 'image', [ 'label' => __( 'Imagen', 'wakoo' ), 'type' => Controls_Manager::MEDIA, 'default' => [ 'url' => Utils::get_placeholder_image_src() ] ] );
		$r->add_control( 'title', [ 'label' => __( 'Título', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Elemento', 'wakoo' ), 'label_block' => true, 'dynamic' => [ 'active' => true ] ] );
		$r->add_control( 'subtitle', [ 'label' => __( 'Frase', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 2, 'dynamic' => [ 'active' => true ] ] );
		$r->add_control( 'category', [ 'label' => __( 'Categoría', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'label_block' => true, 'description' => __( 'Los elementos con el mismo nombre de categoría van juntos.', 'wakoo' ) ] );
		$r->add_control( 'eyebrow', [ 'label' => __( 'Antetítulo', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'label_block' => true, 'placeholder' => __( 'Charla n.º 2', 'wakoo' ) ] );
		$r->add_control( 'badge', [ 'label' => __( 'Etiqueta destacada', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'placeholder' => __( 'Disponible', 'wakoo' ) ] );
		$r->add_control( 'featured', [ 'label' => __( 'Destacar la tarjeta', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ] );
		$r->add_control( 'tags', [ 'label' => __( 'Datos (uno por línea)', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 3, 'placeholder' => "45 min\nPresencial y online" ] );
		$r->end_controls_tab();
		$r->start_controls_tab( 'tab_sheet', [ 'label' => __( 'Ficha', 'wakoo' ) ] );
		$r->add_control( 'details', [ 'label' => __( 'Contenido de la ficha', 'wakoo' ), 'type' => Controls_Manager::WYSIWYG, 'description' => __( 'Se abre al pulsar la tarjeta. Vacío: la tarjeta lleva directamente al enlace.', 'wakoo' ) ] );
		$r->add_control( 'link', [ 'label' => __( 'Enlace', 'wakoo' ), 'type' => Controls_Manager::URL, 'dynamic' => [ 'active' => true ] ] );
		$r->add_control( 'btn_text', [ 'label' => __( 'Texto del botón', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Más información', 'wakoo' ) ] );
		$r->end_controls_tab();
		$r->end_controls_tabs();
		$this->add_control( 'items', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'title_field' => '{{{ category ? category + " · " : "" }}}{{{ title }}}',
			'default'     => [
				[ 'title' => __( 'Respirar con calma', 'wakoo' ), 'subtitle' => __( 'Tres ejercicios para bajar el ritmo.', 'wakoo' ), 'category' => __( 'Bienestar', 'wakoo' ), 'eyebrow' => __( 'Taller 1', 'wakoo' ), 'badge' => __( 'Disponible', 'wakoo' ), 'featured' => 'yes', 'tags' => "45 min\nOnline", 'details' => '<p>' . __( 'Qué se hace en el taller y qué te llevas.', 'wakoo' ) . '</p>' ],
				[ 'title' => __( 'Dormir mejor', 'wakoo' ), 'subtitle' => __( 'Rutinas sencillas para la noche.', 'wakoo' ), 'category' => __( 'Bienestar', 'wakoo' ), 'eyebrow' => __( 'Taller 2', 'wakoo' ), 'tags' => '60 min' ],
				[ 'title' => __( 'Hablar en público', 'wakoo' ), 'subtitle' => __( 'Pierde el miedo paso a paso.', 'wakoo' ), 'category' => __( 'Comunicación', 'wakoo' ), 'eyebrow' => __( 'Taller 3', 'wakoo' ), 'tags' => '90 min' ],
			],
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_cats', [ 'label' => __( 'Categorías', 'wakoo' ) ] );
		$c = new Repeater();
		$c->add_control( 'name', [ 'label' => __( 'Nombre (igual que en los elementos)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'label_block' => true ] );
		$c->add_control( 'icon', [ 'label' => __( 'Icono', 'wakoo' ), 'type' => Controls_Manager::ICONS, 'default' => [ 'value' => 'fas fa-star', 'library' => 'fa-solid' ] ] );
		$c->add_control( 'desc', [ 'label' => __( 'Descripción', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 2 ] );
		$this->add_control( 'cats', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $c->get_controls(),
			'title_field' => '{{{ name }}}',
			'default'     => [
				[ 'name' => __( 'Bienestar', 'wakoo' ), 'icon' => [ 'value' => 'fas fa-spa', 'library' => 'fa-solid' ], 'desc' => __( 'Cuidar el cuerpo y la mente.', 'wakoo' ) ],
				[ 'name' => __( 'Comunicación', 'wakoo' ), 'icon' => [ 'value' => 'fas fa-comments', 'library' => 'fa-solid' ] ],
			],
		] );
		$this->add_control( 'cats_note', [ 'type' => Controls_Manager::RAW_HTML, 'raw' => __( 'El orden de esta lista es el orden de las categorías. Las que solo aparecen en los elementos van al final.', 'wakoo' ), 'content_classes' => 'elementor-descriptor' ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_opts', [ 'label' => __( 'Buscador y filtros', 'wakoo' ) ] );
		$this->add_control( 'show_search', [ 'label' => __( 'Buscador', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'search_ph', [ 'label' => __( 'Texto del buscador', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Buscar…', 'wakoo' ), 'condition' => [ 'show_search' => 'yes' ] ] );
		$this->add_control( 'show_chips', [ 'label' => __( 'Filtro por categorías', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'all_text', [ 'label' => __( 'Texto «todas»', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Todos', 'wakoo' ), 'condition' => [ 'show_chips' => 'yes' ] ] );
		$this->add_control( 'group', [ 'label' => __( 'Agrupar por categoría', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'count_text', [ 'label' => __( 'Resultados ({n} = número)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( '{n} resultados', 'wakoo' ), 'description' => __( 'Vacío para no mostrarlo.', 'wakoo' ) ] );
		$this->add_control( 'empty_text', [ 'label' => __( 'Sin resultados', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 2, 'default' => __( 'No hay nada con esas palabras. Prueba con otra o mira todas las categorías.', 'wakoo' ) ] );
		$this->add_control( 'close_text', [ 'label' => __( 'Texto «cerrar» (lectores de pantalla)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Cerrar', 'wakoo' ) ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Tarjetas', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'accent', [ 'label' => __( 'Color principal', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#1F3A5F', 'selectors' => [ '{{WRAPPER}} .wakoo-cat' => '--wk-cat: {{VALUE}};' ] ] );
		$this->add_control( 'accent2', [ 'label' => __( 'Color de las etiquetas', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#2E8C86', 'selectors' => [ '{{WRAPPER}} .wakoo-cat' => '--wk-cat-2: {{VALUE}};' ] ] );
		$this->add_control( 'card_bg', [ 'label' => __( 'Fondo de la tarjeta', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#FFFFFF', 'selectors' => [ '{{WRAPPER}} .wakoo-cat' => '--wk-cat-bg: {{VALUE}};' ] ] );
		$this->add_responsive_control( 'min_w', [
			'label'      => __( 'Ancho mínimo de la tarjeta', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'range'      => [ 'px' => [ 'min' => 160, 'max' => 480 ] ],
			'default'    => [ 'size' => 270, 'unit' => 'px' ],
			'selectors'  => [ '{{WRAPPER}} .wakoo-cat__g' => 'grid-template-columns: repeat(auto-fill, minmax(min({{SIZE}}px, 100%), 1fr));' ],
		] );
		$this->add_responsive_control( 'img_size', [
			'label'      => __( 'Tamaño de la imagen', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'range'      => [ 'px' => [ 'min' => 32, 'max' => 200 ] ],
			'default'    => [ 'size' => 76, 'unit' => 'px' ],
			'selectors'  => [ '{{WRAPPER}} .wakoo-cat__img' => 'width: {{SIZE}}px; height: {{SIZE}}px;' ],
		] );
		$this->add_control( 'img_fit', [
			'label'     => __( 'Imagen', 'wakoo' ),
			'type'      => Controls_Manager::SELECT,
			'default'   => 'contain',
			'options'   => [ 'contain' => __( 'Entera (insignias, logos)', 'wakoo' ), 'cover' => __( 'Recortada (fotos)', 'wakoo' ) ],
			'selectors' => [ '{{WRAPPER}} .wakoo-cat__img img' => 'object-fit: {{VALUE}};' ],
		] );
		$this->add_control( 'radius', [
			'label'      => __( 'Redondeo', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'range'      => [ 'px' => [ 'min' => 0, 'max' => 40 ] ],
			'default'    => [ 'size' => 20, 'unit' => 'px' ],
			'selectors'  => [ '{{WRAPPER}} .wakoo-cat' => '--wk-cat-r: {{SIZE}}px;' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'ty_title', 'label' => __( 'Título', 'wakoo' ), 'selector' => '{{WRAPPER}} .wakoo-cat__tx strong' ] );
		$this->add_group_control( Group_Control_Typography::get_type(), [ 'name' => 'ty_cat', 'label' => __( 'Nombre de la categoría', 'wakoo' ), 'selector' => '{{WRAPPER}} .wakoo-cat__sec h3' ] );
		$this->end_controls_section();
	}

	private function link_attrs( $link ) {
		if ( empty( $link['url'] ) ) { return ''; }
		$out = 'href="' . esc_url( $link['url'] ) . '"';
		if ( ! empty( $link['is_external'] ) ) { $out .= ' target="_blank"'; }
		$rel = [];
		if ( ! empty( $link['is_external'] ) ) { $rel[] = 'noopener'; }
		if ( ! empty( $link['nofollow'] ) ) { $rel[] = 'nofollow'; }
		return $out . ( $rel ? ' rel="' . esc_attr( implode( ' ', $rel ) ) . '"' : '' );
	}

	private function lines( $txt ) {
		return array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $txt ) ), 'strlen' ) );
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$items = (array) ( $s['items'] ?? [] );
		if ( ! $items ) { return; }
		$id = $this->get_id();

		// Categories: the ones listed first, in order, then any other name used by the items.
		$cats = [];
		foreach ( (array) ( $s['cats'] ?? [] ) as $c ) {
			$k = sanitize_title( $c['name'] ?? '' );
			if ( '' !== $k && ! isset( $cats[ $k ] ) ) { $cats[ $k ] = [ 'name' => $c['name'], 'icon' => $c['icon'] ?? [], 'desc' => $c['desc'] ?? '', 'items' => [] ]; }
		}
		foreach ( $items as $i => $it ) {
			$k = sanitize_title( $it['category'] ?? '' );
			if ( '' === $k ) { $k = '_'; }
			if ( ! isset( $cats[ $k ] ) ) { $cats[ $k ] = [ 'name' => '_' === $k ? '' : $it['category'], 'icon' => [], 'desc' => '', 'items' => [] ]; }
			$cats[ $k ]['items'][] = $i;
		}
		$cats  = array_filter( $cats, function ( $c ) { return $c['items']; } );
		$group = 'yes' === ( $s['group'] ?? 'yes' );
		$cfg   = [ 'count' => (string) ( $s['count_text'] ?? '' ), 'close' => (string) ( $s['close_text'] ?? '' ) ];

		echo '<div class="wakoo-cat" data-id="' . esc_attr( $id ) . '" data-cfg="' . esc_attr( wp_json_encode( $cfg ) ) . '">';
		if ( 'yes' === ( $s['show_search'] ?? 'yes' ) ) {
			echo '<div class="wakoo-cat__search">';
			Icons_Manager::render_icon( [ 'value' => 'fas fa-search', 'library' => 'fa-solid' ], [ 'aria-hidden' => 'true' ] );
			echo '<input type="search" placeholder="' . esc_attr( $s['search_ph'] ) . '" aria-label="' . esc_attr( $s['search_ph'] ) . '" autocomplete="off"></div>';
		}
		$named = array_filter( $cats, function ( $c ) { return '' !== $c['name']; } );
		if ( 'yes' === ( $s['show_chips'] ?? 'yes' ) && count( $named ) > 1 ) {
			echo '<div class="wakoo-cat__chips" role="group"><button type="button" class="is-on" data-cat="" aria-pressed="true">' . esc_html( $s['all_text'] ) . ' <small>' . count( $items ) . '</small></button>';
			foreach ( $named as $k => $c ) {
				echo '<button type="button" data-cat="' . esc_attr( $k ) . '" aria-pressed="false">';
				if ( ! empty( $c['icon']['value'] ) ) { Icons_Manager::render_icon( $c['icon'], [ 'aria-hidden' => 'true' ] ); }
				echo ' ' . esc_html( $c['name'] ) . ' <small>' . count( $c['items'] ) . '</small></button>';
			}
			echo '</div>';
		}
		if ( '' !== $cfg['count'] ) {
			echo '<p class="wakoo-cat__n" aria-live="polite">' . esc_html( str_replace( '{n}', (string) count( $items ), $cfg['count'] ) ) . '</p>';
		}
		if ( ! $group ) { echo '<div class="wakoo-cat__g">'; }
		foreach ( $cats as $k => $c ) {
			if ( $group ) {
				echo '<section class="wakoo-cat__sec" data-cat="' . esc_attr( $k ) . '">';
				if ( '' !== $c['name'] ) {
					echo '<header>';
					if ( ! empty( $c['icon']['value'] ) ) { echo '<span class="wakoo-cat__ci">'; Icons_Manager::render_icon( $c['icon'], [ 'aria-hidden' => 'true' ] ); echo '</span>'; }
					echo '<div><h3>' . esc_html( $c['name'] ) . '</h3>' . ( '' !== $c['desc'] ? '<p>' . esc_html( $c['desc'] ) . '</p>' : '' ) . '</div></header>';
				}
				echo '<div class="wakoo-cat__g">';
			}
			foreach ( $c['items'] as $i ) {
				$this->card( $items[ $i ], $id . '-' . $i, $k, $c['name'] );
			}
			if ( $group ) { echo '</div></section>'; }
		}
		if ( ! $group ) { echo '</div>'; }
		echo '<p class="wakoo-cat__empty" hidden>' . esc_html( $s['empty_text'] ) . '</p>';
		echo '</div>';
	}

	private function card( $it, $uid, $cat, $cat_name ) {
		$img   = ! empty( $it['image']['url'] ) ? $it['image']['url'] : '';
		$tags  = $this->lines( $it['tags'] ?? '' );
		$det   = trim( (string) ( $it['details'] ?? '' ) );
		$link  = $this->link_attrs( $it['link'] ?? [] );
		$cls   = 'wakoo-cat__c' . ( 'yes' === ( $it['featured'] ?? '' ) ? ' is-featured' : '' );
		$attrs = 'class="' . $cls . '" data-cat="' . esc_attr( $cat ) . '" data-q="' . esc_attr( $cat_name ) . '"';
		$open  = '' !== $det ? '<button type="button" ' . $attrs . ' data-sheet="' . esc_attr( $uid ) . '" aria-haspopup="dialog">' : ( $link ? '<a ' . $attrs . ' ' . $link . '>' : '<div ' . $attrs . '>' );
		$close = '' !== $det ? '</button>' : ( $link ? '</a>' : '</div>' );

		echo $open; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( $img ) { echo '<span class="wakoo-cat__img"><img src="' . esc_url( $img ) . '" alt="" loading="lazy"></span>'; }
		echo '<span class="wakoo-cat__tx">';
		if ( ! empty( $it['eyebrow'] ) || ! empty( $it['badge'] ) ) {
			echo '<small class="wakoo-cat__eb">' . esc_html( $it['eyebrow'] ?? '' ) . ( ! empty( $it['eyebrow'] ) && ! empty( $it['badge'] ) ? ' · ' : '' ) . ( ! empty( $it['badge'] ) ? '<b>' . esc_html( $it['badge'] ) . '</b>' : '' ) . '</small>';
		}
		echo '<strong>' . esc_html( $it['title'] ) . '</strong>';
		if ( ! empty( $it['subtitle'] ) ) { echo '<em>' . esc_html( $it['subtitle'] ) . '</em>'; }
		if ( $tags ) {
			echo '<span class="wakoo-cat__tags">';
			foreach ( $tags as $t ) { echo '<span>' . esc_html( $t ) . '</span>'; }
			echo '</span>';
		}
		echo '</span>' . $close; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( '' === $det ) { return; }
		// Sheet content stays in the page (searchable, indexable) inside a template until the card is opened.
		echo '<template id="wakoo-cat-' . esc_attr( $uid ) . '"><div class="wakoo-cat__fh">';
		if ( $img ) { echo '<img src="' . esc_url( $img ) . '" alt="">'; }
		echo '<div>';
		if ( ! empty( $it['eyebrow'] ) || ! empty( $it['badge'] ) ) {
			echo '<small>' . esc_html( $it['eyebrow'] ?? '' ) . ( ! empty( $it['eyebrow'] ) && ! empty( $it['badge'] ) ? ' · ' : '' ) . ( ! empty( $it['badge'] ) ? '<b>' . esc_html( $it['badge'] ) . '</b>' : '' ) . '</small>';
		}
		echo '<h3>' . esc_html( $it['title'] ) . '</h3>';
		if ( ! empty( $it['subtitle'] ) ) { echo '<p class="wakoo-cat__sub">' . esc_html( $it['subtitle'] ) . '</p>'; }
		if ( $tags ) {
			echo '<p class="wakoo-cat__tags">';
			foreach ( $tags as $t ) { echo '<span>' . esc_html( $t ) . '</span>'; }
			echo '</p>';
		}
		echo '</div></div><div class="wakoo-cat__body">' . wp_kses_post( $this->parse_text_editor( $det ) ) . '</div>';
		if ( $link && ! empty( $it['btn_text'] ) ) {
			echo '<p class="wakoo-cat__cta"><a class="wakoo-cat__btn" ' . $link . '>' . esc_html( $it['btn_text'] ) . '</a></p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</template>';
	}
}
