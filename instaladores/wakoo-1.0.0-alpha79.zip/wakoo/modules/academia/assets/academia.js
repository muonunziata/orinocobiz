/**
 * Wakoo Academia: progress store, course header, syllabus, lesson room,
 * catalog, learner dashboard and the immersive evaluation. No libraries.
 */
( function () {
	'use strict';

	var G = window.WakooAcademia || { ajax: '', nonce: '', user: 0, data: {} };
	var LS = 'wk_ac';

	/* ---------- Storage ---------- */

	function lsGet( k, d ) {
		try { var v = window.localStorage.getItem( k ); return null === v ? d : JSON.parse( v ); } catch ( e ) { return d; }
	}
	function lsSet( k, v ) {
		try { window.localStorage.setItem( k, JSON.stringify( v ) ); } catch ( e ) {}
	}

	var local = lsGet( LS, {} ) || {};
	var server = ( G.data && 'object' === typeof G.data && ! Array.isArray( G.data ) ) ? G.data : {};

	function mergeRec( a, b ) {
		a = a || {}; b = b || {};
		var l = ( a.l || [] ).concat( b.l || [] ).filter( function ( v, i, s ) { return s.indexOf( v ) === i; } ).sort( function ( x, y ) { return x - y; } );
		return {
			l: l,
			s: Math.max( a.s || 0, b.s || 0 ),
			ok: a.ok || b.ok || 0,
			n: Math.max( a.n || 0, b.n || 0 ),
			t: a.t || b.t || '',
			c: a.c || b.c || '',
			u: Math.max( a.u || 0, b.u || 0 )
		};
	}

	var P = {};
	Object.keys( local ).concat( Object.keys( server ) ).forEach( function ( k ) { P[ k ] = mergeRec( local[ k ], server[ k ] ); } );

	function post( body ) {
		if ( ! G.user || ! G.ajax || ! window.fetch ) { return Promise.resolve( null ); }
		var f = new FormData();
		f.append( 'action', 'wakoo_academia' );
		f.append( 'nonce', G.nonce );
		Object.keys( body ).forEach( function ( k ) { f.append( k, body[ k ] ); } );
		return fetch( G.ajax, { method: 'POST', body: f, credentials: 'same-origin' } ).then( function ( r ) { return r.json(); } ).then( function ( r ) {
			if ( r && r.success && r.data && r.data.data ) {
				Object.keys( r.data.data ).forEach( function ( k ) { P[ k ] = mergeRec( P[ k ], r.data.data[ k ] ); } );
				save();
			}
			return r;
		} ).catch( function () { return null; } );
	}

	function save() {
		lsSet( LS, P );
		document.dispatchEvent( new CustomEvent( 'wkac:update' ) );
	}

	// After logging in, send what this browser learned while signed out.
	if ( G.user ) {
		var missing = Object.keys( local ).some( function ( k ) {
			var s = server[ k ] || {}, l = local[ k ] || {};
			return ( l.l || [] ).length > ( s.l || [] ).length || ( l.ok && ! s.ok ) || ( l.s || 0 ) > ( s.s || 0 );
		} );
		if ( missing ) { post( { do: 'merge', data: JSON.stringify( local ) } ); }
	}

	var Store = {
		get: function ( k ) { return P[ k ] || { l: [], s: 0, ok: 0, n: 0 }; },
		pct: function ( k, n ) {
			var r = Store.get( k ); n = n || r.n;
			return n ? Math.min( 100, Math.round( 100 * r.l.length / n ) ) : 0;
		},
		lesson: function ( k, i, n, title ) {
			var r = P[ k ] = mergeRec( P[ k ], { l: [ i ], n: n, t: title, u: Date.now() / 1000 | 0 } );
			save();
			post( { do: 'lesson', key: k, i: i, n: n, title: title || '' } );
			return r;
		},
		quiz: function ( k, score, pass, n, title ) {
			P[ k ] = mergeRec( P[ k ], { s: score, ok: pass ? ( Date.now() / 1000 | 0 ) : 0, n: n, t: title } );
			save();
			return post( { do: 'quiz', key: k, score: score, pass: pass ? 1 : 0, n: n, title: title || '' } );
		}
	};
	window.WakooAcademiaStore = Store;

	/* ---------- Helpers ---------- */

	function $( s, c ) { return ( c || document ).querySelector( s ); }
	function $$( s, c ) { return Array.prototype.slice.call( ( c || document ).querySelectorAll( s ) ); }
	function el( tag, cls, html ) {
		var e = document.createElement( tag );
		if ( cls ) { e.className = cls; }
		if ( null != html ) { e.innerHTML = html; }
		return e;
	}
	function esc( s ) {
		return String( null == s ? '' : s ).replace( /[&<>"']/g, function ( c ) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ c ]; } );
	}
	function json( node, attr ) {
		try { return JSON.parse( attr ? node.getAttribute( attr ) : node.textContent ); } catch ( e ) { return {}; }
	}
	function shuffle( a ) {
		a = a.slice();
		for ( var i = a.length - 1; i > 0; i-- ) { var j = Math.floor( Math.random() * ( i + 1 ) ); var t = a[ i ]; a[ i ] = a[ j ]; a[ j ] = t; }
		return a;
	}
	function bar( node, pct ) {
		if ( ! node ) { return; }
		node.hidden = false;
		var i = $( 'i', node ), b = $( 'b', node );
		if ( i ) { i.style.width = pct + '%'; }
		if ( b ) { b.textContent = pct + '%'; }
	}
	var reduce = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	function anim( node, frames, opts ) {
		if ( reduce || ! node || ! node.animate ) { return; }
		node.animate( frames, opts );
	}
	function ICON( name ) {
		var p = {
			check: 'M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z',
			x: 'M19 6.4 17.6 5 12 10.6 6.4 5 5 6.4 10.6 12 5 17.6 6.4 19 12 13.4 17.6 19 19 17.6 13.4 12z',
			star: 'm12 17.3 6.2 3.7-1.6-7 5.4-4.7-7.1-.6L12 2 9.1 8.7 2 9.3l5.4 4.7-1.6 7z',
			up: 'M7 14l5-5 5 5z',
			down: 'M7 10l5 5 5-5z',
			cert: 'M4 3h16v12H4zm2 2v8h12V5zm2 2h8v1.5H8zm0 3h5v1.5H8zM9 16l3 1.5 3-1.5v6l-3-1.5L9 22z',
			play: 'M8 5v14l11-7z'
		};
		return '<svg class="wk-ac-i" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="' + ( p[ name ] || '' ) + '"/></svg>';
	}

	/* ---------- Course header ---------- */

	function head( root ) {
		var cfg = json( root, 'data-cfg' ), w = json( root, 'data-words' );
		var btn = $( '.wk-ac-head__cta .wk-ac-btn', root ), lbl = btn && $( 'span', btn );
		function paint() {
			var r = Store.get( cfg.key ), pct = Store.pct( cfg.key, cfg.n );
			if ( r.l.length ) { bar( $( '.wk-ac-bar', root ), pct ); }
			if ( ! lbl ) { return; }
			if ( r.ok && pct >= 100 ) { lbl.textContent = w.review; btn.setAttribute( 'href', cfg.target ); }
			else if ( r.l.length ) {
				var next = 0;
				while ( r.l.indexOf( next ) > -1 && next < cfg.n - 1 ) { next++; }
				lbl.textContent = w.continue;
				btn.setAttribute( 'href', '#leccion-' + ( next + 1 ) );
			}
		}
		paint();
		document.addEventListener( 'wkac:update', paint );
		var tr = $( '[data-trailer]', root );
		if ( tr ) { tr.addEventListener( 'click', function () { lightbox( tr.getAttribute( 'data-trailer' ) ); } ); }
	}

	function embedUrl( u ) {
		var m = u.match( /(?:youtu\.be\/|youtube(?:-nocookie)?\.com\/(?:watch\?v=|embed\/|shorts\/))([\w-]{11})/ );
		if ( m ) { return 'https://www.youtube-nocookie.com/embed/' + m[ 1 ] + '?autoplay=1&rel=0'; }
		m = u.match( /vimeo\.com\/(?:video\/)?(\d+)/ );
		if ( m ) { return 'https://player.vimeo.com/video/' + m[ 1 ] + '?autoplay=1&dnt=1'; }
		return '';
	}

	function lightbox( url ) {
		var box = el( 'div', 'wk-ac-lb' ), e = embedUrl( url );
		box.setAttribute( 'role', 'dialog' );
		box.setAttribute( 'aria-modal', 'true' );
		box.innerHTML = '<button type="button" class="wk-ac-lb__x" aria-label="×">' + ICON( 'x' ) + '</button><div class="wk-ac-lb__v">' +
			( e ? '<iframe src="' + esc( e ) + '" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>' : '<video src="' + esc( url ) + '" controls autoplay playsinline></video>' ) + '</div>';
		function close() { box.remove(); document.removeEventListener( 'keydown', key ); }
		function key( ev ) { if ( 'Escape' === ev.key ) { close(); } }
		box.addEventListener( 'click', function ( ev ) { if ( ev.target === box || ev.target.closest( '.wk-ac-lb__x' ) ) { close(); } } );
		document.addEventListener( 'keydown', key );
		document.body.appendChild( box );
		$( '.wk-ac-lb__x', box ).focus();
	}

	/* ---------- Lesson room ---------- */

	function room( root ) {
		var cfg = json( root, 'data-cfg' ), w = json( root, 'data-words' );
		var lessons = $$( '.wk-ac-lesson', root ), items = $$( '.wk-ac-item', root );
		var cur = 0, lastKey = 'wk_ac_last_' + cfg.key;

		function stopMedia( art ) {
			$$( 'video', art ).forEach( function ( v ) { v.pause(); } );
			$$( 'iframe', art ).forEach( function ( f ) {
				var b = el( 'button', 'wk-ac-ext' );
				b.type = 'button';
				b.setAttribute( 'data-src', f.getAttribute( 'src' ) );
				b.innerHTML = '<span class="wk-ac-ext__play">' + ICON( 'play' ) + '</span><span class="wk-ac-ext__txt">' + esc( w.play ) + '</span>';
				f.replaceWith( b );
			} );
		}

		function show( i, scroll ) {
			i = Math.max( 0, Math.min( lessons.length - 1, i ) );
			if ( lessons[ cur ] && cur !== i ) { stopMedia( lessons[ cur ] ); }
			lessons.forEach( function ( a, k ) { a.hidden = k !== i; } );
			items.forEach( function ( b, k ) {
				b.classList.toggle( 'is-on', k === i );
				if ( k === i ) { b.setAttribute( 'aria-current', 'true' ); } else { b.removeAttribute( 'aria-current' ); }
			} );
			cur = i;
			lsSet( lastKey, i );
			anim( lessons[ i ], [ { opacity: 0, transform: 'translateY(8px)' }, { opacity: 1, transform: 'none' } ], { duration: 280, easing: 'ease-out' } );
			if ( scroll ) { root.scrollIntoView( { behavior: reduce ? 'auto' : 'smooth', block: 'start' } ); }
		}

		function paint() {
			var r = Store.get( cfg.key );
			items.forEach( function ( b, k ) { b.classList.toggle( 'is-done', r.l.indexOf( k ) > -1 ); } );
			lessons.forEach( function ( a, k ) {
				var d = $( '.wk-ac-done', a );
				if ( ! d ) { return; }
				var seen = r.l.indexOf( k ) > -1;
				d.classList.toggle( 'is-done', seen );
				$( 'span', d ).textContent = seen ? w.isdone : w.done;
			} );
			var pct = Store.pct( cfg.key, cfg.n );
			bar( $( '.wk-ac-room__side .wk-ac-bar', root ), pct );
			var fin = $( '.wk-ac-finish', root );
			if ( fin ) { fin.hidden = pct < 100; }
		}

		function markDone( i ) {
			var before = Store.pct( cfg.key, cfg.n );
			Store.lesson( cfg.key, i, cfg.n, cfg.title );
			if ( before < 100 && Store.pct( cfg.key, cfg.n ) >= 100 ) {
				var fin = $( '.wk-ac-finish', root );
				anim( fin, [ { transform: 'scale(.9)', opacity: 0 }, { transform: 'scale(1.03)', opacity: 1 }, { transform: 'none' } ], { duration: 500, easing: 'ease-out' } );
			}
		}

		root.addEventListener( 'click', function ( ev ) {
			var go = ev.target.closest( '[data-go]' );
			if ( go && root.contains( go ) ) { show( parseInt( go.getAttribute( 'data-go' ), 10 ), true ); return; }
			var done = ev.target.closest( '.wk-ac-done' );
			if ( done ) { markDone( cur ); return; }
			var ext = ev.target.closest( '.wk-ac-ext' );
			if ( ext ) {
				var f = document.createElement( 'iframe' );
				f.src = ext.getAttribute( 'data-src' );
				f.allow = 'autoplay; fullscreen; picture-in-picture';
				f.setAttribute( 'allowfullscreen', '' );
				f.title = $( '.wk-ac-room__h', lessons[ cur ] ).textContent;
				ext.replaceWith( f );
				return;
			}
			var tab = ev.target.closest( '.wk-ac-tab' );
			if ( tab ) {
				var art = tab.closest( '.wk-ac-lesson' ), k = tab.getAttribute( 'data-tab' );
				$$( '.wk-ac-tab', art ).forEach( function ( t ) { t.setAttribute( 'aria-selected', t === tab ? 'true' : 'false' ); } );
				$$( '.wk-ac-pane', art ).forEach( function ( p ) { p.hidden = p.getAttribute( 'data-pane' ) !== k; } );
			}
		} );

		// Native videos: mark as seen at the end and move on.
		lessons.forEach( function ( a, k ) {
			var v = $( 'video', a );
			if ( v ) {
				v.addEventListener( 'ended', function () {
					markDone( k );
					if ( cfg.auto && k < lessons.length - 1 ) { setTimeout( function () { show( k + 1 ); }, 900 ); }
				} );
			}
			var n = $( '.wk-ac-notes', a ), nk = 'wk_ac_n_' + cfg.key + '_' + k, t;
			if ( n ) {
				n.value = lsGet( nk, '' ) || '';
				n.addEventListener( 'input', function () { clearTimeout( t ); t = setTimeout( function () { lsSet( nk, n.value ); }, 400 ); } );
			}
		} );

		function fromHash() {
			var m = ( window.location.hash || '' ).match( /^#leccion-(\d+)$/ );
			if ( m ) { show( parseInt( m[ 1 ], 10 ) - 1, true ); return true; }
			return false;
		}
		window.addEventListener( 'hashchange', fromHash );
		document.addEventListener( 'wkac:go', function ( ev ) { if ( ev.detail && ev.detail.key === cfg.key ) { show( ev.detail.i, true ); } } );
		document.addEventListener( 'wkac:update', paint );
		if ( ! fromHash() ) {
			var last = lsGet( lastKey, null );
			if ( null !== last && last < lessons.length ) { show( last ); }
		}
		paint();
	}

	/* ---------- Syllabus ---------- */

	function syllabus( root ) {
		var cfg = json( root, 'data-cfg' );
		function paint() {
			var r = Store.get( cfg.key );
			$$( 'li[data-i]', root ).forEach( function ( li ) { li.classList.toggle( 'is-done', r.l.indexOf( parseInt( li.getAttribute( 'data-i' ), 10 ) ) > -1 ); } );
			var q = $( 'li.is-quiz', root );
			if ( q ) { q.classList.toggle( 'is-done', !! r.ok ); }
		}
		root.addEventListener( 'click', function ( ev ) {
			var a = ev.target.closest( '[data-go]' );
			if ( ! a ) { return; }
			var i = parseInt( a.getAttribute( 'data-go' ), 10 );
			if ( $( '.wk-ac-room' ) ) {
				ev.preventDefault();
				document.dispatchEvent( new CustomEvent( 'wkac:go', { detail: { key: cfg.key, i: i } } ) );
			}
		} );
		document.addEventListener( 'wkac:update', paint );
		paint();
	}

	/* ---------- Catalog ---------- */

	function catalog( root ) {
		var w = json( root, 'data-words' ), cards = $$( '.wk-ac-card', root );
		var q = $( '.wk-ac-search', root ), lv = $( '.wk-ac-level', root ), cat = '';
		function norm( s ) { return String( s || '' ).toLowerCase().normalize( 'NFD' ).replace( /[̀-ͯ]/g, '' ); }
		function filter() {
			var t = norm( q ? q.value : '' ), l = lv ? lv.value : '', shown = 0;
			cards.forEach( function ( c ) {
				var ok = ( ! t || c.getAttribute( 'data-q' ).indexOf( t ) > -1 ) && ( ! cat || c.getAttribute( 'data-cat' ) === cat ) && ( ! l || c.getAttribute( 'data-level' ) === l );
				c.hidden = ! ok;
				if ( ok ) { shown++; }
			} );
			$( '.wk-ac-empty', root ).hidden = shown > 0;
		}
		if ( q ) { q.addEventListener( 'input', filter ); }
		if ( lv ) { lv.addEventListener( 'change', filter ); }
		$$( '.wk-ac-chips .wk-ac-chip', root ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				cat = b.getAttribute( 'data-cat' );
				$$( '.wk-ac-chips .wk-ac-chip', root ).forEach( function ( o ) { o.classList.toggle( 'is-on', o === b ); o.setAttribute( 'aria-pressed', o === b ? 'true' : 'false' ); } );
				filter();
			} );
		} );
		function paint() {
			cards.forEach( function ( c ) {
				var k = c.getAttribute( 'data-key' ), n = parseInt( c.getAttribute( 'data-n' ), 10 ), r = Store.get( k );
				if ( r.l.length ) {
					bar( $( '.wk-ac-bar', c ), Store.pct( k, n ) );
					$( '.wk-ac-card__go', c ).textContent = w.going;
				}
				$( '.wk-ac-card__done', c ).hidden = ! r.ok;
			} );
		}
		document.addEventListener( 'wkac:update', paint );
		paint();
	}

	/* ---------- Learner dashboard ---------- */

	function dashboard( root ) {
		var w = json( root, 'data-words' ), cfg = json( $( '.wk-ac-cfg', root ) ), body = $( '.wk-ac-dash__body', root );
		function card( c, kind ) {
			var r = Store.get( c.key ), pct = Store.pct( c.key, c.n );
			var html = '<article class="wk-ac-dcard is-' + kind + '">' + ( c.img ? '<img src="' + esc( c.img ) + '" alt="" loading="lazy">' : '<span class="wk-ac-dcard__ph"></span>' ) +
				'<div><span class="wk-ac-chip is-small">' + esc( c.cat ) + '</span><h3><a href="' + esc( c.url ) + '">' + esc( c.title ) + '</a></h3>';
			if ( 'going' === kind ) { html += '<div class="wk-ac-bar"><span class="wk-ac-bar__track"><i style="width:' + pct + '%"></i></span><b>' + pct + '%</b></div><a class="wk-ac-btn" href="' + esc( c.url ) + '#aula">' + esc( w.cont ) + '</a>'; }
			if ( 'done' === kind ) {
				html += '<p class="wk-ac-dcard__ok">' + ICON( 'check' ) + ( c.badge ? esc( c.badge ) + ' · ' : '' ) + r.s + '%</p>';
				if ( cfg.cert && G.user ) { html += '<a class="wk-ac-btn is-ghost" href="' + esc( cfg.cert + ( cfg.cert.indexOf( '?' ) > -1 ? '&' : '?' ) + 'curso=' + encodeURIComponent( c.key ) ) + '">' + ICON( 'cert' ) + esc( w.cert ) + '</a>'; }
			}
			if ( 'next' === kind ) { html += '<a class="wk-ac-btn is-ghost" href="' + esc( c.url ) + '">' + esc( w.see ) + '</a>'; }
			return html + '</div></article>';
		}
		function paint() {
			var going = [], done = [], rest = [], seen = 0, certs = 0;
			( cfg.courses || [] ).forEach( function ( c ) {
				var r = Store.get( c.key );
				seen += r.l.length;
				if ( r.ok ) { done.push( c ); certs++; } else if ( r.l.length ) { going.push( c ); } else { rest.push( c ); }
			} );
			going.sort( function ( a, b ) { return ( Store.get( b.key ).u || 0 ) - ( Store.get( a.key ).u || 0 ); } );
			var h = '<ul class="wk-ac-dash__stats"><li><b>' + ( going.length + done.length ) + '</b>' + esc( w.started ) + '</li><li><b>' + seen + '</b>' + esc( w.seen ) + '</li><li><b>' + certs + '</b>' + esc( w.certs ) + '</li></ul>';
			if ( ! going.length && ! done.length ) { h += '<p class="wk-ac-guest">' + esc( w.empty ) + '</p>'; }
			if ( going.length ) { h += '<h3 class="wk-ac-dash__sub">' + esc( w.going ) + '</h3><div class="wk-ac-dash__grid">' + going.map( function ( c ) { return card( c, 'going' ); } ).join( '' ) + '</div>'; }
			if ( done.length ) { h += '<h3 class="wk-ac-dash__sub">' + esc( w.done ) + '</h3><div class="wk-ac-dash__grid">' + done.map( function ( c ) { return card( c, 'done' ); } ).join( '' ) + '</div>'; }
			if ( cfg.suggest && rest.length ) { h += '<h3 class="wk-ac-dash__sub">' + esc( w.next ) + '</h3><div class="wk-ac-dash__grid">' + rest.slice( 0, cfg.suggest ).map( function ( c ) { return card( c, 'next' ); } ).join( '' ) + '</div>'; }
			body.innerHTML = h;
		}
		document.addEventListener( 'wkac:update', paint );
		paint();
	}

	/* ---------- Immersive evaluation ---------- */

	var audio;
	function tone( ok ) {
		try {
			audio = audio || new ( window.AudioContext || window.webkitAudioContext )();
			var o = audio.createOscillator(), g = audio.createGain(), t = audio.currentTime;
			o.type = 'sine';
			o.frequency.setValueAtTime( ok ? 660 : 300, t );
			if ( ok ) { o.frequency.setValueAtTime( 880, t + 0.09 ); }
			g.gain.setValueAtTime( 0.0001, t );
			g.gain.exponentialRampToValueAtTime( 0.12, t + 0.02 );
			g.gain.exponentialRampToValueAtTime( 0.0001, t + 0.35 );
			o.connect( g ); g.connect( audio.destination );
			o.start( t ); o.stop( t + 0.4 );
		} catch ( e ) {}
	}

	function quiz( root ) {
		var cfg = json( $( '.wk-ac-cfg', root ) ), w = json( root, 'data-words' );
		var go = $( '.wk-ac-quiz__go', root ), lock = $( '.wk-ac-quiz__lock', root ), best = $( '.wk-ac-quiz__best', root );
		var scoredN = cfg.qs.filter( function ( q ) { return 'scale' !== q.t && 'reflect' !== q.t; } ).length;

		function paint() {
			var r = Store.get( cfg.key ), open = ! cfg.gate || ! cfg.n || Store.pct( cfg.key, cfg.n ) >= 100;
			go.disabled = ! open;
			lock.hidden = open;
			if ( r.s || r.ok ) { best.hidden = false; best.innerHTML = ( r.ok ? ICON( 'check' ) : '' ) + esc( w.score ) + ': <b>' + r.s + '%</b>'; }
		}
		document.addEventListener( 'wkac:update', paint );
		paint();
		go.addEventListener( 'click', function () { run(); } );

		function run() {
			var qs = cfg.qs.map( function ( q ) {
				var c = JSON.parse( JSON.stringify( q ) );
				if ( ( 'one' === c.t || 'many' === c.t ) && cfg.shuffle ) { c.o = shuffle( c.o ); }
				return c;
			} );
			var idx = 0, results = [], timer = null, left = cfg.timer * 60, lastFocus = document.activeElement;
			var wrap = el( 'div', 'wk-ac wk-ac-qz' + ( cfg.full ? ' is-full' : '' ) );
			// Carry the widget's colours into the overlay (it lives outside the widget).
			var cs = getComputedStyle( root );
			[ '--wk-ac', '--wk-ac-ink', '--wk-ac-card', '--wk-ac-r', '--wk-ac-bg' ].forEach( function ( v ) { var x = cs.getPropertyValue( v ); if ( x ) { wrap.style.setProperty( v, x.trim() ); } } );
			wrap.__words = w;
			wrap.setAttribute( 'data-key', cfg.key );
			wrap.setAttribute( 'role', 'dialog' );
			wrap.setAttribute( 'aria-modal', cfg.full ? 'true' : 'false' );
			wrap.setAttribute( 'aria-label', cfg.title );
			wrap.innerHTML = '<div class="wk-ac-qz__top"><strong class="wk-ac-qz__title">' + esc( cfg.title ) + '</strong><ol class="wk-ac-qz__dots">' + qs.map( function () { return '<li></li>'; } ).join( '' ) + '</ol>' +
				( cfg.timer ? '<span class="wk-ac-qz__time" aria-label="' + esc( w.time ) + '"></span>' : '' ) +
				'<button type="button" class="wk-ac-qz__x" aria-label="' + esc( w.close ) + '">' + ICON( 'x' ) + '</button></div><div class="wk-ac-qz__stage" aria-live="polite"></div>';
			var stage = $( '.wk-ac-qz__stage', wrap );
			if ( cfg.full ) { document.body.appendChild( wrap ); document.documentElement.classList.add( 'wk-ac-lock' ); }
			else { root.appendChild( wrap ); $( '.wk-ac-quiz__intro', root ).hidden = true; }

			function close() {
				clearInterval( timer );
				document.removeEventListener( 'keydown', keys );
				document.documentElement.classList.remove( 'wk-ac-lock' );
				wrap.remove();
				$( '.wk-ac-quiz__intro', root ).hidden = false;
				if ( lastFocus && lastFocus.focus ) { lastFocus.focus(); }
			}
			function keys( ev ) {
				if ( 'Escape' === ev.key && cfg.full ) { close(); return; }
				if ( /^[1-9]$/.test( ev.key ) && ! /TEXTAREA|INPUT|SELECT/.test( ( ev.target.tagName || '' ) ) ) {
					var b = $$( '.wk-ac-opt', stage )[ parseInt( ev.key, 10 ) - 1 ];
					if ( b && ! b.disabled ) { b.click(); }
				}
				if ( 'Tab' === ev.key && cfg.full ) {
					var f = $$( 'button:not([disabled]),a[href],input,textarea,select,iframe,video,audio', wrap ).filter( function ( n ) { return n.offsetParent !== null; } );
					if ( ! f.length ) { return; }
					if ( ev.shiftKey && document.activeElement === f[ 0 ] ) { ev.preventDefault(); f[ f.length - 1 ].focus(); }
					else if ( ! ev.shiftKey && document.activeElement === f[ f.length - 1 ] ) { ev.preventDefault(); f[ 0 ].focus(); }
				}
			}
			document.addEventListener( 'keydown', keys );
			$( '.wk-ac-qz__x', wrap ).addEventListener( 'click', close );

			if ( cfg.timer ) {
				var tEl = $( '.wk-ac-qz__time', wrap );
				var tick = function () {
					tEl.textContent = Math.floor( left / 60 ) + ':' + ( '0' + ( left % 60 ) ).slice( -2 );
					tEl.classList.toggle( 'is-low', left <= 30 );
					if ( left-- <= 0 ) { clearInterval( timer ); finish(); }
				};
				tick();
				timer = setInterval( tick, 1000 );
			}

			function media( m ) {
				if ( ! m ) { return ''; }
				if ( 'image' === m[ 0 ] ) { return '<figure class="wk-ac-qz__media"><img src="' + esc( m[ 1 ] ) + '" alt=""></figure>'; }
				if ( 'audio' === m[ 0 ] ) { return '<figure class="wk-ac-qz__media is-audio"><audio controls preload="none" src="' + esc( m[ 1 ] ) + '"></audio></figure>'; }
				if ( 'yt' === m[ 0 ] ) { return '<figure class="wk-ac-qz__media is-video"><iframe src="' + esc( m[ 1 ] ) + '" allow="fullscreen" allowfullscreen loading="lazy"></iframe></figure>'; }
				return '<figure class="wk-ac-qz__media is-video"><video controls playsinline preload="metadata" src="' + esc( m[ 1 ] ) + '"></video></figure>';
			}

			function dots() {
				$$( '.wk-ac-qz__dots li', wrap ).forEach( function ( d, k ) {
					d.className = k === idx ? 'is-on' : ( results[ k ] ? ( results[ k ].free ? 'is-free' : ( results[ k ].ok ? 'is-ok' : 'is-ko' ) ) : '' );
				} );
			}

			function render() {
				var q = qs[ idx ], help = { one: w.one, many: w.many, tf: '', order: w.order, match: w.match, scale: w.scale, reflect: w.reflect }[ q.t ];
				dots();
				var h = '<div class="wk-ac-qz__card">';
				if ( q.sc ) { h += '<p class="wk-ac-qz__scene">' + esc( q.sc ) + '</p>'; }
				h += media( q.m ) + '<p class="wk-ac-qz__k">' + esc( w.q + ' ' + ( idx + 1 ) + ' ' + w.of + ' ' + qs.length ) + '</p><h3 class="wk-ac-qz__q">' + esc( q.q ) + '</h3>';
				if ( help ) { h += '<p class="wk-ac-qz__help">' + esc( help ) + '</p>'; }
				h += '<div class="wk-ac-qz__ans"></div>';
				if ( q.h ) { h += '<details class="wk-ac-qz__hint"><summary>' + esc( w.hint ) + '</summary><p>' + esc( q.h ) + '</p></details>'; }
				h += '<div class="wk-ac-qz__fb" hidden></div><div class="wk-ac-qz__act"><button type="button" class="wk-ac-btn wk-ac-qz__check">' + esc( 'scale' === q.t || 'reflect' === q.t ? w.next : w.check ) + '</button></div></div>';
				stage.innerHTML = h;
				var ans = $( '.wk-ac-qz__ans', stage ), check = $( '.wk-ac-qz__check', stage );
				var api = builders[ q.t ]( q, ans, check );
				check.addEventListener( 'click', function () {
					if ( check.getAttribute( 'data-next' ) ) { next(); return; }
					var res = api.grade();
					results[ idx ] = res;
					api.reveal( res );
					feedback( q, res );
					check.setAttribute( 'data-next', '1' );
					check.textContent = idx < qs.length - 1 ? w.next : w.results;
					check.disabled = false;
					if ( res.free ) { next(); }
				} );
				var card = $( '.wk-ac-qz__card', stage );
				anim( card, [ { opacity: 0, transform: 'translateX(24px)' }, { opacity: 1, transform: 'none' } ], { duration: 320, easing: 'cubic-bezier(.2,.7,.2,1)' } );
				var first = $( '.wk-ac-opt, .wk-ac-qz__ans textarea, .wk-ac-qz__ans input', stage );
				if ( first ) { first.focus( { preventScroll: true } ); }
			}

			function feedback( q, res ) {
				if ( res.free ) { return; }
				var fb = $( '.wk-ac-qz__fb', stage );
				fb.hidden = false;
				fb.className = 'wk-ac-qz__fb ' + ( res.ok ? 'is-ok' : 'is-ko' );
				fb.innerHTML = '<strong>' + ICON( res.ok ? 'check' : 'x' ) + esc( res.ok ? w.ok : w.ko ) + '</strong>' + ( q.w ? '<p>' + esc( q.w ) + '</p>' : '' );
				anim( fb, res.ok ? [ { transform: 'scale(.96)' }, { transform: 'scale(1.02)' }, { transform: 'none' } ] : [ { transform: 'translateX(0)' }, { transform: 'translateX(-6px)' }, { transform: 'translateX(6px)' }, { transform: 'none' } ], { duration: 360 } );
				if ( cfg.sound ) { tone( res.ok ); }
			}

			function next() {
				if ( idx < qs.length - 1 ) { idx++; render(); } else { finish(); }
			}

			function finish() {
				clearInterval( timer );
				var pts = 0;
				qs.forEach( function ( q, k ) { var r = results[ k ]; if ( r && ! r.free ) { pts += r.pts; } } );
				var score = scoredN ? Math.round( 100 * pts / scoredN ) : 100, pass = score >= cfg.pass;
				idx = qs.length;
				dots();
				Store.quiz( cfg.key, score, pass, cfg.n, cfg.title );
				var C = 2 * Math.PI * 52;
				var h = '<div class="wk-ac-qz__card wk-ac-qz__end ' + ( pass ? 'is-pass' : 'is-fail' ) + '">' +
					'<p class="wk-ac-qz__k">' + esc( w.score ) + '</p><div class="wk-ac-ring"><svg viewBox="0 0 120 120" aria-hidden="true"><circle cx="60" cy="60" r="52" class="wk-ac-ring__bg"/><circle cx="60" cy="60" r="52" class="wk-ac-ring__fg" stroke-dasharray="' + C.toFixed( 1 ) + '" stroke-dashoffset="' + C.toFixed( 1 ) + '"/></svg><b>' + score + '%</b></div>' +
					'<h3 class="wk-ac-qz__q">' + esc( pass ? w.pass : w.fail ) + '</h3>';
				if ( pass && cfg.badge ) { h += '<p class="wk-ac-qz__badge">' + ICON( 'star' ) + '<span>' + esc( cfg.badge ) + '</span></p>'; }
				if ( pass && cfg.passTxt ) { h += '<p>' + esc( cfg.passTxt ) + '</p>'; }
				if ( scoredN ) { h += '<p class="wk-ac-qz__help">' + esc( w.need + ' ' + cfg.pass + '%' ) + '</p>'; }
				h += '<div class="wk-ac-qz__act">';
				if ( pass && cfg.cert && G.user ) { h += '<a class="wk-ac-btn" href="' + esc( cfg.cert + ( cfg.cert.indexOf( '?' ) > -1 ? '&' : '?' ) + 'curso=' + encodeURIComponent( cfg.key ) ) + '">' + ICON( 'cert' ) + esc( w.cert ) + '</a>'; }
				if ( ! pass ) { h += '<button type="button" class="wk-ac-btn wk-ac-qz__again">' + esc( w.retry ) + '</button>'; }
				h += '<button type="button" class="wk-ac-btn is-ghost wk-ac-qz__done">' + esc( w.close ) + '</button></div>';
				if ( ! G.user ) { h += '<p class="wk-ac-guest">' + esc( w.guest ) + '</p>'; }
				h += '<details class="wk-ac-qz__review"><summary>' + esc( w.review ) + '</summary><ol>' + qs.map( function ( q, k ) {
					var r = results[ k ];
					return '<li class="' + ( ! r ? 'is-ko' : ( r.free ? 'is-free' : ( r.ok ? 'is-ok' : 'is-ko' ) ) ) + '">' + ( r && r.free ? '' : ICON( r && r.ok ? 'check' : 'x' ) ) + esc( q.q ) + ( q.w ? '<small>' + esc( q.w ) + '</small>' : '' ) + '</li>';
				} ).join( '' ) + '</ol></details></div>';
				stage.innerHTML = h;
				var fg = $( '.wk-ac-ring__fg', stage );
				var off = C * ( 1 - score / 100 );
				if ( reduce || ! fg.animate ) { fg.setAttribute( 'stroke-dashoffset', off ); }
				else { fg.animate( [ { strokeDashoffset: C }, { strokeDashoffset: off } ], { duration: 1100, easing: 'cubic-bezier(.2,.7,.2,1)', fill: 'forwards' } ); }
				if ( pass ) { confetti( stage ); if ( cfg.sound ) { tone( true ); } }
				var again = $( '.wk-ac-qz__again', stage );
				if ( again ) { again.addEventListener( 'click', function () { close(); run(); } ); }
				$( '.wk-ac-qz__done', stage ).addEventListener( 'click', close );
				$( '.wk-ac-qz__done', stage ).focus( { preventScroll: true } );
			}

			render();
		}
	}

	function confetti( host ) {
		if ( reduce ) { return; }
		var box = el( 'div', 'wk-ac-confetti' );
		for ( var i = 0; i < 36; i++ ) {
			var p = el( 'i' );
			p.style.left = ( Math.random() * 100 ) + '%';
			p.style.setProperty( '--h', Math.floor( Math.random() * 360 ) );
			box.appendChild( p );
			p.animate( [ { transform: 'translateY(-20px) rotate(0)', opacity: 1 }, { transform: 'translateY(' + ( 260 + Math.random() * 200 ) + 'px) rotate(' + ( Math.random() * 720 - 360 ) + 'deg)', opacity: 0 } ], { duration: 1400 + Math.random() * 900, easing: 'cubic-bezier(.2,.6,.4,1)', delay: Math.random() * 300, fill: 'forwards' } );
		}
		host.appendChild( box );
		setTimeout( function () { box.remove(); }, 2800 );
	}

	/* Each builder draws the answers and returns { grade(), reveal(res) }. grade gives { ok, pts (0..1), free }. */
	var builders = {
		one: function ( q, ans, check ) { return choice( q, ans, check, false ); },
		many: function ( q, ans, check ) { return choice( q, ans, check, true ); },
		tf: function ( q, ans, check ) {
			var w = wordsOf( ans );
			q = { o: [ [ w.true, q.a ], [ w.false, ! q.a ] ] };
			ans.classList.add( 'is-tf' );
			return choice( q, ans, check, false );
		},
		order: function ( q, ans, check ) {
			var items = q.o.map( function ( t, i ) { return { t: t, i: i }; } ), list = el( 'ol', 'wk-ac-order' );
			do { items = shuffle( items ); } while ( items.length > 1 && items.every( function ( x, k ) { return x.i === k; } ) );
			function draw() {
				list.innerHTML = items.map( function ( x, k ) {
					return '<li draggable="true" data-k="' + k + '"><span class="wk-ac-order__grip" aria-hidden="true">⋮⋮</span><span class="wk-ac-order__t">' + esc( x.t ) + '</span>' +
						'<button type="button" class="wk-ac-order__b" data-mv="-1" aria-label="↑"' + ( k ? '' : ' disabled' ) + '>' + ICON( 'up' ) + '</button><button type="button" class="wk-ac-order__b" data-mv="1" aria-label="↓"' + ( k < items.length - 1 ? '' : ' disabled' ) + '>' + ICON( 'down' ) + '</button></li>';
				} ).join( '' );
			}
			draw();
			ans.appendChild( list );
			list.addEventListener( 'click', function ( ev ) {
				var b = ev.target.closest( '[data-mv]' );
				if ( ! b || list.classList.contains( 'is-locked' ) ) { return; }
				var k = parseInt( b.closest( 'li' ).getAttribute( 'data-k' ), 10 ), d = parseInt( b.getAttribute( 'data-mv' ), 10 ), j = k + d;
				var t = items[ k ]; items[ k ] = items[ j ]; items[ j ] = t;
				draw();
				var nb = $( 'li[data-k="' + j + '"] [data-mv="' + d + '"]', list ) || $( 'li[data-k="' + j + '"] [data-mv]', list );
				if ( nb ) { nb.focus(); }
			} );
			var from = null;
			list.addEventListener( 'dragstart', function ( ev ) { var li = ev.target.closest( 'li' ); from = parseInt( li.getAttribute( 'data-k' ), 10 ); li.classList.add( 'is-drag' ); ev.dataTransfer.effectAllowed = 'move'; try { ev.dataTransfer.setData( 'text/plain', '' + from ); } catch ( e ) {} } );
			list.addEventListener( 'dragover', function ( ev ) { ev.preventDefault(); } );
			list.addEventListener( 'drop', function ( ev ) {
				ev.preventDefault();
				var li = ev.target.closest( 'li' );
				if ( ! li || null === from || list.classList.contains( 'is-locked' ) ) { return; }
				var to = parseInt( li.getAttribute( 'data-k' ), 10 ), x = items.splice( from, 1 )[ 0 ];
				items.splice( to, 0, x );
				from = null;
				draw();
			} );
			list.addEventListener( 'dragend', function () { from = null; $$( '.is-drag', list ).forEach( function ( n ) { n.classList.remove( 'is-drag' ); } ); } );
			// Touch: press and slide over the other rows.
			var tFrom = null;
			list.addEventListener( 'touchstart', function ( ev ) { var li = ev.target.closest( 'li' ); if ( li && ev.target.closest( '.wk-ac-order__grip' ) ) { tFrom = parseInt( li.getAttribute( 'data-k' ), 10 ); li.classList.add( 'is-drag' ); } }, { passive: true } );
			list.addEventListener( 'touchmove', function ( ev ) {
				if ( null === tFrom ) { return; }
				ev.preventDefault();
				var t = ev.touches[ 0 ], over = document.elementFromPoint( t.clientX, t.clientY ), li = over && over.closest( '.wk-ac-order li' );
				if ( li ) {
					var to = parseInt( li.getAttribute( 'data-k' ), 10 );
					if ( to !== tFrom ) { var x = items.splice( tFrom, 1 )[ 0 ]; items.splice( to, 0, x ); tFrom = to; draw(); $( 'li[data-k="' + to + '"]', list ).classList.add( 'is-drag' ); }
				}
			}, { passive: false } );
			list.addEventListener( 'touchend', function () { tFrom = null; $$( '.is-drag', list ).forEach( function ( n ) { n.classList.remove( 'is-drag' ); } ); } );
			return {
				grade: function () {
					var good = items.filter( function ( x, k ) { return x.i === k; } ).length;
					return { ok: good === items.length, pts: items.length ? good / items.length : 0 };
				},
				reveal: function () {
					list.classList.add( 'is-locked' );
					$$( 'li', list ).forEach( function ( li, k ) {
						li.setAttribute( 'draggable', 'false' );
						li.classList.add( items[ k ].i === k ? 'is-ok' : 'is-ko' );
						if ( items[ k ].i !== k ) { $( '.wk-ac-order__grip', li ).textContent = items[ k ].i + 1; }
					} );
					$$( 'button', list ).forEach( function ( b ) { b.disabled = true; } );
				}
			};
		},
		match: function ( q, ans ) {
			var left = q.o.map( function ( p, i ) { return { t: p[ 0 ], i: i }; } );
			var right = shuffle( q.o.map( function ( p, i ) { return { t: p[ 1 ], i: i }; } ) );
			var pairs = {}, sel = null;
			ans.classList.add( 'is-match' );
			ans.innerHTML = '<div class="wk-ac-match"><ul class="wk-ac-match__l">' + left.map( function ( x ) { return '<li><button type="button" class="wk-ac-opt" data-l="' + x.i + '">' + esc( x.t ) + '</button></li>'; } ).join( '' ) + '</ul>' +
				'<ul class="wk-ac-match__r">' + right.map( function ( x ) { return '<li><button type="button" class="wk-ac-opt" data-r="' + x.i + '">' + esc( x.t ) + '</button></li>'; } ).join( '' ) + '</ul></div>';
			function paint() {
				var colors = {};
				Object.keys( pairs ).forEach( function ( l, n ) { colors[ 'l' + l ] = n + 1; colors[ 'r' + pairs[ l ] ] = n + 1; } );
				$$( '[data-l]', ans ).forEach( function ( b ) { var c = colors[ 'l' + b.getAttribute( 'data-l' ) ]; b.setAttribute( 'data-pair', c || '' ); b.classList.toggle( 'is-sel', sel === b.getAttribute( 'data-l' ) ); b.setAttribute( 'aria-pressed', sel === b.getAttribute( 'data-l' ) ? 'true' : 'false' ); } );
				$$( '[data-r]', ans ).forEach( function ( b ) { var c = colors[ 'r' + b.getAttribute( 'data-r' ) ]; b.setAttribute( 'data-pair', c || '' ); } );
			}
			ans.addEventListener( 'click', function ( ev ) {
				var b = ev.target.closest( '.wk-ac-opt' );
				if ( ! b || b.disabled ) { return; }
				if ( b.hasAttribute( 'data-l' ) ) {
					var l = b.getAttribute( 'data-l' );
					if ( pairs[ l ] !== undefined ) { delete pairs[ l ]; }
					sel = sel === l ? null : l;
				} else if ( null !== sel ) {
					var r = b.getAttribute( 'data-r' );
					Object.keys( pairs ).forEach( function ( k ) { if ( pairs[ k ] === r ) { delete pairs[ k ]; } } );
					pairs[ sel ] = r;
					sel = null;
				}
				paint();
			} );
			return {
				grade: function () {
					var good = left.filter( function ( x ) { return pairs[ x.i ] === String( x.i ); } ).length;
					return { ok: good === left.length, pts: left.length ? good / left.length : 0 };
				},
				reveal: function () {
					$$( '[data-l]', ans ).forEach( function ( b ) {
						var l = b.getAttribute( 'data-l' );
						b.disabled = true;
						b.classList.add( pairs[ l ] === l ? 'is-ok' : 'is-ko' );
						if ( pairs[ l ] !== l ) { b.insertAdjacentHTML( 'beforeend', '<small>→ ' + esc( q.o[ l ][ 1 ] ) + '</small>' ); }
					} );
					$$( '[data-r]', ans ).forEach( function ( b ) { b.disabled = true; } );
				}
			};
		},
		scale: function ( q, ans ) {
			var w = wordsOf( ans );
			ans.innerHTML = '<div class="wk-ac-scale"><input type="range" min="0" max="10" value="5" aria-label="' + esc( q.q ) + '"><div class="wk-ac-scale__l"><span>' + esc( q.o[ 0 ] ) + '</span><b>5</b><span>' + esc( q.o[ 1 ] ) + '</span></div></div>';
			var r = $( 'input', ans ), b = $( 'b', ans );
			r.addEventListener( 'input', function () { b.textContent = r.value; } );
			return { grade: function () { return { free: true, v: r.value, msg: w.saved }; }, reveal: function () { r.disabled = true; } };
		},
		reflect: function ( q, ans ) {
			var w = wordsOf( ans ), k = 'wk_ac_r_' + ( ans.closest( '[data-key]' ) ? ans.closest( '[data-key]' ).getAttribute( 'data-key' ) : '' ) + '_' + q.q.length;
			ans.innerHTML = '<textarea rows="4" class="wk-ac-reflect" aria-label="' + esc( q.q ) + '"></textarea>';
			var t = $( 'textarea', ans );
			t.value = lsGet( k, '' ) || '';
			return { grade: function () { lsSet( k, t.value ); return { free: true, msg: w.saved }; }, reveal: function () { t.readOnly = true; } };
		}
	};

	function wordsOf( node ) {
		var q = node.closest( '.wk-ac-qz' ), src = q && q.__words;
		return src || {};
	}

	function choice( q, ans, check, multi ) {
		ans.innerHTML = q.o.map( function ( o, i ) {
			return '<button type="button" class="wk-ac-opt" role="' + ( multi ? 'checkbox' : 'radio' ) + '" aria-checked="false" data-i="' + i + '"><span class="wk-ac-opt__k">' + ( i + 1 ) + '</span><span>' + esc( o[ 0 ] ) + '</span></button>';
		} ).join( '' );
		ans.setAttribute( 'role', multi ? 'group' : 'radiogroup' );
		check.disabled = true;
		ans.addEventListener( 'click', function ( ev ) {
			var b = ev.target.closest( '.wk-ac-opt' );
			if ( ! b || b.disabled ) { return; }
			if ( multi ) { b.setAttribute( 'aria-checked', 'true' === b.getAttribute( 'aria-checked' ) ? 'false' : 'true' ); }
			else { $$( '.wk-ac-opt', ans ).forEach( function ( o ) { o.setAttribute( 'aria-checked', o === b ? 'true' : 'false' ); } ); }
			check.disabled = ! $( '[aria-checked="true"]', ans );
		} );
		return {
			grade: function () {
				var hit = 0, wrong = 0, total = 0;
				$$( '.wk-ac-opt', ans ).forEach( function ( b ) {
					var good = q.o[ b.getAttribute( 'data-i' ) ][ 1 ], on = 'true' === b.getAttribute( 'aria-checked' );
					if ( good ) { total++; if ( on ) { hit++; } } else if ( on ) { wrong++; }
				} );
				var ok = hit === total && ! wrong;
				return { ok: ok, pts: ok ? 1 : ( multi && total ? Math.max( 0, ( hit - wrong ) / total ) : 0 ) };
			},
			reveal: function () {
				$$( '.wk-ac-opt', ans ).forEach( function ( b ) {
					var good = q.o[ b.getAttribute( 'data-i' ) ][ 1 ], on = 'true' === b.getAttribute( 'aria-checked' );
					b.disabled = true;
					if ( good ) { b.classList.add( 'is-ok' ); } else if ( on ) { b.classList.add( 'is-ko' ); }
				} );
			}
		};
	}

	/* ---------- Boot ---------- */

	var kinds = { head: head, room: room, syllabus: syllabus, catalog: catalog, dashboard: dashboard, quiz: quiz };

	function boot( scope ) {
		$$( '[data-wk-ac]', scope ).forEach( function ( n ) {
			if ( n.__wkac ) { return; }
			n.__wkac = true;
			var k = kinds[ n.getAttribute( 'data-wk-ac' ) ];
			if ( k ) { k( n ); }
		} );
	}

	if ( 'loading' === document.readyState ) { document.addEventListener( 'DOMContentLoaded', function () { boot(); } ); } else { boot(); }
	window.addEventListener( 'elementor/frontend/init', function () {
		if ( window.elementorFrontend && window.elementorFrontend.hooks ) {
			window.elementorFrontend.hooks.addAction( 'frontend/element_ready/global', function ( $scope ) { boot( $scope[ 0 ] ); } );
		}
	} );
}() );
