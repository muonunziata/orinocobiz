<?php
/**
 * Aula: the lesson room. Video player (YouTube/Vimeo load only on click, or a
 * file from the media library), lesson list with ticks, summary, practice,
 * resources, personal notes, previous / next and the progress of the course.
 * A lesson without video shows its summary ("vídeo en preparación").
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Academia\Widgets;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Wakoo\Modules\Academia\Module;

defined( 'ABSPATH' ) || die();

class Aula extends Base {

	public function get_name() { return 'wakoo-ac-aula'; }
	public function get_title() { return __( 'Aula (lecciones en vídeo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-video-playlist'; }
	public function get_keywords() { return [ 'curso', 'leccion', 'video', 'aula', 'lesson', 'playlist', 'academia', 'wakoo' ]; }

	protected function words() {
		return [
			'lesson'  => [ __( 'Lección', 'wakoo' ) ],
			'of'      => [ __( 'de', 'wakoo' ), __( 'Palabra «de» (Lección 2 de 10)', 'wakoo' ) ],
			'done'    => [ __( 'Marcar como vista', 'wakoo' ), __( 'Botón para marcar la lección', 'wakoo' ) ],
			'isdone'  => [ __( 'Vista', 'wakoo' ), __( 'Lección ya vista', 'wakoo' ) ],
			'prev'    => [ __( 'Anterior', 'wakoo' ) ],
			'next'    => [ __( 'Siguiente', 'wakoo' ) ],
			'soon'    => [ __( 'Vídeo en preparación. Mientras tanto, aquí tienes el contenido de la lección.', 'wakoo' ), __( 'Aviso sin vídeo', 'wakoo' ) ],
			'summary' => [ __( 'De qué trata', 'wakoo' ), __( 'Pestaña del resumen', 'wakoo' ) ],
			'practice'=> [ __( 'Tu práctica', 'wakoo' ), __( 'Pestaña del ejercicio', 'wakoo' ) ],
			'notes'   => [ __( 'Mis notas', 'wakoo' ), __( 'Pestaña de notas', 'wakoo' ) ],
			'notesph' => [ __( 'Escribe aquí lo que quieras recordar. Se guarda en este dispositivo.', 'wakoo' ), __( 'Texto de ayuda de las notas', 'wakoo' ) ],
			'res'     => [ __( 'Material', 'wakoo' ), __( 'Título de los recursos', 'wakoo' ) ],
			'list'    => [ __( 'Lecciones del curso', 'wakoo' ), __( 'Título de la lista', 'wakoo' ) ],
			'quiz'    => [ __( 'Ir a la evaluación', 'wakoo' ), __( 'Botón al terminar', 'wakoo' ) ],
			'finish'  => [ __( '¡Has visto todas las lecciones! Ya puedes hacer la evaluación.', 'wakoo' ), __( 'Mensaje al terminar', 'wakoo' ) ],
			'play'    => [ __( 'Reproducir', 'wakoo' ), __( 'Botón de reproducir (vídeos externos)', 'wakoo' ) ],
			'consent' => [ __( 'El vídeo se carga desde', 'wakoo' ), __( 'Aviso de vídeo externo', 'wakoo' ) ],
			'login'   => [ __( 'Tu progreso se guarda en este dispositivo. Inicia sesión para tenerlo en todos.', 'wakoo' ), __( 'Aviso para quien no ha iniciado sesión', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_lessons', [ 'label' => __( 'Lecciones', 'wakoo' ) ] );
		$r = new Repeater();
		$r->add_control( 'title', [ 'label' => __( 'Título', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'label_block' => true, 'default' => __( 'Lección', 'wakoo' ) ] );
		$r->add_control( 'dur', [ 'label' => __( 'Duración (mm:ss)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '3:00' ] );
		$r->add_control( 'video', [ 'label' => __( 'Vídeo (YouTube, Vimeo o mp4)', 'wakoo' ), 'type' => Controls_Manager::URL, 'options' => false ] );
		$r->add_control( 'file', [ 'label' => __( 'O un vídeo de la biblioteca', 'wakoo' ), 'type' => Controls_Manager::MEDIA, 'media_types' => [ 'video' ] ] );
		$r->add_control( 'poster', [ 'label' => __( 'Portada del vídeo', 'wakoo' ), 'type' => Controls_Manager::MEDIA ] );
		$r->add_control( 'summary', [ 'label' => __( 'De qué trata', 'wakoo' ), 'type' => Controls_Manager::WYSIWYG ] );
		$r->add_control( 'practice', [ 'label' => __( 'Tu práctica', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 3 ] );
		$r->add_control( 'res_label', [ 'label' => __( 'Material: texto', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$r->add_control( 'res_link', [ 'label' => __( 'Material: enlace o archivo', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$r->add_control( 'free', [ 'label' => __( 'Vista previa abierta', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'description' => __( 'Solo cuenta si el aula pide iniciar sesión.', 'wakoo' ) ] );
		$this->add_control( 'lessons', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'title_field' => '{{{ title }}} · {{{ dur }}}',
			'default'     => [
				[ 'title' => __( 'Bienvenida', 'wakoo' ), 'dur' => '3:00' ],
				[ 'title' => __( 'La idea principal', 'wakoo' ), 'dur' => '3:00' ],
				[ 'title' => __( 'Práctica guiada', 'wakoo' ), 'dur' => '3:00' ],
			],
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_room', [ 'label' => __( 'Aula', 'wakoo' ) ] );
		$this->add_control( 'anchor_note', [
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => __( 'Pon «aula» como ID CSS (Avanzado) para que el botón de la cabecera llegue aquí.', 'wakoo' ),
			'content_classes' => 'elementor-descriptor',
		] );
		$this->add_control( 'login', [ 'label' => __( 'Pedir iniciar sesión', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'description' => __( 'Sin sesión solo se ven las lecciones con vista previa abierta.', 'wakoo' ) ] );
		$this->add_control( 'login_url', [ 'label' => __( 'Enlace para iniciar sesión', 'wakoo' ), 'type' => Controls_Manager::URL, 'condition' => [ 'login' => 'yes' ] ] );
		$this->add_control( 'login_txt', [ 'label' => __( 'Texto de la lección cerrada', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Inicia sesión para ver esta lección.', 'wakoo' ), 'condition' => [ 'login' => 'yes' ] ] );
		$this->add_control( 'auto_next', [ 'label' => __( 'Al acabar un vídeo, marcarlo y pasar al siguiente', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'quiz_anchor', [ 'label' => __( 'Ancla de la evaluación', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '#evaluacion' ] );
		$this->end_controls_section();
		$this->texts_section();
		$this->style_section( '.wk-ac-room__h' );
	}

	/** Embed URL for YouTube / Vimeo, or '' for a direct file. */
	private static function embed( $url ) {
		if ( preg_match( '~(?:youtu\.be/|youtube(?:-nocookie)?\.com/(?:watch\?v=|embed/|shorts/))([\w-]{11})~', $url, $m ) ) {
			return [ 'https://www.youtube-nocookie.com/embed/' . $m[1] . '?autoplay=1&rel=0&enablejsapi=1', 'YouTube' ];
		}
		if ( preg_match( '~vimeo\.com/(?:video/)?(\d+)~', $url, $m ) ) {
			return [ 'https://player.vimeo.com/video/' . $m[1] . '?autoplay=1&dnt=1', 'Vimeo' ];
		}
		return null;
	}

	protected function render() {
		$s     = $this->get_settings_for_display();
		$items = (array) ( $s['lessons'] ?? [] );
		if ( ! $items ) { return; }
		$c     = $this->course();
		$gate  = 'yes' === $s['login'] && ! Module::learner();
		$cfg   = [
			'key'   => $c['key'] ?? 'p' . get_the_ID(),
			'title' => $c['title'] ?? get_the_title(),
			'n'     => count( $items ),
			'auto'  => 'yes' === $s['auto_next'],
			'quiz'  => $s['quiz_anchor'] ?: '#evaluacion',
		];
		$total = 0;
		foreach ( $items as $l ) { $total += Module::minutes( $l['dur'] ?? '' ); }

		echo '<div class="wk-ac wk-ac-room" data-wk-ac="room" data-cfg="' . esc_attr( wp_json_encode( $cfg ) ) . '" data-words="' . esc_attr( $this->words_json( $s ) ) . '">';
		echo '<div class="wk-ac-room__main">';
		foreach ( $items as $i => $l ) {
			$n      = $i + 1;
			$locked = $gate && 'yes' !== ( $l['free'] ?? '' );
			$url    = $l['video']['url'] ?? '';
			$file   = $l['file']['url'] ?? '';
			$poster = $l['poster']['url'] ?? '';
			echo '<article class="wk-ac-lesson" id="leccion-' . (int) $n . '" data-i="' . (int) $i . '"' . ( $i ? ' hidden' : '' ) . '>';
			echo '<div class="wk-ac-stage">';
			if ( $locked ) {
				echo '<div class="wk-ac-stage__soon is-locked">' . self::icon( 'lock' ) . '<p>' . esc_html( $s['login_txt'] ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
				if ( ! empty( $s['login_url']['url'] ) ) { echo '<a class="wk-ac-btn" href="' . esc_url( $s['login_url']['url'] ) . '">' . esc_html__( 'Iniciar sesión', 'wakoo' ) . '</a>'; }
				echo '</div>';
			} elseif ( $file || ( $url && ! self::embed( $url ) ) ) {
				echo '<video class="wk-ac-video" controls preload="metadata" playsinline src="' . esc_url( $file ?: $url ) . '"' . ( $poster ? ' poster="' . esc_url( $poster ) . '"' : '' ) . '></video>';
			} elseif ( $url ) {
				$e = self::embed( $url );
				echo '<button type="button" class="wk-ac-ext" data-src="' . esc_attr( $e[0] ) . '"' . ( $poster ? ' style="background-image:url(' . esc_url( $poster ) . ')"' : '' ) . '>';
				echo '<span class="wk-ac-ext__play">' . self::icon( 'play' ) . '</span><span class="wk-ac-ext__txt">' . esc_html( $this->word( $s, 'play' ) ) . ' · ' . esc_html( $this->word( $s, 'consent' ) . ' ' . $e[1] ) . '</span></button>'; // phpcs:ignore WordPress.Security.EscapeOutput
			} else {
				echo '<div class="wk-ac-stage__soon"' . ( $poster ? ' style="background-image:url(' . esc_url( $poster ) . ')"' : '' ) . '><span class="wk-ac-stage__n">' . (int) $n . '</span><p class="wk-ac-stage__t">' . esc_html( $l['title'] ) . '</p><p>' . esc_html( $this->word( $s, 'soon' ) ) . '</p></div>';
			}
			echo '</div>';
			echo '<div class="wk-ac-lesson__bar"><div><span class="wk-ac-lesson__k">' . esc_html( $this->word( $s, 'lesson' ) . ' ' . $n . ' ' . $this->word( $s, 'of' ) . ' ' . count( $items ) ) . '</span>';
			echo '<h3 class="wk-ac-room__h">' . esc_html( $l['title'] ) . '</h3></div>';
			echo '<button type="button" class="wk-ac-btn is-ghost wk-ac-done"' . ( $locked ? ' disabled' : '' ) . '>' . self::icon( 'check' ) . '<span>' . esc_html( $this->word( $s, 'done' ) ) . '</span></button></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
			if ( ! $locked ) {
				$tabs = [];
				if ( ! empty( $l['summary'] ) ) { $tabs['s'] = [ $this->word( $s, 'summary' ), '<div class="wk-ac-rich">' . wp_kses_post( $l['summary'] ) . '</div>' ]; }
				if ( ! empty( $l['practice'] ) ) { $tabs['p'] = [ $this->word( $s, 'practice' ), '<p class="wk-ac-practice">' . nl2br( esc_html( $l['practice'] ) ) . '</p>' ]; }
				$tabs['n'] = [ $this->word( $s, 'notes' ), '<textarea class="wk-ac-notes" rows="5" placeholder="' . esc_attr( $this->word( $s, 'notesph' ) ) . '" aria-label="' . esc_attr( $this->word( $s, 'notes' ) ) . '"></textarea>' ];
				echo '<div class="wk-ac-tabs" role="tablist">';
				$first = true;
				foreach ( $tabs as $k => $t ) {
					echo '<button type="button" role="tab" class="wk-ac-tab" data-tab="' . esc_attr( $k ) . '" aria-selected="' . ( $first ? 'true' : 'false' ) . '">' . esc_html( $t[0] ) . '</button>';
					$first = false;
				}
				echo '</div>';
				$first = true;
				foreach ( $tabs as $k => $t ) {
					echo '<div class="wk-ac-pane" role="tabpanel" data-pane="' . esc_attr( $k ) . '"' . ( $first ? '' : ' hidden' ) . '>' . $t[1] . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
					$first = false;
				}
				if ( ! empty( $l['res_link']['url'] ) ) {
					echo '<p class="wk-ac-res"><strong>' . esc_html( $this->word( $s, 'res' ) ) . ':</strong> <a href="' . esc_url( $l['res_link']['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $l['res_label'] ?: $l['res_link']['url'] ) . '</a></p>';
				}
			}
			echo '<nav class="wk-ac-lesson__nav"><button type="button" class="wk-ac-btn is-ghost" data-go="' . (int) ( $i - 1 ) . '"' . ( $i ? '' : ' disabled' ) . '>← ' . esc_html( $this->word( $s, 'prev' ) ) . '</button>';
			if ( $n < count( $items ) ) {
				echo '<button type="button" class="wk-ac-btn" data-go="' . (int) ( $i + 1 ) . '">' . esc_html( $this->word( $s, 'next' ) ) . ' →</button>';
			} else {
				echo '<a class="wk-ac-btn" href="' . esc_attr( $cfg['quiz'] ) . '">' . esc_html( $this->word( $s, 'quiz' ) ) . ' →</a>';
			}
			echo '</nav></article>';
		}
		echo '<p class="wk-ac-finish" hidden>' . self::icon( 'star' ) . esc_html( $this->word( $s, 'finish' ) ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( ! Module::learner() ) { echo '<p class="wk-ac-guest">' . esc_html( $this->word( $s, 'login' ) ) . '</p>'; }
		echo '</div>';

		echo '<aside class="wk-ac-room__side"><div class="wk-ac-room__sidehead"><strong>' . esc_html( $this->word( $s, 'list' ) ) . '</strong><span>' . esc_html( count( $items ) . ' · ' . self::hm( $total ) ) . '</span></div>';
		echo '<div class="wk-ac-bar"><span class="wk-ac-bar__track"><i style="width:0"></i></span><b>0%</b></div><ol class="wk-ac-list">';
		foreach ( $items as $i => $l ) {
			$locked = $gate && 'yes' !== ( $l['free'] ?? '' );
			echo '<li><button type="button" class="wk-ac-item' . ( $i ? '' : ' is-on' ) . '" data-go="' . (int) $i . '"' . ( $i ? '' : ' aria-current="true"' ) . '>';
			echo '<span class="wk-ac-item__n">' . ( $locked ? self::icon( 'lock' ) : (int) ( $i + 1 ) ) . '</span><span class="wk-ac-item__t">' . esc_html( $l['title'] ) . '</span><span class="wk-ac-item__d">' . esc_html( $l['dur'] ) . '</span></button></li>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</ol></aside></div>';
	}
}
