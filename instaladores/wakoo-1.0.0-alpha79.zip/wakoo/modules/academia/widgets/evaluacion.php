<?php
/**
 * Evaluación interactiva: an immersive, full-screen test with scenes, media
 * (image, video, audio) and seven kinds of question: one answer, several
 * answers, true / false, put in order, match pairs, a self-rating scale and
 * an open reflection (the last two do not score). Feedback after each answer,
 * a final score with review, retry, and the certificate when it is passed.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Academia\Widgets;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Wakoo\Modules\Academia\Module;

defined( 'ABSPATH' ) || die();

class Evaluacion extends Base {

	public function get_name() { return 'wakoo-ac-evaluacion'; }
	public function get_title() { return __( 'Evaluación interactiva', 'wakoo' ); }
	public function get_icon() { return 'eicon-checkbox'; }
	public function get_keywords() { return [ 'evaluacion', 'quiz', 'test', 'examen', 'preguntas', 'curso', 'academia', 'wakoo' ]; }

	protected function words() {
		return [
			'start'   => [ __( 'Empezar la evaluación', 'wakoo' ), __( 'Botón de empezar', 'wakoo' ) ],
			'q'       => [ __( 'Pregunta', 'wakoo' ) ],
			'of'      => [ __( 'de', 'wakoo' ) ],
			'check'   => [ __( 'Comprobar', 'wakoo' ) ],
			'next'    => [ __( 'Siguiente', 'wakoo' ) ],
			'results' => [ __( 'Ver mi resultado', 'wakoo' ) ],
			'ok'      => [ __( '¡Correcto!', 'wakoo' ) ],
			'ko'      => [ __( 'No del todo', 'wakoo' ) ],
			'saved'   => [ __( 'Gracias, lo hemos guardado.', 'wakoo' ), __( 'Tras una reflexión o una escala', 'wakoo' ) ],
			'one'     => [ __( 'Elige una respuesta', 'wakoo' ) ],
			'many'    => [ __( 'Elige todas las que sean ciertas', 'wakoo' ) ],
			'true'    => [ __( 'Verdadero', 'wakoo' ) ],
			'false'   => [ __( 'Falso', 'wakoo' ) ],
			'order'   => [ __( 'Arrastra para ordenar (o usa las flechas)', 'wakoo' ) ],
			'match'   => [ __( 'Une cada frase con su pareja', 'wakoo' ) ],
			'pick'    => [ __( 'Elige…', 'wakoo' ) ],
			'scale'   => [ __( 'Mueve el control: no hay respuestas buenas ni malas', 'wakoo' ) ],
			'reflect' => [ __( 'Escribe con tus palabras (no puntúa)', 'wakoo' ) ],
			'hint'    => [ __( 'Ver una pista', 'wakoo' ) ],
			'score'   => [ __( 'Tu resultado', 'wakoo' ) ],
			'need'    => [ __( 'Para aprobar hace falta', 'wakoo' ) ],
			'pass'    => [ __( '¡Enhorabuena, has aprobado!', 'wakoo' ) ],
			'fail'    => [ __( 'Aún no. Repasa las lecciones y vuelve a intentarlo.', 'wakoo' ) ],
			'retry'   => [ __( 'Intentarlo otra vez', 'wakoo' ) ],
			'review'  => [ __( 'Repasa tus respuestas', 'wakoo' ) ],
			'close'   => [ __( 'Cerrar', 'wakoo' ) ],
			'cert'    => [ __( 'Ver mi certificado', 'wakoo' ) ],
			'locked'  => [ __( 'Se abre cuando hayas visto todas las lecciones.', 'wakoo' ), __( 'Aviso de evaluación cerrada', 'wakoo' ) ],
			'time'    => [ __( 'Tiempo', 'wakoo' ) ],
			'guest'   => [ __( 'Inicia sesión para guardar tu resultado y recibir el certificado.', 'wakoo' ), __( 'Aviso sin sesión', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_intro', [ 'label' => __( 'Evaluación', 'wakoo' ) ] );
		$this->add_control( 'title', [ 'label' => __( 'Título', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'label_block' => true, 'default' => __( 'Evaluación final', 'wakoo' ) ] );
		$this->add_control( 'intro', [ 'label' => __( 'Introducción', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 3 ] );
		$this->add_control( 'bg', [ 'label' => __( 'Imagen de fondo de la escena', 'wakoo' ), 'type' => Controls_Manager::MEDIA ] );
		$this->add_control( 'pass', [
			'label'   => __( 'Nota para aprobar (%)', 'wakoo' ),
			'type'    => Controls_Manager::SLIDER,
			'range'   => [ 'px' => [ 'min' => 0, 'max' => 100 ] ],
			'default' => [ 'size' => 70 ],
		] );
		$this->add_control( 'gate', [ 'label' => __( 'Abrir solo con todas las lecciones vistas', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'immersive', [ 'label' => __( 'A pantalla completa', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'shuffle', [ 'label' => __( 'Mezclar las respuestas', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'timer', [ 'label' => __( 'Tiempo límite (minutos, 0 = sin límite)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 0, 'min' => 0 ] );
		$this->add_control( 'sound', [ 'label' => __( 'Sonidos suaves al responder', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ] );
		$this->add_control( 'cert_url', [ 'label' => __( 'Página del certificado', 'wakoo' ), 'type' => Controls_Manager::URL, 'options' => false, 'description' => __( 'Página con el widget Certificado. Se añade ?curso= con la clave.', 'wakoo' ) ] );
		$this->add_control( 'pass_txt', [ 'label' => __( 'Mensaje extra al aprobar', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 2 ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_q', [ 'label' => __( 'Preguntas', 'wakoo' ) ] );
		$this->add_control( 'q_help', [
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => __( 'Respuestas: una por línea; marca las correctas con * al principio. Ordenar: escribe las líneas en el orden correcto (se mezclan solas). Emparejar: «frase = pareja» en cada línea. Escala: «mínimo | máximo».', 'wakoo' ),
			'content_classes' => 'elementor-descriptor',
		] );
		$r = new Repeater();
		$r->add_control( 'type', [
			'label'   => __( 'Tipo', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'one',
			'options' => [
				'one'     => __( 'Una respuesta', 'wakoo' ),
				'many'    => __( 'Varias respuestas', 'wakoo' ),
				'tf'      => __( 'Verdadero o falso', 'wakoo' ),
				'order'   => __( 'Ordenar', 'wakoo' ),
				'match'   => __( 'Emparejar', 'wakoo' ),
				'scale'   => __( 'Escala (no puntúa)', 'wakoo' ),
				'reflect' => __( 'Reflexión abierta (no puntúa)', 'wakoo' ),
			],
		] );
		$r->add_control( 'scene', [ 'label' => __( 'Escena (situación que se cuenta antes)', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 3 ] );
		$r->add_control( 'q', [ 'label' => __( 'Pregunta', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 2, 'default' => __( '¿Cuál es la idea principal?', 'wakoo' ) ] );
		$r->add_control( 'media_type', [
			'label'   => __( 'Multimedia', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => '',
			'options' => [ '' => __( 'Ninguno', 'wakoo' ), 'image' => __( 'Imagen', 'wakoo' ), 'video' => __( 'Vídeo', 'wakoo' ), 'audio' => __( 'Audio', 'wakoo' ) ],
		] );
		$r->add_control( 'media', [ 'label' => __( 'Archivo', 'wakoo' ), 'type' => Controls_Manager::MEDIA, 'media_types' => [ 'image', 'video', 'audio' ], 'condition' => [ 'media_type!' => '' ] ] );
		$r->add_control( 'media_url', [ 'label' => __( 'O enlace (mp4, mp3, YouTube)', 'wakoo' ), 'type' => Controls_Manager::URL, 'options' => false, 'condition' => [ 'media_type' => [ 'video', 'audio' ] ] ] );
		$r->add_control( 'opts', [ 'label' => __( 'Respuestas', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 5, 'default' => "*Respuesta correcta\nOtra respuesta\nOtra más", 'condition' => [ 'type!' => [ 'tf', 'reflect' ] ] ] );
		$r->add_control( 'tf', [ 'label' => __( 'La frase es', 'wakoo' ), 'type' => Controls_Manager::SELECT, 'default' => 'v', 'options' => [ 'v' => __( 'Verdadera', 'wakoo' ), 'f' => __( 'Falsa', 'wakoo' ) ], 'condition' => [ 'type' => 'tf' ] ] );
		$r->add_control( 'hint', [ 'label' => __( 'Pista', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$r->add_control( 'why', [ 'label' => __( 'Explicación (se ve tras responder)', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 2 ] );
		$this->add_control( 'questions', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'title_field' => '{{{ q }}}',
			'default'     => [
				[ 'type' => 'one', 'q' => __( '¿Cuál es la idea principal del curso?', 'wakoo' ), 'opts' => "*La respuesta correcta\nUna respuesta parecida\nOtra distinta" ],
				[ 'type' => 'tf', 'q' => __( 'Practicar un poco cada día ayuda más que mucho de golpe.', 'wakoo' ), 'tf' => 'v' ],
				[ 'type' => 'reflect', 'q' => __( '¿Qué te llevas de este curso?', 'wakoo' ) ],
			],
		] );
		$this->end_controls_section();
		$this->texts_section();
		$this->style_section( '.wk-ac-quiz__h' );
	}

	/** Media URL for a question (file or link). */
	private static function media( $q ) {
		$t = $q['media_type'] ?? '';
		if ( ! $t ) { return null; }
		$u = $q['media']['url'] ?? '';
		if ( 'image' !== $t && ! empty( $q['media_url']['url'] ) ) { $u = $q['media_url']['url']; }
		if ( ! $u ) { return null; }
		if ( 'video' === $t && preg_match( '~(?:youtu\.be/|youtube(?:-nocookie)?\.com/(?:watch\?v=|embed/|shorts/))([\w-]{11})~', $u, $m ) ) {
			return [ 'yt', 'https://www.youtube-nocookie.com/embed/' . $m[1] . '?rel=0' ];
		}
		return [ $t, esc_url_raw( $u ) ];
	}

	protected function render() {
		$s  = $this->get_settings_for_display();
		$qs = [];
		foreach ( (array) ( $s['questions'] ?? [] ) as $q ) {
			$type  = $q['type'] ?? 'one';
			$lines = array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) ( $q['opts'] ?? '' ) ) ), 'strlen' ) );
			$item  = [ 't' => $type, 'q' => (string) $q['q'], 'sc' => (string) ( $q['scene'] ?? '' ), 'h' => (string) ( $q['hint'] ?? '' ), 'w' => (string) ( $q['why'] ?? '' ), 'm' => self::media( $q ) ];
			if ( in_array( $type, [ 'one', 'many' ], true ) ) {
				$item['o'] = array_map( function ( $l ) { return [ ltrim( $l, '* ' ), '*' === $l[0] ]; }, $lines );
			} elseif ( 'tf' === $type ) {
				$item['a'] = 'f' !== ( $q['tf'] ?? 'v' );
			} elseif ( 'order' === $type ) {
				$item['o'] = $lines;
			} elseif ( 'match' === $type ) {
				$item['o'] = array_values( array_filter( array_map( function ( $l ) {
					$p = array_map( 'trim', explode( '=', $l, 2 ) );
					return 2 === count( $p ) ? $p : null;
				}, $lines ) ) );
			} elseif ( 'scale' === $type ) {
				$p         = array_map( 'trim', explode( '|', $lines[0] ?? '' ) );
				$item['o'] = [ $p[0] ?? '1', $p[1] ?? '10' ];
			}
			$qs[] = $item;
		}
		if ( ! $qs ) { return; }
		$c   = $this->course();
		$bg  = $s['bg']['url'] ?? '';
		$cfg = [
			'key'     => $c['key'] ?? 'p' . get_the_ID(),
			'title'   => $c['title'] ?? get_the_title(),
			'badge'   => $c['badge'] ?? '',
			'n'       => $c ? count( $c['lessons'] ) : 0,
			'pass'    => (int) ( $s['pass']['size'] ?? 70 ),
			'gate'    => 'yes' === $s['gate'],
			'full'    => 'yes' === $s['immersive'],
			'shuffle' => 'yes' === $s['shuffle'],
			'timer'   => max( 0, (int) $s['timer'] ),
			'sound'   => 'yes' === $s['sound'],
			'cert'    => $s['cert_url']['url'] ?? '',
			'passTxt' => (string) $s['pass_txt'],
			'qs'      => $qs,
		];
		$scored = count( array_filter( $qs, function ( $q ) { return ! in_array( $q['t'], [ 'scale', 'reflect' ], true ); } ) );
		echo '<section class="wk-ac wk-ac-quiz" data-wk-ac="quiz" data-words="' . esc_attr( $this->words_json( $s ) ) . '"' . ( $bg ? ' style="--wk-ac-bg:url(' . esc_url( $bg ) . ')"' : '' ) . '>';
		echo '<script type="application/json" class="wk-ac-cfg">' . wp_json_encode( $cfg, JSON_HEX_TAG | JSON_HEX_AMP ) . '</script>';
		echo '<div class="wk-ac-quiz__intro"><span class="wk-ac-quiz__icon">' . self::icon( 'star' ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<h2 class="wk-ac-quiz__h">' . esc_html( $s['title'] ) . '</h2>';
		if ( $s['intro'] ) { echo '<p>' . esc_html( $s['intro'] ) . '</p>'; }
		echo '<ul class="wk-ac-stats"><li>' . self::icon( 'list' ) . (int) count( $qs ) . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $scored ) { echo '<li>' . self::icon( 'check' ) . esc_html( $this->word( $s, 'need' ) . ' ' . $cfg['pass'] . '%' ) . '</li>'; } // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $cfg['timer'] ) { echo '<li>' . self::icon( 'clock' ) . esc_html( $cfg['timer'] . ' min' ) . '</li>'; } // phpcs:ignore WordPress.Security.EscapeOutput
		echo '</ul><p class="wk-ac-quiz__lock" hidden>' . self::icon( 'lock' ) . esc_html( $this->word( $s, 'locked' ) ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<p class="wk-ac-quiz__best" hidden></p>';
		echo '<button type="button" class="wk-ac-btn wk-ac-quiz__go">' . self::icon( 'play' ) . '<span>' . esc_html( $this->word( $s, 'start' ) ) . '</span></button>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( ! Module::learner() ) { echo '<p class="wk-ac-guest">' . esc_html( $this->word( $s, 'guest' ) ) . '</p>'; }
		echo '</div></section>';
	}
}
