<?php
/**
 * Shared base of the Academia widgets: category, assets, the "Textos" panel
 * (every visible word is a control, so each language page has its own) and
 * the common style panel.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Academia\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Wakoo\Modules\Academia\Module;

defined( 'ABSPATH' ) || die();

abstract class Base extends Widget_Base {

	public function get_categories() { return [ Module::CAT ]; }
	public function get_script_depends() { return [ 'wakoo-academia' ]; }
	public function get_style_depends() { return [ 'wakoo-academia' ]; }

	/** [ control => default ] of the words this widget shows. */
	protected function words() { return []; }

	protected function texts_section() {
		$w = $this->words();
		if ( ! $w ) { return; }
		$this->start_controls_section( 'sec_texts', [ 'label' => __( 'Textos', 'wakoo' ) ] );
		foreach ( $w as $k => $d ) {
			$this->add_control( 't_' . $k, [ 'label' => $d[1] ?? $d[0], 'type' => Controls_Manager::TEXT, 'default' => $d[0], 'label_block' => true ] );
		}
		$this->end_controls_section();
	}

	/** Words as JSON for the script, with the defaults when a control is empty. */
	protected function words_json( $s ) {
		$out = [];
		foreach ( $this->words() as $k => $d ) {
			$v         = (string) ( $s[ 't_' . $k ] ?? '' );
			$out[ $k ] = '' !== $v ? $v : $d[0];
		}
		return wp_json_encode( $out );
	}

	protected function word( $s, $k ) {
		$v = (string) ( $s[ 't_' . $k ] ?? '' );
		return '' !== $v ? $v : ( $this->words()[ $k ][0] ?? '' );
	}

	protected function style_section( $title_sel = '.wk-ac-title' ) {
		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'accent', [
			'label'     => __( 'Color principal', 'wakoo' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .wk-ac' => '--wk-ac: {{VALUE}};' ],
		] );
		$this->add_control( 'ink', [
			'label'     => __( 'Color del texto', 'wakoo' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .wk-ac' => '--wk-ac-ink: {{VALUE}};' ],
		] );
		$this->add_control( 'card', [
			'label'     => __( 'Fondo de las tarjetas', 'wakoo' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .wk-ac' => '--wk-ac-card: {{VALUE}};' ],
		] );
		$this->add_responsive_control( 'radius', [
			'label'      => __( 'Redondeo', 'wakoo' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'range'      => [ 'px' => [ 'min' => 0, 'max' => 40 ] ],
			'selectors'  => [ '{{WRAPPER}} .wk-ac' => '--wk-ac-r: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name'     => 'title_typo',
			'label'    => __( 'Tipografía de los títulos', 'wakoo' ),
			'selector' => '{{WRAPPER}} ' . $title_sel,
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name'     => 'body_typo',
			'label'    => __( 'Tipografía del texto', 'wakoo' ),
			'selector' => '{{WRAPPER}} .wk-ac',
		] );
		$this->end_controls_section();
	}

	/** Summary of the course this page is (or of the page chosen in the widget). */
	protected function course( $post_id = 0 ) {
		$post_id = $post_id ?: get_the_ID();
		if ( ! $post_id ) { return null; }
		$c = Module::course( $post_id );
		if ( $c ) {
			$c['id']   = $post_id;
			$c['mins'] = (int) round( array_sum( array_map( [ Module::class, 'minutes' ], wp_list_pluck( $c['lessons'], 1 ) ) ) );
		}
		return $c;
	}

	protected static function icon( $name ) {
		$p = [
			'play'  => '<path d="M8 5v14l11-7z"/>',
			'check' => '<path d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/>',
			'clock' => '<path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 10.4 3.5 2.1-.8 1.3L11 13V7h2z"/>',
			'list'  => '<path d="M3 5h2v2H3zm4 0h14v2H7zM3 11h2v2H3zm4 0h14v2H7zm-4 6h2v2H3zm4 0h14v2H7z"/>',
			'star'  => '<path d="m12 17.3 6.2 3.7-1.6-7 5.4-4.7-7.1-.6L12 2 9.1 8.7 2 9.3l5.4 4.7-1.6 7z"/>',
			'lock'  => '<path d="M17 9h-1V7a4 4 0 0 0-8 0v2H7a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-9a2 2 0 0 0-2-2zm-7-2a2 2 0 0 1 4 0v2h-4z"/>',
			'user'  => '<path d="M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm0 2c-4.4 0-8 2.2-8 5v3h16v-3c0-2.8-3.6-5-8-5z"/>',
			'cert'  => '<path d="M4 3h16v12H4zm2 2v8h12V5zm2 2h8v1.5H8zm0 3h5v1.5H8zM9 16l3 1.5 3-1.5v6l-3-1.5L9 22z"/>',
			'level' => '<path d="M4 20h3v-6H4zm6.5 0h3V9h-3zM17 20h3V4h-3z"/>',
		];
		return '<svg class="wk-ac-i" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . ( $p[ $name ] ?? '' ) . '</svg>';
	}

	/** "1 h 25 min" / "35 min". */
	protected static function hm( $mins ) {
		$mins = (int) round( $mins );
		return $mins >= 60 ? sprintf( '%d h %02d min', intdiv( $mins, 60 ), $mins % 60 ) : $mins . ' min';
	}
}
