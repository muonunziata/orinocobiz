<?php
/**
 * Temario: the course syllabus (lessons with their length, ticks for the ones
 * seen and the final evaluation), read from the Aula of the same page.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Academia\Widgets;

use Elementor\Controls_Manager;

defined( 'ABSPATH' ) || die();

class Temario extends Base {

	public function get_name() { return 'wakoo-ac-temario'; }
	public function get_title() { return __( 'Temario del curso', 'wakoo' ); }
	public function get_icon() { return 'eicon-bullet-list'; }
	public function get_keywords() { return [ 'temario', 'programa', 'lecciones', 'syllabus', 'curso', 'academia', 'wakoo' ]; }

	protected function words() {
		return [
			'title'   => [ __( 'Qué vas a aprender', 'wakoo' ), __( 'Título', 'wakoo' ) ],
			'lessons' => [ __( 'lecciones', 'wakoo' ) ],
			'quiz'    => [ __( 'Evaluación final interactiva', 'wakoo' ), __( 'Última línea', 'wakoo' ) ],
			'video'   => [ __( 'vídeo', 'wakoo' ), __( 'Etiqueta de lección con vídeo', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_t', [ 'label' => __( 'Temario', 'wakoo' ) ] );
		$this->add_control( 'help', [
			'type'            => Controls_Manager::RAW_HTML,
			'raw'             => __( 'Lee las lecciones del widget Aula de esta página (se actualiza al guardar).', 'wakoo' ),
			'content_classes' => 'elementor-descriptor',
		] );
		$this->add_control( 'anchor', [ 'label' => __( 'Ancla del Aula', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '#aula' ] );
		$this->add_control( 'quiz_anchor', [ 'label' => __( 'Ancla de la evaluación', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '#evaluacion' ] );
		$this->end_controls_section();
		$this->texts_section();
		$this->style_section( '.wk-ac-syl__h' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$c = $this->course();
		if ( ! $c || ! $c['lessons'] ) {
			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				echo '<p class="wk-ac-empty">' . esc_html__( 'Añade la Cabecera del curso y el Aula, y guarda la página.', 'wakoo' ) . '</p>';
			}
			return;
		}
		echo '<div class="wk-ac wk-ac-syl" data-wk-ac="syllabus" data-cfg="' . esc_attr( wp_json_encode( [ 'key' => $c['key'], 'anchor' => $s['anchor'] ?: '#aula' ] ) ) . '">';
		echo '<div class="wk-ac-syl__top"><h2 class="wk-ac-syl__h">' . esc_html( $this->word( $s, 'title' ) ) . '</h2><span>' . esc_html( count( $c['lessons'] ) . ' ' . $this->word( $s, 'lessons' ) . ' · ' . self::hm( $c['mins'] ) ) . '</span></div><ol class="wk-ac-syl__list">';
		foreach ( $c['lessons'] as $i => $l ) {
			echo '<li data-i="' . (int) $i . '"><a href="' . esc_attr( '#leccion-' . ( $i + 1 ) ) . '" data-go="' . (int) $i . '"><span class="wk-ac-syl__n">' . (int) ( $i + 1 ) . '</span><span class="wk-ac-syl__t">' . esc_html( $l[0] ) . '</span>';
			if ( ! empty( $l[2] ) ) { echo '<span class="wk-ac-chip is-small">' . esc_html( $this->word( $s, 'video' ) ) . '</span>'; }
			echo '<span class="wk-ac-syl__d">' . esc_html( $l[1] ) . '</span></a></li>';
		}
		if ( $c['quiz'] ) {
			echo '<li class="is-quiz"><a href="' . esc_attr( $s['quiz_anchor'] ?: '#evaluacion' ) . '"><span class="wk-ac-syl__n">' . self::icon( 'star' ) . '</span><span class="wk-ac-syl__t">' . esc_html( $this->word( $s, 'quiz' ) ) . '</span></a></li>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</ol></div>';
	}
}
