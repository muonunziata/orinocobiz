<?php
/**
 * Mi aprendizaje: the person's dashboard (courses in progress, completed with
 * their certificate, and suggestions), built in the browser from the course
 * list of this language and the saved progress.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Academia\Widgets;

use Elementor\Controls_Manager;
use Wakoo\Modules\Academia\Module;

defined( 'ABSPATH' ) || die();

class Progreso extends Base {

	public function get_name() { return 'wakoo-ac-progreso'; }
	public function get_title() { return __( 'Mi aprendizaje', 'wakoo' ); }
	public function get_icon() { return 'eicon-dashboard'; }
	public function get_keywords() { return [ 'progreso', 'mis cursos', 'aprendizaje', 'dashboard', 'academia', 'wakoo' ]; }

	protected function words() {
		return [
			'hello'   => [ __( 'Tu aprendizaje', 'wakoo' ), __( 'Título', 'wakoo' ) ],
			'started' => [ __( 'cursos empezados', 'wakoo' ) ],
			'seen'    => [ __( 'lecciones vistas', 'wakoo' ) ],
			'certs'   => [ __( 'certificados', 'wakoo' ) ],
			'going'   => [ __( 'Sigue donde lo dejaste', 'wakoo' ) ],
			'done'    => [ __( 'Completados', 'wakoo' ) ],
			'next'    => [ __( 'Para empezar', 'wakoo' ) ],
			'cont'    => [ __( 'Continuar', 'wakoo' ) ],
			'see'     => [ __( 'Ver curso', 'wakoo' ) ],
			'cert'    => [ __( 'Certificado', 'wakoo' ) ],
			'empty'   => [ __( 'Todavía no has empezado ningún curso. Elige uno y empieza por la primera lección.', 'wakoo' ), __( 'Sin progreso', 'wakoo' ) ],
			'guest'   => [ __( 'Este progreso está guardado en este dispositivo. Inicia sesión para guardarlo en tu cuenta.', 'wakoo' ), __( 'Aviso sin sesión', 'wakoo' ) ],
		];
	}

	protected function register_controls() {
		$this->start_controls_section( 'sec_p', [ 'label' => __( 'Mi aprendizaje', 'wakoo' ) ] );
		$this->add_control( 'cert_url', [ 'label' => __( 'Página del certificado', 'wakoo' ), 'type' => Controls_Manager::URL, 'options' => false ] );
		$this->add_control( 'suggest', [ 'label' => __( 'Cursos sugeridos', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 3, 'min' => 0, 'max' => 12 ] );
		$this->end_controls_section();
		$this->texts_section();
		$this->style_section( '.wk-ac-dash__h' );
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$list = array_map( function ( $c ) {
			return [ 'key' => $c['key'], 'title' => $c['title'], 'url' => $c['url'], 'img' => $c['img'], 'cat' => $c['cat'], 'n' => count( $c['lessons'] ), 'mins' => $c['mins'], 'badge' => $c['badge'] ];
		}, Module::courses( Module::lang() ) );
		$cfg = [ 'courses' => $list, 'cert' => $s['cert_url']['url'] ?? '', 'suggest' => (int) $s['suggest'] ];
		echo '<div class="wk-ac wk-ac-dash" data-wk-ac="dashboard" data-words="' . esc_attr( $this->words_json( $s ) ) . '">';
		echo '<script type="application/json" class="wk-ac-cfg">' . wp_json_encode( $cfg, JSON_HEX_TAG | JSON_HEX_AMP ) . '</script>';
		echo '<h2 class="wk-ac-dash__h">' . esc_html( $this->word( $s, 'hello' ) ) . '</h2><div class="wk-ac-dash__body"></div>';
		if ( ! Module::learner() ) { echo '<p class="wk-ac-guest">' . esc_html( $this->word( $s, 'guest' ) ) . '</p>'; }
		echo '</div>';
	}
}
