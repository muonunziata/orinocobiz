<?php
/**
 * Wakoo Academia: online courses built with Elementor (catalog, course header,
 * syllabus, lesson room, immersive evaluation, learner dashboard, certificate).
 *
 * - A course is an ordinary page (so languages, packs and folders work as for
 *   any page). It becomes a course when it holds the "Cabecera del curso"
 *   widget; on save the module writes a summary in `_wk_ac` (key, category,
 *   level, image, lessons, evaluation) that the catalog and the dashboard read.
 * - Progress lives in the browser (localStorage) for everyone and, for
 *   logged-in people, also in user meta `_wk_academia`, keyed by the course
 *   key, so it is shared by every language of the course.
 * - Passing the evaluation fires `wakoo_academia_aprobado` and, with every
 *   lesson done, `wakoo_academia_completado` (a site plugin can award a badge).
 * - Ideas taken (not code) from GPL LMS plugins: Sensei LMS (learning mode,
 *   preview), Tutor LMS and LifterLMS (question types, dashboard), H5P
 *   (interactive questions). All code here is Wakoo's own.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Academia;

defined( 'ABSPATH' ) || die();

class Module {

	const META     = '_wk_ac';
	const USERMETA = '_wk_academia';
	const CERT     = '_wk_ac_cert_';
	const NONCE    = 'wakoo_academia';
	const CAT      = 'wakoo-academia';
	const WIDGETS  = [ 'catalogo', 'cabecera', 'temario', 'aula', 'evaluacion', 'progreso', 'certificado' ];

	public static function init() {
		add_action( 'elementor/elements/categories_registered', [ __CLASS__, 'category' ] );
		add_action( 'elementor/widgets/register', [ __CLASS__, 'register_widgets' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ __CLASS__, 'scripts' ] );
		add_action( 'elementor/frontend/after_register_styles', [ __CLASS__, 'styles' ] );
		add_action( 'elementor/editor/after_enqueue_styles', [ __CLASS__, 'styles' ] );
		add_action( 'wp_ajax_wakoo_academia', [ __CLASS__, 'ajax' ] );
		add_action( 'wp_ajax_nopriv_wakoo_academia', [ __CLASS__, 'ajax' ] );
		// Rebuild the course summary whenever the Elementor data changes (editor save or pack import).
		add_action( 'updated_post_meta', [ __CLASS__, 'meta_changed' ], 10, 4 );
		add_action( 'added_post_meta', [ __CLASS__, 'meta_changed' ], 10, 4 );
	}

	public static function category( $mgr ) {
		$mgr->add_category( self::CAT, [ 'title' => __( 'Wakoo · Academia', 'wakoo' ), 'icon' => 'eicon-library-open' ] );
	}

	public static function register_widgets( $wm ) {
		require_once __DIR__ . '/widgets/base.php';
		foreach ( self::WIDGETS as $w ) {
			require_once __DIR__ . '/widgets/' . $w . '.php';
			$cls = __NAMESPACE__ . '\\Widgets\\' . ucfirst( $w );
			$wm->register( new $cls() );
		}
	}

	public static function scripts() {
		wp_register_script( 'wakoo-academia', WAKOO_MODULES_URL . 'academia/assets/academia.js', [], WAKOO_VERSION, true );
		wp_localize_script( 'wakoo-academia', 'WakooAcademia', [
			'ajax'  => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( self::NONCE ),
			'user'  => self::learner() ? 1 : 0,
			'data'  => self::learner() ? self::load( self::learner() ) : new \stdClass(),
		] );
	}

	public static function styles() {
		wp_register_style( 'wakoo-academia', WAKOO_MODULES_URL . 'academia/assets/academia.css', [], WAKOO_VERSION );
		if ( did_action( 'elementor/editor/after_enqueue_styles' ) ) { wp_enqueue_style( 'wakoo-academia' ); }
	}

	/* ---------- Course summary ---------- */

	public static function meta_changed( $mid, $post_id, $key, $value ) {
		if ( '_elementor_data' === $key ) { self::sync( $post_id ); }
	}

	/** Find the first element of a widget type in Elementor data. */
	private static function find( $els, $type ) {
		foreach ( (array) $els as $el ) {
			if ( ( $el['widgetType'] ?? '' ) === $type ) { return $el; }
			if ( ! empty( $el['elements'] ) ) {
				$f = self::find( $el['elements'], $type );
				if ( $f ) { return $f; }
			}
		}
		return null;
	}

	/** Minutes from "3:10", "3" or "3 min". */
	public static function minutes( $d ) {
		$d = trim( (string) $d );
		if ( preg_match( '/^(\d+):(\d{1,2})$/', $d, $m ) ) { return (int) $m[1] + (int) $m[2] / 60; }
		return (float) preg_replace( '/[^\d.]/', '', $d );
	}

	/** Write `_wk_ac` from the page's widgets; remove it when the page is no longer a course. */
	public static function sync( $post_id ) {
		$raw  = get_post_meta( $post_id, '_elementor_data', true );
		$data = is_array( $raw ) ? $raw : json_decode( (string) $raw, true );
		$head = self::find( $data, 'wakoo-ac-cabecera' );
		if ( ! $head ) {
			delete_post_meta( $post_id, self::META );
			return null;
		}
		$h    = $head['settings'] ?? [];
		$room = self::find( $data, 'wakoo-ac-aula' );
		$quiz = self::find( $data, 'wakoo-ac-evaluacion' );
		$less = [];
		foreach ( (array) ( $room['settings']['lessons'] ?? [] ) as $l ) {
			$less[] = [ (string) ( $l['title'] ?? '' ), (string) ( $l['dur'] ?? '' ), ! empty( $l['video']['url'] ) || ! empty( $l['file']['url'] ) ];
		}
		$sum = [
			'key'      => sanitize_key( $h['clave'] ?? '' ) ?: 'p' . $post_id,
			'cat'      => (string) ( $h['cat'] ?? '' ),
			'level'    => (string) ( $h['nivel'] ?? '' ),
			'author'   => (string) ( $h['autora'] ?? '' ),
			'tagline'  => (string) ( $h['lema'] ?? '' ),
			'badge'    => (string) ( $h['insignia'] ?? '' ),
			'img'      => (string) ( $h['img']['url'] ?? '' ),
			'title'    => (string) ( $h['titulo'] ?? '' ) ?: get_the_title( $post_id ),
			'order'    => (int) ( $h['orden'] ?? 0 ),
			'lessons'  => $less,
			'quiz'     => $quiz ? count( (array) ( $quiz['settings']['questions'] ?? [] ) ) : 0,
			'pass'     => $quiz ? (int) ( $quiz['settings']['pass']['size'] ?? $quiz['settings']['pass'] ?? 70 ) : 0,
			'room'     => $room ? (string) ( $room['id'] ?? '' ) : '',
		];
		update_post_meta( $post_id, self::META, $sum );
		return $sum;
	}

	/** Summary of a course page (built on the fly the first time). */
	public static function course( $post_id ) {
		$s = get_post_meta( $post_id, self::META, true );
		return is_array( $s ) ? $s : self::sync( $post_id );
	}

	/** Every published course in a language (or all when the site is not multilingual). */
	public static function courses( $lang = '' ) {
		$args = [
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'posts_per_page' => 300,
			'meta_key'       => self::META, // phpcs:ignore WordPress.DB.SlowDBQuery
			'orderby'        => 'menu_order title',
			'order'          => 'ASC',
			'no_found_rows'  => true,
		];
		$out = [];
		foreach ( get_posts( $args ) as $p ) {
			if ( $lang ) {
				$pl = get_post_meta( $p->ID, '_wakoo_lang', true );
				if ( $pl && $pl !== $lang ) { continue; }
			}
			$c = self::course( $p->ID );
			if ( ! $c ) { continue; }
			$c['id']   = $p->ID;
			$c['url']  = get_permalink( $p );
			$c['mins'] = (int) round( array_sum( array_map( function ( $l ) { return self::minutes( $l[1] ); }, $c['lessons'] ) ) );
			$out[]     = $c;
		}
		usort( $out, function ( $a, $b ) { return $a['order'] <=> $b['order'] ?: strcmp( $a['title'], $b['title'] ); } );
		return $out;
	}

	/** Language of the page being shown. */
	public static function lang() {
		$id = get_queried_object_id();
		if ( ! $id && isset( $_GET['post'] ) ) { $id = absint( $_GET['post'] ); } // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! $id && isset( $_GET['editor_post_id'] ) ) { $id = absint( $_GET['editor_post_id'] ); } // phpcs:ignore WordPress.Security.NonceVerification
		return $id ? (string) get_post_meta( $id, '_wakoo_lang', true ) : '';
	}

	/* ---------- Progress ---------- */

	/**
	 * Who is learning: the WordPress user, or a person signed in with another login system of the site
	 * (filter wakoo_academia_learner returns [ 'id' => stable id, 'name' => name ]). Null for visitors.
	 */
	public static function learner() {
		static $l = false;
		if ( false !== $l ) { return $l; }
		$l = null;
		if ( is_user_logged_in() ) {
			$u = wp_get_current_user();
			$l = [ 'id' => (string) $u->ID, 'uid' => (int) $u->ID, 'name' => $u->display_name ];
		} else {
			$x = apply_filters( 'wakoo_academia_learner', null );
			if ( is_array( $x ) && ! empty( $x['id'] ) ) {
				$l = [ 'id' => 'x' . sanitize_key( $x['id'] ), 'uid' => 0, 'name' => sanitize_text_field( (string) ( $x['name'] ?? '' ) ) ];
			}
		}
		return $l;
	}

	/** Saved progress of a learner: user meta for WordPress users, a non-autoloaded option for the others. */
	public static function load( $l ) {
		$p = $l['uid'] ? get_user_meta( $l['uid'], self::USERMETA, true ) : get_option( 'wk_ac_p_' . $l['id'] );
		return is_array( $p ) && $p ? $p : new \stdClass();
	}

	private static function save( $l, $all ) {
		if ( $l['uid'] ) {
			update_user_meta( $l['uid'], self::USERMETA, $all );
		} else {
			update_option( 'wk_ac_p_' . $l['id'], $all, false );
		}
	}

	public static function progress( $uid ) {
		return self::load( [ 'id' => (string) $uid, 'uid' => (int) $uid ] );
	}

	/** Certificate code: short, stable per person and course. */
	public static function cert_code( $id, $key ) {
		return strtoupper( substr( hash_hmac( 'sha256', $id . '|' . $key, wp_salt( 'auth' ) ), 0, 10 ) );
	}

	/** Find who holds a certificate code. Returns [ name, key, record ] or null. */
	public static function verify( $code ) {
		$code = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $code ) );
		if ( strlen( $code ) !== 10 ) { return null; }
		$users = get_users( [ 'meta_key' => self::CERT . $code, 'number' => 1 ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
		if ( $users ) {
			$l   = [ 'id' => (string) $users[0]->ID, 'uid' => (int) $users[0]->ID, 'name' => $users[0]->display_name ];
			$key = get_user_meta( $users[0]->ID, self::CERT . $code, true );
		} else {
			$c = get_option( 'wk_ac_c_' . $code );
			if ( ! is_array( $c ) ) { return null; }
			$l   = [ 'id' => $c['id'], 'uid' => 0, 'name' => $c['name'] ];
			$key = $c['key'];
		}
		$all = self::load( $l );
		$rec = is_array( $all ) ? ( $all[ $key ] ?? null ) : null;
		return $rec ? [ $l['name'], $key, $rec ] : null;
	}

	/** AJAX: save a lesson as done, an evaluation result, or merge the browser's progress after logging in. */
	public static function ajax() {
		check_ajax_referer( self::NONCE, 'nonce' );
		$who = self::learner();
		if ( ! $who ) { wp_send_json_success( [ 'saved' => false ] ); }
		$uid = $who['uid'];
		$all = self::load( $who );
		$all = is_array( $all ) ? $all : [];
		$do  = sanitize_key( $_POST['do'] ?? '' );
		$in  = [];
		if ( 'merge' === $do ) {
			$in = json_decode( wp_unslash( $_POST['data'] ?? '{}' ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$in = is_array( $in ) ? array_slice( $in, 0, 300, true ) : [];
		} else {
			$key = sanitize_key( $_POST['key'] ?? '' );
			if ( ! $key ) { wp_send_json_error(); }
			$in[ $key ] = [];
			if ( 'lesson' === $do ) { $in[ $key ]['l'] = [ absint( $_POST['i'] ?? 0 ) ]; }
			if ( 'quiz' === $do ) {
				$in[ $key ]['s']  = min( 100, absint( $_POST['score'] ?? 0 ) );
				$in[ $key ]['ok'] = ! empty( $_POST['pass'] ) ? time() : 0;
			}
			$in[ $key ]['n'] = absint( $_POST['n'] ?? 0 );
			$in[ $key ]['t'] = sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) );
		}
		$valid = array_flip( wp_list_pluck( self::courses(), 'key' ) ); // Only keys of published courses.
		foreach ( $in as $key => $rec ) {
			$key = sanitize_key( $key );
			if ( ! $key || ! is_array( $rec ) || ! isset( $valid[ $key ] ) ) { continue; }
			$old  = $all[ $key ] ?? [ 'l' => [], 's' => 0, 'ok' => 0 ];
			$was  = ! empty( $old['ok'] );
			$less = array_values( array_unique( array_map( 'absint', array_merge( (array) ( $old['l'] ?? [] ), (array) ( $rec['l'] ?? [] ) ) ) ) );
			sort( $less );
			$all[ $key ] = [
				'l'  => array_slice( $less, 0, 100 ),
				's'  => max( (int) ( $old['s'] ?? 0 ), min( 100, (int) ( $rec['s'] ?? 0 ) ) ),
				'ok' => ! empty( $old['ok'] ) ? (int) $old['ok'] : (int) ( $rec['ok'] ?? 0 ),
				'n'  => max( (int) ( $old['n'] ?? 0 ), min( 100, (int) ( $rec['n'] ?? 0 ) ) ),
				't'  => sanitize_text_field( (string) ( $rec['t'] ?? '' ) ) ?: ( $old['t'] ?? '' ),
				'u'  => time(),
			];
			if ( ! empty( $old['c'] ) ) { $all[ $key ]['c'] = $old['c']; } // Keep the certificate code on later saves.
			if ( ! $was && $all[ $key ]['ok'] ) {
				$code = self::cert_code( $who['id'], $key );
				$all[ $key ]['c'] = $code;
				if ( $uid ) {
					update_user_meta( $uid, self::CERT . $code, $key );
				} else {
					update_option( 'wk_ac_c_' . $code, [ 'id' => $who['id'], 'name' => $who['name'], 'key' => $key ], false );
				}
				/**
				 * The person passed a course evaluation.
				 *
				 * @param int    $uid   WordPress user id (0 for a person of another login system).
				 * @param string $key   Course key (Cabecera del curso → Clave).
				 * @param array  $rec   Progress record: l (lessons done), s (best score), ok (time passed), c (certificate code).
				 * @param array  $who   The learner: id, uid, name (see learner()).
				 */
				do_action( 'wakoo_academia_aprobado', $uid, $key, $all[ $key ], $who );
			}
			$done = $all[ $key ]['n'] && count( $all[ $key ]['l'] ) >= $all[ $key ]['n'];
			if ( $done && $all[ $key ]['ok'] && empty( $old['done'] ) ) {
				$all[ $key ]['done'] = time();
				do_action( 'wakoo_academia_completado', $uid, $key, $all[ $key ], $who );
			} elseif ( ! empty( $old['done'] ) ) {
				$all[ $key ]['done'] = $old['done'];
			}
		}
		self::save( $who, $all );
		wp_send_json_success( [ 'saved' => true, 'data' => $all ] );
	}
}

Module::init();
