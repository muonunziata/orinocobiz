/* Wakoo · Globo 3D (COBE). One loop per globe; pauses off screen; drag to turn. */
(function () {
	'use strict';
	var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	function angles(lat, lng) {
		return [Math.PI - ((lng * Math.PI) / 180 - Math.PI / 2), (lat * Math.PI) / 180];
	}

	function boot(root) {
		if (!root || root.dataset.wakooInit || !window.WakooCobe) { return; }
		root.dataset.wakooInit = '1';
		var cfg = {};
		try { cfg = JSON.parse(root.getAttribute('data-wakoo-globe') || '{}'); } catch (e) { return; }
		var canvas = root.querySelector('canvas');
		var dpr = Math.min(window.devicePixelRatio || 1, 2);
		var size = Math.max(160, canvas.offsetWidth || 400);
		var a = angles(cfg.lat || 0, cfg.lng || 0);
		var phi0 = a[0], thetaRest = Math.max(-0.6, Math.min(0.6, a[1] * 0.8)), thetaFocus = Math.max(-0.6, Math.min(0.6, a[1])), drag = 0, start = null, moved = 0, t = 0, visible = true, raf = 0, hover = false, cur = a[0], curTheta = thetaRest;
		var markers = (cfg.markers || []).map(function (m) {
			return { location: m.location, size: m.size, color: m.main ? cfg.accent : undefined };
		});
		var globe;
		try {
			globe = window.WakooCobe(canvas, {
				devicePixelRatio: dpr, width: size * dpr, height: size * dpr, phi: phi0, theta: thetaRest,
				dark: cfg.dark ? 1 : 0, diffuse: 1.2, mapSamples: 16000, mapBrightness: cfg.dark ? 5 : 8,
				baseColor: cfg.base, markerColor: cfg.mark, glowColor: cfg.glow, arcColor: cfg.accent,
				arcWidth: 0.6, arcHeight: 0.25, markers: markers, arcs: cfg.arcs || [], opacity: 0.95
			});
		} catch (e) { root.classList.add('is-nogl'); return; }
		root.classList.add('is-ready');
		var zoom = cfg.zoom || null, zk = 0, zTarget = 0, zTheta = a[1];
		function ease(x) { return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; }
		function frame() {
			raf = 0;
			if (!visible) { return; }
			if (!reduce && cfg.spin > 0 && start === null && !hover && zTarget === 0 && zk === 0) { t += 0.002 * cfg.spin; }
			if (zoom && zk !== zTarget) {
				zk = reduce ? zTarget : (zTarget > zk ? Math.min(zTarget, zk + 0.022) : Math.max(zTarget, zk - 0.03));
			}
			var e = ease(zk);
			var swing = (cfg.swing || 0) * Math.PI / 180;
			var wantPhi = phi0 + drag + (swing ? Math.sin(t) * swing / 2 : 0), wantTheta = thetaRest;
			// Without zoom, hovering flies the camera to the main marker.
			if (hover && start === null) { wantPhi = phi0; wantTheta = thetaFocus; }
			var glide = reduce ? 1 : 0.16;
			cur += (wantPhi - cur) * glide;
			curTheta += (wantTheta - curTheta) * glide;
			// Turn the shortest way back to the focus point while zooming in.
			var d = Math.atan2(Math.sin(phi0 - cur), Math.cos(phi0 - cur));
			var upd = { phi: cur + d * e, theta: curTheta + (zTheta - curTheta) * e };
			if (zoom) { upd.scale = 1 + (zoom.scale - 1) * e; }
			globe.update(upd);
			if (zoom) { root.style.setProperty('--wk-zoom', e.toFixed(3)); }
			var moving = (zoom && zk !== zTarget) || Math.abs(wantPhi - cur) > 0.001 || Math.abs(wantTheta - curTheta) > 0.001;
			if (!reduce || start !== null || hover || moving) { raf = requestAnimationFrame(frame); }
		}
		frame();
		var io = 'IntersectionObserver' in window ? new IntersectionObserver(function (es) {
			visible = es[0].isIntersecting;
			if (visible && !raf) { raf = requestAnimationFrame(frame); }
		}) : null;
		if (io) { io.observe(root); }
		canvas.addEventListener('pointerdown', function (e) { if (zTarget) { return; } start = [e.clientX, drag]; moved = 0; canvas.setPointerCapture(e.pointerId); canvas.style.cursor = 'grabbing'; if (!raf) { raf = requestAnimationFrame(frame); } });
		canvas.addEventListener('pointermove', function (e) { if (start) { moved = Math.max(moved, Math.abs(e.clientX - start[0])); drag = start[1] + (e.clientX - start[0]) / 160; } });
		var end = function () { start = null; canvas.style.cursor = ''; };
		canvas.addEventListener('pointerup', function () { if (!zoom && start && moved < 6) { var href = root.getAttribute('data-wakoo-href'); if (href) { window.location.href = href; return; } } end(); });
		canvas.addEventListener('pointercancel', end);
		if (zoom) {
			var stage = root.querySelector('.wk-globe__stage'), mapBox = root.querySelector('.wk-globe__map');
			if (zoom.geo && zoom.geo.length && mapBox) { drawMap(mapBox, zoom.geo, cfg); }
			var set = function (on) {
				zTarget = on ? 1 : 0;
				root.classList.toggle('is-zoomed', !!on);
				if (stage) { stage.setAttribute('aria-pressed', on ? 'true' : 'false'); }
				if (on) { drag = 0; }
				if (!raf) { raf = requestAnimationFrame(frame); }
			};
			var touch = false;
			stage.addEventListener('pointerenter', function (e) { if (e.pointerType === 'mouse') { set(true); } });
			stage.addEventListener('pointerleave', function (e) { if (e.pointerType === 'mouse') { set(false); } });
			stage.addEventListener('pointerdown', function (e) { touch = e.pointerType !== 'mouse'; });
			stage.addEventListener('click', function () {
				if (touch) { set(zTarget === 0); return; }
				var href = root.getAttribute('data-wakoo-href');
				if (href) { window.location.href = href; }
			});
			stage.addEventListener('keydown', function (e) {
				if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); set(zTarget === 0); }
				if (e.key === 'Escape') { set(false); }
			});
		} else {
			canvas.addEventListener('pointerenter', function (e) { if (e.pointerType === 'mouse') { hover = true; drag = 0; if (!raf) { raf = requestAnimationFrame(frame); } } });
			canvas.addEventListener('pointerleave', function () { hover = false; });
		}
		window.addEventListener('resize', function () {
			var s = Math.max(160, canvas.offsetWidth || size);
			if (Math.abs(s - size) > 4) { size = s; globe.update({ width: s * dpr, height: s * dpr }); if (!raf) { raf = requestAnimationFrame(frame); } }
		});
	}

	// Detail map: plain SVG from GeoJSON (equirectangular, cos(lat) corrected), drawn in the globe's circle.
	var NS = 'http://www.w3.org/2000/svg';
	function rgb(c) { return 'rgb(' + c.map(function (v) { return Math.round(v * 255); }).join(',') + ')'; }
	function drawMap(box, feats, cfg) {
		var pts = [];
		function walk(c) { if (typeof c[0] === 'number') { pts.push(c); } else { c.forEach(walk); } }
		// Frame the features marked «fit» (all of them if none is marked); the rest may run past the lens.
		var fit = feats.filter(function (f) { return f.fit; });
		(fit.length ? fit : feats).forEach(function (f) { walk(f.g.coordinates); });
		if (!pts.length) { return; }
		var x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
		pts.forEach(function (p) { x0 = Math.min(x0, p[0]); x1 = Math.max(x1, p[0]); y0 = Math.min(y0, p[1]); y1 = Math.max(y1, p[1]); });
		var k = Math.cos(((y0 + y1) / 2) * Math.PI / 180), w = (x1 - x0) * k || 1, h = (y1 - y0) || 1;
		var S = 1000, inner = fit.length ? 700 : 640, sc = inner / Math.max(w, h), ox = (S - w * sc) / 2, oy = (S - h * sc) / 2;
		function P(p) { return [(ox + (p[0] - x0) * k * sc).toFixed(1), (oy + (y1 - p[1]) * sc).toFixed(1)]; }
		function ring(r, close) { return r.map(function (p, i) { var q = P(p); return (i ? 'L' : 'M') + q[0] + ' ' + q[1]; }).join('') + (close ? 'Z' : ''); }
		var svg = document.createElementNS(NS, 'svg');
		svg.setAttribute('viewBox', '0 0 ' + S + ' ' + S);
		svg.setAttribute('focusable', 'false');
		var accent = rgb(cfg.accent || [0.77, 0.63, 0.36]), i = 0, labels = [];
		feats.forEach(function (f) {
			var g = f.g, d = '';
			if (g.type === 'Polygon') { d = g.coordinates.map(function (r) { return ring(r, true); }).join(''); }
			else if (g.type === 'MultiPolygon') { d = g.coordinates.map(function (pl) { return pl.map(function (r) { return ring(r, true); }).join(''); }).join(''); }
			else if (g.type === 'LineString') { d = ring(g.coordinates, false); }
			else if (g.type === 'MultiLineString') { d = g.coordinates.map(function (r) { return ring(r, false); }).join(''); }
			if (!d) { return; }
			var path = document.createElementNS(NS, 'path');
			var line = /LineString/.test(g.type), outline = f.role === 'outline';
			path.setAttribute('d', d);
			path.setAttribute('pathLength', '1');
			path.setAttribute('class', 'wk-globe__shape' + (line ? ' is-line' : '') + (outline ? ' is-outline' : '') + (f.role === 'river' ? ' is-river' : ''));
			path.style.setProperty('--i', i++);
			path.style.stroke = f.stroke || (f.role === 'river' ? '#7cc4ff' : accent);
			path.style.fill = line || outline ? 'none' : (f.fill || accent);
			svg.appendChild(path);
			if (f.name && !line && !outline) {
				var ring0 = g.type === 'Polygon' ? g.coordinates[0] : g.coordinates[0][0], sx = 0, sy = 0;
				ring0.forEach(function (p) { sx += p[0]; sy += p[1]; });
				labels.push([P([sx / ring0.length, sy / ring0.length]), f.name]);
			}
		});
		labels.forEach(function (l, n) {
			var t = document.createElementNS(NS, 'text');
			t.setAttribute('x', l[0][0]); t.setAttribute('y', l[0][1]);
			t.setAttribute('class', 'wk-globe__label');
			t.style.setProperty('--i', n);
			var words = String(l[1]).split(' '), lines = [], cur = '';
			words.forEach(function (wd) { if ((cur + ' ' + wd).trim().length > 11 && cur) { lines.push(cur); cur = wd; } else { cur = (cur + ' ' + wd).trim(); } });
			lines.push(cur);
			lines.forEach(function (ln, j) {
				var s = document.createElementNS(NS, 'tspan');
				s.setAttribute('x', l[0][0]); s.setAttribute('dy', j ? '1.15em' : (-(lines.length - 1) * 0.575) + 'em');
				s.textContent = ln; t.appendChild(s);
			});
			svg.appendChild(t);
		});
		box.appendChild(svg);
		if (box.getAttribute('data-title')) {
			var cap = document.createElement('span');
			cap.className = 'wk-globe__maptitle';
			cap.textContent = box.getAttribute('data-title');
			box.appendChild(cap);
		}
	}

	function all(ctx) { (ctx || document).querySelectorAll('[data-wakoo-globe]').forEach(boot); }
	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', function () { all(); }); } else { all(); }
	window.addEventListener('elementor/frontend/init', function () {
		if (window.elementorFrontend && elementorFrontend.hooks) {
			elementorFrontend.hooks.addAction('frontend/element_ready/wakoo-globe.default', function ($s) { all($s[0]); });
		}
	});
})();
