<?php
/**
 * «Globo 3D (Wakoo)»: WebGL globe with markers and optional arcs (COBE, MIT).
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Immersive;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

defined( 'ABSPATH' ) || die();

class Globe extends Widget_Base {

	public function get_name() { return 'wakoo-globe'; }
	public function get_title() { return __( 'Globo 3D (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-globe'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'globo', 'globe', 'mundo', 'mapa', '3d', 'webgl', 'inmersivo', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-globe' ]; }
	public function get_style_depends() { return [ 'wakoo-immersive' ]; }

	protected function register_controls() {
		$this->start_controls_section( 'sec_globe', [ 'label' => __( 'Globo', 'wakoo' ) ] );
		$this->add_control( 'focus_lat', [ 'label' => __( 'Mirar hacia (latitud)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 8, 'min' => -90, 'max' => 90, 'step' => 0.01 ] );
		$this->add_control( 'focus_lng', [ 'label' => __( 'Mirar hacia (longitud)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => -64, 'min' => -180, 'max' => 180, 'step' => 0.01 ] );
		$this->add_control( 'spin', [ 'label' => __( 'Giro automático (0 = quieto)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 2, 'min' => 0, 'max' => 10, 'step' => 0.5, 'description' => __( 'Gira un poco a cada lado del punto elegido y vuelve. Se puede girar arrastrando.', 'wakoo' ) ] );
		$this->add_control( 'swing', [ 'label' => __( 'Amplitud del giro (grados)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 35, 'min' => 0, 'max' => 360 ] );
		$this->add_responsive_control( 'size', [ 'label' => __( 'Tamaño (px)', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'default' => 520, 'min' => 160, 'max' => 1200, 'selectors' => [ '{{WRAPPER}} .wk-globe__stage' => 'width: min(100%, {{VALUE}}px);' ] ] );
		$this->add_control( 'label', [ 'label' => __( 'Descripción accesible', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Globo terráqueo con la ubicación señalada', 'wakoo' ), 'label_block' => true ] );
		$this->add_control( 'link', [ 'label' => __( 'Enlace al hacer clic (opcional)', 'wakoo' ), 'type' => Controls_Manager::URL, 'placeholder' => 'https://…', 'label_block' => true, 'description' => __( 'Si se indica, al hacer clic en el globo se abre este enlace (sin arrastrar).', 'wakoo' ) ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_markers', [ 'label' => __( 'Marcadores', 'wakoo' ) ] );
		$r = new Repeater();
		$r->add_control( 'title', [ 'label' => __( 'Nombre', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Lugar', 'wakoo' ) ] );
		$r->add_control( 'lat', [ 'label' => __( 'Latitud', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'step' => 0.0001, 'default' => 8 ] );
		$r->add_control( 'lng', [ 'label' => __( 'Longitud', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'step' => 0.0001, 'default' => -64 ] );
		$r->add_control( 'size', [ 'label' => __( 'Tamaño', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 0.01, 'max' => 0.3, 'step' => 0.01, 'default' => 0.06 ] );
		$r->add_control( 'main', [ 'label' => __( 'Marcador principal (color de acento)', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ] );
		$this->add_control( 'markers', [ 'type' => Controls_Manager::REPEATER, 'fields' => $r->get_controls(), 'title_field' => '{{{ title }}}', 'default' => [ [ 'title' => __( 'Lugar', 'wakoo' ), 'lat' => 8, 'lng' => -64, 'size' => 0.08, 'main' => 'yes' ] ] ] );
		$this->add_control( 'legend', [ 'label' => __( 'Mostrar leyenda con los nombres', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_zoom', [ 'label' => __( 'Zoom al mapa', 'wakoo' ) ] );
		$this->add_control( 'zoom', [ 'label' => __( 'Acercar al pasar el ratón', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => '', 'description' => __( 'Al pasar el ratón (o al tocar en móvil) el globo gira hasta el punto elegido, se acerca y dibuja el mapa de detalle.', 'wakoo' ) ] );
		$on = [ 'zoom' => 'yes' ];
		$this->add_control( 'zoom_geo', [ 'label' => __( 'Mapa de detalle (GeoJSON)', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'rows' => 6, 'condition' => $on, 'description' => __( 'FeatureCollection en grados (lon, lat). Propiedades opcionales por elemento: name (rótulo), fill (color de relleno), stroke (color de línea), role «outline» (contorno sin relleno) o «river», y fit: true en los elementos que deben llenar el encuadre.', 'wakoo' ) ] );
		$this->add_control( 'zoom_title', [ 'label' => __( 'Título del mapa', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'label_block' => true, 'condition' => $on ] );
		$this->add_control( 'zoom_source', [ 'label' => __( 'Fuente de los límites', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'label_block' => true, 'condition' => $on, 'description' => __( 'Se muestra bajo el mapa. Indique de dónde salen los límites.', 'wakoo' ) ] );
		$this->add_control( 'zoom_scale', [ 'label' => __( 'Acercamiento', 'wakoo' ), 'type' => Controls_Manager::NUMBER, 'min' => 1.2, 'max' => 5, 'step' => 0.1, 'default' => 2.6, 'condition' => $on ] );
		$this->add_control( 'zoom_hint', [ 'label' => __( 'Indicación', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Pase el ratón o toque para acercar', 'wakoo' ), 'label_block' => true, 'condition' => $on ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_arcs', [ 'label' => __( 'Arcos', 'wakoo' ) ] );
		$a = new Repeater();
		$a->add_control( 'title', [ 'label' => __( 'Nombre', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		foreach ( [ 'from_lat' => __( 'Desde (latitud)', 'wakoo' ), 'from_lng' => __( 'Desde (longitud)', 'wakoo' ), 'to_lat' => __( 'Hasta (latitud)', 'wakoo' ), 'to_lng' => __( 'Hasta (longitud)', 'wakoo' ) ] as $k => $l ) {
			$a->add_control( $k, [ 'label' => $l, 'type' => Controls_Manager::NUMBER, 'step' => 0.0001 ] );
		}
		$this->add_control( 'arcs', [ 'type' => Controls_Manager::REPEATER, 'fields' => $a->get_controls(), 'title_field' => '{{{ title }}}', 'default' => [], 'description' => __( 'Úselos para relaciones reales, o rotúlelos claramente como proyección.', 'wakoo' ) ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Colores', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'dark', [ 'label' => __( 'Globo oscuro', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ] );
		$this->add_control( 'base', [ 'label' => __( 'Color de los continentes', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#3D6E9E' ] );
		$this->add_control( 'mark', [ 'label' => __( 'Color de los marcadores', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#FFFFFF' ] );
		$this->add_control( 'accent', [ 'label' => __( 'Color de acento (principal y arcos)', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#C5A15B' ] );
		$this->add_control( 'glow', [ 'label' => __( 'Color del halo', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'default' => '#174A7E' ] );
		$this->add_control( 'legend_color', [ 'label' => __( 'Color de la leyenda', 'wakoo' ), 'type' => Controls_Manager::COLOR, 'selectors' => [ '{{WRAPPER}} .wk-globe__legend' => 'color: {{VALUE}};' ] ] );
		$this->end_controls_section();
	}

	private static function rgb( $hex, $def ) {
		$hex = ltrim( (string) ( sanitize_hex_color( $hex ) ?: $def ), '#' );
		if ( 3 === strlen( $hex ) ) { $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2]; }
		return array_map( function ( $c ) { return round( hexdec( $c ) / 255, 3 ); }, str_split( substr( $hex, 0, 6 ), 2 ) );
	}

	/** Keeps only geometry plus the display properties the map uses, rounded to 4 decimals. */
	private static function clean_geo( $geo ) {
		$out = [];
		$rnd = function ( $c ) use ( &$rnd ) { return is_array( $c ) ? array_map( $rnd, $c ) : round( (float) $c, 4 ); };
		foreach ( (array) ( $geo['features'] ?? [] ) as $f ) {
			$g = $f['geometry'] ?? null;
			if ( ! is_array( $g ) || ! in_array( $g['type'] ?? '', [ 'Polygon', 'MultiPolygon', 'LineString', 'MultiLineString', 'Point' ], true ) ) { continue; }
			$p = (array) ( $f['properties'] ?? [] );
			$out[] = [ 'g' => [ 'type' => $g['type'], 'coordinates' => $rnd( $g['coordinates'] ?? [] ) ], 'name' => sanitize_text_field( (string) ( $p['name'] ?? '' ) ), 'fill' => sanitize_hex_color( (string) ( $p['fill'] ?? '' ) ), 'stroke' => sanitize_hex_color( (string) ( $p['stroke'] ?? '' ) ), 'role' => sanitize_key( (string) ( $p['role'] ?? '' ) ), 'fit' => ! empty( $p['fit'] ) ];
		}
		return $out;
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$markers = [];
		foreach ( (array) ( $s['markers'] ?? [] ) as $m ) {
			if ( ! is_numeric( $m['lat'] ?? '' ) || ! is_numeric( $m['lng'] ?? '' ) ) { continue; }
			$markers[] = [ 'title' => (string) ( $m['title'] ?? '' ), 'location' => [ (float) $m['lat'], (float) $m['lng'] ], 'size' => min( 0.3, max( 0.01, (float) ( $m['size'] ?? 0.05 ) ) ), 'main' => 'yes' === ( $m['main'] ?? '' ) ];
		}
		$arcs = [];
		foreach ( (array) ( $s['arcs'] ?? [] ) as $a ) {
			if ( ! is_numeric( $a['from_lat'] ?? '' ) || ! is_numeric( $a['to_lat'] ?? '' ) ) { continue; }
			$arcs[] = [ 'from' => [ (float) $a['from_lat'], (float) $a['from_lng'] ], 'to' => [ (float) $a['to_lat'], (float) $a['to_lng'] ] ];
		}
		$cfg = [
			'lat' => (float) ( $s['focus_lat'] ?? 8 ), 'lng' => (float) ( $s['focus_lng'] ?? -64 ),
			'spin' => (float) ( $s['spin'] ?? 2 ), 'swing' => (float) ( $s['swing'] ?? 35 ),
			'dark' => 'yes' === ( $s['dark'] ?? '' ), 'base' => self::rgb( $s['base'] ?? '', '#3D6E9E' ), 'mark' => self::rgb( $s['mark'] ?? '', '#FFFFFF' ),
			'accent' => self::rgb( $s['accent'] ?? '', '#C5A15B' ), 'glow' => self::rgb( $s['glow'] ?? '', '#174A7E' ),
			'markers' => $markers, 'arcs' => $arcs,
		];
		$zoom = null;
		if ( 'yes' === ( $s['zoom'] ?? '' ) ) {
			$geo  = json_decode( (string) ( $s['zoom_geo'] ?? '' ), true );
			$zoom = [
				'scale' => min( 5, max( 1.2, (float) ( $s['zoom_scale'] ?? 2.6 ) ) ),
				'geo'   => is_array( $geo ) && 'FeatureCollection' === ( $geo['type'] ?? '' ) ? self::clean_geo( $geo ) : null,
			];
			$cfg['zoom'] = $zoom;
		}
		$href = ! empty( $s['link']['url'] ) ? esc_url( $s['link']['url'] ) : '';
		echo '<figure class="wk-globe" data-wakoo-globe="' . esc_attr( wp_json_encode( $cfg ) ) . '"' . ( $href ? ' data-wakoo-href="' . esc_attr( $href ) . '"' : '' ) . '>';
		if ( $zoom ) {
			$title = (string) ( $s['zoom_title'] ?? '' );
			echo '<div class="wk-globe__stage wk-globe__stage--zoom" tabindex="0" role="button" aria-pressed="false" aria-label="' . esc_attr( trim( (string) ( $s['label'] ?? '' ) . '. ' . (string) ( $s['zoom_hint'] ?? '' ), '. ' ) ) . '"><canvas class="wk-globe__canvas" aria-hidden="true"></canvas>';
			echo '<div class="wk-globe__map" aria-hidden="true"' . ( '' !== $title ? ' data-title="' . esc_attr( $title ) . '"' : '' ) . '></div></div>';
			if ( '' !== (string) ( $s['zoom_hint'] ?? '' ) ) { echo '<p class="wk-globe__hint">' . esc_html( $s['zoom_hint'] ) . '</p>'; }
			if ( '' !== (string) ( $s['zoom_source'] ?? '' ) ) { echo '<p class="wk-globe__src">' . esc_html( $s['zoom_source'] ) . '</p>'; }
		} else {
			echo '<div class="wk-globe__stage"><canvas class="wk-globe__canvas" role="img" aria-label="' . esc_attr( (string) ( $s['label'] ?? '' ) ) . '"></canvas></div>';
		}
		if ( 'yes' === ( $s['legend'] ?? '' ) && $markers ) {
			echo '<figcaption class="wk-globe__legend"><ul>';
			foreach ( $markers as $m ) {
				if ( '' === $m['title'] ) { continue; }
				echo '<li class="' . ( $m['main'] ? 'is-main' : '' ) . '"><span aria-hidden="true"></span>' . esc_html( $m['title'] ) . '</li>';
			}
			echo '</ul></figcaption>';
		}
		echo '</figure>';
	}
}
