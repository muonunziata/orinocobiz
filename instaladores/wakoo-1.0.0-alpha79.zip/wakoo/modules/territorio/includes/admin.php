<?php
/**
 * Territorio admin: menu, field boxes for every type, case handling (status, assignee,
 * checklist, public message vs internal note, private documents), map import, settings,
 * reports with CSV and the audit trail. Every save checks nonce + capability and is logged.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Territorio;

defined( 'ABSPATH' ) || die();

class Admin {

	const HUB = 'wakoo-territorio';

	/** Field definitions per type: key => [ label, kind, extra ]. kind: text | area | num | date | select | check | url. */
	public static function fields( $type ) {
		$yn = [ '' => __( 'No', 'wakoo' ), 'yes' => __( 'Sí', 'wakoo' ) ];
		switch ( $type ) {
			case Module::PROJECT:
				return [
					'code'        => [ __( 'Identificador', 'wakoo' ), 'text' ],
					'stage'       => [ __( 'Estado de preparación', 'wakoo' ), 'select', Module::stages() ],
					'scale'       => [ __( 'Escala de la inversión', 'wakoo' ), 'select', [ '' => '—', 'ancla' => __( 'Inversión ancla', 'wakoo' ), 'complementaria' => __( 'Inversión complementaria', 'wakoo' ), 'territorial' => __( 'Inversión de base territorial', 'wakoo' ), 'habilitante' => __( 'Programa o instrumento habilitante', 'wakoo' ) ] ],
					'objective'   => [ __( 'Objetivo económico', 'wakoo' ), 'area' ],
					'location'    => [ __( 'Localización (texto)', 'wakoo' ), 'text' ],
					'lat'         => [ __( 'Latitud', 'wakoo' ), 'text' ],
					'lng'         => [ __( 'Longitud', 'wakoo' ), 'text' ],
					'geo_ok'      => [ __( 'Ubicación verificada (levantamiento o fuente oficial)', 'wakoo' ), 'select', $yn ],
					'geo_source'  => [ __( 'Fuente de la ubicación', 'wakoo' ), 'text' ],
					'amount'      => [ __( 'Inversión (número, sin puntos)', 'wakoo' ), 'num' ],
					'currency'    => [ __( 'Moneda', 'wakoo' ), 'select', [ 'USD' => 'USD', 'EUR' => 'EUR', 'VES' => 'VES' ] ],
					'amount_kind' => [ __( 'Naturaleza de la cifra', 'wakoo' ), 'select', [ 'estimate' => __( 'Estimación', 'wakoo' ), 'verified' => __( 'Cifra verificada', 'wakoo' ) ] ],
					'amount_src'  => [ __( 'Fuente de la estimación', 'wakoo' ), 'text' ],
					'amount_date' => [ __( 'Fecha de la estimación', 'wakoo' ), 'date' ],
					'infra'       => [ __( 'Necesidades de infraestructura', 'wakoo' ), 'area' ],
					'market'      => [ __( 'Mercado objetivo', 'wakoo' ), 'area' ],
					'permits'     => [ __( 'Requisitos y permisos', 'wakoo' ), 'area' ],
					'studies'     => [ __( 'Estudios disponibles', 'wakoo' ), 'area' ],
					'jobs'        => [ __( 'Impacto laboral estimado', 'wakoo' ), 'text' ],
					'risks'       => [ __( 'Riesgos', 'wakoo' ), 'area' ],
					'timeline'    => [ __( 'Cronograma', 'wakoo' ), 'area' ],
					'precond'     => [ __( 'Principal condición previa', 'wakoo' ), 'area' ],
					'responsible' => [ __( 'Responsable autorizado', 'wakoo' ), 'text' ],
					'docs'        => [ __( 'Documentación pública (una por línea: Título|URL)', 'wakoo' ), 'area' ],
					'source'      => [ __( 'Fuente del contenido', 'wakoo' ), 'text' ],
					'pending'     => [ __( 'Datos pendientes de validación', 'wakoo' ), 'area' ],
				];
			case Module::COMPANY:
				return [
					'level'        => [ __( 'Nivel de verificación', 'wakoo' ), 'select', Module::levels() ],
					'homologated'  => [ __( 'Homologado por (compradores, uno por línea)', 'wakoo' ), 'area' ],
					'legal_name'   => [ __( 'Razón social', 'wakoo' ), 'text' ],
					'rif'          => [ __( 'RIF (privado)', 'wakoo' ), 'text' ],
					'products'     => [ __( 'Productos y servicios', 'wakoo' ), 'area' ],
					'capabilities' => [ __( 'Capacidades técnicas', 'wakoo' ), 'area' ],
					'equipment'    => [ __( 'Equipos disponibles', 'wakoo' ), 'area' ],
					'certs'        => [ __( 'Certificaciones', 'wakoo' ), 'area' ],
					'web'          => [ __( 'Sitio web', 'wakoo' ), 'url' ],
					'email'        => [ __( 'Correo de contacto', 'wakoo' ), 'text' ],
					'phone'        => [ __( 'Teléfono', 'wakoo' ), 'text' ],
					'address'      => [ __( 'Dirección', 'wakoo' ), 'text' ],
					'source'       => [ __( 'Fuentes públicas (una por línea: Título|URL)', 'wakoo' ), 'area' ],
				];
			case Module::NEED:
				return [
					'company'  => [ __( 'Empresa (ID)', 'wakoo' ), 'num' ],
					'qty'      => [ __( 'Cantidad o alcance', 'wakoo' ), 'text' ],
					'deadline' => [ __( 'Fecha límite', 'wakoo' ), 'date' ],
					'closed'   => [ __( 'Cerrada', 'wakoo' ), 'select', $yn ],
				];
			case Module::GEO:
				return [
					'lat'      => [ __( 'Latitud (punto)', 'wakoo' ), 'text' ],
					'lng'      => [ __( 'Longitud (punto)', 'wakoo' ), 'text' ],
					'geojson'  => [ __( 'Geometría GeoJSON (líneas o polígonos; opcional)', 'wakoo' ), 'area' ],
					'public'   => [ __( 'Visible al público', 'wakoo' ), 'select', [ 'yes' => __( 'Sí, capa pública', 'wakoo' ), '' => __( 'No, solo uso interno', 'wakoo' ) ] ],
					'verified' => [ __( 'Información verificada', 'wakoo' ), 'select', $yn ],
					'source'   => [ __( 'Fuente', 'wakoo' ), 'text' ],
					'date'     => [ __( 'Fecha de la información', 'wakoo' ), 'date' ],
					'url'      => [ __( 'Enlace a la ficha', 'wakoo' ), 'url' ],
				];
			case Module::IND:
				return [
					'auto'     => [ __( 'Origen de los datos', 'wakoo' ), 'select', [ '' => __( 'Serie registrada a mano', 'wakoo' ), 'stages' => __( 'Automático: proyectos de la cartera por estado', 'wakoo' ), 'cases' => __( 'Automático: solicitudes de la ventanilla por estado', 'wakoo' ), 'response' => __( 'Automático: días hasta la primera respuesta', 'wakoo' ), 'companies' => __( 'Automático: empresas por nivel de verificación', 'wakoo' ), 'certs' => __( 'Automático: certificados emitidos por la academia', 'wakoo' ) ] ],
					'group'    => [ __( 'Grupo', 'wakoo' ), 'select', [ 'inversion' => __( 'Inversión', 'wakoo' ), 'proyectos' => __( 'Proyectos', 'wakoo' ), 'empleo' => __( 'Empleo y formación', 'wakoo' ), 'proveedores' => __( 'Proveedores y producción', 'wakoo' ), 'territorio' => __( 'Obras y servicios', 'wakoo' ), 'gestion' => __( 'Gestión institucional', 'wakoo' ) ] ],
					'unit'     => [ __( 'Unidad de medida', 'wakoo' ), 'text' ],
					'source'   => [ __( 'Fuente', 'wakoo' ), 'text' ],
					'updated'  => [ __( 'Fecha de actualización', 'wakoo' ), 'date' ],
					'period'   => [ __( 'Periodicidad', 'wakoo' ), 'text' ],
					'owner'    => [ __( 'Responsable', 'wakoo' ), 'text' ],
					'method'   => [ __( 'Metodología', 'wakoo' ), 'area' ],
					'check'    => [ __( 'Estado de verificación', 'wakoo' ), 'select', Module::checks() ],
					'public'   => [ __( 'Publicación', 'wakoo' ), 'select', [ 'yes' => __( 'Público (solo datos autorizados y agregados)', 'wakoo' ), '' => __( 'Interno', 'wakoo' ) ] ],
					'chart'    => [ __( 'Gráfico', 'wakoo' ), 'select', [ 'line' => __( 'Serie temporal (líneas)', 'wakoo' ), 'bar' => __( 'Barras', 'wakoo' ), 'doughnut' => __( 'Distribución (anillo)', 'wakoo' ), 'none' => __( 'Sin gráfico', 'wakoo' ) ] ],
					'demo'     => [ __( 'Datos de prueba (nunca se muestran como oficiales)', 'wakoo' ), 'select', $yn ],
					'series'   => [ __( 'Serie: una línea por periodo «periodo;valor;verificado(si/no)»', 'wakoo' ), 'area' ],
				];
			case Module::COURSE:
				return [
					'cstatus' => [ __( 'Estado del curso', 'wakoo' ), 'select', [ 'open' => __( 'Inscripción abierta', 'wakoo' ), 'design' => __( 'En diseño: solo registro de interés', 'wakoo' ), 'closed' => __( 'Cerrado', 'wakoo' ) ] ],
					'hours'   => [ __( 'Duración (horas)', 'wakoo' ), 'num' ],
					'mode'    => [ __( 'Modalidad', 'wakoo' ), 'select', [ '' => __( 'Por definir', 'wakoo' ), 'virtual' => __( 'Virtual', 'wakoo' ), 'mixta' => __( 'Mixta', 'wakoo' ), 'presencial' => __( 'Presencial', 'wakoo' ) ] ],
					'level'   => [ __( 'Nivel', 'wakoo' ), 'text' ],
					'cost'    => [ __( 'Costo (vacío = gratuito)', 'wakoo' ), 'text' ],
					'icon'    => [ __( 'Icono en la vista de iconos (Font Awesome 5, p. ej. fas fa-book)', 'wakoo' ), 'text' ],
					'certify' => [ __( 'Emite certificado al completar', 'wakoo' ), 'select', [ 'yes' => __( 'Sí', 'wakoo' ), 'no' => __( 'No', 'wakoo' ) ] ],
					'criteria'=> [ __( 'Criterios de certificación', 'wakoo' ), 'area' ],
					'moodle'  => [ __( 'Curso en Moodle (URL, opcional)', 'wakoo' ), 'url' ],
					'demo'    => [ __( 'Curso de demostración', 'wakoo' ), 'select', $yn ],
				];
			case Module::LESSON:
				return [
					'course'   => [ __( 'Curso (ID)', 'wakoo' ), 'num' ],
					'video'    => [ __( 'Vídeo (URL de YouTube, Vimeo o MP4)', 'wakoo' ), 'url' ],
					'material' => [ __( 'Materiales descargables (Título|URL por línea)', 'wakoo' ), 'area' ],
					'quiz'     => [ __( 'Evaluación (JSON: [{"q":"Pregunta","options":["A","B"],"answer":0}])', 'wakoo' ), 'area' ],
					'pass'     => [ __( 'Nota mínima (%)', 'wakoo' ), 'num' ],
				];
		}
		return [];
	}

	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ], 9 );
		add_action( 'add_meta_boxes', [ __CLASS__, 'boxes' ] );
		add_action( 'save_post', [ __CLASS__, 'save' ], 10, 2 );
		add_action( 'transition_post_status', [ __CLASS__, 'moderation' ], 10, 3 );
		add_action( 'admin_post_wakoo_t_settings', [ __CLASS__, 'save_settings' ] );
		add_action( 'admin_post_wakoo_t_csv', [ __CLASS__, 'csv' ] );
		add_action( 'admin_post_wakoo_t_geo_import', [ __CLASS__, 'geo_import' ] );
		add_action( 'admin_post_wakoo_t_file_drop', [ __CLASS__, 'file_drop' ] );
		add_action( Module::T_LAYER . '_edit_form_fields', [ __CLASS__, 'layer_fields' ] );
		add_action( 'edited_' . Module::T_LAYER, [ __CLASS__, 'layer_save' ] );
		add_filter( 'manage_' . Module::CASE_T . '_posts_columns', [ __CLASS__, 'case_cols' ] );
		add_action( 'manage_' . Module::CASE_T . '_posts_custom_column', [ __CLASS__, 'case_col' ], 10, 2 );
		add_filter( 'manage_' . Module::PROJECT . '_posts_columns', [ __CLASS__, 'project_cols' ] );
		add_action( 'manage_' . Module::PROJECT . '_posts_custom_column', [ __CLASS__, 'project_col' ], 10, 2 );
		add_filter( 'manage_' . Module::COMPANY . '_posts_columns', [ __CLASS__, 'company_cols' ] );
		add_action( 'manage_' . Module::COMPANY . '_posts_custom_column', [ __CLASS__, 'company_col' ], 10, 2 );
		add_action( 'admin_enqueue_scripts', function () {
			wp_add_inline_style( 'common', '.wkt-f label{display:block;font-weight:600;margin:10px 0 4px}.wkt-f input[type=text],.wkt-f input[type=url],.wkt-f input[type=number],.wkt-f input[type=date],.wkt-f select,.wkt-f textarea{width:100%}.wkt-f textarea{min-height:70px}.wkt-g{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:0 18px}.wkt-tl{max-height:420px;overflow:auto;border:1px solid #dcdcde;background:#fff}.wkt-tl div{padding:8px 10px;border-bottom:1px solid #f0f0f1}.wkt-tl .i{background:#fcf9e8}.wkt-tl .a{background:#f6f7f7;color:#646970}.wkt-tl small{color:#646970;display:block}.wkt-b{display:inline-block;padding:1px 8px;border-radius:9px;background:#e7f0f8;font-size:11px}.wkt-b.i{background:#fcf0c3}.wkt-num{font-size:28px;font-weight:700;color:#10355B}.wkt-cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;margin:16px 0}.wkt-cards>div{background:#fff;border:1px solid #dcdcde;padding:14px;border-radius:6px}' );
		} );
	}

	public static function menu() {
		add_menu_page( __( 'Territorio', 'wakoo' ), __( 'Territorio Wakoo', 'wakoo' ), 'wk_staff', self::HUB, [ __CLASS__, 'dashboard' ], 'dashicons-chart-area', 57 );
		add_submenu_page( self::HUB, __( 'Resumen', 'wakoo' ), __( 'Resumen', 'wakoo' ), 'wk_staff', self::HUB, [ __CLASS__, 'dashboard' ] );
		add_submenu_page( self::HUB, __( 'Reportes', 'wakoo' ), __( 'Reportes', 'wakoo' ), 'wk_reports', 'wakoo-t-reports', [ __CLASS__, 'reports' ] );
		add_submenu_page( self::HUB, __( 'Importar capas del mapa', 'wakoo' ), __( 'Importar al mapa', 'wakoo' ), 'edit_others_wk_geos', 'wakoo-t-geo', [ __CLASS__, 'geo_page' ] );
		add_submenu_page( self::HUB, __( 'Auditoría', 'wakoo' ), __( 'Auditoría', 'wakoo' ), 'wk_view_audit', 'wakoo-t-audit', [ __CLASS__, 'audit' ] );
		add_submenu_page( self::HUB, __( 'Ajustes', 'wakoo' ), __( 'Ajustes', 'wakoo' ), 'wk_manage_portal', 'wakoo-t-settings', [ __CLASS__, 'settings_page' ] );
		foreach ( [ Module::T_SECTOR => [ Module::PROJECT, __( 'Sectores', 'wakoo' ) ], Module::T_MUN => [ Module::PROJECT, __( 'Municipios', 'wakoo' ) ], Module::T_CCAT => [ Module::COMPANY, __( 'Categorías de empresa', 'wakoo' ) ], Module::T_LAYER => [ Module::GEO, __( 'Capas del mapa', 'wakoo' ) ], Module::T_SCHOOL => [ Module::COURSE, __( 'Escuelas', 'wakoo' ) ] ] as $tax => $d ) {
			$t = get_taxonomy( $tax );
			if ( $t ) { add_submenu_page( self::HUB, $d[1], $d[1], $t->cap->manage_terms, 'edit-tags.php?taxonomy=' . $tax . '&post_type=' . $d[0] ); }
		}
	}

	/* ---------------------------------------------------------------- dashboard & reports */

	private static function count_by_meta( $type, $key, $labels, $status = [ 'publish', 'private', 'pending', 'draft' ] ) {
		$out = array_fill_keys( array_keys( $labels ), 0 );
		$args = [ 'post_type' => $type, 'post_status' => $status, 'numberposts' => -1, 'fields' => 'ids' ];
		if ( in_array( $type, [ Module::PROJECT, Module::IND, Module::COURSE ], true ) ) { $args = Module::by_lang( $args, Module::master_lang() ); } // Translations are not counted twice.
		$ids = get_posts( $args );
		foreach ( $ids as $id ) {
			$v = (string) Module::meta( $id, $key );
			if ( isset( $out[ $v ] ) ) { $out[ $v ]++; }
		}
		return $out;
	}

	/** Shared numbers for the dashboard, reports and automatic indicators. */
	public static function numbers( $what ) {
		switch ( $what ) {
			case 'stages':
				return self::count_by_meta( Module::PROJECT, 'stage', Module::stages(), [ 'publish' ] );
			case 'cases':
				return self::count_by_meta( Module::CASE_T, 'status', wp_list_pluck( Module::statuses(), 0 ), [ 'private', 'publish' ] );
			case 'companies':
				return self::count_by_meta( Module::COMPANY, 'level', Module::levels(), [ 'publish' ] );
			case 'certs':
				return [ 'certs' => count( get_posts( [ 'post_type' => Module::CERT, 'post_status' => [ 'private', 'publish' ], 'numberposts' => -1, 'fields' => 'ids' ] ) ) ];
			case 'response':
				$days = [];
				foreach ( get_posts( [ 'post_type' => Module::CASE_T, 'post_status' => [ 'private', 'publish' ], 'numberposts' => -1 ] ) as $c ) {
					foreach ( Store::lines( Module::CASE_T, $c->ID, [ 'public' ] ) as $l ) {
						if ( in_array( $l->kind, [ 'staff', 'status_change' ], true ) ) {
							$days[] = max( 0, ( strtotime( $l->created . ' UTC' ) - strtotime( $c->post_date_gmt . ' UTC' ) ) / DAY_IN_SECONDS );
							break;
						}
					}
				}
				return [ 'avg' => $days ? round( array_sum( $days ) / count( $days ), 1 ) : null, 'n' => count( $days ) ];
		}
		return [];
	}

	public static function dashboard() {
		$m_company = wp_count_posts( Module::COMPANY );
		$m_need    = wp_count_posts( Module::NEED );
		$m_ind     = wp_count_posts( Module::IND );
		$m_course  = wp_count_posts( Module::COURSE );
		$m_cert    = wp_count_posts( Module::CERT );

		$cases    = array_sum( self::numbers( 'cases' ) );
		$stages   = self::numbers( 'stages' );
		$levels   = self::numbers( 'companies' );
		$response = self::numbers( 'response' );

		$users   = count_users();
		$members = isset( $users['avail_roles']['wakoo_member'] ) ? (int) $users['avail_roles']['wakoo_member'] : 0;

		$month = static function ( $type ) {
			$q = new \WP_Query( [
				'post_type' => $type, 'post_status' => 'any', 'posts_per_page' => 1,
				'fields' => 'ids', 'date_query' => [ [ 'after' => 'first day of this month' ] ],
			] );
			return (int) $q->found_posts;
		};
		$month_cases     = $month( Module::CASE_T );
		$month_companies = $month( Module::COMPANY );
		$month_projects  = $month( Module::PROJECT );
		$uc              = new \WP_User_Query( [ 'number' => 1, 'date_query' => [ [ 'after' => 'first day of this month' ] ] ] );
		$month_users     = (int) $uc->get_total();

		$cards = [
			[ __( 'Proyectos publicados', 'wakoo' ), array_sum( $stages ), 'edit.php?post_type=' . Module::PROJECT ],
			[ __( 'Solicitudes en la ventanilla', 'wakoo' ), $cases, 'edit.php?post_type=' . Module::CASE_T ],
			[ __( 'Empresas en el directorio', 'wakoo' ), array_sum( $levels ), 'edit.php?post_type=' . Module::COMPANY ],
			[ __( 'Empresas por moderar', 'wakoo' ), (int) $m_company->pending, 'edit.php?post_status=pending&post_type=' . Module::COMPANY ],
			[ __( 'Necesidades por moderar', 'wakoo' ), (int) $m_need->pending, 'edit.php?post_status=pending&post_type=' . Module::NEED ],
			[ __( 'Indicadores', 'wakoo' ), (int) $m_ind->publish, 'edit.php?post_type=' . Module::IND ],
			[ __( 'Cursos', 'wakoo' ), (int) $m_course->publish, 'edit.php?post_type=' . Module::COURSE ],
			[ __( 'Certificados', 'wakoo' ), (int) $m_cert->publish + (int) $m_cert->private, 'edit.php?post_type=' . Module::CERT ],
			[ __( 'Usuarios registrados', 'wakoo' ), (int) $users['total_users'], 'users.php' ],
			[ __( 'Miembros', 'wakoo' ), $members, 'users.php?role=wakoo_member' ],
		];

		echo '<div class="wrap"><h1>' . esc_html__( 'Territorio e inversión', 'wakoo' ) . '</h1>';
		echo '<p>' . esc_html__( 'Ventanilla del inversionista, cartera de proyectos, directorio empresarial, mapa, observatorio y academia. El portal registra, orienta y hace seguimiento: no concede permisos ni aprueba proyectos.', 'wakoo' ) . '</p>';

		echo '<h2>' . esc_html__( 'Registro este mes', 'wakoo' ) . '</h2><div class="wkt-cards">';
		foreach ( [
			[ __( 'Solicitudes', 'wakoo' ), $month_cases ],
			[ __( 'Empresas', 'wakoo' ), $month_companies ],
			[ __( 'Proyectos', 'wakoo' ), $month_projects ],
			[ __( 'Usuarios', 'wakoo' ), $month_users ],
		] as $c ) {
			echo '<div><div class="wkt-num">' . esc_html( (string) $c[1] ) . '</div><span>' . esc_html( $c[0] ) . '</span></div>';
		}
		echo '</div>';

		echo '<h2>' . esc_html__( 'Funcionamiento', 'wakoo' ) . '</h2><div class="wkt-cards">';
		foreach ( $cards as $c ) {
			echo '<div><div class="wkt-num">' . esc_html( (string) $c[1] ) . '</div><a href="' . esc_url( admin_url( $c[2] ) ) . '">' . esc_html( $c[0] ) . '</a></div>';
		}
		echo '</div>';

		if ( null !== $response['avg'] ) {
			echo '<p>' . esc_html( sprintf( __( 'Tiempo medio hasta la primera respuesta de la ventanilla: %1$s días (%2$d solicitudes).', 'wakoo' ), number_format_i18n( $response['avg'], 1 ), $response['n'] ) ) . '</p>';
		}

		$st     = Module::statuses();
		$recent = get_posts( [ 'post_type' => Module::CASE_T, 'post_status' => 'any', 'numberposts' => 5, 'orderby' => 'date', 'order' => 'DESC' ] );
		if ( $recent ) {
			echo '<h2>' . esc_html__( 'Solicitudes recientes', 'wakoo' ) . '</h2><table class="widefat striped" style="max-width:900px"><thead><tr><th>' . esc_html__( 'Código', 'wakoo' ) . '</th><th>' . esc_html__( 'Iniciativa', 'wakoo' ) . '</th><th>' . esc_html__( 'Estado', 'wakoo' ) . '</th><th>' . esc_html__( 'Fecha', 'wakoo' ) . '</th></tr></thead><tbody>';
			foreach ( $recent as $p ) {
				$code = (string) Module::meta( $p->ID, 'code' );
				$stat = Module::meta( $p->ID, 'status' );
				echo '<tr><td>' . esc_html( $code ) . '</td><td><a href="' . esc_url( (string) get_edit_post_link( $p->ID ) ) . '">' . esc_html( $p->post_title ) . '</a></td><td>' . esc_html( $st[ $stat ][0] ?? '—' ) . '</td><td>' . esc_html( get_the_date( 'd/m/Y', $p ) ) . '</td></tr>';
			}
			echo '</tbody></table>';
		}

		echo '<h2>' . esc_html__( 'Accesos rápidos', 'wakoo' ) . '</h2><p><a class="button" href="' . esc_url( admin_url( 'admin.php?page=wakoo-t-reports' ) ) . '">' . esc_html__( 'Reportes y CSV', 'wakoo' ) . '</a> <a class="button" href="' . esc_url( admin_url( 'admin.php?page=wakoo-t-settings' ) ) . '">' . esc_html__( 'Ajustes del portal', 'wakoo' ) . '</a></p>';

		echo '<h2>' . esc_html__( 'Correo', 'wakoo' ) . '</h2><p>' . esc_html__( 'Las notificaciones usan wp_mail(). Para que lleguen de forma fiable, configure un proveedor SMTP o transaccional en el sitio (plugin SMTP o servidor de correo). Sin proveedor, el registro y el seguimiento funcionan igual, pero los correos pueden no llegar.', 'wakoo' ) . '</p></div>';
	}

	public static function reports() {
		$sets = [
			'projects'  => __( 'Cartera de proyectos', 'wakoo' ),
			'cases'     => __( 'Solicitudes de la ventanilla', 'wakoo' ),
			'companies' => __( 'Empresas del directorio', 'wakoo' ),
			'academy'   => __( 'Participación en la academia', 'wakoo' ),
			'indicators'=> __( 'Indicadores del observatorio', 'wakoo' ),
		];
		echo '<div class="wrap"><h1>' . esc_html__( 'Reportes', 'wakoo' ) . '</h1><table class="widefat striped" style="max-width:780px"><tbody>';
		foreach ( $sets as $k => $label ) {
			$rows = self::rows( $k );
			$url  = wp_nonce_url( admin_url( 'admin-post.php?action=wakoo_t_csv&set=' . $k ), 'wakoo_t_csv' );
			echo '<tr><td><strong>' . esc_html( $label ) . '</strong></td><td>' . esc_html( sprintf( _n( '%d fila', '%d filas', max( 0, count( $rows ) - 1 ), 'wakoo' ), max( 0, count( $rows ) - 1 ) ) ) . '</td><td><a class="button" href="' . esc_url( $url ) . '">' . esc_html__( 'Descargar CSV', 'wakoo' ) . '</a></td></tr>';
		}
		echo '</tbody></table>';
		echo '<h2>' . esc_html__( 'Proyectos por estado', 'wakoo' ) . '</h2><ul>';
		foreach ( self::numbers( 'stages' ) as $k => $n ) { echo '<li>' . esc_html( Module::stages()[ $k ] . ': ' . $n ) . '</li>'; }
		echo '</ul><h2>' . esc_html__( 'Solicitudes por estado', 'wakoo' ) . '</h2><ul>';
		$st = Module::statuses();
		foreach ( self::numbers( 'cases' ) as $k => $n ) { echo '<li>' . esc_html( $st[ $k ][0] . ': ' . $n ) . '</li>'; }
		echo '</ul></div>';
	}

	/** Report rows (first row = header). Private documents and contact data never go in. */
	public static function rows( $set ) {
		$out = [];
		switch ( $set ) {
			case 'projects':
				if ( ! current_user_can( 'edit_wk_projects' ) ) { return []; }
				$out[] = [ 'ID', 'Identificador', 'Proyecto', 'Estado', 'Sector', 'Municipio', 'Inversión', 'Naturaleza', 'Fuente', 'Publicado' ];
				foreach ( get_posts( [ 'post_type' => Module::PROJECT, 'post_status' => 'any', 'numberposts' => -1 ] ) as $p ) {
					$out[] = [ $p->ID, Module::meta( $p->ID, 'code' ), $p->post_title, Module::stages()[ Module::meta( $p->ID, 'stage', 'conceptual' ) ] ?? '', Module::term_names( $p->ID, Module::T_SECTOR ), Module::term_names( $p->ID, Module::T_MUN ), Module::money( $p->ID ), Module::meta( $p->ID, 'amount_kind' ), Module::meta( $p->ID, 'amount_src' ), $p->post_status ];
				}
				break;
			case 'cases':
				if ( ! current_user_can( 'edit_others_wk_cases' ) ) { return []; }
				$out[] = [ 'Código', 'Iniciativa', 'Estado', 'Sector', 'Municipio', 'Madurez', 'Registrada', 'Responsable' ];
				$st = Module::statuses();
				foreach ( get_posts( [ 'post_type' => Module::CASE_T, 'post_status' => 'any', 'numberposts' => -1 ] ) as $p ) {
					$a = (int) Module::meta( $p->ID, 'assignee' );
					$out[] = [ Module::meta( $p->ID, 'code' ), $p->post_title, $st[ Module::meta( $p->ID, 'status' ) ][0] ?? '', Module::term_names( $p->ID, Module::T_SECTOR ), Module::term_names( $p->ID, Module::T_MUN ), Module::stages()[ Module::meta( $p->ID, 'maturity' ) ] ?? '', $p->post_date, $a ? get_the_author_meta( 'display_name', $a ) : '' ];
				}
				break;
			case 'companies':
				if ( ! current_user_can( 'edit_others_wk_companys' ) ) { return []; }
				$out[] = [ 'ID', 'Empresa', 'Categoría', 'Sector', 'Municipio', 'Nivel', 'Estado' ];
				foreach ( get_posts( [ 'post_type' => Module::COMPANY, 'post_status' => 'any', 'numberposts' => -1 ] ) as $p ) {
					$out[] = [ $p->ID, $p->post_title, Module::term_names( $p->ID, Module::T_CCAT ), Module::term_names( $p->ID, Module::T_SECTOR ), Module::term_names( $p->ID, Module::T_MUN ), Module::levels()[ Module::meta( $p->ID, 'level', 'registrada' ) ] ?? '', $p->post_status ];
				}
				break;
			case 'academy':
				if ( ! current_user_can( 'edit_wk_courses' ) ) { return []; }
				$out[] = [ 'ID', 'Curso', 'Inscritos', 'Interesados', 'Completados', 'Certificados' ];
				$users = get_users( [ 'meta_key' => Academy::ENROL, 'fields' => [ 'ID' ] ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
				foreach ( get_posts( [ 'post_type' => Module::COURSE, 'post_status' => 'any', 'numberposts' => -1 ] ) as $p ) {
					if ( ! current_user_can( 'edit_post', $p->ID ) ) { continue; }
					$n = [ 'enrolled' => 0, 'interest' => 0, 'completed' => 0 ];
					foreach ( $users as $u ) { $e = Academy::enrolment( $u->ID, $p->ID ); if ( $e && isset( $n[ $e['status'] ] ) ) { $n[ $e['status'] ]++; } }
					$certs = count( get_posts( [ 'post_type' => Module::CERT, 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids', 'meta_key' => Module::PRE . 'course', 'meta_value' => $p->ID ] ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
					$out[] = [ $p->ID, $p->post_title, $n['enrolled'] + $n['completed'], $n['interest'], $n['completed'], $certs ];
				}
				break;
			case 'indicators':
				if ( ! current_user_can( 'edit_wk_indicators' ) ) { return []; }
				$out[] = [ 'ID', 'Indicador', 'Unidad', 'Fuente', 'Actualización', 'Periodicidad', 'Responsable', 'Verificación', 'Público', 'Prueba' ];
				foreach ( get_posts( [ 'post_type' => Module::IND, 'post_status' => 'any', 'numberposts' => -1 ] ) as $p ) {
					$out[] = [ $p->ID, $p->post_title, Module::meta( $p->ID, 'unit' ), Module::meta( $p->ID, 'source' ), Module::meta( $p->ID, 'updated' ), Module::meta( $p->ID, 'period' ), Module::meta( $p->ID, 'owner' ), Module::checks()[ Module::meta( $p->ID, 'check', 'pendiente' ) ] ?? '', Module::meta( $p->ID, 'public' ) ? 'sí' : 'no', Module::meta( $p->ID, 'demo' ) ? 'sí' : 'no' ];
				}
				break;
		}
		return $out;
	}

	public static function csv() {
		if ( ! current_user_can( 'wk_reports' ) || ! check_admin_referer( 'wakoo_t_csv' ) ) { wp_die( esc_html__( 'No autorizado.', 'wakoo' ) ); }
		$set  = sanitize_key( wp_unslash( $_GET['set'] ?? '' ) );
		$rows = self::rows( $set );
		if ( ! $rows ) { wp_die( esc_html__( 'No autorizado.', 'wakoo' ) ); }
		Store::log( 'report', 0, 'csv', 'Exportación CSV: ' . $set, 'audit' );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $set . '-' . gmdate( 'Ymd' ) . '.csv"' );
		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		foreach ( $rows as $r ) {
			// Cells starting with = + - @ would run as formulas in a spreadsheet.
			fputcsv( $out, array_map( function ( $c ) { $c = (string) $c; return preg_match( '/^[=+\-@]/', $c ) ? "'" . $c : $c; }, $r ) );
		}
		exit;
	}

	public static function audit() {
		$type = sanitize_key( wp_unslash( $_GET['t'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$pg   = max( 1, (int) ( $_GET['pg'] ?? 1 ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$rows = Store::latest( $type, 100, ( $pg - 1 ) * 100 );
		echo '<div class="wrap"><h1>' . esc_html__( 'Auditoría', 'wakoo' ) . '</h1><p>' . esc_html__( 'Registro de cambios y operaciones sensibles. Las direcciones IP no se guardan: solo una huella cifrada para detectar abusos.', 'wakoo' ) . '</p>';
		echo '<form><input type="hidden" name="page" value="wakoo-t-audit"><select name="t"><option value="">' . esc_html__( 'Todo', 'wakoo' ) . '</option>';
		foreach ( [ Module::CASE_T, Module::PROJECT, Module::COMPANY, Module::NEED, Module::RFQ, Module::IND, Module::GEO, Module::COURSE, Module::LESSON, 'user', 'report', 'settings' ] as $t ) { echo '<option' . selected( $type, $t, false ) . '>' . esc_html( $t ) . '</option>'; }
		echo '</select> <button class="button">' . esc_html__( 'Filtrar', 'wakoo' ) . '</button></form><table class="widefat striped"><thead><tr><th>' . esc_html__( 'Fecha (UTC)', 'wakoo' ) . '</th><th>' . esc_html__( 'Usuario', 'wakoo' ) . '</th><th>' . esc_html__( 'Objeto', 'wakoo' ) . '</th><th>' . esc_html__( 'Acción', 'wakoo' ) . '</th><th>' . esc_html__( 'Visibilidad', 'wakoo' ) . '</th><th>' . esc_html__( 'Detalle', 'wakoo' ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$u = $r->user_id ? get_the_author_meta( 'display_name', $r->user_id ) : '—';
			echo '<tr><td>' . esc_html( $r->created ) . '</td><td>' . esc_html( $u ) . '</td><td>' . esc_html( $r->obj_type . ' #' . $r->obj_id ) . '</td><td>' . esc_html( $r->kind ) . '</td><td>' . esc_html( $r->vis ) . '</td><td>' . wp_kses( $r->message, [ 'br' => [] ] ) . '</td></tr>';
		}
		echo '</tbody></table><p>';
		if ( $pg > 1 ) { echo '<a class="button" href="' . esc_url( add_query_arg( 'pg', $pg - 1 ) ) . '">&larr;</a> '; }
		if ( count( $rows ) === 100 ) { echo '<a class="button" href="' . esc_url( add_query_arg( 'pg', $pg + 1 ) ) . '">&rarr;</a>'; }
		echo '</p></div>';
	}

	/* ---------------------------------------------------------------- settings */

	public static function settings_page() {
		$s = Module::settings();
		$pages = get_posts( [ 'post_type' => 'page', 'post_status' => [ 'publish', 'draft', 'private' ], 'numberposts' => 500, 'orderby' => 'title', 'order' => 'ASC' ] );
		$tpls  = get_posts( [ 'post_type' => 'elementor_library', 'post_status' => [ 'publish', 'draft', 'private' ], 'numberposts' => 500, 'orderby' => 'title', 'order' => 'ASC' ] );
		$sel = function ( $name, $list, $val ) {
			$h = '<select name="' . esc_attr( $name ) . '"><option value="0">—</option>';
			foreach ( $list as $p ) { $h .= '<option value="' . (int) $p->ID . '"' . selected( (int) $val, $p->ID, false ) . '>' . esc_html( $p->post_title . ' (#' . $p->ID . ')' ) . '</option>'; }
			return $h . '</select>';
		};
		echo '<div class="wrap wkt-f"><h1>' . esc_html__( 'Ajustes de Territorio', 'wakoo' ) . '</h1>';
		if ( isset( $_GET['saved'] ) ) { echo '<div class="notice notice-success"><p>' . esc_html__( 'Ajustes guardados.', 'wakoo' ) . '</p></div>'; } // phpcs:ignore WordPress.Security.NonceVerification
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'wakoo_t_settings' );
		echo '<input type="hidden" name="action" value="wakoo_t_settings"><div class="wkt-g">';
		echo '<div><h2>' . esc_html__( 'Ventanilla', 'wakoo' ) . '</h2>';
		echo '<label>' . esc_html__( 'Prefijo de los códigos de solicitud', 'wakoo' ) . '</label><input type="text" name="prefix" value="' . esc_attr( $s['prefix'] ) . '">';
		echo '<label>' . esc_html__( 'Estados de tramitación (uno por línea: clave|Nombre|cerrado)', 'wakoo' ) . '</label><textarea name="statuses" rows="8">' . esc_textarea( $s['statuses'] ) . '</textarea>';
		echo '<label>' . esc_html__( 'Lista de requisitos (uno por línea)', 'wakoo' ) . '</label><textarea name="requirements" rows="7">' . esc_textarea( $s['requirements'] ) . '</textarea>';
		echo '<label>' . esc_html__( 'Correo del equipo (avisos internos)', 'wakoo' ) . '</label><input type="text" name="staff_email" value="' . esc_attr( $s['staff_email'] ) . '" placeholder="' . esc_attr( get_option( 'admin_email' ) ) . '">';
		echo '<label>' . esc_html__( 'Tamaño máximo por archivo (MB)', 'wakoo' ) . '</label><input type="number" name="max_mb" min="1" max="50" value="' . (int) $s['max_mb'] . '">';
		echo '<label><input type="checkbox" name="register" value="1"' . checked( $s['register'], 1, false ) . '> ' . esc_html__( 'Permitir crear cuentas desde el portal', 'wakoo' ) . '</label>';
		echo '<p class="description">' . esc_html( sprintf( __( 'Documentos privados en: %s. Para máxima seguridad defina WAKOO_PRIVATE_DIR en wp-config.php con una carpeta fuera de la raíz web (en Nginx el .htaccess no se aplica).', 'wakoo' ), Store::dir() ) ) . '</p></div>';
		echo '<div><h2>' . esc_html__( 'Páginas y plantillas', 'wakoo' ) . '</h2>';
		foreach ( [ 'tpl_project' => __( 'Plantilla de la ficha de proyecto', 'wakoo' ), 'tpl_company' => __( 'Plantilla de la ficha de empresa', 'wakoo' ), 'tpl_course' => __( 'Plantilla de la página de curso', 'wakoo' ) ] as $k => $l ) {
			echo '<label>' . esc_html( $l ) . '</label>' . $sel( $k, $tpls, $s[ $k ] ); // phpcs:ignore WordPress.Security.EscapeOutput
		}
		foreach ( [ 'page_access' => __( 'Página de acceso (iniciar sesión / crear cuenta)', 'wakoo' ), 'page_cases' => __( 'Panel del solicitante', 'wakoo' ), 'page_cases_new' => __( 'Página para presentar una iniciativa', 'wakoo' ), 'page_company' => __( 'Panel de la empresa', 'wakoo' ), 'page_student' => __( 'Panel del estudiante', 'wakoo' ), 'page_verify' => __( 'Verificación de certificados', 'wakoo' ) ] as $k => $l ) {
			echo '<label>' . esc_html( $l ) . '</label>' . $sel( $k, $pages, $s[ $k ] ); // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '<label>' . esc_html__( 'Emisor de los certificados', 'wakoo' ) . '</label><input type="text" name="issuer" value="' . esc_attr( $s['issuer'] ) . '">';
		echo '<label>' . esc_html__( 'Moodle (URL base, opcional)', 'wakoo' ) . '</label><input type="url" name="moodle_url" value="' . esc_attr( $s['moodle_url'] ) . '"></div>';
		echo '<div><h2>' . esc_html__( 'Mapa', 'wakoo' ) . '</h2>';
		echo '<label>' . esc_html__( 'Teselas (URL con {z}/{x}/{y})', 'wakoo' ) . '</label><input type="text" name="tiles" value="' . esc_attr( $s['tiles'] ) . '">';
		echo '<label>' . esc_html__( 'Atribución de las teselas', 'wakoo' ) . '</label><input type="text" name="attr" value="' . esc_attr( $s['attr'] ) . '">';
		echo '<label>' . esc_html__( 'Clave de Google Maps (Maps JavaScript API; vacío = la de Elementor → Ajustes → Integraciones)', 'wakoo' ) . '</label><input type="text" name="gmaps_key" autocomplete="off" value="' . esc_attr( $s['gmaps_key'] ) . '">';
		echo '<label>' . esc_html__( 'Centro inicial (lat,lng)', 'wakoo' ) . '</label><input type="text" name="center" value="' . esc_attr( $s['center'] ) . '">';
		echo '<label>' . esc_html__( 'Zoom inicial', 'wakoo' ) . '</label><input type="number" name="zoom" min="3" max="16" value="' . (int) $s['zoom'] . '">';
		echo '<p class="description">' . esc_html__( 'Las teselas estándar de OpenStreetMap son de uso moderado y exigen atribución. Para tráfico alto use un proveedor propio o con contrato.', 'wakoo' ) . '</p></div>';
		echo '</div>';
		submit_button();
		echo '</form></div>';
	}

	public static function save_settings() {
		if ( ! current_user_can( 'wk_manage_portal' ) || ! check_admin_referer( 'wakoo_t_settings' ) ) { wp_die( esc_html__( 'No autorizado.', 'wakoo' ) ); }
		$s = Module::settings();
		$p = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		foreach ( [ 'prefix', 'staff_email', 'center', 'issuer' ] as $k ) { $s[ $k ] = sanitize_text_field( $p[ $k ] ?? '' ); }
		foreach ( [ 'statuses', 'requirements' ] as $k ) { $s[ $k ] = sanitize_textarea_field( $p[ $k ] ?? '' ); }
		foreach ( [ 'tpl_project', 'tpl_company', 'tpl_course', 'page_access', 'page_cases', 'page_cases_new', 'page_company', 'page_student', 'page_verify', 'zoom', 'max_mb' ] as $k ) { $s[ $k ] = (int) ( $p[ $k ] ?? 0 ); }
		$s['register']   = empty( $p['register'] ) ? 0 : 1;
		$s['moodle_url'] = esc_url_raw( $p['moodle_url'] ?? '' );
		$s['tiles']      = esc_url_raw( str_replace( [ '{', '}' ], [ '%7B', '%7D' ], $p['tiles'] ?? '' ) );
		$s['tiles']      = str_replace( [ '%7B', '%7D' ], [ '{', '}' ], $s['tiles'] ) ?: Module::defaults()['tiles'];
		$s['attr']       = wp_kses( $p['attr'] ?? '', [ 'a' => [ 'href' => [] ] ] );
		$s['gmaps_key']  = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) ( $p['gmaps_key'] ?? '' ) );
		update_option( Module::OPTION, $s );
		Store::log( 'settings', 0, 'save', 'Ajustes de Territorio guardados', 'audit' );
		flush_rewrite_rules( false );
		wp_safe_redirect( admin_url( 'admin.php?page=wakoo-t-settings&saved=1' ) );
		exit;
	}

	/* ---------------------------------------------------------------- boxes */

	public static function boxes() {
		foreach ( [ Module::PROJECT, Module::COMPANY, Module::NEED, Module::GEO, Module::IND, Module::COURSE, Module::LESSON ] as $t ) {
			add_meta_box( 'wkt_fields', __( 'Datos de la ficha', 'wakoo' ), [ __CLASS__, 'fields_box' ], $t, 'normal', 'high' );
		}
		add_meta_box( 'wkt_case', __( 'Tramitación del expediente', 'wakoo' ), [ __CLASS__, 'case_box' ], Module::CASE_T, 'normal', 'high' );
		add_meta_box( 'wkt_files', __( 'Documentos privados', 'wakoo' ), [ __CLASS__, 'files_box' ], [ Module::CASE_T, Module::COMPANY ], 'side' );
		add_meta_box( 'wkt_log', __( 'Historial', 'wakoo' ), [ __CLASS__, 'log_box' ], [ Module::CASE_T, Module::COMPANY, Module::RFQ ], 'normal' );
		add_meta_box( 'wkt_rfq', __( 'Consulta', 'wakoo' ), [ __CLASS__, 'rfq_box' ], Module::RFQ, 'normal', 'high' );
		add_meta_box( 'wkt_cert', __( 'Certificado', 'wakoo' ), [ __CLASS__, 'cert_box' ], Module::CERT, 'normal', 'high' );
	}

	private static function input( $key, $def, $val ) {
		$n = 'wkt[' . $key . ']';
		$h = '<div><label for="wkt_' . esc_attr( $key ) . '">' . esc_html( $def[0] ) . '</label>';
		switch ( $def[1] ) {
			case 'area':
				$h .= '<textarea id="wkt_' . esc_attr( $key ) . '" name="' . esc_attr( $n ) . '">' . esc_textarea( (string) $val ) . '</textarea>';
				break;
			case 'select':
				$h .= '<select id="wkt_' . esc_attr( $key ) . '" name="' . esc_attr( $n ) . '">';
				foreach ( $def[2] as $k => $l ) { $h .= '<option value="' . esc_attr( $k ) . '"' . selected( (string) $val, (string) $k, false ) . '>' . esc_html( $l ) . '</option>'; }
				$h .= '</select>';
				break;
			default:
				$t  = [ 'num' => 'number', 'date' => 'date', 'url' => 'url' ][ $def[1] ] ?? 'text';
				$h .= '<input type="' . $t . '" id="wkt_' . esc_attr( $key ) . '" name="' . esc_attr( $n ) . '" value="' . esc_attr( (string) $val ) . '"' . ( 'num' === $def[1] ? ' step="any"' : '' ) . '>';
		}
		return $h . '</div>';
	}

	public static function fields_box( $post ) {
		wp_nonce_field( 'wkt_save_' . $post->ID, '_wkt_nonce' );
		$f = self::fields( $post->post_type );
		echo '<div class="wkt-f wkt-g">';
		foreach ( $f as $k => $d ) {
			if ( 'quiz' === $k || 'series' === $k || 'geojson' === $k ) { continue; }
			echo self::input( $k, $d, Module::meta( $post->ID, $k ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div><div class="wkt-f">';
		foreach ( [ 'quiz', 'series', 'geojson' ] as $k ) {
			if ( isset( $f[ $k ] ) ) { echo self::input( $k, $f[ $k ], Module::meta( $post->ID, $k ) ); } // phpcs:ignore WordPress.Security.EscapeOutput
		}
		if ( Module::COMPANY === $post->post_type ) {
			$pub = (array) Module::meta( $post->ID, 'public', [] );
			echo '<p><strong>' . esc_html__( 'Datos de contacto que el titular autorizó publicar:', 'wakoo' ) . '</strong> ' . esc_html( $pub ? implode( ', ', array_intersect_key( Forms::contact_fields(), array_flip( $pub ) ) ) : __( 'ninguno', 'wakoo' ) ) . '</p>';
			echo '<p class="description">' . esc_html__( 'Moderación: «Pendiente de revisión» no aparece en el directorio; «Publicar» lo muestra. El nivel «Documentación verificada» solo debe marcarse tras revisar los documentos privados.', 'wakoo' ) . '</p>';
		}
		if ( Module::PROJECT === $post->post_type ) {
			echo '<p class="description">' . esc_html__( 'No publique coordenadas aproximadas como levantamientos oficiales: si la ubicación no está verificada, el mapa la omite. Marque siempre si la inversión es una estimación o una cifra verificada, con su fuente y fecha.', 'wakoo' ) . '</p>';
		}
		if ( Module::LESSON === $post->post_type ) {
			echo '<p class="description">' . esc_html__( 'El contenido de la lección es el texto principal (editor). La evaluación es opcional; si existe, la lección se completa al aprobarla.', 'wakoo' ) . '</p>';
		}
		echo '</div>';
	}

	public static function save( $id, $post ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
		if ( ! isset( $_POST['_wkt_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wkt_nonce'] ) ), 'wkt_save_' . $id ) ) { return; }
		if ( ! current_user_can( 'edit_post', $id ) ) { return; }
		$in = isset( $_POST['wkt'] ) && is_array( $_POST['wkt'] ) ? wp_unslash( $_POST['wkt'] ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( Module::CASE_T === $post->post_type ) { self::save_case( $id, $in ); return; }
		$changed = [];
		foreach ( self::fields( $post->post_type ) as $k => $d ) {
			if ( ! array_key_exists( $k, $in ) ) { continue; }
			$v = $in[ $k ];
			if ( 'area' === $d[1] ) {
				$v = in_array( $k, [ 'quiz', 'geojson' ], true ) ? self::json_or_empty( $v ) : sanitize_textarea_field( $v );
			} elseif ( 'select' === $d[1] ) {
				$v = array_key_exists( (string) $v, $d[2] ) ? (string) $v : '';
			} elseif ( 'num' === $d[1] ) {
				$v = is_numeric( $v ) ? $v + 0 : '';
			} elseif ( 'url' === $d[1] ) {
				$v = esc_url_raw( $v );
			} elseif ( 'date' === $d[1] ) {
				$v = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $v ) ? $v : '';
			} else {
				$v = sanitize_text_field( $v );
				if ( in_array( $k, [ 'lat', 'lng' ], true ) ) { $v = is_numeric( $v ) && abs( (float) $v ) <= ( 'lat' === $k ? 90 : 180 ) ? (string) (float) $v : ''; }
			}
			if ( (string) Module::meta( $id, $k ) !== (string) $v ) { $changed[] = $k; }
			update_post_meta( $id, Module::PRE . $k, $v );
		}
		if ( $changed ) {
			Store::log( $post->post_type, $id, 'edit', 'Campos cambiados: ' . implode( ', ', $changed ), Module::COMPANY === $post->post_type ? 'internal' : 'audit' );
		}
	}

	private static function json_or_empty( $v ) {
		$v = trim( (string) $v );
		if ( '' === $v ) { return ''; }
		$d = json_decode( $v, true );
		return null === $d ? '' : wp_json_encode( $d, JSON_UNESCAPED_UNICODE );
	}

	/** Status changes and moderation are logged; publishing a company or need notifies its owner. */
	public static function moderation( $new, $old, $post ) {
		if ( $new === $old || ! in_array( $post->post_type, [ Module::COMPANY, Module::NEED, Module::PROJECT, Module::IND ], true ) ) { return; }
		Store::log( $post->post_type, $post->ID, 'status', sprintf( 'Estado de publicación: %s → %s', $old, $new ), 'internal' );
		if ( 'publish' === $new && in_array( $post->post_type, [ Module::COMPANY, Module::NEED ], true ) ) {
			$u = get_userdata( (int) $post->post_author );
			if ( $u ) { Module::mail( $u->user_email, __( 'Publicado en el directorio', 'wakoo' ), sprintf( __( '«%s» ya está publicado.', 'wakoo' ), $post->post_title ) ); }
		}
	}

	/* ---------------------------------------------------------------- cases */

	public static function case_box( $post ) {
		wp_nonce_field( 'wkt_save_' . $post->ID, '_wkt_nonce' );
		$m   = function ( $k ) use ( $post ) { return Module::meta( $post->ID, $k ); };
		$st  = Module::statuses();
		$who = get_userdata( (int) $post->post_author );
		$staff = get_users( [ 'capability' => 'edit_others_wk_cases', 'fields' => [ 'ID', 'display_name' ] ] );
		echo '<div class="wkt-f"><p><strong>' . esc_html__( 'Código', 'wakoo' ) . ':</strong> ' . esc_html( $m( 'code' ) ) . ' · <strong>' . esc_html__( 'Solicitante', 'wakoo' ) . ':</strong> ' . esc_html( $who ? $who->display_name . ' <' . $who->user_email . '>' : '—' ) . '</p>';
		echo '<p class="description">' . esc_html__( 'La ventanilla registra, orienta y hace seguimiento. No concede permisos ni aprueba proyectos: oriente hacia los organismos competentes.', 'wakoo' ) . '</p>';
		echo '<table class="widefat striped"><tbody>';
		$rows = [ __( 'Promotor o empresa', 'wakoo' ) => $m( 'promoter' ), __( 'Contacto', 'wakoo' ) => $m( 'contact' ), __( 'Tipo de iniciativa', 'wakoo' ) => $m( 'kind' ), __( 'Madurez declarada', 'wakoo' ) => Module::stages()[ $m( 'maturity' ) ] ?? '', __( 'Sector', 'wakoo' ) => Module::term_names( $post->ID, Module::T_SECTOR ), __( 'Municipio', 'wakoo' ) => Module::term_names( $post->ID, Module::T_MUN ), __( 'Localización', 'wakoo' ) => $m( 'location' ), __( 'Inversión preliminar (declarada)', 'wakoo' ) => $m( 'amount' ) ? $m( 'currency' ) . ' ' . number_format_i18n( (float) $m( 'amount' ) ) : '', __( 'Empleos estimados (declarados)', 'wakoo' ) => $m( 'jobs' ) ?: '', __( 'Servicios requeridos', 'wakoo' ) => $m( 'services' ) ];
		foreach ( $rows as $k => $v ) { echo '<tr><th style="width:220px">' . esc_html( $k ) . '</th><td>' . nl2br( esc_html( (string) $v ) ) . '</td></tr>'; }
		echo '</tbody></table><div class="wkt-g">';
		echo '<div><label>' . esc_html__( 'Estado de tramitación', 'wakoo' ) . '</label><select name="wkt[status]">';
		foreach ( $st as $k => $d ) { echo '<option value="' . esc_attr( $k ) . '"' . selected( $m( 'status' ), $k, false ) . '>' . esc_html( $d[0] ) . '</option>'; }
		echo '</select></div><div><label>' . esc_html__( 'Responsable asignado', 'wakoo' ) . '</label><select name="wkt[assignee]"><option value="0">—</option>';
		foreach ( $staff as $u ) { echo '<option value="' . (int) $u->ID . '"' . selected( (int) $m( 'assignee' ), (int) $u->ID, false ) . '>' . esc_html( $u->display_name ) . '</option>'; }
		echo '</select></div></div><label>' . esc_html__( 'Requisitos recibidos', 'wakoo' ) . '</label>';
		$cl = (array) $m( 'checklist' );
		foreach ( Module::requirements() as $i => $r ) {
			echo '<label style="font-weight:400"><input type="checkbox" name="wkt[checklist][]" value="' . (int) $i . '"' . checked( in_array( $i, array_map( 'intval', $cl ), true ), true, false ) . '> ' . esc_html( $r ) . '</label>';
		}
		echo '<label>' . esc_html__( 'Mensaje para el solicitante (lo verá en su panel y por correo)', 'wakoo' ) . '</label><textarea name="wkt[public_msg]"></textarea>';
		echo '<label>' . esc_html__( 'Nota interna (solo el equipo)', 'wakoo' ) . '</label><textarea name="wkt[internal]" style="background:#fffbea"></textarea>';
		echo '<p><label style="font-weight:400"><input type="checkbox" name="wkt[notify]" value="1" checked> ' . esc_html__( 'Avisar al solicitante por correo de los cambios de estado y mensajes', 'wakoo' ) . '</label></p></div>';
	}

	public static function save_case( $id, $in ) {
		$st   = Module::statuses();
		$old  = (string) Module::meta( $id, 'status' );
		$new  = isset( $in['status'] ) && isset( $st[ $in['status'] ] ) ? $in['status'] : $old;
		$mail = [];
		if ( $new && $new !== $old ) {
			update_post_meta( $id, Module::PRE . 'status', $new );
			Store::log( Module::CASE_T, $id, 'status_change', sprintf( __( 'Estado: %s', 'wakoo' ), $st[ $new ][0] ), 'public' );
			$mail[] = sprintf( __( 'Nuevo estado: %s', 'wakoo' ), $st[ $new ][0] );
		}
		$as = (int) ( $in['assignee'] ?? 0 );
		if ( $as !== (int) Module::meta( $id, 'assignee' ) && ( ! $as || user_can( $as, 'edit_others_wk_cases' ) ) ) {
			update_post_meta( $id, Module::PRE . 'assignee', $as );
			Store::log( Module::CASE_T, $id, 'assign', $as ? 'Asignado a ' . get_the_author_meta( 'display_name', $as ) : 'Sin responsable', 'internal' );
			if ( $as && $as !== get_current_user_id() ) { Module::mail( get_the_author_meta( 'user_email', $as ), sprintf( __( 'Se le asignó el expediente %s', 'wakoo' ), Module::meta( $id, 'code' ) ), admin_url( 'post.php?post=' . $id . '&action=edit' ) ); }
		}
		$cl  = array_values( array_unique( array_map( 'intval', (array) ( $in['checklist'] ?? [] ) ) ) );
		$was = array_map( 'intval', (array) Module::meta( $id, 'checklist', [] ) );
		if ( $cl != $was ) { // phpcs:ignore Universal.Operators.StrictComparisons
			update_post_meta( $id, Module::PRE . 'checklist', $cl );
			Store::log( Module::CASE_T, $id, 'checklist', sprintf( 'Requisitos marcados: %d de %d', count( $cl ), count( Module::requirements() ) ), 'internal' );
		}
		$pm = sanitize_textarea_field( $in['public_msg'] ?? '' );
		if ( '' !== $pm ) {
			Store::log( Module::CASE_T, $id, 'staff', $pm, 'public' );
			$mail[] = $pm;
		}
		$note = sanitize_textarea_field( $in['internal'] ?? '' );
		if ( '' !== $note ) { Store::log( Module::CASE_T, $id, 'note', $note, 'internal' ); }
		if ( $mail && ! empty( $in['notify'] ) ) {
			$u = get_userdata( (int) get_post_field( 'post_author', $id ) );
			if ( $u ) { Module::mail( $u->user_email, sprintf( __( 'Novedades en su solicitud %s', 'wakoo' ), Module::meta( $id, 'code' ) ), implode( "\n\n", $mail ) . "\n\n" . ( Module::page_url( 'cases' ) ?: home_url( '/' ) ) ); }
		}
	}

	public static function files_box( $post ) {
		$files = Store::files( $post->ID );
		if ( ! $files ) { echo '<p>' . esc_html__( 'Sin documentos.', 'wakoo' ) . '</p>'; return; }
		echo '<ul>';
		foreach ( $files as $f ) {
			$drop = wp_nonce_url( admin_url( 'admin-post.php?action=wakoo_t_file_drop&p=' . $post->ID . '&f=' . $f['id'] ), 'wakoo_t_drop_' . $post->ID );
			echo '<li><a href="' . esc_url( Store::download_url( $post->ID, $f['id'] ) ) . '">' . esc_html( $f['name'] ) . '</a> <small>(' . esc_html( size_format( $f['size'] ) . ', ' . wp_date( 'd/m/Y', $f['time'] ) ) . ')</small>';
			if ( current_user_can( 'edit_post', $post->ID ) ) { echo ' · <a href="' . esc_url( $drop ) . '" onclick="return confirm(\'' . esc_js( __( '¿Eliminar este documento?', 'wakoo' ) ) . '\')">' . esc_html__( 'eliminar', 'wakoo' ) . '</a>'; }
			echo '</li>';
		}
		echo '</ul><p class="description">' . esc_html__( 'Sin URL pública: solo el titular y el equipo autorizado pueden descargarlos, y cada descarga queda registrada.', 'wakoo' ) . '</p>';
	}

	public static function file_drop() {
		$pid = (int) ( $_GET['p'] ?? 0 );
		if ( ! $pid || ! current_user_can( 'edit_post', $pid ) || ! check_admin_referer( 'wakoo_t_drop_' . $pid ) ) { wp_die( esc_html__( 'No autorizado.', 'wakoo' ) ); }
		$tok = preg_replace( '/[^A-Za-z0-9]/', '', (string) wp_unslash( $_GET['f'] ?? '' ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$name = Store::files( $pid )[ $tok ]['name'] ?? $tok;
		if ( Store::drop_file( $pid, $tok ) ) { Store::log( get_post_type( $pid ), $pid, 'file_drop', 'Documento eliminado: ' . $name, 'internal' ); }
		wp_safe_redirect( admin_url( 'post.php?post=' . $pid . '&action=edit' ) );
		exit;
	}

	public static function log_box( $post ) {
		$lines = Store::lines( $post->post_type, $post->ID, [ 'public', 'internal' ] );
		if ( ! $lines ) { echo '<p>' . esc_html__( 'Sin actuaciones todavía.', 'wakoo' ) . '</p>'; return; }
		echo '<div class="wkt-tl">';
		foreach ( array_reverse( $lines ) as $l ) {
			$u = $l->user_id ? get_the_author_meta( 'display_name', $l->user_id ) : __( 'Sistema', 'wakoo' );
			echo '<div class="' . ( 'internal' === $l->vis ? 'i' : '' ) . '"><small>' . esc_html( get_date_from_gmt( $l->created, 'd/m/Y H:i' ) . ' · ' . $u . ' · ' . $l->kind ) . ' <span class="wkt-b ' . ( 'internal' === $l->vis ? 'i' : '' ) . '">' . esc_html( 'internal' === $l->vis ? __( 'interno', 'wakoo' ) : __( 'visible al solicitante', 'wakoo' ) ) . '</span></small>' . nl2br( esc_html( $l->message ) ) . '</div>';
		}
		echo '</div>';
	}

	public static function rfq_box( $post ) {
		$to   = (int) Module::meta( $post->ID, 'to' );
		$from = (int) Module::meta( $post->ID, 'from' );
		$a    = get_userdata( (int) $post->post_author );
		echo '<p><strong>' . esc_html__( 'De', 'wakoo' ) . ':</strong> ' . esc_html( $from ? get_the_title( $from ) : ( $a ? $a->display_name : '—' ) ) . ' · <strong>' . esc_html__( 'Para', 'wakoo' ) . ':</strong> ' . esc_html( get_the_title( $to ) ) . ' · <strong>' . esc_html__( 'Tipo', 'wakoo' ) . ':</strong> ' . esc_html( Module::meta( $post->ID, 'kind' ) ) . '</p><div style="background:#fff;border:1px solid #dcdcde;padding:10px">' . nl2br( esc_html( $post->post_content ) ) . '</div><p class="description">' . esc_html__( 'Moderación: puede pasar la consulta a la papelera si incumple las normas de uso. El portal no interviene en precios, contratos ni adjudicaciones.', 'wakoo' ) . '</p>';
	}

	public static function cert_box( $post ) {
		wp_nonce_field( 'wkt_save_' . $post->ID, '_wkt_nonce' );
		foreach ( [ 'code' => __( 'Código', 'wakoo' ), 'name' => __( 'Nombre', 'wakoo' ), 'course_title' => __( 'Curso', 'wakoo' ), 'hours' => __( 'Horas', 'wakoo' ), 'date' => __( 'Fecha', 'wakoo' ) ] as $k => $l ) {
			echo '<p><strong>' . esc_html( $l ) . ':</strong> ' . esc_html( (string) Module::meta( $post->ID, $k ) ) . '</p>';
		}
		echo '<p><a class="button" target="_blank" href="' . esc_url( home_url( '/?wkt_cert=' . rawurlencode( (string) Module::meta( $post->ID, 'code' ) ) ) ) . '">' . esc_html__( 'Ver certificado', 'wakoo' ) . '</a></p>';
		echo '<p class="description">' . esc_html__( 'Para anular un certificado, páselo a la papelera: la verificación dejará de encontrarlo.', 'wakoo' ) . '</p>';
	}

	/* ---------------------------------------------------------------- columns */

	public static function case_cols( $c ) {
		return array_slice( $c, 0, 2 ) + [ 'wkt_code' => __( 'Código', 'wakoo' ), 'wkt_status' => __( 'Estado', 'wakoo' ), 'wkt_as' => __( 'Responsable', 'wakoo' ) ] + array_slice( $c, 2 );
	}

	public static function case_col( $col, $id ) {
		if ( 'wkt_code' === $col ) { echo esc_html( Module::meta( $id, 'code' ) ); }
		if ( 'wkt_status' === $col ) { echo esc_html( Module::statuses()[ Module::meta( $id, 'status' ) ][0] ?? '' ); }
		if ( 'wkt_as' === $col ) { $a = (int) Module::meta( $id, 'assignee' ); echo esc_html( $a ? get_the_author_meta( 'display_name', $a ) : '—' ); }
	}

	public static function project_cols( $c ) {
		return array_slice( $c, 0, 2 ) + [ 'wkt_stage' => __( 'Estado', 'wakoo' ), 'wkt_amt' => __( 'Inversión', 'wakoo' ) ] + array_slice( $c, 2 );
	}

	public static function project_col( $col, $id ) {
		if ( 'wkt_stage' === $col ) { echo esc_html( Module::stages()[ Module::meta( $id, 'stage', 'conceptual' ) ] ?? '' ); }
		if ( 'wkt_amt' === $col ) { $m = Module::money( $id ); echo esc_html( $m ? $m . ( 'verified' === Module::meta( $id, 'amount_kind' ) ? '' : ' (' . __( 'estimación', 'wakoo' ) . ')' ) : '—' ); }
	}

	public static function company_cols( $c ) {
		return array_slice( $c, 0, 2 ) + [ 'wkt_level' => __( 'Verificación', 'wakoo' ) ] + array_slice( $c, 2 );
	}

	public static function company_col( $col, $id ) {
		if ( 'wkt_level' === $col ) { echo esc_html( Module::levels()[ Module::meta( $id, 'level', 'registrada' ) ] ?? '' ); }
	}

	/* ---------------------------------------------------------------- map layers */

	public static function layer_fields( $term ) {
		$c = get_term_meta( $term->term_id, 'wk_color', true ) ?: '#174A7E';
		$p = get_term_meta( $term->term_id, 'wk_public', true );
		wp_nonce_field( 'wkt_layer', '_wkt_layer' );
		echo '<tr class="form-field"><th>' . esc_html__( 'Color', 'wakoo' ) . '</th><td><input type="color" name="wk_color" value="' . esc_attr( $c ) . '"></td></tr>';
		echo '<tr class="form-field"><th>' . esc_html__( 'Capa pública', 'wakoo' ) . '</th><td><label><input type="checkbox" name="wk_public" value="1"' . checked( $p, '1', false ) . '> ' . esc_html__( 'Visible al público (si no, solo la ve el equipo con sesión iniciada)', 'wakoo' ) . '</label></td></tr>';
	}

	public static function layer_save( $tid ) {
		if ( ! isset( $_POST['_wkt_layer'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wkt_layer'] ) ), 'wkt_layer' ) || ! current_user_can( 'edit_others_wk_geos' ) ) { return; }
		update_term_meta( $tid, 'wk_color', sanitize_hex_color( wp_unslash( $_POST['wk_color'] ?? '' ) ) ?: '#174A7E' );
		update_term_meta( $tid, 'wk_public', empty( $_POST['wk_public'] ) ? '0' : '1' );
		Store::log( 'layer', $tid, 'edit', 'Capa del mapa editada', 'audit' );
	}

	public static function geo_page() {
		echo '<div class="wrap"><h1>' . esc_html__( 'Importar al mapa', 'wakoo' ) . '</h1>';
		if ( isset( $_GET['n'] ) ) { echo '<div class="notice notice-success"><p>' . esc_html( sprintf( __( 'Elementos importados: %d (como borrador; revíselos y publíquelos).', 'wakoo' ), (int) $_GET['n'] ) ) . '</p></div>'; } // phpcs:ignore WordPress.Security.NonceVerification
		echo '<p>' . esc_html__( 'Suba un GeoJSON (FeatureCollection) o un CSV con columnas: nombre, lat, lng, capa, verificado (si/no), fuente, publico (si/no), descripcion. Los elementos entran como borrador y sin marca de verificación salvo que el archivo lo indique.', 'wakoo' ) . '</p>';
		echo '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'wakoo_t_geo_import' );
		echo '<input type="hidden" name="action" value="wakoo_t_geo_import"><input type="file" name="geo" accept=".geojson,.json,.csv" required> ';
		echo '<input type="text" name="layer" placeholder="' . esc_attr__( 'Capa por defecto', 'wakoo' ) . '"> ';
		submit_button( __( 'Importar', 'wakoo' ), 'primary', 'submit', false );
		echo '</form></div>';
	}

	public static function geo_import() {
		if ( ! current_user_can( 'edit_others_wk_geos' ) || ! check_admin_referer( 'wakoo_t_geo_import' ) ) { wp_die( esc_html__( 'No autorizado.', 'wakoo' ) ); }
		$f = $_FILES['geo'] ?? null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( ! $f || ! empty( $f['error'] ) || $f['size'] > 10 * MB_IN_BYTES ) { wp_die( esc_html__( 'Archivo no válido.', 'wakoo' ) ); }
		$raw   = file_get_contents( $f['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$def   = sanitize_text_field( wp_unslash( $_POST['layer'] ?? '' ) );
		$items = [];
		$json  = json_decode( (string) $raw, true );
		if ( is_array( $json ) && ( $json['type'] ?? '' ) === 'FeatureCollection' ) {
			foreach ( (array) ( $json['features'] ?? [] ) as $ft ) {
				$pr = (array) ( $ft['properties'] ?? [] );
				$g  = (array) ( $ft['geometry'] ?? [] );
				$it = [ 'name' => $pr['name'] ?? $pr['nombre'] ?? __( 'Elemento', 'wakoo' ), 'layer' => $pr['layer'] ?? $pr['capa'] ?? $def, 'verified' => $pr['verified'] ?? $pr['verificado'] ?? '', 'source' => $pr['source'] ?? $pr['fuente'] ?? '', 'public' => $pr['public'] ?? $pr['publico'] ?? '', 'desc' => $pr['description'] ?? $pr['descripcion'] ?? '' ];
				if ( 'Point' === ( $g['type'] ?? '' ) ) { $it['lng'] = $g['coordinates'][0] ?? ''; $it['lat'] = $g['coordinates'][1] ?? ''; } else { $it['geojson'] = wp_json_encode( $g ); }
				$items[] = $it;
			}
		} else {
			$lines = array_map( 'str_getcsv', preg_split( '/\r\n|\r|\n/', trim( (string) $raw ) ) );
			$head  = array_map( function ( $h ) { return sanitize_key( remove_accents( $h ) ); }, (array) array_shift( $lines ) );
			foreach ( $lines as $l ) {
				$r = @array_combine( $head, array_pad( $l, count( $head ), '' ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
				if ( $r ) { $items[] = [ 'name' => $r['nombre'] ?? '', 'lat' => $r['lat'] ?? '', 'lng' => $r['lng'] ?? '', 'layer' => $r['capa'] ?? $def, 'verified' => $r['verificado'] ?? '', 'source' => $r['fuente'] ?? '', 'public' => $r['publico'] ?? '', 'desc' => $r['descripcion'] ?? '' ]; }
			}
		}
		$yes = function ( $v ) { return in_array( strtolower( remove_accents( (string) $v ) ), [ '1', 'si', 'yes', 'true', 'x' ], true ) ? 'yes' : ''; };
		$n   = 0;
		foreach ( array_slice( $items, 0, 2000 ) as $it ) {
			$name = sanitize_text_field( (string) $it['name'] );
			if ( '' === $name ) { continue; }
			$pid = wp_insert_post( [ 'post_type' => Module::GEO, 'post_status' => 'draft', 'post_title' => $name, 'post_content' => sanitize_textarea_field( (string) $it['desc'] ) ] );
			if ( ! $pid || is_wp_error( $pid ) ) { continue; }
			foreach ( [ 'lat', 'lng' ] as $k ) { if ( isset( $it[ $k ] ) && is_numeric( $it[ $k ] ) ) { update_post_meta( $pid, Module::PRE . $k, (string) (float) $it[ $k ] ); } }
			if ( ! empty( $it['geojson'] ) ) { update_post_meta( $pid, Module::PRE . 'geojson', self::json_or_empty( $it['geojson'] ) ); }
			update_post_meta( $pid, Module::PRE . 'verified', $yes( $it['verified'] ) );
			update_post_meta( $pid, Module::PRE . 'public', $yes( $it['public'] ) );
			update_post_meta( $pid, Module::PRE . 'source', sanitize_text_field( (string) $it['source'] ) );
			if ( '' !== (string) $it['layer'] ) { wp_set_object_terms( $pid, [ sanitize_text_field( (string) $it['layer'] ) ], Module::T_LAYER ); }
			$n++;
		}
		Store::log( Module::GEO, 0, 'import', sprintf( 'Importación al mapa: %d elementos (borrador)', $n ), 'audit' );
		wp_safe_redirect( admin_url( 'admin.php?page=wakoo-t-geo&n=' . $n ) );
		exit;
	}
}
