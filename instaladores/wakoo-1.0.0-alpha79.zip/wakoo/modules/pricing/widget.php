<?php
/**
 * Wakoo Pricing widget: plans with a monthly / yearly switch.
 *
 * @package Wakoo
 */

namespace Wakoo\Modules\Pricing;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

defined( 'ABSPATH' ) || die();

class Widget extends Widget_Base {

	public function get_name() { return 'wakoo-pricing'; }
	public function get_title() { return __( 'Precios mensual/anual (Wakoo)', 'wakoo' ); }
	public function get_icon() { return 'eicon-price-table'; }
	public function get_categories() { return [ 'basic', 'general' ]; }
	public function get_keywords() { return [ 'precios', 'pricing', 'planes', 'mensual', 'anual', 'suscripcion', 'wakoo' ]; }
	public function get_script_depends() { return [ 'wakoo-pricing' ]; }
	public function get_style_depends() { return [ 'wakoo-pricing' ]; }

	protected function register_controls() {

		$this->start_controls_section( 'sec_switch', [ 'label' => __( 'Interruptor', 'wakoo' ) ] );
		$this->add_control( 'label_m', [ 'label' => __( 'Texto mensual', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Mensual', 'wakoo' ) ] );
		$this->add_control( 'label_y', [ 'label' => __( 'Texto anual', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Anual', 'wakoo' ) ] );
		$this->add_control( 'badge', [ 'label' => __( 'Etiqueta de ahorro', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Ahorra 20%', 'wakoo' ) ] );
		$this->add_control( 'default_period', [
			'label'   => __( 'Periodo inicial', 'wakoo' ),
			'type'    => Controls_Manager::SELECT,
			'default' => 'm',
			'options' => [ 'm' => __( 'Mensual', 'wakoo' ), 'y' => __( 'Anual', 'wakoo' ) ],
		] );
		// Texts under each price, editable so every language of a multilingual site gets its own.
		$this->add_control( 'per', [ 'label' => __( 'Texto tras el precio', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( '/mes', 'wakoo' ), 'separator' => 'before' ] );
		$this->add_control( 'bill_m', [ 'label' => __( 'Nota del precio mensual', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'facturado cada mes', 'wakoo' ) ] );
		$this->add_control( 'bill_y', [ 'label' => __( 'Nota del precio anual', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'facturado una vez al año', 'wakoo' ) ] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_plans', [ 'label' => __( 'Planes', 'wakoo' ) ] );
		$r = new Repeater();
		$r->add_control( 'name', [ 'label' => __( 'Nombre', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Plan', 'wakoo' ) ] );
		$r->add_control( 'desc', [ 'label' => __( 'Descripción', 'wakoo' ), 'type' => Controls_Manager::TEXT ] );
		$r->add_control( 'currency', [ 'label' => __( 'Moneda', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '€' ] );
		$r->add_control( 'price_m', [ 'label' => __( 'Precio mensual', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '10' ] );
		$r->add_control( 'price_y', [ 'label' => __( 'Precio anual (por mes)', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => '8', 'description' => __( 'Lo que se muestra al elegir anual, ya dividido por mes.', 'wakoo' ) ] );
		$r->add_control( 'features', [ 'label' => __( 'Características (una por línea)', 'wakoo' ), 'type' => Controls_Manager::TEXTAREA, 'default' => "Función uno\nFunción dos" ] );
		$r->add_control( 'btn_text', [ 'label' => __( 'Texto del botón', 'wakoo' ), 'type' => Controls_Manager::TEXT, 'default' => __( 'Elegir plan', 'wakoo' ) ] );
		$r->add_control( 'btn_link_m', [ 'label' => __( 'Enlace mensual', 'wakoo' ), 'type' => Controls_Manager::URL ] );
		$r->add_control( 'btn_link_y', [ 'label' => __( 'Enlace anual', 'wakoo' ), 'type' => Controls_Manager::URL, 'description' => __( 'Si lo dejas vacío se usa el mensual.', 'wakoo' ) ] );
		$r->add_control( 'featured', [ 'label' => __( 'Destacado', 'wakoo' ), 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ] );
		$this->add_control( 'plans', [
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $r->get_controls(),
			'title_field' => '{{{ name }}}',
			'default'     => [
				[ 'name' => 'Básico', 'price_m' => '9', 'price_y' => '7', 'features' => "1 sitio\nSoporte por email" ],
				[ 'name' => 'Pro', 'price_m' => '29', 'price_y' => '23', 'features' => "5 sitios\nSoporte prioritario\nInformes", 'featured' => 'yes' ],
				[ 'name' => 'Agencia', 'price_m' => '79', 'price_y' => '63', 'features' => "Sitios ilimitados\nMarca blanca\nSoporte 24/7" ],
			],
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'sec_style', [ 'label' => __( 'Estilo', 'wakoo' ), 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'accent', [
			'label'     => __( 'Color principal', 'wakoo' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#6C5CE7',
			'selectors' => [ '{{WRAPPER}} .wakoo-price' => '--wk-price: {{VALUE}};' ],
		] );
		$this->end_controls_section();
	}

	private function link_attrs( $link ) {
		if ( empty( $link['url'] ) ) { return 'href="#"'; }
		$out = 'href="' . esc_url( $link['url'] ) . '"';
		if ( ! empty( $link['is_external'] ) ) { $out .= ' target="_blank"'; }
		$rel = [];
		if ( ! empty( $link['is_external'] ) ) { $rel[] = 'noopener'; }
		if ( ! empty( $link['nofollow'] ) ) { $rel[] = 'nofollow'; }
		return $out . ( $rel ? ' rel="' . esc_attr( implode( ' ', $rel ) ) . '"' : '' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		$plans = (array) ( $s['plans'] ?? [] );
		if ( ! $plans ) { return; }
		$def = ( 'y' === ( $s['default_period'] ?? 'm' ) ) ? 'y' : 'm';

		echo '<div class="wakoo-price" data-period="' . esc_attr( $def ) . '">';
		echo '<div class="wakoo-price__switch" role="group" aria-label="' . esc_attr__( 'Periodo de facturación', 'wakoo' ) . '">';
		echo '<button type="button" class="wakoo-price__opt" data-p="m" aria-pressed="' . ( 'm' === $def ? 'true' : 'false' ) . '">' . esc_html( $s['label_m'] ) . '</button>';
		echo '<button type="button" class="wakoo-price__track" role="switch" aria-checked="' . ( 'y' === $def ? 'true' : 'false' ) . '" aria-label="' . esc_attr__( 'Cambiar entre mensual y anual', 'wakoo' ) . '"><span></span></button>';
		echo '<button type="button" class="wakoo-price__opt" data-p="y" aria-pressed="' . ( 'y' === $def ? 'true' : 'false' ) . '">' . esc_html( $s['label_y'] ) . '</button>';
		if ( ! empty( $s['badge'] ) ) { echo '<span class="wakoo-price__badge">' . esc_html( $s['badge'] ) . '</span>'; }
		echo '</div><div class="wakoo-price__grid">';

		foreach ( $plans as $p ) {
			$feat = ( 'yes' === ( $p['featured'] ?? '' ) );
			$link_y = ! empty( $p['btn_link_y']['url'] ) ? $p['btn_link_y'] : ( $p['btn_link_m'] ?? [] );
			echo '<div class="wakoo-price__plan' . ( $feat ? ' is-featured' : '' ) . '">';
			echo '<h3 class="wakoo-price__name">' . esc_html( $p['name'] ) . '</h3>';
			if ( ! empty( $p['desc'] ) ) { echo '<p class="wakoo-price__desc">' . esc_html( $p['desc'] ) . '</p>'; }
			echo '<div class="wakoo-price__amount"><span class="wakoo-price__cur">' . esc_html( $p['currency'] ) . '</span>';
			echo '<span class="wakoo-price__num" data-m="' . esc_attr( $p['price_m'] ) . '" data-y="' . esc_attr( $p['price_y'] ) . '">' . esc_html( 'y' === $def ? $p['price_y'] : $p['price_m'] ) . '</span>';
			echo '<span class="wakoo-price__per">' . esc_html( $s['per'] ?? __( '/mes', 'wakoo' ) ) . '</span></div>';
			echo '<p class="wakoo-price__bill"><span data-show="m">' . esc_html( $s['bill_m'] ?? __( 'facturado cada mes', 'wakoo' ) ) . '</span><span data-show="y">' . esc_html( $s['bill_y'] ?? __( 'facturado una vez al año', 'wakoo' ) ) . '</span></p>';
			echo '<ul class="wakoo-price__feat">';
			foreach ( preg_split( '/\r\n|\r|\n/', (string) $p['features'] ) as $f ) {
				$f = trim( $f );
				if ( '' !== $f ) { echo '<li>' . esc_html( $f ) . '</li>'; }
			}
			echo '</ul>';
			echo '<a class="wakoo-price__btn" data-href-m="' . esc_attr( ! empty( $p['btn_link_m']['url'] ) ? $p['btn_link_m']['url'] : '#' ) . '" data-href-y="' . esc_attr( ! empty( $link_y['url'] ) ? $link_y['url'] : '#' ) . '" ' . $this->link_attrs( 'y' === $def ? $link_y : ( $p['btn_link_m'] ?? [] ) ) . '>' . esc_html( $p['btn_text'] ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '</div>';
		}
		echo '</div></div>';
	}
}
